/** Automatically generated file. DO NOT MODIFY */
package wei.mark.standout;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}