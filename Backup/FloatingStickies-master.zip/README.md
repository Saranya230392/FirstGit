FloatingStickies
================
Floating Sticky notes that stay on top of all other apps! Easily dock them to the left side to keep your screen real-estate at full potential. Useful for quick note taking. Closing a note will delete its text.  All stickies are auto-saved!

Massive thanks to Mark Wei for his StandOut Library. Floating Stickies is licensed under Apache 2.0

![RoundR](http://i.imgur.com/S9PN4Wf.png)

### Features
- On top of all other apps (access from anywhere)
- Dock to the side & resize
- Copy/Paste/Share
- Smooth fun animations & colors
- Save the state of the stickies
- Simple & Clean look

### Development
- XDA Forums: http://forum.xda-developers.com/showthread.php?t=2127834

### Download
- Google Play: https://play.google.com/store/apps/details?id=genius.mohammad.floating.stickies

Give it a try and leave a comment to further the development. Thanks!
