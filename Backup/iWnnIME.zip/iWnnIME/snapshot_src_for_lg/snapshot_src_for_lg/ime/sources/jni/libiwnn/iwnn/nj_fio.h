/**
 * @file
 *   共通部(ファイルアクセス処理) 定義ファイル
 *
 *   共通部 ファイルアクセス処理での各種定義
 *
 * @author
 *   Copyright (C) OMRON SOFTWARE Co., Ltd. 2011 All Rights Reserved.
 */

#ifndef _NJ_FIO_H_
#define _NJ_FIO_H_

#ifdef NJ_OPT_DIC_STORAGE
#include <stdio.h>
#endif /* NJ_OPT_DIC_STORAGE */

#endif /* _NJ_FIO_H_ */
