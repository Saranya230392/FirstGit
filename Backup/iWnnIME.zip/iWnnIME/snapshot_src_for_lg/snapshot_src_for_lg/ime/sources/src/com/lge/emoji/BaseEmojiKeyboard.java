/*
 * Copyright (C) 2008-2013  OMRON SOFTWARE Co., Ltd.  All Rights Reserved.
 */
package com.lge.emoji;

import android.inputmethodservice.InputMethodService;

public class BaseEmojiKeyboard extends EmojiKeyboard {

    public BaseEmojiKeyboard(InputMethodService ims) {
        super(ims);
    }
}
