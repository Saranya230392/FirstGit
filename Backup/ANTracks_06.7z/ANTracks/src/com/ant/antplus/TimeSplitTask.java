package com.ant.antplus;

public class TimeSplitTask implements PeriodicTask {
    @Override
    public void run(TrackRecordingService service) {
      service.insertStatisticsMarker(service.getLastLocation());
    }

    @Override
    public void shutdown() {
    }

    @Override
    public void start() {
    }
}
