package com.ant.antplus;

import android.app.Dialog;
import android.app.TabActivity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.content.res.Resources;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.Window;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TabHost;
import android.widget.Toast;


public class ANTracks extends TabActivity implements OnTouchListener,
    OnSharedPreferenceChangeListener {

    private static ANTracks instance;
    private ChartActivity chartActivity;    
    private DialogManager dialogManager;
    private MenuManager menuManager;

    private ANTracksProviderUtils providerUtils;
    private SharedPreferences sharedPreferences;    
    
    private NavControls navControls;
    
    private boolean isBound = false;
    private long selectedTrackId = -1;
    private long recordingTrackId = -1;
    
    private ITrackRecordingService trackRecordingService;
    private boolean startNewTrackRequested = false;    

    private final ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
          Log.d(ANTracksConstants.TAG, "ANTracks: Service now connected.");
          // Delay setting the service until we are done with initialization.
          ITrackRecordingService trackRecordingService =
              ITrackRecordingService.Stub.asInterface(service);
          try {
            // TODO: Send a start service intent and broadcast service started
            // message to avoid the hack below and a race condition.
            if (startNewTrackRequested) {
              startNewTrackRequested = false;
              startRecordingNewTrack(trackRecordingService);
            }
          } finally {
            ANTracks.this.trackRecordingService = trackRecordingService;
          }
        }

        @Override
        public void onServiceDisconnected(ComponentName className) {
          Log.d(ANTracksConstants.TAG, "ANTracks: Service now disconnected.");
          trackRecordingService = null;
        }
      };
    
    private final Runnable changeTab = new Runnable() {
      public void run() {
        getTabHost().setCurrentTab(navControls.getCurrentIcons());
      }
    };

    
    public static ANTracks getInstance() {
        return instance;
      }

    public boolean isRecording() {
        if (trackRecordingService == null) {
          // Fall back to alternative check method.
          return isRecordingBasedOnSharedPreferences();
        }
        try {
          return trackRecordingService.isRecording();
          // TODO: We catch Exception, because after eliminating the service process
          // all exceptions it may throw are no longer wrapped in a RemoteException.
        } catch (Exception e) {
          Log.e(ANTracksConstants.TAG, "ANTracks: Remote exception.", e);

          // Fall back to alternative check method.
          return isRecordingBasedOnSharedPreferences();
        }
      }

      private boolean isRecordingBasedOnSharedPreferences() {
        // TrackRecordingService guarantees that recordingTrackId is set to
        // -1 if the track has been stopped.
        return recordingTrackId >= 0;
      }

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(ANTracksConstants.TAG, "ANTracks.onCreate");
        super.onCreate(savedInstanceState);
        instance = this;
        providerUtils = ANTracksProviderUtils.Factory.get(this);
        menuManager = new MenuManager(this);
        sharedPreferences = getSharedPreferences(ANTracksSettings.SETTINGS_NAME, 0);
        dialogManager = new DialogManager(this);

        // We don't need a window title bar:
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        final Resources res = getResources();
        final TabHost tabHost = getTabHost();
        tabHost.addTab(tabHost.newTabSpec("tab1")
            .setIndicator("Map", res.getDrawable(
                android.R.drawable.ic_menu_mapmode))
            .setContent(new Intent(this, MapViewDisplay.class)));
        tabHost.addTab(tabHost.newTabSpec("tab2")
            .setIndicator("Stats", res.getDrawable(R.drawable.menu_stats))
            .setContent(new Intent(this, StatsActivity.class)));
        tabHost.addTab(tabHost.newTabSpec("tab3")
            .setIndicator("Chart", res.getDrawable(R.drawable.menu_elevation))
            .setContent(new Intent(this, ChartActivity.class)));
        
        tabHost.getTabWidget().setVisibility(View.GONE);
        
        RelativeLayout layout = new RelativeLayout(this);
        LayoutParams params =
            new LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT);
        layout.setLayoutParams(params);
        navControls =
            new NavControls(this, layout,
                getResources().obtainTypedArray(R.array.left_icons),
                getResources().obtainTypedArray(R.array.right_icons),
                changeTab);
        navControls.show();
        tabHost.addView(layout);
        layout.setOnTouchListener(this);

        if (sharedPreferences != null) {
            selectedTrackId =
                sharedPreferences.getLong(getString(R.string.selected_track_key), -1);
            recordingTrackId = sharedPreferences.getLong(
                getString(R.string.recording_track_key), -1);
            sharedPreferences.registerOnSharedPreferenceChangeListener(this);
            Log.d(ANTracksConstants.TAG, "recordingTrackId: " + recordingTrackId
                + ", selectedTrackId: " + selectedTrackId);
            if (recordingTrackId > 0) {
              Intent startIntent = new Intent(this, TrackRecordingService.class);
              startService(startIntent);
            }

        // Check if we got invoked via the VIEW intent:
        Intent intent = getIntent();
        String action;
        if (intent != null && (action = intent.getAction()) != null) {
          if (action.equals(Intent.ACTION_MAIN)) {
            // Do nothing.
          } else if (action.equals(Intent.ACTION_VIEW)) {
            if (intent.getScheme() != null && intent.getScheme().equals("file")) {
              Log.w(ANTracksConstants.TAG,
                  "Received a VIEW intent with file scheme. Importing.");
//              importGpxFile(intent.getData().getPath());
            } else {
              Log.w(ANTracksConstants.TAG,
                  "Received a VIEW intent with unsupported scheme "
                  + intent.getScheme());
            }
          } else {
            Log.w(ANTracksConstants.TAG,
                "Received an intent with unsupported action " + action);
          }
        } else {
          Log.d(ANTracksConstants.TAG, "Received an intent with no action.");
        }
      }
    }

    @Override
    protected void onDestroy() {
      Log.d(ANTracksConstants.TAG, "ANTracks.onDestroy");
      tryUnbindTrackRecordingService();
      super.onDestroy();
    }

    @Override
    protected void onPause() {
      Log.d(ANTracksConstants.TAG, "ANTracks.onPause");
      tryUnbindTrackRecordingService();
      super.onPause();
    }

    @Override
    protected void onResume() {
      Log.d(ANTracksConstants.TAG, "ANTracks.onResume");
      tryBindTrackRecordingService();
      super.onResume();
    }

    @Override
    protected void onStop() {
      Log.d(ANTracksConstants.TAG, "Tracks.onStop");
//      TempFileCleaner.clean();
      super.onStop();
    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
      // TODO Auto-generated method stub
      if (event.getAction() == MotionEvent.ACTION_DOWN) {
          navControls.show();
        }
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
      super.onCreateOptionsMenu(menu);
      return menuManager.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
      menuManager.onPrepareOptionsMenu(menu, providerUtils.getLastTrack() != null,
          isRecording(), selectedTrackId >= 0);
      return super.onPrepareOptionsMenu(menu);
    }

    @Override
    protected Dialog onCreateDialog(int id, Bundle args) {
      return dialogManager.onCreateDialog(id, args);
    }

    @Override
    protected Dialog onCreateDialog(int id) {
      return dialogManager.onCreateDialog(id, null);
    }

    @Override
    protected void onPrepareDialog(int id, Dialog dialog) {
      super.onPrepareDialog(id, dialog);
      dialogManager.onPrepareDialog(id, dialog);
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
      return menuManager.onOptionsItemSelected(item)
          ? true
          : super.onOptionsItemSelected(item);
    }

 
    private void tryUnbindTrackRecordingService() {
        if (isBound) {
          Log.d(ANTracksConstants.TAG,
              "ANTracks: Trying to unbind from track recording service...");
          try {
            unbindService(serviceConnection);
            Log.d(ANTracksConstants.TAG, "ANTracks: ...unbind finished!");
          } catch (IllegalArgumentException e) {
            Log.d(ANTracksConstants.TAG,
                "ANTracks: Tried unbinding, but service was not registered.", e);
          }
          isBound = false;
        }
    }
    
    public void setChartActivity(ChartActivity chartActivity) {
        this.chartActivity = chartActivity;
    }
   
    public DialogManager getDialogManager() {
        return dialogManager;
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences,
            String key) {
          if (key != null && key.equals(getString(R.string.selected_track_key))) {
            selectedTrackId = sharedPreferences.getLong(
                getString(R.string.selected_track_key), -1);
          }
          if (key != null && key.equals(getString(R.string.recording_track_key))) {
            recordingTrackId = sharedPreferences.getLong(
                getString(R.string.recording_track_key), -1);
          }
    }

    public Location getCurrentLocation() {
        LocationManager locationManager =
            (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) {
          return null;
        }
        final long maxAgeMilliSeconds = 1000 * 60 * 1;  // 1 minute
        final long maxAgeNetworkMilliSeconds = 1000 * 60 * 10;  // 10 minutes
        final long now = System.currentTimeMillis();
        Location loc = locationManager.getLastKnownLocation(
            ANTracksConstants.GPS_PROVIDER);
        if (loc == null || loc.getTime() < now - maxAgeMilliSeconds) {

          loc = locationManager.getLastKnownLocation(
              LocationManager.NETWORK_PROVIDER);
          if (loc == null || loc.getTime() < now - maxAgeNetworkMilliSeconds) {
            Toast.makeText(this, getString(R.string.status_no_location),
                Toast.LENGTH_LONG).show();
            return null;
          } else {
           Toast.makeText(this, getString(R.string.status_approximate_location),
               Toast.LENGTH_LONG).show();
          }
        }
        return loc;
      }

      public Location getLastLocation() {
        if (providerUtils.getLastLocationId(recordingTrackId) < 0) {
          return null;
        }
        LocationManager locationManager =
            (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        return locationManager.getLastKnownLocation(ANTracksConstants.GPS_PROVIDER);
      }
      
      private void startRecordingNewTrack(
          ITrackRecordingService trackRecordingService) {
        try {
          recordingTrackId = trackRecordingService.startNewTrack();
          setSelectedTrackId(recordingTrackId);
          Toast.makeText(this, getString(R.string.status_now_recording),
              Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
          Toast.makeText(this,
              getString(R.string.error_unable_to_start_recording),
              Toast.LENGTH_SHORT).show();
          Log.w(ANTracksConstants.TAG, "Unable to start recording.", e);
        }
      }

      public void startRecording() {
        if (trackRecordingService == null) {
            startNewTrackRequested = true;
            Intent startIntent = new Intent(this, TrackRecordingService.class);
            startService(startIntent);
            tryBindTrackRecordingService();
          } else {
            startRecordingNewTrack(trackRecordingService);
          }
        }

      public void stopRecording() {
        if (trackRecordingService != null) {
          long currentTrackId = recordingTrackId;
          try {
            trackRecordingService.endCurrentTrack();
          } catch (Exception e) {
            Log.e(ANTracksConstants.TAG, "Unable to stop recording.", e);
          }
          Intent intent = new Intent(ANTracks.this, ANTracksDetails.class);
          intent.putExtra("trackid", currentTrackId);
          intent.putExtra("hasCancelButton", false);
          startActivity(intent);
        }
        tryUnbindTrackRecordingService();
        try {
          stopService(new Intent(ANTracks.this, TrackRecordingService.class));
        } catch (SecurityException e) {
          Log.e(ANTracksConstants.TAG,
              "Encountered a security exception when trying to stop service.", e);
        }
        trackRecordingService = null;
      }
      
      private void tryBindTrackRecordingService() {
        Log.d(ANTracksConstants.TAG,
            "ANTracks: Trying to bind to track recording service...");
        bindService(new Intent(this, TrackRecordingService.class),
            serviceConnection, 0);
        Log.d(ANTracksConstants.TAG, "ANTracks: ...bind finished!");
        isBound = true;
      }      

      public void setSelectedTrackId(final long trackId) {
          sharedPreferences
              .edit()
              .putLong(getString(R.string.selected_track_key), trackId)
              .commit();
        }
  
}
