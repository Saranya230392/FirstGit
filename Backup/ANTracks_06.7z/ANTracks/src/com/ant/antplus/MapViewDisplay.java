
package com.ant.antplus;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.database.Cursor;
import android.hardware.GeomagneticField;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;

public class MapViewDisplay extends MapActivity
    implements View.OnTouchListener, View.OnClickListener,
    SharedPreferences.OnSharedPreferenceChangeListener  {
    
	public String TAG = "MapViewDisplay";

    ListView list;    
    Intent intent;

    private MenuManager menuManager;
    private static final int TRACKPOINT_BUFFER_SIZE = 1024;    

    private long selectedTrackId = -1;
    private long recordingTrackId = -1;
    private boolean keepMyLocationVisible;
    private long firstSeenLocationId = -1;
    private long lastSeenLocationId = -1;
    private double variation;
    private int minRequiredAccuracy =
        ANTracksSettings.DEFAULT_MIN_REQUIRED_ACCURACY;
    private boolean haveGoodFix;
    private Location currentLocation;
    private HandlerThread updateTrackThread;
    private Handler updateTrackHandler;
    private ANTracksProviderUtils providerUtils;
    private SharedPreferences sharedPreferences;
    
	private RelativeLayout screen;
	private MapView mapView;
	private ANTracksOverlay mapOverlay;
	private LinearLayout messagePane;
	private TextView messageText;
	private LinearLayout busyPane;
	private ImageButton optionsBtn;
	
	private MenuItem myLocation;
	private MenuItem toggleLayers;
	
	private SensorManager sensorManager;
	private LocationManager locationManager;
	private ContentObserver observer;
	private ContentObserver waypointObserver;
	
	/** Handler for callbacks to the UI thread */
	private final Handler uiHandler = new Handler();

    private final Runnable updateTrackRunnable = new Runnable() {
      @Override
      public void run() {
        if (!isATrackSelected()) {
          return;
        }
        
        readAllNewTrackPoints();
      }
    };

    @Override
    protected boolean isRouteDisplayed() {
      return false;
    }

    /**
     * We are displaying a location. This needs to return true in order to comply
     * with the terms of service.
     */
    @Override
    protected boolean isLocationDisplayed() {
      return true;
    }

    
    @Override
    public void onCreate(Bundle bundle) 
    {
        Log.d(ANTracksConstants.TAG, "ANTracksMap.onCreate");        
        super.onCreate(bundle);
        
        // The volume we want to control is the Text-To-Speech volume
        int volumeStream =
            new StatusAnnouncerFactory(ApiFeatures.getInstance()).getVolumeStream();
        setVolumeControlStream(volumeStream);

        providerUtils = ANTracksProviderUtils.Factory.get(this);
        // We don't need a window title bar:
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Inflate the layout:
        setContentView(R.layout.antracks_layout);

        // Remove the window's background because the MapView will obscure it
        getWindow().setBackgroundDrawable(null);
        
        // Set up a map overlay:
        screen = (RelativeLayout) findViewById(R.id.screen);
        mapView = (MapView) findViewById(R.id.map);
        mapView.requestFocus();
        mapOverlay = new ANTracksOverlay(this);
        mapView.getOverlays().add(mapOverlay);
        mapView.setOnTouchListener(this);
        messagePane = (LinearLayout) findViewById(R.id.messagepane);
        messageText = (TextView) findViewById(R.id.messagetext);
        busyPane = (LinearLayout) findViewById(R.id.busypane);
        optionsBtn = (ImageButton) findViewById(R.id.showOptions);

        optionsBtn.setOnCreateContextMenuListener(contextMenuListener);
        optionsBtn.setOnClickListener(this);

        setupZoomControls();
        
        // Get the sensor and location managers:
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        locationManager =
            (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        updateTrackThread = new HandlerThread("updateTrackThread");
        updateTrackThread.start();
        updateTrackHandler = new Handler(updateTrackThread.getLooper());

        // Register observer for the track point provider:
        Handler contentHandler = new Handler();
        observer = new ContentObserver(contentHandler) {
          @Override
          public void onChange(boolean selfChange) {
            Log.d(ANTracksConstants.TAG, "MyTracksMap: ContentObserver.onChange");
            if (!isRecordingSelected()) {
              // No track, or one other than the recording track is selected,
              // don't bother.
              return;
            }
            // Update can potentially be lengthy, put it in its own thread:
            updateTrackHandler.post(updateTrackRunnable);
            super.onChange(selfChange);
          }
        };

        waypointObserver = new ContentObserver(contentHandler) {
          @Override
          public void onChange(boolean selfChange) {
            Log.d(ANTracksConstants.TAG,
                "MyTracksMap: ContentObserver.onChange waypoints");
            if (!isATrackSelected()) {
              return;
            }
            updateTrackHandler.post(restoreWaypointsRunnable);
            super.onChange(selfChange);
          }
        };

        // Read shared preferences and register change listener.
        sharedPreferences = getSharedPreferences(ANTracksSettings.SETTINGS_NAME, 0);
        if (sharedPreferences != null) {
          reloadSharedPreferences(sharedPreferences, null);
          updateOptionsButton();
          sharedPreferences.registerOnSharedPreferenceChangeListener(this);
        }
    }
    
    @Override
    protected void onDestroy() {
      Log.d(ANTracksConstants.TAG, "ANTracksMap.onDestroy");

      if (updateTrackThread != null) {
        ApiFeatures.getInstance().getApiPlatformAdapter().stopHandlerThread(
            updateTrackThread);
      }
      if (sharedPreferences != null) {
        sharedPreferences.unregisterOnSharedPreferenceChangeListener(this);
      }
      
      super.onDestroy();
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        myLocation = menu.add(0, ANTracksConstants.MENU_MY_LOCATION, 0,R.string.mylocation);
        	myLocation.setIcon(android.R.drawable.ic_menu_mylocation);
        toggleLayers = menu.add(0, ANTracksConstants.MENU_TOGGLE_LAYERS, 0, R.string.switch_to_sat);
        	toggleLayers.setIcon(android.R.drawable.ic_menu_mapmode);
//        menu.add(0,1,0,"TestTest");
//        menu.add(0,2,0,"2");
//        menu.add(0,3,0,"3");
       return true;
    }

    public void forceError()
    {
       if(true)
       {
         throw new Error("Woops");
       }
    }
    
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        toggleLayers.setTitle(mapView.isSatellite() ?
                R.string.switch_to_map : R.string.switch_to_sat);
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
      switch (item.getItemId()) {
        case ANTracksConstants.MENU_MY_LOCATION: {
		  Log.d(TAG, "onOptionsItemSelected: MyLocation");
          Location loc = ANTracks.getInstance().getCurrentLocation();
          if (loc != null) {
            currentLocation = loc;
            setVariation(currentLocation);
            mapOverlay.setMyLocation(loc);
            mapView.invalidate();
            GeoPoint geoPoint = ANTracksUtils.getGeoPoint(loc);
            MapController controller = mapView.getController();
            controller.animateTo(geoPoint);
            if (mapView.getZoomLevel() < 18) {
              controller.setZoom(18);
            }
            keepMyLocationVisible = true;
          }
          return true;
        }
        case ANTracksConstants.MENU_TOGGLE_LAYERS: {
          toggleLayer();
          return true;
        }
      }
      return super.onOptionsItemSelected(item);
    }

    
    private final OnCreateContextMenuListener contextMenuListener = new OnCreateContextMenuListener() {
        
      @Override
      public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        menu.setHeaderTitle(R.string.tracklist_this_track);
        menu.add(0, ANTracksConstants.MENU_EDIT, 0, R.string.tracklist_edit_track);
        if (!isRecordingSelected()) {
          menu.add(0, ANTracksConstants.MENU_SEND_TO_GOOGLE, 0, R.string.tracklist_send_to_google);
          SubMenu share = menu.addSubMenu(0, ANTracksConstants.MENU_SHARE, 0, R.string.tracklist_share_track);
          share.add(0, ANTracksConstants.MENU_SHARE_LINK, 0, R.string.tracklist_share_link);
          share.add(0, ANTracksConstants.MENU_SHARE_GPX_FILE, 0, R.string.tracklist_share_gpx_file);
          share.add(0, ANTracksConstants.MENU_SHARE_KML_FILE, 0, R.string.tracklist_share_kml_file);
          share.add(0, ANTracksConstants.MENU_SHARE_CSV_FILE, 0, R.string.tracklist_share_csv_file);
          share.add(0, ANTracksConstants.MENU_SHARE_TCX_FILE, 0, R.string.tracklist_share_tcx_file);
          SubMenu save = menu.addSubMenu(0, ANTracksConstants.MENU_WRITE_TO_SD_CARD, 0, R.string.tracklist_write_to_sd);
          save.add(0, ANTracksConstants.MENU_SAVE_GPX_FILE, 0, R.string.tracklist_save_as_gpx);
          save.add(0, ANTracksConstants.MENU_SAVE_KML_FILE, 0, R.string.tracklist_save_as_kml);
          save.add(0, ANTracksConstants.MENU_SAVE_CSV_FILE, 0, R.string.tracklist_save_as_csv);
          save.add(0, ANTracksConstants.MENU_SAVE_TCX_FILE, 0, R.string.tracklist_save_as_tcx);
          menu.add(0, ANTracksConstants.MENU_CLEAR_MAP, 0, R.string.tracklist_clear_map);
          menu.add(0, ANTracksConstants.MENU_DELETE, 0, R.string.tracklist_delete_track);
        }
      }
    };
    
    @Override
    public boolean onMenuItemSelected(int featureId, MenuItem item) {
      if (!super.onMenuItemSelected(featureId, item)) {
        if (isATrackSelected()) {
//          ANTracks.getInstance().onActivityResult(
//              ANTracksConstants.getActionFromMenuId(item.getItemId()), RESULT_OK,
//              new Intent());
          return true;
        }
      }
      return false;
    }

    public void myClickHandler(View target){
        switch(target.getId()){
            case R.id.zoomin:
                 mapView.getController().zoomIn();
                 break;
            case R.id.zoomout:
                 mapView.getController().zoomOut();
                 break;
            case R.id.sat:
                 mapView.setStreetView(true);
                 break;
            case R.id.street:
                Log.d(TAG, "switch:street");
                intent = new Intent(this, ListFromArray.class);                                                         
                startActivity(intent);
                break;
            case R.id.traffic:
        }
    }
    
    @Override
    public boolean onTouch(View arg0, MotionEvent arg1) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        // TODO Auto-generated method stub
    }     
    private boolean isATrackSelected() {
        return selectedTrackId >= 0;
    }

    private boolean isRecordingSelected() {
        return isATrackSelected() && selectedTrackId == recordingTrackId;
    }

    private void readAllNewTrackPoints() {
    int numPoints = mapOverlay.getNumLocations();
    if (numPoints >= ANTracksConstants.MAX_DISPLAYED_TRACK_POINTS) {
        loadSelectedTrack();
        return;
    }
	
	// Keep a copy of selectedTrackId, because it can change asynchronously.
	long currentSelectedTrackId = selectedTrackId;
	long lastStoredLocationId =
	  providerUtils.getLastLocationId(currentSelectedTrackId);
	int samplingFrequency = -1;
	Location location = new Location("");
	while (currentSelectedTrackId == selectedTrackId) {
	Cursor cursor = null;
	try {
	  cursor = providerUtils.getLocationsCursor(currentSelectedTrackId,
	      lastSeenLocationId + 1, TRACKPOINT_BUFFER_SIZE, false);
	  if (cursor == null || !cursor.moveToFirst()) {
	    // No (more) data
	    break;
    }

	final int idColumnIdx = cursor.getColumnIndexOrThrow(
	  TrackPointsColumns._ID);
	do {
	long locationId = cursor.getLong(idColumnIdx);
	lastSeenLocationId = locationId;
	if (firstSeenLocationId == -1) {
	  // This was our first point, keep its ID
	  firstSeenLocationId = locationId;
	}
	if (samplingFrequency == -1) {
	  // Now we already have at least one point, calculate the sampling
	  // frequency
	  long numTotalPoints = lastStoredLocationId - firstSeenLocationId;
	  samplingFrequency = (int) (1 + numTotalPoints
	      / ANTracksConstants.TARGET_DISPLAYED_TRACK_POINTS);
	  // TODO: This shouldn't happen after adding currentSelectedTrackId,
	  // but just to be safe until we have 100% confidence.
	  if (samplingFrequency <= 0) {
	    Log.w(ANTracksConstants.TAG, "readAllNewTrackPoints: samplingFreq <= 0, numTotalPoints = "
	        + numTotalPoints + ", trackId = " + currentSelectedTrackId);
	    samplingFrequency = 1;
	  }
	}

	providerUtils.fillLocation(cursor, location);

	// Include a point if it fits one of the following criteria:
	// - Has the mod for the sampling frequency (includes first point).
	// - Is the last point and we are not recording this track.
	// - The point is a segment split
	if (numPoints % samplingFrequency == 0 ||
	    (!isRecordingSelected() && locationId == lastStoredLocationId) ||
	    !ANTracksUtils.isValidLocation(location)) {
	  // No need to allocate a new location (we can safely reuse the existing).
	  mapOverlay.addLocation(location);
	}

	numPoints++;
	} while (cursor.moveToNext() &&
	  currentSelectedTrackId == selectedTrackId);
	} finally {
		if (cursor != null) {
			cursor.close();
			}
	  	  }
		}
		mapView.postInvalidate();
	}
      
  protected void setupZoomControls() {
      mapView.setBuiltInZoomControls(true);
    }

  private final Runnable restoreWaypointsRunnable = new Runnable() {
      @Override
      public void run() {
        if (!isATrackSelected()) {
          return;
        }

        Cursor cursor = null;
        mapOverlay.clearWaypoints();
        try {
          // We will silently drop extra waypoints to make the app responsive.
          // TODO: Try to only load the waypoints in the view port.
          cursor = providerUtils.getWaypointsCursor(
              selectedTrackId, 0,
              ANTracksConstants.MAX_DISPLAYED_WAYPOINTS_POINTS);
          if (cursor != null && cursor.moveToFirst()) {
            do {
              mapOverlay.addWaypoint(providerUtils.createWaypoint(cursor));
            } while (cursor.moveToNext());
          }
        } catch (RuntimeException e) {
          Log.w(ANTracksConstants.TAG, "Caught an unexpected exception.", e);
        } finally {
          if (cursor != null) {
            cursor.close();
          }
        }
        mapView.postInvalidate();
      }
    };

    private void reloadSharedPreferences(SharedPreferences sharedPreferences,
            String key) {
          if (key == null ||
              key.equals(getString(R.string.min_required_accuracy_key))) {
            minRequiredAccuracy = sharedPreferences.getInt(
                getString(R.string.min_required_accuracy_key),
                ANTracksSettings.DEFAULT_MIN_REQUIRED_ACCURACY);
          }
          if (key == null || key.equals(getString(R.string.recording_track_key))) {
            recordingTrackId = sharedPreferences.getLong(
                getString(R.string.recording_track_key), -1);
          }
          if (key == null || key.equals(getString(R.string.selected_track_key))) {
            setSelectedTrack(sharedPreferences.getLong(
                getString(R.string.selected_track_key), -1));
          }
          
          // Show end marker if the track has been selected and is not recording.
          // Note: This check must be *after* a call to setSelectedTrack(...) above.
          if (isATrackSelected()) {
            mapOverlay.setShowEndMarker(!isRecordingSelected());
            mapView.postInvalidate();
          }
        }

    public void setSelectedTrack(final long trackId) {
        Log.d(ANTracksConstants.TAG, "ANTracksMap.setSelectedTrack: "
            + "selectedTrackId = " + selectedTrackId + ", trackId = " + trackId);

        if (selectedTrackId == trackId) {
          // Selected track did not change, nothing to do.
          mapOverlay.setTrackDrawingEnabled(isATrackSelected());
          updateOptionsButton();
          mapView.invalidate();
          return;
        }

        if (trackId < 0) {
          // Remove selection.
          selectedTrackId = -1;
          mapOverlay.setTrackDrawingEnabled(false);
          mapOverlay.clearWaypoints();
          updateOptionsButton();
          mapView.invalidate();
          return;
        }

        busyPane.setVisibility(View.VISIBLE);
        selectedTrackId = trackId;
        loadSelectedTrack();
      }
    
    private void loadSelectedTrack() {
        updateTrackHandler.post(restoreTrackRunnable);
        updateTrackHandler.post(restoreWaypointsRunnable);
        updateTrackHandler.post(setSelectedTrackRunnable);
      }
    
    private void updateOptionsButton() {
        optionsBtn.setVisibility(
            isATrackSelected() ? View.VISIBLE : View.INVISIBLE);
      }

    private Runnable restoreTrackRunnable = new Runnable() {
        @Override
        public void run() {
          if (!isATrackSelected()) {
            return;
          }
          
          mapOverlay.clearPoints();
          firstSeenLocationId = -1;
          lastSeenLocationId = -1;
          readAllNewTrackPoints();
        }
      };

    private final Runnable setSelectedTrackRunnable = new Runnable() {
      @Override
      public void run() {
        uiHandler.post(new Runnable() {
          public void run() {
            showTrack(selectedTrackId);
            mapOverlay.setTrackDrawingEnabled(isATrackSelected());
            mapOverlay.setShowEndMarker(!isRecordingSelected());
            mapView.invalidate();
            busyPane.setVisibility(View.GONE);
            updateOptionsButton();
          }
        });
      }
    };
    public void showTrack(long trackId) {
        if (mapView == null) {
          return;
        }

        Track track = providerUtils.getTrack(trackId);
        if (track == null || track.getNumberOfPoints() < 2) {
          return;
        }

        TripStatistics stats = track.getStatistics();
        int bottom = stats.getBottom();
        int left = stats.getLeft();
        int latSpanE6 = stats.getTop() - bottom;
        int lonSpanE6 = stats.getRight() - left;
        if (latSpanE6 > 0
            && latSpanE6 < 180E6
            && lonSpanE6 > 0
            && lonSpanE6 < 360E6) {
          keepMyLocationVisible = false;
          GeoPoint center = new GeoPoint(
              bottom + latSpanE6 / 2,
              left + lonSpanE6 / 2);
          if (ANTracksUtils.isValidGeoPoint(center)) {
            mapView.getController().setCenter(center);
            mapView.getController().zoomToSpan(latSpanE6, lonSpanE6);
          }
        }
      }
    
    public void setVariation(Location location) {
        long timestamp = location.getTime();
        if (timestamp == 0) {
          // Hack for Samsung phones which don't populate the time field
          timestamp = System.currentTimeMillis();
        }

        GeomagneticField field = new GeomagneticField(
            (float) location.getLatitude(),
            (float) location.getLongitude(),
            (float) location.getAltitude(),
            timestamp);
        variation = field.getDeclination();

        Log.d(ANTracksConstants.TAG,
            "ANTracksMap: Variation reset to " + variation + " degrees.");
    }

    public void toggleLayer() {
        mapView.setSatellite(!mapView.isSatellite());
      }

}
