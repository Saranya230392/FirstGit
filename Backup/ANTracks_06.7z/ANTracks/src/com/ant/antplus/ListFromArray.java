package com.ant.antplus;

import com.ant.antplus.R;

import android.app.*;
import android.content.Intent;
import android.os.*;
import android.widget.*;
import android.widget.AdapterView.OnItemClickListener;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;

public class ListFromArray extends Activity  implements OnItemClickListener
{
	public String TAG = "ListFromArray";
	ListView list;
	Intent intent;
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");		
		setContentView(R.layout.widget_listtest);
		
		ArrayAdapter<CharSequence> Adapter;
		Adapter = ArrayAdapter.createFromResource(this, R.array.antdevices,
				android.R.layout.simple_list_item_1);
		list = (ListView)findViewById(R.id.list);
		list.setAdapter(Adapter);
		list.setOnItemClickListener(this);
	}

@Override
public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
    // TODO Auto-generated method stub
    Activity activity = null;
    //int index =list.getSelectedItemPosition();
    Log.d(TAG, "click:"+arg2);
    switch(arg2){
        case 0:
            Log.d(TAG, "switch0:");
            intent = new Intent(ListFromArray.this, HeartrateDisplay.class);                                                         
            startActivity(intent);                     
            break;
        case 1:
            Log.d(TAG, "switch1:");
            intent = new Intent(ListFromArray.this, StrideDisplay.class);                                                        
            startActivity(intent);               
            break;
        case 2:
            Log.d(TAG, "switch2:");
            intent = new Intent(ListFromArray.this, WeightScaleDisplay.class);                                                         
            startActivity(intent); 
            break;
        case 3:
//            Log.d(TAG, "switch3:");
//            intent = new Intent(ListFromArray.this, MapViewDisplay.class);                                                         
//            startActivity(intent); 
            break;
        default: 
            
    }
}
   
}
