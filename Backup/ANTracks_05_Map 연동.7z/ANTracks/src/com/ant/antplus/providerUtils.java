package com.ant.antplus;

public class providerUtils {

    public static Object getLastTrack() {
        // TODO Auto-generated method stub
        return null;
    }

}
