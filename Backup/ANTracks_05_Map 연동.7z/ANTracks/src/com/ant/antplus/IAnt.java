
package com.ant.antplus;

import android.os.IBinder;

/**
 * The Android Ant API is not finalized, and *will* change. Use at your 
 * own risk.
 *
 * Public API for controlling the Ant Service. 
 *
 * {@hide}
 */
interface IAnt {
    boolean enable();
    boolean disable();
    boolean isEnabled();    
    class Stub{
        public static IAnt asInterface(IBinder pService){
            return null;
        }
        //asInterface(pService);
    }
    boolean ANTTxMessage( byte[] message);   // in byte[] in delete

    boolean ANTResetSystem();
    boolean ANTUnassignChannel(byte channelNumber);
    boolean ANTAssignChannel(byte channelNumber, byte channelType, byte networkNumber);
    boolean ANTSetChannelId(byte channelNumber, int deviceNumber, byte deviceType, byte txType); 
    boolean ANTSetChannelPeriod(byte channelNumber, int channelPeriod);
    boolean ANTSetChannelRFFreq(byte channelNumber, byte radioFrequency);
    boolean ANTSetChannelSearchTimeout(byte channelNumber, byte searchTimeout);
    boolean ANTSetLowPriorityChannelSearchTimeout(byte channelNumber, byte searchTimeout); 
    boolean ANTSetProximitySearch(byte channelNumber, byte searchThreshold);
    boolean ANTSetChannelTxPower(byte channelNumber, byte txPower);
    boolean ANTAddChannelId(byte channelNumber, int deviceNumber, byte deviceType, byte txType, byte listIndex); 
    boolean ANTConfigList(byte channelNumber, byte listSize, byte exclude); 
    boolean ANTOpenChannel(byte channelNumber);
    boolean ANTCloseChannel(byte channelNumber);
    boolean ANTRequestMessage(byte channelNumber, byte messageID);
    boolean ANTSendBroadcastData(byte channelNumber,  byte[] txBuffer); // in byte[] in delete
    boolean ANTSendAcknowledgedData(byte channelNumber,  byte[] txBuffer); // in byte[] in delete

    boolean ANTSendBurstTransferPacket(byte control,  byte[] txBuffer);// in byte[] in delete

    int ANTSendBurstTransfer(byte channelNumber,  byte[] txBuffer);// in byte[] in delete
    int ANTTransmitBurst(byte channelNumber,  byte[] txBuffer, int initialPacket, boolean containsEndOfBurst);// in byte[] in delete

}
