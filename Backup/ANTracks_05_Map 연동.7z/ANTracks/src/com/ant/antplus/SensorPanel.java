package com.ant.antplus;


import com.ant.antplus.R;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.widget.Button;
import android.widget.LinearLayout;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class SensorPanel extends LinearLayout
{
   private TextDisplay mStatus;
   private TextDisplay[] mData;
   private MenuButton mMainButton;
   private Button mStartButton;
   private UIState mState;
   
   private Animation animSearch = null;
   
   public enum UIState
   {
      INIT,
      SEARCH,
      TRACKING_STATUS,
      TRACKING_DATA,
      OFFLINE,
      BAD
   };

   /** Constructor **/
   public SensorPanel(Context context)
   {
      super(context);
      defaultSettings(context);
   }
   
   public SensorPanel(Context context, AttributeSet attrs)
   {
      super(context, attrs);  
      defaultSettings(context);
   }
   
   private void defaultSettings(Context context)
   {
     mState = UIState.INIT;
     animSearch = AnimationUtils.loadAnimation(context, R.anim.fade);
   }
   
   /** Initialization **/
   public void setStatus(TextDisplay theStatus)
   {
      mStatus = theStatus;
   }
   
   public void setMainButton(MenuButton theButton, int offPic, int onPic)
   {
      mMainButton = theButton;
      mMainButton.setLayoutId(this.getId());
      mMainButton.setImageDefault(offPic);
      mMainButton.setImagePressed(onPic);
   }
   
   public MenuButton getMainButton()
   {
      return mMainButton;
   }
   
   public void setStartButton(Button theButton)
   {
      mStartButton = theButton;
   }
   
   public Button getStartButton()
   {
      return mStartButton;
   }
   
   public void setDataCount(int dataCount)
   {
      mData = new TextDisplay[dataCount];
   }
   
   public void addData(TextDisplay theData, int position)
   {
      if(mData != null && position < mData.length)
      {
         mData[position] = theData;
      }
   }
   
   public void setState(UIState theState)
   {
      mState = theState;
   }
   
   public UIState getState()
   {
      return mState;
   }
   
   /** Update UI based on state **/
   public void switchState(UIState theState)
   {
      if(mState == theState)
         return;
      
      mState = theState;
      refreshUI();     
   }
   
   public void refreshUI()
   {
      switch(mState)
      {
         case INIT:  // Right after start up
            setVisibility(INVISIBLE);
            mStatus.setGone();                        // No data or status is displayed at all
            for(int i=0; i < mData.length; i++)
               mData[i].setGone();
            if(mStartButton != null)                  // Start button not visible
            {
               mStartButton.setEnabled(false);
               mStartButton.setVisibility(GONE);
            }
            if(mMainButton != null)                   // Main button off (grayed)
            {
               mMainButton.setState(false);
            }
            break;
         case SEARCH:
            setVisibility(VISIBLE);
            mStatus.setSearch();                      // Display search status
            mStatus.startAnimation(animSearch);
            for(int i=0; i < mData.length; i++)       // Do not display data
               mData[i].setGone();
            if(mStartButton != null)                  // Start button not visible
            {
               mStartButton.setEnabled(false);
               mStartButton.setVisibility(GONE);
            }
            if(mMainButton != null)                   // Main button on (black)
            {
               mMainButton.setState(true);
            }
            break;
         case TRACKING_STATUS:
            setVisibility(VISIBLE);
            mStatus.setText("");                      // Clear text
            mStatus.setActive();                      // Enable status display
            for(int i=0; i < mData.length; i++)       // Do not display data
               mData[i].setGone();
            if(mStartButton != null)                  // Start button enabled
            {
               mStartButton.setEnabled(true);
               mStartButton.setVisibility(VISIBLE);
            }
            if(mMainButton != null)                   // Main button on (black)
            {
               mMainButton.setState(true);
            }
            break;
         case TRACKING_DATA:
            setVisibility(VISIBLE);
            mStatus.setGone();                        // Remove status display
            for(int i=0; i < mData.length; i++)       // Enable data display
            {
               mData[i].setText("");
               mData[i].setActive();
            }
            if(mStartButton != null)                  // Start button gone
            {
               mStartButton.setEnabled(false);
               mStartButton.setVisibility(GONE);
            }
            if(mMainButton != null)                   // Main button on (black)
            {
               mMainButton.setState(true);
            }
            break;
         case OFFLINE:
            setVisibility(VISIBLE);
            mStatus.setOffline();                     // Show Offline status
            for(int i=0; i < mData.length; i++)       // Disable data display
               mData[i].setGone();
            if(mStartButton != null)                  // Start button gone
            {
               mStartButton.setEnabled(false);
               mStartButton.setVisibility(GONE);
            }
            if(mMainButton != null)                   // Main button off (grayed)
            {
               mMainButton.setState(false);
            }
            break;
         case BAD:
            setVisibility(VISIBLE);
            mStatus.setUnavailable();                 // Show Unavailable status
            for(int i=0; i < mData.length; i++)       // Disable data display
               mData[i].setGone();
            if(mStartButton != null)                  // Start button gone
            {
               mStartButton.setEnabled(false);
               mStartButton.setVisibility(GONE);
            }
            if(mMainButton != null)                   // Main button off (grayed)
            {
               mMainButton.setState(false);
            }
            break;
      }
   }
   
   /** Data display **/
   public void printValue(Enum<?> dataType, String str)
   {
      mData[dataType.ordinal()].setActive();
      mData[dataType.ordinal()].setText(str);
   }
   
   public void printStatus(String str)
   {
      mStatus.setActive();
      mStatus.setText(str);
   }
   
   public void enableStartButton(boolean bEnable)
   {
         mStartButton.setEnabled(bEnable);
   }
   
   
   /** Save/restore **/
   public Bundle bundleState()
   {
      Bundle savedState = new Bundle();
      savedState.putInt("UIState", mState.ordinal());
      return savedState;      
   }
   
   public void restoreState(Bundle savedState)
   {
      int temp = savedState.getInt("UIState");
      mState = UIState.values()[temp];
   }

   

}
