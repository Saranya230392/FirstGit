package com.ant.antplus;

import com.ant.antplus.R;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

public class TextDisplay extends TextView
{
   private void defaultSettings()
   {
      setTextSize(getContext().getResources().getDimension(R.dimen.big));
   }
   public TextDisplay(Context context, AttributeSet attrs, int defStyle)
   {
      super(context, attrs, defStyle);
      defaultSettings();
   }
   public TextDisplay(Context context, AttributeSet attrs)
   {
      super(context, attrs);
      defaultSettings();
   }
   public TextDisplay(Context context)
   {
      super(context);
      defaultSettings();
   }
   public void setActive()
   {
      this.setVisibility(VISIBLE);
      setTextColor(getContext().getResources().getColor(R.color.black));
   }
   public void setInactive()
   {
      this.setVisibility(VISIBLE);
      setTextColor(getContext().getResources().getColor(R.color.grey));
   }
   public void setOffline()
   {
      this.setVisibility(VISIBLE);
      setTextColor(getContext().getResources().getColor(R.color.grey));
      setText(getContext().getString(R.string.NoSensor_txt));
   }
   public void setSearch()
   {
      this.setVisibility(VISIBLE);
      setTextColor(getContext().getResources().getColor(R.color.grey));
      setText(getContext().getString(R.string.Search));
   }
   public void setUnavailable()
   {
      this.setVisibility(VISIBLE);
      setTextColor(getContext().getResources().getColor(R.color.grey));
      setText(getContext().getString(R.string.NoANT_txt));
   }
   public void setGone()
   {
      this.setVisibility(GONE);
   }
}
