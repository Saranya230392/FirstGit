package com.ant.antplus;

import com.ant.antplus.R;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class WeightScaleDisplay extends Activity {
    ListView list;
    public void onCreate(Bundle savedInstanceState) 
    {
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.weight_display);
        ArrayAdapter<CharSequence> Adapter;
        Adapter = ArrayAdapter.createFromResource(this, R.array.weight,
        R.layout.array_list);
       
        list = (ListView)findViewById(R.id.ListView01);
        list.setAdapter(Adapter);
    }
}
