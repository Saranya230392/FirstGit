package com.ant.antplus;

import java.util.ArrayList;
import java.util.List;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.ant.antplus.R;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;



public class MappingOverlay extends MapActivity {
    private MapView mapView;
    
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.antracks_layout);
        
        mapView = (MapView) findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
        Drawable marker = getResources().getDrawable(R.drawable.mapmarker);
        marker.setBounds(0,0,marker.getIntrinsicWidth(),marker.getIntrinsicHeight());
        InterestingLocations funPlaces = new InterestingLocations(marker);
        mapView.getOverlays().add(funPlaces);
        
        GeoPoint pt = funPlaces.getCenter();
        mapView.getController().setCenter(pt);
        mapView.getController().setZoom(15);
    }
    @Override
    protected boolean isLocationDisplayed(){
        return false;
    }
    @Override
    protected boolean isRouteDisplayed() {
        // TODO Auto-generated method stub
        return false;
    }
    
    class InterestingLocations extends ItemizedOverlay{
        
        private List<OverlayItem> locations = new ArrayList<OverlayItem>();
        private Drawable marker;
        
        public InterestingLocations(Drawable marker) {
            super(marker);
            this.marker= marker;
            
            GeoPoint disneyMagickingdom  = new GeoPoint((int)(28.418971*1000000),(int)(-81.581436*1000000));
            GeoPoint disneySevenLagoon = new GeoPoint((int)(28.410067*1000000),(int)(-81.583699*1000000));
            locations.add(new OverlayItem(disneyMagickingdom, "Magic kingdom", "magic kingdom"));
            locations.add(new OverlayItem(disneySevenLagoon, "Seven Lagoon", "Seven Lagoon"));
            populate();
            // TODO Auto-generated constructor stub
        }
        
        @Override
        public void draw(Canvas canvas, MapView mapView, boolean shadow){
            super.draw(canvas, mapView, shadow);
            boundCenterBottom(marker);
        }
        
        @Override
        protected OverlayItem createItem(int i) {
            // TODO Auto-generated method stub
            return locations.get(i);
        }

        @Override
        public int size() {
            // TODO Auto-generated method stub
            return locations.size();
        }
        
    }
    
    
}
