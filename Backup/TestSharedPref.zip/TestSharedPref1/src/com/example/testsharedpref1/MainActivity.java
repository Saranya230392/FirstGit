package com.example.testsharedpref1;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private TextView mSharedPrefTextView;
    private Button mButton1, mButton2, mButton3;
    SharedPreferences mSharedPref;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        mSharedPref = getSharedPreferences("pref", MODE_MULTI_PROCESS|MODE_WORLD_READABLE);
        mSharedPrefTextView = (TextView) findViewById(R.id.sharedPrefText);
        mSharedPrefTextView.setText("shared pref is " + mSharedPref.getInt("theme", 0));
        mButton1 = (Button) findViewById(R.id.button1);
        mButton2 = (Button) findViewById(R.id.button2);
        mButton3 = (Button) findViewById(R.id.button3);
        
        OnClickListener l = new OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences.Editor e = mSharedPref.edit();
                switch (v.getId()) {
                case R.id.button1:
                    e.putInt("theme", 1);
                    break;
                case R.id.button2:
                    e.putInt("theme", 2);
                    break;
                case R.id.button3:
                    e.putInt("theme", 3);
                    break;
                }
                e.commit();
                
                mSharedPrefTextView.setText("shared pref is " + mSharedPref.getInt("theme", 0));
            }
        };
        
        mButton1.setOnClickListener(l);
        mButton2.setOnClickListener(l);
        mButton3.setOnClickListener(l);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

}
