

import android.bluetooth.IAnt;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
//import android.os.RemoteException;
import android.util.Log;


/**
 * Wrapper class for implementation of IAnt.aidl, so applications do not care that they are talking to a service.
 */
public class AntInterface {

    public static final String TAG = "ANTInterface";
    private static final boolean DBG = true; //TODO: debug

    public static IAnt sAntReceiver = null;
    
    private static AntInterface INSTANCE;
    /** Used when obtaining a reference to the singleton instance. */
    private static Object INSTANCE_LOCK = new Object();
    
    private static Context sContext = null;
    private static ServiceListener sServiceListener;
    private static boolean sServiceConnected = false;


    /**
     * An interface for notifying AntInterface IPC clients when they have
     * been connected to the ANT service.
     */
     public interface ServiceListener 
     {
         /**
          * Called to notify the client when this proxy object has been
          * connected to the ANT service. Clients must wait for
          * this callback before making IPC calls on the ANT
          * service.
          */
         public void onServiceConnected();

         /**
          * Called to notify the client that this proxy object has been
          * disconnected from the ANT service. Clients must not
          * make IPC calls on the ANT service after this callback.
          * This callback will currently only occur if the application hosting
          * the BluetoothAg service, but may be called more often in future.
          */
         public void onServiceDisconnected();
     }

     
  //Constructor
    private AntInterface(Context context, ServiceListener listener)
    {
        // This will be around as long as this process is
        sContext = context;
        sServiceListener = listener;
    }


    public static AntInterface getInstance(Context context,ServiceListener listener) 
    {
        if(DBG)   Log.d(TAG, "getInstance");

        synchronized (INSTANCE_LOCK) 
        {
            if (INSTANCE == null) 
            {
                if(DBG)   Log.d(TAG, "getInstance: Creating new instance");
                
                // TODO: rohan: bug, each new request for an instance will not have context and listener set to the requested objects
                INSTANCE = new AntInterface(context,listener);
            }
            else
            {
                if(DBG)   Log.d(TAG, "getInstance: Using existing instance");
            }

            if(!sServiceConnected)
            {
                if(DBG)   Log.d(TAG, "getInstance: No connection to proxy service, attempting connection");

                if(!INSTANCE.initService())
                {
                    Log.e(TAG, "getInstance: No connection to proxy service");
                }
            }

            return INSTANCE;
        }
    }


    /**
     * Class for interacting with the ANT interface.
     */
    private static ServiceConnection sIAntConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName pClassName, IBinder pService) {
            // This is called when the connection with the service has been
            // established, giving us the service object we can use to
            // interact with the service.  We are communicating with our
            // service through an IDL interface, so get a client-side
            // representation of that from the raw service object.
            if(DBG)   Log.d(TAG, "sIAntConnection onServiceConnected()");
            sAntReceiver = IAnt.Stub.asInterface(pService);

            sServiceConnected = true;

            // Notify the attached application if it is registered
            if (sServiceListener != null) 
            {
                sServiceListener.onServiceConnected();
            }
            else
            {
                if(DBG) Log.d(TAG, "sIAntConnection onServiceConnected: No service listener registered");
            }
        }

        public void onServiceDisconnected(ComponentName pClassName) {
            // This is called when the connection with the service has been
            // unexpectedly disconnected -- that is, its process crashed.
            if(DBG)   Log.d(TAG, "sIAntConnection onServiceDisconnected()");
            sAntReceiver = null;

            sServiceConnected = false;

            // Notify the attached application if it is registered
            if (sServiceListener != null) 
            {
                sServiceListener.onServiceDisconnected();
            }
            else
            {
                if(DBG) Log.d(TAG, "sIAntConnection onServiceDisconnected: No service listener registered");
            }

            // Try and rebind to the service
            INSTANCE.releaseService();
            INSTANCE.initService();
        }
    };

    /** Binds this activity to the ANT service. */
    private boolean initService() {
        if(DBG)   Log.d(TAG, "initService() entered");

        boolean ret = false;

        if(!sServiceConnected)
        {
            ret = sContext.bindService(new Intent(IAnt.class.getName()), sIAntConnection, Context.BIND_AUTO_CREATE);
            Log.i(TAG, "initService(): Bound with ANT service: " + ret);
            //ret = true;
            //Log.i(TAG, "initService(): Bound with ANT service2: " + ret);            
        }
        else
        {
            if(DBG)   Log.d(TAG, "initService: already initialised service");
            ret = true;
        }
     
        return ret;
    }
    
    /** Unbinds this activity from the ANT service. */
    private void releaseService() {
      if(DBG)   Log.d(TAG, "releaseService() entered");
        
      sContext.unbindService(sIAntConnection);
      sServiceConnected = false;

      if(DBG)   Log.d(TAG, "releaseService() unbound.");
    }


    public boolean destroy()
    {
        if(DBG)   Log.d(TAG, "destroy");

        releaseService();

        INSTANCE = null;

        return true;
    }


    private void antServiceConnectionLost()
    {
        Log.e(TAG, "Connection to ANT service lost");
    }
    
    
    ////-------------------------------------------------
    
    public boolean enable()
    {
        if(DBG)   Log.d(TAG, "enable");

        if(!sServiceConnected)
        {
            // Haven't received 'onConnected' notification yet
            return false;
        }

        boolean result = false;
		result = true;
/*
        try {
            result = sAntReceiver.enable();
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
*/        
        return result;
    }
    
    public boolean disable()
    {
        if(DBG)   Log.d(TAG, "disable");

        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.disable();
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    
    public boolean isEnabled()
    {
        if(DBG)   Log.d(TAG, "isEnabled");

        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.isEnabled();
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }        

    public boolean ANTTxMessage(byte[] message)
    {
        if(DBG)   Log.d(TAG, "ANTTxMessage");

        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTTxMessage(message);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }

    public boolean ANTResetSystem()
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTResetSystem();
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTUnassignChannel(byte channelNumber)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTUnassignChannel(channelNumber);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTAssignChannel(byte channelNumber, byte channelType, byte networkNumber)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTAssignChannel(channelNumber, channelType, networkNumber);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTSetChannelId(byte channelNumber, short deviceNumber, byte deviceType, byte txType)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSetChannelId(channelNumber, deviceNumber, deviceType, txType);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    } 
    public boolean ANTSetChannelPeriod(byte channelNumber, short channelPeriod)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSetChannelPeriod(channelNumber, channelPeriod);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTSetChannelRFFreq(byte channelNumber, byte radioFrequency)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSetChannelRFFreq(channelNumber, radioFrequency);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTSetChannelSearchTimeout(byte channelNumber, byte searchTimeout)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSetChannelSearchTimeout(channelNumber, searchTimeout);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTSetLowPriorityChannelSearchTimeout(byte channelNumber, byte searchTimeout)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSetLowPriorityChannelSearchTimeout(channelNumber, searchTimeout);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    } 
    public boolean ANTSetProximitySearch(byte channelNumber, byte searchThreshold)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSetProximitySearch(channelNumber, searchThreshold);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTAddChannelId(byte channelNumber, short deviceNumber, byte deviceType, byte txType, byte listIndex)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTAddChannelId(channelNumber, deviceNumber, deviceType, txType, listIndex);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    } 
    public boolean ANTConfigList(byte channelNumber, byte listSize, byte exclude)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTConfigList(channelNumber, listSize, exclude);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTOpenChannel(byte channelNumber)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTOpenChannel(channelNumber);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTCloseChannel(byte channelNumber)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTCloseChannel(channelNumber);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTRequestMessage(byte channelNumber, byte messageID)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTRequestMessage(channelNumber, messageID);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTSendBroadcastData(byte channelNumber, byte[] txBuffer)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSendBroadcastData(channelNumber, txBuffer);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    }
    public boolean ANTSendAcknowledgedData(byte channelNumber, byte[] txBuffer)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSendAcknowledgedData(channelNumber, txBuffer);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    } 

    public boolean ANTSendBurstTransferPacket(byte control, byte[] txBuffer)
    {
        if(!sServiceConnected)
        {
            return false;
        }

        boolean result = false;
        try {
            result = sAntReceiver.ANTSendBurstTransferPacket(control, txBuffer);
        } catch (Exception ex) {
            antServiceConnectionLost();
        }
        return result;
    } 

    public int ANTSendBurstTransfer(byte channelNumber, byte[] txBuffer)
    {
        int result = txBuffer.length;
        
        if(sServiceConnected)
        {
            try {
                result = sAntReceiver.ANTSendBurstTransfer(channelNumber, txBuffer);
            } catch (Exception ex) {
                antServiceConnectionLost();
            }
        }
        return result;
    }
    
    public int ANTSendPartialBurst(byte channelNumber, byte[] txBuffer, int initialPacket, boolean containsEndOfBurst)
    {
        int result = txBuffer.length;
        
        if(sServiceConnected)
        {
            try {
                result = sAntReceiver.ANTTransmitBurst(channelNumber, txBuffer, initialPacket, containsEndOfBurst);
            } catch (Exception ex) {
                antServiceConnectionLost();
            }
        }
        return result;
    }
    
}
