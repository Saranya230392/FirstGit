package com.ant.antplus;

import com.ant.antplus.R;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PairingDialog extends Dialog
{
   public static final int HRM_ID = 0;
   public static final int SDM_ID = 1;
   public static final int PROX_ID = 2;
   public static final int WGT_ID = 3;
   public static final int CAD_ID = 4;
   
   public interface PairingListener
   {
      public void updateID(int id, short deviceNumber);
      public void updateThreshold(int id, byte proxThreshold);
   }

   
   public int getId()
   {
      return mId;
   }

   public void setId(int id)
   {
      this.mId = id;
   }

   public short getDeviceNumber()
   {
      return mDeviceNumber;
   }

   public void setDeviceNumber(short deviceNumber)
   {
      this.mDeviceNumber = deviceNumber;
   }
   
   public byte getProximityThreshold()
   {
      return mProximityThreshold;
   }
   
   public void setProximityThreshold(byte proximityThreshold)
   {
      this.mProximityThreshold = proximityThreshold;
   }

   private int mId;
   private short mDeviceNumber;
   private byte mProximityThreshold;
   private PairingListener mPairingListener;
     
   
   public PairingDialog(Context context, int id, short deviceNumber, PairingListener pairingListener)
   {
      super(context);
      mId = id;
      mDeviceNumber = deviceNumber;
      mPairingListener = pairingListener;
   }
   
   public PairingDialog(Context context, int id, byte proximityThreshold, PairingListener pairingListener)
   {
      super(context);
      mId = id;
      mProximityThreshold = proximityThreshold;
      mPairingListener = pairingListener;
   }
   
   @Override
   public void onCreate(Bundle savedInstanceState)
   {
      super.onCreate(savedInstanceState);
      
      if(mId >= HRM_ID && mId <= CAD_ID)
      {
         setContentView(R.layout.pairing_dialog);
         
         if(mId == HRM_ID)
            setTitle(getContext().getResources().getString(R.string.Dialog_Pair_HRM));
         else if(mId == SDM_ID)
            setTitle(getContext().getResources().getString(R.string.Dialog_Pair_SDM));
         else if(mId == WGT_ID)
            setTitle(getContext().getResources().getString(R.string.Dialog_Pair_WGT));
         // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]		 
         else if(mId == CAD_ID)
            setTitle(getContext().getResources().getString(R.string.Dialog_Pair_CAD));		 
         else if(mId == PROX_ID)
            setTitle(getContext().getResources().getString(R.string.Dialog_Proximity));
         
         TextView descr = (TextView) findViewById(R.id.dialog_text);
         EditText input = (EditText) findViewById(R.id.dialog_input);
         if(mId == PROX_ID)
         {
            descr.setText(getContext().getResources().getString(R.string.Dialog_Prox_Text));
            input.setText("" + (int) (mProximityThreshold & 0xFF));
            input.setHint("0 - 10");
         }
         else
         {
            descr.setText(getContext().getResources().getString(R.string.Dialog_Pair));
            input.setText("" + (int) mDeviceNumber);
            input.setHint("0 - 65535");
         }
         
         
         Button buttonOK = (Button) findViewById(R.id.dialog_button);
         buttonOK.setOnClickListener(new OKListener());
      }      
   }
    
   @Override 
   protected void onStart()
   {
      super.onStart();
      EditText input = (EditText) findViewById(R.id.dialog_input);
      if(mId == PROX_ID)
      {
         input.setText("" + (int) (mProximityThreshold & 0xFF));
      }
      else
      {
         input.setText("" + (int) (mDeviceNumber & 0xFFFF));
      }
      input.selectAll();
   }
   
   private class OKListener implements android.view.View.OnClickListener
   {  
      public void onClick(View v)
      {
         EditText input = (EditText) findViewById(R.id.dialog_input);
         Integer tempInt = Integer.parseInt(input.getText().toString());         
         if(tempInt != null && (mId == SDM_ID | mId == HRM_ID | mId == WGT_ID | mId == CAD_ID) && tempInt < 65536)
         {
            int temp = tempInt.intValue();
            mDeviceNumber = (short) (temp & 0xFFFF);
            mPairingListener.updateID(mId, mDeviceNumber);  // Let main activity know about update
            PairingDialog.this.dismiss();
         }
         else if(tempInt != null && mId == PROX_ID && tempInt <= 10)
         {
            int temp = tempInt.intValue();
            mProximityThreshold = (byte) (temp & 0xFFFF);
            mPairingListener.updateThreshold(mId, mProximityThreshold);
            PairingDialog.this.dismiss();
         }
         else
         {
            input.setText("0");            
         }
      }
   }
   
}
