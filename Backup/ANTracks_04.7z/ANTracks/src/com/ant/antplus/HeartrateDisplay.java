package com.ant.antplus;

import com.ant.antplus.R;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import android.widget.TextView;

public class HeartrateDisplay extends Activity {
    public String TAG = "HeartrateDispaly";
    public boolean check = false;
    //public String []text = new String[10];
    //text[0] = "Heart Rate";
    //text[1] = "n/a";
    public void onCreate(Bundle savedInstanceState) 
    {
        
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.heart_display);
        initcontrols();
        final Button button = (Button) findViewById(R.id.Button01);
        final EditText edittext = (EditText)findViewById(R.id.EditText01);
        button.setOnClickListener(new View.OnClickListener() {
            
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Log.d(TAG, "onclick");
                
                if(check ==false)
                {
                    //Log.d(TAG, "false");
                    button.setText("Connect");
                    edittext.setText("     100");
                    edittext.setTextSize((float)60.0);
                    check = true;
                }
                else if(check ==true){
                   // Log.d(TAG, "true");
                    button.setText("DisConnect");
                    edittext.setText("     N/A");
                    edittext.setTextSize((float)60.0);
                    check = false;
                    
                }
            }
        });
    }
    public void initcontrols(){
        ImageView iv = (ImageView)findViewById(R.id.ImageView01);  

        Bitmap image = BitmapFactory.decodeResource(getResources(), R.drawable.signal);  
        Bitmap resized = Bitmap.createScaledBitmap(image, 70, 70, true);  
        iv.setImageBitmap(resized);  


//        Drawable d = getResources().getDrawable(R.drawable.signal);        //�׸� �����´�.
//        ImageView image = new ImageView(this);



//
    
    }
}
