package com.ant.antplus;

public class ITrackRecordingService {

    public boolean isRecording() {
        // TODO Auto-generated method stub
        return false;
    }

}
