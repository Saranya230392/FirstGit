package com.ant.antplus;

import com.ant.antplus.R;

import android.app.Activity;
import android.os.Bundle;

public class StrideDisplay extends Activity {
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.heart_display);
    }
}
