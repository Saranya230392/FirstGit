package com.ant.antplus;

public class AdaptiveLocationListenerPolicy {

    public AdaptiveLocationListenerPolicy(int i, int j, int k) {
        // TODO Auto-generated constructor stub
    }


}
