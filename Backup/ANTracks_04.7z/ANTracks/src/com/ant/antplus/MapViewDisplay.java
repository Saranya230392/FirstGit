
package com.ant.antplus;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.ContentObserver;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;

public class MapViewDisplay extends MapActivity
    implements View.OnTouchListener, View.OnClickListener,
    SharedPreferences.OnSharedPreferenceChangeListener  {
    
	public String TAG = "MapViewDisplay";

    ListView list;    
    Intent intent;

    private MenuManager menuManager;
    private static final int TRACKPOINT_BUFFER_SIZE = 1024;    

    private long selectedTrackId = -1;
    private long recordingTrackId = -1;
    private boolean keepMyLocationVisible;
    private long firstSeenLocationId = -1;
    private long lastSeenLocationId = -1;
    private double variation;
    private int minRequiredAccuracy =
        ANTracksSettings.DEFAULT_MIN_REQUIRED_ACCURACY;
    private boolean haveGoodFix;
    private Location currentLocation;
    private HandlerThread updateTrackThread;
    private Handler updateTrackHandler;
//    private ANTracksProviderUtils providerUtils;
    private SharedPreferences sharedPreferences;
    
	private RelativeLayout screen;
	private MapView mapView;
	private ANTracksOverlay mapOverlay;
	private LinearLayout messagePane;
	private TextView messageText;
	private LinearLayout busyPane;
	private ImageButton optionsBtn;
	
	private MenuItem myLocation;
	private MenuItem toggleLayers;
	
	private SensorManager sensorManager;
	private LocationManager locationManager;
	private ContentObserver observer;
	private ContentObserver waypointObserver;
	
	/** Handler for callbacks to the UI thread */
	private final Handler uiHandler = new Handler();

    
    @Override
    public void onCreate(Bundle bundle) 
    {
        Log.d(ANTracksConstants.TAG, "ANTracksMap.onCreate");        
        super.onCreate(bundle);
        
        // The volume we want to control is the Text-To-Speech volume
        int volumeStream =
            new StatusAnnouncerFactory(ApiFeatures.getInstance()).getVolumeStream();
        setVolumeControlStream(volumeStream);

//        providerUtils = MyTracksProviderUtils.Factory.get(this);
        // We don't need a window title bar:
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        // Inflate the layout:
        setContentView(R.layout.mapview_display);

        // Remove the window's background because the MapView will obscure it
        getWindow().setBackgroundDrawable(null);
        
        // Set up a map overlay:
        screen = (RelativeLayout) findViewById(R.id.screen);
        mapView = (MapView) findViewById(R.id.map);
        mapView.requestFocus();
        mapOverlay = new ANTracksOverlay(this);
        mapView.getOverlays().add(mapOverlay);
        mapView.setOnTouchListener(this);
        messagePane = (LinearLayout) findViewById(R.id.messagepane);
        messageText = (TextView) findViewById(R.id.messagetext);
        busyPane = (LinearLayout) findViewById(R.id.busypane);
        optionsBtn = (ImageButton) findViewById(R.id.showOptions);
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
      super.onCreateOptionsMenu(menu);
      return menuManager.onCreateOptionsMenu(menu);
//        menu.add(0,1,0,"1");
//        menu.add(0,2,0,"2");
//        menu.add(0,3,0,"3");
//        return true;
    }

    public void forceError()
    {
       if(true)
       {
         throw new Error("Woops");
       }
    }
    
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
//      menuManager.onPrepareOptionsMenu(menu, providerUtils.getLastTrack() != null,
//          isRecording(), selectedTrackId >= 0);
      return super.onPrepareOptionsMenu(menu);
    }

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//      return menuManager.onOptionsItemSelected(item)
//          ? true
//          : super.onOptionsItemSelected(item);
//    }

    public void myClickHandler(View target){
        switch(target.getId()){
            case R.id.zoomin:
                 mapView.getController().zoomIn();
                 break;
            case R.id.zoomout:
                 mapView.getController().zoomOut();
                 break;
            case R.id.sat:
                 mapView.setStreetView(true);
                 break;
            case R.id.street:
                Log.d(TAG, "switch:street");
                intent = new Intent(this, ListFromArray.class);                                                         
                startActivity(intent);
                break;
            case R.id.traffic:
        }
    }
    @Override
    protected boolean isLocationDisplayed(){
        return false;
    }
    @Override
    protected boolean isRouteDisplayed() {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public boolean onTouch(View arg0, MotionEvent arg1) {
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        // TODO Auto-generated method stub
        
    }     
}
