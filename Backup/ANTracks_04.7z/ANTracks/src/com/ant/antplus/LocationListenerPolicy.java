package com.ant.antplus;

public class LocationListenerPolicy {

}
