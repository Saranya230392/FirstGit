package com.ant.antplus;

public class AbsoluteLocationListenerPolicy extends LocationListenerPolicy {

    public AbsoluteLocationListenerPolicy(int i) {
        // TODO Auto-generated constructor stub
    }
}
