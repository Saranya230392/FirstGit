/*****************************************************************************
**
**  Name:           adi_lge_btui.h
**
**  Description:    This interface file contains definitions used for compilation with the 
**                  phone platform.
**
**  Copyright (c) 2003-2004, WIDCOMM Inc., All Rights Reserved.
**  WIDCOMM Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/
#ifndef ADI_LGE_BTUI_H
#define ADI_LGE_BTUI_H

#define DM_USE_NEW_STRUCTURE
#define DM_USE_NEW_KEYPAD_MODULE
#endif
