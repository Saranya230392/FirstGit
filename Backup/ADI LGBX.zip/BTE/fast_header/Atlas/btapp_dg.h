/*
   MODULE  : BTAPP_DG

   PURPOSE : This module contains the BTAPP Data Gateway APIs
*/
#ifndef BTAPP_DG_H
#define BTAPP_DG_H

/*******************************************************************************
**
** Function         btapp_dg_enable
**
** Description      Enables Data Gateway
**
**
** Returns          void
*******************************************************************************/
void btapp_dg_enable(void);

/*******************************************************************************
**
** Function         btapp_dg_disable
**
** Description      Disable Data Gateway
**
**
** Returns          void
*******************************************************************************/
void btapp_dg_disable(void);

/*******************************************************************************
**
** Function         btapp_dg_listen
**
** Description      enable servers DUN, SPP, FAX
**
**
** Returns          void
*******************************************************************************/
void btapp_dg_listen(UINT8 appId);

/*******************************************************************************
**
** Function         btapp_dg_shut_down
**
** Description      disables servers DUN, SPP, FAX
**
**
** Returns          void
*******************************************************************************/
void btapp_dg_shut_down(UINT8 appId);

/*******************************************************************************
 **
 ** Function         btapp_dg_client_connect
 **
 ** Description      Connects to the selected device
 **
 **
 ** Returns          void
 *******************************************************************************/
void btapp_dg_client_connect(BD_ADDR bd_addr);

/*******************************************************************************
 **
 ** Function         btapp_dg_disconnect_device
 **
 ** Description      Connects to the selected device
 **
 **
 ** Returns          void
 *******************************************************************************/
void btapp_dg_disconnect_device(void);
/*******************************************************************************
 **
 ** Function         btapp_dg_is_service
 **
 ** Description      TRUE if the service defined by the appId is enabled
 **
 ** Returns          void
 *******************************************************************************/
BOOLEAN btapp_dg_is_service(UINT8 appId);

/*******************************************************************************
 **
 ** Function         btapp_dg_is_spp_server_connected
 **
 ** Description      TRUE is SPP service is enabled and a peer connects to us
 **
 ** Returns          void
 *******************************************************************************/
BOOLEAN btapp_dg_is_spp_server_connected(void);


#endif  /* BTAPP_DG_H */
