/*
   MODULE  : BTAPP_AG

   PURPOSE : This module contains the BTAPP Audio Gateway APIs
*/
#ifndef BTAPP_AG_H
#define BTAPP_AG_H



#define BTAPP_AG_IND_CALL    0
#define BTAPP_AG_IND_SETUP   2
#define BTAPP_AG_IND_LEN     4
/* define how many HS/HF connections can be supported in the meantime ( typically 1 or 2 ) */
#define BTAPP_AG_NUM_APP     2

typedef struct
{
    tBTA_SERVICE_ID service;
    UINT16          handle;
    BOOLEAN         is_open;
    UINT8           spk_vol;
    UINT8           mic_vol;
} tBTAPP_AG_APP;

typedef struct
{
    tBTAPP_AG_APP   app[BTAPP_AG_NUM_APP];
    char            ind[BTAPP_AG_IND_LEN];
    UINT8           call_state;
    UINT16          call_handle;
    UINT16          app_id;
    BOOLEAN         inband_ring;
    UINT8           spk_vol;
    UINT8           mic_vol;
   tBTA_AG_PARSE_MODE  parse_mode;
} tBTAPP_AG_CB;


/*******************************************************************************
**
** Function         btapp_ag_is_enabled
**
** Description      Check if the AG profile is enabled or not.
**
** Returns          TRUE is AG profile is enabled, FALSE otherwise
**
*******************************************************************************/
BOOLEAN btapp_ag_is_enabled(void);

/*******************************************************************************
 **
 ** Function         btapp_ag_enable
 **
 ** Description      Enables Audio Gateway
 **
 **
 ** Returns          void
 *******************************************************************************/
void btapp_ag_enable(tBTA_AG_PARSE_MODE parse_mode);


/*******************************************************************************
 **
 ** Function         btapp_ag_disable
 **
 ** Description      Initialises BTUI AG and BTA AG
 **
 **
 ** Returns          void
 *******************************************************************************/
void btapp_ag_disable(void);

/*******************************************************************************
**
** Function         btapp_ag_open_audio
**
** Description      Action function to open a SCO link
**
** Returns          void
*******************************************************************************/
void btapp_ag_open_audio(void);

/*******************************************************************************
**
** Function         btapp_ag_disconnect_audio
**
** Description      Action function to close a SCO link
**
** Returns          void
*******************************************************************************/
void btapp_ag_disconnect_audio(void);

/*******************************************************************************
**
** Function         btapp_ag_connect_device
**
** Description      Connects to the selected headset
**
** Returns          void
*******************************************************************************/
void btapp_ag_connect_device(BD_ADDR audio_device);

/*******************************************************************************
**
** Function         btapp_ag_disconnect
**
** Description      Action function to disconnect active connection to AG
**
** Returns          void
*******************************************************************************/
void btapp_ag_disconnect(void);

/*******************************************************************************
**
** Function         btapp_ag_decrease_mic_vol
**
** Description      Action function to decrease mic volume
**
** Returns          void
*******************************************************************************/
void btapp_ag_decrease_mic_vol(void);

/*******************************************************************************
**
** Function         btapp_ag_increase_mic_vol
**
** Description      Action function to increase mic volume
**
** Returns          void
*******************************************************************************/
void btapp_ag_increase_mic_vol(void);

/*******************************************************************************
**
** Function         btapp_ag_increase_spk_vol
**
** Description      Action function to increase speaker volume
**
** Returns          void
*******************************************************************************/
void btapp_ag_increase_spk_vol(void);

/*******************************************************************************
**
** Function         btapp_ag_decrease_spk_vol
**
** Description      Action function to decrease speaker volume
**
** Returns          void
*******************************************************************************/
void btapp_ag_decrease_spk_vol(void);

/*******************************************************************************
**
** Function         btapp_ag_phone_call
**
** Description      Initiate phone call
**
** Returns          void
*******************************************************************************/
void btapp_ag_phone_call(UINT8* p_number );

/*******************************************************************************
**
** Function         btapp_ag_end_calls
**
** Description      Hang up ongoing calls
**
** Returns          void
*******************************************************************************/
void btapp_ag_end_calls(void);
/*******************************************************************************
**
** Function         btapp_ag_simulate_incoming_call
**
** Description      alert for an incoming call phone call
**
**
** Returns          void
*******************************************************************************/
void btapp_ag_simulate_incoming_call(void);

/*******************************************************************************
**
** Function         btapp_ag_simulate_active_call
**
** Description      alert for a call answeared
**
**
** Returns          void
*******************************************************************************/
void btapp_ag_simulate_active_call(void);

#endif  /* BTAPP_AG_H */
