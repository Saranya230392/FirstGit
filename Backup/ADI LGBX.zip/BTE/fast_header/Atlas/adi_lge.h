/*****************************************************************************
**
**  Name:           adi_lge.h
**
**  Description:    This interface file contains definitions used for compilation with the 
**                  phone platform.
**
**  Copyright (c) 2003-2004, WIDCOMM Inc., All Rights Reserved.
**  WIDCOMM Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/
#ifndef ADI_LGE_H
#define ADI_LGE_H

#include "target.h"
#ifndef DM_USE_NEW_STRUCTURE
#define DM_USE_NEW_STRUCTURE
#endif

#ifndef DM_USE_NEW_KEYPAD_MODULE
#define DM_USE_NEW_KEYPAD_MODULE
#endif

#ifndef LGE_L1_BLUETOOTH
#define LGE_L1_BLUETOOTH
#endif

#ifndef UPGRADE_FSYSTEM
 #define UPGRADE_FSYSTEM
#endif

#if defined(PLATFORM_LEMANS_BT) && (PLATFORM_LEMANS_BT ==TRUE)
#ifndef LGE_LEMANS_BLUETOOTH
#define LGE_LEMANS_BLUETOOTH
#endif
#endif /* PLATFORM_LEMANS_BT */


#include "fs_io.h"
#include "fstdio.h"

#include "bta_codec.h"


extern void btapp_aa_timer_event(void );
extern void btui_av_start_from_mm_chip(void);

#if defined(PLATFORM_LEMANS_BT) && (PLATFORM_LEMANS_BT ==TRUE)
extern void userial_timer_start( void );
extern void userial_timer_stop(void);
#endif

void btui_main_poweroff_bt(void);

#endif
