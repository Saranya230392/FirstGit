/*****************************************************************************
**
**  Name:           btapp_flash.h
**
**  Description:  This module contains utility functions for dealing with the flash file system.
**
**
**  Copyright (c) 2004-2005, Widcomm Inc., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/

#ifndef DEF_BTUI_FLASH_HEADER
#define DEF_BTUI_FLASH_HEADER

#include "bta_api.h"
#include "bta_fs_co.h"

#include "adi_lge.h"

#ifndef FLASH_AVAILABLE
#define FLASH_AVAILABLE FALSE
#endif

#ifndef FLASH_DEBUG
#define FLASH_DEBUG FALSE
#endif

typedef struct
{
    char         *p_name;              /* file name. */
    UINT32     data_size;   /* file length */
    BOOLEAN  is_dir;
    UINT32      flags;
} tBTAPP_FILE_PROP;


void btapp_flash_init_fs(char * config_dir );
/*******************************************************************************
**
** Function        btapp_flash_set_root_path
**
** Description     This function set the root path
**
** Returns
**
*******************************************************************************/
void btapp_flash_set_root_path(char * root_dir );

/*file handling */
BOOLEAN btapp_flash_open(char* p_path, INT32 oflags, INT32 * fd);
 void btapp_flash_close( UINT32 fd );
 UINT32 btapp_flash_read(UINT32 fd, void * p_buf, UINT32 size, BOOLEAN *is_eof );
 UINT32 btapp_flash_write(UINT32 fd, void * p_buf, UINT32 size );
tBTA_FS_CO_STATUS btapp_flash_delete(char* file_name );
void btapp_flash_seek(UINT32 fd, INT32 offset, INT16 origin);
UINT32 btapp_flash_file_size( UINT32 fd, char* file_name);
BOOLEAN btapp_flash_file_properties( const char* file_name, tBTAPP_FILE_PROP *properties  );

BOOLEAN btapp_flash_isfileexists(char *name);

/*directory handling */
BOOLEAN btapp_flash_opendir( const char* p_path, UINT32 *param);
void btapp_flash_closedir(UINT32 param );
#if (defined(PLATFORM_LEMANS_BT) && PLATFORM_LEMANS_BT == TRUE)
char* btapp_flash_readdir( UINT32 dir_handle );
#elif (defined(PLATFORM_GB8_BT) && PLATFORM_GB8_BT == TRUE) || \
      (defined (PLATFORM_GB5_BT) && (PLATFORM_GB5_BT == TRUE))
BOOLEAN btapp_flash_readdir (UINT32 dir_handle, char *ptName);
#endif
tBTA_FS_CO_STATUS btapp_flash_mkdir( char* p_path);
tBTA_FS_CO_STATUS btapp_flash_rmdir( char* p_path);
void btapp_flash_change_dir(char * dir );
char* btapp_flash_pwdir(void);
BOOLEAN btapp_flash_isdir(char * path);
#if (defined(PLATFORM_LEMANS_BT) && PLATFORM_LEMANS_BT == TRUE)
void btapp_flash_get_parentdir(char * p_path , char * pdir, char * name);
BOOLEAN btapp_flash_check_if_drive(char *dir);
#elif (defined(PLATFORM_GB8_BT) && PLATFORM_GB8_BT == TRUE)|| \
      (defined (PLATFORM_GB5_BT) && (PLATFORM_GB5_BT == TRUE))
BOOLEAN btapp_flashdelfile(const char *path);
#endif


#endif
