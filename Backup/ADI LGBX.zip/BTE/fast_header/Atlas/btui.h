/******************************************************************************
 **                                                                           *
 **  Name:          btui.h                                                    *
 **                                                                           *
 **  Description:    This is the interface file for the btui                  *
 **	                                                                      *
 **                                                                           *
 **  Copyright (c) 2003, WIDCOMM Inc., All Rights Reserved.                   *
 **  WIDCOMM Bluetooth Core. Proprietary and confidential.                    *
 ******************************************************************************/
#ifndef __BTUI_H__
#define  __BTUI_H__

#include "bta_av_api.h"
#include "bta_ag_api.h"
#include "bta_op_api.h"
#include "bta_dg_api.h"
#include "bta_ft_api.h"
#include "bta_pr_api.h"
#include "bta_pbs_api.h"

#if( defined BTA_FM_INCLUDED ) && (BTA_FM_INCLUDED == TRUE)
#include "bta_fm_api.h"
#endif
 

/* LCD definition */
#define BTUI_LCD_LINE_LEN 70
#define BTUI_LCD_NUM_OF_LINE 50

/* userial port Id for btui mmi */
#define BTUI_SERIAL_PORT_ID USERIAL_PORT_2

/* assigned  in btui_main*/
extern UINT8 btui_task_id;

/* event masks for events to the task */
#define BTUI_MMI_EVT_MASK          0x0100  /* events from mmi to the BTUI application */
#define BTUI_PHONE_EVT_MASK        0x0200  /* events from Phone to the BTUI application */
#define BTUI_BTA_EVT_MASK          0x0400  /* events from BTA translated by BTUI and forwarded to itself */


/* UI IDs used by the menu manager and the BTUI event handler */
#define UI_DM_ID       1
#define UI_DG_ID       2
#define UI_AG_ID       3
#define UI_FTS_ID     4 
#define UI_OPC_ID     5
#define UI_OPS_ID     6
#define UI_CT_ID       7
#define UI_SYNC_ID   8
#define UI_FTC_ID     9
#define UI_PAN_ID     0x0A
#define UI_PR_ID       0x0B
#define UI_AA_ID       0x0C
#define UI_CG_ID       0x0D
#define UI_FLASH_ID 0x0E
#define UI_TEST_ID   0x0F
#define UI_PBS_ID     0x10
#define UI_SC_ID       0x11
#define UI_FM_ID       0x12

/* value of the inputs in the mmi */
#define MENU_ITEM_0 '0'
#define MENU_ITEM_1 '1'
#define MENU_ITEM_2 '2'
#define MENU_ITEM_3 '3'
#define MENU_ITEM_4 '4'
#define MENU_ITEM_5 '5'
#define MENU_ITEM_6 '6'
#define MENU_ITEM_7 '7'
#define MENU_ITEM_8 '8'
#define MENU_ITEM_9 '9'
#define MENU_ITEM_10 '10'


/********************************************************
Macro for getting the root state for a ID
********************************************************/

#define UI_STATE_START(id)       ((id) << 8)


/********************************************************
BTUI Remote Device Structure
********************************************************/
#define BTUI_NUM_REM_DEVICE_FLASH 10
#define BTUI_NUM_REM_DEVICE_RAM 20
#define BTUI_NUM_REM_DEVICE (BTUI_NUM_REM_DEVICE_FLASH + BTUI_NUM_REM_DEVICE_RAM)
#define BTUI_DATA_LEN          56
#define BTUI_NAME_LEN 32  /*equal to BTA_DM_REMOTE_DEVICE_NAME_LENGTH */
#define BTUI_MAX_FILES 15
/* remote device */
typedef struct
{
    /* important!The first parameters should be the same as tBTUI_REM_DEVICE_INFO */
    BOOLEAN             in_use;
    BD_ADDR             bd_addr;
    char                name[BTUI_NAME_LEN+1];
    DEV_CLASS           dev_class;
    tBTA_SERVICE_MASK   services;
    tBTA_SERVICE_MASK   trusted_services;
    BOOLEAN             is_default_hs;
    BOOLEAN             stored;
    BOOLEAN             link_key_present;
    LINK_KEY            link_key;
}
tBTUI_REM_DEVICE;



/********************************************************
BTUI Control Block
********************************************************/
typedef void (tBTUI_MENU)( void );
typedef UINT32 tBTUI_STATE;

typedef struct
{
    tBTUI_STATE       ui_state;
    tBTUI_STATE       ui_next_state;
    tBTUI_STATE       ui_prev_state;
    tBTA_SERVICE_MASK searched_services;
    tBTUI_REM_DEVICE *p_selected_rem_device;
    tBTUI_REM_DEVICE *p_device_viewed[BTUI_NUM_REM_DEVICE];
    tBTUI_REM_DEVICE *p_device_db[BTUI_NUM_REM_DEVICE];
    UINT8             num_devices;
    BOOLEAN           is_inq_going_on;
    BOOLEAN           get_string;
    BOOLEAN           is_sco_link_on;
    BOOLEAN           update_flash;
    BOOLEAN           is_spp_loopback;
    tBTUI_MENU  *     pin_cback_menu;
    tBTUI_MENU  *     cback_next_menu;
    tBTUI_MENU  *     cback_previous_menu;
    UINT8             object_path[BTA_FS_PATH_LEN];
    UINT8             trace_to_change;
    tBTA_SEC          sec_mask;
    char              msg_str[BTUI_LCD_LINE_LEN];
}
tBTUI_CB;

extern tBTUI_CB btui_cb;

/********************************************************
All the types for tBTUI_BTA_EVT union
********************************************************/

/* data type for connection up event */
typedef struct
{
    BT_HDR    hdr;
    BD_ADDR   bd_addr;
    tBTA_STATUS status;
    tBTA_SERVICE_ID service;

} tBTUI_CONN_UP_MSG;

/* data type for connection down event */
typedef struct
{
    BT_HDR    hdr;
    BD_ADDR   bd_addr;
    tBTA_STATUS status;
    tBTA_SERVICE_ID service;

} tBTUI_CONN_DOWN_MSG;

/* data type for pin request message */
typedef struct
{
    BT_HDR    hdr;
    BD_ADDR   bd_addr;
    char     dev_name[BTUI_NAME_LEN+1];
} tBTUI_PIN_REQ_MSG;

typedef struct
{
    BT_HDR          hdr;
    BD_ADDR         bd_addr;
    char           dev_name[BTUI_NAME_LEN+1];
    tBTA_SERVICE_ID service;
} tBTUI_AUTH_REQ_MSG;

typedef struct
{
       BT_HDR     hdr;
       BD_ADDR    bd_addr;
       char      dev_name[BTUI_NAME_LEN+1];
       LINK_KEY   link_key;
       BOOLEAN    link_key_present;
       BOOLEAN    is_success;
}
tBTUI_DM_AUTH_CMPL;

/* union of all message type */
typedef struct
{
    BT_HDR            hdr;
    BD_ADDR           bd_addr;
    char            dev_name[BTUI_NAME_LEN+1];
    tBTA_SERVICE_MASK service;
} tBTUI_DISC_MSG;

typedef struct
{
    BT_HDR       hdr;
    BD_ADDR      bd_addr;
    DEV_CLASS    dev_class;
} tBTUI_INQ_MSG;

typedef struct
{
    BT_HDR      hdr;
    UINT16      data;
    /* length should be AG_AT_STR_MAX_LENGTH. Don't know where it is defined! */
    char        str[50];
} tBTUI_BTA_AG_AT_MSG;

/* data type for MMI message */
typedef struct
{
    BT_HDR    hdr;
    UINT8       app_id;
} tBTUI_DATA_MSG;


/* UI message for OP */
typedef struct
{
    BT_HDR  hdr;
    UINT8   status;
    UINT16  bytes;
    UINT32  obj_size;
    char    obj_name[BTA_FS_PATH_LEN];
    tBTA_OP_OPER   oper;
} tBTUI_BTA_OP_MSG;

/* UI message for AA */
typedef struct
{
    BT_HDR  hdr;
    tBTA_AV_RC rc_id;
    tBTA_AV_STATE key_state;
} tBTUI_BTA_AA_MSG;

#if( defined BTA_FM_INCLUDED ) && (BTA_FM_INCLUDED == TRUE)
/* UI message for FM */
typedef struct
{
    BT_HDR  hdr;
    tBTA_FM_STATUS status;
    UINT16 freq;
    tBTA_FM_AUDIO_MODE audio_mode;
    UINT8 rssi;
} tBTUI_BTA_FM_MSG;
#endif


/* union of all message type */
typedef union
{
    BT_HDR                     hdr;
    tBTUI_CONN_UP_MSG          open;
    tBTUI_CONN_DOWN_MSG        close;
    tBTUI_PIN_REQ_MSG          pin_req;
    tBTUI_AUTH_REQ_MSG         auth_req;
    tBTUI_INQ_MSG              inq_res;
    tBTUI_DISC_MSG             disc_res;
    tBTUI_DM_AUTH_CMPL         auth_cmpl;
    tBTUI_BTA_AG_AT_MSG        ag_msg;
    tBTUI_DATA_MSG             data_msg;
    tBTUI_BTA_AA_MSG    rcmd;
    tBTUI_BTA_OP_MSG   op;
#if( defined BTA_FM_INCLUDED ) && (BTA_FM_INCLUDED == TRUE)
    tBTUI_BTA_FM_MSG fm_msg;
#endif
} tBTUI_BTA_MSG;

/* data type for MMI message */
typedef struct
{
    BT_HDR    hdr;
    UINT8     data[BTUI_DATA_LEN+1];
} tBTUI_MMI_MSG;



/********************************************************
BTUI Functions
********************************************************/

/* MMI functions */
void btui_mmi_init(void);
void BTUI_SetInputMode( BOOLEAN bOn );
void BTUI_getc(char key_nb);
void BTUI_putc(UINT8 ch);
void BTUI_puts(const char *str);
void BTUI_cls(void);

/* Root menu */
void btui_menu_idle( void );
void btui_main_start_bt( void );
void btui_main_continue_start( void );
void btui_main_stop_bt(void);

/*BTUI device manager */
void btui_dm_display_devices(tBTA_SERVICE_MASK services);
void btui_dm_display_name_selected_device(tBTUI_REM_DEVICE * p_rem_device);
void btui_dm_menu_bond(void);
void btui_dm_trust_device(tBTUI_REM_DEVICE * p_rem_device,tBTA_SERVICE_MASK services, BOOLEAN add_service);
BOOLEAN btui_dm_is_trusted(tBTUI_REM_DEVICE * p_rem_device, tBTA_SERVICE_MASK   services);
void btui_dm_menu_security(void);

/*BTUI flash : handling storage of BT config and devices database */
BOOLEAN btui_flash_init( void );
BOOLEAN btui_flash_store_db(void);
BOOLEAN btui_flash_is_bt_started( void );
BOOLEAN btui_flash_is_visible( void );
char * btui_flash_get_local_name(void);
char * btui_flash_get_root_path(void);
char * btui_flash_get_default_vcard_path(void);
void btui_flash_get_bd_addr(UINT8 * bd_addr);
BOOLEAN btui_flash_store_bd_addr( BD_ADDR bd_addr );

BOOLEAN btui_flash_store_status( BOOLEAN new_enable_status );
BOOLEAN btui_flash_store_visibility( BOOLEAN new_visibility );
BOOLEAN btui_flash_store_local_name( char* new_name );
BOOLEAN btui_flash_store_root_path( char* new_path );

BOOLEAN btui_flash_store_device( tBTUI_REM_DEVICE * p_rem_device);
BOOLEAN btui_flash_delete_device(tBTUI_REM_DEVICE * p_rem_device);
BOOLEAN btui_flash_is_device_new(tBTUI_REM_DEVICE * p_rem_device);
void btui_flash_set_default_audio_device(tBTUI_REM_DEVICE * p_rem_device);
void btui_flash_browse_folder(char * path);


/* BTUI event handlers */
void btui_main_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_dm_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_dg_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_aa_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_ag_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_opc_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_ct_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_pan_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_ftc_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_fts_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_pr_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_pbs_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);
void btui_sc_bta_evt_hdlr(tBTUI_BTA_MSG *p_msg);

/* BTUI input handlers */
void btui_main_input_evt_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_dm_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_flash_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_ag_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_dg_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_opc_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_aa_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_ct_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_pan_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_ft_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_pr_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_pbs_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_sc_input_hdlr(tBTUI_MMI_MSG *p_msg);
void btui_test_input_hdlr(tBTUI_MMI_MSG *p_msg);

/* BTUI main menus */
void btui_ag_menu_main(void);
void btui_dg_menu_main(void);
void btui_ft_menu_main(void);
void btui_opc_menu_main(void);
void btui_ct_menu_main(void);
void btui_cg_menu_main(void);
void btui_pan_menu_main(void);
void btui_pr_menu_main(void);
#if( defined BTA_FM_INCLUDED ) && (BTA_FM_INCLUDED == TRUE)
void btui_fm_menu_main(void);
#endif
void btui_pbs_menu_main(void);
void btui_dm_menu_setting(void);
void btui_dm_menu_devices(void);
void btui_aa_menu_main(void);
void btui_sc_menu_main(void);
void btui_test_menu_main(void);

/* MMI Event notification functions */
void btui_send_evt_to_ui (UINT8 event, UINT16 ui_id);
void btui_ag_mmi_notify(tBTA_AG_EVT event, tBTA_AG *p_data);
void btui_ag_platform_mmi_notify(tBTA_AG_EVT event, tBTA_AG *p_data);
void btui_dm_security_mmi_notify(tBTA_DM_SEC_EVT event, tBTA_DM_SEC *data);
void btui_dm_search_mmi_notify(tBTA_DM_SEARCH_EVT event, tBTA_DM_SEARCH *data);
void btui_opc_mmi_notify(tBTA_OPC_EVT event, tBTA_OPC *p_data);
void btui_ops_mmi_notify(tBTA_OPS_EVT event, tBTA_OPS *p_data);
void btui_dg_mmi_notify(tBTA_DG_EVT event, tBTA_DG *p_data);
void btui_ftc_mmi_notify(tBTA_FTC_EVT event, tBTA_FTC *p_data);
void btui_fts_mmi_notify(tBTA_FTS_EVT event, tBTA_FTS *p_data);
void btui_pr_mmi_notify(tBTA_PR_EVT event, tBTA_PR *p_data);
void btui_send_evt_to_ui (UINT8 event, UINT16 ui_id);


#endif
