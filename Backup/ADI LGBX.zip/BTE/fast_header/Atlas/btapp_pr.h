/*****************************************************************************
**
**  Name:           btapp_pr.h
**
**  Description:    Contains application functions Bluetooth Printer client Profile
**
**
**  Copyright (c) 2005, Widcomm Inc., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/
#ifndef BTAPP_PR_H
#define BTAPP_PR_H

#include "bd.h"
#include "bta_api.h"
enum
{
     BTUI_IMG_ERR_NONE,    /* OK */
     BTUI_IMG_ERR_EOF,     /* EOF */
     BTUI_IMG_ERR_BAD      /* bad format */
};

/*****************************************************************************
**  Prototype
*****************************************************************************/

/*******************************************************************************
 **
 ** Function         btapp_pr_is_enabled
 **
 ** Description      Used by UI to know if PR profile is enabled or not
 **
 **
 ** Returns          void
 *******************************************************************************/
BOOLEAN btapp_pr_is_enabled( void );

/*******************************************************************************
 **
 ** Function         btapp_pr_enable
 **
 ** Description      Initialises BTA PR module
 **
 **
 ** Returns          void
 *******************************************************************************/
void btapp_pr_enable(void);

/*******************************************************************************
 **
 ** Function         btapp_pr_disable
 **
 ** Description      Disable PR profile
 **
 **
 ** Returns          void
 *******************************************************************************/
void btapp_pr_disable(void);

/*******************************************************************************
**
** Function         btapp_pr_abort
**
** Description      Cancels print job
**
**
** Returns          void
*******************************************************************************/
void btapp_pr_abort(void);

/*******************************************************************************
**
** Function         btapp_pr_is_job_status
**
** Description
**
**
** Returns
*******************************************************************************/
BOOLEAN btapp_pr_is_job_status(void);

/*******************************************************************************
**
** Function         btapp_pr_set_job_status
**
** Description
**
**
** Returns
*******************************************************************************/
void btapp_pr_set_job_status(BOOLEAN enable);

/*******************************************************************************
**
** Function         btapp_pr_get_printer_caps
**
** Description      Call BTA_PrGetCaps for requested printer
**
** Returns          void
*******************************************************************************/
void btapp_pr_get_printer_caps (BD_ADDR bdaddr, tBTA_SERVICE_MASK services);

/*******************************************************************************
**
** Function         btapp_pr_is_caps
**
** Description      TRUE if we had already saved capabilities of this printer
**
** Returns          void
*******************************************************************************/
BOOLEAN btapp_pr_is_caps (BD_ADDR bdaddr);
/*******************************************************************************
**
** Function         btapp_pr_print_file
**
** Description      Sends the file 
**
**
** Returns          void
*******************************************************************************/
BOOLEAN btapp_pr_print_file (BD_ADDR bdaddr, char *p_name,tBTA_SERVICE_MASK services );


#endif  /* BTAPP_AG_H */

