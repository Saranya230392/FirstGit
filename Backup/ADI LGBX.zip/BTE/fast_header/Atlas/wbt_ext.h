/*****************************************************************************
**
**  Name:           wbt_ext.h
**
**  Description:    This file contains definitions and constants used by the
**                  Broadcom Bluetooth Extensions software.
**
**  Copyright (c) 2005, Broadcom Corp., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/
#ifndef WBT_EXT_H
#define WBT_EXT_H


#endif /* WBT_EXT_H */
