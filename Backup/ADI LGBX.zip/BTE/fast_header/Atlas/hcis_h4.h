/*****************************************************************************
**                                                                           
**  Name:          hcis_h4.h
**                                                                           
**  Description:
**      H4 HCI Services
**
**      This file contains definitions and function prototypes for the H4.
**      HCI services.
**                                                                           
**  Copyright (c) 2002-2004, WIDCOMM Inc., All Rights Reserved.             
**  WIDCOMM Bluetooth Core. Proprietary and confidential.                    
******************************************************************************/
#ifndef HCIS_H4_H
#define HCIS_H4_H

/*****************************************************************************
** Definitions
******************************************************************************/

/* Configuration structure for H4 */
typedef struct {
    UINT8   port_id;            /* Port ID */
    UINT8   baud;               /* Baud rate */
    UINT16  data_fmt;           /* Data format (parity, data bits, and stop bits) */
    UINT8   slip_mode;          /* whether slip mode support */
} tHCIS_H4_CFG;

enum
{
    HCISU_H4_CLOSED_ST,
    HCISU_H4_OPENING_ST,
    HCISU_H4_OPENED_ST,
    HCISU_H4_CLOSING_ST
};
typedef UINT8 tHCISU_H4_STATE;


/* Trasnprt receive states */
enum
{
    HCISU_H4_MSGTYPE_ST,
    HCISU_H4_LEN_ST,
    HCISU_H4_NOBUF_LEN_ST,
    HCISU_H4_DATA_ST,
    HCISU_H4_IGNORE_ST
};
typedef UINT8 tHCISU_H4_RCV_STATE;

/* Control block for HCISU_H4 */
typedef struct
{
    BT_HDR  *p_rcv_msg;             /* Buffer for holding current incoming HCI message */
    UINT16  rcv_len;                /* Size of current incoming message */
    UINT16  transport_task_evt;     /* Event used to indicate an HCIS event */
    UINT8   rcv_msg_type;           /* Current incoming message type */
    UINT8   previous_rcv_byte;      /* Used to accumulate message length from stream */
    tHCISU_H4_RCV_STATE rcv_state;  /* Receive state of current incoming message */
    UINT8 port_id;                  /* Port ID of serial port */
    tHCISU_H4_STATE h4_state;       /* State of serial port */
    UINT8 btu_task_id;              /* Task that is handling incoming HCI messages */
    UINT8 transport_task_id;        /* Task that is handling HCIS evnets */
    UINT8   slip_mode;              /* whether slip mode support */
} tHCISU_H4_CB;


/*****************************************************************************
** External Declarations
******************************************************************************/

extern const tHCISU_IF hcisu_h4;

#endif      /* #ifndef HCIS_H4_H */
