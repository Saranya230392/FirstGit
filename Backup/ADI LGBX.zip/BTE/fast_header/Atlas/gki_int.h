/****************************************************************************
**
**  Name        gki_int.h
**
**  Function    This file contains GKI private definitions
**
**
**  Copyright (c) 1999-2002, Widcomm Inc., All Rights Reserved.
**  Proprietary and confidential.
**
*****************************************************************************/
#ifndef GKI_INT_H
#define GKI_INT_H

#ifndef BUILDCFG
#define BUILDCFG
#endif
#include "target.h"

#include "gki_common.h"
#undef BTA_TARGET_H
#undef ASSERT_FATAL

#include "kernel.h"


/**********************************************************************
** OS specific definitions
*/

typedef struct
{
    /* OS specific variables */
    #if defined (GKI_EVENT_USE) 
    UINT8 event_group[GKI_MAX_TASKS];
    #endif
     QueueId  QTaskId[GKI_MAX_TASKS];
     TaskId   ki_task_id[GKI_MAX_TASKS];

} tGKI_OS;

/* Contains common control block as well as OS specific variables */
typedef struct
{
    tGKI_OS     os;
    tGKI_COM_CB com;
} tGKI_CB;


#ifdef __cplusplus
extern "C" {
#endif

#if GKI_DYNAMIC_MEMORY == FALSE
GKI_API extern tGKI_CB  gki_cb;
#else
GKI_API extern tGKI_CB *gki_cb_ptr;
#define gki_cb (*gki_cb_ptr)
#endif

#ifdef __cplusplus
}
#endif

#endif
