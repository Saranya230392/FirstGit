/******************************************************************************
**                                                                            *
**  Name:          pap_api.h                                                  *
**                                                                            *
**                                                                            *
**  Description:   This file contains the PAP Profile API definitions.        *
**                                                                            *
**                                                                            *
**  Copyright (c) 1999-2004, WIDCOMM Inc., All Rights Reserved.               *
**  WIDCOMM Bluetooth Core. Proprietary and confidential.                     *
******************************************************************************/
#ifndef PAP_API_H
#define PAP_API_H

#include "gap_api.h"
#include "hsp2_api.h"
#include "hfp_api.h"


/*****************************************************************************
**  Constants
*****************************************************************************/

/* Discoverability Modes */
#define PAP_GENERAL_DISCOVERABLE        BTM_GENERAL_DISCOVERABLE
#define PAP_NON_DISCOVERABLE            BTM_NON_DISCOVERABLE
#define PAP_DEFAULT_DISCOVERABLE        BTM_GENERAL_DISCOVERABLE
#define PAP_IGNORE_DISCOVERABLE         0x7E


/* Connectability Modes */
#define PAP_NON_CONNECTABLE             BTM_NON_CONNECTABLE
#define PAP_CONNECTABLE                 BTM_CONNECTABLE
#define PAP_DEFAULT_CONNECTABLE         BTM_CONNECTABLE


/* Pairability Modes */
#define PAP_DISALLOW_PAIRING            0
#define PAP_ALLOW_PAIRING               1
#define PAP_DEFAULT_PAIRING             PAP_ALLOW_PAIRING


/* Security Modes */
#define PAP_SEC_MODE_NONE               BTM_SEC_MODE_NONE:
#define PAP_SEC_MODE_SERVICE            BTM_SEC_MODE_SERVICE
#define PAP_SEC_MODE_LINK               BTM_SEC_MODE_LINK
#define PAP_DEFAULT_SECURITY            BTM_SEC_MODE_NONE


/* Options set at PAP_EstablishConnection */
#define PAP_CONN_OPT_SKIP_INQ           HSP2_CONN_OPT_SKIP_INQ  /* Connection established w/o inquiring for peer */
#define PAP_CONN_OPT_USE_LTD_INQ        HSP2_CONN_OPT_USE_LTD_INQ  /* TE/ME: Use limited inquiry when finding devices */

#define PAP_ME_THREE_WAY_CALLS          0x0001
#define PAP_ME_EC_ANDOR_NR_FUNC         0x0002
#define PAP_ME_VOICE_REC_FUNC           0x0004
#define PAP_ME_INBAND_RING_TONE         0x0008
#define PAP_ME_ATT_PHNUM_VTAG           0x0010

#define PAP_TE_EC_ANDOR_NR_FUNC         0x0001
#define PAP_TE_CW_THREE_WAY_CALLS       0x0002
#define PAP_TE_CLI_CAPABILITY           0x0004
#define PAP_TE_VOICE_REC_ACT            0x0008
#define PAP_TE_REMOTE_VOL_CTRL          0x0010

/* Options set in RegInfo at PAP_Register */
#define PAP_REG_OPT_NO_AT_CMD_ACK       HSP2_REG_OPT_NO_AT_CMD_ACK  /* AG: Do not send 'OK' when AT command received */
#define PAP_REG_OPT_PARK_MODE           HSP2_REG_OPT_PARK_MODE  /* HS/AG: Enter park mode on disconnect */
#define PAP_CONN_OPT_WAIT_AT_CMD_RSP    HSP2_CONN_OPT_WAIT_AT_CMD_RSP  /* HS: Do not send AT command until receive responce from previous cmd */

#define PAP_REG_OPT_HF_RX_OK_EVT        0x0020  /* HF: To Receive HFP_APP_EVT_OK_RESULT event through the callback */
#define PAP_REG_OPT_SEND_CHLD_QUERY     HFP_REG_OPT_SEND_CHLD_QUERY  /* TE to send AT+CHLD=? at service level connection */

/* Supported Features Bitmask */
#define PAP_ME_3WAY_SUPPORTED       0x0001  /* 3-way calling */
#define PAP_ME_ECNR_SUPPORTED       0x0002  /* EC and/or NR function */
#define PAP_ME_VREC_SUPPORTED       0x0004  /* Voice Recognition function */
#define PAP_ME_INBAND_SUPPORTED     0x0008  /* Inband ring-tone */
#define PAP_ME_VTAG_SUPPORTED       0x0010  /* Attach a phone number to a voice tag */
#define PAP_ME_RSP_HLD_SUPPORTED    0x0020  /* Response And Hold Feature */

#define PAP_TE_ECNR_SUPPORTED       0x0001  /* EC and/or NR function */
#define PAP_TE_CW_3WAY_SUPPORTED    0x0002  /* Call Waiting and 3 way calling */
#define PAP_TE_CLIP_SUPPORTED       0x0004  /* CLI presentation capability */
#define PAP_TE_VREC_SUPPORTED       0x0008  /* Voice Recognition activation */
#define PAP_TE_RVOL_SUPPORTED       0x0010  /* Remote Volume */

/* Error code base offset (tPAP_STATUS) */
#define PAP_ERR_GRP 0xF00

/* Maximum length of service name */
#define PAP_MAX_NAME_LEN        HSP2_MAX_NAME_LEN


/*****************************************************************************
**  Type Definitions
*****************************************************************************/

/* HFP role definitions */
enum {
    PAP_ROLE_IS_ME,
    PAP_ROLE_IS_TE
};
typedef UINT8 tPAP_ROLE;

/* HFP application callback event codes */
enum {
    PAP_APP_EVT_RFC_OPEN,           /* RFCOMM port opened */
    PAP_APP_EVT_RFC_CLOSE,          /* RFCOMM port closed */

    PAP_APP_EVT_SCO_OPEN,           /* SCO channel opened */
    PAP_APP_EVT_SCO_CLOSE,          /* SCO channel closed */
 
    PAP_APP_EVT_OK_RESULT,          /* Received OK result code */
    PAP_APP_EVT_RING,               /* Received RING result code */
    PAP_APP_EVT_ERROR_RESULT,       /* Received ERROR result code */
    PAP_APP_EVT_CKPD,               /* Received AT+CKPD command */
    PAP_APP_EVT_VGM,                /* Received AT+VGM command */
    PAP_APP_EVT_VGS,                /* Received AT+VGS command */

    PAP_APP_EVT_A,
    PAP_APP_EVT_D,
    PAP_APP_EVT_CCWA,
    PAP_APP_EVT_CHLD,
    PAP_APP_EVT_CHUP,
    PAP_APP_EVT_CIND,
    PAP_APP_EVT_CLIP,
    PAP_APP_EVT_CMER,
    PAP_APP_EVT_CIEV,
    PAP_APP_EVT_VTS,
    PAP_APP_EVT_BINP,
    PAP_APP_EVT_BLDN,
    PAP_APP_EVT_BVRA,
    PAP_APP_EVT_NREC,
    PAP_APP_EVT_BSIR,

	PAP_APP_EVT_AT_RSP_TOUT = HSP2_APP_EVT_AT_RSP_TOUT,        /* Response to AT command not received withing timeout */
    PAP_APP_EVT_SNT_ERROR = HSP2_APP_EVT_SNT_ERROR,          /* Sent an Error result code */                  

#if (HFP_RPT_PEER_INFO_INCLUDED == TRUE)
    PAP_APP_EVT_PEER_INFO,
#endif
    PAP_APP_EVT_PAP_STATUS = HSP2_APP_EVT_HSP2_STATUS,       /* Report of internal status code (see below) */ 
	PAP_APP_EVT_DTMF_COMPLETE

};
typedef UINT16 tPAP_APP_CALLBACK_EVENT;

/* Status codes */
enum {
    PAP_SUCCESS = BT_PASS,      /* Success */
    PAP_FAILURE = PAP_ERR_GRP,  /* Unspecified failure. */

    PAP_NO_RESOURCES,           /* Unspecified failure to allocate resource */
    PAP_NO_MSG_RESOURCES,       /* Unable to allocate AT Command Message buffer */
    PAP_NO_GKI_RESOURCES,       /* Unable to allocate GKI Buffer */
    PAP_NO_QUEUE_RESOURCES,     /* Unable to allocate HSP Event Queue Buffer */

    PAP_ERR_ALREADY_REGISTERED, /* Attempt to register HSP failed: Already registered */
    PAP_ERR_NOT_REGISTERED,     /* Attempt to call API function failed: Not registered */
    
    PAP_ERR_PORT_OPEN,          /* Unspecified failure to open RFCOMM Port. */
    PAP_ERR_RFC_IS_CLOSED,      /* Attempt to close RFC failed: Port closed or closing. */
    PAP_ERR_RFC_IS_OPEN,        /* Attempt to open RFC failed: Port open or opening. */
    PAP_ERR_RFC_DATA_ERR,       /* Attempt to read RFC Data failed. */

    PAP_ERR_SCO_OPEN,           /* Unspecified failure to open SCO or enter SCO Listen mode */
    PAP_ERR_SCO_IS_OPEN,        /* Attempt to open SCO failed: Connection open or opening. */

    PAP_ERR_NO_MSG,             /* Attempt to send AT Command failed: Queue empty. */

    PAP_ERR_INQUIRY,            /* Unspecified failure to perform Inquiry */
    PAP_INQ_NO_DEVICES,         /* Inquiry found no devices */ 
    PAP_ERR_START_INQ,          /* Attempt to start Inquiry failed. */

    PAP_ERR_SECURITY_FAILED,    /* Attempt to set Security Level failed. */
    PAP_ERR_SET_DISC_MODE,      /* Attempt to set Discoverability Mode failed. */
    PAP_ERR_SET_CONN_MODE,      /* Attempt to set Connectability Mode failed. */

    PAP_ERR_DISCOVERY,          /* Attempt to perform Discovery failed. */
    PAP_ERR_SDP_REG,            /* Attempt to register SDP for Discovery failed. */
    PAP_ERR_SDP_PROTO,          /* Attempt to add Protocol List to SDP failed. */
    PAP_ERR_SDP_CLASSID,        /* Attempt to add Class ID to SDP failed */
    PAP_ERR_SDP_PROFILE,        /* Attempt to add Profile Descriptor list to SDP failed */
    PAP_ERR_SDP_ATTR,           /* Attempt to add Attribute to SDP failed */
    PAP_ERR_NO_SCN,             /* Peer discovery record did not contain SCN number */
    PAP_SERV_NOT_SUPPORTED,     /* Peer discovery failed to find required services */         

    PAP_ERR_GAIN_OUT_OF_RANGE,  /* Attempt to set gain failed: Value outside of valid range */
    PAP_ERR_NO_GAIN_SUPPORT,    /* Attempt to set gain failed: Peer does not support 
                                 * remote gain control */

    PAP_ERR_NO_BDADDR           /* Attempt to establish connection failed: No BD Address
                                 * was specified */

};
typedef UINT16 tPAP_STATUS;

/* AT query types */
enum {
    PAP_AT_NO_QUERY,
    PAP_AT_CMD_QUERY,
    PAP_AT_VAL_QUERY
};
typedef UINT8 tPAP_AT_QUERY_TYPE;

typedef tHSP2_REG_INFO tPAP_REG_INFO;
typedef tHSP2_PEER_INFO tPAP_PEER_INFO;

typedef tHFP_AG_INFO tPAP_ME_INFO;

enum {
    PAP_INDICATORS_STATUS,	/* To send current status of all indicators. */
    PAP_CALLS_STATUS,	    /* To send current calls info. */
    PAP_PIN_STATUS,	        /* To send SIM PIN status */
    PAP_OPERATOR_STATUS,	/* To send current operator/available operators. */
    PAP_CLIR_STATUS,	    /* To send CLIR status */
    PAP_NW_REG_STATUS,	    /* To send Network Registration status. */
    PAP_CALL_BAR_STATUS,	    /* To send Call Waiting status */
    PAP_CALL_FWD_STATUS,	    /* To send Call Waiting status */
    PAP_CALL_WAIT_STATUS    /* To send Call Forwarding status */
}; typedef UINT8 tPAP_CURR_STATUS_CODE;

typedef struct
{
    char clip_info[PAP_MAX_CLIP_INFO];
    BOOLEAN inband_ring;
} tPAP_IND_INCALL_PARAMS;

enum {
    PAP_CONNECT_CALL,       /* ME has answered call on TE's behalf and it is to be connected */
    PAP_ME_ANSWERED_CALL,   /* Call answered from ME, now unavailable to TE */
    PAP_ME_REJECTED_CALL,   /* Call rejected and is no longer available to TE */
    PAP_ME_CALL_HELD,       /* ME has put the call on hold as instructed from TE */
    PAP_ME_CALL_HELD_ACCEPTED, /* ME has connected to held call as instructed by TE */
    PAP_ME_CALL_HELD_UNAVLBL    /* The held call is no longer available to TE */
}; typedef UINT8 tPAP_IN_CALL_STATUS;

enum {
    PAP_CALL_SETUP_FAILURE,
    PAP_REMOTE_PARTY_REACHED
}; typedef UINT8 tPAP_OUT_CALL_STATUS;

enum {
    PAP_PHONE_NUM_SUPPLIED,
    PAP_MEMORY_DIALING,
    PAP_LAST_NUMBER_REDIAL
}; typedef UINT8 tPAP_PH_NUM_SRC;

enum {
    PAP_SET_CALLER_ID,
    PAP_SET_EC_NR_FUNC,
    PAP_SET_VOICE_REC,
    PAP_SET_REG_IND_REPORTING,
    PAP_SET_CLIR,
    PAP_SET_CALL_BARRING,
    PAP_SET_CALL_FWDING,
    PAP_SET_CALL_WAITING,
    PAP_SET_USSD_NOTIFICATION,
    PAP_SET_SSN_NOTIFICATION
}; typedef UINT8 tPAP_SET_CODE;

enum {
    PAP_UPD_VOICE_REC,	    /* Used with notification set to "0" to indicate voice rec deactivation by ME */
    PAP_UPD_INBAND_RING,    /* Used with notification set to "1"/"0" to indicate in-band ringing activation/deactivation by ME */
    PAP_UPD_REGISTRATION_IND,/*	Used with notification set to "<reg-ind>,<status>" to indicate changes in registration indicator. */
    PAP_UPD_NW_REG_STATUS,  /* Used to transfer network registration status change. */
    PAP_CALL_WAITING_NOTIFY,/* Used to send call waiting notification. */
    PAP_USSD_NOTIFY,        /* Used to send unstructured supplementary data. */
    PAP_SSN_NOTIFY_CSSI,    /* Used to send intermidiate supplementary service notifications. */
    PAP_SMS_NOTIFY,         /* Used to send Short Message arrival notifications. */
    PAP_SMS_BCST_NOTIFY,     /* Used to send Cell Broadcast arrival notifications.*/
    PAP_SSN_NOTIFY_CSSU    /* Used to send unsolicited supplementary service notifications. */
}; typedef UINT8 tPAP_UPDATE_CODE;

enum {
    PAP_PB_GOP_FIND_BY_NAME, 
    PAP_PB_GOP_FIND_BY_LOC, 
    PAP_PB_GOP_SCROLL_PB
}; typedef UINT8 tPAP_PB_GET_ENTRY_OP;

enum {
    PAP_GET_AVLBL_PB,       /* Get all available phonebooks */
    PAP_GET_PB_SUMMARY,     /* Get a summary of selected phonebook.	*/
    PAP_GET_ALL_REG_INDS,   /* Get all available indicators */
    PAP_GET_CURR_REG_INDS,  /* Get current status of indicators.*/
    PAP_GET_AVLBL_OPS,      /* Get available operators in the network. */ 
    PAP_GET_SELECTED_OP,    /* Get selected network operator. */
    PAP_GET_CLIR_SUPPORT,   /* Find if CLIR supported by network. */
    PAP_GET_MEM_STOR_LIST,  /* Get a list of supported memory storages. */
    PAP_GET_PIN_STATUS,     /* Get status of PIN in ME. */
    PAP_GET_NW_REG_STATUS,  /* Get current status of network registration. */
    PAP_GET_CURR_CALLS,	    /* To send current calls info. */
    PAP_GET_CALL_WAITING,	/* To send Call Waiting status */
    PAP_GET_CALL_BARRING,	/* To send Call Waiting status */
    PAP_GET_CALL_FORWARDING,/* To send Call Forwarding status */
    PAP_GET_MUL_PARTY_SUPPORT /* Get 3-way calling and multiparty support info. */
}; typedef UINT8 tPAP_QUERY_CODE;


enum {
    PAP_SMS_MTYPE_INF,       /* Use to send types of messages supported. */
    PAP_SMS_AVLBL_MEM_STG,   /* Use to send available memory storages. */
    PAP_SMS_SEL_STG_SUM,     /* Use to send summary information for selected storages */
    PAP_SMS_NSND_REF_VALUE,  /* Use to send reference value for a newly sent SMS message */
    PAP_SMS_WRI_REF_VALUE,   /* Use to send reference value for a SMS message written to the memory location. */
    PAP_SMS_MSND_REF_VALUE,  /* Use to send reference value for the SMS message sent from a memory location. */
    PAP_SMS_STATUS_REPORT    /* Use to send CDS unsolicited result code */
}; typedef UINT8 tPAP_SMS_INF_CODE;

enum {
    PAP_SMSP_MSG_SVC,       /* Use to select message service */
    PAP_SMSP_PREF_MSG_ST,   /* Use to set preferred message storage. */
    PAP_SMSP_MSG_FORMAT,    /* Use to set message format.  */
    PAP_SMSP_SVC_CTR_ADR,   /* Use to set service center address. */ 
    PAP_SMSP_TXT_MODE,      /* Use to set text mode parameters. */
    PAP_SMSP_BCST_MTYPE,    /* Use to select cell broadcast message type. */ 
    PAP_SMSP_MSG_IND        /* Use to set new message indications to TE. */
}; typedef UINT8 tPAP_SMS_PARAM_CODE;

enum {
    PAP_SMS_GET_SMS_LIST,
    PAP_SMS_GET_MSG_LOC
}; typedef UINT8 tPAP_SMS_GET_ENTRY_OP;

enum {
    PAP_SMSW_SND_NEW_MSG,   /* Use to send a new short message.*/
    PAP_SMSW_WRITE_MEM,     /* Use to write short message to a memory location.*/
    PAP_SMSW_SND_MEM_LOC,   /* Use to send short message from a memory location. */
    PAP_SMSW_DEL_MEM_LOC    /* Use to delete short message from a memory location.*/
}; typedef UINT8 tPAP_SMS_WRITE_CODE;


/* Type of PAP application callback function */
typedef void (tPAP_CALLBACK) (tPAP_APP_CALLBACK_EVENT event, UINT32 data, void *pdata);


/*****************************************************************************
**  External Function Declarations
*****************************************************************************/
#ifdef __cplusplus
extern "C"
{
#endif

/*******************************************************************************
**
** Function         PAP_Init
**
** Description      This function is called before accessing the PAP APIs in
**                  order to initialize the control block.
**
** Returns          void
**
*******************************************************************************/
PAP_API extern void PAP_Init(void);

/******************************************************************************
**
** Function      PAP_Register
**
** Description   This is the PAP API call used to register an ME or 
**               TE.  This function must be called before any other PAP 
**               API function is called.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_Register (tPAP_REG_INFO *pHFPRegInfo,
                                         tPAP_ME_INFO *inds);

/******************************************************************************
**
** Function      PAP_Deregister
**
** Description   This is the PAP API call used to deregister an ME or 
**               TE.  
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_Deregister(void);

/******************************************************************************
**
** Function      PAP_EstablishServLevelConn
**
** Description   This is the PAP API call used to establish a connection to a 
**               peer TE or ME.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_EstablishServLevelConn(BD_ADDR ServerBDAddr,
                                                      UINT8 *ServerName,
                                                      UINT16 Options);

/******************************************************************************
**
** Function      PAP_ReleaseServLevelConn
**
** Description   This is the PAP API call used to disconnect froma peer TE
**               or ME.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ReleaseServLevelConn(void);

/******************************************************************************
**
** Function      PAP_SetupAudioConn
**
** Description   This API initiates SCO connection with the peer.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_SetupAudioConn(void);

/******************************************************************************
**
** Function      PAP_ReleaseAudioConn
**
** Description   This API releases SCO connection with the peer.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ReleaseAudioConn(void);

/******************************************************************************
**
** Function      PAP_SendATString
**
** Description   This API sends AT commands or response codes to the peer when 
**               a service level connection has been established.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_SendATString(BOOLEAN is_cmd, char at_cmd[]);

/******************************************************************************
**
** Function      PAP_SendMicGain
**
** Description   This is the PAP API call used to send the mic gain 
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_SendMicGain (UINT8 MicGain);

/******************************************************************************
**
** Function      PAP_SendSpkGain
**
** Description   This is the PAP API call used to send the speaker gain 
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_SendSpkGain (UINT8 SpkGain);

/******************************************************************************
**
** Function      PAP_ME_IndicateInCall
**
** Description   This API, to be used by the ME application, indicates to the 
**               hands-free kit presence of an incoming call. If in-band ring 
**               option is chosen, and SCO hasn't been already established, it 
**               initiates a SCO connection. Upon SCO connection establishment, 
**               it sends RING and optionally +CLIP unsolicited result codes to 
**               hands-free kit repeatedly.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_IndicateInCall (tPAP_IND_INCALL_PARAMS params);

/******************************************************************************
**
** Function      PAP_ME_ProceedInCall
**
** Description   This API, to be used by the ME application, indicates the status
**               of the incoming call (delivered using PAP_ME_IndicateInCall) to
**               the hands-free kit. This causes an appropriate +CIEV: unsolicited
**               response code to be sent to the hands free kit. If call is to be
**               connected, it initiates SCO connection (if not there already.)
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_ProceedInCall (tPAP_IN_CALL_STATUS status );

/******************************************************************************
**
** Function      PAP_ME_ProceedOutCall
**
** Description   This API, to be used by the ME application, indicates the status
**               of the outgoing call (requested using PAP_TE_PlaceOutCall) to the
**               hands-free kit. This causes an appropriate +CIEV: unsolicited
**               response code to be sent to the hands free kit. If remote party
**               is reached, it initiates SCO connection (if not there already.)
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_ProceedOutCall (tPAP_OUT_CALL_STATUS status);

/******************************************************************************
**
** Function      PAP_ME_TerminateCall
**
** Description   This API, to be used by the ME application, terminates an on-going
**               call with the hands-free kit. This causes an appropriate +CIEV: 
**               unsolicited response code to be sent to the hands free kit.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_TerminateCall (void);

/******************************************************************************
**
** Function      PAP_ME_ReplyCurrStatus
**
** Description   This API, to be used by ME application, sends the current 
**               status of Indicators, Calls, PIN, selected operator to the TE.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_ReplyCurrStatus(tPAP_CURR_STATUS_CODE code,
                                                  char status[]);

/******************************************************************************
**
** Function      PAP_ME_SendCmdStatus
**
** Description   This API, to be used by ME application, sends the status of the
**               commands issued by hands-free kit to enable or disable functions
**               such as Enabling of Indicator Status Update (CMER), Call Waiting
**               (CCWA), Caller Id (CLIP), EC and/or NR function (NREC), Voice
**               Recognition (BVRA) etc.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_SendCmdStatus (BOOLEAN status);

/******************************************************************************
**
** Function      PAP_ME_SendCMEError
**
** Description   This API sends +CME Error: along with the provided code.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_SendCMEError (UINT16 err_code);

/******************************************************************************
**
** Function      PAP_ME_SendCMSError
**
** Description   This API sends +CMS Error: along with the provided code
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_SendCMSError (UINT16 err_code);

/******************************************************************************
**
** Function      PAP_ME_VrecReplyForPhoneNum
**
** Description   This API, to be used by ME application, sends the response to
**               the AT+BINP command from TE (request phone number for the 
**               procedure to attach number to a voice tag.).
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_VrecReplyForPhoneNum (char ph_num[]);

/******************************************************************************
**
** Function      PAP_ME_StatusUpdate
**
** Description   This API, to be used by ME application, informs TE of the
**               changes status of functions such as Voice Recognition, In-band Ringing etc.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_StatusUpdate (tPAP_UPDATE_CODE code,
                                                char notification[] );

/******************************************************************************
**
** Function      PAP_ME_ReplyPBEntry
**
** Description   This API, to be used by ME application, sends the response to
**               the AT+CPBF, CPBR or BPBS commands from TE (to get phonebook entries).
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_ReplyPBEntry (tPAP_PB_GET_ENTRY_OP get_op,
                                                char pb_entry[]);

/******************************************************************************
**
** Function      PAP_ME_ReplySubNumInfo
**
** Description   This API, to be used by ME application, sends the response to
**               the AT+CNUM=? from TE (to get subscriber info).
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_ReplySubNumInfo (char sub_num[]);

/******************************************************************************
**
** Function      PAP_ME_ReplySMSInfo
**
** Description   This API, to be used by ME application, sends the response to
**               the AT+CSMS, CPMS or CMGS, CMGW, CMSS commands from TE 
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_ReplySMSInfo (tPAP_SMS_INF_CODE  code,
                                                char sms_info[]);

/******************************************************************************
**
** Function      PAP_ME_ReplySMSMsg
**
** Description   This API, to be used by ME application, sends the response to
**               the AT+CMGL, or CMGR commands from TE (to get SMS entries).
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_ReplySMSMsg (tPAP_SMS_GET_ENTRY_OP get_op,
                                               char entry[]);

/******************************************************************************
**
** Function      PAP_TE_AnswerInCall
**
** Description   This API, to be used by the TE application, either answers a call
**               or puts it on hold. This causes the at command ATA or AT+BTRH=0
**               to be sent to the ME.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_AnswerInCall (BOOLEAN hold);

/******************************************************************************
**
** Function      PAP_TE_ProceedHeldInCall
**
** Description   This API, to be used by the TE application, proceeds on a held
**               incoming call This causes the at command AT+BTRH=1 or 2 
**               to be sent to the ME.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_ProceedHeldInCall (BOOLEAN accept_flag);

/******************************************************************************
**
** Function      PAP_TE_TerminateCall
**
** Description   This API, to be used by the TE application, terminates an on-
**               going call with the ME. This causes the command AT+CHUP to be
**               sent to the ME.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_TerminateCall (void);

/******************************************************************************
**
** Function      PAP_TE_PlaceOutCall
**
** Description   This API, to be used by TE application, initiates an outgoing call.
**               It sends an appropriate command ATD, ATD> or AT+BLDN to ME.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_PlaceOutCall (tPAP_PH_NUM_SRC src, char num[]);

/******************************************************************************
**
** Function      PAP_TE_ToggleFeature
**
** Description   This API, to be used by TE application, enables or disables
**               functions such as Call Waiting, Caller Id, EC and/or NR function,
**               and Voice Recognition.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_ToggleFeature (tPAP_SET_CODE code,
                                                 char setting[]);

/******************************************************************************
**
** Function      PAP_TE_HookFlash
**
** Description   This API, to be used by TE application, indicates desire to place
**               a call on hold and go to the other call for the three-way calling
**               or call waiting functions.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_HookFlash (UINT8 call_num);

/******************************************************************************
**
** Function      PAP_TE_VrecReqForPhoneNum
**
** Description   This API, to be used by TE application, indicates desire to
**               place a voice tag to a phone number.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_VrecReqForPhoneNum (void);

/******************************************************************************
**
** Function      PAP_TE_TxDTMFCode
**
** Description   This API, to be used by TE application, transmits DTMF code.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_TxDTMFCode (char dtmf[]);

/******************************************************************************
**
** Function      PAP_TE_QueryStatus
**
** Description   This API, to be used by TE application, an AT query
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_QueryStatus (tPAP_QUERY_CODE code,
                                               UINT8 additional_info);

/******************************************************************************
**
** Function      PAP_TE_SelectPB
**
** Description   This API can be used to select a Phonebook for further
**               operations.
**               This results in sending of AT+CPBS="<selected-PB>".
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_SelectPB (char pb[]);

/******************************************************************************
**
** Function      PAP_TE_GetPBEntry
**
** Description   This API find phonebook entries by name, memory location or
**               for scrolling phonebook. This results in sending of either CPBF,
**               CPBR or BPBS AT command.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_GetPBEntry (tPAP_PB_GET_ENTRY_OP get_op,
                                              char search_info[]);

/******************************************************************************
**
** Function      PAP_TE_SelectPBSortOrder
**
** Description   This API can be used to select a Phonebook sort order for
**               further operations. This results in sending of AT+BPBSO=<sort-order>.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_SelectPBSortOrder (UINT8 sort_order);

/******************************************************************************
**
** Function      PAP_TE_WritePBEntry
**
** Description   This API can be used to add, edit or delete a phonebook entry.
**               This results in sending of AT+CPBW="<entry-info>".
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_WritePBEntry (char entry_info[]);

/******************************************************************************
**
** Function      PAP_TE_SetupPBFixDial
**
** Description   This API can be used to set up phonebook for Fixed Dialing.
**               This results in sending of AT+CLCK command.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_SetupPBFixDial (char fd_info[]);

/******************************************************************************
**
** Function      PAP_TE_SendPinCode
**
** Description   This API can be used to send SIM PIN or PUK code to ME.
**               This results in sending of AT+CPIN command.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_SendPinCode (char pin_info[]);

/******************************************************************************
**
** Function      PAP_TE_SetSMSParam
**
** Description   This API can be used to select message service, set preferred 
**               message storage, set message format, set service center address,
**               set text mode parameters, select cell broadcast message type or
**               set new message indications to TE.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_SetSMSParam (tPAP_SMS_PARAM_CODE code,
                                               char setting[]);

/******************************************************************************
**
** Function      PAP_TE_GetSMSMsgs
**
** Description   This API, to be used by TE application, sends requests to
**               get SMS entries.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_GetSMSMsgs (tPAP_SMS_GET_ENTRY_OP get_op,
                                              char info[]);

/******************************************************************************
**
** Function      PAP_TE_WriteSMSMsg
**
** Description   This API can be used to add, edit or delete or send a short message.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_WriteSMSMsg (tPAP_SMS_WRITE_CODE code,
                                               char info[]);

/******************************************************************************
**
** Function      PAP_TE_SelectNwOp
**
** Description   This API can be used to select and register a network operator.
**               This results in sending of AT+COPS command.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_SelectNwOp (char nw_info[]);

/******************************************************************************
**
** Function      PAP_TE_GetSubNumInfo
**
** Description   This API can be used to access to the phone number of the ME 
**               for Voice Calls Data Calls and Fax Calls. This results in 
**               sending of AT+CNUM command.
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_TE_GetSubNumInfo (void);

/******************************************************************************
**
** Function      PAP_ME_ReplyPBInfo
**
** Description   This API, to be used by ME application, sends the response to
**               the AT+CPBS=? or AT+CPBS? command from TE (to get phonebook info).
**
** Returns       tPAP_STATUS (PAP_SUCCESS or an error code).
**
******************************************************************************/
PAP_API extern tPAP_STATUS PAP_ME_ReplyPBInfo (char pb_info[]);

#ifdef __cplusplus
}
#endif

#endif /* PAP_API_H */
