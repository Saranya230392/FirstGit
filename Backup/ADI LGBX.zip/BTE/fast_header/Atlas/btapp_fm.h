/*****************************************************************************
**
**  Name:           btapp_fm.h
**
**  Description:    Contains application functions Bluetooth FM Profile
**
**
**  Copyright (c) 2006, Widcomm Inc., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/


/*******************************************************************************
**
** Function         btapp_fm_enable
**
** Description    Enable FM 
**                  
**
** Returns          void
**
*******************************************************************************/
extern void btapp_fm_enable(void);

/*******************************************************************************
**
** Function         btapp_fm_disable
**
** Description      Disables PBS
**                  
**
** Returns          void
**
*******************************************************************************/
extern void btapp_fm_disable(void);


/*******************************************************************************
**
** Function         btapp_fm_is_enabled
**
** Description    return the current state of FM
**                  
**
** Returns          void
**
*******************************************************************************/
extern BOOLEAN btapp_fm_is_enabled(void);


/*******************************************************************************
**
** Function         btapp_fm_is_rds_on
**
** Description    return the state of RDS (TRUE if ON, FALSE if OFF)
**                  
**
** Returns          void
**
*******************************************************************************/
extern BOOLEAN btapp_fm_is_rds_on(void);



/*******************************************************************************
**
** Function         btapp_fm_is_rds_on
**
** Description    return the state of RDS (TRUE if ON, FALSE if OFF)
**                  
**
** Returns          void
**
*******************************************************************************/
BOOLEAN btapp_fm_is_fm_sco_on(void);


/*******************************************************************************
**
** Function         btapp_fm_is_rds_on
**
** Description    return the state of audio quality status
**                  
**
** Returns          void
**
*******************************************************************************/
BOOLEAN btapp_fm_is_audio_quality_on(void);


/*******************************************************************************
**
** Function         btapp_fm_is_af_on
**
** Description    return the state of Alternative Frequency
**                  
**
** Returns          void
**
*******************************************************************************/
BOOLEAN btapp_fm_is_af_on(void);


/*******************************************************************************
**
** Function         btapp_fm_get_current_audio_mode
**
** Description    return the current audio mode
**                  
**
** Returns          void
**
*******************************************************************************/
tBTA_FM_AUDIO_MODE btapp_fm_get_current_audio_mode(void);



/*******************************************************************************
**
** Function        btapp_fm_read_rds
**
** Description   Reads the RDS information of the current FM radio station
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_read_rds(void);


/*******************************************************************************
**
** Function       btapp_fm_search_frequency
**
** Description   Searches the radio band for good channels.
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_search_frequency(BOOLEAN  search_up);

/*******************************************************************************
**
** Function       btapp_fm_scan full
**
** Description   Searches the radio band for good channels.
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_scan_full(void);

/*******************************************************************************
**
** Function       btapp_fm_scan_fast 
**
** Description   Searches the radio band for good channels.
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_scan_fast(void);

/*******************************************************************************
**
** Function       btapp_fm_tune_frequency
**
** Description   Sets the FM receiver to a specific frequency.
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_tune_frequency(char* freq_str);


/*******************************************************************************
**
** Function       btapp_fm_cancel_search
**
** Description   Cancel the ongoing search operation.
**                  
**
** Returns         void
**
*******************************************************************************/
void btapp_fm_cancel_search (void);



/*******************************************************************************
**
** Function       btapp_fm_menu_set_audio_mode
**
** Description   Manually sets the FM radio control parameter for mono/stereo/blend mode.
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_set_audio_mode(tBTA_FM_AUDIO_MODE mode);



/*******************************************************************************
**
** Function       btapp_fm_set_rds
**
** Description   Turn RDS and/or the AF algorithm ON/OFF.
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_set_rds(BOOLEAN rds_state);


/*******************************************************************************
**
** Function       btapp_fm_set_af
**
** Description   Turn RDS and/or the AF algorithm ON/OFF.
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_set_af(BOOLEAN af_state);


/*******************************************************************************
**
** Function       btapp_fm_set_audio_path
**
** Description   Set the audio path 
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_set_audio_path(tBTA_FM_AUDIO_PATH audio_path);


/*******************************************************************************
**
** Function       btapp_fm_set_audio_quality
**
** Description   Set the audio quality status
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_set_audio_quality( BOOLEAN turn_on);

/*******************************************************************************
**
** Function       btapp_fm_config_deemphasis
**
** Description   Set the emphasis/deemphasis time constant
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_config_deemphasis( tBTA_FM_DEEMPHA_TIME time_const);


/*******************************************************************************
**
** Function         btapp_fm_rds_cback
**
** Description     FM Callback function.  Handles all FM events
**                  
**
** Returns          void
**
*******************************************************************************/
void btapp_fm_rdsp_cback(tBTA_RDS_EVT event, tBTA_FM_RDS *p_data, UINT8 app_id);


