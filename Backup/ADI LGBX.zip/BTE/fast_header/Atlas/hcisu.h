/*****************************************************************************
**                                                                           
**  Name:          hcisu.h
**                                                                           
**  Description:
**      HCI Services for the upper layer stack.
**
**      This file contains definitions used by the lower-layer HCIS,
**                                                                           
**  Copyright (c) 2002-2004, WIDCOMM Inc., All Rights Reserved.             
**  WIDCOMM Bluetooth Core. Proprietary and confidential.                    
******************************************************************************/
#ifndef HCISU_H
#define HCISU_H

#include "target.h"
#include "bt_types.h"

/*****************************************************************************
** Prototypes for HCI Service interface functions
******************************************************************************/

/* Initialize transport's control block and hardware */
typedef void (*tHCISU_INIT)(UINT8 btu_task_id,
                            UINT8 transport_task_id,
                            UINT16 transport_task_evt);

/* Open port for HCI services */
typedef BOOLEAN (*tHCISU_OPEN)(void *p_cfg);

/* Close port for HCI services */
typedef void (*tHCISU_CLOSE)(void);

/* Send HCI command/data to the transport */
typedef BOOLEAN (*tHCISU_SEND)(BT_HDR *p_msg);

/* Handler for HCIS events */
typedef UINT32 (*tHCISU_EVENT_HDLR)(UINT16 event);


/*****************************************************************************
** Structure of interface functions 
******************************************************************************/
typedef struct {
    tHCISU_INIT init;
    tHCISU_OPEN open;
    tHCISU_CLOSE close;
    tHCISU_SEND send;
    tHCISU_EVENT_HDLR handle_event;
} tHCISU_IF;


/* Pointer to current HCI Service functions */
extern tHCISU_IF *p_hcisu_if;   /* Pointer to current HCIS interface functions */
extern void *p_hcisu_cfg;       /* Pointer to configuration parameter of current HCIS */
extern void bte_hcisu_task(UINT32 param);

#endif /* ifndef HCISU_H */
