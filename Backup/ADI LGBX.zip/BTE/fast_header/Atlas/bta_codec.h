/*****************************************************************************
**
**  Name:          bta_codec.h
**
**  Description:   this file contains constants and definitions for Aa codecs
**
**
**  Copyright (c) 2004-2006, Broadcom Corp., All Rights Reserved.
**  Broadcom Bluetooth Core. Proprietary and confidential.
**
******************************************************************************/
#ifndef _BTA_CODEC_H_
#define _BTA_CODEC_H_

#include "sbc_encoder.h"

#include "target.h"
#include "gki.h"
#include "bta_av_api.h"
#include "bta_av_co.h"
#include "bta_av_ci.h"
#include "a2d_sbc.h"

#ifndef BTA_AA_DEBUG
#define BTA_AA_DEBUG FALSE
#endif

#ifndef BTA_AA_MP3_SW_CODEC
#define BTA_AA_MP3_SW_CODEC FALSE
#endif


/* audio streaming codec indexes used in bta_aa_co/bta_av_co */
#define BTA_AA_SBC_INDEX       0
#define BTA_AA_M12_INDEX       1
#define BTA_AA_M24_INDEX       2
#define BTA_AA_ATRAC_INDEX     3

/* video streaming codec indexes used in bta_av_co */
enum {
    BTA_AV_H263P0_INDEX,        /* H.263 baseline (profile 0) */
#if 0
    BTA_AV_H263_P3_INDEX,       /* H.263 profile 3 */
    BTA_AV_H263_P8_INDEX,       /* H.263 profile 8 */
#endif
    BTA_AV_MPEG4_INDEX,         /* MPEG-4 Visual Simple Profile */
    BTA_AV_VEND_H264_INDEX,     /* Non-VDP */
    BTA_AV_VEND_IMG_INDEX   /* Slideshow */
};

/*  TIMER DEFINITIONS  */

#define BTA_AA_GSM_TICKS             4615
#define BTA_AA_USE_HW_TIMER          FALSE

#if  BTA_AA_USE_HW_TIMER == TRUE
#define BTA_AA_TIMER_INTERVAL_IN_US       40*1000                 //40ms
#define BTA_AA_TIMER_INTERVAL_IN_MS       40
#else
#define BTA_AA_TIMER_INTERVAL_IN_US        8*BTA_AA_GSM_TICKS    //=36920us
#endif

#ifndef BTA_AA_SBC_TIMER_MULTIPLIER
#define BTA_AA_SBC_TIMER_MULTIPLIER 1  /* default AV timer period (see period lenght in uhbtaa.h) */
#endif

#define BTA_AV_CO_INVALID_IDX       0xFF

/* max number of SBC frames per packet */
#define BTA_SBC_CODEC_FR_MAX           15

/* tuneable number of SBC frames per waveIn data buffer		*/
/* NOTE: If you change this value then you need to reset	*/
/*       the asrc_wav_period_tbl with correct info.			*/
/*       BTA_SBC_CODEC_FR_PER_BUF = 7 means we will read 896	*/
/*       samples per buffer.								*/
#define BTA_SBC_CODEC_FR_PER_BUF       15

/* Number of samples per waveIn pcm data buffer period, calculated as follows:
** Max SBC frames per AVDTP packet is 15.
** Samples per SBC frame for SBC is num_blocks * num_subbands.
** Typically music uses num_blocks=16, num_subbands=8 --> 128 samples/frame.
*/
#define BTA_SBC_CODEC_SAMPLES_PER_BUF  (BTA_SBC_CODEC_FR_PER_BUF * 128)

/* maximum number of bytes in each waveIn pcm data buffer
** samples per frame * num channels * bytes per sample 
*/
#define BTA_SBC_CODEC_BUF_MAX          (BTA_SBC_CODEC_SAMPLES_PER_BUF * 2 * 2)

/* maximum number of packets for bta codec to queue before dropping data
** this is in units of waveIn buffer periods, 20.3 ms
*/
#ifndef BTA_AA_PKT_Q_MAX
#define BTA_AA_PKT_Q_MAX           4
#endif

#define BTA_AA_SBC_OFFSET (AVDT_MEDIA_OFFSET + BTA_AV_SBC_HDR_SIZE)
#define BTA_MARKER_PACKET_TYPE     0x60

/* make sure queue structure does not exceed the pool id 0! */
#ifndef BTA_AV_VIDEO_Q_POOL_ID 
#define BTA_AV_VIDEO_Q_POOL_ID GKI_POOL_ID_0
#endif

/* use pool 2 instead of pool 3 which is sufficient for SBC streaming */
#ifndef BTA_CODEC_POOL_ID
#define BTA_CODEC_POOL_ID GKI_POOL_ID_2 
#endif

#ifndef BTA_CODEC_BUF_SIZE
#define BTA_CODEC_BUF_SIZE GKI_BUF2_SIZE
#endif

#ifndef BTA_DEFAULT_CHANNEL_MODE
#define BTA_DEFAULT_CHANNEL_MODE A2D_SBC_IE_CH_MD_JOINT
#endif
#ifndef BTA_AA_DEFAULT_LINE_SPEED_KBPS
#define BTA_AA_DEFAULT_LINE_SPEED_KBPS (200) /* for testing use 120 */
#endif

#define BTA_AA_CO_CODEC_TYPE_IDX       2
#define BTA_AV_CO_CODEC_TYPE_IDX       2

#ifndef BTA_AA_CO_MAX_SNKS
#define BTA_AA_CO_MAX_SNKS      1   /* max number of SIMULTANIOUS SNK devices (normally one per bd) */
#endif


#ifndef BTA_AA_CO_MAX_SEPS
#define BTA_AA_CO_MAX_SEPS      BTA_AV_MAX_SEPS
#endif

#ifndef BTA_AV_CO_MAX_SNKS
#define BTA_AV_CO_MAX_SNKS      BTA_AA_CO_MAX_SNKS   /* max number of SIMULTANIOUS SNK devices (normally one per bd) */
#endif

#ifndef BTA_AV_CO_MAX_SEPS
#define BTA_AV_CO_MAX_SEPS      BTA_AA_CO_MAX_SEPS /* number of codecs supported locally */
#endif

#ifndef BTA_AA_SBC_MAX_BITPOOL
#define BTA_AA_SBC_MAX_BITPOOL  0x59
#endif


#ifndef BT_NUM_AV_BUFFERS
#define BT_NUM_AV_BUFFERS 16
#endif

/* is called by sbc codec for reading new data. it shall return the numbers of byte actuall read */
#if  SBC_MULTI_FRAMES == TRUE
typedef int (tBTA_SBC_READ_CBACK)( INT16 ** p_buf, UINT16 len ); 
#else
typedef void (tBTA_SBC_READ_CBACK)( INT16 ** p_buf, UINT16 len ); 
#endif
typedef int (tCODEC_ENCODER)(void * p_param);

/* codec endpoint info */
typedef struct tBTA_AA_CO_SEP_tag
{
    UINT8           codec_info[AVDT_CODEC_SIZE]; /* peer SEP configuration */
    UINT8           seid;       /* local stream endpoint id */
    UINT8           sep_idx;    /* sep idx */
} tBTA_AA_CO_SEP;

/* sink info of peer device */
typedef struct tBTA_AA_CO_SNK_tag
{
    BD_ADDR         addr; /* address of audio SNK */
    tBTA_AA_CO_SEP  sep[BTA_AA_CO_MAX_SEPS];
    UINT8           num_seps;   /* total number of SEPs supported at peer */
    UINT8           num_snk;    /* total number of snk at peer if mulitple SNKs are supported */
    UINT8           num_good;   /* total number of SEPs that we are interested in */
    UINT8           idx;    /* the index of sep[] to store info next */
    UINT8           use;    /* the index of sep[] used for streaming */
} tBTA_AA_CO_SNK;
#if 0
typedef struct tBTA_AA_CO_SNK_CB_tag {
    UINT8           curr_codec_info[AVDT_CODEC_SIZE]; /* current configuration for incoming connection */
    UINT8           sep_info_idx; /* sep_info_idx as reported/used in the bta_aa_co_getconfig */
    UINT8           snk_idx;
    UINT8           num_snk;
    UINT8           sep_info_idx_temp;
    tBTA_AA_CO_SNK  snk[BTA_AA_CO_MAX_SNKS];
} tBTA_AA_CO_SNK_CB;
#endif
typedef struct
{
    UINT8           codec_info[AVDT_CODEC_SIZE]; /* peer SEP configuration */
    UINT8           seid;
    UINT8           sep_idx;
} tBTA_AV_CO_SEP;

typedef struct
{
    BD_ADDR         addr; /* address of audio/video SNK */
    tBTA_AV_CO_SEP  sep[BTA_AV_CO_MAX_SEPS];
    UINT8           num_seps;   /* total number of seps at peer */
    UINT8           num_snk;    /* total number of snk at peer */
    UINT8           num_good;   /* total number of snk that we are interested. 0->not used */
    UINT8           idx;    /* the index of sep[] to store info next */
    UINT8           use;    /* the index of sep[] used for streaming */
    UINT8           cur;    /* sep counter */
    UINT8           index;  /* the index of snk[] */
} tBTA_AV_CO_SNK;

#if defined(BTA_AV_INCLUDED) && (BTA_AV_INCLUDED==TRUE)
/* returns pointer into new or existing buffer depending on audio codec */
typedef void *(* tBTA_AUDIO_GET_BUF)( BT_HDR **p, UINT16 frame_size, UINT32 timestamp );

/* in case that the SRC streams to multiple SNKs */
typedef struct
{
    UINT16              mtu;
    UINT8               curr_codec_info[AVDT_CODEC_SIZE];
    tBTA_AV_HNDL        hndl;
    BOOLEAN             need_recfg;
    UINT8               snk_idx;
    UINT8               sep_info_idx;
    UINT8               state;          /* keep track of init, in/out */
} tBTA_AV_CO_AI_CB;

typedef struct
{
    tBTA_AV_CO_SNK      snk[BTA_AV_CO_MAX_SNKS];/* for each SNK */
    tBTA_AV_CO_AI_CB    inst[BTA_AV_NUM_STRS];  /* for each open stream */
    UINT8               idx[BTA_AV_NUM_STRS];   /* index into inst[] */
    tA2D_SBC_CIE        open_cie;
    UINT8               curr_codec_info[AVDT_CODEC_SIZE];
    UINT32              timestamp;
    UINT16              use_mtu;
    UINT8               num_hndls;
    UINT8               num_stream; /* number of handles that are in BTA_AV_CO_ST_STREAM state */
} tBTA_AV_CO_AUDIO_CB;

extern tBTA_AV_CO_AUDIO_CB    bta_av_co_audio_cb;

/* structure for video streaming control block */
typedef struct
{
    UINT32              timestamp;
    BUFFER_Q            TxQ;
    UINT16              mtu;
    tBTA_AV_CODEC       codec_type;
    /* patch rl: */
    UINT32              tick_counter;
    UINT32              num_bufs;
    UINT32              max_bufs;
    /* patch end */
    tBTA_AV_CO_SNK      snk[BTA_AV_CO_MAX_SNKS];/* for each SNK */
    UINT8               curr_codec_info[AVDT_CODEC_SIZE];
    tBTA_AV_HNDL        hndl;
    UINT8               sep_info_idx;
    UINT8               snk_idx;
} tBTA_AV_CO_VIDEO_CB;

extern tBTA_AV_CO_VIDEO_CB    bta_av_co_video_cb;

extern BOOLEAN bta_av_video_set_pref_codec( tBTA_AV_VIDEO_CFG *p_video_cfg );
extern BOOLEAN bta_av_audio_set_pref_codec( tBTA_AV_CODEC codec_type, UINT8 num_chan, UINT32 samp_freq );
extern UINT8 *bta_av_video_set_cur_codec_info( tBTA_AV_CODEC codec_type, UINT8 *p_seid,
                                               UINT8 *p_sep_info_idx );
extern int bta_av_video_get_seps( tBTA_AV_CO_SEP **p_sep );
#endif

/* configuration structure passed to bta_sbc_codec_open */
typedef struct tBTA_SBC_USER_CFG_tag {
    tBTA_SBC_READ_CBACK    *p_cback;        /* call back for reading PCM data */
    UINT16                  bit_rate;       /* SBC encoder bit rate in kbps */
    UINT16                  bytes_per_fr;   /* this is only result return by bta_aa_codec_get_info */
    UINT16                  num_channels; /* 0: mono (=1 channel) 1: stereo (2 channels)*/
    UINT8                   channel_mode;   /* channel mode. see a2d_sbc.h */
} tBTA_SBC_USER_CFG;


typedef struct
{
    tBTA_AV_CODEC       codec_type;             /* current choosen codec type */
    UINT8           	sbc_seps; /* sbc /mp3 selection -> default sbc seps */
    UINT8           	m12_sep; 
    UINT8           	m24_sep; 
    UINT8           	current_sep;
    UINT8           	num_seps; /* sbc /mp3 selection -> total number of seps */
    UINT8		CurrCodecInfo[AVDT_CODEC_SIZE]; /* Current codec info */
    UINT8               RemSbcCodecInfo[AVDT_CODEC_SIZE]; /* remote sbc codec capabilities */
    UINT8               RemM12CodecInfo[AVDT_CODEC_SIZE]; /* remote mp3 codec capabilities */
    tBTA_SBC_USER_CFG   sbc_usr_cfg;            /* user confg set with  bta_aa_codec_init */
} tBTA_CODEC_CB;


typedef struct tBTA_SBC_CB_tag {
    tCODEC_ENCODER       *codec_encoder;
    UINT32                timestamp;    /* time stamp used in AV transmit leave at the 
                                                   beggining for performance! */
    UINT32                TimerCounter;
    SBC_ENC_PARAMS        encoder;                /* SBC encoder control block */
    BUFFER_Q              out_q;                  /* output packet GKI queue */
    BUFFER_Q              pcm_q;                /* this is PCM GKI input buffer queue! */
    UINT16                mtu;
    UINT8                 avdt_handle;            /* to avoid context switching store handle */
    tBTA_SBC_READ_CBACK  *p_cback;                /* data read callback */
    UINT16                bytes_per_fr;           /* pcm bytes per SBC frame encode */
    UINT16                num_channels;       /* 0: mono 1:stereo (num of channels -1)  */
    UINT16                fr_per_pkt;             /* SBC frames per packet */
    UINT8                 channel_mode;   /* CHOOSEN channel mode */
    tBTA_CODEC_CB         codec_cb;     /* generic control block used by bta and UIF */
} tBTA_SBC_CB;


extern tA2D_SBC_CIE bta_aa_co_sbc_pref;
extern tBTA_SBC_CB bta_sbc_codec_cb;
//extern const tA2D_M24_CIE bta_av_co_m24_cap;
extern const tBTA_AV_VIDEO_CFG bta_av_co_h263_cap;
extern const tBTA_AV_VIDEO_CFG bta_av_co_mpeg4_cap;

/* sink codec info */
//extern tBTA_AA_CO_SNK_CB bta_aa_co_snk_cb;

/* returns the current (to use) sep_info_idx and codec_info corresponding to this sep_info_idx */
/* 0xff indicates error */
extern UINT8 bta_aa_co_current_sep( UINT8 **pp_current_codec_info );
extern UINT8 bta_aa_co_current_protect( UINT8 **pp_current_protect );

#if 0 //(BTA_AA_INCLUDED==TRUE)
/* stores SEP info for a SNK (bd_addr). on last call bLast needs to be set to TRUE
   it returns negative values if it failed to store sep successfully. otherwise 0. */
extern int bta_aa_co_update_sep_info( const BD_ADDR bd_addr, const tBTA_AA_CO_SEP *p_sep, BOOLEAN bLast );
/* returns the SEP pointed by p_sep for a given SNK (bd_addr). result: 0 no sep for given bd_addr. 
   the first call give the total number of SEPs. afterwards it counts down to 0. bFirst starts
   process. needs to be set only the first time. this should only be called after OPEN event */
extern int bta_aa_co_retrieve_sep_info( const BD_ADDR bd_addr, tBTA_AA_CO_SEP *p_sep, BOOLEAN bFirst );
/* returns current user config. if result >0 data valid */
extern int bta_aa_co_codec_get_info( tBTA_AA_CODEC codec_type, void * cfg );
extern int bta_aa_co_codec_write( tBTA_AA_CODEC codec_type, void * p_buf , UINT16 num );
#else
/* stores SEP info for a SNK (bd_addr). on last call bLast needs to be set to TRUE
   it returns negative values if it failed to store sep successfully. otherwise 0. */
extern int bta_aa_co_update_sep_info( const BD_ADDR bd_addr, const tBTA_AV_CO_SEP *p_sep, BOOLEAN bLast );
/* returns the SEP pointed by p_sep for a given SNK (bd_addr). result: 0 no sep for given bd_addr. 
   the first call give the total number of SEPs. afterwards it counts down to 0. bFirst starts
   process. needs to be set only the first time. this should only be called after OPEN event */
extern int bta_aa_co_retrieve_sep_info( const BD_ADDR bd_addr, tBTA_AV_CO_SEP *p_sep, BOOLEAN bFirst );
/* returns current user config. if result >0 data valid */
extern int bta_aa_co_codec_get_info( tBTA_AV_CODEC codec_type, void * cfg );
extern int bta_aa_co_codec_write( tBTA_AV_CODEC codec_type, void * p_buf , UINT16 num );
#endif

/* call this before calling BTA_AaStart(). selects codec to use. */
extern void bta_aa_co_sbc_codec_init( UINT8 *p_codec_info, UINT16 mtu  );
extern int bta_aa_co_codec_init( tBTA_AV_CODEC codec_type, void * cfg , UINT8 *p_codec_info );
/* AV sbc codec derived from p_codec_info */
extern UINT8 bta_aa_co_get_sbc_codec_config( UINT8 *p_codec_info);
/* patch */
extern int bta_aa_co_sbc_is_adjusting_timer( UINT32 *TimerCounter);


#endif  /* _BTA_CODEC_H_ */
