/******************************************************************************
**
**  File Name:   $RCSfile: sbc_types.h,v $
**
**  Description: Data type declarations.
**
**  Revision :   $Id: sbc_types.h,v 1.7 2006/07/27 12:03:21 mjougit Exp $
**
**  Copyright (c) 1999-2002, Widcomm Inc., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
**
******************************************************************************/

#ifndef SBC_TYPES_H
#define SBC_TYPES_H

#include "data_types.h"

typedef short SINT16;
typedef long SINT32;

#if (SBC_IPAQ_OPT == TRUE)
typedef __int64 SINT64;
#elif (SBC_IS_64_MULT_IN_WINDOW_ACCU == TRUE) || (SBC_IS_64_MULT_IN_IDCT == TRUE)
typedef __int64 SINT64;
#endif

#define abs32(x) ( (x >= 0) ? x : (-x) )


#endif
