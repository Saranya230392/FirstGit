/*****************************************************************************
**                                                                           
**  Name:          hcilp.h
**                                                                           
**  Description:
**      This file contains definitions and function prototypes for the.
**      HCI low power mode module.
**                                                                           
**  Copyright (c) 2002-2004, WIDCOMM Inc., All Rights Reserved.             
**  WIDCOMM Bluetooth Core. Proprietary and confidential.                    
******************************************************************************/
#ifndef HCILP_H
#define HCILP_H


/*******************************************************************************
**
** Function           HCILP_Enable
**
** Description        Enables Sleep mode.
**
** Output Parameter   None
**
** Returns            TRUE  if sleep mode command was issued to BT device
**                    FALSE if the feature is not supported
**
*******************************************************************************/
BOOLEAN HCILP_Enable(BOOLEAN);

/*******************************************************************************
**
** Function           HCILP_IsSleepState
**
** Description        Checks if its ok for application to go to sleep mode
**
** Output Parameter   None
**
** Returns            TRUE  if bluetooth is OK for app to go to sleep mode
**                    FALSE if bluetooth is awake and cannot go to sleep mode
**
*******************************************************************************/
BOOLEAN HCILP_IsSleepState(void);


/*******************************************************************************
**
** Function           HCILP_AppSleeping
**
** Description        Called by application when it wants to indicate to bluetooth
**                    that it is going into low power mode
**
** Output Parameter   None
**
**
*******************************************************************************/
void HCILP_AppSleeping(void);

/*******************************************************************************
**
** Function           HCILP_WakeupBTDevice
**
** Description        Called to wake up Bluetooth chip. This is called by HCIS
**                    when there is data to be sent over UART
**
** Output Parameter   None
**
**
*******************************************************************************/
void HCILP_WakeupBTDevice(void);


/*******************************************************************************
**
** Function           HCILP_AllowBTDeviceSleep
**
** Description        Called to indicate to bluetooth chip that it can go to
**                    sleep mode.This is called by HCIS when all data has been
**                    read from UART
**
** Output Parameter   None
**
**
*******************************************************************************/
void HCILP_AllowBTDeviceSleep(void);

/*******************************************************************************
 **
 ** Function           HCILP_Pause
 **
 ** Description        
 **
 ** Output Parameter   Service mask : service bit filed that indicate the service that req the pause
 **                              
 **
 ** Returns        none
 **
 *******************************************************************************/
void HCILP_Pause(UINT32);

/*******************************************************************************
 **
 ** Function           HCILP_Resume
 **
 ** Description        
 **
 ** Output Parameter   Service mask : service bit filed that indicate the service that release the pause
 **                              
 **
 ** Returns        none
 **
 *******************************************************************************/
void HCILP_Resume(UINT32);

#endif
