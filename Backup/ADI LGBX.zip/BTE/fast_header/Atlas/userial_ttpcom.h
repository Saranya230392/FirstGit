/*******************************************************************************
**  Name:       userial_adi.h
**
**  Description:
**
**  This file contains serial definitions from WIDCOMM's Universal Embedded 
**  Drivers API.
**
**  Copyright (c) 2001-2004, WIDCOMM Inc., All Rights Reserved.
**  WIDCOMM Bluetooth Core. Proprietary and confidential.
*******************************************************************************/
#ifndef BUILDCFG
#define BUILDCFG
#endif

#include "target.h"
#include "userial.h"

/***************************************************************************
** External Global Variables
***************************************************************************/

extern volatile BOOLEAN gIsSending;
extern tUSERIAL_CBACK *gUartCallback;

/*******************************************************************************
** Platform Specific Function Prototypes 
*******************************************************************************/
extern void USERIAL_CheckTxData(void);

