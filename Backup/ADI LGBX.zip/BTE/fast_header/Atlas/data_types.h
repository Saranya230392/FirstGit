/****************************************************************************
**
**  Name        data_types.h
**  $Header: /mobileports/CVSROOT/widcomm/components/gki/adi_lge/data_types.h,v 1.2 2006/08/10 08:47:11 cporcel Exp $
**
**  Function    this file contains common data type definitions used
**              throughout the Widcomm Bluetooth code
**
**  Date       Modification
**  -----------------------
**  3/12/99    Create
**	07/27/00	Added nettohs macro for Little Endian
**                                                                         
**  Copyright (c) 1999- 2002, Widcomm Inc., All Rights Reserved.
**  Proprietary and confidential.
**
*****************************************************************************/

#ifndef DATA_TYPES_H
#define DATA_TYPES_H

#ifndef NULL
#define NULL     0
#endif

#ifndef FALSE
#define FALSE  0
#endif


#ifndef UINT8
typedef unsigned char   UINT8;
#endif
#ifndef UINT16
typedef unsigned short  UINT16;
#endif
#ifndef UINT32
typedef unsigned long   UINT32;
#endif
#ifndef INT32
typedef signed   long   INT32;
#endif
#ifndef INT8
typedef signed   char   INT8;
#endif
#ifndef INT16
typedef signed   short  INT16;
#endif
#ifndef BOOLEAN
typedef unsigned char BOOLEAN;
#endif

typedef UINT32          TIME_STAMP;

#ifndef TRUE
#define TRUE   (!FALSE)
#endif

#ifndef UBYTE
typedef unsigned char   UBYTE;
#endif

#ifdef __arm
#define PACKED  __packed
#define INLINE  __inline
#else
#define PACKED
#define INLINE
#endif

#define BIG_ENDIAN FALSE

#define UINT16_LOW_BYTE(x)      ((x) & 0xff)
#define UINT16_HI_BYTE(x)       ((x) >> 8)

#endif
