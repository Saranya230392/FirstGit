
#ifndef __BTAPP_H__
#define  __BTAPP_H__


/* please avoid to modifying the order of include files declarations */
#include "target.h"

#include "bt_types.h"
#include "bta_api.h"
#include "bta_sys.h"
#include "bta_dm_int.h"

/* BTAPP DM control block */
typedef struct
{
    BD_ADDR            peer_device_bdaddr;      /* peer bdaddr stored for pin_reply etc*/
    char               peer_device_name[BTA_DM_REMOTE_DEVICE_NAME_LENGTH+1];
    tBTA_SERVICE_ID    peer_device_services;
    tBTA_SERVICE_MASK  searched_services;    /* services to search for */
    BOOLEAN inq_only;
}
tBTAPP_DM_CB;

extern tBTAPP_DM_CB btapp_dm_cb;

/*******************************************************************************
 $Function:      btapp_dm_enable
 $Description:   enable bluetooth
 $Returns:	
 $Arguments:
*******************************************************************************/
void btapp_dm_enable(void );

/*******************************************************************************
 $Function:      btapp_dm_set_visibility
 $Description:   set visibility of local BT device
 $Returns:
 $Arguments:     is_visible: new visibility setting
*******************************************************************************/
void btapp_dm_set_visibility( BOOLEAN is_visible, BOOLEAN is_connectable);

/*******************************************************************************
 $Function:     btapp_dm_set_local_name
 $Description:  set local BT device name
 $Returns:
 $Arguments:    new name. Pointer to a string. This string is copied locally. Buffer is not freed.
*******************************************************************************/
void btapp_dm_set_local_name( char *name );

/*******************************************************************************
 $Function:     btapp_dm_pin_code_reply
 $Description:  used by BMI to send back a pin code
 $Returns:
 $Arguments:    pin code and pin code length. This data is copied.
*******************************************************************************/
void btapp_dm_pin_code_reply(UINT8* pin_code, UINT8 pin_len);

/*******************************************************************************
 $Function:       btapp_dm_bond
 $Description:    used by BMI to send a pin code in order to establish a bonding with a remote device.
 $Returns:
 $Arguments:      BD_ADDR of the remote device, pin code and pin code length. Data is copied.
*******************************************************************************/
void btapp_dm_bond(BD_ADDR bd_addr, UINT8* pin_code, UINT8 pin_len );

/*******************************************************************************
 $Function:      btapp_dm_authorize_resp
 $Description:   used to answer to an authorization request
 $Returns:
 $Arguments:     BTA_DM_NOT_AUTH to refuse, 
                 BTA_DM_AUTH_TEMP to grant access temporarily,
                 BTA_DM_AUTH_PERM to grant permanent access
*******************************************************************************/
void btapp_dm_authorize_resp( tBTA_AUTH_RESP auth);

/*******************************************************************************
 $Function:      btapp_dm_delete_device
 $Description:   remove a device from the local DB
 $Returns:
 $Arguments:     BD address
*******************************************************************************/
void btapp_dm_delete_device(BD_ADDR bd_addr);

/*******************************************************************************
**
** Function        btapp_dm_add_device
**
** Description    This will store permanently a device in Flash.
** Parameters     new BD address , link_key, trusted_services
** Returns
**
*******************************************************************************/
void btapp_dm_add_device(BD_ADDR bd_addr, LINK_KEY link_key, tBTA_SERVICE_MASK trusted_services, BOOLEAN link_key_present);

/*******************************************************************************
 $Function:       btapp_dm_discover_device
 $Description:    Discovers services on a new device
 $Returns:
 $Arguments:      bd address of the remote device to discover
*******************************************************************************/
void btapp_dm_discover_device(BD_ADDR bd_addr);

/*******************************************************************************
 $Function:       btapp_dm_cancel_search
 $Description:    cancel an ongoing search
 $Returns:
 $Arguments:
*******************************************************************************/
void btapp_dm_cancel_search( void );

/*******************************************************************************
 $Function:      btapp_dm_search
 $Description:   Searches for devices supporting the services specified. If services = 0, will 
                 return all the found devices regardless of their functionalities.
 $Returns:
 $Arguments:     services. bd_addr
*******************************************************************************/
void btapp_dm_search(tBTA_SERVICE_MASK services, BD_ADDR bd_addr);
#endif


