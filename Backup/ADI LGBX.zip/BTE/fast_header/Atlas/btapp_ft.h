/*****************************************************************************
**
**  Name:           btapp_ft.h
**
**  Description:    This module contains the functions for Bluetooth FT Profile
**
**
**  Copyright (c) 2005, Wifdcomm Inc., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/
#ifndef DEF_BTUI_FT_HEADER
#define DEF_BTUI_FT_HEADER

#include "bta_ft_api.h"
#include "btui.h"

/*
** The following Macros define the File Transfer Signals (BT -> Mfw)
*/
#define T_BTUI_FTC_EVT				tBTA_FTC_EVT
#define T_BTUI_FTC_SIG_DATA		tBTA_FTC

#define T_BTUI_FTS_EVT				tBTA_FTS_EVT
#define T_BTUI_FTS_SIG_DATA		tBTA_FTS

/*******************************************************************************
 **
 ** Function         btapp_ftc_get_state
 **
 ** Description    
 **
 **
 ** Returns          void
 *******************************************************************************/
UINT8 btapp_ftc_get_state(void);

/*******************************************************************************
**
** Function         btapp_ftc_is_enabled
**
** Description    Check if the FTC profile is enabled or not.
**                  
**
** Returns          TRUE is Ft profile is enabled, FALSE otherwise
**
*******************************************************************************/
BOOLEAN btapp_ftc_is_enabled(void);

/*******************************************************************************
 **
 ** Function         btapp_ft_enable
 **
 ** Description      Enable both FTP client and FTP server
 **
 ** Returns          void
 **
 *******************************************************************************/
void btapp_ft_enable(void);

/*******************************************************************************
 **
 ** Function         btapp_ft_enable
 **
 ** Description     Disable FT client and server
 **
 **
 ** Returns          void
 *******************************************************************************/
void btapp_ft_disable(void );

/*******************************************************************************
 **
 ** Function         btapp_ftc_connect
 **
 ** Description     Open client connection for FTP 
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
void btapp_ftc_connect(tBTUI_REM_DEVICE *p_device);

/*******************************************************************************
 **
 ** Function         btui_ftc_close
 **
 ** Description      Close FTC connection
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
BOOLEAN btapp_ftc_close(void);

/*******************************************************************************
 **
 ** Function         btapp_ftc_change_dir
 **
 ** Description      Change directory
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
void btapp_ftc_change_dir(char *p_dir);

/*******************************************************************************
 **
 ** Function         btapp_ftc_get_file
 **
 ** Description      Get file
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
BOOLEAN btapp_ftc_get_file(char *p_getfile, char *p_remotefile);

/*******************************************************************************
 **
 ** Function         btapp_ftc_put_file
 **
 ** Description      Put file
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
BOOLEAN btapp_ftc_put_file(tBTUI_REM_DEVICE* p_device, char *p_putfile);

/*******************************************************************************
 **
 ** Function         btapp_ftc_abort_transfer
 **
 ** Description      
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
void btapp_ftc_abort_transfer(void);

UINT8 btapp_ftc_copy_list_2_mmi_buf(UINT8 ** file_list, UINT8* file_type);

/*******************************************************************************
 **
 ** Function         btapp_ftc_send_disconnect_ind
 **
 ** Description      this function is called after link loss, to be sure everything is ok.
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
void btapp_ftc_send_disconnect_ind(BD_ADDR bd_addr);

/*******************************************************************************
 **
 ** Function         btapp_ftc_create_dir
 **
 ** Description     
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
void btapp_ftc_create_dir(char* full_path);
/*******************************************************************************
 **
 ** Function         btapp_ftc_list_dir
 **
 ** Description      
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
void btapp_ftc_list_dir(char* p_dir );


/*******************************************************************************
 **
 ** Function         btapp_ftc_delete_object
 **
 ** Description     
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
void btapp_ftc_delete_object(char* full_path);

/*******************************************************************************
**
** Function         btapp_ft_set_security_mask
**
** Description
**
** Returns          void
**
******************************************************************************/
void btapp_ft_set_security_mask(tBTA_SEC sec_mask);

#endif


