/*****************************************************************************
**
**  Name:           btapp_aa.h
**
**  Description:    This module contains the functions for Bluetooth Object Push Profile
**
**
**  Copyright (c) 2005, Wifdcomm Inc., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/

#ifndef BTAPP_AA_H
#define BTAPP_AA_H

/*typedef struct tBTAPP_AA_PCM_BUF
{
	UINT32              len;
	UINT32              offset;
	UINT16             pBuff[500];
} tBTAPP_AA_PCM_BUF;*/
typedef struct tBTAPP_AA_PCM_HDR_TAG
{
    UINT8   index;
    UINT32 len;
    UINT32 offset;
    UINT16  *pBuff;
} tBTAPP_AA_PCM_HDR;

#define BTA_AA_BUFFER_REQ      20

/* Number  of PCM buffer filled by MP3 to WAV codec */
#ifndef BTA_AA_CODEC_MAX_PCM_BUF
#define BTA_AA_CODEC_MAX_PCM_BUF 3
#endif

/* size of PCM buffer filled by MP3 to WAV codec */
#ifndef BTA_AA_CODEC_SIZE_PCM_BUF
#define BTA_AA_CODEC_SIZE_PCM_BUF (32*1024)       /* allocate 64k (bytes) per buffer =32 *UINT16*1024 */
#endif

/*******************************************************************************
**
** Function         btapp_aa_is_enabled
**
** Description
**
** Returns          void
*******************************************************************************/
BOOLEAN btapp_aa_is_enabled(void);

/*******************************************************************************
**
** Function         btapp_aa_is_streaming
**
** Description
**
** Returns          void
*******************************************************************************/
BOOLEAN btapp_aa_is_streaming(void);

/*******************************************************************************
**
** Function         btapp_aa_enable
**
** Description      Initializes BTUI AA and BTA AA
**
** Returns          void
*******************************************************************************/
void btapp_aa_enable(void);

/*******************************************************************************
 **
 ** Function         btapp_aa_disable
 **
 ** Description      Disables Advanced Audio module
 **
 ** Returns          void
 *******************************************************************************/
void btapp_aa_disable(void);

/*******************************************************************************
**
** Function         btapp_aa_open
**
** Description
**
** Returns          void
*******************************************************************************/
void btapp_aa_open(void);

/*******************************************************************************
**
** Function         btapp_aa_connect
**
** Description
**
** Returns          void
*******************************************************************************/
void btapp_aa_connect(BD_ADDR bd_addr, char * devname);

/*******************************************************************************
**
** Function         btapp_aa_disconnect
**
** Description      Connects to the audio gateway
**
** Returns          void
*******************************************************************************/
void btapp_aa_disconnect(void);

/*******************************************************************************
**
** Function         btapp_aa_start
**
** Description      start the streaming
**                       give the Sampling_freq and channel_mode of the pcm data.
**
** Returns          void
*******************************************************************************/
void btapp_aa_start( UINT16 S_freq, UINT16 chan_mode);

/*******************************************************************************
**
** Function         btapp_aa_stop
**
** Description      start the streaming
**                      isAgCall , the streaming was stoped by an incoming call.
**
** Returns          void
*******************************************************************************/
void btapp_aa_stop(BOOLEAN isAgCall);

/*******************************************************************************
**
** Function         btui_aa_reconfig
**
** Description      initiate a reconfig. 
**
** Returns          void
*******************************************************************************/
void btapp_aa_reconfig(void);

/*******************************************************************************
**
** Function         btapp_aa_play_pause
**
** Description      Stop or start streaming by starting or stoping timer.
**
** Returns          void
*******************************************************************************/
void btapp_aa_play_pause(void);

/*******************************************************************************
**
** Function         btapp_aa_get_pcm_buf
**
** Description      
**
** Returns          void
*******************************************************************************/
void * btapp_aa_get_pcm_buf(void );

/*******************************************************************************
**
** Function         btapp_aa_free_pcm_buf
**
** Description    
**
** Returns          void
*******************************************************************************/
void btapp_aa_free_pcm_buf(   tBTAPP_AA_PCM_HDR            *pPcmHdr);

/*******************************************************************************
**
** Function         btapp_aa_enqueue_pcm_buf
**
** Description    
**
** Returns          void
*******************************************************************************/
void btapp_aa_enqueue_pcm_buf(void * p_buf);

#endif
