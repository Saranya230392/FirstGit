/*****************************************************************************
**
**  Name:           bta_rds_api.h
**
**  Description:    This is the public interface file for the RDS decoder.
**                  
**  Copyright (c) 2006, Broadcom Corp., All Rights Reserved.
**  Broadcom Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/
#ifndef BTA_RDS_API_H
#define BTA_RDS_API_H

#include "bta_api.h"
#include "bta_fm_api.h"
/*****************************************************************************
**  Constants and data types
*****************************************************************************/

#ifndef BTA_RDS_DEBUG
#define BTA_RDS_DEBUG    TRUE
#endif

/* Maxinum number of different RDS streams supported by the decoder */
#ifndef BTA_RDS_MAX_STREAM
#define BTA_RDS_MAX_STREAM      1
#endif

/* RDS Decoder structure */
#define BTA_RDS_PI_BIT           (1<<0)
#define BTA_RDS_AF_BIT           (1<<1)
#define BTA_RDS_PS_BIT           (1<<2)
#define BTA_RDS_PTY_BIT          (1<<3)
#define BTA_RDS_TP_BIT           (1<<4)
#define BTA_RDS_PTYN_BIT         (1<<5)
#define BTA_RDS_RT_BIT           (1<<6)
#define BTA_RDS_DI_BIT           (1<<7)
#define BTA_RDS_PIN_BIT          (1<<8)
#define BTA_RDS_CT_BIT           (1<<9)
#define BTA_RDS_MS_BIT           (1 <<10)
#define BTA_RDS_ODA_BIT          (1 <<11)
#define BTA_RDS_TDC_BIT          (1 <<12)
#define BTA_RDS_EWS_BIT          (1 << 13)
#define BTA_RDS_SLC_BIT          (1 << 14)

typedef UINT32  tBTA_RDS_FEATURE; 



/* RDS decoder event */
enum
{
    BTA_RDS_REG_EVT,        /* RDS decoder user register event*/
    BTA_RDS_PI_EVT,         /* PI code */
    BTA_RDS_AF_EVT,         /* Alternative Frequency */
    BTA_RDS_PS_EVT,         /* Program service name */
    BTA_RDS_TP_EVT,         /* traffic program identification */
    BTA_RDS_PTY_EVT,        /* program type */
    BTA_RDS_PTYN_EVT,       /* program type name */
    BTA_RDS_RT_EVT,         /* Radio Text */
    BTA_RDS_DI_EVT,         /* Decoder Identification */
    BTA_RDS_PIN_EVT,        /* program Item number */
    BTA_RDS_CT_EVT,         /* clock time */
    BTA_RDS_MS_EVT,         /* music speech content */
    BTA_RDS_ODA_EVT,        /* open data application */
    BTA_RDS_TDC_EVT,        /* transparent data channel */
    BTA_RDS_EWS_EVT,        /* emergency warning system */
    BTA_RDS_SLC_EVT,         /* slow labelling code */
    BTA_RDS_RPTOR_EVT,      /* chracter repertoire set */
    BTA_RDS_STATS_EVT
};
typedef UINT32   tBTA_RDS_EVT;

/* RDS mode */
enum
{
    BTA_FM_RDS,
    BTA_FM_RBDS
};
typedef UINT8 tBTA_FM_RDS_B;

/* RDS status code */
enum
{
    BTA_RDS_OK,
    BTA_RDS_ERR,            /* general error */
    BTA_RDS_ERR_DAT,        /* error RDS data */
    BTA_RDS_ERR_INTL,       /* internal error */
    BTA_RDS_ERR_BAD_AID     /* bad application ID error */
};
typedef UINT8 tBTA_RDS_STATUS;


/* CT data */
typedef struct
{
    UINT32  day;
    UINT8   hour;
    UINT8   minute;
    UINT8   sense;
    UINT8   offset;
} tBTA_RDS_CT;

/* PIN data */
typedef struct
{
    UINT8   day;
    UINT8   hour;
    UINT8   minute;
} tBTA_RDS_PIN;

/* music speech content type */
enum
{
    BTA_RDS_SPEECH,
    BTA_RDS_MUSIC
};
typedef UINT8 tBTA_RDS_M_S;

/* transprant data channell structure */
typedef struct
{
    UINT8       chnl_num;   /* channel number */
    UINT8       len;        /* data length */
    UINT8       tdc_seg[4]; /* TDC data, max to 4 bytes */

}tBTA_RDS_TDC_DATA;

/* segment data type, used for EWS, and ODA */
typedef struct
{
    UINT8               data_5b;        /* the 5 bits data carried in 2nd block */
    UINT16              data_16b_1;     /* 16 bits data carried in block 3 if group type A */
    UINT16              data_16b_2;     /* 16 bits data carried in block 4 */
} tBTA_RDS_SEG_DATA;

/* ODA */
typedef struct
{
    UINT16              aid;        /* ODA application ID */
    UINT8               grp_type;   /* group type which is carrying this AID */ 
    tBTA_RDS_SEG_DATA   data;       /* real ODA data */

}tBTA_RDS_ODA_DATA;

/* slow labelling code type */
enum
{
    BTA_RDS_SLC_ECC,            /* enhanced country code */
    BTA_RDS_SLC_TMC,
    BTA_RDS_SLC_PID,
    BTA_RDS_SLC_LAG,
    BTA_RDS_SLC_UNASSIGNED,
    BTA_RDS_SLC_BRCST,
    BTA_RDS_SLC_EWS
};
typedef UINT8   tBTA_RDS_SLC_TYPE;

typedef struct 
{
    UINT8           paging;
    UINT8           ecc_code;
}tBTA_RDS_ECC;  /* ECC code */
/* Slow labelling Code data */
typedef union 
{
    tBTA_RDS_ECC        ecc;            /* ECC code */
    UINT16              language;       /* language code */
    UINT16              tmc_id;         /* TMC ID */
    UINT16              paging_id;      /* paging ID */
    UINT16              ews_channel;    /* EWS channel ID */
    UINT16              other;           /* broadcaster data */
}  tBTA_RDS_SLC ;

/* Slow labelling Code call back data*/
typedef struct
{
    tBTA_RDS_SLC_TYPE   slc_type;
    tBTA_RDS_SLC        data;

}tBTA_RDS_SLC_DATA;


enum
{
    BTA_RDS_RPTOR_SI,
    BTA_RDS_RPTOR_SO,
    BTA_RDS_RPTOR_LS2,
    BTA_RDS_RPTOR_UNKNOW
};
typedef UINT8 tBTA_RDS_RPTOR_SET;  

/* RDS callback data */
typedef union
{
    tBTA_RDS_CT         ct;             /* Clock time */
    tBTA_RDS_PIN        pin;            /* Program Item Number */
    tBTA_RDS_STATUS     status;         /* status */
    tBTA_FM_AF_LIST     af_data;        /* AF */
    UINT16               pi_code;       /* PI code */
    UINT8                data8;         /* UINT8 data, used for TP_TA, DI callback */
    UINT8               *p_data;        /* data pointer to UINT8, used for RT, PS, PTY, PTYN */
    tBTA_RDS_RPTOR_SET  rptor_set;
    tBTA_RDS_M_S        m_s;            /* music speech feature */
    tBTA_RDS_ODA_DATA   oda;            /* Open data application data */
    tBTA_RDS_TDC_DATA   tdc_data;       /* transparent data channel data */
    tBTA_RDS_SEG_DATA   seg_data;       /* EWS data */
    tBTA_RDS_SLC_DATA   slc;            /* slow labelling codes */
    UINT32              stats[4];       /* statistics data */
} tBTA_FM_RDS;

typedef void (tBTA_RDS_CBACK)(tBTA_RDS_EVT event, tBTA_FM_RDS *p_data, UINT8 app_id);
/*****************************************************************************
**  External Function Declarations
*****************************************************************************/
#ifdef __cplusplus
extern "C"
{
#endif
/*******************************************************************************
**
** Function         BTA_FmRDSInitDecoder
**
** Description      This funtion initialize the RDS group decoder by resetting
**                  default values to the RDS parser control block.
**
** Returns          void
**
*******************************************************************************/
BTA_API extern void BTA_FmRDSInitDecoder(void);
/*******************************************************************************
**
** Function         BTA_FmRDSRegister
**
** Description      This funtion register the user callback and app ID with RDS 
**                  decoder, together with the RDS feature mask they are interested 
**                  in. Use the function, a client:
**
**                  I.   can be registered at RDS decoder,
**                  II.  deregister at decoder by sending the same app_id with a NULL
**                       call back function; or 
**                  III. re-register the call back with different RDS feature mask.
**                  
**
** Parameter        rds_mask: RDS feature this client interested in
**                  p_cback: call back function of the client
**                  app_id: application ID associate with this client, it must be a 
**                           NONE-ZERO number.
**
** Returns          void
**
*******************************************************************************/
BTA_API extern tBTA_RDS_STATUS BTA_FmRDSRegister(tBTA_FM_RDS_B mode, tBTA_RDS_FEATURE rds_mask, 
                                      tBTA_RDS_CBACK *p_cback, UINT8 app_id);

/*******************************************************************************
**
** Function         BTA_FmRDSResetDecoder
**
** Description      Reset RDS decoder decoding control variable for a new parsing. 
**                  Usually this function is called when jumping to a new frequency,
**                  and all the old RDS information should be erased. 
**
** Returns          app_id: application ID associate with a RDS stream, it must be a 
**                           NONE-ZERO positive number.
**
*******************************************************************************/
BTA_API extern tBTA_RDS_STATUS BTA_FmRDSResetDecoder(UINT8 app_id);
/*******************************************************************************
**
** Function         BTA_FmRDSDecode
**
** Description      Parse the rds group 
**
** Parameter        p_data : input rds data in multiple tuples, which means it's
**                           always 3n bytes.
**                  len    : the total length of p_data.
**s
**                  app_id: application ID associate with a RDS stream, it must be a 
**                           NONE-ZERO positive number.
** Returns          void
**
*******************************************************************************/
BTA_API extern tBTA_RDS_STATUS BTA_FmRDSDecode(UINT8 app_id, UINT8 *p_data, UINT16 length);


#ifdef __cplusplus
}
#endif

#endif /* BTA_RDS_API_H */

