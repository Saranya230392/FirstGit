/*****************************************************************************
**
**  Name:           btapp_op.h
**
**  Description:    This module contains the functions for Bluetooth Object Push Profile
**
**
**  Copyright (c) 2005, Wifdcomm Inc., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
**
*****************************************************************************/
#ifndef DEF_BTUI_OP_HEADER
#define DEF_BTUI_OP_HEADER

#include "bta_op_api.h"


#define BTUI_FILE_SIZE 70000
#define FS_MAX_FILES 7
/*
** Bluetooth Object Push Profile Prototypes
*/

/*******************************************************************************
 **
 ** Function         btapp_op_enable
 **
 ** Description      Enable object push profile (server and client)
 **
 ** Returns          void
 *******************************************************************************/
void btapp_op_enable(void);

/*******************************************************************************
 **
 ** Function         btapp_op_disable
 **
 ** Description      Disable opject push
 **
 ** Returns          void
 *******************************************************************************/
void btapp_op_disable(void);

/*******************************************************************************
 **
 ** Function         btapp_opc_is_enabled
 **
 ** Description     return the state of Object push client (enabled or not)
 **
 ** Returns          void
 *******************************************************************************/
BOOLEAN btapp_opc_is_enabled(void);


/*******************************************************************************
 **
 ** Function         btapp_op_pull_card
 **
 ** Description      Fetch vcard card from remote device
 **
 ** Returns          void
 *******************************************************************************/
void btapp_op_pull_card(BD_ADDR bdaddr);

/*******************************************************************************
 **
 ** Function         btapp_op_exch_card
 **
 ** Description      Initiates card exchange
 **
 ** Returns          void
 *******************************************************************************/
void btapp_op_exch_card(BD_ADDR bdaddr);

/*******************************************************************************
 **
 ** Function         btapp_opc_send_file
 **
 ** Description      Sends the file 
 **
 ** Returns          void
 *******************************************************************************/
BOOLEAN btapp_opc_send_file (BD_ADDR bd_addr, char* p_name);

/*******************************************************************************
 **
 ** Function         btapp_ops_disconnect
 **
 ** Description      Closes active obex server connection, if any.
 **
 ** Returns          void
 *******************************************************************************/
void btapp_ops_disconnect(void);

/*******************************************************************************
 **
 ** Function         btapp_opc_disconnect
 **
 ** Description      Closes active obex connection, if any.
 **
 ** Returns          void
 *******************************************************************************/
void btapp_opc_disconnect(void);

/*******************************************************************************
 **
 ** Function         btapp_op_pull_card
 **
 ** Description      initiate a pull card and give the path where we want to receive the card
 **
 ** Returns          void
 *******************************************************************************/
void btapp_opc_pull_card(BD_ADDR bd_addr, char * p_rcv_path);

/*******************************************************************************
 **
 ** Function         btapp_opc_exch_card
 **
 ** Description      Initiates card exchange
 **
 ** Returns          void
 *******************************************************************************/
void btapp_opc_exch_card(BD_ADDR bd_addr, char * p_send, char * p_rcv_path);

/*******************************************************************************
 **
 ** Function         btapp_opc_abort_push
 **
 ** Description    Abort the current push operation
 **
 ** Returns          void
 *******************************************************************************/
void btapp_opc_abort_push(void);


void btapp_ops_set_access(BOOLEAN allow);
void btapp_ops_access_rsp(tBTA_OP_OPER oper ,char * p_path);
/*******************************************************************************
**
** Function         btapp_ops_set_security_mask
**
** Description
**
** Returns          void
**
******************************************************************************/
void btapp_ops_set_security_mask(tBTA_SEC sec_mask);


#endif

