/*****************************************************************************
**                                                                           
**  Name:          hcisu_h4.c
**                                                                           
**  Description:
**      H4 HCI Services for the lower layer stack.
**
**      This file contains the upper-layer HCIS interface functions for H4.
**      (for dongle mode)
**                                                                           
**  Copyright (c) 2002-2004, WIDCOMM Inc., All Rights Reserved.             
**  WIDCOMM Bluetooth Core. Proprietary and confidential.                    
******************************************************************************/
#include "target.h"
#include <string.h>
#include "gki.h"
#include "userial.h"
#include "hcidefs.h"
#include "btu.h"
#include "hcisu.h"
#include "hcis_h4.h"
#include "userial.h"
#if (defined(HCILP_INCLUDED) && HCILP_INCLUDED == TRUE)
#include "hcilp.h"
#endif

#include "l2c_int.h"
#if defined (SLIP_INCLUDED) && SLIP_INCLUDED == TRUE
#include "slip_api.h"
#endif


#ifndef HCI_INITIAL_TRACE_LEVEL
#define HCI_INITIAL_TRACE_LEVEL BT_TRACE_LEVEL_NONE
#endif
UINT8 hci_trace_level = HCI_INITIAL_TRACE_LEVEL;
#ifndef HCI_DEBUG
#define HCI_DEBUG FALSE
#endif

/*****************************************************************************
** Internal functions
******************************************************************************/
void hcisu_h4_init(UINT8 btu_task_id, UINT8 transport_task_id, UINT16 transport_task_evt);
BOOLEAN hcisu_h4_open(void *p_cfg);
void hcisu_h4_close(void);
BOOLEAN hcisu_h4_send(BT_HDR *p_msg);
UINT32 hcisu_h4_handle_event(UINT16 event);

/* HCI and L2CAP Protocol Trace display functions */
#if (BT_TRACE_PROTOCOL == TRUE)||(HCI_DEBUG==TRUE)
extern BOOLEAN bt_trace_protocol_active;
extern void DispHciEvt(BT_HDR *p_buf);
extern void DispHciAclData (BT_HDR *p_buf, BOOLEAN is_rcvd);
extern void DispL2CCmd(BT_HDR *p_buf, BOOLEAN is_rcvd);
#endif

/* L2CAP segmentation functions */
L2C_API extern BT_HDR   *l2cap_link_chk_pkt_start(BT_HDR *); /* Called at start of rcv to check L2CAP segmentation */
L2C_API extern BOOLEAN   l2cap_link_chk_pkt_end (void);       /* Called at end   of rcv to check L2CAP segmentation */
L2C_API extern BT_HDR   *l2c_link_get_decompressed_pkt(BT_HDR *); /* Called at end of rcv to check L2CAP decompression */

#if defined(HCILL_VS_PROTOCOL)
extern BOOLEAN HCILL_VS_PROTOCOL( UINT8 byte );
#endif

#if defined(HCILL_VS_AWAKE_BB)
extern void HCILL_VS_AWAKE_BB( tHCISU_H4_CB *p_cb, BT_HDR *p_msg );
#endif

/*****************************************************************************
** Globals
******************************************************************************/

/* H4 HCI Services interface table */
const tHCISU_IF hcisu_h4 =
{
    hcisu_h4_init,
    hcisu_h4_open,
    hcisu_h4_close,
    hcisu_h4_send,
    hcisu_h4_handle_event
};

/* Table of HCI preamble sizes for the different HCI message types */
static const UINT8 hcisu_preamble_table[] =
{
    HCIC_PREAMBLE_SIZE,
    HCI_DATA_PREAMBLE_SIZE,
    HCI_SCO_PREAMBLE_SIZE,
    HCIE_PREAMBLE_SIZE
};


static const UINT16 hcisu_msg_evt_table[] =
{
    BT_EVT_TO_BTU_HCIT_ERR,         /* HCIT_TYPE_COMMAND */
    BT_EVT_TO_BTU_HCI_ACL,          /* HCIT_TYPE_ACL_DATA */
    BT_EVT_TO_BTU_HCI_SCO,          /* HCIT_TYPE_SCO_DATA */
    BT_EVT_TO_BTU_HCI_EVT           /* HCIT_TYPE_EVENT */
};

/* H4 lower layer control block */
static tHCISU_H4_CB hcisu_h4_cb;

#if defined (SLIP_INCLUDED) && SLIP_INCLUDED == TRUE
static UINT32 USERIAL_BAUD_RATE[] = {300, 600, 1200, 2400, 9600, 
                                     19200, 57600, 115200, 230400, 460800, 921600, 0};
static BOOLEAN hcisu_slip_tx_cback(UINT8 pak_type, UINT8 *p_data, UINT16 size)
{
    USERIAL_Write(hcisu_h4_cb.port_id, (UINT8 *) p_data, size);
    return TRUE;
}

static BOOLEAN hcisu_slip_rx_cback(UINT8 pak_type, UINT8 *p_data, UINT16 size)
{
    BT_HDR *p_rcv_msg = NULL;
    if (pak_type == HCIT_TYPE_EVENT)
        p_rcv_msg = (BT_HDR *) GKI_getpoolbuf (HCI_CMD_POOL_ID);
    else if (pak_type == HCIT_TYPE_ACL_DATA)
        p_rcv_msg = (BT_HDR *) GKI_getpoolbuf (HCI_ACL_POOL_ID);
    else if (pak_type == HCIT_TYPE_SCO_DATA)
        p_rcv_msg = (BT_HDR *) GKI_getpoolbuf (HCI_SCO_POOL_ID);

    if (p_rcv_msg) {
        p_rcv_msg->event = hcisu_msg_evt_table[pak_type-1];
        p_rcv_msg->offset = 0;
        p_rcv_msg->len = size;
        memcpy((void *) ((UINT8 *)(p_rcv_msg + 1) + p_rcv_msg->offset), (void *) p_data, size);

        if (pak_type == HCIT_TYPE_ACL_DATA) {
            hcisu_h4_cb.p_rcv_msg = l2cap_link_chk_pkt_start (p_rcv_msg);
            if (hcisu_h4_cb.p_rcv_msg == NULL)
                return FALSE;
            if (l2cap_link_chk_pkt_end ()) {
#if (BT_TRACE_PROTOCOL == TRUE)||(HCI_DEBUG==TRUE)
    if( bt_trace_protocol_active == TRUE )
        {
                DispHciAclData((BT_HDR *)hcisu_h4_cb.p_rcv_msg, TRUE);
                DispL2CCmd((BT_HDR *)hcisu_h4_cb.p_rcv_msg, TRUE);
        }
#endif
                GKI_send_msg (hcisu_h4_cb.btu_task_id, BTU_HCI_RCV_MBOX, hcisu_h4_cb.p_rcv_msg);
                return TRUE;
            } else {
                return TRUE;
            }
        } else { 
#if (BT_TRACE_PROTOCOL == TRUE)||(HCI_DEBUG==TRUE)
    if( bt_trace_protocol_active == TRUE )
        {
            if (p_rcv_msg->event == BT_EVT_TO_BTU_HCI_EVT)
                DispHciEvt ((BT_HDR *)p_rcv_msg);
        }
#endif
            GKI_send_msg (hcisu_h4_cb.btu_task_id, BTU_HCI_RCV_MBOX, p_rcv_msg);
            return TRUE;
        }
    } else {
        BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_ERROR, "HCIS: Unable to allocate buffer for incoming HCI message.");
        return FALSE;
    }    
}
#endif

/*****************************************************************************
**
** Function         hcisu_h4_serial_cback
**
** Description
**      USERIAL callback function.
**
**      This function is called by the USERIAL driver whenever a uart event
**      occurs. This function then notifys the transport task, which will
**      handle the serial event.
**
*****************************************************************************/
void hcisu_h4_serial_cback(tUSERIAL_PORT port_id, tUSERIAL_EVT event,
                           tUSERIAL_EVT_DATA *pdata)
{
    if (event == USERIAL_RX_READY_EVT)
    {
        /* Notify transport task of serial port event */
        GKI_send_event(hcisu_h4_cb.transport_task_id, hcisu_h4_cb.transport_task_evt);
    }
#if (defined(HCI_SUPPORT_TX_DONE) && HCI_SUPPORT_TX_DONE == TRUE)
    if (event == USERIAL_TX_DONE_EVT)
    {
#if (defined(HCILP_INCLUDED) && HCILP_INCLUDED == TRUE)
        HCILP_IsTxDoneCplted(TRUE);
#endif
    }
#endif
}

/*****************************************************************************
**
** Function         hcisu_h4_slip_receive_msg
**
** Description
**      Handle incoming data (HCI commands) from the serial port.
**
**      If there is data waiting from the serial port, this funciton reads the
**      data and parses it. Once an entire HCI message has been read, it calls
**      hcil_handle_msg to send the message to LM.
**
*****************************************************************************/
UINT16 hcisu_h4_slip_receive_msg(tHCISU_H4_CB *p_cb)
{
    UINT16      bytes_read = 0;
    UINT8       byte;

    /* If H4 port is not opened, then exit */
    if (p_cb->h4_state != HCISU_H4_OPENED_ST)
        return (0);

    while (TRUE)
    {
        /* Read one byte to see if there is anything waiting to be read */
        if (USERIAL_Read(p_cb->port_id, &byte, 1) == 0)
            break;

        bytes_read++;

#if defined (SLIP_INCLUDED) && SLIP_INCLUDED == TRUE
        SLIP_Read(byte);
#endif 
    }

    return (bytes_read);
}
    


/*****************************************************************************
**
** Function         hcisu_h4_receive_msg
**
** Description
**      Handle incoming data (HCI commands) from the serial port.
**
**      If there is data waiting from the serial port, this funciton reads the
**      data and parses it. Once an entire HCI message has been read, it calls
**      hcil_handle_msg to send the message to LM.
**
*****************************************************************************/
UINT16 hcisu_h4_receive_msg(tHCISU_H4_CB *p_cb)
{
    UINT16      bytes_read = 0;
    UINT8       byte;
    UINT16      msg_len, len;
    BOOLEAN     msg_received;
 
    /* If H4 port is not opened, then exit */
    if (p_cb->h4_state != HCISU_H4_OPENED_ST)
        return (0);

    while (TRUE)
    {
        /* Read one byte to see if there is anything waiting to be read */
        if (USERIAL_Read(hcisu_h4_cb.port_id, &byte, 1) == 0)
        {
            break;
        }
        bytes_read++;
        msg_received = FALSE;

        switch (p_cb->rcv_state)
        {
        case HCISU_H4_MSGTYPE_ST:
            /* Start of new message. Allocate a buffer for message, size depends on the type */

#if defined(HCILL_VS_PROTOCOL)
            /* Ignore this byte if the vendor specific protocol consumes it */
            if( HCILL_VS_PROTOCOL(byte) == TRUE )
            {
                bytes_read--;
                continue;
            }
#endif
            if (byte == HCIT_TYPE_EVENT)
                p_cb->p_rcv_msg = (BT_HDR *) GKI_getpoolbuf (HCI_CMD_POOL_ID);
            else if (byte == HCIT_TYPE_ACL_DATA)
                p_cb->p_rcv_msg = (BT_HDR *) GKI_getpoolbuf (HCI_ACL_POOL_ID);
            else if (byte == HCIT_TYPE_SCO_DATA)
                p_cb->p_rcv_msg = (BT_HDR *) GKI_getpoolbuf (HCI_SCO_POOL_ID);
            else
            {
                /* Unknown HCI message type */
                HCI_TRACE_ERROR1( "[hcis] Unknown HCI message type drop this byte 0x%x", byte);
                /* Drop this byte */
                break;
            }

            /* Initialize rx parameters */
            p_cb->rcv_msg_type = byte;

            /* Check for problem allocating message buffer */
            if (p_cb->p_rcv_msg)
            {
                /* Initialize BT_HDR */
                p_cb->p_rcv_msg->len = 0;
                p_cb->p_rcv_msg->event = hcisu_msg_evt_table[byte-1];
                p_cb->p_rcv_msg->offset = 0;

                p_cb->rcv_state = HCISU_H4_LEN_ST;              /* Next, wait for length to come in */
            }
            else
            {
                /* Unable to allocate message buffer. */
                HCI_TRACE_ERROR1("[hcis] Unable to allocate buffer for incoming HCI message 0x%x", byte);

                p_cb->rcv_state = HCISU_H4_NOBUF_LEN_ST;        /* Next, wait for length to come in */
            }

            p_cb->rcv_len = hcisu_preamble_table[byte-1];   /* Get number preamble bytes for this msg type */

            break;

        case HCISU_H4_LEN_ST:
            /* Receiving preamble */
            *((UINT8 *)(p_cb->p_rcv_msg + 1) + p_cb->p_rcv_msg->len++) = byte;
            p_cb->rcv_len--;

            /* Check if we received entire preamble yet */
            if (p_cb->rcv_len == 0)
            {
                /* Received entire preamble. Length is in the last byte(s) of the preamble */
                msg_len = byte;
                if (p_cb->rcv_msg_type == HCIT_TYPE_ACL_DATA)
                {
                    /* ACL data lengths are 16-bits (lobyte of msg length was the previous byte received) */
                    msg_len = (msg_len << 8) + p_cb->previous_rcv_byte;

                    /* Check for segmented packets. If this is a continuation packet, then   */
                    /* current rcv buffer will be freed, and we will continue appending data */
                    /* to the original rcv buffer.                                           */
                    if ((p_cb->p_rcv_msg = l2cap_link_chk_pkt_start (p_cb->p_rcv_msg)) == NULL)
                    {
                        /* If a NULL is returned, then we have a problem. Ignore remaining data in this packet */
                        p_cb->rcv_len = msg_len;
                        if (msg_len == 0)
                        {
                            p_cb->rcv_state = HCISU_H4_MSGTYPE_ST;  /* Wait for next message */
                        }
                        else
                        {
                            p_cb->rcv_state = HCISU_H4_IGNORE_ST;   /* Ignore rest of the packet */
                        }

                        break;
                    }
                }
                p_cb->rcv_len = msg_len;

                /* Verify that buffer is big enough to fit message */
                if ((sizeof(BT_HDR) + hcisu_preamble_table[p_cb->rcv_msg_type-1] + msg_len) > GKI_get_buf_size(p_cb->p_rcv_msg))
                {
                    /* Message cannot fit into buffer */
                    GKI_freebuf(p_cb->p_rcv_msg);
                    p_cb->p_rcv_msg = NULL;
                    p_cb->rcv_state = HCISU_H4_IGNORE_ST;   /* Ignore rest of the packet */

                    HCI_TRACE_ERROR0("[hcis] Invalid length for incoming HCI message");
                }
                else
                {
                    /* Message length is valid */
                    if (msg_len)
                    {
                        /* Read rest of message */
                        p_cb->rcv_state = HCISU_H4_DATA_ST;
                    }
                    else
                    {
                        /* Message has no additional parameters. (Entire message has been received) */
                        msg_received = TRUE;
                        p_cb->rcv_state = HCISU_H4_MSGTYPE_ST;  /* Next, wait for next message */
                    }
                }

            }
            else
            {
                /* Did not receive entire message length from stream yet. Retain the byte we just received */
                p_cb->previous_rcv_byte = byte;
            }

            break;

        case HCISU_H4_NOBUF_LEN_ST:
            /* Unable to allocate buffer for incoming message. Get length of message so that */
            /* the rest of the message can be ignored.                                       */

            /* Receiving preamble */
            p_cb->rcv_len--;

            /* Check if we received entire preamble yet */
            if (p_cb->rcv_len == 0)
            {
                /* Received entire preamble. Length is in the last byte(s) of the preamble */
                msg_len = byte;
                if (p_cb->rcv_msg_type == HCIT_TYPE_ACL_DATA)
                {
                    /* ACL data lengths are 16-bits (the lobyte of length was the previous byte received) */
                    msg_len = (msg_len << 8) + p_cb->previous_rcv_byte;
                }
                p_cb->rcv_len = msg_len;

                p_cb->rcv_state = HCISU_H4_IGNORE_ST;   /* Ignore rest of the packet */
            }
            else
            {
                /* Did not receive entire message length from stream yet. Retain the byte we just received */
                p_cb->previous_rcv_byte = byte;
            }
            break;


        case HCISU_H4_DATA_ST:
            *((UINT8 *)(p_cb->p_rcv_msg + 1) + p_cb->p_rcv_msg->len++) = byte;
            p_cb->rcv_len--;

            /* Read in the rest of the message */
            len = USERIAL_Read(hcisu_h4_cb.port_id, ((UINT8 *)(p_cb->p_rcv_msg + 1) + p_cb->p_rcv_msg->len),  p_cb->rcv_len);
            p_cb->p_rcv_msg->len += len;
            p_cb->rcv_len -= len;
            bytes_read += len;

            /* Check if we read in entire message yet */
            if (p_cb->rcv_len == 0)
            {
                /* Received entire packet. */

                /* Check for segmented l2cap packets */
                if ((p_cb->rcv_msg_type == HCIT_TYPE_ACL_DATA) &&
                    !l2cap_link_chk_pkt_end ())
                {
                    /* Not the end of packet yet. */
                    p_cb->rcv_state = HCISU_H4_MSGTYPE_ST;      /* Next, wait for next message */
                }
                else
                {
                    /* Received entire message */
#if (L2CAP_ENHANCED_FEATURES & L2CAP_COMPRESSION)
                    if (p_cb->rcv_msg_type == HCIT_TYPE_ACL_DATA)
                        p_cb->p_rcv_msg = l2c_link_get_decompressed_pkt(p_cb->p_rcv_msg);
#endif
                    msg_received = TRUE;
                    p_cb->rcv_state = HCISU_H4_MSGTYPE_ST;      /* Next, wait for next message */
                }
            }
            break;


        case HCISU_H4_IGNORE_ST:
            /* Ignore reset of packet */
            p_cb->rcv_len--;

            /* Check if we read in entire message yet */
            if (p_cb->rcv_len == 0)
            {
                p_cb->rcv_state = HCISU_H4_MSGTYPE_ST;      /* Next, wait for next message */
            }
            break;
        }


        /* If we received entire message, then send it to the BTU task */
        if (msg_received)
        {
            /* Display protocol trace message */
#if (BT_TRACE_PROTOCOL == TRUE)||(HCI_DEBUG==TRUE)
    if( bt_trace_protocol_active == TRUE )
        {
            if (p_cb->p_rcv_msg->event == BT_EVT_TO_BTU_HCI_ACL)
            {
                DispHciAclData((BT_HDR *)p_cb->p_rcv_msg, TRUE);
                DispL2CCmd((BT_HDR *)p_cb->p_rcv_msg, TRUE);
            }
            else if (p_cb->p_rcv_msg->event == BT_EVT_TO_BTU_HCI_EVT)
            {
                DispHciEvt ((BT_HDR *)p_cb->p_rcv_msg);
            }
        }
#endif

            GKI_send_msg (hcisu_h4_cb.btu_task_id, BTU_HCI_RCV_MBOX, p_cb->p_rcv_msg);

            p_cb->p_rcv_msg = NULL;
        }
    }

#if (defined(HCILP_INCLUDED) && HCILP_INCLUDED == TRUE)
    /* since we are done reading data from HCI, allow
       device to sleep */
    HCILP_AllowBTDeviceSleep();
#endif

    return (bytes_read);
}


/*****************************************************************************
**
** Function         hcisu_h4_send_msg
**
** Description
**      Sends HCI messages (HCI commands and data) out the uart.
**
*****************************************************************************/
void hcisu_h4_send_msg_now(tHCISU_H4_CB *p_cb, BT_HDR *p_msg)
{
    UINT8 type = 0;
    UINT16 handle;
    UINT16 bytes_sent;
    UINT16 bytes_to_send;
    UINT8 *p = ((UINT8 *)(p_msg + 1)) + p_msg->offset;

#if defined (SLIP_INCLUDED) && SLIP_INCLUDED == TRUE
    BT_HDR *p_slip = NULL;
#endif

    if (p_msg->event == BT_EVT_TO_LM_HCI_ACL)
        type = HCIT_TYPE_ACL_DATA;
    else if (p_msg->event == BT_EVT_TO_LM_HCI_SCO)
        type = HCIT_TYPE_SCO_DATA;
    else if (p_msg->event == BT_EVT_TO_LM_HCI_CMD)
        type = HCIT_TYPE_COMMAND;


    /* Check if sending ACL data that needs fragmenting */
    if ((p_msg->event == BT_EVT_TO_LM_HCI_ACL) && (p_msg->len > btu_cb.hcit_acl_pkt_size))
    {
        /* Get the handle from the packet */
        STREAM_TO_UINT16 (handle, p);

        /* Set packet boundary flags to "continuation packet" */
        handle = (handle & 0xCFFF) | 0x1000;

        /* Do all the first chunks */
        while (p_msg->len > btu_cb.hcit_acl_pkt_size)
        {
            if (!p_cb->slip_mode) {
            p = ((UINT8 *)(p_msg + 1)) + p_msg->offset - 1;
            *p = type;
            bytes_to_send = btu_cb.hcit_acl_pkt_size + 1;   /* packet_size + message type */

#if (defined(HCILP_INCLUDED) && HCILP_INCLUDED == TRUE)
            /* wake up BT device if its in sleep mode */
            HCILP_WakeupBTDevice();
#endif

            bytes_sent = USERIAL_Write(hcisu_h4_cb.port_id, (UINT8 *) p, bytes_to_send);
#if (HCI_DEBUG==TRUE)
            if(bytes_sent != bytes_to_send)
            {
                HCI_TRACE_ERROR0( "[hcis] hcisu does not partial send of data(1)");
            }
#endif
            } else {
#if defined (SLIP_INCLUDED) && SLIP_INCLUDED == TRUE
                p = ((UINT8 *)(p_msg + 1)) + p_msg->offset;
                p_slip = (BT_HDR *)GKI_getpoolbuf (HCI_ACL_POOL_ID);
                if (!p_slip)
                      return;
                p_slip->offset = 0;
                p_slip->len = btu_cb.hcit_acl_pkt_size;
                memcpy((void *) (p_slip + 1), (void *) p, btu_cb.hcit_acl_pkt_size);
                SLIP_Send(p_slip, type);
#endif
            }

            /* Adjust offset and length for what we just sent */
            p_msg->offset += btu_cb.hcit_acl_data_size;
            p_msg->len    -= btu_cb.hcit_acl_data_size;

            p = ((UINT8 *)(p_msg + 1)) + p_msg->offset;

            UINT16_TO_STREAM (p, handle);

            if (p_msg->len > btu_cb.hcit_acl_pkt_size)
            {
                UINT16_TO_STREAM (p, btu_cb.hcit_acl_data_size);
            }
            else
            {
                UINT16_TO_STREAM (p, p_msg->len - HCI_DATA_PREAMBLE_SIZE);
            }

            /* If we were only to send partial buffer, stop when done.    */
            /* Send the buffer back to L2CAP to send the rest of it later */
            if (p_msg->layer_specific)
            {
                if (--p_msg->layer_specific == 0)
                {
                    p_msg->event = BT_EVT_TO_BTU_L2C_SEG_XMIT;
                    GKI_send_msg (hcisu_h4_cb.btu_task_id, TASK_MBOX_0, p_msg);
                    return;
                }
            }
        }
    }

    /* Put the HCI Transport packet type 1 byte before the message for non slip mode*/
    if (hcisu_h4_cb.slip_mode) {
#if defined (SLIP_INCLUDED) && SLIP_INCLUDED == TRUE
        SLIP_Send(p_msg, (UINT8) type);
#endif 
    }
    else {
    p = ((UINT8 *)(p_msg + 1)) + p_msg->offset - 1;
    *p = type;
    bytes_to_send = p_msg->len + 1;         /* message_size + message type */

#if (defined(HCILP_INCLUDED) && HCILP_INCLUDED == TRUE)
    /* wake up BT device if its in sleep mode */
    HCILP_WakeupBTDevice();
#endif

    bytes_sent = USERIAL_Write(hcisu_h4_cb.port_id, (UINT8 *) p, bytes_to_send);
#if (HCI_DEBUG==TRUE) && (HCI_TRACE_VERBOSE!=TRUE)
    HCI_TRACE_DEBUG6( "[hcis] CMD len %d, sent %d [0x%x;0x%x;0x%x;0x%x]",
        bytes_to_send, bytes_sent, p[0], p[1], p[2], p[3]);
    if(bytes_sent != bytes_to_send)
    {
        HCI_TRACE_ERROR0( "[hcisu] partial send of data not supported (2)");
    }
#endif

    GKI_freebuf (p_msg);
    }

    return;
}

void hcisu_h4_send_msg(tHCISU_H4_CB *p_cb, BT_HDR *p_msg)
{
#if defined(HCILL_VS_AWAKE_BB)
    HCILL_VS_AWAKE_BB(p_cb, p_msg);
#else
    hcisu_h4_send_msg_now(p_cb, p_msg );
#endif
}


/*****************************************************************************
**  Upper layer HCIS Interface Functions
*****************************************************************************/

/*****************************************************************************
**
** Function         hcisu_h4_init
**
** Description
**      Initialize control block and message queue for hcisu_h4.
**
*****************************************************************************/
void hcisu_h4_init(UINT8 btu_task_id, UINT8 transport_task_id, UINT16 transport_task_evt)
{
    hcisu_h4_cb.h4_state = HCISU_H4_CLOSED_ST;      /* Initial h4 state: closed */
    hcisu_h4_cb.rcv_state = HCISU_H4_MSGTYPE_ST;    /* Initial rx state: wait for HCI message type */

    hcisu_h4_cb.btu_task_id = btu_task_id;                  /* Task that is handling incoming HCI messages */
    hcisu_h4_cb.transport_task_id = transport_task_id;      /* Task that is handling HCIS evnets */
    hcisu_h4_cb.transport_task_evt = transport_task_evt;    /* Event used to indicate an HCIS event */    
}


/*****************************************************************************
**
** Function         hcisu_h4_open
**
** Description
**      Open the uart port.
**
*****************************************************************************/
BOOLEAN hcisu_h4_open(void *p_cfg)
{
    tUSERIAL_OPEN_CFG open_cfg;
    tHCIS_H4_CFG *p_h4_cfg = (tHCIS_H4_CFG *)p_cfg;

    /* Save port id */
    hcisu_h4_cb.port_id = p_h4_cfg->port_id;

    /* Initialize serial driver */
    open_cfg.fmt  = p_h4_cfg->data_fmt;
    open_cfg.baud = p_h4_cfg->baud;
    open_cfg.fc   = USERIAL_FC_HW;
    open_cfg.buf  = USERIAL_BUF_BYTE;
    hcisu_h4_cb.slip_mode = p_h4_cfg->slip_mode;

    hcisu_h4_cb.h4_state = HCISU_H4_OPENED_ST;

    USERIAL_Open(p_h4_cfg->port_id,&open_cfg,hcisu_h4_serial_cback);  

    if (p_h4_cfg->slip_mode) {
#if defined (SLIP_INCLUDED) && SLIP_INCLUDED == TRUE
        SLIP_Init(USERIAL_BAUD_RATE[p_h4_cfg->baud], hcisu_slip_tx_cback, hcisu_slip_rx_cback);
#endif
    }   

    return (TRUE);
}


/*****************************************************************************
**
** Function         hcisu_h4_close
**
** Description
**      Open the uart port.
**
*****************************************************************************/
void hcisu_h4_close(void)
{
    hcisu_h4_cb.h4_state = HCISU_H4_CLOSED_ST;      /* Initial h4 state: closed */
    USERIAL_Close( hcisu_h4_cb.port_id );

}


/*****************************************************************************
**
** Function         hcisu_h4_send
**
** Description
**      Open the uart port.
**
*****************************************************************************/
BOOLEAN hcisu_h4_send(BT_HDR *p_msg)
{
    hcisu_h4_send_msg(&hcisu_h4_cb, p_msg);

    return (TRUE);
}


/*****************************************************************************
**
** Function         hcisu_h4_handle_event
**
** Description
**      Open the uart port.
**
*****************************************************************************/
UINT32 hcisu_h4_handle_event(UINT16 event)
{
    UINT16 bytes_read;

    if (!hcisu_h4_cb.slip_mode) {
        bytes_read = hcisu_h4_receive_msg(&hcisu_h4_cb);
    } else {
        bytes_read = hcisu_h4_slip_receive_msg(&hcisu_h4_cb);
    }

    return (0);
}

/*****************************************************************************
**
** Function         hcisu_write_byte
**
** Description
**      This function is called by HCI LL to send one byte of data.
**
*****************************************************************************/
void hcisu_write_byte( UINT8 byte )
{
    UINT16 bytes_sent;

    bytes_sent = USERIAL_Write(hcisu_h4_cb.port_id, &byte, 1);

#if (HCI_DEBUG==TRUE)
    if(bytes_sent != 1)
    {
        HCI_TRACE_ERROR0( "[hcis] ERROR partial send of data not supported {3)");
    }
#endif
}

