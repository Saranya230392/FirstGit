/*****************************************************************************
**                                                                           
**  Name:          hcilp.c
**                                                                           
**  Description:
**      This file implements the HCI sleep mode implementation on the host side
**
**                                                                           
**  Copyright (c) 2002-2004, WIDCOMM Inc., All Rights Reserved.             
**  WIDCOMM Bluetooth Core. Proprietary and confidential.                    
******************************************************************************/
#include "target.h"
#include "bt_types.h"
#include "gki.h"
#include "hcidefs.h"
#include "btm_api.h"
#include "upio.h"
#include "hcilp.h"


#ifndef HCILP_BT_WAKE_GPIO
#define HCILP_BT_WAKE_GPIO    UPIO_GENERAL1
#endif

#ifndef HCILP_HOST_WAKE_GPIO
#define HCILP_HOST_WAKE_GPIO  UPIO_GENERAL2
#endif

#ifndef BT_WAKE_POLARITY
#define BT_WAKE_POLARITY  0
#endif

#ifndef HOST_WAKE_POLARITY
#define HOST_WAKE_POLARITY  0
#endif

#if (BT_WAKE_POLARITY == 1)
/* active high */
enum {
    HCILP_BT_MAY_SLEEP = UPIO_OFF,
    HCILP_BT_BE_AWAKE = UPIO_ON
};
#else
/* active low */
enum {
    HCILP_BT_MAY_SLEEP = UPIO_ON,
    HCILP_BT_BE_AWAKE = UPIO_OFF
};
#endif

#if (HOST_WAKE_POLARITY == 1)
/* active high */
enum {
    HCILP_HOST_MAY_SLEEP = UPIO_OFF,
    HCILP_HOST_BE_AWAKE = UPIO_ON
};
#else
/* active low */
enum {
    HCILP_HOST_MAY_SLEEP = UPIO_ON,
    HCILP_HOST_BE_AWAKE = UPIO_OFF
};
#endif
extern tBTM_STATUS bte_set_loc_features(UINT8 *data, tBTM_CMPL_CB *set_loc_features_cback);   /*  CHECK_HY   071203  for EDR disable  */

#define HCI_WRITE_SLEEP_MODE (HCI_GRP_VENDOR_SPECIFIC | 0x27)
#define HCI_WRITE_SLEEP_MODE_CMD_LENGTH 10
UINT8 loc_data[8] = {0xff, 0xff, 0x8d, 0x78, 0x18, 0x18, 0, 0};     /*   CHECK_HY   071203   for disable EDR   */
UINT32 lp_service_mask = 0;   /* is accessed by BTUI. not very nice */
static BOOLEAN lp_enabled = FALSE;
#if (defined(HCI_SUPPORT_TX_DONE) && HCI_SUPPORT_TX_DONE == TRUE)
static BOOLEAN lp_no_tx_data = FALSE;
#endif

/* Callback function */
static void hcilp_vs_cback(tBTM_VSC_CMPL *p)
{
    tUPIO_STATE state;

    state = lp_enabled ? HCILP_BT_MAY_SLEEP : HCILP_BT_BE_AWAKE;

    UPIO_Set(UPIO_GENERAL, HCILP_BT_WAKE_GPIO, state);
    
    BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_ERROR, "HCIS: hciu_lp - hcilp_vs_cback");
    bte_set_loc_features(loc_data, NULL);     /*  CHECK_HY   071203  for EDR disable  */	
}

/*******************************************************************************
 **
 ** Function           HCILP_Init
 **
 ** Description        Init HCILP data.
 **
 ** Output Parameter   None
 **
 ** Returns            void
 **
 *******************************************************************************/
void HCILP_Init(void)
{
    lp_enabled = FALSE;
#if (defined(HCI_SUPPORT_TX_DONE) && HCI_SUPPORT_TX_DONE == TRUE)
    lp_no_tx_data = FALSE;
#endif
}


/*******************************************************************************
**
** Function           HCILP_Enable
**
** Description        Enables Sleep mode.
**
** Output Parameter   None
**
** Returns            TRUE  if sleep mode command was issued to BT device
**                    FALSE if the feature is not supported
**
*******************************************************************************/
BOOLEAN HCILP_Enable(BOOLEAN on)
{
    tBTM_STATUS result;
    static UINT8 data[HCI_WRITE_SLEEP_MODE_CMD_LENGTH] =    {
    0x01,              /* Sleep Mode algorithm 1 */
    0x01,              /* Host Idle Treshold in 300ms */
#if defined (PLATFORM_LEMANS_BT) && (PLATFORM_LEMANS_BT == TRUE)
    0x01,              /* Host Controller Idle Treshold in 300ms */
#elif defined (PLATFORM_GB8_BT) && (PLATFORM_GB8_BT == TRUE)
    0x09,              /* Host Controller Idle Treshold in 300ms */
#elif defined (PLATFORM_GB5_BT) && (PLATFORM_GB5_BT == TRUE)
    0x01,              /* Host Controller Idle Treshold in 300ms */
#endif
    BT_WAKE_POLARITY,  /* BT_WAKE Polarity - 0=Active Low, 1= Active High*/
    HOST_WAKE_POLARITY,/* HOST_WAKE Polarity - 0=Active Low, 1= Active High */
    0x01,              /* Allow host Sleep during SCO */
    0x01,              /* Combine Sleep Mode and LPM */
    0x00,              /* UART_TXD Tri-State */
    0x00,              /* NA to Mode 1 */
    0x00,              /* NA to Mode 1 */
    };

    if (on)
    {
    	lp_enabled = TRUE;
        data[0] = 0x01;
    }
    else
    {
        lp_enabled = FALSE;
        data[0] = 0x00;
    }

    result = BTM_VendorSpecificCommand(HCI_WRITE_SLEEP_MODE, HCI_WRITE_SLEEP_MODE_CMD_LENGTH,
    	(UINT8 *)data, (tBTM_CMPL_CB *) hcilp_vs_cback);

    return (result < BTM_CMD_STARTED) ? TRUE : FALSE;
}


/*******************************************************************************
**
** Function           HCILP_IsSleepState
**
** Description        Checks if its ok for application to go to sleep mode
**
** Output Parameter   None
**
** Returns            TRUE  if bluetooth is OK for app to go to sleep mode
**                    FALSE if bluetooth is awake and cannot go to sleep mode
**
*******************************************************************************/
BOOLEAN HCILP_IsSleepState(void)
{
    tUPIO_STATE gpio_state;

    /* Read HOST_WAKE gpio */
    gpio_state = UPIO_Read(UPIO_GENERAL, HCILP_HOST_WAKE_GPIO);

    return (gpio_state == HCILP_HOST_MAY_SLEEP) ? TRUE : FALSE;
}


/*******************************************************************************
**
** Function           HCILP_AppSleeping
**
** Description        Called by application when it wants to indicate to bluetooth
**                    that it is going into low power mode
**
** Output Parameter   None
**
**
*******************************************************************************/
void HCILP_AppSleeping(void)
{
    /* assert BT_WAKE if its deasserted */
    UPIO_Set(UPIO_GENERAL, HCILP_BT_WAKE_GPIO, HCILP_BT_MAY_SLEEP);
}


/*******************************************************************************
 **
 ** Function           hcilp_do_awake_dev
 **
 ** Description        wake up the host controler and stop timer that might let 
 **                    it go to sleep
 **
 ** Output Parameter   None
 **
 **
 *******************************************************************************/
void hcilp_do_awake_dev(void)
{
/*        APPL_TRACE_DEBUG0("hcilp_do_awake_dev");*/
        UPIO_Set(UPIO_GENERAL, HCILP_BT_WAKE_GPIO, HCILP_BT_BE_AWAKE);
}

/*******************************************************************************
 **
** Function           HCILP_WakeupBTDevice
**
** Description        Called by HCIS to wake up Bluetooth chip when
**                    there is data to be sent over UART
**
** Output Parameter   None
**
**
*******************************************************************************/
void HCILP_WakeupBTDevice(void)
{
    if (lp_enabled)
    {
        /* deassert BT_WAKE in case we are waking up and sending data */
        UPIO_Set(UPIO_GENERAL, HCILP_BT_WAKE_GPIO, HCILP_BT_BE_AWAKE);
    }
    #if (defined(HCI_SUPPORT_TX_DONE) && HCI_SUPPORT_TX_DONE == TRUE)
    HCILP_IsTxDoneCplted(FALSE);
    #endif
}


/*******************************************************************************
**
** Function           HCILP_AllowBTDeviceSleep
**
** Description        Called by HCIS to indicate to bluetooth chip that it can go to
**                    sleep mode.This is called by when all data has been
**                    read from UART
**
** Output Parameter   None
**
**
*******************************************************************************/
void HCILP_AllowBTDeviceSleep(void)
{
    #if (defined(HCI_SUPPORT_TX_DONE) && HCI_SUPPORT_TX_DONE == TRUE)
    if (lp_enabled && lp_no_tx_data && (lp_service_mask == 0))
    #else
    if (lp_enabled && (lp_service_mask == 0))
    #endif
    {
        /* assert BT_WAKE if its deasserted */
        UPIO_Set(UPIO_GENERAL, HCILP_BT_WAKE_GPIO, HCILP_BT_MAY_SLEEP);
    }
}

/*******************************************************************************
 **
 ** Function           HCILP_CheckInitCompletion
 **
 ** Description        Called by the Userial to check if the Bleutooth module initialization
 **                        is completed or not
 **
 ** Returns           TRUE  if bluetooth initialization is completed
 **                       FALSE otherwise.
 **
 *******************************************************************************/
 BOOLEAN HCILP_CheckInitCompletion(void)
{
    return lp_enabled;
}

/*******************************************************************************
 **
 ** Function           HCILP_IsTxDoneCplted
 **
 ** Description       This function is to inform the hcilp module if data is waiting in the Tx Q or not.
 **                             IsTxDone: TRUE if All data in the Tx Q are gone
 **                                       FALSE if all data in the Tx Q not gone.
 **                             Typicaly this function must be call before USERIAL Write and in the Tx Done routine
 **                             
 ** Returns           TRUE  if bluetooth initialization is completed
 **                       FALSE otherwise.
 **
 *******************************************************************************/
#if (defined(HCI_SUPPORT_TX_DONE) && HCI_SUPPORT_TX_DONE == TRUE)
void HCILP_IsTxDoneCplted(BOOLEAN IsTxDone)
{
     lp_no_tx_data = IsTxDone;
}
#endif
/*******************************************************************************
 **
 ** Function           HCILP_Pause
 **
 ** Description        
 **
 ** Output Parameter   Service mask : service bit filed that indicate the service that req the pause
 **
 ** Returns        none
 **
 *******************************************************************************/
void HCILP_Pause(UINT32 ServiceMask)
{
    /* update the service mask */
    lp_service_mask |= ServiceMask;

    /*APPL_TRACE_DEBUG1("HCILP_Pause 0x%x", lp_service_mask);*/
    if(lp_service_mask)
    {
        hcilp_do_awake_dev();
    }
}

/*******************************************************************************
 **
 ** Function           HCILP_Resume
 **
 ** Description        
 **
 ** Output Parameter   Service mask : service bit filed that indicate the service that release the pause
 **                              
 ** Returns        none
 **
 *******************************************************************************/
void HCILP_Resume(UINT32 ServiceMask)
{
    /* update the service mask */
    lp_service_mask &= ~ServiceMask;

    /*APPL_TRACE_DEBUG1("HCILP_Resume 0x%x", lp_service_mask);*/
    if(lp_service_mask)
    {
        return;
    }

    /* let the host controler go to sleep mode if nothing else prevent it */
    HCILP_AllowBTDeviceSleep();
}
