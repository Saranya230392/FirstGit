/*****************************************************************************
**                                                                           *
**  Name:          bte_main.c                                                *
**                                                                           *
**  Description:   This is the main module for the BTE system.  It contains  *
**                 task implementations, system initialization functions,    *
**                 and the main function for the system.                     *
**                                                                           *
**  Copyright (c) 2000-2004, WIDCOMM Inc., All Rights Reserved.              *
**  WIDCOMM Bluetooth Core. Proprietary and confidential.                    *
******************************************************************************/
/* Platform specific inclusions */
#include	<system.h>
#include	<kernel.h>

#ifndef BUILDCFG
#define BUILDCFG
#endif
#include "target.h"

#include "gki.h"
#include "userial.h"
#include "hcidefs.h"
#include "btm_api.h"
#include "bta_api.h"
#include "bta_dg_api.h"
#include "bta_sys.h"
#include "btapp_aa.h"
#include "upio.h"
#include "bte.h"

extern UINT8 appl_trace_level;

#if (defined PLATFORM_GB8_BT && (PLATFORM_GB8_BT == TRUE))|| \
      (defined (PLATFORM_GB5_BT) && (PLATFORM_GB5_BT == TRUE))
#endif
//BCM_CHANGE_070307
const UINT8 BCM_bte_version_string[] = "BTE_080111-010";
//END_OF_BCM_CHANGE

BTU_API extern void bte_hcisu_task(UINT32 param);
BTU_API extern UINT32 btu_task (UINT32 param);
BTU_API extern UINT32 sbc_encode_task (UINT32 param);
#ifndef LGBX_INCLUDE
BTU_API extern void bte_appl_task(UINT32 param);
#endif
BTU_API extern void BTE_Init (void);
BT_API extern void BTE_LoadStack(void);
void BTE_HciTaskInit(void);
#if (defined(BTU_INCLUDED) && (BTU_INCLUDED == TRUE))            
void BTE_BtuTaskInit(void);
#endif
#if (defined (BTUI_INCLUDED) && (BTUI_INCLUDED == TRUE))
void BTE_ApplTaskInit(void);
#endif
void BTE_SBCTaskInit(void);


#if (BT_WAKE_POLARITY == 1)
/* active high */
enum {
    HCILP_BT_MAY_SLEEP = UPIO_OFF,
    HCILP_BT_BE_AWAKE = UPIO_ON
};
#else
/* active low */
enum {
    HCILP_BT_MAY_SLEEP = UPIO_ON,
    HCILP_BT_BE_AWAKE = UPIO_OFF
};
#endif

#if (HOST_WAKE_POLARITY == 1)
/* active high */
enum {
    HCILP_HOST_MAY_SLEEP = UPIO_OFF,
    HCILP_HOST_BE_AWAKE = UPIO_ON
};
#else
/* active low */
enum {
    HCILP_HOST_MAY_SLEEP = UPIO_ON,
    HCILP_HOST_BE_AWAKE = UPIO_OFF
};
#endif
/*****************************************************************************/
/*                             Power Management Configuration    */
/*****************************************************************************/
/* MSMP Voltage setting  = 2.6 Volts */
#define MSMP_LEVEL        2600

/* MSME Voltage setting  = 1.85 Volts*/
#define MSME_LEVEL        1850

/* WLAN Voltage setting  = 3.05 Volts*/
#define WLAN_LEVEL        3050  //sec_jhlee_20050621_1 adjust to 3.05V for BCM2045

/*****************************************************************************/
/*                            HCIS Configuration                             */
/*****************************************************************************/
#include "hcisu.h"

/* H4 Configuration for BTE */
#if defined(HCISU_H4_INCLUDED) && HCISU_H4_INCLUDED == TRUE
#include "userial.h"
#include "hcis_h4.h"
extern const tHCISU_IF hcisu_h4;
static const tHCIS_H4_CFG bte_hcisu_h4_cfg =
{
    USERIAL_PORT_1,
    USERIAL_BAUD_115200,
    USERIAL_DATABITS_8 | USERIAL_PARITY_NONE | USERIAL_STOPBITS_1
};
#endif /* HCISU_H4_INCLUDED */

/*****************************************************************************
**                        System Task Configuration                          *
******************************************************************************/

/* HCI transport task */
#ifndef BTE_HCI_STACK_SIZE
#define BTE_HCI_STACK_SIZE       0x2000         /* In bytes */
#endif

#define BTE_HCI_TASK_STR        ((INT8 *) "HCI")
UINT32 bte_hci_stack[(BTE_HCI_STACK_SIZE + 3) / 4];

/* bluetooth protocol stack (BTU) task */
#ifndef BTE_BTU_STACK_SIZE
#define BTE_BTU_STACK_SIZE       0x4000         /* In bytes */
#endif
#define BTE_BTU_TASK_STR        ((INT8 *) "BTU")
UINT32 bte_btu_stack[(BTE_BTU_STACK_SIZE + 3) / 4];

/* SBC_Encode_task */
#ifndef SBC_ENCODE_STACK_SIZE
#define SBC_ENCODE_STACK_SIZE 0x2000
#endif
#define SBC_ENCODE_TASK_STR   ((INT8 *) "SBC")
UINT32 sbc_encode_stack[(SBC_ENCODE_STACK_SIZE + 3) / 4];

/* Stack size for BTE application, serial port demo, and sample apps */
#ifndef BTE_APPL_STACK_SIZE
#define BTE_APPL_STACK_SIZE      0x1000         /* In bytes */
#endif
#ifndef BTE_APPL_TASK_STR
#define BTE_APPL_TASK_STR       ((INT8 *) "APPL")   /* Default Name */
#endif
UINT32 bte_appl_stack[(BTE_APPL_STACK_SIZE + 3) / 4];


#define PM_VOTE_VREG_WLAN_APP__BT ( 1 <<0)

UINT8  my_bd_addr[BD_ADDR_LEN] = {0x01,0x20,0x45,0xBE,0xab}; 

BOOLEAN bt_trace_protocol_active = FALSE;

BOOLEAN bte_hcisuInitialised = FALSE;
BOOLEAN btu_hcisuInitialised = FALSE; 
BOOLEAN appl_Initialised = FALSE;
BOOLEAN sbc_Initialised = FALSE;

/*****************************************************************************
**                          F U N C T I O N S                                *
******************************************************************************/
void BTE_EnableProtocolTrace(BOOLEAN enable)
{
    bt_trace_protocol_active = enable;
}

/*******************************************************************************
 * Function:           KI_HciTask
 * Parameters:      None
 * Returns:            Nothing
 * Description:       This task is the KI interface function for btu_task from BTE.
 *                         When the signal SIG_INITIALISE is send to the BTU_TASK_ID the task
 *                         btu_task from BTE is launched.
*******************************************************************************/
KI_ENTRY_POINT KI_HciTask (void);

KI_SINGLE_TASK (KI_HciTask, HCISU_QUEUE_ID, HCISU_TASK_ID)

KI_ENTRY_POINT KI_HciTask (void)
{
    SignalBuffer signal = kiNullBuffer;
    
    while(bte_hcisuInitialised == FALSE)
    {

        KiReceiveSignal(HCISU_QUEUE_ID, &signal);
        
        switch(*signal.type)
        {
        case SIG_INITIALISE:
            KiDestroySignal(&signal);
            APPL_TRACE_DEBUG0("KI_HciTask receives SIG_INITIALISE");

            bte_hcisuInitialised = TRUE; 
            //BtTrace("HciExtraTsk() initialize OK");

            /* Start Btu task */

            #if (defined(BTU_INCLUDED) && (BTU_INCLUDED == TRUE))
            BTE_BtuTaskInit();
            #endif

            /* hci task entry point */
            bte_hcisu_task(NULL);
            bte_hcisuInitialised = FALSE; 
            APPL_TRACE_ERROR0("HCI TASK ended!!!");
            break;
            
        default:
            APPL_TRACE_ERROR1("ERROR HciExtraTsk wrong KI Event %d!!", *signal.type);
            KiDestroySignal(&signal);
            break;	
        }
        
    }
}

/*******************************************************************************
 * Function:           KI_BtuTask
 * Parameters:      None
 * Returns:            Nothing
 * Description:       This task is the KI interface function for btu_task from BTE.
 *                         When the signal SIG_INITIALISE is send to the BTU_TASK_ID the task
 *                         btu_task from BTE is launched.
*******************************************************************************/
#if (defined(BTU_INCLUDED) && (BTU_INCLUDED == TRUE))
KI_ENTRY_POINT KI_BtuTask (void);

KI_SINGLE_TASK (KI_BtuTask, BTU_QUEUE_ID, BTU_TASK_ID)

KI_ENTRY_POINT KI_BtuTask (void)
{
    SignalBuffer signal = kiNullBuffer;
	
    while(btu_hcisuInitialised == FALSE)
    {
        KiReceiveSignal(BTU_QUEUE_ID, &signal);
        switch(*signal.type)
        {
        case SIG_INITIALISE:
            APPL_TRACE_DEBUG0("KI_BtuTask receives SIG_INITIALISE");
            KiDestroySignal(&signal);
            btu_hcisuInitialised = TRUE; 

#ifndef LGBX_INCLUDE
            #if (defined(BTUI_INCLUDED) && (BTUI_INCLUDED == TRUE))
                     APPL_TRACE_DEBUG0("KI_BtuTask call BTE_ApplTaskInit");

			BTE_ApplTaskInit();
          #endif
#endif

            btu_task(NULL);
            btu_hcisuInitialised = FALSE;

            APPL_TRACE_ERROR0("BTU TASK ended!!!");
            break;


        default:
            APPL_TRACE_ERROR1("ERROR BtuExtraTsk wrong KI Event %d!!", *signal.type);
            KiDestroySignal(&signal);
            break;
        }
        
    }
}
#endif
/*******************************************************************************
 * Function:           KI_SbcEncTask
 * Parameters:      None
 * Returns:            Nothing
 * Description:       This task is the KI interface function for btu_task from BTE.
 *                         When the signal SIG_INITIALISE is send to the BTU_TASK_ID the task
 *                         btu_task from BTE is launched.
*******************************************************************************/
KI_ENTRY_POINT KI_BteApplTask (void);
KI_SINGLE_TASK (KI_BteApplTask, BTE_APPL_QUEUE_ID, BTE_APPL_TASK_ID)

#if (defined (BTUI_INCLUDED) && (BTUI_INCLUDED == TRUE))           
KI_ENTRY_POINT KI_BteApplTask (void)
{
    //UINT8 task_id;
    SignalBuffer signal = kiNullBuffer;
    
    while(appl_Initialised == FALSE)
    {
        KiReceiveSignal(BTE_APPL_QUEUE_ID, &signal);
        switch(*signal.type)
        {
        case SIG_INITIALISE:
            KiDestroySignal(&signal);
            //BtTrace("HciExtraTsk() initialize OK");
            APPL_TRACE_DEBUG0("KI_BteApplTask receives SIG_INITIALISE");
            appl_Initialised  = TRUE; 
            #if (defined(SBC_ENCODER_INCLUDED) && (SBC_ENCODER_INCLUDED == TRUE))
            BTE_SBCTaskInit();
            #endif
            /* Start Btui task */
#ifndef LGBX_INCLUDE
            bte_appl_task(NULL);
            appl_Initialised  = FALSE; 
#endif /*LGBX_INCLUDE*/
            APPL_TRACE_ERROR0("APPL TASK ended!!!");
            //printf("ERROR HCI TASK ended!!!");
            break;
            
        default:
            APPL_TRACE_ERROR1("ERROR HciExtraTsk wrong KI Event %d!!", *signal.type);
            //printf("ERROR HciExtraTsk wrong KI Event %d!!", *signal.type);
            KiDestroySignal(&signal);
            break;	
        }
        
    }
}
#else
KI_ENTRY_POINT KI_BteApplTask (void)
{
}

void bte_appl_task(UINT32 param)
{
}

#endif
/*******************************************************************************
 * Function:           KI_SbcEncTask
 * Parameters:      None
 * Returns:            Nothing
 * Description:       This task is the KI interface function for btu_task from BTE.
 *                         When the signal SIG_INITIALISE is send to the BTU_TASK_ID the task
 *                         btu_task from BTE is launched.
*******************************************************************************/
#if ((defined(SBC_ENCODER_INCLUDED) && (SBC_ENCODER_INCLUDED == TRUE) ) ||(defined(PLATFORM_GB8_BT) && (PLATFORM_GB8_BT == TRUE)) )
KI_ENTRY_POINT KI_SbcEncTask (void);

KI_SINGLE_TASK (KI_SbcEncTask, SBC_ENCODE_QUEUE_ID, SBC_ENCODE_TASK_ID)

KI_ENTRY_POINT KI_SbcEncTask (void)
{
    SignalBuffer signal = kiNullBuffer;
    
    while(sbc_Initialised == FALSE)
    {
        KiReceiveSignal(SBC_ENCODE_QUEUE_ID, &signal);
        switch(*signal.type)
        {
        case SIG_INITIALISE:
            KiDestroySignal(&signal);
            APPL_TRACE_ERROR0("SBC TASK received SIG_INITIALISE");

            //BTUI_puts("SBCTask() initialize OK");
            sbc_Initialised = TRUE ;
            /* Start Btu task */
            sbc_encode_task(NULL);
            sbc_Initialised = FALSE ;

            APPL_TRACE_ERROR0("SBC TASK ended!!!");
            //printf("ERROR HCI TASK ended!!!");
            break;
            
        default:
            APPL_TRACE_ERROR1("ERROR SBCTsk wrong KI Event %d!!", *signal.type);
            //printf("ERROR HciExtraTsk wrong KI Event %d!!", *signal.type);
            KiDestroySignal(&signal);
            break;	
        }
        
    }
}
#endif

void BTE_HciTaskInit(void)
{
    SignalBuffer signal = kiNullBuffer;
    APPL_TRACE_ERROR0("BTE_HciTaskInit");
    KiCreateSignal(SIG_INITIALISE, sizeof(KiInitialiseTask), &signal);
    KiSendSignal (HCISU_TASK_ID, &signal);
}

#if (defined(BTU_INCLUDED) && (BTU_INCLUDED == TRUE))
void BTE_BtuTaskInit(void)
{
    SignalBuffer signal = kiNullBuffer;
    APPL_TRACE_ERROR0("BTE_BtuTaskInit"); 
    /* send an init signal to BTU_TASK to start it up */
    KiCreateSignal(SIG_INITIALISE, sizeof(KiInitialiseTask), &signal);
    KiSendSignal (BTU_TASK_ID, &signal);
}
#endif

#if (defined (BTUI_INCLUDED) && (BTUI_INCLUDED == TRUE))
void BTE_ApplTaskInit(void)
{
    SignalBuffer signal = kiNullBuffer;
    APPL_TRACE_ERROR0("BTE_ApplTaskInit"); 
    /* send an init signal to BTU_TASK to start it up */
    KiCreateSignal(SIG_INITIALISE, sizeof(KiInitialiseTask), &signal);
    KiSendSignal (BTE_APPL_TASK_ID, &signal);
}
#else
void BTE_ApplTaskInit(void)
{
     APPL_TRACE_ERROR0("BTE_ApplTaskInit 2"); 
}

#endif

#if (defined(SBC_ENCODER_INCLUDED) && (SBC_ENCODER_INCLUDED == TRUE))
void BTE_SBCTaskInit(void)
{
    SignalBuffer signal = kiNullBuffer;
    APPL_TRACE_ERROR0("BTE_SBCTaskInit"); 
    /* send an init signal to BTU_TASK to start it up */
    KiCreateSignal(SIG_INITIALISE, sizeof(KiInitialiseTask), &signal);
    KiSendSignal (SBC_ENCODE_TASK_ID, &signal);
}
#endif
/*******************************************************************************
**
** Function         BTE_InitHW
**
** Description      Initialize hardware.
**
** Returns          void
**
*******************************************************************************/
 
void BTE_InitHW(void)
{
    
#ifdef FEATURE_BCOM_BT
#if defined(BCM2035_UPDATE_PATCH_RAM) && (BCM2035_UPDATE_PATCH_RAM == TRUE)
 //   pm_vreg_set_level(PM_VREG_WLAN_ID,  MSME_LEVEL);// adjust to 1.85V
#else
#endif
   APPL_TRACE_ERROR0("BTE_InitHW"); 
   UPIO_Init(NULL);

   HCILP_WakeupBTDevice();

    /* initialize serial driver */
    USERIAL_Init(NULL); // uart initialization 
    #endif
}




/*******************************************************************************
**
** Function         BTE_CreateTasks
**
** Description      Create BTE tasks.
**
** Returns          void
**
*******************************************************************************/
static void BTE_CreateTasks (void)
{
    APPL_TRACE_DEBUG0(" BTE_CreateTasks");
#if defined(HCISU_H4_INCLUDED) && HCISU_H4_INCLUDED == TRUE
    /* Initialize pointer to function that sends hci commands and data to the transport */
    p_hcisu_if  = (tHCISU_IF *)&hcisu_h4;
    p_hcisu_cfg = (void *)&bte_hcisu_h4_cfg;
#endif  /* HCISU_H4_INCLUDED */

    /* Start the HCI Services task */
    GKI_create_task(bte_hcisu_task, HCISU_TASK, BTE_HCI_TASK_STR,
        (UINT16 *) ((UINT8 *)bte_hci_stack + BTE_HCI_STACK_SIZE),
        sizeof(bte_hci_stack));
#ifndef LGBX_INCLUDE      
#if (defined(BTUI_INCLUDED) && (BTUI_INCLUDED == TRUE))
    APPL_TRACE_DEBUG0("Create bte_appl_task");

    /* Create the BTE application task */
    GKI_create_task(bte_appl_task, BTE_APPL_TASK, BTE_APPL_TASK_STR,
                (UINT16 *) ((UINT8 *)bte_appl_stack + BTE_APPL_STACK_SIZE),
                sizeof(bte_appl_stack));
#endif
#endif

#if (defined(BTU_INCLUDED) && (BTU_INCLUDED == TRUE))
    /* Create BTU Task */
    GKI_create_task((TASKPTR)btu_task, BTU_TASK, BTE_BTU_TASK_STR,
                    (UINT16 *) ((UINT8 *)bte_btu_stack + BTE_BTU_STACK_SIZE),
                    sizeof(bte_btu_stack));
#endif

#if (defined(SBC_ENCODER_INCLUDED) && (SBC_ENCODER_INCLUDED == TRUE))
    /* Create SBC_Encode_Task */
    APPL_TRACE_DEBUG0("Create SBC ENCODE TASK");
    GKI_create_task((TASKPTR)sbc_encode_task, SBC_ENCODE_TASK,
                                 SBC_ENCODE_TASK_STR, (UINT16 *) ((UINT8 *)sbc_encode_stack +
                                 SBC_ENCODE_STACK_SIZE), sizeof(sbc_encode_stack));
#endif
}

/*******************************************************************************
**
** Function         BootEntry
**
** Description      BTE main function.
**
** Returns          nothing
**
*******************************************************************************/
BT_API int BootEntry( void )
{
    /* initialize hardware */
    // BTE_InitHW(); mpm

    /* initialize OS */
    GKI_init();

    /* enable interrupts */
    GKI_enable();

    /* (optionally) allocate memory for stack control blocks */
    BTE_LoadStack();

    /* Initialize BTE control block */
    BTE_Init();

    /* create tasks */
    BTE_CreateTasks();

    /* start tasks */
    GKI_run(0);

    BTE_HciTaskInit();
    return 0;
}


UINT32 sbc_encode_task(UINT32 param)
{
    UINT16 event;

    while (TRUE)
    {
        event = GKI_wait(0xFFFF, 0);
#if defined(BTA_AV_INCLUDED) && BTA_AV_INCLUDED == TRUE
        if (event & BTAPP_AA_TIMER_EVT_MASK)
        {
            bta_aa_co_timer_routine();
        }
#endif
        if (event & BT_EXIT_TASK_EVT)
        {
           break;
        }

    }
    APPL_TRACE_DEBUG0("OUT OF SBC TASK");
}


BOOLEAN bta_dm_co_get_compress_memory(tBTA_SYS_ID id, UINT8 **memory_p, UINT32 *memory_size)
 {
     return TRUE;
 }


