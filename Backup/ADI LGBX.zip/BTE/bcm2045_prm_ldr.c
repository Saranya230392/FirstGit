/********************************************************************************
**                                                                              *
**  Name        bcm2045_prm_ldr.c                                               *
**                                                                              *
**  Function    this file contains patch ram loader API source code             *
**                                                                              *
**                                                                              *
**  Copyright (c) 1999-2005, Broadcom Inc., All Rights Reserved.                *
**  Proprietary and confidential.                                               *
**                                                                              *
*********************************************************************************/
#include "target.h"
#include "hcidefs.h"
#include "btm_api.h"
#include "bcm2045_prm_int.h"
#include <string.h>

#include "gki.h"


#define BCM2045_PRM
#ifdef BCM2045_PRM
/* dest ram location */
#define BCM2045_DEST_RAM_LOCATION 0x00085D00
#define BCM2045_MINIDRV_2_PATCH_RAM_DELAY   (50)
#endif

/* 2045 patch ram control block */
static tBCM2045_PRM_CB bcm2045_prm_cb;

/* Vendor specified command complete callback */
static void bcm2045_prm_command_complete_cback(tBTM_VSC_CMPL *pData);

/* Send next patch of data */
static void bcm2045_prm_send_next_patch(void);

/* Launching RAM */
static void bcm2045_prm_launch_ram(void);

/* default minidriver tempo funcion */
#define BCM_2045_DELAY(milisec) GKI_delay(milisec)



#if (BCM2045_USE_DELAY == FALSE)
static void bcm2045_register_timer(UINT32 timeout_ms);
#ifndef BCM2045_REGISTER_TIMER
#define BCM2045_REGISTER_TIMER(timeout_ms) btu_register_timer(&(bcm2045_prm_cb.timer), \
                                                               BTU_TTYPE_USER_FUNC, \
                                                               (timeout_ms/1000)+1, (tBTU_TIMER_CALLBACK) bcm2045_timer_cback)
#endif
#endif

/*******************************************************************************
**
** Function         BCM2045_PrmInit
**
** Description      Register patch ram callback, start to send Download_Mini_Driver
**                  to controller to start the download process, if use internal patch, 
**                  it will start the download data process from the internal patch, else
**                  application need to provide the patch data 
** Input Param      p_cb - callback for download status
**                  use_internal_patch_data - if true patch data is built into code, 
**                                          - else application need to provide patch data
**                                          - by calling BCM2045_PRM_Load_Data                 
**
** Returns          TRUE if successful, otherwise FALSE
**                  
**
*******************************************************************************/
BOOLEAN BCM2045_PrmInit (tBCM2045_PRM_CBACK *p_cb,
                         BOOLEAN use_internal_patch_data)
{

    BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_API, "BCM2045_PRM_Init");
    
    memset(&bcm2045_prm_cb, 0, sizeof(tBCM2045_PRM_CB));
    
    if (use_internal_patch_data) 
    {
        bcm2045_prm_cb.p_patch_data = bcm2045_patchram;
        bcm2045_prm_cb.patch_length = bcm2045_patch_ram_length;
        if (bcm2045_prm_cb.patch_length == 0)
            return FALSE;
    }

    bcm2045_prm_cb.internal_patch = use_internal_patch_data;
    bcm2045_prm_cb.p_cb = p_cb;
    bcm2045_prm_cb.dest_ram = BCM2045_DEST_RAM_LOCATION;

    /* Put the BB in mini driver mode */
    
    BTM_VendorSpecificCommand(HCI_BRCM_DOWNLOAD_MINI_DRV, 0, NULL, 
                              (tBTM_CMPL_CB *) bcm2045_prm_command_complete_cback);
    bcm2045_prm_cb.state = BCM2045_PRM_ST_LOADING_MINIDRV; 
        
    return TRUE;
}

/*******************************************************************************
**
** Function         bcm2045_prm_command_complete_cback
**
** Description      This is the vendor specific comand complete event call back.
**
** Returns          void
**
*******************************************************************************/
static void bcm2045_prm_command_complete_cback(tBTM_VSC_CMPL *pData)
{    
    /* if it is not completed */
    if (pData->param_buf[0] != 0) {
        if (bcm2045_prm_cb.p_cb)
            (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_ABORT);
        return;
    }
    switch (bcm2045_prm_cb.state) 
    {
        case BCM2045_PRM_ST_LOADING_MINIDRV:
             if (!(pData->opcode == HCI_BRCM_DOWNLOAD_MINI_DRV))
             {
                  if (bcm2045_prm_cb.p_cb)
                      (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_ABORT);
                  return;
             }
             bcm2045_prm_cb.state = BCM2045_PRM_ST_LOADING_MINIDRV_DONE;
             BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_API, "Minidrv download completed");
             
#if (BCM2045_USE_DELAY == TRUE)
             BCM_2045_DELAY(BCM2045_MINIDRV_2_PATCH_RAM_DELAY);

             if (!bcm2045_prm_cb.internal_patch)
             {
                  if (bcm2045_prm_cb.p_cb)
                      (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_CONTINUE);
             }
             else
             {
                  bcm2045_prm_cb.state = BCM2045_PRM_ST_LOADING_DATA;
                  bcm2045_prm_send_next_patch();    
             }
#else
             bcm2045_register_timer( BCM2045_MINIDRV_2_PATCH_RAM_DELAY );
#endif
             break;
        case BCM2045_PRM_ST_LOADING_DATA:
             if (!(pData->opcode == HCI_BRCM_WRITE_RAM))
             {
                  if (bcm2045_prm_cb.p_cb)
                      (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_ABORT);
                  return;
             }
             if (bcm2045_prm_cb.tx_patch_length == bcm2045_prm_cb.patch_length)
             {
                 bcm2045_prm_cb.state = BCM2045_PRM_ST_LOADING_DATA_DONE;
                 /* For internal patch, if all patches are sent */
                 if (bcm2045_prm_cb.internal_patch) {
                     BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_API, 
                                "Internal patch download completed, starting launching ram");
                     bcm2045_prm_cb.state = BCM2045_PRM_ST_LAUNCHING_RAM;
                     bcm2045_prm_launch_ram();              
                 }
                 /* For external patch, send contiune to application back */
                 else 
                 {
                     BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_API, 
                                    "External patch piece down, wait for next piece");
                     bcm2045_prm_cb.dest_ram += bcm2045_prm_cb.patch_length;
                     if (bcm2045_prm_cb.p_cb)      
                         (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_CONTINUE);
                 }
             }  
             else 
             {
                 /* Have not complete this piece yet */
#if 0           
                 BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_API, 
                                    "Internal patch send next piece");
#endif
                 bcm2045_prm_send_next_patch();
             }
             break;
        case BCM2045_PRM_ST_LAUNCHING_RAM:
             if (!(pData->opcode == HCI_BRCM_LAUNCH_RAM))
             {
                  if (bcm2045_prm_cb.p_cb)
                      (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_ABORT);
                  return;
             }
             
             BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_API, 
                                    "Launch RAM successful");

#if (BCM2045_USE_DELAY == TRUE)
             BCM_2045_DELAY(BCM2045_END_DELAY);

             if (bcm2045_prm_cb.p_cb) 
                 (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_COMPLETE);
             memset(&bcm2045_prm_cb, 0, sizeof(tBCM2045_PRM_CB));
#else
             bcm2045_register_timer( BCM2045_END_DELAY );
#endif
             break;
        default:
             break;                    
    }
    return;
}

/*******************************************************************************
**
** Function         bcm2045_prm_send_next_patch
**
** Description      Send next patch of data: 250 bytes max
**
** Returns          void
**
*******************************************************************************/
static void bcm2045_prm_send_next_patch(void)
{
    UINT8   p_write_ram[260];
    UINT16  len, offset = bcm2045_prm_cb.tx_patch_length;

#if 0           /* Reduce amount of traces during patch download */
    BT_TRACE_2(TRACE_LAYER_HCI, TRACE_TYPE_API, 
                                    "bcm2045_prm_send_next_patch total len %d, sent len %d", 
                                     bcm2045_prm_cb.patch_length, bcm2045_prm_cb.tx_patch_length );
#endif

    len = (bcm2045_prm_cb.patch_length - bcm2045_prm_cb.tx_patch_length);

    if (len > MAX_PRM_LEN)
        len = MAX_PRM_LEN;

    /* Address in little endian order */
    p_write_ram[0] =  (bcm2045_prm_cb.dest_ram + offset)        & 0xFF;
    p_write_ram[1] = ((bcm2045_prm_cb.dest_ram + offset) >>  8) & 0xFF;
    p_write_ram[2] = ((bcm2045_prm_cb.dest_ram + offset) >> 16) & 0xFF;
    p_write_ram[3] = ((bcm2045_prm_cb.dest_ram + offset) >> 24) & 0xFF;

    memcpy (p_write_ram + 4, bcm2045_prm_cb.p_patch_data + offset, len);

    BTM_VendorSpecificCommand(HCI_BRCM_WRITE_RAM, (UINT8) (len+4), p_write_ram, 
                              (tBTM_CMPL_CB *) bcm2045_prm_command_complete_cback);
                              
    bcm2045_prm_cb.tx_patch_length += len;    

    return;
}
    

/*******************************************************************************
**
** Function         BCM2045_PrmLoadData
**
** Description      Download data to controller if application need to provide patch data.
**                  
** Input Param      p_patch_data            - pointer to patch data
**                  patch_data_len          - patch data len
**                  
** Returns          TRUE if successful, otherwise FALSE
**
*******************************************************************************/
BOOLEAN BCM2045_PrmLoadData (UINT8 *p_patch_data,
                               UINT16 patch_data_len)
{
    /* Only load data if loading minidri or data piece is done */
    if (bcm2045_prm_cb.state != BCM2045_PRM_ST_LOADING_MINIDRV_DONE
        && bcm2045_prm_cb.state != BCM2045_PRM_ST_LOADING_DATA_DONE)
        return FALSE;

    if (patch_data_len == 0)
        return FALSE;

    bcm2045_prm_cb.tx_patch_length = 0;
    bcm2045_prm_cb.p_patch_data = p_patch_data;
    bcm2045_prm_cb.patch_length = patch_data_len;
    
    bcm2045_prm_send_next_patch();
    bcm2045_prm_cb.state = BCM2045_PRM_ST_LOADING_DATA;

    BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_API, "BCM2045_PRM_Load_Data send next patch");

    return TRUE;
}

/*******************************************************************************
**
** Function         BCM2045_PrmLaunchRam
**
** Description      After all patches are download, lauch ram
** Input Param      
**
**
** Returns          TRUE if successful, otherwise FALSE
**
*******************************************************************************/
extern BOOLEAN BCM2045_PrmLaunchRam (void)
{
    /* Only launch ram if data piece is done */
    if (bcm2045_prm_cb.state != BCM2045_PRM_ST_LOADING_DATA_DONE)
        return FALSE;

    BT_TRACE_0(TRACE_LAYER_HCI, TRACE_TYPE_API, 
                                "Externl patch download completed, starting launching ram");
    bcm2045_prm_cb.state = BCM2045_PRM_ST_LAUNCHING_RAM;
    bcm2045_prm_launch_ram();
    

    return TRUE;
}

/*******************************************************************************
**
** Function         bcm2045_prm_launch_ram
**
** Description      Launch RAM 
**
** Returns          void
**
*******************************************************************************/
static void bcm2045_prm_launch_ram(void)
{ 
  //  UINT8 p_write_launch_ram[4] = {0x00, 0x08, 0x5D, 0x00};
    UINT8 p_write_launch_ram[4] = {0xFF, 0xFF, 0xFF, 0xFF};    
//    BCM_2045_DELAY(BCM2045_MINIDRV_2_PATCH_RAM_DELAY);
    BTM_VendorSpecificCommand(HCI_BRCM_LAUNCH_RAM, 4, p_write_launch_ram, 
                              (tBTM_CMPL_CB *) bcm2045_prm_command_complete_cback);
    return;
}


/*******************************************************************************
**
** Function         BCM2045_PRM_Get_State
**
** Description      get patch ram state info
** Input Param      
**
**
** Returns          patch ram state
**
*******************************************************************************/
extern UINT8 BCM2045_PRM_Get_State (void)
{
    return (bcm2045_prm_cb.state);
}

#if (BCM2045_USE_DELAY == FALSE)
/*******************************************************************************
**
** Function         bcm2045_timer_cback
**
** Description    Timer call back routine.
**
** Returns          void
**
*******************************************************************************/
void bcm2045_timer_cback(void *p_tle)
{
    switch(bcm2045_prm_cb.state)
    {
        case BCM2045_PRM_ST_LOADING_MINIDRV_DONE:
             if (!bcm2045_prm_cb.internal_patch)
             {
                  if (bcm2045_prm_cb.p_cb)
                      (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_CONTINUE);
             }
             else
             {
                  bcm2045_prm_cb.state = BCM2045_PRM_ST_LOADING_DATA;
                  bcm2045_prm_send_next_patch();    
             }
             break;

        case BCM2045_PRM_ST_LAUNCHING_RAM:
             if (bcm2045_prm_cb.p_cb) 
                 (bcm2045_prm_cb.p_cb)(BCM2045_PRM_STS_COMPLETE);
             memset(&bcm2045_prm_cb, 0, sizeof(tBCM2045_PRM_CB));
            break;

        default:
            BT_TRACE_1(TRACE_LAYER_HCI, TRACE_TYPE_ERROR, "ERROR bcm2045_timer_cback wrong state: %d",
                       bcm2045_prm_cb.state);
            break;
    }
}

/*******************************************************************************
**
** Function         bcm2045_register_timer  
**
** Description      register a timer callback.
**
** Input            timeout_ms: time out in milisecond
**
** Returns          void
**
*******************************************************************************/
static void bcm2045_register_timer( UINT32 timeout_ms )
{    
    /*  */
    BCM2045_REGISTER_TIMER(timeout_ms);
}
#endif






