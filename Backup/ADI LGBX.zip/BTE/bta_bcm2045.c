/*****************************************************************************
**
**  Name:           bta_bcm2045.c
**
**  Description:    This is the common code (used by both serial MMI and
**                  phone MMI) for starting up the core stack.
**
**  Copyright (c) 2004, Broadcom Corp., All Rights Reserved.
**
*****************************************************************************/
#include "target.h"
#include "gki.h"
#include "bt_types.h"

#include "userial.h"
#include "hcilp.h"
#include "hcisu.h"
#include "hcis_h4.h"
#include "btu.h"
#include "btm_int.h"
#include "upio.h"
#include "btapp_flash.h"

#include "bta_api.h"
#include "bta_sys.h"
#include "bta_sys_int.h"
#if (defined(BCM2045_PRM_INCLUDED) && (BCM2045_PRM_INCLUDED==TRUE))
#include "bta_prm_api.h"
#include "bcm2045_prm_int.h"
#endif
#include <string.h>



/*******************************************************************************
* Constants
*******************************************************************************/

/* Parameters for HCI_UPDATE_UART_BAUD_RATE */
#define HCI_UPDATE_UART_BAUD_RATE               (0x0018 | HCI_GRP_VENDOR_SPECIFIC)
#define HCI_UPDATE_UART_BAUD_RATE_PARAM_LEN     6
typedef struct tagBAUD_REG_t {
    UINT8 DHBR;
    UINT8 DLBR;
    UINT8 ExplicitBaudRate0;
    UINT8 ExplicitBaudRate1;
    UINT8 ExplicitBaudRate2;
    UINT8 ExplicitBaudRate3;
} BAUD_REG_t;

const BAUD_REG_t baud_rate_regs[10] = { { 0x00, 0x00, 0x00, 0xc2, 0x01, 0x00 } /* 0x0001C200 =  115200 */
                                       , { 0x00, 0x00, 0x00, 0x84, 0x03, 0x00 } /* 0x00038400 = 230400 */
                                       , { 0x00, 0x00, 0x00, 0x08, 0x07, 0x00 }/* 0x00070800 = 460800 */
                                       , { 0x00, 0x00, 0x00, 0x10, 0x0E, 0x00 }/* 0x000E1000 = 921600 */
                                       , { 0x00, 0x00, 0x60, 0xe3, 0x16, 0x00 }/* 0x0016E360 = 1500000 */
                                       , { 0x00, 0x00, 0x00, 0x20, 0x1C, 0x00 }/* 0x001C2000 = 1843200 */
                                       , { 0x00, 0x00, 0x80, 0x84, 0x1E, 0x00 }/* 0x001E8480 = 2000000 */
                                       , { 0x00, 0x00, 0xa0, 0x25, 0x26, 0x00 }/* 0x002625A0 = 2500000 */
                                       , { 0x00, 0x00, 0xc0, 0xc6, 0x2d, 0x00 }/* 0x002DC6C0 = 3000000 */
                                       , { 0x00, 0x00, 0x50, 0x97, 0x31, 0x00 }/* 0x00319750 =3250000 */
                                       }; 

/* Parameters for HCI_WRITE_PAGE_SCAN_REPETITION_MODE */
#define HCI_WRITE_PAGE_SCAN_REPETITION_MODE             (0x0005 | HCI_GRP_VENDOR_SPECIFIC)
#define HCI_WRITE_PAGE_SCAN_REPETITION_MODE_PARAM_LEN   1
#define HCI_WRITE_PAGE_SCAN_REPETITION_MODE_R0          0
#define HCI_WRITE_PAGE_SCAN_REPETITION_MODE_R1          1
#define HCI_WRITE_PAGE_SCAN_REPETITION_MODE_R2          2

/* Parameters for HCI_WRITE_BD_ADDR */
#define HCI_WRITE_BD_ADDR                               (0x0001 | HCI_GRP_VENDOR_SPECIFIC)
#define HCI_WRITE_BD_ADDR_PARAM_LEN                     (BD_ADDR_LEN)


/* Post patch-ram delay before sending next HCI command (in milliseconds) */
#define BTA_PATCH_RAM_POST_DOWNLOAD_DELAY         (250)

#if defined BCM2045_PRM_INCLUDED && BCM2045_PRM_INCLUDED == TRUE
#define BCM_DOWNLOAD_PATCHRAM           TRUE
#else
#define BCM_DOWNLOAD_PATCHRAM           FALSE
#endif

//#define BCM_DOWNLOAD_PATCH_AT_MAXRATE  (TRUE && BCM_DOWNLOAD_PATCHRAM)
#define BCM_DOWNLOAD_PATCH_AT_MAXRATE  FALSE

#define BCM_UPDATE_BAUDRATE     TRUE
//#define BCM_UPDATE_BAUDRATE     FALSE

#if defined (PLATFORM_LEMANS_BT) && (PLATFORM_LEMANS_BT == TRUE)
#define BCM_BAUDRATE USERIAL_BAUD_921600
#elif defined (PLATFORM_GB8_BT) && (PLATFORM_GB8_BT == TRUE)
#define BCM_BAUDRATE USERIAL_BAUD_460800
#if (defined(BCM_UPDATE_BAUDRATE) && (BCM_UPDATE_BAUDRATE == TRUE))
extern void BtUartCleanupAfterChangeBaudrate (void);
#endif
#elif defined (PLATFORM_GB5_BT) && (PLATFORM_GB5_BT == TRUE)
#define BCM_BAUDRATE USERIAL_BAUD_921600
#if (defined(BCM_UPDATE_BAUDRATE) && (BCM_UPDATE_BAUDRATE == TRUE))
extern void BtUartCleanupAfterChangeBaudrate (void);
#endif
#endif

/* New USERIAL configuration after baud rate change */
BOOLEAN hcisu_h4_open(void *p_cfg);
extern tHCIS_H4_CFG bte_hcisu_h4_cfg;

/* Counter for hci_reset attempts */
UINT32 reset_attempt_count = 0;
#define RESET_ATTEMPT_MAX   4

extern tHCISU_H4_CB hcisu_h4_cb;


/*******************************************************************************
*   Function Prototypes
*******************************************************************************/
void BTA_Bcm2045EnableHostWakeInterrupt(BOOLEAN enable);
void BTA_Bcm2045GetStoredBDA(UINT8 *p_bda);
void bta_bcm2045_patch_ram_cback(tBTA_STATUS status);

void bta_bcm_2045_write_bda_cback(void *p);
void bta_bcm2045_update_uart_baud_rate_cback(void *p);
void bta_bcm2045_update_baud_rate(tBTM_CMPL_CB *p_cb,UINT8 NewBaudRate);

void BTA_Bcm2045UpdateBDA(void);


/*******************************************************************************
*   Static variables
*******************************************************************************/
static BOOLEAN bta_is_first_bda_try = TRUE;


/*******************************************************************************
 **
 ** Function        BTA_Bcm2045EnableHostWakeInterrupt
 **
 ** Description     Call platform specific function for enabling HOST_WAKE
 **                 interrupts.
 **
 ** Returns         void
 *******************************************************************************/
void BTA_Bcm2045EnableHostWakeInterrupt(BOOLEAN enable)
{
#if 0
    if (enable)
        SetupGPIO_HostWakeup();
    else
        SetupGPIO_HostShutdown();
#endif
}


/*******************************************************************************
 **
 ** Function        BTA_Bcm2045Stop
 **
 ** Description     Shutdown the bluetooth chip (put it in the lowest power
 **                 consumption mode)
 **
 ** Returns         void
 *******************************************************************************/
void BTA_Bcm2045Stop(void)
{
#if 0
    /* If using B2, then deassert vreg ctl */
    UPIO_Set(UPIO_GENERAL, BCM2045_VREG_CTL, UPIO_OFF);
    /* Turn off UART to save power */
    BTA_Bcm2045DisableHostUart();
#endif
}

/*******************************************************************************
 **
 ** Function        BTA_Bcm2045PowerCycle
 **
 ** Description     Power cycle the 2045
 **
 ** Returns         void
 *******************************************************************************/
void BTA_Bcm2045PowerCycle(void)
{
#if 0
    /* Power down */
    UPIO_Set(UPIO_GENERAL, BCM2045_VREG_CTL, UPIO_OFF);
    GKI_delay(20);

    /* Power up, make sure BT_RESET is high */
    UPIO_Set(UPIO_GENERAL, BCM2045_VREG_CTL, UPIO_ON);
    UPIO_Set(UPIO_GENERAL, BCM2045_BT_RESET, UPIO_ON);
#endif
}


/*******************************************************************************
 **
 ** Function        BTA_Bcm2045Restart
 **
 ** Description     Restart bluetooth after BTA_Bcm2045Stop.
 **
 ** Returns         void
 *******************************************************************************/
void BTA_Bcm2045Restart(void)
{
#if 0
    UINT16 temp;

    /* Power down the BT chip */
    UPIO_Set(UPIO_GENERAL, BCM2045_VREG_CTL, UPIO_OFF);
 
    /* Restore serial port to power-up baud rate of 115k */
    /* Close HCI port */
    USERIAL_Close(USERIAL_PORT_1);
 
    /* Enable UART C in case it was disabled */
    BTA_Bcm2045EnableHostUart();
    /* UART workaround: reset uart mode to NORMAL, in case it is currently in FAST mode */
    /* (will eventually be done in uart driver) */
    /* Clear BCR_REG    (0x0887000F) bit 2 to 0 */
    temp = *((UINT16 *)(0x0887000E));
    temp &= 0xFFFB;
    *((UINT16 *)(0x0887000E)) = temp;

    hcisu_h4_open((void *)&bte_hcisu_h4_cfg);

    /* Power up the BT chip - be sure all the signals are ON */
    UPIO_Set(UPIO_GENERAL, BCM2045_VREG_CTL, UPIO_ON);
    UPIO_Set(UPIO_GENERAL, BCM2045_BT_RESET, UPIO_ON);
    UPIO_Set(UPIO_GENERAL, BCM2045_BT_WAKE, UPIO_ON);   

    UPIO_Init(NULL);    
    /* Allow hardware to reset */
    GKI_delay(20);
#endif
}
#define VSC_HCI_CMD_SET_LOC_FEATURES_CMD         (0x000B | HCI_GRP_VENDOR_SPECIFIC)
#define VSC_HCI_CMD_SET_LOC_FEATURES_CMD_LEN     (HCI_NUM_FEATURE_BYTES)
tBTM_STATUS BCM20XX_set_loc_features(UINT8 *set_features, tBTM_CMPL_CB *set_loc_features_cback)
{
    if(set_features == NULL)
    {
       APPL_TRACE_DEBUG0("BCM20XX_set_loc_features : set_features is NULL !");        
        return BTM_ILLEGAL_VALUE;
    }
    else
    {
            APPL_TRACE_DEBUG4("BCM20XX_set_loc_features : [ 0x%02X 0x%02X 0x%02X 0x%02X",   set_features[0], set_features[1], set_features[2], set_features[3]);
            APPL_TRACE_DEBUG4("BCM20XX_set_loc_features :   0x%02X 0x%02X 0x%02X 0x%02X ]", set_features[4], set_features[5], set_features[6], set_features[7]);        
            return ( BTM_VendorSpecificCommand(VSC_HCI_CMD_SET_LOC_FEATURES_CMD,
                                               VSC_HCI_CMD_SET_LOC_FEATURES_CMD_LEN,
                                               set_features, NULL));
    }
}

void bcm_local_features(UINT8 *loc_features)
{

    memcpy(loc_features, btm_cb.devcb.local_features, HCI_NUM_FEATURE_BYTES);
    
}
/*******************************************************************************
**
** Function         bte_set_loc_features_cback
**
** Description      HCI VS SET_LOC_FEATURES_CMD cmd complete function.
**
** Returns          void
**
** Date             Nov.05.2005
**
*******************************************************************************/
void bte_set_loc_features_cback(void *param)
{
    UINT8 *vsc_result = (UINT8 *)(param);

    
    APPL_TRACE_DEBUG3("set_loc_features_cback: op_code[0x%02X%02X] result[0x%x]", 
                       *(vsc_result+1), *(vsc_result+0), *(vsc_result+4));
                   
}
/*******************************************************************************
**
 ** Function         bte_set_loc_features
 **
 ** Description      This function should be called DISABLE purpose ONLY!!!
 **
 **
 ** Returns          void
 **
 *******************************************************************************/
tBTM_STATUS bte_set_loc_features(UINT8 *data, tBTM_CMPL_CB *set_loc_features_cback)
{
    UINT8 i;
    UINT8 set_features[VSC_HCI_CMD_SET_LOC_FEATURES_CMD_LEN];
    
    bcm_local_features( set_features );
        APPL_TRACE_DEBUG4("bte_set_loc_features : [ 0x%02X 0x%02X 0x%02X 0x%02X",   set_features[0], set_features[1], set_features[2], set_features[3]);
        APPL_TRACE_DEBUG4("bte_set_loc_features :   0x%02X 0x%02X 0x%02X 0x%02X ]", set_features[4], set_features[5], set_features[6], set_features[7]);        
        
    
    for(i=0; i<VSC_HCI_CMD_SET_LOC_FEATURES_CMD_LEN; i++)
    {
       set_features[i] = set_features[i] & data[i];
           set_features[i] = data[i];
        
        APPL_TRACE_DEBUG2("BCM2048_set_loc_features : features[%d] = 0x%02X", i, set_features[i]);
       
    }
        

    return ( BTM_VendorSpecificCommand(VSC_HCI_CMD_SET_LOC_FEATURES_CMD,
                                       VSC_HCI_CMD_SET_LOC_FEATURES_CMD_LEN,
                                       set_features, 
                                       ((set_loc_features_cback != NULL)? set_loc_features_cback: bte_set_loc_features_cback)) );
}
/*******************************************************************************
 **
 ** Function        bta_bcm_2045_write_bda_cback
 **
 ** Description     Called when Command Complete event is received for
 **                 HCI_WRITE_BD_ADDR.
 **
 ** Returns         void
 *******************************************************************************/
void bta_bcm_2045_write_bda_cback(void *p)
{

    tBTM_VSC_CMPL *p_vsc_result;
    tUSERIAL_IOCTL_DATA data; 

    if(p!=NULL)
    {
        p_vsc_result = (tBTM_VSC_CMPL *) p;
        if(p_vsc_result->param_len>0 )
        {
            if(p_vsc_result->param_buf[0] == HCI_ERR_UNSPECIFIED )
            {
                APPL_TRACE_DEBUG0("[BT] BCM2045 failed to change BD address");
                data.baud = USERIAL_BAUD_115200;
        
                    USERIAL_Ioctl(USERIAL_PORT_1, USERIAL_OP_BAUD_RD, &data);
    	         APPL_TRACE_DEBUG1("[BT] BCM2045 Actual platform Baudrate %d",data.baud);
    	         if(data.baud != BCM_BAUDRATE)
    	         {
    		      APPL_TRACE_DEBUG0("[BT] BCM2045 failed to change PLATFORM BAUDRATE");
    		      return;
    	          }
    
                 if( bta_is_first_bda_try == TRUE )
                 {
                     GKI_delay(10);
                     //bta_is_first_bda_try = FALSE;
                     bta_bcm2045_patch_ram_cback(BTA_SUCCESS);
                 }
                 else
                     bta_is_first_bda_try = TRUE;
                 return;
            }
        }
    }
/* finish reset */

#if (defined(HCILP_INCLUDED) && (HCILP_INCLUDED==TRUE))
     /* Enable LP mode */
     HCILP_Enable(TRUE);
#endif

     BTM_ContinueReset( );

}

/*******************************************************************************
 **
 ** Function        BTA_Bcm2045GetStoredBDA
 **
 ** Description     Read the Bdaddr stored in NV ram.
 **                 
 **
 ** Returns         void
 *******************************************************************************/
void BTA_Bcm2045GetStoredBDA(UINT8 *p_bda)    
{
    const char bta_temp_bda[BD_ADDR_LEN] = {0x20, 0x45, 0x44, 0x33, 0x22, 0x11};      /* Little endian format */
    memcpy(p_bda, bta_temp_bda, BD_ADDR_LEN);
}



/*******************************************************************************
 **
 ** Function        BTA_Bcm2045UpdateBDA
 **
 ** Description     Read the BdAddr in NV ram and send it to the 2045.
 **                 
 **                 
 ** Returns         void
 *******************************************************************************/
void BTA_Bcm2045UpdateBDA(void)
{
    int i;
    UINT8 p_bda[BD_ADDR_LEN];
    UINT8 bda_le[BD_ADDR_LEN];  /* bda in little endian format */
    
    APPL_TRACE_DEBUG0("read BT Device Address in flash...\n");

    /* Read from storage */
    BTA_Bcm2045GetStoredBDA(p_bda);
    APPL_TRACE_DEBUG6("[BT] Device Address %02X-%02x-%02x-%02x-%02x-%02x\n",
        p_bda[0], p_bda[1], p_bda[2], p_bda[3], p_bda[4], p_bda[5]);

    /* Convert to little endian as required by VS command */
    for (i=0; i<BD_ADDR_LEN; i++)
        bda_le[i] =p_bda[BD_ADDR_LEN-i-1];

    /* Send VS command to set BDA */
    BTM_VendorSpecificCommand(  HCI_WRITE_BD_ADDR,
                                HCI_WRITE_BD_ADDR_PARAM_LEN, 
                                bda_le, 
                                bta_bcm_2045_write_bda_cback);
}


/*******************************************************************************
 **
 ** Function        bta_bcm2045_update_uart_baud_rate_cback
 **
 ** Description     Called when Command Complete event is received for
 **                 HCI_UPDATE_UART_BAUD_RATE. (2045's HCI baud rate has changed)
 **
 ** Returns         void
 *******************************************************************************/
static BOOLEAN bta_is_first_baudrate_try = TRUE;
void bta_bcm2045_update_uart_baud_rate_cback(void *p)
{
    tBTM_VSC_CMPL *p_vsc_result;
    tUSERIAL_IOCTL_DATA data;       

    if( p != NULL )
    {
        p_vsc_result = (tBTM_VSC_CMPL *) p;
        if(p_vsc_result->param_len>0 )
        {
            if(p_vsc_result->param_buf[0] == HCI_ERR_UNSPECIFIED )
            {
                APPL_TRACE_DEBUG0("[BT] BCM2045 failed to change baud rate");
                if( bta_is_first_baudrate_try == TRUE )
                {
                    bta_is_first_baudrate_try = FALSE;
                    GKI_delay(50);
                    bta_bcm2045_update_baud_rate(bta_bcm2045_update_uart_baud_rate_cback, BCM_BAUDRATE);
                }
                else
                    bta_is_first_baudrate_try = TRUE;
                return;
            }
        }
    }
    bta_is_first_baudrate_try = TRUE;        
    APPL_TRACE_DEBUG1("[BT] BCM2045 baud rate changed succesfuly to %d", BCM_BAUDRATE);
    
    data.baud = BCM_BAUDRATE;  
    USERIAL_Ioctl(USERIAL_PORT_1, USERIAL_OP_BAUD_WR, &data);
#if defined (PLATFORM_GB8_BT) && (PLATFORM_GB8_BT == TRUE)
    GKI_delay(10);

    BtUartCleanupAfterChangeBaudrate();
    GKI_delay(10);
#endif
    BTA_Bcm2045UpdateBDA();

}


/*******************************************************************************
 **
 ** Function        bta_bcm2045_patch_ram_cback
 **
 ** Description     Called when Command Complete event is received for
 **                 HCI_CMD_DOWNLOAD_MINI_DRV. (Patch ram downloaded)
 **                 
 ** Returns         void
 *******************************************************************************/
void bta_bcm2045_patch_ram_cback(tBTA_STATUS status)
{
#if (defined(BCM_UPDATE_BAUDRATE) && (BCM_UPDATE_BAUDRATE == TRUE))
     tUSERIAL_IOCTL_DATA data;  
#endif

	if (status == BTA_SUCCESS)
	{
	    APPL_TRACE_DEBUG0("[BT] patch ram updated - success");
    
    GKI_delay(BTA_PATCH_RAM_POST_DOWNLOAD_DELAY);
	}
	else 
	    APPL_TRACE_DEBUG0("[BT] patch ram updated - fail");

#if (defined(BCM_UPDATE_BAUDRATE) && (BCM_UPDATE_BAUDRATE== TRUE))
#if (defined (PLATFORM_LEMANS_BT) && (PLATFORM_LEMANS_BT == TRUE))
    #if (defined(BCM2045_PRM_INCLUDED) && (BCM2045_PRM_INCLUDED== TRUE))
     /* After downloading patch, the 2045's baud rate is reset to 115kbps. Need to set host baud rate to match. */
    data.baud = USERIAL_BAUD_115200;
    USERIAL_Ioctl(USERIAL_PORT_1, USERIAL_OP_BAUD_WR, &data);
	
    APPL_TRACE_DEBUG1("[BT] BCM2045 baud rate updated succesfuly to %d", USERIAL_BAUD_115200);
    #endif
#endif
    bta_bcm2045_update_baud_rate(bta_bcm2045_update_uart_baud_rate_cback, BCM_BAUDRATE);
#else
   BTA_Bcm2045UpdateBDA();
#endif
}


#if (defined(BCM_DOWNLOAD_PATCHRAM) && (BCM_DOWNLOAD_PATCHRAM == TRUE))
/*******************************************************************************
 **
 ** Function        bta_bcm2045_patchDownload_baud_rate_cback
 **
 ** Description     Called when Command Complete event is received for
 **                 HCI_UPDATE_UART_BAUD_RATE. (2045's HCI baud rate has changed)
 **
 ** Returns         void
 *******************************************************************************/
static BOOLEAN bta_is_first_download_baudrate_try = TRUE;
void bta_bcm2045_patchDownload_baud_rate_cback(void *p)
{
    tBTM_VSC_CMPL *p_vsc_result;
    tUSERIAL_IOCTL_DATA data;       

    if( p != NULL )
    {
        p_vsc_result = (tBTM_VSC_CMPL *) p;
        if(p_vsc_result->param_len>0 )
        {
            if(p_vsc_result->param_buf[0] == HCI_ERR_UNSPECIFIED )
            {
                APPL_TRACE_DEBUG0("[BT] BCM2045 failed to change Download baud rate to 460K");
                if( bta_is_first_download_baudrate_try == TRUE )
                {
                    bta_is_first_download_baudrate_try = FALSE;
                    GKI_delay(50);
                    bta_bcm2045_update_baud_rate(bta_bcm2045_patchDownload_baud_rate_cback, BCM_BAUDRATE);//USERIAL_BAUD_460800);
                }
                else
                    bta_is_first_download_baudrate_try = TRUE;
                return;
            }
        }
    }
    bta_is_first_download_baudrate_try = TRUE;        
    APPL_TRACE_DEBUG0("[BT] BCM2045 download  baud rate changed to 921K");
   
    data.baud = BCM_BAUDRATE;
    
    USERIAL_Ioctl(USERIAL_PORT_1, USERIAL_OP_BAUD_WR, &data);
#if (defined(BCM2045_PRM_INCLUDED) && (BCM2045_PRM_INCLUDED==TRUE))
    APPL_TRACE_DEBUG1("Patch RAM version: %s", bcm2045_patch_version);
    BTA_PatchRam(bta_bcm2045_patch_ram_cback,NULL, 0);        
#endif
}

#endif
 
/*******************************************************************************
 **
 ** Function        bta_bcm2035_update_baud_rate
 **
 ** Description     Increase baud rate to 920 kbps
 **                 
 ** Returns         void
 *******************************************************************************/
void bta_bcm2045_update_baud_rate(tBTM_CMPL_CB *p_cb,UINT8 NewBaudRate )
{

    APPL_TRACE_DEBUG1("[BT] BCM2045 try to change baud rate to %d",NewBaudRate);
    /* Increase HCI baud rate to 920 kbps */
    BTM_VendorSpecificCommand(  HCI_UPDATE_UART_BAUD_RATE,
                                HCI_UPDATE_UART_BAUD_RATE_PARAM_LEN, 
                                (UINT8 *) &(baud_rate_regs[NewBaudRate -USERIAL_BAUD_115200]), p_cb);
}


/*******************************************************************************
 **
 ** Function        bta_brcm2045_dev_init
 **
 ** Description     Platform-specific intialization routine. Called after
 **                 HCI_RESET command complete
 **
 ** Returns         void
 *******************************************************************************/
void bta_brcm2045_dev_init(void)
{
    /* Reset successful. Set reset_attempt back to 0 */
    reset_attempt_count = 0;

#if (defined(BCM_DOWNLOAD_PATCH_AT_MAXRATE) && (BCM_DOWNLOAD_PATCH_AT_MAXRATE == TRUE))
    /* Increase baud rate before downloading patch ram */
    bta_bcm2045_update_baud_rate(bta_bcm2045_patchDownload_baud_rate_cback, BCM_BAUDRATE);
#else
    #if (defined(BCM_DOWNLOAD_PATCHRAM) && (BCM_DOWNLOAD_PATCHRAM == TRUE))
    /* Download the patch now */
    BTA_PatchRam(bta_bcm2045_patch_ram_cback,NULL, 0);
    #else
    bta_bcm2045_patch_ram_cback(BTA_SUCCESS);
    #endif
#endif
}


/*******************************************************************************
 **
 ** Function        bta_brcm2045_reattempt_reset_check
 **
 ** Description     Called when HCI_RESET has failed.
 **                 Increment reset attempt counter. If max count is exceeded,
 **                 then return FALSE to indicate that we should not
 **                 attempt any more HCI_RESETs.
 **
 ** Returns         TRUE if attempt count is below the maximum
 **
 *******************************************************************************/
BOOLEAN bta_brcm2045_reattempt_reset_check(void)
{
    /* Increment reset attempt counter */
    reset_attempt_count++;

    /* If attempt threshold not exceeded yet, then return TRUE */
    return (reset_attempt_count<RESET_ATTEMPT_MAX);
}

