/*****************************************************************************
** 
**  Name    upio.c
** 
**  Description
**      Definitions for UPIO driver
**
**  Copyright (c) 2001-2006, WIDCOMM Inc., All Rights Reserved.
**  WIDCOMM Bluetooth Core. Proprietary and confidential.
*****************************************************************************/
#include "target.h"
#include "upio.h"
#if defined(PLATFORM_LEMANS_BT) && (PLATFORM_LEMANS_BT == TRUE)
#include "pdgpio.h"
#include "pdgpio500.h"
#include "pdgpioassign500.h"
#elif (defined (PLATFORM_GB8_BT) && (PLATFORM_GB8_BT == TRUE)) || \
      (defined (PLATFORM_GB5_BT) && (PLATFORM_GB5_BT == TRUE))
#include "dlgpio.h"
#endif
#include "l1btif.h"

#define UPIO_NUMBER           2     /* HCILP_BT_WAKE_GPIO and HCILP_HOST_WAKE_GPIO */
static INT32 Lge_upio[UPIO_NUMBER];


/*****************************************************************************
**
** Function         UPIO_Init
**
** Description
**      Initialize the GPIO service.
**      This function is typically called once upon system startup.  
**
** Returns          nothing
**
*****************************************************************************/
UDRV_API void UPIO_Init(void *p_cfg)
{
	Lge_upio[HCILP_BT_WAKE_GPIO] = M_DLGpioLine(GPIO_BT_WAKEUP);
    	Lge_upio[HCILP_HOST_WAKE_GPIO] = M_DLGpioLine(GPIO_BT_INT);
}


/*****************************************************************************
**
** Function         UPIO_Set
**
** Description
**      This function sets one or more GPIO devices to the given state.
**      Multiple GPIOs of the same type can be masked together to set more
**      than one GPIO. This function can only be used on types UPIO_LED and
**      UPIO_GENERAL.
**
** Input Parameters:
**      type    The type of device.
**      pio     Indicates the particular GPIOs.
**      state   The desired state.
**
** Output Parameter:
**      None.
**
** Returns:
**      None.
**
*****************************************************************************/
UDRV_API void UPIO_Set(tUPIO_TYPE type, tUPIO pio, tUPIO_STATE state)
{
	if(state == UPIO_ON)
    {
        PdGpioAssertLine(Lge_upio[pio]);		
    }
    else if(state == UPIO_OFF)
    {
        PdGpioDeassertLine(Lge_upio[pio]);
    }
    else
    {
        APPL_TRACE_ERROR0("UPIO_Set ERROR - UPIO_TOGGLE not managed");
    }
}


/*****************************************************************************
**
** Function         UPIO_Read
**
** Description
**      Read the state of a GPIO. This function can be used for any type of
**      device. Parameter pio can only indicate a single GPIO; multiple GPIOs
**      cannot be masked together.
**
** Input Parameters:
**      Type:	The type of device.
**      pio:    Indicates the particular GUPIO.
**
** Output Parameter:
**      None.
**
** Returns:
**      State of GPIO (UPIO_ON or UPIO_OFF).
**
*****************************************************************************/
UDRV_API tUPIO_STATE UPIO_Read(tUPIO_TYPE type, tUPIO pio)
{
    tUPIO_STATE state;
	
    if(pio == HCILP_HOST_WAKE_GPIO)
    {
        state =PdGpioReadInputLine(Lge_upio[HCILP_HOST_WAKE_GPIO]);
		
    }else if (pio == HCILP_BT_WAKE_GPIO)
    {
        state =PdGpioReadOutputLine(Lge_upio[HCILP_BT_WAKE_GPIO]);
    }
    else
    {
        APPL_TRACE_ERROR0("ERROR  UPIO_Read - IO not managed - return UPIO_TOGGLE");
        return(UPIO_TOGGLE);	 
    }

    return(state ? UPIO_ON : UPIO_OFF);	 
}


/*****************************************************************************
**
** Function         UPIO_Config
**
** Description      - Configure GPIOs of type UPIO_GENERAL as inputs or outputs
**                  - Configure GPIOs to be polled or interrupt driven
**
**                  Currently only support polled GPIOs.
**
** Input Parameters:
**      type    The type of device.
**      pio     Indicates the particular GPIOs.
**      config
**      cback
**
** Output Parameter:
**      None.
**
** Returns:
**      None.
**
*****************************************************************************/
UDRV_API void UPIO_Config(tUPIO_TYPE type, tUPIO pio, tUPIO_CONFIG config, tUPIO_CBACK *cback)
{
}


/*****************************************************************************
**
** Function         UPIO_Feature
**
** Description 
**      Checks whether a feature of the pio API is supported
**
** Input Parameter:
**      feature     The feature to check
**
** Output Parameter:
**      None.
**
** Returns:
**      TRUE if feature is supported, FALSE if it is not.
**
*****************************************************************************/
UDRV_API BOOLEAN UPIO_Feature(tUPIO_FEATURE feature)
{
}


