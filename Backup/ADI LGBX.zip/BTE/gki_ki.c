/****************************************************************************
**
**  Name        gki_ki.c
**
**  Function    this file Gki functions specific to WIN_32
**
**
**  Copyright (c) 1999-2006, WIDCOMM Inc., All Rights Reserved.
**  Proprietary and confidential.
**
*****************************************************************************/

#include <string.h>


//#include <Config.h>
//#include "l1timers.h"
#include "kernel.h"
#include "gki_int.h"
#include "target.h"
#include "system.h"
#include "kioslow.h"
#include "ki_event.h"
#include "kiamxos.h"
#include "bt_trace.h"
#if defined(UPGRADE_500_Platform)
#include "dl500tick.h"
#endif
#if defined(UPGRADE_430_Platform)
#include "dl430delay.h"
#endif
#include "lgebttimers.h"
#include "l1timers.h"

#if (GKI_MAX_TASKS > 16)
#error Number of gki tasks out of range (16 Max)!
#endif

/**********************************************************************
** specific definitions
*/

/* disable BT related interrupt only */
#define OS_ENTER_CRITICAL()     dlDisableIrq()  

#define OS_EXIT_CRITICAL()        dlEnableIrq()  


/* Define the structure that holds the GKI variables
*/
#if GKI_DYNAMIC_MEMORY == FALSE
tGKI_CB   gki_cb;
#endif

/* Contains common control block as well as OS specific variables */
//typedef struct tGKI_KI_CB_TAG
//{
//    TaskId   ki_task_id[GKI_MAX_TASKS];
//    QueueId  QTaskId[GKI_MAX_TASKS];
//} tGKI_KI_CB;

//tGKI_KI_CB gki_ki_cb;


/*******************************************************************************
**
** Function         startBTTimer
**
** Description      Test function for integration purposes 
**
** Returns          void
**
*******************************************************************************/
void startBTTimer (void)
{
    /* start gki ticks updata */
    l1Timer[L1_TIMER_TYPE_BT].timeoutPeriod = 10;//GKI_MS_TO_TICKS(500);
    l1Timer[L1_TIMER_TYPE_BT].myTaskId = L1_AL_TASK_ID;
    L1StartTimer(L1_TIMER_TYPE_BT);
}


void stopBTTimer (void)
{
    /* start gki ticks updata */
    
    L1StopTimer(L1_TIMER_TYPE_BT);
}

void GKI_setBTTimerState(BOOLEAN state)
{
    if(state == TRUE)
    {
        startBTTimer();
        
    }
    else
    {
        stopBTTimer();
    }
}
/*******************************************************************************
**
** Function         GKI_init
**
** Description      This function is called once at startup to initialize
**                  all the timer structures.
**
** Returns          void
**
*******************************************************************************/
void GKI_init(void)
{
    memset (&gki_cb, 0, sizeof (tGKI_CB));

    gki_cb.com.OSDisableNesting = 1;

    gki_buffer_init();

    gki_timers_init();
    GKI_timer_queue_register_callback(GKI_setBTTimerState);

    gki_cb.com.OSTicks = 0;

    #if defined (BTU_INCLUDED) && (BTU_INCLUDED == TRUE)
    /* BTU task defined staticaly here */
    gki_cb.os.ki_task_id[BTU_TASK] = BTU_TASK_ID;
    gki_cb.os.QTaskId[BTU_TASK] = BTU_QUEUE_ID;
    #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)
    gki_cb.os.event_group[BTU_TASK] = KI_BTU_EVENT_GROUP;
    #endif
    #endif

    /* HCI task defined staticaly here */
    gki_cb.os.ki_task_id[HCISU_TASK] = HCISU_TASK_ID;
    gki_cb.os.QTaskId[HCISU_TASK] = HCISU_QUEUE_ID;
    #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)
    gki_cb.os.event_group[HCISU_TASK] = KI_HCISU_TASK_EVENT_GROUP;
    #endif
    #if defined (BTUI_INCLUDED) && (BTUI_INCLUDED == TRUE)
    /* BTUI task defined staticaly here */
    gki_cb.os.ki_task_id[BTE_APPL_TASK] = BTE_APPL_TASK_ID;
    gki_cb.os.QTaskId[BTE_APPL_TASK] = BTE_APPL_QUEUE_ID;
    #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)
    gki_cb.os.event_group[BTE_APPL_TASK] = KI_BTE_APPL_EVENT_GROUP;
    #endif
#endif
    #if defined (SBC_ENCODER_INCLUDED) && (SBC_ENCODER_INCLUDED == TRUE)
    /* SBC encode task defined staticaly here */
    gki_cb.os.ki_task_id[SBC_ENCODE_TASK] = SBC_ENCODE_TASK_ID;
    gki_cb.os.QTaskId[SBC_ENCODE_TASK] = SBC_ENCODE_QUEUE_ID;
 //   #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)
    gki_cb.os.event_group[SBC_ENCODE_TASK] = KI_SBC_EVENT_GROUP;
  //  #endif
    #endif

    /* start gki ticks updata */
    //startBTTimer();

}

/*******************************************************************************
**
** Function         GKI_create_task
**
** Description      This function is called to create a new OSS task.
**
** Parameters:      task_entry  - (input) pointer to the entry function of the task
**                  task_id     - (input) Task id is mapped to priority
**                  taskname    - (input) name given to the task
**                  stack       - (input) pointer to the top of the stack (highest memory location)
**                  stacksize   - (input) size of the stack allocated for the task
**
** Returns          GKI_SUCCESS if all OK, GKI_FAILURE if any problem
**
** NOTE             This function take some parameters that may not be needed
**                  by your particular OS. They are here for compatability
**                  of the function prototype.
**
*******************************************************************************/
UINT8 GKI_create_task (TASKPTR task_entry, UINT8 task_id, INT8 *taskname,
                       UINT16 *stack, UINT16 stacksize)
{
    if (task_id >= GKI_MAX_TASKS)
    {
        return (GKI_FAILURE);
    }


    if (stack)
    {

        gki_cb.com.OSStack[task_id]     = (UINT8 *)stack - stacksize;
        gki_cb.com.OSStackSize[task_id] = stacksize;
    }

    gki_cb.com.OSRdyTbl[task_id]    = TASK_READY;
    gki_cb.com.OSTName[task_id]     = taskname;
    gki_cb.com.OSWaitTmr[task_id]   = 0;
    gki_cb.com.OSWaitEvt[task_id]   = 0;



    /* Create one Event Group for this task -> here it is done staticaly */

    /* Create Task -> here it is done staticaly */

    return (GKI_SUCCESS);
}


/*******************************************************************************
**
** Function         GKI_run
**
** Description      This function is called at startup if there is no OS
**                  to start the GKI dispatcher. It is also used on Windows
**                  to launch the application tasks.
**
** Returns          void
**
*******************************************************************************/
void GKI_run (void *p_task_id)
{
//    SignalBuffer signal = kiNullBuffer;

    //di_displayLine(3, "    BT_HciTaskInit    ");
    //BtTrace("BT_HciTaskInit()");

    gki_cb.com.OSDisableNesting = 0;

//    KiCreateSignal(SIG_INITIALISE, sizeof(KiInitialiseTask), &signal);
//    KiSendSignal (HCI_TASK_ID, &signal);

}


/*******************************************************************************
**
** Function         GKI_suspend_task()
**
** Description      This function suspends the task specified in the argument.
**
** Returns          0 if all OK, else 1
**                  It also tries to do context switch. 
**                  If task tries to suspend itself, then some other task must
**                  resume it, because it is no longer running.
**
*******************************************************************************/
UINT8 GKI_suspend_task(UINT8 task_id)
{
//    M_KiOsSuspendTask (task_id);
    return (GKI_SUCCESS);
}

/*******************************************************************************
**
** Function         GKI_resume_task()
**
** Description      This function resumes the task specified in the argument.
**
** Returns          0 if all OK, else 1
**                  It also tries to do context switch. 
**                  If task tries to suspend itself, then some other task must
**                  resume it, because it is no longer running.
**
*******************************************************************************/
UINT8 GKI_resume_task(UINT8 task_id)
{
//    M_KiOsResumeTask (task_id);
    return (GKI_SUCCESS);
}


/*******************************************************************************
**
** Function         GKI_exit_task
**
** Description      This function is called to stop a GKI task.
**
** Returns          void
**
*******************************************************************************/
void GKI_exit_task (UINT8 task_id)
{
        GKI_send_event(task_id, BT_EXIT_TASK_EVT);
}

/*******************************************************************************
**
** Function         GKI_sched_lock
**
** Description      This function is called by tasks to disable scheduler switching.
**
** Returns          void
**
*******************************************************************************/
void GKI_sched_lock(void)
{
    /* Lets avoid interrupt trigger a prehemtion -> may need to be replaced by a real scheduler lock mechanism */
    GKI_disable();
}

/*******************************************************************************
**
** Function         GKI_sched_unlock
**
** Description      This function is called by tasks to disable scheduler switching.
**
** Returns          void
**
*******************************************************************************/
void GKI_sched_unlock(void)
{
    /* Lets avoid interrupt trigger a prehemtion -> may need to be replaced by a real scheduler lock mechanism */
    GKI_enable();
}



/*******************************************************************************
**
** Function         GKI_wait
**
** Description      This function is called by tasks to wait for a specific
**                  event or set of events. The task may specify the duration
**                  that it wants to wait for, or 0 if infinite.
**
** Parameters:      flag -    (input) the event or set of events to wait for
**                  timeout - (input) the duration that the task wants to wait 
**                                    for the specific events (in system ticks)
**                  
**
** Returns          the event mask of received events or zero if timeout
**
*******************************************************************************/
UINT16 GKI_wait (UINT16 flag, UINT32 timeout)
{

    UINT16      evt   = 0;
//    UINT8       rtask = GKI_get_taskid();
    UINT8       rtask ;
    #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)
    //UINT8 ki_task_id = gki_cb.os.ki_task_id[rtask];
    UINT8 evt_group;
    int i;
    GKI_disable();

    rtask = GKI_get_taskid();
    if (gki_cb.com.OSTaskQFirst[rtask][0])
        gki_cb.com.OSWaitEvt[rtask] |= TASK_MBOX_0_EVT_MASK;
    if (gki_cb.com.OSTaskQFirst[rtask][1])
        gki_cb.com.OSWaitEvt[rtask] |= TASK_MBOX_1_EVT_MASK;
    if (gki_cb.com.OSTaskQFirst[rtask][2])
        gki_cb.com.OSWaitEvt[rtask] |= TASK_MBOX_2_EVT_MASK;
    if (gki_cb.com.OSTaskQFirst[rtask][3])
        gki_cb.com.OSWaitEvt[rtask] |= TASK_MBOX_3_EVT_MASK;

    /* If any valid event if pending, return immediately */
    if (gki_cb.com.OSWaitEvt[rtask] & flag)
    {
       /* Return only those bits which user wants... */
       evt = (UINT16) (gki_cb.com.OSWaitEvt[rtask] & flag);

       /* Clear only those bits which user wants... */
       gki_cb.com.OSWaitEvt[rtask] &= ~flag;
       GKI_enable();

        return ((UINT16) evt);
    }

    evt_group = gki_cb.os.event_group[rtask];
    //gki_cb.com.OSWaitForEvt[rtask] = flag;
    //APPL_TRACE_DEBUG2(" task ID = %d waits EVTGROUP = %d",rtask,evt_group);
   GKI_enable();
    M_KiOsWaitEventGroup(evt_group,gki_cb.com.OSWaitEvt[rtask] );

     GKI_disable();
     if (gki_cb.com.OSWaitEvt[rtask] & flag)
     {
         evt = (UINT16) (gki_cb.com.OSWaitEvt[rtask] & flag);
         gki_cb.com.OSWaitEvt[rtask] &= ~flag;
     }
     GKI_enable();

    #else
    SignalBuffer KiSignal;

    /* Check if anything in any of the mailboxes. Possible race condition. */
    if (gki_cb.com.OSTaskQFirst[rtask][0])
        gki_cb.com.OSWaitEvt[rtask] |= TASK_MBOX_0_EVT_MASK;
    if (gki_cb.com.OSTaskQFirst[rtask][1])
        gki_cb.com.OSWaitEvt[rtask] |= TASK_MBOX_1_EVT_MASK;
    if (gki_cb.com.OSTaskQFirst[rtask][2])
        gki_cb.com.OSWaitEvt[rtask] |= TASK_MBOX_2_EVT_MASK;
    if (gki_cb.com.OSTaskQFirst[rtask][3])
        gki_cb.com.OSWaitEvt[rtask] |= TASK_MBOX_3_EVT_MASK;

    /* If any valid event if pending, return immediately */
    if (gki_cb.com.OSWaitEvt[rtask] & flag)
    {
       /* Return only those bits which user wants... */
       evt = (UINT16) (gki_cb.com.OSWaitEvt[rtask] & flag);

       /* Clear only those bits which user wants... */
       gki_cb.com.OSWaitEvt[rtask] &= ~flag;

        return ((UINT16) evt);
    }

//    if (!timeout)
//        timeout = 0xFFFFFFFFL;
    KiReceiveSignal(gki_cb.os.QTaskId[rtask], &KiSignal);

    if(*(KiSignal.type) != BTE_SIGNAL_IND)
    {
        GKI_exception(0x0001, "GKI exeception Wrong signal Id");
        printf("Wrong signal Id %d, QTaskId %d, rttask %d	", *(KiSignal.type), gki_cb.os.QTaskId[rtask], rtask);
        KiDestroySignal(&KiSignal);
        return 0;
    }

    gki_cb.com.OSWaitEvt[rtask] |= KiSignal.sig->BteSigDesc.BTeventID;

    KiDestroySignal(&KiSignal);

    /* Return only those bits which user wants... */
    evt = gki_cb.com.OSWaitEvt[rtask] & flag;

    /* Clear only those bits which user wants... */
    gki_cb.com.OSWaitEvt[rtask] &= ~evt;

#endif
    return ((UINT16) evt);

}


/*******************************************************************************
**
** Function         GKI_delay 
**
** Description      This function is called by tasks to sleep unconditionally
**                  for a specified amount of time.
**
** Returns          void
**
*******************************************************************************/
void GKI_delay (UINT32 timeout)
{
    UINT8  task_id = GKI_get_taskid();
    UINT8  timer_index,queue_id;
    UINT32 i ;
    SignalBuffer signal = kiNullBuffer;

     //DelayMilliseconds(timeout);
    lgeBtDelayMilliseconds(timeout);
}


/*******************************************************************************
**
** Function         GKI_send_event
**
** Description      This function is called by tasks to send events to other
**                  tasks. Tasks can also send events to themselves.
**
** Returns          GKI_SUCCESS if all OK, else GKI_FAILURE
**
*******************************************************************************/
UINT8 GKI_send_event (UINT8 task_id, UINT16 event)
{
    UINT8 ki_task_id = gki_cb.os.ki_task_id[task_id];
    
    #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)

    #else
    SignalBuffer KiSignal = kiNullBuffer;
    #endif

    if (task_id >= GKI_MAX_TASKS)
    {
        return (GKI_FAILURE);
    }

    GKI_disable();

    gki_cb.com.OSWaitEvt[task_id] |= event;
    gki_cb.com.OSRdyTbl[task_id]   = TASK_READY;

    GKI_enable();
    #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)
//    M_KiOsCreateEventGroup(gki_cb.os.event_group[task_id]);
    //APPL_TRACE_DEBUG3("Send event  = %d / task ID = %d / event group = %d",event,task_id,gki_cb.os.event_group[task_id]);

    M_KiOsSetEvent(gki_cb.os.event_group[task_id],event);
    #else
    KiCreateSignal(BTE_SIGNAL_IND, sizeof(BteSigDescriptor), &KiSignal);

    KiSignal.sig->BteSigDesc.BTeventID = event;

    KiSendSignal(gki_cb.os.ki_task_id[task_id],&KiSignal);
    #endif
    return (GKI_SUCCESS);
}

/*******************************************************************************
**
** Function         GKI_isend_event
**
** Description      This function is called by ISRs to send events to other
**                  tasks. Does not cause reschedule.
**                  Assume interrupts are disabled...
** Returns          GKI_SUCCESS if all OK, else GKI_FAILURE
**
*******************************************************************************/
UINT8 GKI_isend_event (UINT8 task_id, UINT16 event)
{
    UINT8 ki_task_id = gki_cb.os.ki_task_id[task_id];
    
    #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)

    #else
    SignalBuffer KiSignal = kiNullBuffer;
    #endif

    if (task_id >= GKI_MAX_TASKS)
    {
        return (GKI_FAILURE);
    }

    gki_cb.com.OSWaitEvt[task_id] |= event;
    gki_cb.com.OSRdyTbl[task_id]   = TASK_READY;

    #if defined (GKI_EVENT_USE) && (GKI_EVENT_USE == TRUE)
//    M_KiOsCreateEventGroup(gki_cb.os.event_group[task_id]);
//        APPL_TRACE_DEBUG3("Send event  = %d / task ID = %d / event group = %d",event,task_id,gki_cb.os.event_group[task_id]);

    M_KiOsSetEvent(gki_cb.os.event_group[task_id],event);
    #else
    KiCreateSignal(BTE_SIGNAL_IND, sizeof(BteSigDescriptor), &KiSignal);

    KiSignal.sig->BteSigDesc.BTeventID = event;

    KiSendSignal(gki_cb.os.ki_task_id[task_id],&KiSignal);
    #endif

    return (GKI_SUCCESS);
}


/*******************************************************************************
**
** Function         GKI_get_taskid
**
** Description      This function gets the currently running task ID.
**
** Returns          task ID
**
*******************************************************************************/
UINT8 GKI_get_taskid(void)
{
    UINT8   task_id = 0;
    TaskId  ki_task_id;

    ki_task_id = KiThisTask();

    for(task_id =0; task_id<GKI_MAX_TASKS ; task_id++)
    {
        if(ki_task_id == gki_cb.os.ki_task_id[task_id])
        {
            return task_id;
        }
    }
//    GKI_exception(0x0002, "GKI_exception: Task Id not found");
//    printf("GKI_exception: Task Id not found ki_task_id %d, btu_task_id %d, hci_task_id %d", ki_task_id, BTU_TASK_ID, HCI_TASK_ID);

    return GKI_MAX_TASKS;
}

/*******************************************************************************
**
** Function         GKI_map_taskname
**
** Description      This function gets the task name of the taskid passed as arg.
**                  If GKI_MAX_TASKS is passed as arg the currently running task
**                  name is returned
**
** Returns          pointer to task name
**
*******************************************************************************/
INT8 *GKI_map_taskname(UINT8 task_id)
{
	if (task_id < GKI_MAX_TASKS)
		 return (gki_cb.com.OSTName[task_id]);
	else if (task_id == GKI_MAX_TASKS )
        return (gki_cb.com.OSTName[GKI_get_taskid()]);
    else
		return (INT8 *) "BAD";
}



/*******************************************************************************
**
** Function         GKI_enable
**
** Description      This function enables interrupts.
**
** Returns          void
**
*******************************************************************************/
void GKI_enable(void)
{
    if (gki_cb.com.OSIntNesting)
        return;

    if (gki_cb.com.OSDisableNesting > 0)
    {
        gki_cb.com.OSDisableNesting--;
    }
    if (gki_cb.com.OSDisableNesting == 0)
    {
        OS_EXIT_CRITICAL();
    }

}


/*******************************************************************************
**
** Function         GKI_disable
**
** Description      This function disables interrupts.
**
** Returns          void
**
*******************************************************************************/
void GKI_disable (void)
{
    if (gki_cb.com.OSIntNesting)
        return;

    /* For NUCLEUS, control interrupt nesting ourselves */
    if (!gki_cb.com.OSDisableNesting)
        OS_ENTER_CRITICAL();

    gki_cb.com.OSDisableNesting++;
}

/*******************************************************************************
**
** Function         GKI_exception
**
** Description      This function throws an exception.
**                  This is normally only called for a nonrecoverable error.
**
** Parameters:      code    -  (input) The code for the error
**                  msg     -  (input) The message that has to be logged
**
** Returns          void
**
*******************************************************************************/

void GKI_exception (UINT16 code, char * msg)
{

#if (GKI_DEBUG == TRUE)
    GKI_disable();

    if (gki_cb.com.ExceptionCnt < GKI_MAX_EXCEPTION)
    {
        EXCEPTION_T *pExp;

        pExp =  &gki_cb.com.Exception[gki_cb.com.ExceptionCnt++];
        pExp->type = code;
        pExp->taskid = GKI_get_taskid();
        strncpy((char *)pExp->msg, msg, GKI_MAX_EXCEPTION_MSGLEN - 1);
    }

    GKI_enable();
#endif

    /* TODO:  You can print or otherwise handle your exception here */
    printf(msg);

    return;
}



/*******************************************************************************
**
** Function         GKI_get_time_stamp
**
** Description      This function formats the time into a user area
**
** Returns          the address of the user area containing the formatted time
**
*******************************************************************************/
INT8 *GKI_get_time_stamp (INT8 *tbuf)
{
	return (tbuf);
}


/*******************************************************************************
**
** Function         GKI_register_mempool
**
** Description      This function registers a specific memory partition to be
**                  used with dynamic memory pool allocation.
**
** Returns          void
**
*******************************************************************************/
void GKI_register_mempool (void *p_mem)
{
    gki_cb.com.p_user_mempool = p_mem;
}


/*******************************************************************************
**
** Function         GKI_os_malloc
**
** Description      This function allocates memory
**
** Returns          the address of the memory allocated, or NULL if failed
**
*******************************************************************************/
void *GKI_os_malloc (UINT32 size)
{
    return (NULL);
}

/*******************************************************************************
**
** Function         GKI_os_free
**
** Description      This function frees memory
**
** Returns          void
**
*******************************************************************************/
void GKI_os_free (void *p_mem)
{
    BT_ERROR_TRACE_0(TRACE_LAYER_NONE,"ERROR GKI_os_free-> not done");
}

/*******************************************************************************
**
** Function         BtBuildTest
**
** Description      Test function for integration purposes 
**
** Returns          void
**
*******************************************************************************/
void BtBuildTest (void)
{
   // strncpy(buf, "Hello bt word", 80); 
   #ifndef LGBX_INCLUDE
      btapp_dm_enable();
   #endif
}

