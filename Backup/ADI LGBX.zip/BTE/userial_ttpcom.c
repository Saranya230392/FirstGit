/*******************************************************************************
**  Name:       userial_ttpcom.c
**
**  Description:
**
**  This file contains the universal driver wrapper for the BTE-QC serial
**  drivers
**
**  Copyright (c) 2001-2006, Widcomm Inc., All Rights Reserved.
**  Widcomm Bluetooth Core. Proprietary and confidential.
*******************************************************************************/
#include "target.h"

/***************************************************************************
* Include Files
***************************************************************************/

#include <string.h>
#include "userial_ttpcom.h"
#include "lgebtspalhi.h"
#include "userial.h"
#include "btqueue.h"
#include "btu.h"	//for btu_cb
#include <Dlspalif.h> 
#include "udebug.h"
/***************************************************************************
* Manifest Constants / Defines
***************************************************************************/
#define NUM_ACL_DATA_PACKET_2048	8
/* with 8 NUM_DMA_TX_BUFFER, the USERIAL_Write won't fail to write 
    btu_task() will not send more than NUM_ACL_DATA_PACKET_2048 packets */
#define NUM_DMA_TX_BUFFER		(NUM_ACL_DATA_PACKET_2048)

#define PARITY_MASK      0x38

/****************************************************************************
* Type Definitions
****************************************************************************/
typedef struct BtDmaTxBufferTag
{
    INT8  buffer[BT_TX_BUFF_SIZE]; 
    INT16 num;
} BtDmaTxBuffer;

/***************************************************************************
** Static Variables
***************************************************************************/
static BtDmaTxBuffer gTxDblBuffer[NUM_DMA_TX_BUFFER];
static INT8 gWrIndex;
static INT8 gRdIndex;

static TIMER_LIST_Q userial_timer_queue;
static TIMER_LIST_ENT   userial_timer;
static INT16 userial_is_timer_running = 1;
/***************************************************************************
** Global Variables
***************************************************************************/
volatile BOOLEAN gIsSending;
tUSERIAL_CBACK *gUartCallback;
extern BtQueue rxQueue;

/****************************************************************************
** Imported Functions
****************************************************************************/

extern DlSpalHandle btPortHandle; 
extern Int16 DlSpalTxFromBuffer( DlSpalHandle h, Int8 * dataPtr, Int16 dataLength);
extern int Trigger_ReadDMABuffer(void);
extern void Trigger_CheckTxData(void);
extern void BtClearRTS(void);
extern void BtSetRTS(void);

/****************************************************************************
** Global Functions
****************************************************************************/
UINT8    baudrate_cfg;

void	 USERIAL_InitData(void)
{
    Int8 i;
    gIsSending = FALSE;

    for (i = 0; i < NUM_DMA_TX_BUFFER; i++) gTxDblBuffer[i].num = 0;
    gWrIndex = 0;
    gRdIndex = 0;
}

/*******************************************************************************
**
** Function           USERIAL_Reset
**
** Description        This function initializes the  serial driver. 
**
** Output Parameter   None
**
** Returns            Nothing
**
*******************************************************************************/
UDRV_API void    USERIAL_Init(void * p_cfg)
{
    Int8 i;

    baudrate_cfg = USERIAL_BAUD_115200;
    gUartCallback = NULL;
    gIsSending = FALSE;

    for (i = 0; i < NUM_DMA_TX_BUFFER; i++) gTxDblBuffer[i].num = 0;
    gWrIndex = 0;
    gRdIndex = 0;

    rxQueue.Count = 0;
    rxQueue.Head = 0;
    rxQueue.Tail = 0;

    BtSetRTS();	//allow 2048 sending

    //DlSpalInitialise();
    BtInitSerialPort();
    //BtDmaResetRxBuffer();	
    BtDisableRxDataReadyInt();
}

BOOLEAN userial_checkbaudrate(UINT8 input_baudrate, UINT8* output_baudrate)
{
    switch(input_baudrate)
    {
        case USERIAL_BAUD_1200:
            *output_baudrate = SPAL_BAUD_1200;
            break;

        case USERIAL_BAUD_2400:
            *output_baudrate =SPAL_BAUD_2400;
            break;

        case USERIAL_BAUD_9600:
            *output_baudrate = SPAL_BAUD_9600;
            break;

        case USERIAL_BAUD_19200:
            *output_baudrate = SPAL_BAUD_19200;
            break;

        case USERIAL_BAUD_57600:
            *output_baudrate = SPAL_BAUD_57600;
            break;

        case USERIAL_BAUD_115200:
	     APPL_TRACE_DEBUG1("BAUD RATE IS 115 = %d",SPAL_BAUD_115200);
            *output_baudrate = SPAL_BAUD_115200;
            break;

        case USERIAL_BAUD_230400:
            *output_baudrate = SPAL_BAUD_230400;
            break;

        case USERIAL_BAUD_460800:
	     APPL_TRACE_DEBUG1("BAUD RATE IS 460 = %d",SPAL_BAUD_460800);
            *output_baudrate = SPAL_BAUD_460800;
            break;

        case USERIAL_BAUD_921600:
	     APPL_TRACE_DEBUG1("BAUD RATE IS 921 = %d",SPAL_BAUD_921600);
            *output_baudrate = SPAL_BAUD_921600;
            break;

        default:
            /* Unsupported Baud rate */
            return FALSE;
            //break;
    }
    return TRUE;
}

BOOLEAN userial_checkparity(UINT16 input_parity, UINT8* output_parity)
{
    UINT16 parity;
    parity = (input_parity) &  PARITY_MASK;

    switch(parity)
    {
        case USERIAL_PARITY_NONE:
            APPL_TRACE_DEBUG0("NO PARITY");
            *output_parity = SPAL_NO_PARITY;
            break;

        case USERIAL_PARITY_EVEN:
            APPL_TRACE_DEBUG0("EVEN PARITY");
            *output_parity = SPAL_EVEN_PARITY;
            break;

        case USERIAL_PARITY_ODD:
            APPL_TRACE_DEBUG0("ODD PARITY");
            *output_parity = SPAL_ODD_PARITY;
            break;

        default:
            /* Unsupported Baud rate */
            return FALSE;
    }
    return TRUE;
}

void userial_timer_init()
{
    /* first, create a timer for userial. It will run when the L1 timer is ticking */
    GKI_start_timer(TIMER_2, GKI_MS_TO_TICKS(10), TRUE);

    /* then init the timer structures */
    GKI_init_timer_list(&userial_timer_queue);
    GKI_init_timer_list_entry(&userial_timer );
}

void userial_timer_start( INT16 iterations )
{
    if( !userial_is_timer_running )
    {
        userial_timer.ticks = 1;
        GKI_add_to_timer_list (&userial_timer_queue, &userial_timer);
    }
    /* check if userial_timer is running by Host_Wakeup*/
    if(userial_is_timer_running < iterations)
	userial_is_timer_running = iterations;
}

void userial_timer_stop()
{
    if( --userial_is_timer_running == 0 )
    {
        /* here, data packet from controller (by Host_Wakeup) should be received  */
        if( GKI_queue_is_empty (&btu_cb.cmd_cmpl_q) && (gWrIndex ==  gRdIndex))
        {
	      /* all event (response) received && no data to send */
	      GKI_remove_from_timer_list (&userial_timer_queue, &userial_timer);
        }
        /* initialize to value to 1 */
        userial_is_timer_running = 1;
    }
}


/*******************************************************************************
**
** Function           USERIAL_Open
**
** Description        Open the indicated serial port with the given configuration
**
** Output Parameter   None
**
** Returns            Nothing
**
*******************************************************************************/

UDRV_API void USERIAL_Open(tUSERIAL_PORT port_id, tUSERIAL_OPEN_CFG * config, tUSERIAL_CBACK * cback)
{
    BOOLEAN success;
    UINT8 adi_baudrate, adi_parity;

    gIsSending = FALSE;
    gWrIndex = 0;
    gRdIndex = 0;
    gUartCallback = cback;
    
    success = userial_checkbaudrate(config->baud,&adi_baudrate);
    if (success == TRUE)
    {
	success = userial_checkparity(config->fmt,&adi_parity);
    }
        
    if (success == TRUE)
    {
        APPL_TRACE_DEBUG2("UART config: baudrate = %d - parity = %d",adi_baudrate,adi_parity);
        BtConfigSerialPort((DlSpalBaudRate) adi_baudrate, (DlSpalParity) adi_parity);
    }
}

/*******************************************************************************
**
** Function           USERIAL_Ioctl
**
** Description        Perform an operation on a serial port.
**
** Output Parameter   The p_data parameter is either an input or output depending 
**                    on the operation.
**
** Returns            Nothing
**
*******************************************************************************/
UDRV_API void USERIAL_Ioctl(tUSERIAL_PORT port, tUSERIAL_OP op, tUSERIAL_IOCTL_DATA *p_data)
{
    UINT8 adi_baudrate;
    //UINT8 adi_parity;
    BOOLEAN success;

#if 0	//it should be enabled for LPM !!  ( _BCM_ENABLE_DEEP_SLEEP_ added to wakeup uart deep sleep mode.
	extern boolean sleep_uart_clock_rgm;
	if(sleep_uart_clock_rgm == FALSE)
	{
		extern void siors_enable_clock(void);
		siors_enable_clock();
	}	
#endif 

    switch(op) 
    {
        case USERIAL_OP_FLUSH:
            break;
        case USERIAL_OP_FLUSH_RX:
            break;
        case USERIAL_OP_FLUSH_TX:
            break;
        case USERIAL_OP_GET_CTS:
            break;
        case USERIAL_OP_SET_RTS:
            break;
        case USERIAL_OP_CLEAR_RTS:
            break;
        case USERIAL_OP_NO_FLOW_CTRL:
            break;
        case USERIAL_OP_BAUD_WR:
            success = userial_checkbaudrate(p_data->baud, &adi_baudrate);
            APPL_TRACE_DEBUG2("[AD6720]   Check Baud Rate Inout = 0x%x, Output = 0x%x", p_data->baud,&adi_baudrate); 
            APPL_TRACE_DEBUG1("[AD6720]   Check baud Rate Status = %d", success); 

            //if (success == TRUE)
            //   success = userial_checkparity(p_data->fmt,&adi_parity);
          
            if (success == TRUE)
            {
                 baudrate_cfg = p_data->baud;

                 APPL_TRACE_DEBUG1("[AD6720]   Changing Baud Rate to AD6720 Baud = %d", p_data->baud); 				  
		   GKI_delay(10);/*BT_L1_KIMSANGJIN_061127   noti_010301*/
                 BtUartChangeConfig((DlSpalBaudRate) adi_baudrate, SPAL_NO_PARITY);
            }
            break;
        case USERIAL_OP_BAUD_RD:
		p_data->baud = baudrate_cfg;
	     break;

        default:
	     break;
    }

    return;

}

/*******************************************************************************
**
** Function           USERIAL_Read
**
** Description        Read data from a serial port using byte buffers.
**
** Output Parameter   None
**
** Returns            Number of bytes actually read from the serial port and 
**                    	copied into p_data.  This may be less than len.
**
*******************************************************************************/
UDRV_API UINT16  USERIAL_Read(tUSERIAL_PORT port_id, UINT8 *p_data, UINT16 len)
{
    UINT16 num = 0; // number of bytes read from buffer

    GKI_disable();
    num = BQ_ReadData(&rxQueue, p_data, len);
#if 1
       /* rxQueue.Size - rxQueue.Count = rxQueue available space */   
       if ((rxQueue.Size - rxQueue.Count) > BT_RX_BUFF_SIZE)  //when larger than 1024byte
       {
	    BtSetRTS();	//allow 2048 sending
       }
#endif
    GKI_enable();

    //BT_DEBUG(("USERIAL_Read, num: 0x%x", num));
    return num;
}

/*******************************************************************************
**
** Function           USERIAL_CheckTxData
**
** Description        Called when TX interrupt occurs
**                    If there is some data to send in the next TX buffer, 
**						then DMA is initiated to send it.
**
*******************************************************************************/

void USERIAL_CheckTxData(void)
{
    gIsSending = FALSE;

    /* see if data available to send */
    if (gWrIndex ==  gRdIndex) 
    {
        //BT_DEBUG(("[USERIAL_CheckDMAUART] no data to send"));
        return ;
    }
    if (BtGetCTS() == FALSE)  //2048 is not ready to receive
    {
        //BT_DEBUG(("[USERIAL_CheckDMAUART] /CTS high"));
        userial_timer_start(1);
        return ;
    }

    //Yes, data to send and 2048 is ready to receive
    {
        /* disable Interrupt */			   
        DlSpalDisableTxBufferReadyInt(btPortHandle);

        /* initiate DMA */			   
        DlSpalTxFromBuffer( btPortHandle, gTxDblBuffer[gRdIndex].buffer, gTxDblBuffer[gRdIndex].num);
        gRdIndex = (gRdIndex+1) % NUM_DMA_TX_BUFFER;
        gIsSending = TRUE;

        /* enable Interrupt */			   
        DlSpalEnableTxBufferReadyInt(btPortHandle);
    }
}

/*******************************************************************************
**
** Function           USERIAL_Write
**
** Description        Write data to a serial port using a byte buffer.  
**
** Output Parameter   None
**
** Returns         	  Number of bytes actually written to the serial port.  This 
**                    may be less than len.
**
*******************************************************************************/
UDRV_API UINT16  USERIAL_Write(tUSERIAL_PORT port_id, UINT8 *p_data, UINT16 len)
{
    UINT16 byte_sent = 0; /* number of bytes written to buffer */
    UINT16 copied_bytes = 0;

    #if 0  // testing
		GKI_delay(5);
    #endif
	
    if ((gWrIndex+1) % NUM_DMA_TX_BUFFER == gRdIndex)
    {
        /* If happens, it is a design error, BTU shouldn't send more than 8 packets without completion */
        //BT_DEBUG(("[USERIAL_Write] No buffer available"));
        /* wait until a buffer available, less than 10ms MAX*/
        while (gIsSending);
    }

    /* 
    * Save p_data to Line Buffer
    *  - write to a line buffer (gTxDblBuffer) with gWrIndex.
    *  - always at least one line buffer will be available among 8 (same with num ACL buffers).
    */
    byte_sent = gTxDblBuffer[gWrIndex].num = (len < BT_TX_BUFF_SIZE) ? len : BT_TX_BUFF_SIZE;
    memcpy(gTxDblBuffer[gWrIndex].buffer, p_data, gTxDblBuffer[gWrIndex].num);
    gWrIndex = (gWrIndex+1) % NUM_DMA_TX_BUFFER;

    //BT_DEBUG(("USERIAL_Write, len: 0x%x, sent:0x%x, gWrIndex:%d, gRdIndex:%d", len, byte_sent, gWrIndex, gRdIndex));

    /* see whether DMA is in idle */
    //if ((gIsSending == TRUE) || (BtGetCTS() == FALSE)) 
        //BT_DEBUG(("[USERIAL_Write] gIsSending = TRUE or /CTS is High"));
    if (gIsSending == TRUE)
    {
        //BT_DEBUG(("[USERIAL_Write] gIsSending = TRUE"));
        HCILP_WakeupBTDevice(NULL);
        /* Start timer to come back later */
        userial_timer_start(1);
    }
    else   
    {
        /* disable Interrupt */			   
        DlSpalDisableTxBufferReadyInt(btPortHandle);

        /* initiate DMA */			   
        copied_bytes = DlSpalTxFromBuffer( btPortHandle, gTxDblBuffer[gRdIndex].buffer, gTxDblBuffer[gRdIndex].num);

        //if(copied_bytes != gTxDblBuffer[gRdIndex].num)
        //{
        //    BT_DEBUG(("ERROR copy bytes[%d] < num bytes to copy[%d]",copied_bytes,gTxDblBuffer[gRdIndex].num));
        //}

        gRdIndex = (gRdIndex+1) % NUM_DMA_TX_BUFFER;
        gIsSending = TRUE;

        /* enable Interrupt */			   
        DlSpalEnableTxBufferReadyInt(btPortHandle);
    }
    return byte_sent;
}

/*******************************************************************************
**
** Function           USERIAL_Close
**
** Description        Close a serial port
**
** Output Parameter   None
**
** Returns            Nothing
**
*******************************************************************************/
UDRV_API void    USERIAL_Close(tUSERIAL_PORT port)
{
    GKI_stop_timer(TIMER_2);
}

void USERIAL_CheckDMAUART(void)
{
    /* data is sitting in DMA buffer, then event to Spal
          i) timer started by USERIAL_Write ()
          ii) timer started by Host_Wakeup ()
    */

    //myung - read DMA buffer too often ?
    //Trigger_ReadDMABuffer();

    if ((gWrIndex !=  gRdIndex) && (!gIsSending))
    {
            Trigger_CheckTxData() ;
            userial_timer_stop();
			
            //BT_DEBUG(("[USERIAL_CheckDMAUART] gIsSending = FALSE"));

#if 0
        if (BtGetCTS() == FALSE)
        {
            APPL_TRACE_DEBUG3("[USERIAL_CheckDMAUART] - /CTS is HIGH. gIsSending: %d, gWrIndex: %d, gRdIndex: %d", gIsSending, gWrIndex, gRdIndex );
            //HCILP_WakeupBTDevice();
            userial_timer_start(1);
        }
        else
        {
            Trigger_CheckTxData() ;
            APPL_TRACE_DEBUG0("[USERIAL_CheckDMAUART] - Check tx data");
            userial_timer_stop();
        }
#endif		
    }
    else
    {
            userial_timer_start(1);
    }
}

