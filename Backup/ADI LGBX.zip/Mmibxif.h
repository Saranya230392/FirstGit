
#if !defined(MMIBXIF_H)
#define MMIBXIF_H

#if defined(LGE_MMI_BLUETOOTH)

/* BT_COMMON_KIMSANGJIN_070416 */
#define BTMMI_DYNAMIC_OBJECT     0x8051
#define BTMMI_DYNAMIC_SUCCESS   0x4407
#define BTMMI_DYNAMIC_FAIL      0x0319


#define BTMMI_STATIC_OBJECT     0x0000
/* end of BT_COMMON_KIMSANGJIN_070416 */

typedef enum
{
    BT_MMI_DOWN_STREAM = 0x0080,								//128
    //--------------------------------------------------------------------------
    BT_TASK_LAUNCH,
    BT_TASK_SHUTDOWN,
    //--------------------------------------------------------------------------
    // Application Management
    //--------------------------------------------------------------------------
    BT_APP_DN_MSG_BASE = BT_MMI_DOWN_STREAM + 0x0100,		//384
    //--------------------------------------------------------------------------
    BT_APP_INITIALIZE,
    BT_APP_SET_LOCALNAME,       // void    BT_AppSetLocalName(instData, char * Utf8String);
    BT_APP_SET_VISIBILITY,      // void    BT_AppSetVisibility(Sds_InstanceData_t *instData, bool_t Show);
    BT_APP_ENTER_TEST_MODE,     // void    BT_AppEnterTestMode(void);
    BT_APP_ENTER_BYPASS_MODE,   // void    BT_AppEnterBypassMode(App_InstanceData_t *instData);
    BT_APP_READ_RSSI,           // void    BT_ReadRSSI(App_InstanceData_t *instData);
    BT_DUT_INIT_CNF,
    BT_DUT_ON_CNF,
    BT_DUT_OFF_CNF,
    BT_APP_RADIO_TEST_TX_START,	//TestID = 1
    BT_APP_RADIO_TEST_RX_START1,	//TestID = 2
    BT_APP_RADIO_TEST_RX_START2,	//TestID = 3
    BT_APP_RADIO_TEST_TX_DATA1,	//TestID = 4    
    BT_APP_RADIO_TEST_TX_DATA2,	//TestID = 5    
    BT_APP_RADIO_TEST_TX_DATA3,	//TestID = 6        
    BT_APP_RADIO_TEST_TX_DATA4,	//TestID = 7
    BT_APP_RADIO_TEST_RX_DATA1,	//TestID = 8            
    BT_APP_RADIO_TEST_RX_DATA2,	//TestID = 9
    BT_APP_RADIO_TEST_RX_BER1,		//TestID = 19            
    BT_APP_RADIO_TEST_RX_BER2,		//TestID = 20          
    BT_APP_READ_LOCAL_BDADDR,
    //--------------------------------------------------------------------------
    BT_SDP_DN_MSG_BASE = BT_APP_DN_MSG_BASE + 0x0100,		//640
    //--------------------------------------------------------------------------
    BT_SDP_START_INQUIRY,       // void    BT_SdpStartInquiry(Sds_InstanceData_t *instData, BTMMI_INQFILTER_T devclass);
    BT_SDP_STOP_INQUIRY,        // void    BT_SdpStopInquiry(Sds_InstanceData_t *instData);
    BT_SDP_BOND_DEVICE,         // void    BT_SdpBondDevice(Sds_InstanceData_t *instData, LGBX_BD_ADDR_TYPE * bd_addr);
    BT_SDP_DEBOND_DEVICE,       // void    BT_SdpDebondDevice(Sds_InstanceData_t *instData, LGBX_BD_ADDR_TYPE * theAddr);
    BT_SDP_SEND_PASSKEY,        // void    BT_SdpSendPasskey(Sds_InstanceData_t *instData, BTMMI_PASSKEY_T * passkey);
    BT_SDP_AUTHORISE,           // void    BT_SdpAuthorise(Sds_InstanceData_t *instData, BTMMI_SDS_AUTH_RES_T * auth);
    BT_SDP_READ_REMOTE_NAME,    // void    BT_SdpReadRemoteName(Sds_InstanceData_t *instData, LGBX_BD_ADDR_TYPE * bd_addr);
    BT_SDP_READ_SERVICE_LIST,   // void    BT_SdpReadServiceList(Sds_InstanceData_t *instData, LGBX_BD_ADDR_TYPE * bd_addr);
#ifndef ADI_EXCLUDE_BPP_UPGL
    BT_SDP_QUERY_SOME_SVC,	
    BT_SDP_QUERY_STOP_REQ,
#endif
/* BT_MMI_CHOOBYOUNGSOO */
	BT_GAP_CONNECT_CFM,
	BT_GAP_DISCONNECT_CFM,
    //--------------------------------------------------------------------------
    BT_AGW_DN_MSG_BASE = BT_SDP_DN_MSG_BASE + 0x0100,	//896
    //--------------------------------------------------------------------------
    BT_AGW_ACTIVATE,            // void    BT_AgwActivate(Agw_InstanceData_t *instData);
    BT_AGW_DEACTIVATE,          // void    BT_AgwDeactivate(Agw_InstanceData_t *instData);
    BT_AGW_ATTATCH_HEADSET,     // void    BT_AgwAttatchHeadset(Agw_InstanceData_t *instData, BTMMI_CONNECT_REQ_T * prim);
    BT_AGW_DETATCH_HEADSET,     // void    BT_AgwDetatchHeadset(Agw_InstanceData_t *instData);
    BT_AGW_ALERT_RING,          // void    BT_AgwAlertRing(Agw_InstanceData_t *instData);
    BT_AGW_INBAND_RING,         // void    BT_AgwInbandRing(Agw_InstanceData_t *instData);
    BT_AGW_STOP_RING,           // void    BT_AgwStopRing(Agw_InstanceData_t *instData);
    BT_AGW_AUDIO_REQ,           // void    BT_AgwAudioReq(Agw_InstanceData_t *instData);
    BT_AGW_ON_HOOK,             // void    BT_AgwOnHook(Agw_InstanceData_t *instData);
    BT_AGW_SET_PACKET_TYPE,     // void    BT_AgwSetPacketType(Agw_InstanceData_t *instData, int sco_packet_type);
    BT_AGW_SPK_CHANGE_REQ,      // void    BT_AgwSpkVolChange(Agw_InstanceData_t *instData, int spk_volume);
    BT_AGW_MIC_CHANGE_REQ,      // void    BT_AgwMicVolChange(Agw_InstanceData_t *instData, int mic_volume);
    BT_AGW_AT_CMD_SEND_REQ,     // void    BT_AgwAtCmdSendReq(Agw_InstanceData_t *instData, BTMMI_STRING_T * mstr);

    //--------------------------------------------------------------------------
    BT_HFG_DN_MSG_BASE = BT_AGW_DN_MSG_BASE + 0x0100,	//1152
    //--------------------------------------------------------------------------
    BT_HFG_ACTIVATE,            // void    BT_HfgActivate(Hfg_InstanceData_t *instData);
    BT_HFG_DEACTIVATE,          // void    BT_HfgDeactivate(Hfg_InstanceData_t *instData);
    BT_HFG_CONNECT,             // void    BT_HfgConnect(Hfg_InstanceData_t *instData, BTMMI_CONNECT_REQ_T * prim);
    BT_HFG_DISCONNECT,          // void    BT_HfgDisconnect(Hfg_InstanceData_t *instData);

    BT_HFG_SERVICE_STATUS,      // void    BT_HfgServiceStatus(Hfg_InstanceData_t *instData, bool_t serviceStatus);
    BT_HFG_CALL_SETUP_STATUS,   // void    BT_HfgCallSetupStatus(Hfg_InstanceData_t *instData, BTMMI_HFG_STATUS CallStatus);
    BT_HFG_CALL_STATUS,         // void    BT_HfgCallStatus(Hfg_InstanceData_t *instData, bool_t serviceStatus);
    BT_HFG_CALL_HOLD_RES,       // void    BT_HfgCallHoldRes(Hfg_InstanceData_t *instData, bool_t AcceptorNot);

    BT_HFG_RING_REQ,            // void    BT_HfgRingReq(Hfg_InstanceData_t *instData, BTMMI_RING_T * prim);
    BT_HFG_AUDIO_REQ,           // void    BT_HfgAudioReq(Hfg_InstanceData_t *instData, bool_t audioStatus);
    BT_HFG_AUDIO_TYPE_REQ,      // void    BT_HfgAudioTypeChange(Hfg_InstanceData_t *instData, int sco_packet_type);
    BT_HFG_SPK_CHANGE_REQ,      // void    BT_HfgSpkVolChange(Hfg_InstanceData_t *instData, int spk_volume);
    BT_HFG_MIC_CHANGE_REQ,      // void    BT_HfgMicVolChange(Hfg_InstanceData_t *instData, int mic_volume);

    BT_HFG_AT_CMD_SEND_REQ,     // void    BT_HfgAtCmdSendReq(Agw_InstanceData_t *instData, BTMMI_STRING_T * mstr);
    BT_HFG_DIAL_RES,            // void    BT_HfgDialRes(Hfg_InstanceData_t *instData, bool_t AcceptOrNot);
    BT_HFG_DIAL_VOICE_RES,      // void    BT_HfgVoiceDialRes(Hfg_InstanceData_t *instData, bool_t ActiveOfNot);

    //--------------------------------------------------------------------------
    BT_SPP_DN_MSG_BASE = BT_HFG_DN_MSG_BASE + 0x0100,		//1408
    //--------------------------------------------------------------------------
    BT_SPP_ACTIVATE,            // void    BT_SppActivate(Spp_GroupData_t *instData, uint16_t isntId);
    BT_SPP_DEACTIVATE,          // void    BT_SppDeactivate(Spp_GroupData_t *instData, uint16_t instId);
    BT_SPP_CONNECT,             // void    BT_SppConnect(Dun_InstanceData_t *instData, uint16_t instId);
    BT_SPP_DISCONNECT,          // void    BT_SppDisconnect(Dun_InstanceData_t *instData, uint16_t instId);
    BT_SPP_TX_PUMP_REQ,         // void    BT_SppPumpTxData(Spp_GroupData_t *instData, uint16_t instId);
    BT_SPP_RX_PUMP_REQ,         // void    BT_SppPumpRxData(Spp_GroupData_t *instData, uint16_t instId);

    //--------------------------------------------------------------------------
    BT_DUN_DN_MSG_BASE = BT_SPP_DN_MSG_BASE + 0x0100,		//1664
    //--------------------------------------------------------------------------
    BT_DUN_ACTIVATE,            // void    BT_DunActivate    (Dun_InstanceData_t *instData);
    BT_DUN_DEACTIVATE,          // void    BT_DunDeactivate  (Dun_InstanceData_t *instData);
    BT_DUN_DISCONNECT,          // void    BT_DunDisconect   (Dun_InstanceData_t *instData);
    BT_DUN_TX_PUMP_REQ,         // void    BT_DunPumpTxData  (Dun_InstanceData_t *instData);
    BT_DUN_RX_PUMP_REQ,         // void    BT_DunPumpRxData  (Dun_InstanceData_t *instData);

    //--------------------------------------------------------------------------
    BT_FTS_DN_MSG_BASE = BT_DUN_DN_MSG_BASE + 0x0100, 	//1920  to do, support multiple client
    //--------------------------------------------------------------------------
    BT_FTS_SET_ROOT_DIR,        // void    BT_FtsSetRootDir  (Fts_InstanceData_t *instData, uint8_t * Utf8Path);
    BT_FTS_ACTIVATE,            // void    BT_FtsActivate    (Fts_InstanceData_t *instData, bool_t lowSecurity);
    BT_FTS_DEACTIVATE,          // void    BT_FtsDeactivate  (Fts_InstanceData_t *instData);
    BT_FTS_DISCONNECT,          // void    BT_FtsDisconnect  (Fts_InstanceData_t *instData);
    BT_FTS_AUTHENTICATE,        // void    BT_FtsAuthenticate(Fts_InstanceData_t *instData, BTMMI_OSS_AUTH_RES_T * prim);

    //--------------------------------------------------------------------------
    BT_FTC_DN_MSG_BASE = BT_FTS_DN_MSG_BASE + 0x0100,		//2176
    //--------------------------------------------------------------------------
    BT_FTC_SET_ROOT_DIR,        // void    BT_FtcSetRootDir  (Fts_InstanceData_t *instData, uint8_t * Utf8Path);
    BT_FTC_START_SEARCH,        // void    BT_FtcStartSeatch (Ftc_InstanceData_t *instData);
    BT_FTC_STOP_SEARCH,         // void    BT_FtcStopSeatch  (Ftc_InstanceData_t *instData);
    BT_FTC_CONNECT,             // void    BT_FtcConnect     (Ftc_InstanceData_t *instData, BTMMI_CONNECT_REQ_T * prim);
    BT_FTC_DISCONNECT,          // void    BT_FtcDisconnect  (Ftc_InstanceData_t *instData);
    BT_FTC_AUTHENTICATE,        // void    BT_FtcAuthenticate(Ftc_InstanceData_t *instData, BTMMI_OCS_AUTH_RES_T * prim);
    BT_FTC_LOCAL_GETDIR,        // void    BT_FtcLocalGetDir (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_LOCAL_CHDIR,         // void    BT_FtcLocalChDir  (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_LOCAL_MKDIR,         // void    BT_FtcLocalMkDir  (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_LOCAL_RMDIR,         // void    BT_FtcLocalRmDir  (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_LOCAL_DEL,           // void    BT_FtcLocalDel    (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_REMOTE_GETDIR,       // void    BT_FtcRemoteGetDir(Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_REMOTE_CHDIR,        // void    BT_FtcRemoteChDir (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_REMOTE_MKDIR,        // void    BT_FtcRemoteMkDir (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_REMOTE_RMDIR,        // void    BT_FtcRemoteRmDir (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_REMOTE_DEL,          // void    BT_FtcRemoteDel   (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_PUTFILE,             // void    BT_FtcPutFile     (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_GETFILE,             // void    BT_FtcGetFile     (Ftc_InstanceData_t *instData, char * Utf8String);
    BT_FTC_ABORT,               // void    BT_FtcAbort       (Ftc_InstanceData_t *instData);
    
    //--------------------------------------------------------------------------
    BT_OPS_DN_MSG_BASE = BT_FTC_DN_MSG_BASE + 0x0100,		//2432
    //--------------------------------------------------------------------------
    BT_OPS_ACTIVATE,            // void    BT_OpsActivate(Ops_InstanceData_t *instData, uint16_t theSupportedFormats);
    BT_OPS_DEACTIVATE,          // void    BT_OpsDeactivate(Ops_InstanceData_t *instData);
    BT_OPS_DISCONNECT,          // void    BT_OpsDisconnect(Ops_InstanceData_t *instData);
    BT_OPS_GET_ACK,             // void    BT_OpsGetAck(Ops_InstanceData_t *instData, BTMMI_OPS_GET_ACK_T * prim);
    BT_OPS_PUT_ACK,             // void    BT_OpsPutAck(Ops_InstanceData_t *instData, BTMMI_OPS_PUT_ACK_T * prim);

    //--------------------------------------------------------------------------
    BT_OPC_DN_MSG_BASE = BT_OPS_DN_MSG_BASE + 0x0100,		//2688
    //--------------------------------------------------------------------------
    BT_OPC_START_SEARCH,        // void    BT_OpcStartSeatch(Opc_InstanceData_t *instData);
    BT_OPC_STOP_SEARCH,         // void    BT_OpcStopSeatch(Opc_InstanceData_t *instData);
    BT_OPC_PUT_REQ,             // void    BT_OpcPutReq(Opc_InstanceData_t *instData, BTMMI_OPC_PUT_REQ_T * prim);
    BT_OPC_GET_REQ,             // void    BT_OpcGetReq(Opc_InstanceData_t *instData, BTMMI_OPC_GET_REQ_T * prim);
    BT_OPC_XCHG_REQ,            // void    BT_OpcXchgReq(Opc_InstanceData_t *instData, BTMMI_OPC_XCHG_REQ_T * prim);
    BT_OPC_ABORT,               // void    BT_OpcAbort(Opc_InstanceData_t *instData);

    //--------------------------------------------------------------------------
    BT_SYNC_DN_MSG_BASE = BT_OPC_DN_MSG_BASE + 0x0100,	//2944
    //--------------------------------------------------------------------------
    BT_SYNC_ACTIVATE,            // void    BT_SyncActivate(Sync_InstanceData_t *instData, bool_t lowSecurity);
    BT_SYNC_DEACTIVATE,          // void    BT_SyncDeactivate(Sync_InstanceData_t *instData);
    BT_SYNC_DISCONNECT,          // void    BT_SyncDisconnect(Sync_InstanceData_t *instData);
    BT_SYNC_AUTHENTICATE,        // void    BT_SyncAuthenticate(Sync_InstanceData_t *instData, BTMMI_OSS_AUTH_T * prim);

    //--------------------------------------------------------------------------
    BT_AV_DN_MSG_BASE = BT_SYNC_DN_MSG_BASE + 0x0100,		//3200
    //--------------------------------------------------------------------------
    BT_AV_ACTIVATE_REQ,		// void    BT_AvActivateReq(Av_InstanceData_t *instData);
    BT_AV_DEACTIVATE_REQ,	// void    BT_AvDeactivateReq(Av_InstanceData_t *instData);
    BT_AV_START_SEARCH_REQ,     // void    BT_AvStartSeatch(Av_InstanceData_t *instData);
    BT_AV_STOP_SEARCH_REQ,      // void    BT_AvStopSeatch(Av_InstanceData_t *instData);
    BT_AV_CONNECT_REQ,       	// void    BT_AvConnectReq(Av_InstanceData_t *instData, BTMMI_CONNECT_REQ_T * prim);
    BT_AV_DISCONNECT_REQ,       // void    BT_AvDisconnectReq(Av_InstanceData_t *instData);
    BT_AV_GET_CAPABILITIES_REQ, // void    BT_AvGetCapabilitiesReq(Av_InstanceData_t *instData);
    BT_AV_SET_CONFIGURATION_REQ,// void    BT_AvSetCapabilitiesReq(Av_InstanceData_t *instData);
    BT_AV_GET_CONFIGURATION_REQ,// void    BT_AvGetConfigurationReq(Av_InstanceData_t *instData);
    BT_AV_RECONFIGURE_REQ,      // void    BT_AvReconfigureReq(Av_InstanceData_t *instData);
    BT_AV_START_REQ,            // void    BT_AvStartReq(Av_InstanceData_t *instData);
    BT_AV_STOP_REQ,             // void    BT_AvStopReq(Av_InstanceData_t *instData);
    BT_AV_PAUSE_REQ,            // void    BT_AvPauseReq(Av_InstanceData_t *instData);
    BT_AV_RESUME_REQ,           // void    BT_AvResumeReq(Av_InstanceData_t *instData);
    BT_AV_ABORT_REQ,            // void    BT_AvAbortReq(Av_InstanceData_t *instData);


    //--------------- LGE_MERGE_BLUETOOTH KANE_BT job050518 --------------------
    BT_BPP_DN_MSG_BASE = BT_AV_DN_MSG_BASE + 0x0100,		//3456
    //--------------------------------------------------------------------------
    BT_BPP_START_SEARCH,   //void  BT_
    BT_BPP_STOP_SEARCH,
    BT_BPP_CONNECT, /* JIN100_BT_BPP */
    BT_BPP_GET_PRINTER_ATTRIBUTE_REQ,
    BT_BPP_GET_PRINTER_ATTRIBUTE_RES,
    BT_BPP_SEND_DOCUMENT_REQ,
    BT_BPP_SEND_DOCUMENT_RES,
    BT_BPP_CREATE_JOB_REQ,
    BT_BPP_AUTHENTICATE_RES,
    BT_BPP_ABORT_REQ,
    BT_BPP_DISCONNECT,
    BT_BPP_AUTHENTICATE,
//    BT_BPP_SEND_XHTML,
    //------------- End of KANE_BT job050518 -------------------------------------	

    //--------------------------------------------------------------------------
    // Upstream Messages from BCHS to MMI
    //--------------------------------------------------------------------------
    BT_MMI_UP_STREAM = 0x8000,							//32768
    //--------------------------------------------------------------------------
    // Stack task management
    BT_TASK_LAUNCH_COMPLETE,
    BT_TASK_LAUNCH_FAIL,
    BT_TASK_SHUTDOWN_COMPLETE,

    //--------------------------------------------------------------------------
    BT_APP_UP_MSG_BASE = BT_MMI_UP_STREAM + 0x0100,	//33024
    //--------------------------------------------------------------------------
    // Application Management
    BT_APP_INIT_CFM,
    BT_APP_SET_LOCAL_NAME_CFM,
    BT_APP_VISIBILITY_CFM,
    BT_APP_TEST_MODE_CFM,
    BT_APP_BYPASS_MODE_CFM,
    BT_APP_READ_RSSI_CFM,
    BT_APP_READ_LOCAL_BDADDR_CFM,

    //--------------------------------------------------------------------------
    BT_SDP_UP_MSG_BASE = BT_APP_UP_MSG_BASE + 0x0100,	//33280
    //--------------------------------------------------------------------------
    // SC & DM : Security & Device managemenr Service Application
    BT_SDP_READ_REMOTE_NAME_CFM,    // BTMMI_PEER_NAME_T
    BT_SDP_DISCOVERY_CFM,
    BT_SDP_CANCEL_DISCOVERY_CFM,
    BT_SDP_DISCOVERY_RESULT_IND,    // BTMMI_SDS_INFO_T
    BT_SDP_INPUT_PASSKEY_IND,       // BTMMI_SDS_INFO_T
    BT_SDP_AUTHORISE_IND,           // LGBX_BD_ADDR_TYPE
    BT_SDP_BOND_CFM,		        // LGBX_BD_ADDR_TYPE (NULL address will be returned if fail)
    BT_SDP_BOND_IND,		        // LGBX_BD_ADDR_TYPE : bonding result which was initiated by remote device
    BT_SDP_DEBOND_CFM,		        // LGBX_BD_ADDR_TYPE
    BT_SDP_DB_ADD_IND,              // LGBX_BD_ADDR_TYPE
    BT_SDP_DB_UPDATE_IND,           // LGBX_BD_ADDR_TYPE
    BT_SDP_DB_ERASE_IND,            // LGBX_BD_ADDR_TYPE
    BT_SDP_DB_NO_STORAGE_IND,       // LGBX_BD_ADDR_TYPE
    BT_SDP_READ_SERVICE_LIST_CFM,   // LGBX_BD_ADDR_TYPE
    BT_SDP_CACHE_ADD_IND,           // LGBX_BD_ADDR_TYPE
    BT_SDP_CACHE_UPDATE_IND,        // LGBX_BD_ADDR_TYPE
    BT_SDP_CACHE_ERASE_IND,         // LGBX_BD_ADDR_TYPE
    BT_SDP_CACHE_NO_STORAGE_IND,    // LGBX_BD_ADDR_TYPE
#ifndef ADI_EXCLUDE_BPP_UPGL
    BT_SDP_QUERY_SOME_SVC_CFM,	
#endif    

    //--------------------------------------------------------------------------
    BT_AGW_UP_MSG_BASE = BT_SDP_UP_MSG_BASE + 0x0100,		//33536
    //--------------------------------------------------------------------------
    // AudioGateway
    BT_AGW_ACTIVATE_CFM,            // No parameter
    BT_AGW_DEACTIVATE_CFM,          // No parameter
    BT_AGW_CONNECT_IND,             // BTMMI_CONNECT_T
    BT_AGW_DISCONNECT_IND,          // BTMMI_DISCONNECT_T
    BT_AGW_ANSWER_IND,              // No parameter
    BT_AGW_AUDIO_IND,               // BTMMI_SCO_... in IParam
    BT_AGW_RING_START_IND,          // No parameter
    BT_AGW_RING_STOP_IND,           // No parameter
    BT_AGW_ON_HOOK_IND,             // No parameter
    BT_AGW_SPK_CHANGE_IND,          // Gain (0..15) in IParam
    BT_AGW_MIC_CHANGE_IND,          // Gain (0..15) in IParam
    BT_AGW_AT_CMD_MSG_IND,          // BTMMI_STRING_T

    //--------------------------------------------------------------------------
    BT_HFG_UP_MSG_BASE = BT_AGW_UP_MSG_BASE + 0x0100,		//33792
    //--------------------------------------------------------------------------
    // HandsfreeGateway
    BT_HFG_ACTIVATE_CFM,            // No parameter
    BT_HFG_DEACTIVATE_CFM,          // No parameter
    BT_HFG_CONNECT_IND,             // BTMMI_CONNECT_T
    BT_HFG_DISCONNECT_IND,          // BTMMI_DISCONNECT_T

    BT_HFG_RING_STATUS_IND,         // No parameter
    BT_HFG_AUDIO_STATUS_IND,        // BTMMI_SCO_... in IParam
    BT_HFG_AUDIO_TYPE_CFM,          // BTMMI_SCO_... in IParam
    BT_HFG_SPK_CHANGE_IND,          // Gain (0..15) in IParam
    BT_HFG_MIC_CHANGE_IND,          // Gain (0..15) in IParam

    BT_HFG_AT_CMD_MSG_IND,          // BTMMI_STRING_T
    BT_HFG_ANSWER_IND,              // No parameter
    BT_HFG_REJECT_IND,              // No parameter
    BT_HFG_CALL_HOLD_IND,           // IParam : 0,1,2,3 or 4
    BT_HFG_DIAL_STR_IND,            // BTMMI_STRING_T
    BT_HFG_DIAL_NUM_IND,            // Index of phonebook
    BT_HFG_DIAL_LAST_IND,           // No parameter
    BT_HFG_DIAL_VOICE_IND,          // Voice Dialing (recognition) enable/diable status in IParam
    BT_HFG_DTMF_IND,                // ASCII Code : '1','2','3','4','5','6','7','8','9','0','*','#'
    // $suhui HFP1.5
    BT_HFG_OPERATOR_SELECTION_IND,         // AT+COPS?
    BT_HFG_EXTENDED_ERROR_ENABLE_IND,      // AT+CMEE = 1
    BT_HFG_EXTENDED_ERROR_DISABLE_IND,     // AT+CMEE = 0
    BT_HFG_SUBSCRIBER_NUM_IND,             // AT+CNUM
    BT_HFG_CURRENT_CALL_LIST_IND,          // AT+CLCC
    BT_HFG_CIND_IND,					// AT+CIND
    BT_HFG_3WAY_IND,					// AT+CHLD
    //--------------------------------------------------------------------------
    BT_SPP_UP_MSG_BASE = BT_HFG_UP_MSG_BASE + 0x0100,		//34048
    //--------------------------------------------------------------------------
    // SerialPort
    BT_SPP_ACTIVATE_CFM,            // instId,
    BT_SPP_DEACTIVATE_CFM,          // instId,
    BT_SPP_CONNECT_IND,             // BTMMI_CONNECT_T
    BT_SPP_DISCONNECT_IND,          // BTMMI_DISCONNECT_T
    BT_SPP_CONTORL_IND,
    BT_SPP_PORTNEG_IND,
    BT_SPP_SERVICE_NAME_IND,
    BT_SPP_DATA_IND,                // instId, data arrived from peer device
    BT_SPP_TX_PUMP_CFM,             // instId, all the data has flushed out
    BT_SPP_RX_PUMP_CFM,             // instId, all the data has flushed out

    //--------------------------------------------------------------------------
    BT_DUN_UP_MSG_BASE = BT_SPP_UP_MSG_BASE + 0x0100,		//34304
    //--------------------------------------------------------------------------
    // Dial Up Networking
    BT_DUN_ACTIVATE_CFM,            // No parameter
    BT_DUN_DEACTIVATE_CFM,          // No parameter
    BT_DUN_CONNECT_IND,             // BTMMI_CONNECT_T
    BT_DUN_DISCONNECT_IND,          // BTMMI_DISCONNECT_T
    BT_DUN_CONTORL_IND,
    BT_DUN_PORTNEG_IND,
    BT_DUN_DATA_IND,                // instId, data arrived from peer device
    BT_DUN_TX_PUMP_CFM,             // instId, all the data has flushed out
    BT_DUN_RX_PUMP_CFM,             // instId, all the data has flushed out

    //--------------------------------------------------------------------------
    BT_FTS_UP_MSG_BASE = BT_DUN_UP_MSG_BASE + 0x0100,		//34560
    //--------------------------------------------------------------------------
    // OBEX Ftp Server
    BT_FTS_SET_ROOT_DIR_CFM,        // IParam = 0 : success, other fails
    BT_FTS_ACTIVATE_CFM,            // No parameter
    BT_FTS_DEACTIVATE_CFM,          // No parameter
    BT_FTS_CONNECT_IND,	            // BTMMI_CONNECT_T
    BT_FTS_DISCONNECT_IND,          // BTMMI_DISCONNECT_T
    BT_FTS_AUTHENTICATE_IND,        // BTMMI_OSS_AUTH_IND_T
    BT_FTS_DIR_CHANGE_IND,          // BTMMI_DIR_CHANGE_T
    BT_FTS_ACTION_IND,              // BTMMI_OBEX_ACTION_T when doing put or get
	BT_FTS_ABORT_IND,				// No parameter
    BT_FTS_DEL_OBJ_IND,            // IParam = 0 : success, other fails
    BT_FTS_GET_OBJ_COMPLETE_IND,    // IParam = 0 : success, other fails
    BT_FTS_PUT_OBJ_COMPLETE_IND,    // IParam = 0 : success, other fails
    BT_FTS_GETFILE_CFM,
    BT_FTS_ABORT_CFM,
    //--------------------------------------------------------------------------
    BT_FTC_UP_MSG_BASE = BT_FTS_UP_MSG_BASE + 0x0100,		//34816
    //--------------------------------------------------------------------------
    // OBEX Ftp Client
    BT_FTC_SET_ROOT_DIR_CFM,        // IParam = 0 : success, other fails
    BT_FTC_SEARCH_RESULT_IND,       // BTMMI_SDS_INFO_T
    BT_FTC_SEARCH_CFM,              // IParam = 0 : success, other fails
    BT_FTC_CONNECT_CFM,	            // BTMMI_CONNECT_T
    BT_FTC_DISCONNECT_CFM,          // BTMMI_DISCONNECT_T
    BT_FTC_DISCONNECT_IND,          // BTMMI_DISCONNECT_T
    BT_FTC_AUTHENTICATE_IND,        // BTMMI_OCS_AUTH_IND_T
    BT_FTC_LOCAL_GETDIR_CFM,        // IParam = 0 : success, other fails
    BT_FTC_LOCAL_CHDIR_CFM,         // IParam = 0 : success, other fails
    BT_FTC_LOCAL_MKDIR_CFM,         // IParam = 0 : success, other fails
    BT_FTC_LOCAL_RMDIR_CFM,         // IParam = 0 : success, other fails
    BT_FTC_LOCAL_DEL_CFM,           // IParam = 0 : success, other fails
    BT_FTC_REMOTE_GETDIR_CFM,       // IParam = 0 : success, other fails
    BT_FTC_REMOTE_CHDIR_CFM,        // IParam = 0 : success, other fails
    BT_FTC_REMOTE_MKDIR_CFM,        // IParam = 0 : success, other fails
    BT_FTC_REMOTE_RMDIR_CFM,        // IParam = 0 : success, other fails
    BT_FTC_REMOTE_DEL_CFM,          // IParam = 0 : success, other fails
    BT_FTC_PUTFILE_CFM,             // IParam = 0 : success, other fails
    BT_FTC_GETFILE_CFM,             // IParam = 0 : success, other fails
    BT_FTC_ABORT_CFM,               // IParam = 0 : success, other fails
    BT_FTC_DIR_CHANGE_IND,          // BTMMI_DIR_CHANGE_T
    BT_FTC_DIR_LIST_IND,            // BTMMI_DIR_LIST_T
    BT_FTC_ACTION_IND,              // BTMMI_OBEX_ACTION_T when doing put or get

    //--------------------------------------------------------------------------
    BT_OPS_UP_MSG_BASE = BT_FTC_UP_MSG_BASE + 0x0100,		//35072
    //--------------------------------------------------------------------------
    // OBEX Push Server
    BT_OPS_ACTIVATE_CFM,            // No parameter
    BT_OPS_DEACTIVATE_CFM,          // No parameter
    BT_OPS_CONNECT_IND,	            // BTMMI_CONNECT_T
    BT_OPS_DISCONNECT_IND,          // BTMMI_DISCONNECT_T
    BT_OPS_GET_IND,                 // BTMMI_OPS_GET_IND_T
    BT_OPS_GET_CFM,                 // IParam = 0 : success, other fails
    BT_OPS_PUT_IND,                 // BTMMI_OPS_PUT_IND_T
    BT_OPS_PUT_CFM,                 // IParam = 0 : success, other fails
    BT_OPS_OBJ_IND,                 // BTMMI_OPP_OBJECT_T
	BT_OPS_ACTION_IND,		        // BTMMI_OBEX_ACTION_T
    BT_OPS_PUT_METHOD_IND,
    BT_OPS_GET_METHOD_IND,
    BT_OPS_ABORT_CFM,
    //--------------------------------------------------------------------------
    BT_OPC_UP_MSG_BASE = BT_OPS_UP_MSG_BASE + 0x0100,		//35328
    //--------------------------------------------------------------------------
    // OBEX Push Client
    BT_OPC_SEARCH_RESULT_IND,       // BTMMI_OPC_SDS_INFO_T
    BT_OPC_SEARCH_CFM,
    BT_OPC_CONNECT_CFM,             // BTMMI_CONNECT_T
    BT_OPC_DISCONNECT_IND,          // BTMMI_DISCONNECT_T
    BT_OPC_GET_CFM,                 // IParam = 0 : success, other fails
    BT_OPC_PUT_CFM,                 // IParam = 0 : success, other fails
    BT_OPC_EXCHANGE_CFM,            // IParam = 0 : success, other fails
    BT_OPC_OBJ_IND,                 // BTMMI_OPP_OBJECT_T when doing get or exchange
    BT_OPC_ABORT_CFM,
	BT_OPC_ACTION_IND,		   // BTMMI_OBEX_ACTION_T

    //--------------------------------------------------------------------------
    BT_SYNC_UP_MSG_BASE = BT_OPC_UP_MSG_BASE + 0x0100,	//35584
    //--------------------------------------------------------------------------
    // OBEX Sync Server
    BT_SYNC_CONNECT_CFM,             // BTMMI_CONNECT_T
    BT_SYNC_DISCONNECT_IND,          // BTMMI_DISCONNECT_T
    BT_SYNC_GET_CFM,                 // IParam = 0 : success, other fails
    BT_SYNC_PUT_CFM,                 // IParam = 0 : success, other fails

    //--------------------------------------------------------------------------
    BT_AV_UP_MSG_BASE = BT_SYNC_UP_MSG_BASE + 0x0100,		//35840
    //--------------------------------------------------------------------------
    // AV Server/Client
    BT_AV_ACTIVATE_CFM,             // No parameter
    BT_AV_DEACTIVATE_CFM,           // No parameter
    BT_AV_START_SEARCH_CFM,          // IParam = 0 : success, IParam = -1 : fail
    BT_AV_STOP_SEARCH_CFM,          // IParam = 0 : success, IParam = -1 : fail

    BT_AV_CONNECT_CFM,              // BTMMI_CONNECT_T
    BT_AV_DISCONNECT_CFM,           // BTMMI_DISCONNECT_T
    BT_AV_START_CFM,
    BT_AV_STOP_CFM,
    BT_AV_PAUSE_CFM,
    BT_AV_RESUME_CFM,
    BT_AV_ABORT_CFM,

    BT_AV_SEARCH_RESULT_IND,        // BTMMI_AV_SDS_INFO_T
    BT_AV_CONNECT_IND,              // BTMMI_CONNECT_T
    BT_AV_DISCONNECT_IND,           // BTMMI_DISCONNECT_T
    BT_AV_START_IND,
    BT_AV_STOP_IND,
    BT_AV_PAUSE_IND,
    BT_AV_RESUME_IND,
    BT_AV_ABORT_IND,

    //--------------- LGE_MERGE_BLUETOOTH KANE_BT job050518 --------------------
    BT_BPP_UP_MSG_BASE = BT_AV_UP_MSG_BASE + 0x0100,		//36096
    //--------------------------------------------------------------------------
    // Basic Printing Profile
    BT_BPP_SEARCH_RESULT_IND,
    BT_BPP_SEARCH_CFM,
    BT_BPP_CONNECT_CFM,
    BT_BPP_GET_PRINTER_ATTRIBUTE_IND,
    BT_BPP_GET_PRINTER_ATTRIBUTE_CFM,
    BT_BPP_SEND_DOCUMENT_IND,
    BT_BPP_SEND_DOCUMENT_CFM,
    BT_BPP_AUTHENTICATE_IND,
    BT_BPP_DISCONNECT_CFM, 
    BT_BPP_DISCONNECT_IND,
    BT_BPP_CREATE_JOB_CFM,
    BT_BPP_ABORT_CFM,
    BT_BPP_ACTION_IND,
    //------------- End of KANE_BT job050518 -------------------------------------	
	BT_BPP_PRINT_CFM ,
    BT_AG_ZERO_EVENT,
    BT_AG_ONE_EVENT ,
    BT_AG_TWO_EVENT,
    BT_AG_THREE_EVENT,
    BT_AG_FOUR_EVENT,
    BT_AG_FIVE_EVENT ,
    BT_AG_SIX_EVENT ,
    BT_AG_SEVEN_EVENT,
    BT_AG_EIGHT_EVENT,
    BT_FTP_ENABLE_IND,
    BT_OPP_ENABLE_IND,
    BT_OBEX_ENABLE_IND, /* BT_COMMON_KIMSANGJIN_071106 */
    BT_SPP_ENABLE_IND,
    BT_DUN_ENABLE_IND,
    BT_HSP_ENABLE_IND,
    BT_PBAP_ENABLE_IND,
    BT_HFP_ENABLE_IND,
    BT_FTP_DISABLE_IND,
    BT_OPP_DISABLE_IND,
    BT_OBEX_DISABLE_IND, /* BT_COMMON_KIMSANGJIN_071106 */
    BT_SPP_DISABLE_IND,
    BT_DUN_DISABLE_IND,
    BT_HSP_DISABLEE_IND,
    BT_HFP_DISABLE_IND,
    BT_PBAP_DISABLE_IND,
    //--------------------------------------------------------------------------
    // Top of MMI message types
    //--------------------------------------------------------------------------
    BT_MMI_LAST_STREAM
}BTMMIMSG;

#endif /* LGE_MMI_BLUETOOTH */

#endif /* MMIBXIF_H */


