/***************************************************************************
 * LG Electronics Copyright (c) KEVIN_BT job100502
 ***************************************************************************
 * $Id: //central/releases/Branch_release_8/tplgsm/BLUETOOTH/lgeBtSpalhi.c#1 $
 * $Revision: #1 $
 * $DateTime: 2006/08/11 09:25:26 $
 ***************************************************************************
 *  File Description :
 *      Bluetooth layer 2 and layer 1 protocol elements.
 *      task runs at high priority (just under timers)
 *      interrupts run at high priority
 *
 *      The BLUETOOTH protocol is taken from BTE 3.0
 *
 * $Author : KEVIN PIEN(KYUE SUP BYUN) :-), KIM SANG JIN, KANG HYUNG WOOK
 *
 **************************************************************************/

#define MODULE_NAME "LGEBTSPALHI"

#if defined (LGE_L1_BLUETOOTH)
/***************************************************************************
** Include Files
***************************************************************************/
#include <system.h>
#include <string.h>
#include <kernel.h>
#include <kioslow.h>
#include <plkmirq.h>
#include <dlemmihi.h>
#include <l1debug.h>
#include <emmiev.h>
#include <Dlegsp.h>
#include <dldmadrv.h>
#include <dlemmihi.h>
#include <kirlgutl.h>

#if defined(UPGRADE_500_PLATFORM)
#include "dl500tick.h"
#include <dlirqdef.h>
#elif defined(UPGRADE_430_PLATFORM)
#include <dl430irq.h>
#include <dldmadrv.h>
#endif

#if !defined (LGEBTSPALHI_H)
#include "lgeBtSpalhi.h"
#endif

#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

#if !defined(L1BTIF_H)
#include "l1btif.h"
#endif

#if defined(LGE_BRCM_BLUETOOTH)
#include "userial_ttpcom.h"
#include "userial.h"
#endif

#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
#include "dlsingleuart.h"
#endif

/****************************************************************************
* Mainfest Constants / Defines
****************************************************************************/
#if defined(GENIE_VIA_BLUETOOTH)
/* Control Frames */
#define	BT_ACK_OCTET		6
#define	BT_NAK_OCTET		21

/* Frame Structure */
#define	BT_STX_OCTET		2
#define	BT_ETX_OCTET		3
#endif /* GENIE_VIA_BLUETOOTH */

/*******************************************************************************
** Define: BT_L2_PACKET_HEAD_LENGTH
** Description: Number of bytes before the data in the EMMI Layer 2 Packet. This
**                  is the STX and Length fields.
*******************************************************************************/
#define BT_L2_PACKET_HEAD_LENGTH     (2)

/*******************************************************************************
** Define: BT_L2_PACKET_TAIL_LENGTH
** Description: Number of bytes after the data in the EMMI Layer 2 Packet. This
**                  is the Checksum and ETX fields.
*******************************************************************************/
#define BT_L2_PACKET_TAIL_LENGTH     (2)

/*
** If Host does notsend the ack in 1.5 seconds then retransmit after 1.5 sec
*/
# if defined (EMMI_BAUD_RATE_19200)
#  define BT_ACK_TIMEOUT_PERIOD        MILLISECONDS_TO_TICKS (800)
# elif defined (EMMI_BAUD_RATE_38400)
#  define BT_ACK_TIMEOUT_PERIOD        MILLISECONDS_TO_TICKS (400)
# elif defined (EMMI_BAUD_RATE_57600)
#  define BT_ACK_TIMEOUT_PERIOD        MILLISECONDS_TO_TICKS (200)
# elif defined (EMMI_BAUD_RATE_115200)
#  define BT_ACK_TIMEOUT_PERIOD        MILLISECONDS_TO_TICKS (100)
# elif defined (EMMI_BAUD_RATE_230400)
#  define BT_ACK_TIMEOUT_PERIOD        MILLISECONDS_TO_TICKS (50)
# else /* 9600 */
#  define BT_ACK_TIMEOUT_PERIOD        MILLISECONDS_TO_TICKS (1500)
# endif

/*
** If Host sends a nak then retransmit in 100 ms - this gives the Host
** time to empty its rx queue
*/
#define BT_RETRANS_TIMEOUT_PERIOD      MILLISECONDS_TO_TICKS (100)

/****************************************************************************
* Macros
****************************************************************************/
/* Macro to make core code more readable */
#define M_BtDisableTxBufferReadyInt() DlSpalDisableTxBufferReadyInt ( btPortHandle )
/* Macro to make core code more readable */
#define M_BtEnableTxBufferReadyInt() DlSpalEnableTxBufferReadyInt ( btPortHandle )

#define M_BtDisableRxBufferReadyInt() DlSpalDisableRxDataReadyInt ( btPortHandle )
#define M_BtDisableRxBufferReadyInt() DlSpalDisableRxDataReadyInt ( btPortHandle )

/* Macro to make core code more readable */
#define M_BtTxByte(bYTE) DlSpalTxByte(btPortHandle, bYTE)
#define M_BtTxMuxByte(bYTE) DlSpalTxByte(muxPortHandle, bYTE)


/* Macro to make core code more readable */
#define M_BtRxByte(bYTE) DlSpalRxByte(btPortHandle, bYTE)

#define M_BtDmaWriteByte(bYTE)       \
{                                      \
    M_BtDisableTxBufferReadyInt();   \
    *btDmaTxHoldEndPtr = bYTE;       \
    btDmaTxHoldEndPtr++;             \
    M_BtEnableTxBufferReadyInt();    \
}

#define M_BtAbortTransmission()   /* from task */  \
      dlDisableIrq();                            \
      /* Reset Tx Hold buffer and init state */  \
      btDmaTxHoldEndPtr = btDmaTxHoldBuffer; \
      dlEnableIrq();


/***************************************************************************
** Type definitions
***************************************************************************/
#if defined(BT_UART_PERFORMANCE_TEST)
typedef struct
{
    Int32 index;
    Int8  expected;
    Int8  received;
} BT_TEST_ERR_TYPE;
#endif

/***************************************************************************
** Variables
***************************************************************************/
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 04Aug2006 */
static BT_TEST_STATE_TYPE btTestState = BT_UART_NO_STATE_S;
DlSpalBaudRate btTestBaudrate = SPAL_BAUD_115200;
    
Int8 btTestData[] =
{
#include "btTestData.bin"
};

const Int32 btTestDataSize = sizeof(btTestData);

Int8 btTestRxData[btTestDataSize + 1024] = {0};
Int32 btTestRxDataIdx = 0;

Int32 btTestTxBufferIndex = 0;
Int32 btTestRxBufferIndex = 0;

Int8 btTestRxTempBuffer[BT_TEST_RX_TEMP_BUF_SIZE] = {0};
Int8 btTestCmdBuffer[BT_TEST_CMD_SIZE + 2];

Boolean btTestCmdDetected = FALSE;
Int8 btTestRxCmdBuffer[BT_TEST_CMD_SIZE];
Int8 btTestRxCmdBufferCnt = 0;

Int32 btTestStatisticRxCnt = 0;
Int32 btTestStatisticRxErrCnt = 0;
Int32 btTestStatisticTxCnt = 0;
Int32 btTestStatisticTxErrCnt = 0;

Int32 btTestStartTime = 0;
Int32 btTestEndTime = 0;
Int32 btTestDurationTime = 0;
float btTestDurationTimeInSecond = 0.0;
Int32 btTestPerformance = 0;

Boolean btTestRxEnd = FALSE;
Boolean btTestTxEnd = FALSE;
Boolean btTestRxEndSent = FALSE;
Boolean btTestTxEndSent = FALSE;
Boolean btTestStarted = FALSE;
DlSpalDataLocation btTestNextNotif = BT_TEST_115200_NEXT_NOTIF;
Boolean first_err = TRUE;
BT_TEST_ERR_TYPE btTestErr[BT_TEST_ERR_BUF_SIZE];
const Int8 btTestCmd[BT_TEST_CMD_MAX][BT_TEST_CMD_SIZE + 1] = 
{
    "0", // BT_TEST_NOT_CMD
    "A", // BT_TEST_CONNECT_CMD
    "B", // BT_TEST_CONNECT_ACK_CMD
    "C", // BT_TEST_TX_END_CMD
    "D", // BT_TEST_BAUDRATE_CHANGE_CMD
    "E", // BT_TEST_BAUDRATE_CHANGE_ACK_CMD
};
#endif	/* BT_UART_PERFORMANCE_TEST */

#if defined(GENIE_VIA_BLUETOOTH)

static Int8    btGenieTxHoldBuffer [BT_TX_BUFF_SIZE + 1];	
static Int8   *btGenieTxHoldEndPtr;
static Int8    btGenieRxHoldBuffer [BT_RX_BUFF_SIZE + 1];

static BtBlockState  btTxBlockState = BT_IDLE;
static BtBlockState  btRxBlockState = BT_IDLE;

static BtTxState     btTxState      = BT_TX_IDLE;
static Boolean btDmaBlockAddedToFifo = FALSE;

#if !defined (NO_EMMI_INTERFACE)
extern TxInterruptBlock txInterruptBlock;
extern RxInterruptBlock rxInterruptBlocks[BT_MAX_NUM_RX_BLOCKS];
#else
TxInterruptBlock txInterruptBlock;
RxInterruptBlock rxInterruptBlocks[BT_MAX_NUM_RX_BLOCKS];
#endif

/* KANE_BT job050529 */
static RxInterruptBlock *btrxInterruptBlockInUse;
Int16 btCurrentRxBlock;

#if 0 /* KANE_BT job050225 for BT GENIE*/ /* LGE_K_JIN100_WARNING_050321 */
static Int16   btDmaRxCurrentBlockLength;
#endif

#if !defined (EMMI_UART_DMA_MODE)
Boolean btsendANakAsap = FALSE;
Boolean btsendAnAckAsap = FALSE;
#endif

#define BtTransmitByte       BtUartStartByteTransmit

#endif /* GENIE_VIA_BLUETOOTH */

KiTimer                  btAckTimer;
KiTimer                  btRetransTimer;
KiTimer                  btDmaRxPollTimer;
#if defined(BT_UART_PERFORMANCE_TEST)
KiTimer                  btTestStartTimer;
#endif

static Boolean btDmaRxPollActive = FALSE;
static Boolean btDmaTxInProgress = FALSE;
static Int16   btRxPollIdleCount = 0;

static Int8    btDmaTxHoldBuffer [BT_TX_BUFF_SIZE + 1];
static Int8    btDmaRxHoldBuffer [BT_RX_BUFF_SIZE + 1];
static Int8   *btDmaTxHoldEndPtr;

static Int8   *btDmaRxHoldPtr;
static Int8   *btDmaRxHoldEndPtr;

static Int16 BT_RX_POLL_IDLE_COUNT_MAX = BT_RX_POLL_IDLE_TIME_MAX/BT_RX_DATA_POLL_PERIOD_115200;

DlSpalHandle btPortHandle     = SPAL_INVALID_HANDLE;
DlSpalBufferType btSpalBufferType = SPAL_BUFF_NONE;
DlSpalBaudRate Btbaudrate=SPAL_BAUD_115200; /* BT_COMMON_KIMSANGJIN_070130  noti_011002*/
DlSpalDataLocation BT_RX_NOTIFY = BT_NEXT_NOTIF_115200;

#if defined(LGE_CSR_BLUETOOTH) /* Sean_070823: changed uart callback structure */
static struct {
    void    (*txCallback)(void);
    void    (*rxCallback)(void*, int);
} gUartCallback = {NULL, NULL};
#endif /* LGE_CSR_BLUETOOTH */

#if defined(LGE_BRCM_BLUETOOTH)
bt_uint8 rxbuffer[BT_RX_QUEUE_SIZE];
BtQueue rxQueue = {BT_RX_QUEUE_SIZE,0,0,0,rxbuffer};

Int8 btDmaRxBuffer[BT_RX_BUFF_SIZE];
Int8 btDmaTxBuffer[BT_TX_BUFF_SIZE];
#endif /* LGE_BRCM_BLUETOOTH */

#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
/* indicator as to whether the serial line is enabled     */
/* Treat as read only and set using bluetoothDteEnable_UART        */
DlSpalPortId btDlSpalPortId = SPAL_PORT_BT_1;
Boolean btSerialLineIsEnabled = FALSE;

extern DlSpalPortId vgmuxDlSpalPortId;
extern DlSpalPortId emmiDlSpalPortId;
extern Boolean vgmuxSerialLineIsEnabled;
extern Boolean emmiSerialLineIsEnabled;
extern void vgmuxDteEnable_UART(Boolean enable, DlSpalPortId port);
extern void emmiDteEnable_UART(Boolean enable, DlSpalPortId port);
#endif /* LGE_L1_SINGLE_UART */

extern DlSpalHandle emmiPortHandle;
extern DlSpalPortId muxPortHandle;/* KANE_BT job041209 Bypass */

extern Boolean BtFlag_IsEnabled(void);
#if defined (LGE_ATLAS_BLUETOOTH)
extern void BtClearRTS(void);
extern void BtSetRTS(void);
#endif

#if defined(GENIE_VIA_BLUETOOTH)
extern void BtCommonSPPGenieReadData(UINT8 * data,int *nbytes);
extern void BtCommonSPPGenieWriteData(UINT8 * data,int *nbytes);
#endif

/****************************************************************************
** Local Functions
****************************************************************************/
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 28Jul2006 */
void btTestPowerUp(void)
{
    static Boolean bConfigured = FALSE;

    if(!bConfigured)
    {
        bConfigured = TRUE;
        BtPowerUpBTModule();
    }
}

BT_TEST_STATE_TYPE btTestStateGet(void)
{
    return btTestState;
}

void btTestInitVar(void)
{
    btTestTxBufferIndex = 0;
    btTestRxBufferIndex = 0;

    btTestCmdDetected = FALSE;
    btTestRxCmdBufferCnt = 0;

    btTestStatisticRxCnt = 0;
    btTestStatisticRxErrCnt = 0;
    btTestStatisticTxCnt = 0;
    btTestStatisticTxErrCnt = 0;

    btTestStartTime = 0;
    btTestEndTime = 0;
    btTestDurationTime = 0;
    btTestPerformance = 0;

    btTestRxEnd = FALSE;
    btTestTxEnd = FALSE;
    btTestRxEndSent = FALSE;
    btTestTxEndSent = FALSE;

    first_err = TRUE;

    memset(btTestRxData, 0xFF, sizeof(btTestRxData));
    btTestRxDataIdx = 0;

}

void btTestStateSet(BT_TEST_STATE_TYPE state)
{
    int i;
    
    printf("btTestStateSet() : from %d to %d", btTestState, state);
    if(btTestState == BT_UART_CONNECTED_S && state == BT_UART_IDLE_S)
    {
        extern void btTestCheckResult(void);
        
        btTestCheckResult();
    }
    btTestState = state;
}

void btTestSendHciReset(void)
{
    Int8 HCI_RESET[] = {0x01, 0x03, 0x0C, 0x00};
    
    DelayMilliseconds(100);
    DlSpalTxFromBuffer(btPortHandle, HCI_RESET, 4);
    
    printf("Sent HCI_RESET");
}

void btTestSendCmd(BT_TEST_UART_CMD_TYPE cmd)
{
    
    Int16 sentBytes = 0;

    btTestCmdBuffer[0] = BT_TEST_CMD_FLAG;
    memcpy(&btTestCmdBuffer[1], btTestCmd[cmd], BT_TEST_CMD_SIZE);
    btTestCmdBuffer[BT_TEST_CMD_SIZE + 1] = BT_TEST_CMD_FLAG;
        
    DlSpalDisableTxBufferReadyInt(btPortHandle);
    sentBytes = DlSpalTxFromBuffer(btPortHandle, btTestCmdBuffer, BT_TEST_CMD_SIZE + 2);

    if(sentBytes == BT_TEST_CMD_SIZE + 2)
    {
        switch(cmd)
        {
        case BT_TEST_CONNECT_CMD:
            printf("BT_TEST_CONNECT_CMD sent");
            btTestStateSet(BT_UART_CONNECTING_S);
            break;

        case BT_TEST_CONNECT_ACK_CMD:
            printf("BT_TEST_CONNECT_ACK_CMD sent");
            btTestStateSet(BT_UART_CONNECTED_S);
            break;

        case BT_TEST_TX_END_CMD:
            printf("BT_TEST_TX_END_CMD sent");
            btTestTxEndSent = TRUE;            
            break;

        case BT_TEST_BAUDRATE_CHANGE_CMD:
            printf("BT_TEST_BAUDRATE_CHANGE_CMD sent");
            btTestStateSet(BT_UART_BAUDRATE_CHANGING_S);
            break;
            
        default:
            break;
        }
    }
    else
    {
        printf("Could not send a command at one time, So ...");
    }

    DlSpalEnableTxBufferReadyInt(btPortHandle); 
}

BT_TEST_UART_CMD_TYPE btTestCmdParse(Int8* cmd)
{
    int i;
    
    for(i = BT_TEST_CONNECT_CMD; i < BT_TEST_CMD_MAX; i++)
    {
        if(0 == memcmp(cmd, btTestCmd[i], BT_TEST_CMD_SIZE))
        {
            return (BT_TEST_UART_CMD_TYPE) i;
        }
    }
    return BT_TEST_NOT_CMD;
}

BT_TEST_UART_CMD_TYPE btTestCheckCmd(Int8 cmd_data)
{
    if(btTestCmdDetected)
    {
        if(btTestRxCmdBufferCnt < BT_TEST_CMD_SIZE)
        {
            btTestRxCmdBuffer[btTestRxCmdBufferCnt++] = cmd_data;
        }
        else if(cmd_data == BT_TEST_CMD_FLAG)
        {
            btTestCmdDetected = FALSE;
            
            return btTestCmdParse(btTestRxCmdBuffer);
        }
        else
        {
            btTestCmdDetected = FALSE;
            btTestRxCmdBufferCnt = 0; 
        }
    }
    else if(cmd_data == BT_TEST_CMD_FLAG)
    {
        btTestCmdDetected = TRUE;
        btTestRxCmdBufferCnt = 0;
    }

    return BT_TEST_NOT_CMD;
}

void btTestCheckResult(void)
{
    Int32 loopLimit = 0;
    Int32 i = 0;
    Int32 j = 0;
    
    btTestStarted = FALSE;
    btTestEndTime = ReadRawTime();
    btTestDurationTime = btTestEndTime - btTestStartTime;
    btTestDurationTimeInSecond = (float)(btTestDurationTime / 32768.0);
    btTestPerformance = (Int32)(btTestDataSize * 32768.0 * 8.0 / btTestDurationTime);
    printf("BT UART Test Completed : %d", btTestEndTime);

    loopLimit = (btTestRxDataIdx > btTestDataSize) ? (btTestRxDataIdx) : (btTestDataSize);
    for(i = 0, j = 0; i < loopLimit; i++)
    {
        if(btTestCmdDetected || btTestRxData[i] == BT_TEST_CMD_FLAG)
        {
            btTestCheckCmd(btTestRxData[i]);
        }
        else 
        {
            if(btTestData[j] != btTestRxData[i])
            {
                if(btTestStatisticRxErrCnt < 10)
                {
                    printf("  %07d : exp 0x%02X, rcv 0x%02X, >>1 0x%2X", i, btTestData[j], btTestRxData[i], btTestRxData[i] >> 1);
                }
                btTestStatisticRxErrCnt++;
            }
            btTestStatisticRxCnt++;
            j++;
        }
    }
    printf("StatisticRxCnt=%d, StatisticRxErrCnt=%d", btTestStatisticRxCnt, btTestStatisticRxErrCnt);
    printf("%d bps (%d Bytes/%d.%d Sec)", 
        btTestPerformance, btTestDataSize, (int)btTestDurationTimeInSecond, 
        (int)((btTestDurationTimeInSecond - (int)(btTestDurationTimeInSecond)) * 100));
    btTestInitVar();
}

void btTestSendData(void)
{
    Int16 sentBytes = 0;

    DlSpalDisableTxBufferReadyInt(btPortHandle);

    switch(btTestStateGet())
    {
    case BT_UART_CONNECTED_S:
        if(!btTestTxEndSent && btTestStarted)
        {
            if(btTestDataSize - btTestTxBufferIndex > BT_TEST_TX_LENGTH_AT_ONE_TIME)
            {
                sentBytes = DlSpalTxFromBuffer(btPortHandle, &btTestData[btTestTxBufferIndex], BT_TEST_TX_LENGTH_AT_ONE_TIME);
                //printf("sentBytes=%d, btTestTxBufferIndex=%d", sentBytes, btTestTxBufferIndex);                
                btTestTxBufferIndex += sentBytes;
                DlSpalEnableTxBufferReadyInt(btPortHandle);
            }
            else if(btTestDataSize - btTestTxBufferIndex > 0)
            {
                sentBytes = DlSpalTxFromBuffer(btPortHandle, &btTestData[btTestTxBufferIndex], btTestDataSize - btTestTxBufferIndex);
                //printf("sentBytes=%d, btTestTxBufferIndex=%d", sentBytes, btTestTxBufferIndex);
                btTestTxBufferIndex += sentBytes;
                DlSpalEnableTxBufferReadyInt(btPortHandle);
            }
            else
            {
                btTestTxEnd = TRUE;
                btTestSendCmd(BT_TEST_TX_END_CMD);
                if(btTestRxEnd)
                {
                    btTestStateSet(BT_UART_IDLE_S);
                }
            }
        }
        break;
        
    default:
        break;
    }
}

Int16 btTestReceiveData(void)
{
    Int16   dataInDmaBuffer = 0;

    Int16    i;

    DlSpalDataLocation   startAddress;

    switch(btTestStateGet())
    {
    case BT_UART_IDLE_S:
        DlSpalDisableRxBufferIntOnly( btPortHandle );
        dataInDmaBuffer = DlSpalRxIntoBuffer (btPortHandle, btTestRxTempBuffer, BT_TEST_RX_TEMP_BUF_SIZE);
        DlSpalEnableRxBufferIntOnly( btPortHandle );
        for(i = 0; i < dataInDmaBuffer; i++)
        {
            printf("BT_RX[%02d] : 0x%02X", i, btTestRxTempBuffer[i]);
            switch(btTestCheckCmd(btTestRxTempBuffer[i]))
            {
            case BT_TEST_CONNECT_CMD:
                printf("BT_TEST_CONNECT_CMD received");
                btTestSendCmd(BT_TEST_CONNECT_ACK_CMD);
                DelayMicroseconds(5000);
                KiStartTimer (&btTestStartTimer);
                printf("Timer Started");
                break;

            case BT_TEST_BAUDRATE_CHANGE_CMD:
                printf("BT_TEST_BAUDRATE_CHANGE_CMD received");
                if(btTestBaudrate == SPAL_BAUD_115200)
                {
                    btTestBaudrate = SPAL_BAUD_460800;
                    btTestNextNotif = BT_TEST_460600_NEXT_NOTIF;
                    printf("BT UART baudrate changed to 460800");
                }
                else if(btTestBaudrate == SPAL_BAUD_460800)
                {
                    btTestBaudrate = SPAL_BAUD_921600;
                    btTestNextNotif = BT_TEST_921200_NEXT_NOTIF;
                    printf("BT UART baudrate changed to 921600");
                }
                else
                {
                    btTestBaudrate = SPAL_BAUD_115200;
                    btTestNextNotif = BT_TEST_115200_NEXT_NOTIF;
                    printf("BT UART baudrate changed to 115200");
                }
                BtUartChangeConfig(btTestBaudrate, SPAL_NO_PARITY);
                DelayMicroseconds(1500);
                btTestSendCmd(BT_TEST_BAUDRATE_CHANGE_ACK_CMD);
                break;
            default:
                break;
            }
        }
        break;

    case BT_UART_BAUDRATE_CHANGING_S:
        printf("BT_UART_BAUDRATE_CHANGING_S");
        
        DlSpalDisableRxBufferIntOnly( btPortHandle );
        dataInDmaBuffer = DlSpalRxIntoBuffer (btPortHandle, btTestRxTempBuffer, BT_TEST_RX_TEMP_BUF_SIZE);
        DlSpalEnableRxBufferIntOnly( btPortHandle );
        for(i = 0; i < dataInDmaBuffer; i++)
        {
            printf("BT_RX[%02d] : 0x%02X", i, btTestRxTempBuffer[i]);
            switch(btTestCheckCmd(btTestRxTempBuffer[i]))
            {
            case BT_TEST_BAUDRATE_CHANGE_ACK_CMD:
                printf("BT_TEST_BAUDRATE_CHANGE_ACK_CMD received");
                btTestStateSet(BT_UART_IDLE_S);
                break;

            default:
                break;
            }
        }
        break;
        
    case BT_UART_CONNECTING_S:
        printf("BT_UART_CONNECTING_S");
        
        DlSpalDisableRxBufferIntOnly( btPortHandle );
        dataInDmaBuffer = DlSpalRxIntoBuffer (btPortHandle, btTestRxTempBuffer, BT_TEST_RX_TEMP_BUF_SIZE);
        DlSpalEnableRxBufferIntOnly( btPortHandle );

        for(i = 0; i < dataInDmaBuffer; i++)
        {
            printf("BT_RX[%02d] : 0x%02X", i, btTestRxTempBuffer[i]);
            switch(btTestCheckCmd(btTestRxTempBuffer[i]))
            {
            case BT_TEST_CONNECT_ACK_CMD:
                printf("BT_TEST_CONNECT_ACK_CMD received");
                btTestStateSet(BT_UART_CONNECTED_S);
                KiStartTimer (&btTestStartTimer);
                printf("Timer Started");
                break;
            default:
                break;
            }
        }
        break;
        
    case BT_UART_CONNECTED_S:
        //printf("BT_UART_CONNECTED_S");
        
#if defined(UART_HW_RTS_TEST) /* JHS2 15Aug2006 */        
        DlSpalDisableRxDataReadyInt( btPortHandle );
#else
        DlSpalDisableRxBufferIntOnly( btPortHandle );
#endif
        dataInDmaBuffer = DlSpalRxIntoBuffer (btPortHandle, &btTestRxData[btTestRxDataIdx], BT_TEST_RX_TEMP_BUF_SIZE);
#if defined(UART_HW_RTS_TEST) /* JHS2 15Aug2006 */
        DlSpalEnableRxDataReadyInt( btPortHandle );
#else
        DlSpalEnableRxBufferIntOnly( btPortHandle );
#endif

        if(btTestRxDataIdx + dataInDmaBuffer + 32 > btTestDataSize)
        {
            for(i = 0; i < dataInDmaBuffer; i++)
            {
                if(btTestCmdDetected || btTestRxData[btTestRxDataIdx] == BT_TEST_CMD_FLAG)
                {
                    switch(btTestCheckCmd(btTestRxData[btTestRxDataIdx]))
                    {
                    case BT_TEST_TX_END_CMD:
                        printf("BT_TEST_TX_END_CMD received");
                        btTestRxEnd = TRUE;
                        if(btTestTxEnd)
                        {
                            btTestStateSet(BT_UART_IDLE_S);
                        }
                        break;

                    default:
                        btTestRxDataIdx++;
                        break;
                    }
                }
                else
                {
                    btTestRxDataIdx++;
                }
            }
        }
        else
        {
            btTestRxDataIdx += dataInDmaBuffer;
        }
        break;

    default:
        DlSpalDisableRxBufferIntOnly( btPortHandle );
        DlSpalResetRxBuffer( btPortHandle );
        DlSpalEnableRxBufferIntOnly( btPortHandle );    
        break;
    }

#if !defined(UART_HW_RTS_TEST) /* JHS2 15Aug2006 */
    //BtUartAssertRts();
#endif

    return dataInDmaBuffer;
}

void BtUartDeassertRts(void)
{
#if defined(UART_HW_RTS_TEST) /* JHS2 15Aug2006 */
    DlGpioConfigure(GPIO_BT_UART_RTS_HW);
    DLGpioDeassertLine(M_DLGpioLine(GPIO_BT_UART_RTS_HW));
#else
    DLGpioDeassertLine(M_DLGpioLine(GPIO_BT_UART_RTS));
#endif
}

void BtUartAssertRts(void)
{
#if defined(UART_HW_RTS_TEST) /* JHS2 15Aug2006 */
    DlGpioConfigure(GPIO_BT_UART_RTS_HW);
#else
    DLGpioAssertLine(M_DLGpioLine(GPIO_BT_UART_RTS));
#endif
}

void BtUartSendHciReset(void)
{
    Int8 HCI_RESET[] = {0x01, 0x03, 0x0C, 0x00};
    
    DlSpalTxFromBuffer(btPortHandle, HCI_RESET, 4);
    printf("Sent HCI_RESET");
}
#endif /* BT_UART_PERFORMANCE_TEST */

#if defined(GENIE_VIA_BLUETOOTH)
/*
 * This is the UART transport version of BtTransmitByte().
 */
void BtUartStartByteTransmit(bt_uint8 byte)
{
	if(BtFlag_IsEnabled() && BtFlag_IsConnected(BT_PROFILE_SERIAL_PORT_GENIE)) /* KEVIN_BT for GENIE */
		BtCommonSPPGenieWriteData(&byte,(int *)1);


#if defined (EMMI_UART_DMA_MODE)
{
    M_BtDmaWriteByte(byte);
    BtDmaCheckForTxData();
}	
#else
{
    dlDisableIrq();
    M_BtTxByte(byte);
    dlEnableIrq();
}	
#endif
}

static void SendBTEmmiRxBlockInd (Int16 blockIx)
{
    SignalBuffer theSignal = kiNullBuffer;

    KiCreateSignal (SIG_EMMI_RX_BLOCK_IND, sizeof(EmmiRxBlockInd), &theSignal);
    ((EmmiRxBlockInd *)(theSignal.sig))->blockIx = blockIx;
    KiSendSignal (EMMI_LOW_PRI_TASK_ID, &theSignal);
}

static void BtSendEmmiLowSignal (SignalId signalId)
{
    SignalBuffer theSignal = kiNullBuffer;

    KiCreateSignal (signalId, 0, &theSignal);
    KiSendSignal (EMMI_LOW_PRI_TASK_ID, &theSignal);
}

void BtReceivedAck (void)
{
    DlSpalSetNextRxInterruptStep( btPortHandle, BT_RX_NOTIFY);  /* KANE_BT job050303 for BT GENIE */

    if ((btTxState == BT_TX_WAITING_FOR_ACK) ||
        (btTxState == BT_TX_START_ACK_TIMER))
    {
        KiStopTimer (&btAckTimer);
        BtSendEmmiLowSignal (SIG_EMMI_FREE_TX_BLOCK);
        btTxState = BT_TX_IDLE;
    }
    /* else we have received an ACK while already Txing a block so ignore. */
}

void BtReceivedNak (void)
{

    DlSpalSetNextRxInterruptStep( btPortHandle, BT_RX_NOTIFY); /* KANE_BT job050303 for BT GENIE */

    if ((btTxState == BT_TX_WAITING_FOR_ACK) ||
        (btTxState == BT_TX_START_ACK_TIMER) ||
        (btTxState == BT_TX_SENDING_BLOCK))
    {
        KiStopTimer (&btAckTimer);
        KiStopTimer (&btRetransTimer); /* Just in case */
        KiStartTimer (&btRetransTimer);

        /* abort current block */
//        M_AbortTransmission ();

      dlDisableIrq();                                  
      /* disable tx interrupts and init state */       
      DlSpalDisableTxBufferReadyInt(btPortHandle);        
      btTxBlockState = BT_IDLE;                    
      dlEnableIrq();
		
      btTxState = BT_TX_WAITING_FOR_RETRANS;
    }
}


void BtFailedReceive (void)
{
     if (btTxState != BT_TX_SENDING_BLOCK)
     {
         BtTransmitByte(BT_NAK_OCTET);
     }
     else
     {
#if !defined (EMMI_UART_DMA_MODE)
         btsendANakAsap = TRUE;
#endif
     }
}

static void BtReceivedBlock (void)
{
    /* Indicate to EMMIOSLO that Rx block ready */
    SendBTEmmiRxBlockInd (btCurrentRxBlock);
    DevCheck(rxInterruptBlocks[btCurrentRxBlock].empty == FALSE,
             rxInterruptBlocks[btCurrentRxBlock].empty, btCurrentRxBlock, 0);

    /* Move to next Rx buffer */
    btCurrentRxBlock++;
    if (btCurrentRxBlock >= BT_MAX_NUM_RX_BLOCKS)
    {
        btCurrentRxBlock = 0;
    }
    btrxInterruptBlockInUse = &rxInterruptBlocks[btCurrentRxBlock];

/* Send ACK Byte */
    if (btTxState != BT_TX_SENDING_BLOCK)
    {
	    BtTransmitByte(BT_ACK_OCTET);
//	    BT_DEBUG1("BtReceivedBlock = %02X ", BT_ACK_OCTET); /* KANE_BT job050301 */
    }
    else
   {
#if !defined (EMMI_UART_DMA_MODE)
        btsendAnAckAsap = TRUE;
#endif
    }
}

void BtSppGenieProcessEMMIRxData(Int8 gBuffer, int nlength)
{
	Int16 cnt; 
	int nbytes;

	/* read data from bluetooth */
	BtCommonSPPGenieReadData(btGenieRxHoldBuffer, &nbytes);

#if 0 /* KEVIN_BT job100607 */
	BT_DEBUG(("GENIE>> RX-BtSppGenieProcessEMMIRxData(0x%p, %d)\r\n[ ", btGenieRxHoldBuffer, nbytes)); /* KANE_BT job050223 for GENIE */
	for (i=0; i<nbytes; i++)
		BT_DEBUG(("%02X ", btGenieRxHoldBuffer[i] & 0xff));
	BT_DEBUG(("]\r\n"));
#endif

	for(cnt = 0;cnt < nbytes;cnt++)
		SPPEmmiRxProcess(btGenieRxHoldBuffer[cnt]);
}

void SPPEmmiRxProcess (Int8 c) 
{
    static Int8        checkOctet;     /* running check value */
    static Int8        length;         /* decrementing length */
    static Int8       *pointer;        /* to received data */
    static Boolean     btRxTrashBlock = FALSE;

//    BT_DEBUG1(" GENIE> SPPEmmiRxProcess(RECEIVED BYTE) = %d", c); /* KANE_BT job050224 */

    switch (btRxBlockState)
    {
        case BT_IDLE:
        {
            /*
            ** After reset and after each frame
            */
            switch (c)
            {
                case BT_STX_OCTET:
                {
                    checkOctet = c;
                    btRxBlockState = BT_LENGTH; 
//                    BT_DEBUG1(" GENIE> BT_STX_OCTET = %02X ", BT_STX_OCTET & 0xff); /* KANE_BT job050228 for GENIE TRACE*/					
                    break;
                }
                case BT_ACK_OCTET:
                {
                    /* For DMA mode this is run in task not interrupt time. */
                    BtReceivedAck ();
//                    BT_DEBUG1(" GENIE> BT_ACK_OCTET = %02X ", BT_ACK_OCTET & 0xff); /* KANE_BT job050228 for GENIE TRACE*/
                    break;
                }
                case BT_NAK_OCTET:
                {
                    /* For DMA mode this is run in task not interrupt time. */
                    BtReceivedNak ();
//                   BT_DEBUG1(" GENIE> BT_NAK_OCTET = %02X ", BT_NAK_OCTET & 0xff); /* KANE_BT job050228 for GENIE TRACE*/
                    break;
                }
                default:
                {
                    /* try to resync */
                }
            }
            break;
        }
        case BT_LENGTH:
        {
            if (btrxInterruptBlockInUse->empty == TRUE)
            {
                btrxInterruptBlockInUse->empty       = FALSE;
                btrxInterruptBlockInUse->blockLength = c;
                checkOctet                        ^= c;
                btRxTrashBlock                   = FALSE;
//                BT_DEBUG0(" GENIE> btrxInterruptBlockInUse->empty == TRUE" ); /* KANE_BT job050228 for GENIE TRACE*/	
            }
            else
            {   /* No free buffers so trash this block */
                btRxTrashBlock                   = TRUE;
//                BT_DEBUG0(" GENIE> btrxInterruptBlockInUse->empty == FALSE" ); /* KANE_BT job050228 for GENIE TRACE*/	
            }
#if 0 /* KANE_BT job050225 for BT GENIE*/
            btDmaRxCurrentBlockLength = c;
#endif
            length = c - 1; /* for mi */
            btRxBlockState = BT_MI;        
//            BT_DEBUG1(" GENIE> BT_LENGTH = %02X ", BT_LENGTH & 0xff); /* KANE_BT job050228 for GENIE TRACE*/				
            break;
        }
        case BT_MI:
        {
            if (btRxTrashBlock == FALSE)
            {
                btrxInterruptBlockInUse->mi = c;
                checkOctet               ^= c;
                pointer                   = btrxInterruptBlockInUse->data;
            }
            if (length == 0)
            {
                btRxBlockState = BT_CHECKSUM;
            }
            else
            {
                btRxBlockState = BT_IN_BODY;
            }   
//                BT_DEBUG1(" GENIE> BT_MI = %02X ", BT_MI & 0xff); /* KANE_BT job050228 for GENIE TRACE*/			
            break;
        }
        case BT_IN_BODY:
        {
            if (btRxTrashBlock == FALSE)
            {
                checkOctet ^= c;
                *pointer++  = c;
//                BT_DEBUG1(" GENIE> BT_IN_BODY(btRxTrashBlock == FALSE) = %02X ", BT_IN_BODY & 0xff); /* KANE_BT job050228 for GENIE TRACE*/
            }
            length--;
            if (length == 0)
            {
                btRxBlockState = BT_CHECKSUM;
//                BT_DEBUG1(" GENIE> BT_IN_BODY(length=0) = %02X ", BT_IN_BODY & 0xff); /* KANE_BT job050228 for GENIE TRACE*/				
            }
//                BT_DEBUG1(" GENIE> BT_IN_BODY = %02X ", BT_IN_BODY & 0xff); /* KANE_BT job050228 for GENIE TRACE*/			
            break;
        }
        case BT_CHECKSUM:
        {
            if ((btRxTrashBlock == FALSE) && (c != checkOctet))
            {
                /* Release the Rx buffer for re-use */
                btrxInterruptBlockInUse->empty = TRUE;        

/* KANE_BT job050302 for BT GENIE */
                BtFailedReceive ();
//                BT_DEBUG1(" GENIE> BT_CHECKSUM = %02X ", BT_NAK_OCTET & 0xff); /* KANE_BT job050228 for GENIE TRACE*/
                btRxBlockState = BT_IDLE; /* then resync */
            }
            else
            {
                btRxBlockState = BT_END_OF_FRAME;
            }            
            break;
        }

        case BT_END_OF_FRAME:
        {
	
            if ((btRxTrashBlock == TRUE) || (c != BT_ETX_OCTET))
            {
                if (btRxTrashBlock == FALSE)
                {        
                    /* Release the Rx buffer for re-use only applicable 
                    ** if we are not trashing this block. */
                    btrxInterruptBlockInUse->empty = TRUE;        
                }

/* KANE_BT job050212 for GENIE :: START */
                BtFailedReceive ();
//                BT_DEBUG1(" GENIE > BT_END_OF_FRAME(btRxTrashBlock) = %d", btRxTrashBlock);/* KANE_BT job050228 for GENIE TRACE*/
//                BT_DEBUG1(" GENIE > BT_END_OF_FRAME(BT_ETX_OCTET) = %d", BT_ETX_OCTET & 0xff);/* KANE_BT job050228 for GENIE TRACE*/
//                BT_DEBUG1(" GENIE> BT_END_OF_FRAME(BT_NAK_OCTET) = %02X ", BT_NAK_OCTET & 0xff); /* KANE_BT job050228 for GENIE TRACE*/
            }
            else
            {                
                BtReceivedBlock (); /* KANE_BT job050302 for BT GENIE */
//                BT_DEBUG1(" GENIE> BT_END_OF_FRAME(BT_ACK_OCTET) = %02X ", BT_ACK_OCTET & 0xff); /* KANE_BT job050228 for GENIE TRACE*/
            }
/* KANE_BT job050212 for GENIE :: END */				
            btRxBlockState = BT_IDLE;            
            break;
        }
        default:
        {
            btRxBlockState = BT_IDLE;   

        }
    }
//    BT_DEBUG0(" GENIE> SPPEmmiRxProcess - END "); /* KANE_BT job050224 */	
}

void BTGenieForTxData(void)
{
    //Int8    i; /* KANE_BT job050223 for GENIE */ /* LGE_K_JIN100_WARNING_050321 */
	
    if ((btDmaTxInProgress == FALSE) && (btGenieTxHoldEndPtr > btGenieTxHoldBuffer))
    {   /* Data to send */
		{
            Int16 btDmaTxHoldNum = btGenieTxHoldEndPtr -btGenieTxHoldBuffer;

            btDmaTxInProgress = TRUE;
            /* If more than 0 bytes to send */
            if (btDmaTxHoldNum > 0)
            {
                /* We have some data to send to SPP, so send it. */
		 DEBUG0(" GENIE> BtCommonSPPGenieWriteData - BEGIN "); /* KANE_BT job050227 */				
		 BtCommonSPPGenieWriteData(btGenieTxHoldBuffer,(int *)btDmaTxHoldNum);
		 
#if 0 /* KANE_BT job050223 */
	bt_debug("TX--BtCommonSPPGenieWriteData(0x%p, %d)\r\n[ ", btGenieTxHoldBuffer, btDmaTxHoldNum); /* KANE_BT job050223 for GENIE */
	for (i=0; i<btDmaTxHoldNum; i++)
		bt_debug("%02X ", btGenieTxHoldBuffer[i] & 0xff);
	bt_debug("]\r\n");
#endif
				
                /* Reset buffer */
                btGenieTxHoldEndPtr = btGenieTxHoldBuffer; /* Init Tx Hold Buffer */
            }
        }
    }
}

void BTEmmiTxProcess (void)
{
    Int8			c;              		/* the char to send */
    static Int8        	checkOctet;     	/* running check value */
    static Int8       	*pointer;        	/* where in tx buffer */
    static Int8        	preambleLength;
    static Int16       	blockLength;

//    BT_DEBUG0(" GENIE> BTEmmiTxProcess - BEGIN "); /* KANE_BT job050224 */
    switch (btTxBlockState)
    {
        case BT_IDLE:
        {
            /*
            ** After reset and after each frame
            */
            c = BT_STX_OCTET;
            checkOctet = c;
            btTxBlockState = BT_LENGTH;           
            break;
        }
        case BT_LENGTH:
        {
            c = txInterruptBlock.blockLength;
            blockLength = c - 1; /* for mi */
            checkOctet ^= c;
            btTxBlockState = BT_MI;             
            break;
        }
        case BT_MI:
        {
            c = txInterruptBlock.mi;
            checkOctet ^= c;
            if (txInterruptBlock.preambleLength != 0)
            {
                btTxBlockState = BT_IN_PREAMBLE;
                pointer = txInterruptBlock.preamble;
                preambleLength = txInterruptBlock.preambleLength;
                blockLength -= preambleLength;
            }
            else
            {
                if (blockLength != 0)
                {
                    btTxBlockState = BT_IN_BODY;
                    pointer = txInterruptBlock.data;
                }
                else
                {
                    btTxBlockState = BT_CHECKSUM;
                }
            }             
            break;
        }
        case BT_IN_PREAMBLE:       /* only for ttp MIs */
        {
            c = *pointer++;
            preambleLength--;
            checkOctet ^= c;
            if (preambleLength == 0)
            {
                if (blockLength != 0)
                {
                    btTxBlockState = BT_IN_BODY;
                    pointer = txInterruptBlock.data;
                }
                else
                {
                    btTxBlockState = BT_CHECKSUM;
                }
            }              
            break;
        }
        case BT_IN_BODY:
        {
            c = *pointer++;
            blockLength--;
            checkOctet ^= c;
            if (blockLength == 0)
            {
                btTxBlockState = BT_CHECKSUM;
            }
            break;
        }
        case BT_CHECKSUM:
        {
            c = checkOctet;
            btTxBlockState = BT_END_OF_FRAME;         
            break;
        }
        case BT_END_OF_FRAME:
        {
            c = BT_ETX_OCTET;
            btTxBlockState = BT_LAST_BYTE;             
            break;
        }
        case BT_LAST_BYTE:
        {

                btDmaBlockAddedToFifo = TRUE; /* KANE_BT job050302 */

                btTxState = BT_TX_WAITING_FOR_ACK;

                M_BtDisableTxBufferReadyInt();
#if 0 /* KANE_BT job050227 for GENIE */
                BtHighSendEvent (BT_TRANSMIT_BLOCK_COMPLETE);
#else
                if (btTxState == BT_TX_WAITING_FOR_ACK)
                {
                    KiStartTimer (&btAckTimer);
                }

#if !defined (EMMI_UART_DMA_MODE)
                if (btsendANakAsap == TRUE)
                {
                    btsendANakAsap = FALSE;
                    BtTransmitByte(BT_NAK_OCTET);
                }
                else if (btsendAnAckAsap == TRUE)
                {
                    btsendAnAckAsap = FALSE;
                    BtTransmitByte(BT_ACK_OCTET);
                }
#endif				
//                DEBUG0(" BT_TRANSMIT_BLOCK_COMPLETE "); /* KANE_BT job050213 for GENIE */	
#endif
		
                btTxBlockState = BT_IDLE;
            break;
        }

        default:
        {
            DevFail ("EMMI Invalid Tx State");
            btTxBlockState = BT_IDLE;
            break;
        }
 }

/* KANE_BT job050227 for GENIE */
        if (btTxBlockState != BT_IDLE)
        {
#if defined (EMMI_UART_DMA_MODE)
            DevCheck (btDmaBlockAddedToFifo != TRUE, btDmaBlockAddedToFifo, 0, 0);
            /* Add character to FIFO */
            M_BtDmaWriteByte(c);
#else
//	BT_DEBUG1(" BtTransmitByte(c) = %d", c);
            BtTransmitByte(c);
#endif
        }
//BT_DEBUG0(" GENIE> BTEmmiTxProcess "); /* KANE_BT job050222 */	
}

void SPPEmmiStartBlockTransmit(void)
{
    Boolean done = FALSE;
    Boolean started = FALSE;
    
	DEBUG0("SPPEmmiStartBlockTransmit");
	
       btTxState = BT_TX_SENDING_BLOCK;

	btDmaTxInProgress = FALSE;

      /* Add data to FIFO */
      btDmaBlockAddedToFifo = FALSE; /* KANE_BT job050302 */
	  
    /* while space in LOCAL queue, add a char by txprocess,
     *   if state becomes IDLE stop adding and trigger dma transmission.
     *   if there wasn't any space trigger dma transmission
     */
    while (done == FALSE)
    {
        /* If DMA hold buffer not full */
        if ((btGenieTxHoldEndPtr - btGenieTxHoldBuffer) < BT_TX_BUFF_SIZE)
        {
            BTEmmiTxProcess();
            if ( btTxBlockState == BT_IDLE)
            {
                done = TRUE;                
            }
        }
        else
        {
            /* If not tx-ing start */
            if (btDmaTxInProgress == FALSE)
            {
                BTGenieForTxData();
                started = TRUE;
            }
        }
    }

    /* If not tx-ing start */
    if (started == FALSE)
    {
        BTGenieForTxData();
    }	 
}
#endif /* GENIE_VIA_BLUETOOTH */

#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
void bluetoothDteEnable_UART(Boolean enable, DlSpalPortId port)
{
	Boolean ok;

	BT_DEBUG(("bluetoothDteEnable_UART() enable=%s, port=%d", enable?"On":"Off", port));
	if (enable == TRUE)
	{
/* BT_COMMON_KIMSANGJIN_071004 noti_011219 */
	       if(btSerialLineIsEnabled == TRUE)
	       {
                     BT_DEBUG(("btSerialLineIsEnabled was already set TRUE...............error case"));
	       }
/* end of BT_COMMON_KIMSANGJIN_071004 */
		btSerialLineIsEnabled = TRUE;
#if 0
		/* open port if it has been closed */
		if ( btPortHandle == SPAL_INVALID_HANDLE)
		{  
			DlSpalInitialise();

			ok = DlSpalPortRouting( SPAL_STACK_BT, port );
			DevAssert ( ok );

			btDlSpalPortId = port; 

			/* Stack opens a link.  Returns a handle */
			btPortHandle = DlSpalOpenPortFor( SPAL_STACK_BT );

			/* Check validity of handle */
			DevAssert( btPortHandle != SPAL_INVALID_HANDLE);
		}

		/*  Initialise the serial port which also switches the clock on. */
		BtConfigSerialPort(SPAL_BAUD_921600, SPAL_NO_PARITY);
#endif		
	}
	else
	{
		DevAssert(btSerialLineIsEnabled == TRUE);
		btSerialLineIsEnabled = FALSE;

/* BT_COMMON_KIMSANGJIN_071004  noti_011219 */
		if (btDmaRxPollTimer.timerId != KI_TIMER_NOT_RUNNING)
		{
			KiStopTimer (&btDmaRxPollTimer);
		}
/* end of BT_COMMON_KIMSANGJIN_071004 */

		DlSpalDisableTxBufferReadyInt( btPortHandle );
		DlSpalDisableRxDataReadyInt( btPortHandle );
		DlSpalResetRxBuffer( btPortHandle );
		DlSpalDisableStatusEventInt( btPortHandle );

		DlSpalClosePort( btPortHandle );
		btPortHandle = SPAL_INVALID_HANDLE;
		DlSpalPortRouting( SPAL_STACK_BT, SPAL_NO_PORT);
		
		btDlSpalPortId = SPAL_NO_PORT; 

		BT_DEBUG(("End of bluetoothDteEnable_UART() BT UART port is closed"));
	}
}
#endif /* LGE_L1_SINGLE_UART */    

void BtHighSendEvent (BtHighEvent theEvent)
{
	M_KiOsSetEvent(BT_HIGH_EVENT_FLAG, theEvent);
}

/*==========================================================================
 *
 * Function    : BtDmaCheckForTxData
 *
 * Parameters  : none
 *
 * Returns     : none
 *
 * Description : Check if there is any more Tx data to send.
 *
 *=========================================================================*/
void BtDmaCheckForTxData(void)
{
	M_BtDisableTxBufferReadyInt();
	if ((btDmaTxInProgress == FALSE) && (btDmaTxHoldEndPtr > btDmaTxHoldBuffer))
	{   /* Data to send */
		Int16 btDmaTxHoldNum = btDmaTxHoldEndPtr - btDmaTxHoldBuffer;

		btDmaTxInProgress = TRUE;

		/* If more than 0 bytes to send */
		if (btDmaTxHoldNum > 0)
		{
			/* We have some data to send to the DMA, so send it. */
			//DlSpalTxFromBuffer( muxPortHandle, btDmaTxHoldBuffer, btDmaTxHoldNum);
			DlSpalTxFromBuffer( btPortHandle, btDmaTxHoldBuffer, btDmaTxHoldNum);				
			/* Reset buffer */
			btDmaTxHoldEndPtr = btDmaTxHoldBuffer; /* Init Tx Hold Buffer */
		}
	}
	else
	{
#if defined(LGE_BRCM_BLUETOOTH)    
		gIsSending = FALSE;
		if (gUartCallback != NULL) 
			gUartCallback(USERIAL_PORT_1, USERIAL_TX_DONE_EVT, NULL);
#elif defined(LGE_CSR_BLUETOOTH)
		if (gUartCallback.txCallback != NULL) 
			gUartCallback.txCallback();
#endif		
	}
	M_BtEnableTxBufferReadyInt(); 
}

/*==========================================================================
 *
 * Function    : BtDmaCheckForRxData
 *
 * Parameters  : none
 *
 * Returns     : none
 *
 * Description : Check if there is any received Rx data
 *
 *=========================================================================*/
#if defined(LGE_BRCM_BLUETOOTH)

Int16 BtDmaCheckForRxData(void)
{
    Int8    byte; 
    Int16   dataInDmaBuffer, i;
    bt_uint16* Headptr;
#if defined(LOOPBACK_TEST)
    Int16 sent;
#endif

    DlSpalDataLocation   startAddress;

    DlSpalDisableRxBufferIntOnly( btPortHandle );

    startAddress = DlSpalGetCurrentRxDataLocation( btPortHandle );
    dataInDmaBuffer = DlSpalRxIntoBuffer (btPortHandle, btDmaRxHoldBuffer, BT_RX_BUFF_SIZE);

    btDmaRxHoldEndPtr = btDmaRxHoldBuffer + dataInDmaBuffer;
    btDmaRxHoldPtr    = btDmaRxHoldBuffer;


#if defined(LOOPBACK_TEST) /* KANE_BT Bypass mode job041209 */
	/* While Rx buffer not empty */
	/*noti_011002*/
	if(BtGetEnablePcm()  == FALSE )
	{
		while (btDmaRxHoldPtr != btDmaRxHoldEndPtr)
		{
			/* Read byte */
			byte = *btDmaRxHoldPtr;
			sent = 0; /*sent =1 / not sent =0*/
			while (sent !=1)
			{
				sent=DlSpalTxByte(btPortHandle, byte);
			}
			/* Next byte */
			btDmaRxHoldPtr++;
		}
		return (dataInDmaBuffer);	
	}
#endif /* LOOPBACK_TEST */


//BCM_CHANGE_070306 debugUART460K
#if 1 //defined (LGE_ATLAS_BLUETOOTH)   /*  CHECK_HY   071108    */
    if ((rxQueue.Count + dataInDmaBuffer) > BT_RX_QUEUE_SIZE)
    {
	    BT_DEBUG(("rxQueue will be overwritten"));
    }

    if ((rxQueue.Count + dataInDmaBuffer) > BT_RX_BUFF_SIZE) //less than 1024 Bytes available    /*  CHECK_HY  071108  */
    {
	    BT_DEBUG(("BtClearRTS, rxQueue.Count: %d, dataInDmaBuffer: %d", rxQueue.Count, dataInDmaBuffer));
	    BtClearRTS();	//stop 2048 sending
         }
#endif
//END_OF_BCM_CHANGE

       if (dataInDmaBuffer > 0)
	{
		BtEnterCS();
		BQ_WriteData(&rxQueue, btDmaRxHoldBuffer, dataInDmaBuffer);
		BtLeaveCS();
#if 0		
/* BT_L1_KIMSANGJIN_060822:For debug message */
		BRCM_bt_debug("<btDmaRxHoldBuffer>");
		BRCM_bt_debug("RX--BQ_WriteData(0x%p, %d)\r\n[ ", btDmaRxHoldBuffer, dataInDmaBuffer); /* KEVIN_BT job100504 */
		for (i=0; i<dataInDmaBuffer; i++)
			BRCM_bt_debug("%02X ", btDmaRxHoldBuffer[i] & 0xff);
		BRCM_bt_debug("]\r\n");

		/*BRCM_bt_debug("<rxQueue.Buffer>");
		BRCM_bt_debug("RX--BQ_WriteData(0x%p, %d)\r\n[ ", rxQueue.Buffer, rxQueue.Size);
		for (i=0; i<100; i++)
			BRCM_bt_debug("%02X ", rxQueue.Buffer[i] & 0xff);
	       Headptr = rxQueue.Tail;
		for (i=0; i<(rxQueue.Head -rxQueue.Tail); i++)
			BRCM_bt_debug("%02X ", Headptr[i] & 0xff);
		BRCM_bt_debug("]\r\n");*/
#endif		
/* end of BT_L1_KIMSANGJIN_060822 */

		if (gUartCallback != NULL && dataInDmaBuffer > 0) 
			gUartCallback(USERIAL_PORT_1, USERIAL_RX_READY_EVT, NULL);
	}
	   
    DlSpalEnableRxBufferIntOnly( btPortHandle ); /* BT_COMMON_KIMSANGJIN_071010 */
    return (dataInDmaBuffer);
}
		   
#elif defined(LGE_CSR_BLUETOOTH)

Int16 BtDmaCheckForRxData(void)
{
    Int8	byte; /* LGE_K_JIN100_WARNING_050321 */
    Int16	dataInDmaBuffer;
#if defined(LOOPBACK_TEST) /* KANE_BT Bypass mode job041209 */
    Int16	sent;
#endif

    DlSpalDataLocation   startAddress;

    DlSpalDisableRxBufferIntOnly( btPortHandle );

    startAddress = DlSpalGetCurrentRxDataLocation( btPortHandle );
    dataInDmaBuffer = DlSpalRxIntoBuffer (btPortHandle, btDmaRxHoldBuffer, BT_RX_BUFF_SIZE);

    btDmaRxHoldEndPtr = btDmaRxHoldBuffer + dataInDmaBuffer;
    btDmaRxHoldPtr    = btDmaRxHoldBuffer;


#if defined(LOOPBACK_TEST) /* KANE_BT Bypass mode job041209 */
	/* While Rx buffer not empty */
	/*noti_011002*/
	if(BtGetEnablePcm()  == FALSE )
	{
		while (btDmaRxHoldPtr != btDmaRxHoldEndPtr)
		{
			/* Read byte */
			byte = *btDmaRxHoldPtr;
			sent = 0; /*sent =1 / not sent =0*/
			while (sent !=1)
			{
				sent=DlSpalTxByte(btPortHandle, byte);
			}
			/* Next byte */
			btDmaRxHoldPtr++;
		}
		return (dataInDmaBuffer);	
	}
#endif /* LOOPBACK_TEST */

       if (dataInDmaBuffer > 0)		
	{		
		/* Sean_070823: changed uart callback structure <-- */
		dlDisableIrq();
		if (gUartCallback .rxCallback != NULL) 
		{
		 	gUartCallback.rxCallback((void*)btDmaRxHoldBuffer, dataInDmaBuffer);
		}
		dlEnableIrq();
		/* Sean_070823 --> */
#if 0
	CSR_debug("RX--BQ_WriteData(0x%p, %d)\r\n[ ", btDmaRxHoldBuffer, dataInDmaBuffer); /* KANE_BT job041205 */
	for (i=0; i<dataInDmaBuffer; i++)
		CSR_debug("%02X ", btDmaRxHoldBuffer[i] & 0xff);
	CSR_debug("]\r\n");
#endif
		
		//CSR_debug("<BtDmaCheckForRxData> USERIAL_RX_READY_EVT");		
	}
    DlSpalEnableRxBufferIntOnly( btPortHandle ); /* BT_COMMON_KIMSANGJIN_071010 */
	   
    return (dataInDmaBuffer);
}
#endif

void BtDmaResetRxBuffer(void)
{
      if ( btPortHandle != SPAL_INVALID_HANDLE)
      {
		DlSpalDisableRxDataReadyInt( btPortHandle );
		btDmaRxPollActive   = FALSE;
		DlSpalResetRxBuffer( btPortHandle );
		DlSpalEnableRxDataReadyInt( btPortHandle );
	}
      else
      {
		BT_DEBUG(("\x1b[31m BtDmaResetRxBuffer() BT UART is already closed \x1b[0m "));			  
      }
}

void BtDisableRxDataReadyInt(void)
{
      if ( btPortHandle != SPAL_INVALID_HANDLE)
      {
		DlSpalDisableRxDataReadyInt( btPortHandle );
		btDmaRxPollActive   = FALSE;
      }
}

void BtRxInterrupt(void)
{
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 13Aug2006 */
        extern BT_TEST_STATE_TYPE btTestStateGet(void);

#if !defined(UART_HW_RTS_TEST) /* JHS2 15Aug2006 */    
        //if(btTestStateGet() == BT_UART_CONNECTED_S)
        //    BtUartDeassertRts();
#endif
#endif
	BtHighSendEvent (BT_DMA_RX_EVENT);
}

void BtTxInterrupt(void)
{
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 03Aug2006 */    
    	BtHighSendEvent (BT_DMA_TX_EVENT);
#else
#if defined(LGE_BRCM_BLUETOOTH)  /* Sean_070823: CSR does not use this variable gIsSending */
	gIsSending = FALSE;
#endif

#if defined(GENIE_VIA_BLUETOOTH)
        btDmaTxInProgress = FALSE;

        if ( btDmaBlockAddedToFifo == TRUE)
        {
            btDmaBlockAddedToFifo = FALSE;
            btTxState = BT_TX_START_ACK_TIMER;
        }
#endif /* GENIE_VIA_BLUETOOTH */

	BtHighSendEvent (BT_DMA_TX_EVENT);
#endif
}

/* The SPAL version of this is so radically different that the before-and-after
 * versions of this function are separated entirely. SPAL version first. */
void BtInitSerialPort(void)
{
	/* These two functions should be called from the accessory/resource manager
	* when that architectural change is implemented.  In the meantime they
	* are called from th Stack to assign itself its port */
	Boolean ok;

	BT_DEBUG(("BtInitSerialPort()"));
	if ( btPortHandle == SPAL_INVALID_HANDLE)
 	{
		ok = DlSpalPortRouting( SPAL_STACK_BT, SPAL_PORT_BT_1 );
		DevAssert ( ok );
		
#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
		btDlSpalPortId = SPAL_PORT_BT_1; 
#endif
		/* Open the port assigned to BT */
		btPortHandle = DlSpalOpenPortFor(SPAL_STACK_BT);
		/* Check validity of handle */
		if(btPortHandle != SPAL_INVALID_HANDLE)
		{
			BT_DEBUG((" BtInitSerialPort() BT UART port SUCCESS to open. [btPortHandle=%d]", btPortHandle));
		}
		else 
		{
			BT_DEBUG(("\x1b[31m BtInitSerialPort() BT UART port FAIL to open. [btPortHandle=%d] \x1b[0m", btPortHandle));
		}
		DevAssert( btPortHandle != SPAL_INVALID_HANDLE);
 	}
	else
		BT_DEBUG(("\x1b[31m BtInitSerialPort()  BT UART port is already opened.  btPortHandle(!= SPAL_INVALID_HANDLE)=%d \x1b[0m ", btPortHandle));
}

void BtConfigSerialPort(DlSpalBaudRate baud, DlSpalParity parity)
{
	  DlSpalConnectionSpec portSpecification;

	  /* Configure serial port uart. */
	  /* 1. Pick up defaults */
	  DlSpalSetSpecToDefault( &portSpecification );
	  /* 2. Set specific values that we are bothered about */
	  portSpecification.baudRate = baud;
	  portSpecification.parity   = parity;
	  portSpecification.dataBits = 8;
	  portSpecification.stopBits = 1;

	  portSpecification.bufferType      = SPAL_BUFF_DMA;
	  portSpecification.bufferIntMethod = SPAL_BUFFINT_SET;
	  portSpecification.bufferInterval  = 1;
#if defined(LGE_LEMANS_BLUETOOTH)
	  portSpecification.routeCts = SPAL_CTS_ALT_1;
#endif  /*End of LGE_LEMANS_BLUETOOTH*/
	  portSpecification.routeRxTx = SPAL_RXTX_STD;
/* BT_COMMON_KIMSANGJIN_070416 */
#if defined(LGE_LEMANS_BLUETOOTH) /*Use H/W Flow control */
	  portSpecification.supportRtsCtsRi = TRUE;
	  portSpecification.hardwareRts = TRUE;
#else /*Use S/W Flow control */
	  portSpecification.supportRtsCtsRi = FALSE;
	  portSpecification.hardwareRts = FALSE;
#endif
/* end of BT_COMMON_KIMSANGJIN_070416 */
	  portSpecification.supportDtr = FALSE;
	  portSpecification.routeDtr = SPAL_DTR_NOT_ROUTED;
	  portSpecification.dataReadyIntCallback = BtRxInterrupt;
	  portSpecification.dataSentIntCallback = BtTxInterrupt;

	  BT_DEBUG((" Parity = %d", parity));
	  BT_DEBUG((" Baud = %d", baud));

#if defined (TTC_PLATFORM_RPV4_MCU)
	  portSpecification.bufferType = SPAL_BUFF_HW_FIFO;
#endif

	  /* Publish the buffer type we're using - the Rx ISR uses it */
	  btSpalBufferType = portSpecification.bufferType;

	  /* Configure the link with the specification. */
	  DlSpalPortConfiguration( btPortHandle, portSpecification );

	  DlSpalEnableRxDataReadyInt( btPortHandle );
	  DlSpalEnableStatusEventInt( btPortHandle );
	  BtDmaResetRxBuffer();   
}

void BtPortInvalidate(void)
{
	if(btPortHandle != SPAL_INVALID_HANDLE)
	{
/* BT_COMMON_KIMSANGJIN_071004  noti_011219 */
		if (btDmaRxPollTimer.timerId != KI_TIMER_NOT_RUNNING)
		{
			KiStopTimer (&btDmaRxPollTimer);
		}
/* end of BT_COMMON_KIMSANGJIN_071004 */	
		DlSpalDisableTxBufferReadyInt( btPortHandle );
		DlSpalDisableRxDataReadyInt( btPortHandle );
		DlSpalResetRxBuffer( btPortHandle );
		DlSpalDisableStatusEventInt( btPortHandle );
		DlSpalDisableDtrInt( btPortHandle );
		
		DlSpalClosePort( btPortHandle );   
		btPortHandle = SPAL_INVALID_HANDLE;
		DlSpalPortRouting(SPAL_STACK_BT, SPAL_NO_PORT);
		BT_DEBUG(("BtPortInvalidate() BT UART port is closed"));		

#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
		btDlSpalPortId = SPAL_NO_PORT; 
#endif
	}
	else
	{
		BT_DEBUG(("\x1b[31m BtPortInvalidate() BT UART port is already closed \x1b[0m "));
	}		
}

void EmmiPortInvalidate(void)
{
	if(emmiPortHandle != SPAL_INVALID_HANDLE)
	{
		DlSpalDisableTxBufferReadyInt( emmiPortHandle );
		DlSpalDisableRxDataReadyInt( emmiPortHandle );
		DlSpalDisableStatusEventInt( emmiPortHandle );
		DlSpalDisableDtrInt( emmiPortHandle );

		DlSpalClosePort( emmiPortHandle );   
		emmiPortHandle = SPAL_INVALID_HANDLE;
		DlSpalPortRouting(SPAL_STACK_EMMI, SPAL_NO_PORT);
		BT_DEBUG(("EmmiPortInvalidate() EMMI port is closed"));
	}
	else
	{
		BT_DEBUG(("\x1b[31m EmmiPortInvalidate() EMMI port is already closed \x1b[0m "));
	}
}

/* BT_L1_KIMSANGJIN_060822 noti_011002 */
void BTSetRxNotify(void) 
{
	BT_DEBUG(("BTSetRxNotify Btbaudrate................ [%d]",Btbaudrate));
	switch(Btbaudrate)
	{
		case SPAL_BAUD_115200:
		{
			BT_RX_NOTIFY = BT_NEXT_NOTIF_115200;
			btDmaRxPollTimer.timeoutPeriod    = MILLISECONDS_TO_TICKS(BT_RX_DATA_POLL_PERIOD_115200);
			BT_RX_POLL_IDLE_COUNT_MAX =BT_RX_POLL_IDLE_TIME_MAX/BT_RX_DATA_POLL_PERIOD_115200;
			break;
		}
		case SPAL_BAUD_460800:
		{
			BT_RX_NOTIFY = BT_NEXT_NOTIF_460800;
			btDmaRxPollTimer.timeoutPeriod    = MILLISECONDS_TO_TICKS(BT_RX_DATA_POLL_PERIOD_460800);
			BT_RX_POLL_IDLE_COUNT_MAX =BT_RX_POLL_IDLE_TIME_MAX/BT_RX_DATA_POLL_PERIOD_460800;
			break;
		}
		case SPAL_BAUD_921600:
		{
			BT_RX_NOTIFY = BT_NEXT_NOTIF_921600;
			btDmaRxPollTimer.timeoutPeriod    = MILLISECONDS_TO_TICKS(BT_RX_DATA_POLL_PERIOD_921600);
			BT_RX_POLL_IDLE_COUNT_MAX = BT_RX_POLL_IDLE_TIME_MAX/BT_RX_DATA_POLL_PERIOD_921600;
			break;
		}
		default :
			BT_DEBUG(("Unkown baudrate................ [%d]",Btbaudrate));
			break;
	}
#if 0 /*Need more test*/
	DlSpalSetNextRxInterruptStep( btPortHandle, BT_RX_NOTIFY);
	if (btDmaRxPollActive == FALSE)
	{
		KiStartTimer (&btDmaRxPollTimer);
		btDmaRxPollActive	= TRUE;
	}
#endif	
	BT_DEBUG(("BTSetRxNotify ..........BT_RX_NOTIFY=[%d], BT_RX_POLL_IDLE_COUNT_MAX=[%d]", BT_RX_NOTIFY, BT_RX_POLL_IDLE_COUNT_MAX));
}

void BtUartChangeConfig(DlSpalBaudRate baudrate, DlSpalParity parity)
{
	BT_DEBUG(("BtUartChangeConfig() baudrate=%d, parity=%d", baudrate, parity));
	
#if 0 /* check point */
	DlGpioConfigure(GPIO_BT_UART_RX );
	DlGpioConfigure(GPIO_BT_UART_TX);
	M_DLGpioDeassertLine(M_DLGpioLine(GPIO_BT_UART_TX));
	PdGpioConfigure(GPIO_BT_UART_TX_NORMAL);
#endif

#if 0 //defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
	if((vgmuxDlSpalPortId == SPAL_PORT_WIRE_2) && (emmiDlSpalPortId != SPAL_PORT_WIRE_2))		
	{
		BT_DEBUG(("BtUartChangeConfig() BT UART port is same with VG"));
#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
		if(vgmuxSerialLineIsEnabled==TRUE)
		{
			vgmuxDteEnable_UART(FALSE, SPAL_NO_PORT);
			BT_DEBUG(("VG port is closed"));
		}
#endif
	}
	else if((vgmuxDlSpalPortId != SPAL_PORT_WIRE_2) && (emmiDlSpalPortId == SPAL_PORT_WIRE_2))
	{
		BT_DEBUG(("BtUartChangeConfig() BT UART port is same with EMMI"));	
#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */		
		if(emmiSerialLineIsEnabled==TRUE)
		{
			emmiDteEnable_UART(FALSE, SPAL_NO_PORT);
			BT_DEBUG(("EMMI port is closed"));			
		}
#endif
	}
	else
	{
		BT_DEBUG(("\x1b[31m BtUartChangeConfig() vgmuxDlSpalPortId=%d, emmiDlSpalPortId=%d \x1b[0m", vgmuxDlSpalPortId, emmiDlSpalPortId));
	}
#endif /* LGE_ATLAS_BLUETOOTH */

	BtInitSerialPort();
	BtConfigSerialPort(baudrate, parity);

	BtDmaResetRxBuffer();
	Btbaudrate = baudrate;	/* noti_011002 */
}

#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
void BtUartCleanupAfterChangeBaudrate(void)
{
    BtDmaResetRxBuffer();
    //USERIAL_InitData();
}
#endif /*End of LGE_ATLAS_BLUETOOTH*/

#if defined(LGE_CSR_BLUETOOTH) /* Sean_070823: added new API for the changed uart callback structure */
void BtRegisterUartCallbacks( void (*txCallback)(void), void (*rxCallback)(void*, int))
{
    gUartCallback.txCallback = txCallback;
    gUartCallback.rxCallback = rxCallback;
}
#endif

#if defined(LGE_BRCM_BLUETOOTH) /* myung */
int Trigger_ReadDMABuffer(void)
{
   //Int16 i;
   Int16 Dmasize =0;
   
   BtHighSendEvent (BT_DMA_POLL_RX_EVENT);

#if 0   
   Dmasize= DlSpalRxIntoBuffer (btPortHandle, btDmaRxHoldBuffer, BT_RX_BUFF_SIZE);
   if (Dmasize>0)
   	{
		BT_DEBUG(("Trigger_ReadDMABuffer, event BT_DMA_POLL_RX_EVENT"));
		BtHighSendEvent (BT_DMA_POLL_RX_EVENT);
   	}
#endif
#if 0	
	BT_DEBUG(("<Trigger_ReadDMABuffer :%d [timer period :%d]=",Dmasize,btDmaRxPollTimer.timeoutPeriod));
	BT_DEBUG(("RX--Trigger_ReadDMABuffer (0x%p, %d)\r\n[ ", bttestxHoldBuffer, Dmasize)); /* KEVIN_BT job100504 */
	for (i=0; i<Dmasize; i++)
		BT_DEBUG(("%02X ", bttestxHoldBuffer[i] & 0xff));
	BT_DEBUG(("]\r\n"));
#endif

   return Dmasize;
}


void Trigger_CheckTxData(void)
{
    BtHighSendEvent (BT_DMA_TX_EVENT);
}
#endif /* LGE_BRCM_BLUETOOTH */

void BtSpalInitTask(void)
{
	/* send a SIG_INITIALISE to BtSpalHighPriTask() */
	SignalBuffer sigbuf = kiNullBuffer;

	KiCreateSignal(SIG_INITIALISE, sizeof(KiInitialiseTask), &sigbuf);
	KiSendSignal(SPAL_HIGH_PRI_TASK_ID, &sigbuf);
}

KI_ENTRY_POINT BtSpalHighPriTask(KI_TASK_ARGS)
{
    Int16 events;
    Int16 event;
    SignalBuffer signal = kiNullBuffer;
    Boolean init  = FALSE;

#if defined(GENIE_VIA_BLUETOOTH)	
    /* Init Rx buffers */
    for (btCurrentRxBlock = 0; btCurrentRxBlock < BT_MAX_NUM_RX_BLOCKS; btCurrentRxBlock++)
    {
        rxInterruptBlocks[btCurrentRxBlock].empty = TRUE;
    }
    btCurrentRxBlock    = 0;
    btrxInterruptBlockInUse = &rxInterruptBlocks[btCurrentRxBlock];
#endif

    btDmaTxHoldEndPtr = btDmaTxHoldBuffer;

    /* Initialise ACK timer */
    btAckTimer.timeoutPeriod = BT_ACK_TIMEOUT_PERIOD;
    btAckTimer.myTaskId      = EMMI_LOW_PRI_TASK_ID;
    btAckTimer.timerId       = KI_TIMER_NOT_RUNNING;
    btAckTimer.userValue     = BT_ACK_TIMEOUT_USER_VALUE;

    /* Initialise RETRANS timer */
    btRetransTimer.timeoutPeriod = BT_RETRANS_TIMEOUT_PERIOD;
    btRetransTimer.myTaskId      = EMMI_LOW_PRI_TASK_ID;
    btRetransTimer.timerId       = KI_TIMER_NOT_RUNNING;
    btRetransTimer.userValue     = BT_RETRANS_USER_VALUE;

    btDmaRxPollTimer.timeoutPeriod    = MILLISECONDS_TO_TICKS(BT_RX_DATA_POLL_PERIOD_115200);
    btDmaRxPollTimer.myTaskId          = EMMI_LOW_PRI_TASK_ID;
    btDmaRxPollTimer.timerId          = KI_TIMER_NOT_RUNNING;
    btDmaRxPollTimer.userValue        = BT_RX_POLL_TIMER_USER_VALUE;

#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 07Aug2006 */
    btTestStartTimer.timeoutPeriod  = MILLISECONDS_TO_TICKS(200);
    btTestStartTimer.myTaskId       = EMMI_LOW_PRI_TASK_ID;
    btTestStartTimer.timerId        = KI_TIMER_NOT_RUNNING;
    btTestStartTimer.userValue      = BT_TEST_START_TIMER_USER_VALUE;
#endif

    while (init == FALSE)
    {
        KiReceiveSignal (SPAL_HIGH_PRI_QUEUE_ID, &signal);
                                               
        switch (*signal.type)
        {
            	case SIG_INITIALISE:
			init = TRUE;
		break;
        }        
        KiDestroySignal (&signal);
    }
    
    for (;;)
    {
		M_KiRlgLogEventInternal (KI_RLG_GKE_EXIT_TASK, SPAL_HIGH_PRI_TASK_ID, 0, 0);
		M_KiOsWaitEventGroup(BT_HIGH_EVENT_FLAG, events);
		M_KiRlgLogEventInternal (KI_RLG_GKE_BEGIN_TASK, SPAL_HIGH_PRI_TASK_ID, 0, 0);

        for (event = 0x0001; event < END_OF_EVENTS_TO_BT_HIGH; event <<= 1)
        {
            switch (events & event)
            {
			case 0:
			/* not set - try the next one */
			break;

#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 02Aug2006 */
            case BT_UART_TEST_START:
                {
                    printf("BT_UART_TEST_START, check connection");
#if defined(BT_BCM2045_TEST) /* JHS2 21Aug2006 */
                    btTestSendHciReset();
#else
                    btTestSendCmd(BT_TEST_CONNECT_CMD);
#endif
                }
                break;

            case BT_UART_CHANGE_BAUDRATE:
                {
                    if(btTestStateGet() == BT_UART_IDLE_S)
                    {
#if defined(BT_BCM2045_TEST) /* JHS2 21Aug2006 */
                        BtUartChangeConfig(SPAL_BAUD_115200, SPAL_NO_PARITY);
#else                    
                        btTestSendCmd(BT_TEST_BAUDRATE_CHANGE_CMD);
                        DelayMicroseconds(500);
                        if(btTestBaudrate == SPAL_BAUD_115200)
                        {
                            btTestBaudrate = SPAL_BAUD_460800;
                            btTestNextNotif = BT_TEST_460600_NEXT_NOTIF;
                            printf("BT UART baudrate changed to 460800");
                        }
                        else if(btTestBaudrate == SPAL_BAUD_460800)
                        {
                            btTestBaudrate = SPAL_BAUD_921600;
                            btTestNextNotif = BT_TEST_921200_NEXT_NOTIF;
                            printf("BT UART baudrate changed to 921600");
                        }
                        else
                        {
                            btTestBaudrate = SPAL_BAUD_115200;
                            btTestNextNotif = BT_TEST_115200_NEXT_NOTIF;
                            printf("BT UART baudrate changed to 115200");
                        }
                        BtUartChangeConfig(btTestBaudrate, SPAL_NO_PARITY);
#endif						
                    }
                }
                break;

            case BT_TEST_START_EVENT:
                {
                    btTestStarted = TRUE;
                    printf("Starting Bluetooth UART Test : Test Size=%d Bytes", btTestDataSize);
                    btTestStartTime = ReadRawTime();
                    printf("BT UART Test Started : %d", btTestStartTime);
                    btTestSendData();
                }
                break;
#endif /* BT_UART_PERFORMANCE_TEST */

#if defined(GENIE_VIA_BLUETOOTH)
#if !defined(BT_UART_PERFORMANCE_TEST) /* JHS2 14Aug2006 */
			/* events from low pri task */
			case BT_ACK_TIMEOUT_EVENT:
				/* Resend the old block */
				if (btTxState == BT_TX_WAITING_FOR_ACK)
				{
//					if(BtFlag_IsEnabled() && BtFlag_IsConnected(BT_PROFILE_SERIAL_PORT_GENIE))
//	 		                   	SPPEmmiStartBlockTransmit();	
				}				
				DEBUG0("GN> BT_ACK_TIMEOUT_EVENT "); /* KANE_BT job050213 for GENIE */ 
				break;

			case BT_RETRANS_TIMEOUT_EVENT: 
				/* Resend the old block */
				if (btTxState == BT_TX_WAITING_FOR_RETRANS)
				{
//					if(BtFlag_IsEnabled() && BtFlag_IsConnected(BT_PROFILE_SERIAL_PORT_GENIE))
//                    			SPPEmmiStartBlockTransmit();				
				}
				DEBUG0("GN> BT_RETRANS_TIMEOUT_EVENT "); /* KANE_BT job050213 for GENIE */			  
				break;

			case BT_PUT_TX_BLOCK_EVENT: 
				/* Send the new block */
				if (btTxState == BT_TX_IDLE)
				{
//					if(BtFlag_IsEnabled() && BtFlag_IsConnected(BT_PROFILE_SERIAL_PORT_GENIE))
//	                    	SPPEmmiStartBlockTransmit();				
				}
				DEBUG0("GN> BT_PUT_TX_BLOCK_EVENT "); /* KANE_BT job050213 for GENIE */			  
				break;
#endif

/* This defined Events is that for not DMA so, blocked, If U want to use DMA, use below events */
#if 0 /* KANE_BT job050302 */
            /* events from interrupt */
            case  BT_RECEIVED_ACK_EVENT:
                BtReceivedAck ();
                BT_DEBUG0(" BT_RECEIVED_ACK_EVENT "); /* KANE_BT job050213 for GENIE */
                break;
				
            case BT_RECEIVED_NAK_EVENT:
                BtReceivedNak ();
                BT_DEBUG0(" BT_RECEIVED_NAK_EVENT "); /* KANE_BT job050213 for GENIE */
                break;
				
            case BT_FAILED_RECEIVE_EVENT:
                BtFailedReceive ();
                BT_DEBUG0(" BT_FAILED_RECEIVE_EVENT "); /* KANE_BT job050213 for GENIE */				
                break;
				
            case BT_RECEIVED_BLOCK_EVENT:
                BtReceivedBlock ();
                BT_DEBUG0(" BT_RECEIVED_BLOCK_EVENT "); /* KANE_BT job050213 for GENIE */				
                break;
				
            case BT_TRANSMIT_BLOCK_COMPLETE:
                if (btTxState == BT_TX_WAITING_FOR_ACK)
                {
                    KiStartTimer (&btAckTimer);
                }

                if (btsendANakAsap == TRUE)
                {
                    btsendANakAsap = FALSE;
                    BtTransmitByte(BT_NAK_OCTET);
                }
                else if (btsendAnAckAsap == TRUE)
                {
                    btsendAnAckAsap = FALSE;
                    BtTransmitByte(BT_ACK_OCTET);
                }
                DEBUG0(" BT_TRANSMIT_BLOCK_COMPLETE "); /* KANE_BT job050213 for GENIE */				
                break;
#endif
#endif /* GENIE_VIA_BLUETOOTH */

            /* events from interrupt */
            case BT_DMA_RX_EVENT:      /* From Rx Interrupt */
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 03Aug2006 */
                btTestReceiveData();
                DlSpalSetNextRxInterruptStep( btPortHandle, btTestNextNotif);
#else
               // DEBUG0(" 	BT_DMA_RX_EVENT " );	
                BtDmaCheckForRxData();
                DlSpalSetNextRxInterruptStep( btPortHandle, BT_RX_NOTIFY);
#endif /* BT_UART_PERFORMANCE_TEST */

                if (btDmaRxPollActive == FALSE)
                {
                    KiStartTimer (&btDmaRxPollTimer);
                    btDmaRxPollActive   = TRUE;
                }
                break;

            case BT_DMA_TX_EVENT:      /* From Tx Interrupt */
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 03Aug2006 */
			btTestSendData();
#else

#if defined(LGE_CSR_BLUETOOTH) /* Sean_070823: changed uart callback structure */
			if (gUartCallback.txCallback != NULL) 
				gUartCallback.txCallback();
#endif /* LGE_CSR_BLUETOOTH */

#if defined(LGE_BRCM_BLUETOOTH)
			USERIAL_CheckTxData();
#endif /* LGE_BRCM_BLUETOOTH */

#endif		
	            break;

            case BT_DMA_POLL_RX_EVENT: /* From EMMIOSLO */
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 03Aug2006 */
                if(btTestReceiveData() > 0)
#else
                /*
                ** Then call the function in the hardware driver to poll
                ** the Rx buffer
                */
                if (BtDmaCheckForRxData() > 0)
#endif                    
                {   
			/* Reset idle count */
			btRxPollIdleCount = 0;
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 08Aug2006 */                        
			DlSpalSetNextRxInterruptStep( btPortHandle, btTestNextNotif);
#else
			DlSpalSetNextRxInterruptStep( btPortHandle, BT_RX_NOTIFY);
#endif
                }
                else
                {   /* Increment idle count */
                    btRxPollIdleCount++;
                }

                if (btRxPollIdleCount < BT_RX_POLL_IDLE_COUNT_MAX)
                {
                    /* Re-start the poll timer. */
                    KiStartTimer (&btDmaRxPollTimer);
                }
                else
                {
                    /*
                    ** The receiver has been idle for a long time so reset
                    ** the receiver and notify back to 1.
                    */
                    btRxPollIdleCount = 0;
/* BT_COMMON_KIMSANGJIN_071119 noti_011227 */
		      if((BtFlag_IsConnected(BT_PROFILE_DIAL_UP) == TRUE) ||(BtFlag_IsConnected(BT_PROFILE_SERIAL_PORT) == TRUE)) 					
		      {
		           /*During the DUN/SPP , skip the reset dma buffer*/
			    KiStartTimer (&btDmaRxPollTimer);
		      }
		      else
		      {
			    BtDmaResetRxBuffer();
		      }
/* end of BT_COMMON_KIMSANGJIN_071119 */
                }			
                break;

            default:
                DevFail ("Illegal Event");
                break;
            }
        }
    }
}

#endif /* End of LGE_L1_BLUETOOTH */

/* END OF FILE */


