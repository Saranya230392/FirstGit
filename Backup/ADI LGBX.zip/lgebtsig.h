/**************************************************************************
 * TTPCom Software Copyright (c) 1997-2005 TTPCom Ltd
 **************************************************************************
 *   $Id: //central/projects/elbow/Rel16Development/tplgsm/bluetooth/lgebtsig.h#1 $
 *   $Revision: #1 $
 *   $DateTime: 2006/09/30 13:40:33 $
 **************************************************************************
 *  File Description :
 *      LGE BLUETOOTH Signal Definitions
 **************************************************************************/

#if defined(LGE_L1_BLUETOOTH)
/*
** Add new signal Identifiers and types external to the TTP software here
** e.g.
**    SIG_DEF( SIG_AL_KEY_REQ,       AlKeyReq            alKeyReg)
**    SIG_DEF( SIG_AL_MAKE_DATA_IND, AlMakeDataInd       alMakeDataInd)
**    SIG_DEF( SIG_AL_WHAT_CNF,      AlWhatCnf           alWhatCnf)
*/

#if defined (LGE_MMI_BLUETOOTH)
SIG_DEF( SIG_BT_MMI_DUMMY = LGBT_SIGNAL_BASE,	EmptySignal				lgBtDummy)
SIG_DEF(SIG_BT_MMI_MESSAGE,					BtMmiMessage			btMmiMessage)
SIG_DEF( SIG_AFSH_MENUHANDLER_REFRESH_REQ_SIG,	EmptySignal				menuHandlerRefreshSig)
SIG_DEF( SIG_AFSH_BT_RELOAD_REQ_SIG,	 		EmptySignal				BtHandlerReloadSig)
SIG_DEF( SIG_AFBT_BT_INTERRUPT_SIG,	 			EmptySignal				afbtInterruptSig)
SIG_DEF( SIG_AFBT_ALERT_IND,	 					EmptySignal				BtAlertSig)
SIG_DEF(SIG_AFBT_ACTION_SIG,					AfbtActionSig				afbtActionSig)

/* BT_070720_reset_setting */
SIG_DEF(SIG_AFBT_RESET_SETTING_REQ,			EmptySignal				afbtResetSettingReq)
SIG_DEF(SIG_AFBT_RESET_SETTING_CNF,			AfbtResetSettingCnf		afbtResetSettingCnf)

#if defined (LGBX_INCLUDE)
SIG_DEF( SIG_LGBX_CMD, 							EmptySignal 				lgbxCmdType )
#endif /* LGBX_INCLUDE */

#endif /*LGE_MMI_BLUETOOTH*/

#endif /* LGE_L1_BLUETOOTH */


