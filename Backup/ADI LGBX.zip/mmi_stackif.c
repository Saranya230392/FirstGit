#if defined (ON_PC)
#include "defines.h"
#endif
 
/***************************************************************************
* FILE: Mmi_stackif.c
* AUTH: KIM SANGJIN,LEE JINBACK
* DATE: 2006/10/14 ~ 
* DESC: This file only use in converting stack function call, from MMI to BT stack
             we should independent from stack sw
****************************************************************************/

#if defined(LGE_MMI_BLUETOOTH)

#if defined(LGBX_INCLUDE)

/***************************************************************************
* Include Files
***************************************************************************/
#if !defined (AFBT_FNC_H)
#include "afbt_fnc.h"
#endif

#if !defined( BTTASK_SIG_H)
#include "bttask_sig.h"
#endif

#include "LGBXAgApi.h"
#include "LGBXBppApi.h"
#include "LGBXFtcApi.h"
#include "LGBXFtsApi.h"
#include "LGBXGapApi.h"
#include "LGBXOpcApi.h"
#include "LGBXOpsApi.h"
#include "LGBXSppApi.h"

#if defined (LGE_LEMANS_BLUETOOTH)
#include "LGBXA2dpApi.h"
#include "LGBXNewAvrcpType.h"
#endif /*LGE_LEMANS_BLUETOOTH*/

/* BT_COMMON_KIMSANGJIN_070428 noti_011057*/
#if defined(LGE_MMI_EXTERNAL_MEMORY)
#if !defined ( L1EXFS_TYP_H )
#include "L1exfs_typ.h"
#endif /*L1EXFS_TYP_H*/
#endif /*LGE_MMI_EXTERNAL_MEMORY*/
/* end of BT_COMMON_KIMSANGJIN_070428 */
#if defined(LGE_CSR_BLUETOOTH) /* Temp for dolphin2 */

typedef struct
{
    uint32_t lap;		/* Lower Address Part 00..23 */
    uint8_t  uap;               /* upper Address Part 24..31 */
    uint16_t nap;		/* Non-significant    32..47 */
} BD_ADDR_T;

#endif
/***************************************************************************
* Manifest Constants / Defines
***************************************************************************/

/* BT_MMI_CHOOBYOUNGSOO */
extern Int8 p_bt_buf[NUM_OF_GETDIR_BUF_LENGTH] ;
UINT8_T afbtChangeFileTypeToLgbxObjType(AfmfFileType type);
LGBX_SERVICE_TYPE afbtGetBxProfile(AfbtProfile profile);
#if defined(LGE_BRCM_BLUETOOTH)
extern const char bcm2045_patch_version[];
#endif

#if defined(LGE_L1_FM) /* BT_COMMON_TIBURONA_090117 */
extern BOOLEAN LGE_fm_is_enabled(void);
#endif

/* BT_COMMON_KIMSANGJIN_070313 */
static void CopyAgChar2Char(char *chStr, AgCharCode *agStr, Int16 len)
{
	Int16 i;

	for (i = 0; i < len; i++)
		chStr[i] = (char) agStr[i];
	chStr[i] = '\0';
}

void BtLaunchTask(void)
{
#if defined(LGE_CSR_BLUETOOTH) /* Temp for dolphin2 */
	BD_ADDR_T*  bdAddr=PNULL; /* noti_011219*/
#endif
#if defined(LGE_BRCM_BLUETOOTH)
	BT_DEBUG(("[MMI] BtLaunchTask() patch :%s", bcm2045_patch_version));
#else
	BT_DEBUG(("[MMI] BtLaunchTask()"));
#endif

#if defined(LGE_LEMANS_BLUETOOTH)
	LGBX_GAP_SetPowerCycleServer(LGBX_SVC_HSP | LGBX_SVC_HFP |LGBX_SVC_OPP | LGBX_SVC_FTP|LGBX_SVC_SPP|LGBX_SVC_A2SRC);//|LGBX_SVC_DUN);
#else
	LGBX_GAP_SetPowerCycleServer(LGBX_SVC_HSP | LGBX_SVC_HFP |LGBX_SVC_OPP | LGBX_SVC_FTP|LGBX_SVC_SPP|LGBX_SVC_DUN);
#endif

#if defined(LGE_CSR_BLUETOOTH) /* Temp for dolphin2 */
	KiAllocZeroMemory(sizeof(BD_ADDR_T), (void **)&bdAddr);
	bdAddr->nap = ( ((afbtNVMyinfoData.MyInfo.BdAddr[0] & 0x00ff)<<8)  | ((afbtNVMyinfoData.MyInfo.BdAddr[1] & 0xff)) );
	bdAddr->uap= afbtNVMyinfoData.MyInfo.BdAddr[2] & 0x00ff;
	bdAddr->lap = ( ((afbtNVMyinfoData.MyInfo.BdAddr[3] & 0x0000ff)<<16) | ((afbtNVMyinfoData.MyInfo.BdAddr[4] & 0x00ff)<<8)  | ((afbtNVMyinfoData.MyInfo.BdAddr[5] & 0xff)) );
	BootstrapSetBdAddress(bdAddr);
	KiFreeMemory((void **)&bdAddr);
#endif /* LGE_CSR_BLUETOOTH */
	LGBX_GAP_Enable(TRUE, TRUE);
}

void BtShutdownTask(void)
{
	BT_DEBUG(("[MMI] BtShutdownTask() "));
	LGBX_GAP_Disable();
}

Boolean BtIsEnabled(void)
{
#if 1
	if(LGBX_GAP_IsEnabled() == LGBX_SUCCESS)
		return TRUE;
	else
		return FALSE;
#else
       return BtFlag_IsEnabled();
#endif
}

void BtStartInquiry(AfbtProfile profile)
{
	BT_DEBUG(("[MMI] BtStartInquiry() : profile %d", profile));
	LGBX_GAP_Search(afbtGetBxProfile(profile), TRUE, 0, 0);
}

void BtStopInquiry(void)
{
	BT_DEBUG(("[MMI] BtStopInquiry()"));
	LGBX_GAP_SearchCancel();
}

LGBX_DEVICEINFO_LIST_TYPE BtRetrieveSearchList(void)
{
	LGBX_DEVICEINFO_LIST_TYPE tmpList;

	tmpList = LGBX_GAP_RetrieveSearchList();

	BT_DEBUG(("[MMI] BtRetrieveSearchList() : list cnt %d", tmpList.Cnt));

	return tmpList;
}

void BtSendPasskey(Int8 passkey[], Boolean flag, LGBX_BD_ADDR_TYPE bd_addr)
{
	LGBX_PINCODE_TYPE bxPincode;
	bxPincode.Length = strlen(passkey);
	memcpy(bxPincode.Pin, passkey, bxPincode.Length);
	bxPincode.Pin[bxPincode.Length] = '\0';
       /*Need get bd address function*/
	BT_DEBUG(("[MMI] BtSendPasskey() : Pincode [%s] flag [%d] BD_addr [%s]", bxPincode.Pin, flag, afbtGetBDAddrString(bd_addr)));
	LGBX_GAP_PinReply(bxPincode, flag, bd_addr);
}
void BtBxSendPasskey(LGBX_BD_ADDR_TYPE bd_addr, Int8 len, Int8* number)
{
	LGBX_PINCODE_TYPE bxPincode;

	BT_DEBUG(("[MMI] BtBxSendPasskey : BD_addr [%s], len %d, Pincode [%s]", afbtGetBDAddrString(bd_addr), len, number));
	bxPincode.Length = len;
	memcpy(bxPincode.Pin, number, len);
	bxPincode.Pin[len] = '\0';
	LGBX_GAP_AddRegDev(bd_addr, LGBX_SVC_ANY, bxPincode);
}


void BtSetVisibility(Boolean visibility)
{
	BT_DEBUG(("BtSetVisibility :: %s",visibility?"TRUE":"FALSE"));
	LGBX_GAP_SetVisible(visibility);
}

Boolean IsBtSetVisibility(void)
{
       if(LGBX_SUCCESS == LGBX_GAP_IsVisible())
       {
		BT_DEBUG(("BtSetVisibility was OK"));
		return TRUE;
       }
       else
       {
		BT_DEBUG(("BtSetVisibility was Not OK"));
		return FALSE;
       }
}

void BtSetLocalName(AgCharCode *name)
{
	static Int8 myDevName[LGBX_BD_NAME_LEN]; 
	memset(myDevName, 0x00, LGBX_BD_NAME_LEN);

	/* BT_COMMON_KIMSANGJIN_070507 noti_011081*/
	utUcs2ToUtf8(name, utStrlenUcs2(name), myDevName, LGBX_BD_NAME_LEN);
	BT_DEBUG(("BtSetLocalName ::  send BT_APP_SET_LOCALNAME(%s)[len:%d]", myDevName,utStrlenUcs2(name)));
	LGBX_GAP_SetDeviceName((CHAR_T *)myDevName);
}

void BtSetRemoteNickName(LGBX_BD_ADDR_TYPE bdAddr, Int8 * name)
{
	LGBX_GAP_SetRemoteNickName(bdAddr, (CHAR_T *)name);
}

void BtEnterTestMode(void)
{
        /*Need to modify to set a DUT mode*/
	BT_DEBUG(("Need to modify to set a DUT mode"));
	BT_DEBUG((">>> Not Implement BtSDPQuerySomeSvc()")); 
}

void BtGetServiceList(LGBX_BD_ADDR_TYPE bd_addr)
{
	LGBX_GAP_Discover(bd_addr, 
/* BT_COMMON_KIMSANGJIN_070111 noti_010410 :Get service information more quickly*/
#if defined(LGE_LEMANS_BLUETOOTH)
                                         LGBX_SVC_SPP|LGBX_SVC_DUN|LGBX_SVC_HSP|LGBX_SVC_HFP|LGBX_SVC_HSP_HFP|
                                         LGBX_SVC_OPP|LGBX_SVC_FTP|LGBX_SVC_BPP|LGBX_SVC_NEWAVRCP|LGBX_SVC_A2SRC
#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
					      LGBX_SVC_SPP|LGBX_SVC_DUN|LGBX_SVC_HSP|LGBX_SVC_HFP|LGBX_SVC_HSP_HFP|
					      LGBX_SVC_OPP|LGBX_SVC_FTP|LGBX_SVC_BPP
#else
		                           LGBX_SVC_ALL
#endif /*LGE_LEMANS_BLUETOOTH*/		
/* end of BT_COMMON_KIMSANGJIN_070111 */
		);
}
			
void BtSDPQuerySomeSvc(LGBX_BD_ADDR_TYPE *bd_addr)
{
       BT_DEBUG((">>> Not Implement BtSDPQuerySomeSvc() : %s", bd_addr));	
}

void BtSDPQueryStopReq(void)
{
	BT_DEBUG((">>> Not Implement BtSDPQueryStopReq()")); 
}

void BtAgwActivate(void)
{			
	BT_DEBUG((">>> Not Implement BtAgwActivate()")); 
}

void BtAgwDeactivate(void)
{
	BT_DEBUG((">>> Not Implement BtAgwDeactivate()")); 
}

void BtHfgActivate(void)
{
	BT_DEBUG((">>> Not Implement BtHfgActivate()")); 
}

void BtHfgDeactivate(void)
{
	BT_DEBUG((">>> Not Implement BtHfgDeactivate()")); 
}

void BtSppActivate(Int16 instId)
{
	BT_DEBUG((">>> Not Implement BtSppActivate() : %0x", instId)); 
}

void BtSppDeactivate(Int16 instId)
{
	BT_DEBUG((">>> Not Implement BtSppDeactivate() : %0x", instId)); 

}

void BtDunActivate(void)
{
	BT_DEBUG((">>> Not Implement BtDunActivate()")); 
}
		
void BtDunDeactivate(void)
{
	BT_DEBUG((">>> Not Implement BtDunDeactivate()")); 
}

/* BT_COMMON_KIMSANGJIN_070430 noti_011057 */
static void BtChangeSperator(char  *src_path, char *dst_path)
{
    Int16 i,j;
#if defined(LGE_MMI_EXTERNAL_MEMORY)    
    if(strncmp(src_path,LGE_EXT_SYSTEM_DRIVE_PATH,5) == 0) /*LGE_EXT_SYSTEM_DRIVE_PATH  "DEV0"*/
    {
           strcat(dst_path, "A:/External memory/");  /*19=strlen("A:/External Memory/")  noti_011057  */
           j=19;/*start from 19th array (means 20th charactor)*/
	    for(i=6; i<strlen(src_path); i++)
	    {
	             if(src_path[i] == '\\') src_path[i]='/'; /*Nor use '/' , EXFS use '\\'*/
			dst_path[j]=src_path[i];
			j++;
	    } 
    }
    else
#endif /*LGE_MMI_EXTERNAL_MEMORY*/		
    {
          strcpy(dst_path,src_path);
    }
    BT_DEBUG(("BtChangeSperator [%s]",dst_path));   
}

void BtOpcPutObject(LGBX_DEVICEINFO_TYPE *dev, FileNameChar * fileFullPath, AfmfFileType  type, Int8 *p_obj, Int32 fileSize)
{
	static UINT8_T lgbxOppObjType;

#if defined(LGE_FS_SUPPORT_LONG_FILE_NAME)
	char p_name[AFBT_FILENAME_SIZE+1];
       static char file_path[AFBT_FILENAME_SIZE+1];

	memset(p_name, 0, sizeof(char)*(AFBT_FILENAME_SIZE +1));
       /* BT_COMMON_KIMSANGJIN_071025 */
	utUcs2ToUtf8(fileFullPath, STRLEN(fileFullPath), p_name, AFBT_FILENAME_SIZE+1);  /*noti_011084*/
	BT_DEBUG(("API : BtOpcPutObject : fullpath name :%s [%d]",p_name,STRLEN(fileFullPath)));
#else
	FileNameChar * p_name = fileFullPath;
#endif

	lgbxOppObjType = afbtChangeFileTypeToLgbxObjType(type);
	
/*****************************************************************************************************
LGBX_ASYNC VOID_T LGBX_OPC_PutObject
			(LGBX_IN LGBX_BD_ADDR_TYPE p_addr,  // the address of device 
			 LGBX_IN STR_T p_name,				// full path and file name
			 LGBX_IN UINT8_T type,				// lgbx object type
			 LGBX_IN PUINT8_T p_obj,				// buffer point. if using file system directly, then input 'null'.
			 LGBX_IN UINT32_T size_obj);			// file size
******************************************************************************************************/
/* BT_COMMON_KIMSANGJIN_080128 */
       if(strlen(p_name)== 0) /*It means there are any file path*/
       {
	if(lgbxOppObjType == LGBX_OBJ_VCARD)
	{
		sprintf(p_name, "/vcard.vcf");
	}
	else if(lgbxOppObjType == LGBX_OBJ_VCAL) 
	{
		sprintf(p_name, "/vcalendar.vcs");
	}
	else if(lgbxOppObjType == LGBX_OBJ_VMSG) 
	{
		sprintf(p_name, "/memo.txt");
	}
      else if(lgbxOppObjType == LGBX_OBJ_VNOTE)
      {
		  sprintf(p_name, "/vnote.vnt");
      }
      else 
      {
               BT_DEBUG(("Unknow lgbxOppObjType[%d]",lgbxOppObjType));
      }
      }
      else
      {
                /********************************************************************************************
                  - Sometime My stuff set a filetype to Vcard or Vcalendar even though it just a file (B:/Others/kim sang jin.vcf)
                  - So, we add a check file string length 
                *********************************************************************************************/
		  lgbxOppObjType=LGBX_OBJ_UNKNOWN;
		  BT_DEBUG(("p_name[%s]",p_name));
      }
/* end of BT_COMMON_KIMSANGJIN_080128 */

	BT_DEBUG(("BtOpcPutObject() Addr[%s]  fileName [%s] fileSize[%ld]  fileType[%d]", afbtGetBDAddrString(dev->BdAddr), p_name, fileSize, lgbxOppObjType));

	BT_DEBUG(("Opp information : \r\n[%s]", p_obj));
       memset(file_path,0x00,sizeof(char)*(AFBT_FILENAME_SIZE+1));
	BtChangeSperator(p_name,file_path);
       BT_DEBUG(("BtOpcPutObject :: file_path[%s]",file_path));
	LGBX_OPC_PutObject(dev->BdAddr, 
						file_path,
						lgbxOppObjType,
						p_obj,
						fileSize);
}

void BtOpcSendCancel(void)
{
	BT_DEBUG(("API : BtOpcSendCancel"));
	LGBX_OPC_Cancel();
}

void BtOpsSendCancel(void)
{
	BT_DEBUG(("API : BtOpsSendCancel"));
	LGBX_OPS_Cancel();
}

void BtOpsActivate(void)
{
	BT_DEBUG((">>> Not Implement BtOpsActivate()")); 
}

void BtOpsDeactivate(void)
{
	BT_DEBUG((">>> Not Implement BtOpsDeactivate()")); 
}


void BtOpenSecurityDB(void)
{
	BT_DEBUG((">>> Not Implement BtOpenSecurityDB()")); 
}

void BtCloseSecurityDB(void)
{
	BT_DEBUG((">>> Not Implement BtCloseSecurityDB()")); 
}

/* bd_addr must be a statically-allocated object */
void BtBondDevice(LGBX_BD_ADDR_TYPE *bd_addr)
{
	BT_DEBUG((">>> Not Implement BtBondDevice() : %s", bd_addr)); 
}

LGBX_RESULT_TYPE BtDebondDevice(LGBX_BD_ADDR_TYPE *bd_addr)
{
	BT_DEBUG(("[MMI] BtDebondDevice() : delete [%s] ", afbtGetBDAddrString(*bd_addr)));
	return LGBX_GAP_DeleteRegDev(*bd_addr, LGBX_SVC_ALL);
}

LGBX_RESULT_TYPE BtDebondAllDevice(LGBX_SERVICE_TYPE *service)
{
	return LGBX_GAP_DeleteRegAll(LGBX_SVC_ALL);
}

/* BT_LEEJINBAEK 20071022 : set authorize */
LGBX_RESULT_TYPE BtSetAuthorize(LGBX_BD_ADDR_TYPE BdAddr, Boolean bAuthorize)
{
#if 0
	BT_DEBUG(("[MMI] BtSetAuthorize() : bAuthorize %d, [%s] ", bAuthorize, afbtGetBDAddrString(BdAddr)));
	return LGBX_GAP_SetAuthorize(BdAddr, bAuthorize);
#else	
	Int32 devIndex = 0;
	Int32 devCnt = afbtNVDBData.BondDevCnt;

	for(devIndex = 0; devIndex < devCnt; devIndex++)
		if(afbtIsBdAddrEqual(afbtNVDBData.DeviceInfo[devIndex].BdAddr, BdAddr))
			afbtNVDBData.DeviceInfo[devIndex].bAuthorized = bAuthorize;
		
	return LGBX_SUCCESS;
#endif
}

/* BT_LEEJINBAEK 20071022 : set authorize */
LGBX_RESULT_TYPE BtIsAuthorized(LGBX_BD_ADDR_TYPE BdAddr)
{
#if 0
	BT_DEBUG(("[MMI] BtIsAuthorized() : [%s] ", afbtGetBDAddrString(BdAddr)));
	return LGBX_GAP_IsAuthorized(BdAddr);
#else	
	Int32 devIndex = 0;
	Int32 devCnt = afbtNVDBData.BondDevCnt;

	for(devIndex = 0; devIndex < devCnt; devIndex++)
		if(afbtIsBdAddrEqual(afbtNVDBData.DeviceInfo[devIndex].BdAddr, BdAddr))
			return afbtNVDBData.DeviceInfo[devIndex].bAuthorized;

	return LGBX_SUCCESS;
#endif
}

LGBX_SERVICE_TYPE BtIsConnected(LGBX_BD_ADDR_TYPE addr)
{
	return LGBX_GAP_IsConnected(addr);
}

LGBX_SERVICE_TYPE BtIsPaired(LGBX_BD_ADDR_TYPE addr)
{
	LGBX_RESULT_TYPE retValue;
//KF240_Kimyoungwun_20071228		
	LGBX_DEVICEINFO_TYPE *tmpDev = PNULL ;

	retValue = LGBX_GAP_GetRegDevInfo(addr, tmpDev);
	BT_DEBUG(("[MMI] BtIsPaired() : return value  [%d] ", retValue));

	return retValue;
}

Boolean BtIsAnyDevConnected(void)
{
	Boolean	result = FALSE;
#if 1
	LGBX_DEVICEINFO_LIST_TYPE devList;

	LGBX_GAP_GetConList(&devList);

	if(devList.Cnt != 0)
		result = TRUE;
	
	return result;
#else	
	Int16 i;
	for (i = 0; i < BT_PROFILE_NUMS; i++)
	{
		if(BtFlag_IsConnected(i) == TRUE)
		{
		   result = TRUE;
		}
	}
	return result;
#endif
}

/*KF300_KIMJAEHUN_071030 BT COMMON UI*/ 
UINT8_T BtConnectedDevClass(void)
{
	//KIMJAEHUN_071213 : 
	UINT8_T devClass;
		Int32 index = 0;

		for(index = 0; index < afbtGetPairedDevCnt(); index++)
		{
			if (BtIsConnected(afbtNVDBData.DeviceInfo[index].BdAddr))
				{
				devClass = afbtNVDBData.DeviceInfo[index].DevClass;
	return devClass;
}
		}
	return 0;
}

UINT8_T afbtChangeFileTypeToLgbxObjType(AfmfFileType type)
{
	UINT8_T lgbxObjType;

	switch(type)
	{
		case AFMF_FILE_TYPE_VCARD:
			lgbxObjType = LGBX_OBJ_VCARD;
			break;
		case AFMF_FILE_TYPE_VCAL:
			lgbxObjType = LGBX_OBJ_VCAL;
			break;
		case AFMF_FILE_TYPE_ICAL:
			lgbxObjType = LGBX_OBJ_ICAL;
			break;
		case AFMF_FILE_TYPE_VMSG:
			lgbxObjType =LGBX_OBJ_VMSG;   // LGBX_OBJ_VMSG -> LGBX_OBJ_TEXT guide from Ahn; /*noti_011102*/
			break;
		case AFMF_FILE_TYPE_JPG:
			lgbxObjType = LGBX_OBJ_JPEG;
			break;
		case AFMF_FILE_TYPE_GIF:
			lgbxObjType = LGBX_OBJ_GIF;
			break;
/* BT_COMMON_KIMSANGJIN_080111 noti_011257 */
	       case AFMF_FILE_TYPE_VNOTE:
	       {
	              lgbxObjType = LGBX_OBJ_VNOTE;
	       	break;
	       }
/* end of BT_COMMON_KIMSANGJIN_080111 */
		default:
		{
		       BT_DEBUG(("Uknown afbtChangeFileTypeToLgbxObjType(0x%x)",type));
			lgbxObjType = LGBX_OBJ_UNKNOWN;
			break;
	}
	}
	return lgbxObjType;
}

AfbtProfile afbtGetProfile(unsigned int devClass)   // $suhui Not Used
{
	AfbtProfile profile;

	switch(devClass)
		{
		case LGBX_SVC_BIM:
			profile = AFBT_P_BIM;
			break;
		
		case LGBX_SVC_SPP:
			profile = AFBT_P_SPP;
			break;
		
		case LGBX_SVC_DUN:
			profile = AFBT_P_DUN;
			break;
		case LGBX_SVC_GE:
			profile = AFBT_P_GE;
			break;
		case LGBX_SVC_LAP:
			profile = AFBT_P_LAP;
			break;
		case LGBX_SVC_HSP:
			profile = AFBT_P_HSP;
			break;
		case LGBX_SVC_HFP:
			profile = AFBT_P_HFP;
			break;
		case LGBX_SVC_FTP:
			profile = AFBT_P_FTP;
			break;
		case LGBX_SVC_OPP:
			profile = AFBT_P_OPP;
			break;
		case LGBX_SVC_CTP:
			profile = AFBT_P_CTP;
			break;
		case LGBX_SVC_ICP:
			profile = AFBT_P_ICP;
			break;
		case LGBX_SVC_PAN:
			profile = AFBT_P_PAN;
			break;
		case LGBX_SVC_A2DP:
		case LGBX_SVC_A2SRC:
		case LGBX_SVC_NEWAVRCP:           
			profile = AFBT_P_A2DP;
			break;
		case LGBX_SVC_AV:
			profile = AFBT_P_AG;
			break;
		case LGBX_SVC_AVRCP:
			profile = AFBT_P_AVRCP;
			break;
		case LGBX_SVC_PBAP:	// $suhui PBAP
			profile = AFBT_P_PBAP;
			break;
		default :
			BT_DEBUG((" afbtGetProfile> Unknown BT service"));
			profile =AFBT_P_ALL;
			break;
		}
	return profile;
}

LGBX_SERVICE_TYPE afbtGetBxProfile(AfbtProfile profile)
{
	LGBX_SERVICE_TYPE type = LGBX_SVC_ALL;
	switch(profile)
		{
		case AFBT_P_BIM:
			type = LGBX_SVC_BIM;
			break;
		
		case AFBT_P_SPP:
			type = LGBX_SVC_SPP;
			break;
		
		case AFBT_P_DUN:
			type = LGBX_SVC_DUN;
			break;
		case AFBT_P_GE:
			type = LGBX_SVC_DUN;
			break;
		case AFBT_P_LAP:
			type = LGBX_SVC_LAP;
			break;
		case AFBT_P_HSP:
			type = LGBX_SVC_HSP;
			break;
		case AFBT_P_HFP:
			type = LGBX_SVC_HFP;
			break;
		case AFBT_P_FTP:
			type = LGBX_SVC_FTP;
			break;
		case AFBT_P_OPP:
			type = LGBX_SVC_OPP;
			break;
		case AFBT_P_CTP:
			type = LGBX_SVC_CTP;
			break;
		case AFBT_P_ICP:
			type = LGBX_SVC_ICP;
			break;
		case AFBT_P_PAN:
			type = LGBX_SVC_PAN;
			break;
		case AFBT_P_A2DP:
			//type = LGBX_SVC_A2DP;
			type = LGBX_SVC_A2SRC;			
			break;
		case AFBT_P_AG:
			type = LGBX_SVC_AV;
			break;
		case AFBT_P_AVRCP:
			type = LGBX_SVC_NEWAVRCP;  // $suhui AVRCP
			break;

		case AFBT_P_BPP:
			type = LGBX_SVC_BPP;
			break;
		case AFBT_P_PBAP:	// $suhui PBAP
			type = LGBX_SVC_PBAP;
			break;

		case AFBT_P_ALL:
		default :
			type = LGBX_SVC_ALL;
			break;
		}

	return type;
	}

void BtGetSVCdiscover(LGBX_BD_ADDR_TYPE bd_addr)
{
	BT_DEBUG(("[MMI] BtGetSVCdiscover() : addr [%s] ", afbtGetBDAddrString(bd_addr)));
	LGBX_GAP_Discover(bd_addr, LGBX_SVC_ALL);
}

/* BT_LEEJINBAEK 20071019 : AV connect */
void BtSendConnect(LGBX_DEVICEINFO_TYPE *dev, LGBX_SERVICE_TYPE reqSvcType)
{ 
	LGBX_SERVICE_TYPE devServices = dev->Services;
	BT_DEBUG(("[MMI] BtSendConnect() : addr [%s], Services [0x%08X] device class[0x%x], reqSvcType %0x ", afbtGetBDAddrString(dev->BdAddr), dev->Services,dev->DevClass, reqSvcType));

	if(reqSvcType != LGBX_SVC_ANY)
	{
		LGBX_GAP_Connect(dev->BdAddr, reqSvcType);
		return;
	}
		
        if((devServices&LGBX_SVC_BPP) == LGBX_SVC_BPP)
	       LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_BPP);
	else if(((devServices&LGBX_SVC_FTP) == LGBX_SVC_FTP) &&(dev->DevClass != LGBX_DEV_CLASS_AUDIO)) /*noti_011132*/
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_FTP);
	else if((devServices&LGBX_SVC_HFP) == LGBX_SVC_HFP)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_HFP);
	else if((devServices&LGBX_SVC_HSP) == LGBX_SVC_HSP)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_HSP);
	else if((devServices&LGBX_SVC_HSP_HFP) == LGBX_SVC_HSP_HFP) /*noti_010406 add hs/hf device connect*/
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_HSP_HFP);
#if defined(LGE_LEMANS_BLUETOOTH)
	else if((devServices&LGBX_SVC_A2SRC) == LGBX_SVC_A2SRC)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_A2SRC);
	else if((devServices&LGBX_SVC_AV) == LGBX_SVC_AV)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_A2SRC);
#endif	 /*LGE_LEMANS_BLUETOOTH*/
	else if((devServices&LGBX_SVC_OPP) == LGBX_SVC_OPP)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_OPP);
	else if((devServices&LGBX_SVC_DUN) == LGBX_SVC_DUN)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_DUN);
	else if((devServices&LGBX_SVC_SPP) == LGBX_SVC_SPP)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_SPP);
	// $suhui PBAP : PBAP�� Server�� ����
	else
	{
		
		BT_DEBUG(("Dev Services is not inited : COD service:%x", dev->R.COD.Service));
		LGBX_GAP_Connect(dev->BdAddr, dev->R.COD.Service);
	}
}

//BT_KIMJAEHUN_20080318 discovery service everytime before connect device	
void BtSvcSendConnect(LGBX_DEVICEINFO_TYPE *dev, UINT8_T devClass, LGBX_SERVICE_TYPE reqSvcType)
{ 
	LGBX_SERVICE_TYPE devServices = dev->Services;
	BT_DEBUG(("[MMI] BtSvcSendConnect() : addr [%s], Services [0x%08X] device class[0x%x], reqSvcType %0x ", afbtGetBDAddrString(dev->BdAddr), dev->Services,devClass, reqSvcType));

	if(reqSvcType != LGBX_SVC_ANY)
	{
		LGBX_GAP_Connect(dev->BdAddr, reqSvcType);
		return;
	}
		
        if((devServices&LGBX_SVC_BPP) == LGBX_SVC_BPP)
	       LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_BPP);
	else if(((devServices&LGBX_SVC_FTP) == LGBX_SVC_FTP) &&(devClass != LGBX_DEV_CLASS_AUDIO)) /*noti_011132*/
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_FTP);
	else if((devServices&LGBX_SVC_HFP) == LGBX_SVC_HFP)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_HFP);
	else if((devServices&LGBX_SVC_HSP) == LGBX_SVC_HSP)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_HSP);
	else if((devServices&LGBX_SVC_HSP_HFP) == LGBX_SVC_HSP_HFP) /*noti_010406 add hs/hf device connect*/
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_HSP_HFP);
#if defined(LGE_LEMANS_BLUETOOTH)
	else if((devServices&LGBX_SVC_A2SRC) == LGBX_SVC_A2SRC)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_A2SRC);
	else if((devServices&LGBX_SVC_AV) == LGBX_SVC_AV)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_A2SRC);
#endif	 /*LGE_LEMANS_BLUETOOTH*/
	else if((devServices&LGBX_SVC_OPP) == LGBX_SVC_OPP)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_OPP);
	else if((devServices&LGBX_SVC_DUN) == LGBX_SVC_DUN)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_DUN);
	else if((devServices&LGBX_SVC_SPP) == LGBX_SVC_SPP)
		LGBX_GAP_Connect(dev->BdAddr, LGBX_SVC_SPP);
	// $suhui PBAP : PBAP�� Server�� ����
	else
	{
		
		BT_DEBUG(("Dev Services is not inited : COD service:%x", dev->R.COD.Service));
		LGBX_GAP_Connect(dev->BdAddr, dev->R.COD.Service);
	}
}


void BtConnectCancel(LGBX_DEVICEINFO_TYPE *dev)
{
	BT_DEBUG(("[MMI] BtConnectCancel() : addr [%s]", afbtGetBDAddrString(dev->BdAddr)));
	LGBX_GAP_ConnectCancel(dev->BdAddr);
}

void BtSendDisconnect(LGBX_DEVICEINFO_TYPE *dev)
{
	LGBX_SERVICE_TYPE retService;
	retService = LGBX_GAP_IsConnected(dev->BdAddr);
/* BT_LEEJINBAEK 20071019 : AV connect */
	#if defined(LGE_LEMANS_BLUETOOTH)
	if((retService&LGBX_SVC_A2SRC) == LGBX_SVC_A2SRC)
		retService = LGBX_SVC_A2SRC;
	else if((retService&LGBX_SVC_AV) == LGBX_SVC_AV)
		retService = LGBX_SVC_AV;
	#endif	 /*LGE_LEMANS_BLUETOOTH*/
	
	BT_DEBUG(("[MMI] BtSendDisconnect() : addr [%s], Services [%6x] ", afbtGetBDAddrString(dev->BdAddr), retService));
	LGBX_GAP_Disconnect(dev->BdAddr, retService);
}

/* BT_COMMON_KIMSANGJIN_070427 */
void BtDisableServer(LGBX_SERVICE_TYPE Service)
{
	BT_DEBUG(("[MMI] BtDisableServer() : Services [%6x] ", Service));
	LGBX_GAP_DisableServer(Service);
}

/* BT_COMMON_KIMSANGJIN_070503 noti_011066 */
void BtEnableServer(LGBX_SERVICE_TYPE Service)
{
	BT_DEBUG(("[MMI] BtEnableServer() : Services [%6x] ", Service));
	LGBX_GAP_EnableServer (Service);
}
/* end of BT_COMMON_KIMSANGJIN_070503 */

/*BT_COMMON 20071126 baeheejung*/
void BtSetVisibleConnectableState (Boolean flag)
{
	BT_DEBUG(("[MMI] BtSetVisibleConnectableState() flag:[%s]", flag?"TRUE":"FALSE"));
	LGBX_GAP_SetVisible(flag);
	LGBX_GAP_SetConnectable(flag);
}

/*BT_COMMON 20071127 baeheejung*/
void BtSetConnectableState (Boolean flag)
{
	BT_DEBUG(("[MMI] BtSetConnectableState() flag:[%s]", flag?"TRUE":"FALSE"));
	LGBX_GAP_SetConnectable(flag);
}

Int16  BtSendAllDevDisConnect(void)
{
//KF240_Kimyoungwun_20071228	
	Int8	i = 0;
	LGBX_DEVICEINFO_LIST_TYPE *pDevList = PNULL;

	if(LGBX_GAP_GetConList(pDevList) == LGBX_SUCCESS)
	{
		for(i = 0; i < pDevList->Cnt; i++)
		{
			LGBX_GAP_Disconnect(pDevList->Info[i].BdAddr, LGBX_SVC_ALL);
		}
	}

	return i;
}

void  BtSendAGDisConnect(void) /*noti_011183*/
{
       Int32 count=0;
       Int32 i=0;
	LGBX_SERVICE_TYPE retService;

	count=afbtNVDBData.BondDevCnt;
	for(i=0; i<count; i++)
	{
           retService = BtIsConnected(afbtNVDBData.DeviceInfo[i].BdAddr);
           BT_DEBUG(("BtSendAGDisConnect service==> [0x%x]",retService));
	    if(((retService&LGBX_SVC_HSP) == LGBX_SVC_HSP) || ((retService&LGBX_SVC_HFP) == LGBX_SVC_HFP) ||((retService&LGBX_SVC_HSP_HFP) == LGBX_SVC_HSP_HFP))
	    {
		  LGBX_GAP_Disconnect(afbtNVDBData.DeviceInfo[i].BdAddr, retService);
	    }
	}

}

void BtEnableAudio(void)
{
	if(BtFlag_IsConnected(BT_PROFILE_HEADSET) || BtFlag_IsConnected(BT_PROFILE_HANDSFREE))
		LGBX_AG_EnableAudio();
}

void BtDisableAudio(void)
{
	if(BtFlag_IsConnected(BT_PROFILE_HEADSET) || BtFlag_IsConnected(BT_PROFILE_HANDSFREE))
		LGBX_AG_DisableAudio();
}

Boolean BtIsAudioEnabled(void)
{
	Boolean retValue;
	retValue = LGBX_AG_IsAudioEnabled();
	return retValue;	
}

void BtInitCallState(void)
{
#if 1
	BtSetCallState(LGBX_AG_CALL_IDLE_TYPE);
#else
	BtSetCallState(BT_STATE_CALL_IDLE);
#endif
}

int momting = 0; /*hfp15 20071001 baeheejung*/
#if 1
LGBX_AG_CALLSTATE_TYPE btCallstate =LGBX_AG_CALL_IDLE_TYPE;
void BtSetCallState(LGBX_AG_CALLSTATE_TYPE states)
{
       if(BtFlag_IsEnabled() == TRUE)    /* BT_COMMON_KIMSANGJIN_071128 */
       {
		BT_DEBUG(("[MMI] BtSetCallState : %d", states));
		//if LGBX_GAP_IsEnabled
		btCallstate =states;
		LGBX_AG_SetCallState(states);
       }
}
#else
BTCallStateType btCallstate =BT_STATE_CALL_IDLE;
void BtSetCallState(BTCallStateType states)
{
	BT_DEBUG(("[MMI] BtSetCallState : %d", states));
}
#endif

/* BT_COMMON_KIMSANGJIN_070528 noti_011118*/
LGBX_AG_CALLSTATE_TYPE BtGetCallState(void)
{
      BT_DEBUG(("BtGetCallState(%d)",btCallstate));
      return btCallstate;
}
/* end of BT_COMMON_KIMSANGJIN_070528 */

void BtSetNetworkState(LGBX_AG_NETSTATE_TYPE states)
{
	BT_DEBUG(("[MMI] BtSetNetworkState : %d", states));
//if LGBX_GAP_IsEnabled
       if(BtFlag_IsEnabled() == TRUE) /*noti_011114 network enable*/
       {
	LGBX_AG_SetNetworkState(states);
       }
}

/* BT_COMMON_KIMSANGJIN_070308 noti_011029*/
void BtSetCID(char* num,Int8 len)
{
	BT_DEBUG(("[MMI] BtSetCID : %s[%d] ", num,len));
	LGBX_AG_SetCID((UINT8_T*)num,len);
}
/* end of BT_COMMON_KIMSANGJIN_070308 */

void BtSetSpkGain(Int8 level)	/* BT_COMMON_TIBURONA_090117 */
{
	UINT8_T spkGain=0;
	
#if defined(LGE_L1_FM) 
	if(LGE_fm_is_enabled()==TRUE)
	{
		spkGain = level * 15 / FM_UISPK_MAXLVL;
		BT_DEBUG(("[MMI] BtSetSpkGain() FM Radio via SCO : level %d, spkGain %d", level, spkGain));
	}
	else
#endif		
	{
		spkGain = level * 15 / AG_UISPK_MAXLVL;	// BT_COMMON LEEJINBAEK 20080111 : reassign volume level for MMI
		BT_DEBUG(("[MMI] BtSetSpkGain() AG via SCO : level %d, spkGain %d", level, spkGain));
	}
	LGBX_AG_SetSpkGain(spkGain);
}

void BtSetPcmMute(Boolean Spk, Boolean Mic)
{
	BT_DEBUG(("[MMI] BtSetPcmMute() Spk=%s, Mic=%s", Spk?"True":"False", Mic?"True":"False"));
	LGBX_AG_SetPcmMute(Spk, Mic);
}

void BtAgwOpenPcmAudio()
{
	BT_DEBUG((">>> Not Implement BtAgwOpenPcmAudio()")); 
}

void BtAgwClosePcmAudio(void)
{
	BT_DEBUG((">>> Not Implement BtAgwClosePcmAudio()")); 
}

void BtAgwStartRing(void)
{
	BT_DEBUG((">>> Not Implement BtAgwStartRing()")); 
}

void BtAgwStopRing(void)
{
	BT_DEBUG((">>> Not Implement BtAgwStopRing()")); 
}

/****************************************************************************
** Hands-Free profile
****************************************************************************/

void BtHfgOpenPcmAudio(void)
{
	BT_DEBUG((">>> Not Implement BtHfgOpenPcmAudio()")); 
}

void BtHfgClosePcmAudio(void)
{
	BT_DEBUG((">>> Not Implement BtHfgClosePcmAudio()")); 
}

void BtHfgInCallSetup(void)
{
	BT_DEBUG((">>> Not Implement BtHfgInCallSetup()")); 
}

void BtHfgInCallAlert(char *callerId)
{
	BT_DEBUG((">>> Not Implement BtHfgInCallAlert() : callerId [%s]", callerId)); 

}

void BtInCallAlert(char *callerId) 	/* BT_COMMON_KIMSANGJIN_070507 noti_011076 */
{
//KF240_Kimyoungwun_080103
	BTRing * ring = NULL;

	if (callerId != NULL)
	{
		ring = (BTRing *) malloc(sizeof(BTRing)+strlen(callerId));
		if ( ring != NULL)
		{
		ring->inbandRing 	= FALSE;
		ring->callerId	 	= TRUE;
		ring->size		= strlen(callerId);
		strcpy((char *)ring->buffer, callerId);
		}
		BtSetCID(callerId,strlen(callerId)); /*noti_011091*/
	}
	else
	{
		ring = (BTRing *) malloc(sizeof(BTRing));
		if ( ring != NULL)
		{
		ring->inbandRing	= FALSE;
		ring->callerId	 	= FALSE;
		ring->size		= 0;
		strcpy((char *)ring->buffer, "");
		}
		BtSetCID(NULL,0); /*noti_011091_2*/
	}
	
	BT_DEBUG(("    >>> BtHfgInCallAlert (%s)", callerId ? callerId : "No Number"));
	free(ring);
}
/* end of BT_COMMON_KIMSANGJIN_070507 */


void BtHfgOutCallSetup(void)
{
	BT_DEBUG((">>> Not Implement BtHfgOutCallSetup()")); 
}

void BtHfgOutCallAlert(void)
{
	BT_DEBUG((">>> Not Implement BtHfgOutCallAlert()")); 
}

void BtHfgCallAccept(void)
{
	BT_DEBUG((">>> Not Implement BtHfgCallAccept()")); 
}

void BtHfgCallReject(void)
{
	BT_DEBUG((">>> Not Implement BtHfgCallReject()")); 
}

void BtHfgCallEnd(void)
{
	BT_DEBUG((">>> Not Implement BtHfgCallEnd()")); 
}

/* BT_COMMON_KIMSANGJIN_070620 noti_011148*/
Boolean IsBtCallPending = FALSE;
void BtSetCallWait(Boolean flag)
{
       IsBtCallPending =flag;
       if(IsBtCallPending == TRUE)
       {
	      afshSetWaitToProcIncomingCall(TRUE); 
        }
	 else
	 {
		 afshSetWaitToProcIncomingCall(FALSE); 
	 }
}
void BtFreeCallWait(void)
{
       BT_DEBUG(("BtFreeCallWait :IsBtCallPending:%s ",IsBtCallPending?"TRUE":"FALSE"));
	if(IsBtCallPending == TRUE)
	{
		afshSetWaitToProcIncomingCall(FALSE); 
	}
	IsBtCallPending = FALSE;
}
/* end of BT_COMMON_KIMSANGJIN_070620 */


/****************************************************************************
** Hands-Free 1.5		// $suhui HFP1.5
****************************************************************************/
/*kp230 20071107 baeheejung - HFP15 AT+CIND*/
static Int8 SignalStrengthLevel = 0;
static Int8 RoamingStatus = 0;
static Int8 BatteryLevel = 0;
static LGBX_AG_CALL_HELD_TYPE CallHeldStatus = LGBX_AG_NO_CALL_HELD;
	
//** Description 	Signal Strength ���� 
void BtHfgSetSignalStrength(Int8 Level)
{
	if (SignalStrengthLevel != Level)
	{
		if(BtFlag_IsConnected(BT_PROFILE_HANDSFREE) == TRUE)
		{
			BT_DEBUG(("[MMI]BtHfgSetSignalStrength : Level %d", Level));	
			LGBX_AG_SetSignalStrength(Level);
		}
		SignalStrengthLevel = Level;
	}
}

//** Description 	Roaming Status ���� 
void BtHfgSetRoamingStatus(Int8 Level)
{
	if (RoamingStatus != Level)
	{
		if(BtFlag_IsConnected(BT_PROFILE_HANDSFREE) == TRUE)
		{
			BT_DEBUG(("[MMI]BtHfgSetRoamingStatus : Level %d", Level));
			LGBX_AG_SetRoamingStatus(Level);
		}
		RoamingStatus = Level;
	}
}

//** Description 	Battery Level ���� 
void BtHfgSetBatteryLevel(Int8 Level)
{
	if (BatteryLevel != Level)
	{
		if(BtFlag_IsConnected(BT_PROFILE_HANDSFREE) == TRUE)
		{
			BT_DEBUG(("[MMI]BtHfgSetBatteryLevel : Level %d", Level));
			LGBX_AG_SetBatteryLevel(Level);
		}
		BatteryLevel = Level;
	}
}

//** Description 	Callheld Status ���� 
void BtHfgSetCallHeldStatus(LGBX_AG_CALL_HELD_TYPE value)
{
    if(CallHeldStatus != value)  // $suhui
    {
        if(BtFlag_IsConnected(BT_PROFILE_HANDSFREE) == TRUE)
        {
		BT_DEBUG(("[MMI]BtHfgSetCallHeldStatus : Value %d", value));
        	LGBX_AG_SetCallHeldStatus(value);
        }
        CallHeldStatus = value;
    }
}

/*hfp15 20071001 baeheejung*/
//** Description	Call Waiting ���� ���� 
void BtHfgSetCallWaiting(UINT8_T* Num, Int8 Len)
{
	UINT8_T Type = 0x81;
	BT_DEBUG(("[MMI]BtHfgSetCallWaiting : Num(%s) Lenth : %d", Num, Len));
	LGBX_AG_SetCallWaiting(Num, Len, Type);
}

//** Description 	Operator ���� ���� 
void BtHfgSetOperatorSelection(LGBX_AG_NETMODE_TYPE  Netmode, char *OpName)
{
	BT_DEBUG(("[MMI] Netmode : %s  OpName : %s", Netmode? "MANUAL":"AUTO", OpName));
	LGBX_AG_SetOperatorSelection(Netmode, (LGBX_IN STR_T)OpName);
}

//** Description 	Extended AG error result code ���� 
void BtHfgSetExtendedError(LGBX_AG_CME_ERR_TYPE ErrorCode)
{
	/*hfp15 20071001 baeheejung*/
	BT_DEBUG(("[MMI]BtHfgSetExtendedError, ErrorCode[%d]", ErrorCode));
	if(BTGetExtendedErrorFlag())
           LGBX_AG_SetExtendedError(ErrorCode);
}

//** Description 	Subscriber Number�� �����Ѵ�. 
//**				���� 2�� �̻��� Subscriber Number�� �����ϴ� ��� �ش� ������ŭ �� �Լ��� ȣ���Ͽ��� �Ѵ�. 
void BtHfgSetSubscriberNumber(UINT8_T* Num, Int8 Len, Int8 Type, 
									LGBX_AG_SERVICE_TYPE Service, Boolean FinalFlag)
{
	BT_DEBUG(("[MMI]BtHfgSetSubscriberNumber : Num[%s], Len[%d] Type[%d] FianlFlag[%d]", Num, Len, Type, FinalFlag));	// $suhui
	LGBX_AG_SetSubscriberNumber(Num, Len, Type, Service, FinalFlag); /*hfp15 20070916 baeheejung*/
}	

//** Description 	OK�� �����Ѵ�. 
//**			    AT Command�� ���� OK�� ���� �� �� �Լ��� ȣ���Ѵ�.
Boolean BtHfgSendOK(void)
{
	BT_DEBUG(("[MMI]BtHfgSendOK"));
	LGBX_AG_SendOK();
}

//** Description 	CIND�� �����Ѵ�. 
//**			    HF CONNECT�߿� CIND�� ���� �� �Լ��� ȣ���Ѵ�.
#if 1 /*hee_test*/
Boolean BtHfgSetCIND(void)
#else
Boolean BtHfgSetCIND(Int8 SignalLevel, Int8 RoamingStatus, Int8 BatteryLevel, LGBX_AG_CALL_HELD_TYPE value)
#endif
{
	BT_DEBUG(("[MMI]BtHfgSetCIND : SignalLevel[%d], RoamingStatus[%d], BatteryLevel[%d], callheld[%d]", SignalStrengthLevel, RoamingStatus, BatteryLevel, CallHeldStatus));
	LGBX_AG_SetCIND(SignalStrengthLevel, RoamingStatus, BatteryLevel, CallHeldStatus);
}

//** Description 	Current call list�� �����Ѵ�.
//**				���� 2�� �̻��� Call �� �����ϴ� ��� �ش� ������ŭ �� �Լ��� ȣ���Ͽ��� �Ѵ�. 
void BtHfgSetCurrentCallList(Int8 Idx, LGBX_AG_CL_DIR_TYPE Dir, LGBX_AG_CL_STATUS_TYPE Status,
								LGBX_AG_CL_MODE_TYPE Mode, LGBX_AG_CL_MPRTY_TYPE Mprty, UINT8_T* Num,
								Int8 Len, Int8 Type, Boolean FinalFlag)
{
	BT_DEBUG(("[MMI]BtHfgSetCurrentCallList : Idx[%d] Status[%d] Num[%s]", Idx, Status, Num));
	LGBX_AG_SetCurrentCallList(Idx, Dir, Status, Mode, Mprty, Num, Len, Type, FinalFlag); /*hfp15 20070916 baeheejung*/
}

/****************************************************************************
** OPP profile
****************************************************************************/

void BtOpsPutAuthReply(Boolean allow)
{
	BT_DEBUG(("API : BtOpsPutAuthReply : %s", allow ? "TRUE":"FALSE"));
	LGBX_OPS_PutAuthReply(allow);
}

void BtOpsPutMethodReply(Int8 * p_buf, Int32 size_buf, char* p_path)
{
	BT_DEBUG(("API : BtOpsPutMethodReply : [%s], %d, p_buf [%d]", p_path, size_buf, p_buf));
	LGBX_OPS_PutMethodReply(p_buf, size_buf, p_path);
}

/* GX_LEEJINBAEK_070227 */
void BtOpsGetAuthReply(Boolean allow)
{
	BT_DEBUG(("API : BtOpsGetAuthReply : %s", allow ? "TRUE":"FALSE"));
	LGBX_OPS_GetAuthReply(allow);
}

void BtOpsGetMethodReply(Int8 * p_obj, Int32 size_obj, char* p_path)
{
	BT_DEBUG(("API : BtOpsGetMethodReply : [%s], %d, p_obj [%d]", p_path, size_obj, p_obj));
	LGBX_OPS_GetMethodReply(p_obj, size_obj, p_path);
}
/* end of GX_LEEJINBAEK_070227 */

/****************************************************************************
** FTP profile
****************************************************************************/
void BtFtcRemoteGetDir(char *name)
{
	BT_DEBUG(("API : LGBX_FTC_RemoteGetDir"));
	LGBX_FTC_RemoteGetDir((LGBX_IN STR_T)name, p_bt_buf, (NUM_OF_GETDIR_BUF_LENGTH/4)*sizeof(int));
}

void BtFtcRemoteChDir(char *name)
{
	BT_DEBUG(("API : LGBX_FTC_RemoteChDir"));
	LGBX_FTC_RemoteChDir((LGBX_IN STR_T) name);
}

void BtFtcGetFile(char *name)
{
	char folderName[32] = {0,};

	Btfs_GetFolderNameToSave(folderName, name);
	LGBX_FTC_LocalChDir(folderName);

       BT_DEBUG(("API : LGBX_FTC_GetFile : folder [%s], file [%s]", folderName, name));
	LGBX_FTC_GetFile((LGBX_IN STR_T)name);
}

void BtFtcPutFile(char *name)
{
	BT_DEBUG(("API : LGBX_FTC_PutFile"));
	LGBX_FTC_PutFile((LGBX_IN STR_T)name);
}

void BtFtcSendCancel(void)
{
	BT_DEBUG(("API : LGBX_FTC_Cancel"));
	LGBX_FTC_Cancel();
}

void BtFtsSendAuthAccept(Boolean isAccepted)
{
	LGBX_FTS_RC_TYPE rcType;
	if(TRUE == isAccepted)
		rcType = LGBX_ALLOW_RES; 
	else
		rcType = LGBX_FORBID_RES;
	
	BT_DEBUG(("API : BtFtsSendAuthAccept : %s", isAccepted ? "TRUE":"FALSE"));

	LGBX_FTS_OprAuthReply(rcType);
}

void BtFtsSendCancel(void)
{
	BT_DEBUG(("API : LGBX_FTS_Cancel"));
	LGBX_FTS_Cancel();
}

void BtFtsDisconnectReq(void)
{
/* 20071001_Music_BGM_update (LEEJINBAEK) */
	BT_DEBUG(("\x1b[35m mmi_stackif.c> BtFtsDisconnectReq() : call BtDisableServer(LGBX_SVC_FTP) \x1b[0m"));
	BtDisableServer(LGBX_SVC_FTP);
}

/****************************************************************************
** BPP profile
****************************************************************************/
void BtBppPutObject(LGBX_DEVICEINFO_TYPE *dev, FileNameChar * fileFullPath, AfmfFileType  type, Int8 *p_obj, Int32 fileSize)
{
	UINT8_T lgbxOppObjType;

#if defined(LGE_FS_SUPPORT_LONG_FILE_NAME)
	char p_name[AFBT_FILENAME_SIZE+1];

	memset(p_name, 0, sizeof(char)*(AFBT_FILENAME_SIZE +1));

	ConvertUCS2toUTF8(fileFullPath,STRLEN(fileFullPath),p_name);
#else
	FileNameChar * p_name = fileFullPath;
#endif

	lgbxOppObjType = afbtChangeFileTypeToLgbxObjType(type);
	BT_DEBUG(("API : BtBppPutObject"));

/* BT_COMMON_KIMSANGJIN_080111 noti_011257 */
	if(lgbxOppObjType == LGBX_OBJ_VCARD)
	{
		sprintf(p_name, "vcard.vcf");
	}
	else if(lgbxOppObjType == LGBX_OBJ_VCARD)
	{
		sprintf(p_name, "vcalendar.vcal");
	}
	else if (lgbxOppObjType == LGBX_OBJ_VNOTE)
	{
	       sprintf(p_name, "vnote.vnt");
	}
	else
	{
              BT_DEBUG(("Unknow BtBppPutObject type of LGBX OBJ"));
	}
/* end of BT_COMMON_KIMSANGJIN_080111 */
	
	
	BT_DEBUG(("H16> Send via BPP dev Name : %s  1.fileName : %s, 2. fileSize : %ld, 3. fileType : %d", 
	afbtGetBDAddrString(dev->BdAddr), p_name, fileSize, lgbxOppObjType));

	LGBX_BPP_PrintObject(dev->BdAddr, 
						p_name,
						lgbxOppObjType,
						p_obj,
						fileSize);
}

void BtBppJobObjectPush(LGBX_DEVICEINFO_TYPE *dev,  Int8 *p_obj, Int16 color, Int16 fontsize, Int16 style)
{
	LGBX_BPP_ATR_TYPE  test ={0,};

	BT_DEBUG(("API : BtBppPutDocument"));
	
	BT_DEBUG(("		Send via BPP dev Name : %s  1.color : %d, 2. fontsize : %dd, 3. style : %d", 
	afbtGetBDAddrString(dev->BdAddr), color, fontsize, style));

	test.color	= color;
	test.fontsize = fontsize;
	test.style =style;
#if defined (LGE_SIG_BLUETOOTH)	 /*noti_011108*/
	LGBX_Bpp_PrintXHTML(dev->BdAddr,p_obj,&test);   /*noti_011105*/
#else
	PARAMETER_NOT_USED(p_obj);
	PARAMETER_NOT_USED(test);
#endif /*LGE_SIG_BLUETOOTH*/
}

void BtBppSendCancel(void)
{
	BT_DEBUG(("API : LGBX_BPP_Cancel"));
	LGBX_BPP_Cancel();
}

/***************************************************************************
* A2DP & AVRCP(Audio & Video Remote Control Profile)
***************************************************************************/
#if defined(LGE_LEMANS_BLUETOOTH)
Boolean BtA2dpIsStreaming(void)
{
#if 1 /* BT_COMMON_TIBURONA_080205 */
	if( (BtFlag_IsEnabled()==TRUE) && (BtFlag_IsConnected(BT_PROFILE_A2DP)==TRUE)
		&& (BtGetA2dpStreamRequest()==TRUE) )
#else
	if((BtFlag_IsEnabled()==TRUE) && (BtFlag_IsConnected(BT_PROFILE_A2DP)==TRUE)
		&& (LGBX_A2SRC_IsStreaming()==TRUE) // (LGBX_AV_STREAMING) || (LGBX_AV_PAUSED)
	)
#endif
	{
		BT_DEBUG(("BtA2dpIsStreaming()=TRUE"));
		return TRUE;
	}
	else
	{
#if 0	
		BT_DEBUG(("BtA2dpIsStreaming() : BT ON/OFF=%s, BtFlag_IsConnected(BT_PROFILE_A2DP)=%s, LGBX_A2SRC_IsStreaming()=%s",
				BtFlag_IsEnabled()? "True" : "False", BtFlag_IsConnected(BT_PROFILE_A2DP)? "True" : "False",
				LGBX_A2SRC_IsStreaming()? "True":"False"));
#endif
		return FALSE;
	}
}

static void BtA2dpStartStreaming(void)
{
	if(BtGetA2dpStreamRequest() == FALSE)	// BT_A2DP LEEJINBAEK 20071214 : AVRCP audio path control
	{
		BtSetA2dpStreamRequest(TRUE);
		LGBX_A2SRC_StartStreaming();
	}
	else
		BT_DEBUG(("\x1b[31m [MMI] BtA2dpStartStreaming() BtGetA2dpStreamRequest()=TRUE (Is Already Streaming)\x1b[0m"));
}

static void BtA2dpPauseStreaming(void)
{
	if(BtGetA2dpStreamRequest()==TRUE)		// BT_A2DP LEEJINBAEK 20071214 : AVRCP audio path control
	{
		BtSetA2dpStreamRequest(FALSE);	
		LGBX_A2SRC_PauseStreaming();
	}
	else
		BT_DEBUG(("\x1b[31m [MMI] BtA2dpPauseStreaming() BtGetA2dpStreamRequest()=FALSE (Not Streaming)\x1b[0m"));
}

static void BtA2dpStopStreaming(void)
{
	BtSetA2dpStreamRequest(FALSE);			// BT_A2DP LEEJINBAEK 20071214 : AVRCP audio path control
	LGBX_A2SRC_StopStreaming();			/* BT_LEEJINBAEK 20071029 : listen via bluetooth in MP3 player */	
}

Boolean mp3StopForEndOfSong = FALSE;
/* Tiburona_071025 For Bluetooth A2DP */
void BtA2dpPlay(void) 			
{
	// BT_A2DP LEEJINBAEK 20071214 : AVRCP audio path control
	if(BtFlag_IsConnected(BT_PROFILE_A2DP)==TRUE)
	{
		BT_DEBUG(("\x1b[35m[MMI] BtA2dpPlay() Music Play \x1b[0m"));	
		if (mp3StopForEndOfSong)
		{
			BT_DEBUG(("BtA2dpPlay::: mp3StopForEndOfSong = TRUE;"));
			mp3StopForEndOfSong = FALSE;
		}
		else
		{
			BT_DEBUG(("BtA2dpPlay::: mp3StopForEndOfSong = FALSE;"));
			BtA2dpStartStreaming();
		}
	}
	else
	{
		BT_DEBUG(("\x1b[31m [MMI] BtA2dpPlay() A2DP device is not connected. \x1b[0m"));
	}
}

void BtA2dpStop(void)
{
	if(BtFlag_IsConnected(BT_PROFILE_A2DP)==TRUE)
	{
		BT_DEBUG(("\x1b[35m [MMI] BtA2dpStop() Music Stop \x1b[0m"));
		BtA2dpStopStreaming();
		mp3StopForEndOfSong = FALSE;
	}
	else
	{
		BT_DEBUG(("\x1b[31m [MMI] BtA2dpStop() A2DP device is not connected. \x1b[0m"));
	}	
}

void BtA2dpPause(void)
{
	if(BtFlag_IsConnected(BT_PROFILE_A2DP)==TRUE)
	{
		BT_DEBUG(("\x1b[35m [MMI] BtA2dpPause() Music Pause \x1b[0m"));
		if (mp3StopForEndOfSong == TRUE)
		{
			//mp3StopForEndOfSong = FALSE;
		}
		else
		{		
			BtA2dpPauseStreaming();
		}
	}
	else
	{
		BT_DEBUG(("\x1b[31m [MMI] BtA2dpPause() A2DP device is not connected. \x1b[0m"));
	}	
}

void BtA2dpResume(void)
{
	if(BtFlag_IsConnected(BT_PROFILE_A2DP)==TRUE)
	{
		BT_DEBUG(("\x1b[35m [MMI] BtA2dpResume() Music Resume \x1b[0m"));
		BtA2dpStartStreaming();
	}
	else
	{
		BT_DEBUG(("\x1b[31m [MMI] BtA2dpResume() A2DP device is not connected. \x1b[0m"));
	}	
}

void BtA2dpForwardRewind(void)
{
	if(BtFlag_IsConnected(BT_PROFILE_A2DP)==TRUE)
	{
		BT_DEBUG(("\x1b[35m [MMI] BtA2dpForwardRewind() Music FF/REW \x1b[0m"));
		LGBX_AV_PcmNotifyEndOfData();
	}
	else
	{
		BT_DEBUG(("\x1b[31m [MMI] BtA2dpForwardRewind() A2DP device is not connected. \x1b[0m"));
	}		
}

void BtA2dpSetMp3PathAsBluetooth(BOOLEAN path)
{
	if(BtFlag_IsConnected(BT_PROFILE_A2DP)==TRUE)
	{	
		if(path==TRUE) /* bluetooth stereo headset */
		{
			BT_DEBUG(("\x1b[35m [MMI] BtA2dpSetMp3PathAsBluetooth() MP3 path is stereo headset. \x1b[0m"));							
			LGBX_AV_PcmNotifyAudioFormat(BtA2dpGetSamplingRate(), ((BtA2dpGetNumAuioChannel() == 2) ? LGBX_AV_CHANNEL_STEREO : LGBX_AV_CHANNEL_MONO));
			BtA2dpStartStreaming();
		}
		else	 /* speaker or ear-jack */
		{
			BT_DEBUG(("\x1b[35m [MMI] BtA2dpSetMp3PathAsBluetooth() MP3 path is speaker or ear-jack. \x1b[0m"));
			BtA2dpPauseStreaming();
		}
	}
	else
	{
		BT_DEBUG(("\x1b[31m [MMI] BtA2dpSetMp3PathAsBluetooth() A2DP is not connected. \x1b[0m"));
	}
}

void BtAvrcpSendEvent(LGBX_AVRCP_PASS_THROUGH_CMD_TYPE cmd)	/* LEMANS_Tiburona_070105 : add the AVRCP interface */
{
	switch(cmd)
	{
		case LGBX_AVRCP_RMC_PLAY:
		{
			BT_DEBUG(("BtAvrcpSendEvent() LGBX_AVRCP_RMC_PLAY"));
			//BT KIMJAEHUN 20080117 AVRCP control in BGM play [START]
			if(afshIsTopHandler(afshReadHandlerIdleId()) && (afshGetKeyCode() != KEY_FLIP_CLOSED) && afmusicGetBGMstate() == FALSE)
			{
				afbtEventSignalSend(AG_GO_MP3_EVENT);
				BT_DEBUG(("=====>afbtEventSignalSend(AG_GO_MP3_EVENT)"));	
			}
			else if((MusicFlag_IsPlayerOn()||MyStuffFlag_IsPlayerOn()) && afmusicGetBGMstate() == FALSE)
			{
				afbtEventSignalSend(AG_OK_EVENT);
				BT_DEBUG(("=====>afbtEventSignalSend(AG_OK_EVENT)"));			
			}			
			else if(afmusicGetBGMstate())
			{
				 afmusicSendBGMActionReq(0, MP3_BGM_ACTION_RESUME, 0,	afshFindBgmHandler());
			}
		}
			break;
		case LGBX_AVRCP_RMC_PAUSE:
		{
			BT_DEBUG(("BtAvrcpSendEvent() LGBX_AVRCP_RMC_PAUSE"));
			/*start of KF300_KIMJAEHUN_071221 : block unnecessary event*/
			if(afshIsTopHandler(afshReadHandlerIdleId()) && (afshGetKeyCode() != KEY_FLIP_CLOSED) && afmusicGetBGMstate() == FALSE)
			{
				afbtEventSignalSend(AG_GO_MP3_EVENT);
				BT_DEBUG(("=====>afbtEventSignalSend(AG_GO_MP3_EVENT)"));	
			}
			else if((MusicFlag_IsPlayerOn()||MyStuffFlag_IsPlayerOn()) && afmusicGetBGMstate() == FALSE)
			{
				afbtEventSignalSend(AG_OK_EVENT);
				BT_DEBUG(("=====>afbtEventSignalSend(AG_OK_EVENT)"));
			}
			else if(afmusicGetBGMstate())
			{
				 afmusicSendBGMActionReq(0, MP3_BGM_ACTION_PAUSE, 0,	afshFindBgmHandler());
			}			
		}
			break;
		case LGBX_AVRCP_RMC_FORWARD:
		{
			BT_DEBUG(("BtAvrcpSendEvent() LGBX_AVRCP_RMC_FORWARD"));
			 if((MusicFlag_IsPlayerOn()||MyStuffFlag_IsPlayerOn()) && afmusicGetBGMstate() == FALSE)
			{
				afbtEventSignalSend(AG_NEXT_SONG_EVENT);
				BT_DEBUG(("=====>afbtEventSignalSend(AG_NEXT_SONG_EVENT)"));
			}
			 else if(afmusicGetBGMstate())
			 	{
				 afmusicSendBGMActionReq(0, MP3_BGM_ACTION_FF, 0,	afshFindBgmHandler());
			 	}
		}
			break;
		case LGBX_AVRCP_RMC_BACKWARD:
		{
			BT_DEBUG(("BtAvrcpSendEvent() LGBX_AVRCP_RMC_BACKWARD"));
			 if((MusicFlag_IsPlayerOn()||MyStuffFlag_IsPlayerOn()) && afmusicGetBGMstate() == FALSE)
			{
				afbtEventSignalSend(AG_BEFORE_SONG_EVENT);
				BT_DEBUG(("=====>afbtEventSignalSend(AG_BEFORE_SONG_EVENT)"));
			}
			 else if(afmusicGetBGMstate())
			{
				 afmusicSendBGMActionReq(0, MP3_BGM_ACTION_REW, 0,	afshFindBgmHandler());
			}
		}
			break;
		case LGBX_AVRCP_RMC_STOP:
		{
			BT_DEBUG(("BtAvrcpSendEvent() LGBX_AVRCP_RMC_STOP"));
			if((MusicFlag_IsPlayerOn()||MyStuffFlag_IsPlayerOn()) && afmusicGetBGMstate() == FALSE)
			{
				afbtEventSignalSend(AG_BACK_EVENT);
				BT_DEBUG(("=====>afbtEventSignalSend(AG_BACK_EVENT)"));
			}
			 else if(afmusicGetBGMstate())
			{
				 afmusicSendBGMActionReq(0, MP3_BGM_ACTION_STOP, 0,	afshFindBgmHandler());
			}			
		}	
			break;
			//BT KIMJAEHUN 20080117 AVRCP control in BGM play [END]			
		default:
		{
			BT_DEBUG(("BtAvrcpSendEvent() unknown Event(%d)",cmd));			
		}
			break;
	}
}
#endif /* LGE_LEMANS_BLUETOOTH */

/****************************************************************************
** Message Debugging
****************************************************************************/

typedef struct MsgNameTableTag
{
	BTMMIMSG msgid;
	char *   msgname;
} 
MsgNameTable;
		
		
const MsgNameTable gBtMsgTable[] =
{
	{BT_TASK_LAUNCH,              "BT_TASK_LAUNCH"},             
	{BT_TASK_SHUTDOWN,            "BT_TASK_SHUTDOWN"},    
		
	{BT_APP_INITIALIZE,           "BT_APP_INITIALIZE"},          
	{BT_APP_SET_LOCALNAME,        "BT_APP_SET_LOCALNAME"},       
	{BT_APP_SET_VISIBILITY,       "BT_APP_SET_VISIBILITY"},      
	{BT_APP_ENTER_TEST_MODE,      "BT_APP_ENTER_TEST_MODE"},     
	{BT_APP_ENTER_BYPASS_MODE,    "BT_APP_ENTER_BYPASS_MODE"},   
	{BT_APP_READ_RSSI,            "BT_APP_READ_RSSI"},        

	{BT_SDP_START_INQUIRY,        "BT_SDP_START_INQUIRY"},       
	{BT_SDP_STOP_INQUIRY,         "BT_SDP_STOP_INQUIRY"},        
	{BT_SDP_BOND_DEVICE,          "BT_SDP_BOND_DEVICE"},       
	{BT_SDP_DEBOND_DEVICE,        "BT_SDP_DEBOND_DEVICE"},        
	{BT_SDP_SEND_PASSKEY,         "BT_SDP_SEND_PASSKEY"},        
	{BT_SDP_AUTHORISE,            "BT_SDP_AUTHORISE"},  
	{BT_SDP_READ_REMOTE_NAME,     "BT_SDP_READ_REMOTE_NAME"},    
	{BT_SDP_READ_SERVICE_LIST,    "BT_SDP_READ_SERVICE_LIST"},
	{BT_SDP_QUERY_SOME_SVC,    "BT_SDP_QUERY_SOME_SVC"}, /* JIN100_BT_BPP part2 */
	{BT_SDP_QUERY_STOP_REQ,    "BT_SDP_QUERY_STOP_REQ"},

	/* BT_MMI_CHOOBYOUNGSOO */
	{BT_GAP_CONNECT_CFM,    "BT_GAP_CONNECT_CFM"},
	{BT_GAP_DISCONNECT_CFM,    "BT_GAP_DISCONNECT_CFM"},

	{BT_AGW_ACTIVATE,             "BT_AGW_ACTIVATE"},            
	{BT_AGW_DEACTIVATE,           "BT_AGW_DEACTIVATE"},          
	{BT_AGW_ATTATCH_HEADSET,      "BT_AGW_ATTATCH_HEADSET"},     
	{BT_AGW_DETATCH_HEADSET,      "BT_AGW_DETATCH_HEADSET"},     
	{BT_AGW_AUDIO_REQ,            "BT_AGW_AUDIO_REQ"},           
	{BT_AGW_ALERT_RING,           "BT_AGW_ALERT_RING"},          
	{BT_AGW_INBAND_RING,          "BT_AGW_INBAND_RING"},         
	{BT_AGW_STOP_RING,            "BT_AGW_STOP_RING"},           
	{BT_AGW_ON_HOOK,              "BT_AGW_ON_HOOK"},              
	{BT_AGW_SET_PACKET_TYPE,      "BT_AGW_SET_PACKET_TYPE"},     
	{BT_AGW_SPK_CHANGE_REQ,       "BT_AGW_SPK_CHANGE_REQ"},      
	{BT_AGW_MIC_CHANGE_REQ,       "BT_AGW_MIC_CHANGE_REQ"},      
	{BT_AGW_AT_CMD_SEND_REQ,       "BT_AGW_AT_CMD_SEND_REQ"},   

	{BT_HFG_ACTIVATE,             "BT_HFG_ACTIVATE"},
	{BT_HFG_DEACTIVATE,           "BT_HFG_DEACTIVATE"},
	{BT_HFG_CONNECT,              "BT_HFG_CONNECT"},
	{BT_HFG_DISCONNECT,           "BT_HFG_DISCONNECT"},
		
	{BT_HFG_SERVICE_STATUS,       "BT_HFG_SERVICE_STATUS"},
	{BT_HFG_CALL_SETUP_STATUS,    "BT_HFG_CALL_SETUP_STATUS"},
	{BT_HFG_CALL_STATUS,          "BT_HFG_CALL_STATUS"},
	{BT_HFG_CALL_HOLD_RES,  "BT_HFG_CALL_HOLD_RES"},
		

       {BT_HFG_RING_REQ,      "BT_HFG_RING_REQ"},
       {BT_HFG_AUDIO_REQ, 	  "BT_HFG_AUDIO_REQ"},
	{BT_HFG_DIAL_RES,             "BT_HFG_DIAL_RES"},
       {BT_HFG_DIAL_VOICE_RES,    " BT_HFG_DIAL_VOICE_RES"},    
	{BT_HFG_AUDIO_TYPE_REQ,       "BT_HFG_AUDIO_TYPE_REQ"},
	{BT_HFG_SPK_CHANGE_REQ,       "BT_HFG_SPK_CHANGE_REQ"},
	{BT_HFG_MIC_CHANGE_REQ,       "BT_HFG_MIC_CHANGE_REQ"},
	{BT_HFG_AT_CMD_SEND_REQ,      "BT_HFG_AT_CMD_SEND_REQ"},
		
	{BT_SPP_ACTIVATE,             "BT_SPP_ACTIVATE"},            
	{BT_SPP_DEACTIVATE,           "BT_SPP_DEACTIVATE"},          
	{BT_SPP_CONNECT,              "BT_SPP_CONNECT"},             
	{BT_SPP_DISCONNECT,           "BT_SPP_DISCONNECT"},          
	{BT_SPP_TX_PUMP_REQ,          "BT_SPP_TX_PUMP_REQ"},         
	{BT_SPP_RX_PUMP_REQ,          "BT_SPP_RX_PUMP_REQ"},    

	{BT_DUN_ACTIVATE,             "BT_DUN_ACTIVATE"},            
	{BT_DUN_DEACTIVATE,           "BT_DUN_DEACTIVATE"},          
	{BT_DUN_DISCONNECT,           "BT_DUN_DISCONNECT"},          
	{BT_DUN_TX_PUMP_REQ,          "BT_DUN_TX_PUMP_REQ"},         
	{BT_DUN_RX_PUMP_REQ,          "BT_DUN_RX_PUMP_REQ"},  

	{BT_OPS_ACTIVATE,             "BT_OPS_ACTIVATE"},		
	{BT_OPS_DEACTIVATE,           "BT_OPS_DEACTIVATE"}, 
	{BT_OPS_DISCONNECT,           "BT_OPS_DISCONNECT"},
	{BT_OPS_GET_ACK,              "BT_OPS_GET_ACK"},
	{BT_OPS_PUT_ACK,              "BT_OPS_PUT_ACK"},

	{BT_OPC_START_SEARCH,         "BT_OPC_START_SEARCH"},
	{BT_OPC_STOP_SEARCH,          "BT_OPC_STOP_SEARCH"},
	{BT_OPC_GET_REQ,              "BT_OPC_GET_REQ"},
	{BT_OPC_PUT_REQ,              "BT_OPC_PUT_REQ"},
	{BT_OPC_XCHG_REQ,             "BT_OPC_XCHG_REQ"},
	{BT_OPC_ABORT,                "BT_OPC_ABORT"},


	{BT_FTS_SET_ROOT_DIR,         "BT_FTS_SET_ROOT_DIR"},         
	{BT_FTS_ACTIVATE,             "BT_FTS_ACTIVATE"},             
	{BT_FTS_DEACTIVATE,           "BT_FTS_DEACTIVATE"},           
	{BT_FTS_DISCONNECT,           "BT_FTS_DISCONNECT"},           
	{BT_FTS_AUTHENTICATE,         "BT_FTS_AUTHENTICATE"},         
	                                                         
	{BT_FTC_SET_ROOT_DIR,         "BT_FTC_SET_ROOT_DIR"},         
	{BT_FTC_START_SEARCH,         "BT_FTC_START_SEARCH"},         
	{BT_FTC_STOP_SEARCH,          "BT_FTC_STOP_SEARCH"},          
	{BT_FTC_CONNECT,              "BT_FTC_CONNECT"},              
	{BT_FTC_DISCONNECT,           "BT_FTC_DISCONNECT"},           
	{BT_FTC_AUTHENTICATE,         "BT_FTC_AUTHENTICATE"},         
	{BT_FTC_LOCAL_GETDIR,         "BT_FTC_LOCAL_GETDIR"},         
	{BT_FTC_LOCAL_CHDIR,          "BT_FTC_LOCAL_CHDIR"},          
	{BT_FTC_LOCAL_MKDIR,          "BT_FTC_LOCAL_MKDIR"},          
	{BT_FTC_LOCAL_RMDIR,          "BT_FTC_LOCAL_RMDIR"},          
	{BT_FTC_LOCAL_DEL,            "BT_FTC_LOCAL_DEL"},            
	{BT_FTC_REMOTE_GETDIR,        "BT_FTC_REMOTE_GETDIR"},        
	{BT_FTC_REMOTE_CHDIR,         "BT_FTC_REMOTE_CHDIR"},         
	{BT_FTC_REMOTE_MKDIR,         "BT_FTC_REMOTE_MKDIR"},         
	{BT_FTC_REMOTE_RMDIR,         "BT_FTC_REMOTE_RMDIR"},         
	{BT_FTC_REMOTE_DEL,           "BT_FTC_REMOTE_DEL"},           
	{BT_FTC_PUTFILE,              "BT_FTC_PUTFILE"},              
	{BT_FTC_GETFILE,              "BT_FTC_GETFILE"},              
	{BT_FTC_ABORT,                "BT_FTC_ABORT"},  

	{BT_SYNC_ACTIVATE,            "BT_SYNC_ACTIVATE"},
	{BT_SYNC_DEACTIVATE,          "BT_SYNC_DEACTIVATE"},
	{BT_SYNC_DISCONNECT,          "BT_SYNC_DISCONNECT"},
	{BT_SYNC_AUTHENTICATE,        "BT_SYNC_AUTHENTICATE"},
		
	{BT_TASK_LAUNCH_COMPLETE,     "BT_TASK_LAUNCH_COMPLETE"},    
	{BT_TASK_LAUNCH_FAIL,         "BT_TASK_LAUNCH_FAIL"},        
	{BT_TASK_SHUTDOWN_COMPLETE,   "BT_TASK_SHUTDOWN_COMPLETE"},  
		
	{BT_APP_INIT_CFM,             "BT_APP_INIT_CFM"},            
	{BT_APP_SET_LOCAL_NAME_CFM,   "BT_APP_SET_LOCAL_NAME_CFM"},  
	{BT_APP_VISIBILITY_CFM,       "BT_APP_VISIBILITY_CFM"},      
	{BT_APP_TEST_MODE_CFM,        "BT_APP_TEST_MODE_CFM"},       
	{BT_APP_BYPASS_MODE_CFM,      "BT_APP_BYPASS_MODE_CFM"},     
	{BT_APP_READ_RSSI_CFM,        "BT_APP_READ_RSSI_CFM"},  
		
	{BT_SDP_READ_REMOTE_NAME_CFM, "BT_SDP_READ_REMOTE_NAME_CFM"},    
	{BT_SDP_DISCOVERY_CFM,        "BT_SDP_DISCOVERY_CFM"}, 
	{BT_SDP_CANCEL_DISCOVERY_CFM, "BT_SDP_CANCEL_DISCOVERY_CFM"},
	{BT_SDP_DISCOVERY_RESULT_IND, "BT_SDP_DISCOVERY_RESULT_IND"},     
	{BT_SDP_INPUT_PASSKEY_IND,    "BT_SDP_INPUT_PASSKEY_IND"},        
	{BT_SDP_AUTHORISE_IND,        "BT_SDP_AUTHORISE_IND"},            
		      
	{BT_SDP_BOND_CFM,             "BT_SDP_BOND_CFM"},    
	{BT_SDP_BOND_IND,             "BT_SDP_BOND_IND"},
	{BT_SDP_DEBOND_CFM,           "BT_SDP_DEBOND_CFM"},
	{BT_SDP_DB_ADD_IND,           "BT_SDP_DB_ADD_IND"},          
	{BT_SDP_DB_UPDATE_IND,        "BT_SDP_DB_UPDATE_IND"},       
	{BT_SDP_DB_ERASE_IND,         "BT_SDP_DB_ERASE_IND"},        
	{BT_SDP_DB_NO_STORAGE_IND,    "BT_SDP_DB_NO_STORAGE_IND"},   
	{BT_SDP_READ_SERVICE_LIST_CFM,"BT_SDP_READ_SERVICE_LIST_CFM"},
	{BT_SDP_QUERY_SOME_SVC_CFM,"BT_SDP_QUERY_SOME_SVC_CFM"},
		
	{BT_AGW_CONNECT_IND,          "BT_AGW_CONNECT_IND"},              
	{BT_AGW_DISCONNECT_IND,       "BT_AGW_DISCONNECT_IND"},           
	{BT_AGW_ANSWER_IND,           "BT_AGW_ANSWER_IND"},          
	{BT_AGW_AUDIO_IND,            "BT_AGW_AUDIO_IND"},                
	{BT_AGW_RING_START_IND,       "BT_AGW_RING_START_IND"},      
	{BT_AGW_RING_STOP_IND,        "BT_AGW_RING_STOP_IND"},       
	{BT_AGW_ON_HOOK_IND,          "BT_AGW_ON_HOOK_IND"},         
	{BT_AGW_SPK_CHANGE_IND,       "BT_AGW_SPK_CHANGE_IND"},      
	{BT_AGW_MIC_CHANGE_IND,       "BT_AGW_MIC_CHANGE_IND"},      
	{BT_AGW_AT_CMD_MSG_IND,       "BT_AGW_AT_CMD_MSG_IND"},  
	{BT_AGW_DEACTIVATE_CFM,       "BT_AGW_DEACTIVATE_CFM"}, 
	{BT_AGW_ACTIVATE_CFM,         "BT_AGW_ACTIVATE_CFM"}, 

	{BT_HFG_CONNECT_IND,          "BT_HFG_CONNECT_IND"},    
	{BT_HFG_DISCONNECT_IND,       "BT_HFG_DISCONNECT_IND"}, 
	{BT_HFG_ANSWER_IND,           "BT_HFG_ANSWER_IND"},     
	{BT_HFG_REJECT_IND,           "BT_HFG_REJECT_IND"},     
	{BT_HFG_CALL_HOLD_IND,        "BT_HFG_CALL_HOLD_IND"},
	{BT_HFG_AUDIO_STATUS_IND,     "BT_HFG_AUDIO_STATUS_IND"},      
	{BT_HFG_RING_STATUS_IND,      "BT_HFG_RING_STATUS_IND"}, 
	{BT_HFG_SPK_CHANGE_IND,       "BT_HFG_SPK_CHANGE_IND"}, 
	{BT_HFG_MIC_CHANGE_IND,       "BT_HFG_MIC_CHANGE_IND"}, 
	{BT_HFG_AT_CMD_MSG_IND,       "BT_HFG_AT_CMD_MSG_IND"}, 
	{BT_HFG_DIAL_STR_IND,         "BT_HFG_DIAL_STR_IND"},   
	{BT_HFG_DIAL_NUM_IND,         "BT_HFG_DIAL_NUM_IND"},   
	{BT_HFG_DIAL_LAST_IND,        "BT_HFG_DIAL_LAST_IND"},     
	{BT_HFG_DTMF_IND,             "BT_HFG_DTMF_IND"},     
	{BT_HFG_DIAL_VOICE_IND,       "BT_HFG_DIAL_VOICE_IND"},
	{BT_HFG_DEACTIVATE_CFM,       "BT_HFG_DEACTIVATE_CFM"}, 
	{BT_HFG_ACTIVATE_CFM,         "BT_HFG_ACTIVATE_CFM"}, 

	{BT_SPP_CONNECT_IND,          "BT_SPP_CONNECT_IND"},           
	{BT_SPP_DISCONNECT_IND,       "BT_SPP_DISCONNECT_IND"},           
	{BT_SPP_CONTORL_IND,          "BT_SPP_CONTORL_IND"},         
	{BT_SPP_PORTNEG_IND,          "BT_SPP_PORTNEG_IND"},         
	{BT_SPP_SERVICE_NAME_IND,     "BT_SPP_SERVICE_NAME_IND"},    
	{BT_SPP_DATA_IND,             "BT_SPP_DATA_IND"},                 
	{BT_SPP_TX_PUMP_CFM,          "BT_SPP_TX_PUMP_CFM"},              
	{BT_SPP_RX_PUMP_CFM,          "BT_SPP_RX_PUMP_CFM"},              
	{BT_SPP_DEACTIVATE_CFM,       "BT_SPP_DEACTIVATE_CFM"}, 
	{BT_SPP_ACTIVATE_CFM,         "BT_SPP_ACTIVATE_CFM"}, 
		
	{BT_DUN_CONNECT_IND,          "BT_DUN_CONNECT_IND"},           
	{BT_DUN_DISCONNECT_IND,       "BT_DUN_DISCONNECT_IND"},      
	{BT_DUN_CONTORL_IND,          "BT_DUN_CONTORL_IND"},         
	{BT_DUN_PORTNEG_IND,          "BT_DUN_PORTNEG_IND"},         
	{BT_DUN_DATA_IND,             "BT_DUN_DATA_IND"},                 
	{BT_DUN_TX_PUMP_CFM,          "BT_DUN_TX_PUMP_CFM"},              
	{BT_DUN_RX_PUMP_CFM,          "BT_DUN_RX_PUMP_CFM"},              
	{BT_DUN_DEACTIVATE_CFM,       "BT_DUN_DEACTIVATE_CFM"},  
	{BT_DUN_ACTIVATE_CFM,         "BT_DUN_ACTIVATE_CFM"}, 

	{BT_OPS_CONNECT_IND,          "BT_OPS_CONNECT_IND"},
	{BT_OPS_DISCONNECT_IND,       "BT_OPS_DISCONNECT_IND"},
	{BT_OPS_DEACTIVATE_CFM,       "BT_OPS_DEACTIVATE_CFM"},
	{BT_OPS_ACTIVATE_CFM,         "BT_OPS_ACTIVATE_CFM"},
	{BT_OPS_GET_IND,              "BT_OPS_GET_IND"},
	{BT_OPS_GET_CFM,              "BT_OPS_GET_CFM"},
	{BT_OPS_PUT_IND,              "BT_OPS_PUT_IND"},
	{BT_OPS_OBJ_IND,              "BT_OPS_OBJ_IND"},
	{BT_OPS_ACTION_IND,           "BT_OPS_ACTION_IND"},
	{BT_OPS_PUT_METHOD_IND,           "BT_OPS_PUT_METHOD_IND"},
	{BT_OPS_GET_METHOD_IND,           "BT_OPS_GET_METHOD_IND"},
	{BT_OPS_PUT_CFM,           "BT_OPS_PUT_CFM"},
	{BT_OPS_ABORT_CFM,		 "BT_OPS_ABORT_CFM"},
		
	{BT_OPC_SEARCH_RESULT_IND,    "BT_OPC_SEARCH_RESULT_IND"},
	{BT_OPC_SEARCH_CFM,           "BT_OPC_SEARCH_CFM"},
	{BT_OPC_CONNECT_CFM,          "BT_OPC_CONNECT_CFM"},
	{BT_OPC_DISCONNECT_IND,       "BT_OPC_DISCONNECT_IND"},
	{BT_OPC_GET_CFM,              "BT_OPC_GET_CFM"},
	{BT_OPC_PUT_CFM,              "BT_OPC_PUT_CFM"},
	{BT_OPC_EXCHANGE_CFM,         "BT_OPC_EXCHANGE_CFM"},
	{BT_OPC_OBJ_IND,              "BT_OPC_OBJ_IND"},
	{BT_OPC_ABORT_CFM,            "BT_OPC_ABORT_CFM"},
	{BT_OPC_ACTION_IND,           "BT_OPC_ACTION_IND"},
		
	{BT_FTS_SET_ROOT_DIR_CFM,     "BT_FTS_SET_ROOT_DIR_CFM"},     
	{BT_FTS_ACTIVATE_CFM,         "BT_FTS_ACTIVATE_CFM"},         
	{BT_FTS_DEACTIVATE_CFM,       "BT_FTS_DEACTIVATE_CFM"},       
	{BT_FTS_CONNECT_IND,	  "BT_FTS_CONNECT_IND"},	     
	{BT_FTS_DISCONNECT_IND,       "BT_FTS_DISCONNECT_IND"},       
	{BT_FTS_AUTHENTICATE_IND,     "BT_FTS_AUTHENTICATE_IND"},     
	{BT_FTS_DIR_CHANGE_IND,       "BT_FTS_DIR_CHANGE_IND"},       
	{BT_FTS_ACTION_IND,           "BT_FTS_ACTION_IND"},           
	                  
	{BT_FTC_SET_ROOT_DIR_CFM,     "BT_FTC_SET_ROOT_DIR_CFM"},     
	{BT_FTC_SEARCH_RESULT_IND,    "BT_FTC_SEARCH_RESULT_IND"},    
	{BT_FTC_SEARCH_CFM,           "BT_FTC_SEARCH_CFM"},           
	{BT_FTC_CONNECT_CFM,	  "BT_FTC_CONNECT_CFM"},	     
	{BT_FTC_DISCONNECT_CFM,       "BT_FTC_DISCONNECT_CFM"},       
	{BT_FTC_DISCONNECT_IND,       "BT_FTC_DISCONNECT_IND"},       
	{BT_FTC_AUTHENTICATE_IND,     "BT_FTC_AUTHENTICATE_IND"},     
	{BT_FTC_LOCAL_GETDIR_CFM,     "BT_FTC_LOCAL_GETDIR_CFM"},     
	{BT_FTC_LOCAL_CHDIR_CFM,      "BT_FTC_LOCAL_CHDIR_CFM"},      
	{BT_FTC_LOCAL_MKDIR_CFM,      "BT_FTC_LOCAL_MKDIR_CFM"},      
	{BT_FTC_LOCAL_RMDIR_CFM,      "BT_FTC_LOCAL_RMDIR_CFM"},      
	{BT_FTC_LOCAL_DEL_CFM,        "BT_FTC_LOCAL_DEL_CFM"},        
	{BT_FTC_REMOTE_GETDIR_CFM,    "BT_FTC_REMOTE_GETDIR_CFM"},    
	{BT_FTC_REMOTE_CHDIR_CFM,     "BT_FTC_REMOTE_CHDIR_CFM"},     
	{BT_FTC_REMOTE_MKDIR_CFM,     "BT_FTC_REMOTE_MKDIR_CFM"},     
	{BT_FTC_REMOTE_RMDIR_CFM,     "BT_FTC_REMOTE_RMDIR_CFM"},     
	{BT_FTC_REMOTE_DEL_CFM,       "BT_FTC_REMOTE_DEL_CFM"},       
	{BT_FTC_PUTFILE_CFM,          "BT_FTC_PUTFILE_CFM"},          
	{BT_FTC_GETFILE_CFM,          "BT_FTC_GETFILE_CFM"},          
	{BT_FTC_ABORT_CFM,            "BT_FTC_ABORT_CFM"},            
	{BT_FTC_DIR_CHANGE_IND,       "BT_FTC_DIR_CHANGE_IND"},       
	{BT_FTC_DIR_LIST_IND,         "BT_FTC_DIR_LIST_IND"},         
	{BT_FTC_ACTION_IND,           "BT_FTC_ACTION_IND"},           
	{BT_FTS_ABORT_IND, 		"BT_FTS_ABORT_IND"},   /* JIN100_BT_FTP 050822 */
	{BT_FTS_DEL_OBJ_IND,		 "BT_FTS_DEL_OBJ_IND"},	 
	{BT_FTS_GET_OBJ_COMPLETE_IND,  "BT_FTS_GET_OBJ_COMPLETE_IND"},	 
	{BT_FTS_PUT_OBJ_COMPLETE_IND,  "BT_FTS_PUT_OBJ_COMPLETE_IND"},	 
	{BT_FTS_GETFILE_CFM,  "BT_FTS_GETFILE_CFM"},
	{BT_FTS_ABORT_CFM,  "BT_FTS_ABORT_CFM"},
	                     
	{BT_SYNC_CONNECT_CFM,         "BT_SYNC_CONNECT_CFM"},         
	{BT_SYNC_DISCONNECT_IND,      "BT_SYNC_DISCONNECT_IND"},      
	{BT_SYNC_GET_CFM,             "BT_SYNC_GET_CFM"},             
	{BT_SYNC_PUT_CFM,             "BT_SYNC_PUT_CFM"},      
		
    // Avanced Audio Distribution Profile
	{BT_AV_CONNECT_CFM,     		"BT_AV_CONNECT_CFM"},         
	{BT_AV_DISCONNECT_CFM,   	"BT_AV_DISCONNECT_CFM"},      
	{BT_AV_START_CFM,             	"BT_AV_START_CFM"},             
	{BT_AV_STOP_CFM,             	"BT_AV_STOP_CFM"},      
	{BT_AV_PAUSE_CFM,         		"BT_AV_PAUSE_CFM"},         
	{BT_AV_RESUME_CFM,      		"BT_AV_RESUME_CFM"},      
	{BT_AV_ABORT_CFM,             	"BT_AV_ABORT_CFM"},	
	
	{BT_AV_START_IND,             	"BT_AV_START_IND"},             
	{BT_AV_STOP_IND,             	"BT_AV_STOP_IND"},      
	{BT_AV_PAUSE_IND,         		"BT_AV_PAUSE_IND"},         
	{BT_AV_RESUME_IND,      		"BT_AV_RESUME_IND"},      
	{BT_AV_ABORT_IND,             	"BT_AV_ABORT_IND"},	
		
    // Basic Printing Profile
      {BT_BPP_START_SEARCH,                 		"BT_BPP_START_SEARCH"},                  
      {BT_BPP_STOP_SEARCH,          		"BT_BPP_STOP_SEARCH"},           
      {BT_BPP_CONNECT,				"BT_BPP_CONNECT"},                 
      {BT_BPP_GET_PRINTER_ATTRIBUTE_REQ,			"BT_BPP_GET_PRINTER_ATTRIBUTE_REQ"},   
      {BT_BPP_GET_PRINTER_ATTRIBUTE_RES,  		"BT_BPP_GET_PRINTER_ATTRIBUTE_RES"},   
      {BT_BPP_SEND_DOCUMENT_REQ,				"BT_BPP_SEND_DOCUMENT_REQ"},           
      {BT_BPP_SEND_DOCUMENT_RES,				"BT_BPP_SEND_DOCUMENT_RES"},           
      {BT_BPP_CREATE_JOB_REQ,				"BT_BPP_CREATE_JOB_REQ"},              
      {BT_BPP_AUTHENTICATE_RES,				"BT_BPP_AUTHENTICATE_RES"},            
      {BT_BPP_ABORT_REQ,					"BT_BPP_ABORT_REQ"},                   
      {BT_BPP_DISCONNECT,				"BT_BPP_DISCONNECT"},              
                                                                                               
                                                                                               
      {BT_BPP_SEARCH_RESULT_IND,				"BT_BPP_SEARCH_RESULT_IND"},           
      {BT_BPP_SEARCH_CFM,				"BT_BPP_SEARCH_CFM"},            
      {BT_BPP_CONNECT_CFM,				"BT_BPP_CONNECT_CFM"},                 
      {BT_BPP_GET_PRINTER_ATTRIBUTE_IND, 			"BT_BPP_GET_PRINTER_ATTRIBUTE_IND"},   
      {BT_BPP_GET_PRINTER_ATTRIBUTE_CFM,			"BT_BPP_GET_PRINTER_ATTRIBUTE_CFM"},   
      {BT_BPP_SEND_DOCUMENT_IND,				"BT_BPP_SEND_DOCUMENT_IND"},           
      {BT_BPP_SEND_DOCUMENT_CFM,				"BT_BPP_SEND_DOCUMENT_CFM"},           
      {BT_BPP_AUTHENTICATE_IND,				"BT_BPP_AUTHENTICATE_IND"},            
      {BT_BPP_DISCONNECT_CFM,				"BT_BPP_DISCONNECT_CFM"},              
      {BT_BPP_DISCONNECT_IND,				"BT_BPP_DISCONNECT_IND"},              
      {BT_BPP_CREATE_JOB_CFM,				"BT_BPP_CREATE_JOB_CFM"},              
      {BT_BPP_ABORT_CFM,				"BT_BPP_ABORT_CFM"},
      {BT_BPP_ACTION_IND,				"BT_BPP_ACTION_IND"},
	{BT_BPP_PRINT_CFM,				"BT_BPP_PRINT_CFM "}, 
/*hfp15 20071001 baeheejung*/	
	{BT_HFG_OPERATOR_SELECTION_IND,		"BT_HFG_OPERATOR_SELECTION_IND"},
	{BT_HFG_EXTENDED_ERROR_ENABLE_IND,	"BT_HFG_EXTENDED_ERROR_ENABLE_IND"},
	{BT_HFG_EXTENDED_ERROR_DISABLE_IND,	"BT_HFG_EXTENDED_ERROR_DISABLE_IND"},
	{BT_HFG_SUBSCRIBER_NUM_IND,			"BT_HFG_SUBSCRIBER_NUM_IND"},
	{BT_HFG_CURRENT_CALL_LIST_IND,			"BT_HFG_CURRENT_CALL_LIST_IND"},
	{BT_HFG_CIND_IND,						"BT_HFG_CIND_IND"},
	{BT_HFG_3WAY_IND,						"BT_HFG_3WAY_IND"},
	{BT_FTP_ENABLE_IND,						"BT_FTP_ENABLE_IND"},
	{BT_OPP_ENABLE_IND,						"BT_OPP_ENABLE_IND"},
	{BT_OBEX_ENABLE_IND,						"BT_OBEX_ENABLE_IND"}, /* BT_COMMON_KIMSANGJIN_071106 */
	{BT_SPP_ENABLE_IND,						"BT_SPP_ENABLE_IND"},
	{BT_DUN_ENABLE_IND,						"BT_DUN_ENABLE_IND"},
	{BT_HSP_ENABLE_IND,						"BT_HSP_ENABLE_IND"},
	{BT_PBAP_ENABLE_IND,						"BT_PBAP_ENABLE_IND"},
	{BT_HFP_ENABLE_IND,						"BT_HFP_ENABLE_IND"},
	{BT_FTP_DISABLE_IND,						"BT_FTP_DISABLE_IND"},
	{BT_OPP_DISABLE_IND,                                       "BT_OPP_DISABLE_IND"},
	{BT_OBEX_DISABLE_IND,						"BT_OBEX_DISABLE_IND"},
	{BT_SPP_DISABLE_IND,                                       "BT_SPP_DISABLE_IND"},
	{BT_DUN_DISABLE_IND,                                      "BT_DUN_DISABLE_IND"},
	{BT_HSP_DISABLEE_IND,                                     "BT_HSP_DISABLEE_IND"},
	{BT_PBAP_DISABLE_IND,                                     "BT_PBAP_DISABLE_IND"},
	{BT_MMI_LAST_STREAM,          "UNKNOWN MESSAGE"}
};

char *BtGetMmiMsgName(BTMMIMSG msgid)
{
	Int16 i;

	i = 0;
	while (1)
	{
		if ( gBtMsgTable[i].msgid == BT_MMI_LAST_STREAM)
			return "UNKNOWN MESSAGE";
		if (gBtMsgTable[i].msgid == msgid )
			return gBtMsgTable[i].msgname;
		i++;
	}
}

#endif /* LGBX_INCLUDE */

#endif /* LGE_MMI_BLUETOOTH */

