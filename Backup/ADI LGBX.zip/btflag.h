/***************************************************************************
* FILE: btflag.h
* AUTH: Sang-Kwon Lee
* DATE: 2004/10/01
* DESC: Global flags for Bluetooth Service
 ***************************************************************************/

#if !defined(BTFLAG_H)
#define BTFLAG_H

#if defined(LGE_L1_BLUETOOTH)

#if !defined (SYSTEM_H)
#include <system.h>
#endif 

#if !defined (LGEBTTYPE_H)
#include "Lgebttype.h"
#endif

/***************************************************************************
* Functions
***************************************************************************/
void	BtFlag_Init(void);

void	BtFlag_SetActivated(Int16 flagId, Boolean flag);
Boolean	BtFlag_IsActivated(Int16 flagId);
void	BtFlag_SetConnected(Int16 flagId, Boolean flag);
Boolean	BtFlag_IsConnected(Int16 flagId);
void	BtFlag_SetEnabled(Boolean flag);
Boolean BtFlag_IsEnabled(void);

/* BT_COMMON_KIMSANGJIN_070124 noti_010434 */
#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)/*noti_010420*/
void BtFlag_SetUscLock(Boolean flag);
Boolean BtFlag_isUscLock(void); 
#endif

/***************************************************************************
* A2DP
***************************************************************************/
#if defined(LGE_LEMANS_BLUETOOTH) /* Tiburona_071025 For Bluetooth A2DP */
void BtSetA2dpStreamRequest(Boolean flag);
Boolean BtGetA2dpStreamRequest(void);

void BtSetA2dpPathChange(Boolean flag);
Boolean BtGetA2dpPathChange(void);
#endif /* LGE_LEMANS_BLUETOOTH */

/****************************************************************************
** PCM Control
****************************************************************************/
void BtSetEnablePcm(Boolean flag);
Boolean BtGetEnablePcm(void);

/***************************************************************************
* Audio
***************************************************************************/
void BtFlag_SetSpeechEn(Boolean flag);
Boolean BtFlag_IsSpeechEn(void);
void BtFlag_SetAudioOpen(Boolean flag);
Boolean BtFlag_IsAudioOpen(void);
void BtFlag_SetAudioMicMute(Boolean flag);
Boolean BtFlag_IsAudioMicMute(void);
void BtFlag_SetSpkGainFromAg(Boolean flag); /* BT_COMMON_TIBURONA_080116 */
Boolean BtFlag_ChangeSpkGainFromAg(void); /* BT_COMMON_TIBURONA_080116 */

/***************************************************************************
* Connection
***************************************************************************/
Boolean BTFlag_IsHeadsetConnected(void); /* GX_LEEJINBAEK_070211 */
Boolean BtFlag_IsAnyAudioDevConnected(void);

/***************************************************************************
* Audio Path: Phone or Bluetooth Device
***************************************************************************/
void BtFlag_SetAudioPathPhone(Boolean flag);
Boolean BtFlag_IsAudioPathPhone(void);
Boolean IsUseBTAudio(void);

void    BtFlag_SetTimeOutFlag(Boolean flag);
Boolean BtFlag_GetTimeOutFlag(void);

void    BtFlag_SetShutdownFromTimer(Boolean flag);
Boolean BtFlag_GetShutdownFromTimer(void);
Boolean BtGetPCMCloseWait(void);
void BtSetPCMCloseWait(Boolean flag);
Boolean IsAudioPathBt(void);
void BtSetAudioPath2BT(Boolean flag);

void BTSetTextualUI(Boolean flag);
Boolean BTGetTextualUI(void);

/*hfp15 20071001 baeheejung*/
void BTSetExtendedErrorFlag(Boolean flag);
Boolean BTGetExtendedErrorFlag(void);
#endif /* LGE_L1_BLUETOOTH */

#endif /* BTFLAG_H */

