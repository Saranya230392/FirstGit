/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfs_ttp.c

DESCRIPTION:	     Functions of TTPCom File Sytem for Bluetooth

History:
2006/08/28  $Revision: 1.0 $  :: Created for TTPCom File System Functions
			 			     $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/

#define MODULE_NAME "BTFS_TTP"

#if defined(LGE_TTPCOM_FS_BLUETOOTH)
/****************************************************************************
* Include Files
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <kernel.h>
#include <system.h>
#include <ki_sig.h>

#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

#if !defined(BTFSIF_H)
#include "btfsif.h"
#endif

#if !defined(BTFS_TTP_H)
#include "btfs_ttp.h"
#endif

#if defined (UPGRADE_FSYSTEM)
#if !defined(FSMN_FNC_H)
#include "fsmn_fnc.h"
#endif
#endif

#if !defined (AFSH_FNC_H)
#include "afsh_fnc.h"
#endif /*AFSH_FNC_H*/

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/
#define EXTERNAL_MEMORY		"External Memory"
#define EXTERNAL_ROOT_LENGTH	16 //strlen(EXTERNAL_MEMORY)

/****************************************************************************
* Type Definitions
****************************************************************************/

/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Global Variables
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/
/* BT_COMMON_KIMSANGJIN_070412 noti_011047*/
static Boolean OpenRootDir = FALSE;
Boolean OneCycle = FALSE;

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
* Global Functions
****************************************************************************/
/****************************************************************************

				TTPCOM File System Interface for Bluetooth
				
	O_RDONLY 	: open for reading only
	O_WRONLY	: open for writing only
	O_RDWR		: open for reading and writing

	O_CREAT 	: create if nonexistent
	O_TRUNC 	: truncate to zero length
	O_EXCL		: error if already exists
	O_APPEND 	: set append mode

'w' - ���� �������� �����ϴ�; ���� �����͸� ������ �� �տ� �����ϴ� �׸��� ������ ũ�⸦ 0���� ����ϴ�. ������ ������ ����ϴ�. 
'w+' - �б� ���Ⱑ �����մϴ�; ���������͸� ������ �� �տ� �����ϴ�. �׸��� ������ ũ�⸦0���� ����ϴ�. ������ ������ ����ϴ�. 

'a' - ���� �������� �����ϴ�; ���� �����͸� ������ ���� �����ϴ�. ������ ������ ����ϴ�. 
'a+' - �б� ���Ⱑ �����մϴ�; ���� �����͸� ������ ���� �����ϴ�. ������ ������ ����ϴ�. 

'r' - �б��������� �����ϴ�; ���������͸� ������ �� �տ� �����ϴ�. 
'r+' - �б� ���Ⱑ �����մϴ�.; ���� �����͸� ������ �� �տ� �����ϴ�. 

****************************************************************************/
int btfs_ttpcom_open(const char *fileName, const char *mode)
{
	int retVal=0;
	int  fsError=0;
	Int16 access=0, perms=0;

	/*Check mode is valid */
	if ( *mode != 'r' && *mode != 'a' && *mode != 'w' )
	{
		/*Invalid mode */
    		BT_DEBUG(("Btfs_Open:BadMode %c should be r,a or w", *mode));
		return BT_FS_FAIL;
	}
	
	if ( *mode == 'w' )
	{
		/*+ means open for reading and writing */
		if ( *(mode + 1) == '+' )
		{
			/*Open an existing file, over-writing any existing data or just create a new file.*/
			access = O_RDWR | O_CREAT | O_TRUNC;
			perms = (O_READABLE | O_WRITABLE);
		}
		else
		{
			access = O_WRONLY | O_CREAT | O_TRUNC;
			perms = (O_READABLE | O_WRITABLE);
		}
	}
	else if ( *mode == 'a' )
	{
		if ( *(mode + 1) == '+' )
		{
			/*Open an existing file, appending. If no file then create it*/
			access = O_RDWR | O_CREAT | O_APPEND;
			perms = (O_READABLE | O_WRITABLE);			
		}
		else
		{
			access = O_WRONLY | O_CREAT | O_APPEND;
			perms = (O_READABLE | O_WRITABLE);		
		}
	}
	else
	{
		/*Open for reading */
		if ( *(mode + 1) == '+' )
		{
			access = O_RDWR;
			perms = (O_READABLE | O_WRITABLE);		
		}
		else
		{
			access = O_RDONLY;
			perms = (O_READABLE | O_WRITABLE);		
		}
	}

#if defined(FS_OVERWRITE_EN) /*use over write option*/
	retVal= fsysOpen(fileName, access, perms);
#else
	if((strcmp(mode,"w+") == 0) || (strcmp(mode,"w") == 0) || (strcmp(mode,"a") == 0) ||(strcmp(mode,"a+") == 0))
	{
		if(btfs_ttpcom_exists(fileName) == TRUE)	// $suhui 070402 FTP ���� ���� name ���� ����
			retVal = FILE_ALREADY_EXIST;		
		else
			retVal = fsysOpen(fileName, access, perms);
	}
	else
	{
		retVal = fsysOpen(fileName, access, perms);		
	}
#endif
	BT_DEBUG(("btfs_ttpcom_open() fsysOpen() retVal=[%d] ", retVal));
	
	//if (fserrno)
	//	retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;		
		if( (fsError == EEXIST)||(retVal == FILE_ALREADY_EXIST) )
			BT_DEBUG(("\x1b[35m ================> btfs_ttpcom_open() EEXIST [%ld] \x1b[0m ", fsError));
		else
			BT_DEBUG(("btfs_ttpcom_open() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_open() Success [%ld], retVal=%d", fsError, retVal));
	}
	
	return retVal;
}

int btfs_ttpcom_read(int handle, void *buf, Int32 len)
{
	int retVal=0;
	int  fsError=0;
	
	retVal= fsysRead(handle, buf, len);
	BT_DEBUG(("btfs_ttpcom_read() fsysRead() retVal=[%d] ", retVal));

	//if (fserrno)
		//retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_read() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		//BT_DEBUG(("btfs_ttpcom_read() Success [%ld]", fsError));
	}
	
	return retVal;
}

int btfs_ttpcom_write(int handle, void *buf, Int32 len)
{
	int retVal=0;
	int  fsError=0;
	
	retVal= fsysWrite(handle, buf, len);
	BT_DEBUG(("btfs_ttpcom_write() fsysWrite() retVal=[%d] ", retVal));	

//	if (fserrno)
	//	retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_write() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		//BT_DEBUG(("btfs_ttpcom_write() Success [%ld]", fsError));
	}
	
	return retVal;
}

int btfs_ttpcom_close(int handle)
{
	int retVal=0;
	int  fsError=0;
	
	retVal= fsysClose(handle);
	BT_DEBUG(("btfs_ttpcom_close() fsysClose() retVal=[%d] ", retVal));	

//	if (fserrno)
//		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_close() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_close() Success [%ld]", fsError));
	}
	
	return retVal;
}

int btfs_ttpcom_stat(const char *fileName, Stat *statBuf_p)
{
	int retVal=0;
	int  fsError=0;

	if(strcmp(fileName, "c:\\External Memory") == 0)
	{
		BT_DEBUG(("btfs_ttpcom_stat() e:\\External Memory directory >>>"));
		retVal = 0;
		statBuf_p->st_mtime = 0;
		statBuf_p->st_mode = 16768; /* To Do */
		statBuf_p->st_size = 0;
	}
	else
	{
		retVal = fsysStat(fileName, statBuf_p);
		BT_DEBUG(("btfs_ttpcom_stat() fsysStat() retVal=[%d] ", retVal));		
	}

	if (retVal < 0)
	{
		fsError = fserrno;
		retVal = EINVAL;		
		BT_DEBUG(("btfs_ttpcom_stat() Failure [%ld], retVal=%d", fsError, retVal));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("==============================================="));			
		BT_DEBUG(("01. st_dev=%d", statBuf_p->st_dev)); 		/*Logical drive number   	*/
		BT_DEBUG(("02. st_ino=%d", statBuf_p->st_ino));		/*Unique file number     	*/
		BT_DEBUG(("03. st_nlink=%d", statBuf_p->st_nlink));		/*Number of links to file	*/
		BT_DEBUG(("04. st_mode=%d", statBuf_p->st_mode));	/*File permissions       		*/
		BT_DEBUG(("05. st_rdev=%d", statBuf_p->st_rdev));		/*Device file            */	
		BT_DEBUG(("06. st_size=%d", statBuf_p->st_size));		/*File size in bytes     */
		BT_DEBUG(("07. st_rdev=%d", statBuf_p->st_rdev));		/*Device file            */	
		BT_DEBUG(("08. st_mtime=%d", statBuf_p->st_mtime));	/*File modification time */
		BT_DEBUG(("09. st_atime=%d", statBuf_p->st_atime));	/*File access time       */	
		BT_DEBUG(("10. st_ctime=%d", statBuf_p->st_ctime));	/*File create time       */
		BT_DEBUG(("11. st_uid=%d", statBuf_p->st_uid));		/*File owner             */
		BT_DEBUG(("12. st_gid=%d", statBuf_p->st_gid));		/*File owner's group     */		
		BT_DEBUG(("==============================================="));	
		BT_DEBUG(("btfs_ttpcom_stat() Success [%ld]", fsError));
	}
	
	return retVal;
}

Int32 btfs_ttpcom_statistics(char *deviceLabel)	/* check this function() : L1ExfsSendGetDiskStatisticsReqSig() in l1exfs_sigif.c */
{
	Int8			mntDevNo, mntPartNo;
	Int16		err, blockSize;
	Int32		numBlocks, freeBlocks;
	FileSystem	fsType;
	Char			volName[MAX_FS_VOL_NAME];
	Int32		totalSize, freeSize, usedSize;
	int fsError=0;

	BT_DEBUG(("btfs_ttpcom_statistics() driver name : %s ", deviceLabel));

	err = getmount( deviceLabel[0], &mntDevNo, &mntPartNo, &blockSize, &numBlocks, &freeBlocks, &fsType, volName, MAX_FS_VOL_NAME );

	/* file system error */
	if ((err == FSMN_OK) && (numBlocks >= freeBlocks))
	{
		totalSize = numBlocks * blockSize;
		freeSize  = freeBlocks * blockSize;
		usedSize  = totalSize - freeSize;
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_statistics() totalSize=%ld[Byte], freeSize=%ld[Byte], usedSize=%ld[Byte]", totalSize, freeSize, usedSize));
		BT_DEBUG(("btfs_ttpcom_statistics() Success [%ld]", fsError));
	}
	else
	{
		totalSize = freeSize = usedSize = 0;
		fsError = err;
		BT_DEBUG(("btfs_ttpcom_statistics() Failure [%ld]", fsError));
	}
	
	return freeSize;
}

int btfs_ttpcom_chmod( const char *fileName, const char *mode)
{
	int retVal=0;
	int  fsError=0;
	Int16 access=0, perms=0;

	/*Check mode is valid */
	if ( *mode != 'r' && *mode != 'a' && *mode != 'w' )
	{
		/*Invalid mode */
    		BT_DEBUG(("Btfs_Open:BadMode %c should be r,a or w", *mode));
		return BT_FS_FAIL;
	}

	if ( *mode == 'w' )
	{
		/*+ means open for reading and writing */
		if ( *(mode + 1) == '+' )
		{
			/*Open an existing file, over-writing any existing data or just create a new file.*/
			access = O_RDWR | O_CREAT | O_TRUNC;
			perms = (O_READABLE | O_WRITABLE);
		}
		else
		{
			access = O_WRONLY | O_CREAT | O_TRUNC;
			perms = (O_READABLE | O_WRITABLE);
		}
	}
	else if ( *mode == 'a' )
	{
		if ( *(mode + 1) == '+' )
		{
			/*Open an existing file, appending. If no file then create it*/
			access = O_RDWR | O_CREAT | O_APPEND;
			perms = (O_READABLE | O_WRITABLE);			
		}
		else
		{
			access = O_WRONLY | O_CREAT | O_APPEND;
			perms = (O_READABLE | O_WRITABLE);		
		}
	}
	else
	{
		/*Open for reading */
		if ( *(mode + 1) == '+' )
		{
			access = O_RDWR;
			perms = (O_READABLE | O_WRITABLE);		
		}
		else
		{
			access = O_RDONLY;
			perms = (O_READABLE | O_WRITABLE);		
		}
	}
	
	retVal = fsysChmod(fileName, perms);
	BT_DEBUG(("btfs_ttpcom_chmod() fsysChmod() retVal=[%d] ", retVal));	

	if (fserrno)
		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_chmod() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_chmod() Success [%ld]", fsError));
	}
	
	return retVal;
}

int btfs_ttpcom_remove(const char *fileName)
{
	int retVal=0;
	int  fsError=0;
	
	retVal = fsysUnlink(fileName);
	BT_DEBUG(("btfs_ttpcom_remove() fsysUnlink() retVal=[%d] ", retVal));

	if (fserrno)
		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_remove() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_remove() Success [%ld]", fsError));
	}
	
	return retVal;
}

int btfs_ttpcom_rename(const char *oldName, const char *newName)
{
	int retVal=0;
	int  fsError=0;
	
	retVal = fsysRename(oldName, newName);
	BT_DEBUG(("btfs_ttpcom_rename() fsysRename() retVal=[%d] ", retVal));

	if (fserrno)
		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_rename() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_rename() Success [%ld]", fsError));
	}
	
	return retVal;
}

int btfs_ttpcom_seek(int handle, int offset, Int32 fromwhere)
{
	int retVal=0;
	int  fsError=0;
	
	retVal = fsysLseek(handle, offset, fromwhere);
	BT_DEBUG(("btfs_ttpcom_seek() fsysLseek() retVal=[%d] ", retVal));

	if (fserrno)
		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_seek() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_seek() Success [%ld]", fsError));
	}
	
	return retVal;
}

Boolean btfs_ttpcom_exists(const char *fileName)
{
	struct stat statBuf_p;
	Boolean exist=FALSE;
	int retVal=0;
	int fsError=0;	
	
	retVal = fsysStat(fileName, &statBuf_p);
	BT_DEBUG(("btfs_ttpcom_exists() fsysStat() retVal=[%d] ", retVal));

	if (retVal==0)
	{
		exist = TRUE;
	}
	else
	{
		exist = FALSE;
	}

	if (fserrno)
	{
		fsError = fserrno;
		exist = FALSE;
		BT_DEBUG(("btfs_ttpcom_exists() Failure [%ld]", fsError));
	}
	else
	{
		BT_DEBUG(("btfs_ttpcom_exists() Success [%ld]", fsError));
	}
	
	return exist;
}
	
DIR * btfs_ttpcom_opendir(const char *dirname_p)
{
  	DIR *retVal=PNULL;
	int  fsError=0;
	
	if(strcmp(dirname_p, "c:\\") == 0)
	{
	       BT_DEBUG(("btfs_ttpcom_opendir() Read Root dir>>>"));
		OpenRootDir = TRUE;
		OneCycle = FALSE;
	}
	
	retVal = opendir(dirname_p);

	if (fserrno)
		fsError = fserrno;
	
	if (retVal == PNULL)
	{
		BT_DEBUG(("btfs_ttpcom_opendir() Failure [%ld], retVal=%s", fsError, retVal));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		BT_DEBUG(("btfs_ttpcom_opendir() Success [%ld], retVal=%s", fsError, retVal));
	}
	
	return retVal;
}

struct dirent *btfs_ttpcom_readdir(DIR *dir_p)
{
	struct dirent *retVal=PNULL;
	struct dirent externalRootName[EXTERNAL_ROOT_LENGTH+1];		
	int  fsError=0;

	BT_DEBUG(("btfs_ttpcom_readdir() start"));

	retVal = readdir(dir_p);

#if 0
	//////////////////////////////////FOR DEBUG/////////////////////////////////////////////////
	if (retVal != PNULL)
	{
		//BtconvertFileNameToChar(retVal, debugstr);
		BT_DEBUG(("************ DIR Entry d_name = %s", retVal));
		//if(debugstr != PNULL) KiFreeMemory( &debugstr ); /*noti_011021*/
	}
	else
	{
		BT_DEBUG((" DIR Entry End : retVal is PNULL"));	
		BT_DEBUG(("************ DIR Entry Information End **************** "));		
	}
	///////////////////////////////////FOR DEBUG/////////////////////////////////////////////////	
#endif

	BT_DEBUG(("btfs_ttpcom_readdir() return"));
	if ( (retVal == PNULL) || ((OneCycle == TRUE) &&(SDCardIsPresent() == SDCARD_IN)))
	{
		/* BT_COMMON_KIMSANGJIN_070412 noti_011047 */
		if((OpenRootDir == TRUE) && (SDCardIsPresent() == SDCARD_IN))
		{
			//Int16 *tempstr=PNULL;
			OneCycle = TRUE;
			OpenRootDir = FALSE;
			memset(externalRootName, 0x00, sizeof(char)*(EXTERNAL_ROOT_LENGTH+1));
			strcpy((char *)externalRootName, EXTERNAL_MEMORY);			
			BT_DEBUG(("btfs_ttpcom_readdir() Root Directory Success : DIR Entry retVal = [0x%p,], externalRootName = [%s], error = [%ld]", 
						retVal, externalRootName, fsError));
			BT_DEBUG(("End of btfs_ttpcom_readdir() external was exist !!! "));			
			return externalRootName;
		}
		else
		{
			OneCycle =FALSE;
			fsError = fserrno;
			BT_DEBUG(("btfs_ttpcom_readdir() Failure [%ld], OpenRootDir=%s, SDCardIsPresent()=%d", fsError, OpenRootDir?"True":"False", SDCardIsPresent()));
			BT_DEBUG((" DIR Entry End : retVal is PNULL"));		
			//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);			
			return PNULL;
		}
		/* end of BT_COMMON_KIMSANGJIN_070412 */
	}
	else
	{
		BT_DEBUG(("btfs_ttpcom_readdir() Success DIR Entry d_name = [%s], error = [%ld]", retVal, fsError));
	}

	return retVal;
}

int btfs_ttpcom_closedir(DIR *dir_p)
{
	int retVal=0;
	int  fsError=0;
	
	retVal = closedir(dir_p);

	if (retVal < 0)
	{
		fsError = fserrno;
		retVal = EINVAL;
		BT_DEBUG(("btfs_ttpcom_closedir() Failure [%ld], retVal=%d", fsError, retVal));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_closedir() Success [%ld], retVal=%d", fsError, retVal));
	}
	
	return retVal;
}

void btfs_ttpcom_rewinddir(DIR  *dir_p)
{
	int retVal=0;
	int  fsError=0;
	
	rewinddir(dir_p);

	if (fserrno)
		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_rewinddir() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_rewinddir() Success [%ld]", fsError));
	}
}

int btfs_ttpcom_rmdir(const char *path)
{
	int retVal=0;
	int  fsError=0;
	
	retVal= rmdir(path);

	if (fserrno)
		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_rmdir() Failure [%ld]", retVal));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_rmdir() Success [%ld]", retVal));
	}
	
	return retVal;
}

int btfs_ttpcom_mkdir(const char *path)
{
	int retVal=0;
	int fsError=0;
	
	retVal= mkdir(path);	

	if (fserrno)
		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_mkdir() Failure [%ld]", retVal));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_mkdir() Success [%ld]", retVal));
	}
	
	return retVal;
}

Boolean btfs_ttpcom_isdir(const char *path)
{
	struct stat statBuf_p;
	int retVal=0;
	int fsError=0;
	
	retVal = fsysStat(path, &statBuf_p);
	BT_DEBUG(("btfs_ttpcom_isdir() fsysStat() retVal=[%d] ", retVal));

	//if (fserrno)
		//retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_ttpcom_isdir() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
		return FALSE;
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_ttpcom_isdir() Success [%ld]", fsError));		
		if ( statBuf_p.st_mode & S_IFDIR) 
		{
			BT_DEBUG(("btfs_ttpcom_isdir() This is Directory"));
			return TRUE;
		}
		else 
		{
			BT_DEBUG(("btfs_ttpcom_isdir() This is File"));		
			return FALSE;
		}
	}
}	   
#endif /* LGE_TTPCOM_FS_BLUETOOTH */

