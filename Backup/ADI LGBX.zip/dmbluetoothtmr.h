/**************************************************************************
 * TTPCom Software Copyright (c) 1997-2005 TTPCom Ltd
 * Licensed to Analog Devices (USA)
 **************************************************************************
 *   $Id: //central/releases/branch_release_lemans_0.4/tplgsm/dvinc/dmBluetoothtmr.h#1 $
 *   $Revision: #1 $
 *   $DateTime: 2006/08/18 13:53:43 $
 **************************************************************************
 *  File Description : DM Bluertooth Module Timer Definitions
 **************************************************************************/
/* BT_L1_KIMSANGJIN_060818 */
/* job100506 */
#if defined(DM_USE_NEW_STRUCTURE)
DM_TIMER_DEF(DM_TMR_BT_SEMA_TIMER	  ,  DM_TASK_ID,   0,	0)
DM_TIMER_DEF(DM_TMR_BT_TEST_TIMER     ,  DM_TASK_ID,   0,   0)
DM_TIMER_DEF(DM_TMR_BT_DEBUG_DISPLAY_TIMER	  ,  DM_TASK_ID,   0,	0)
DM_TIMER_DEF(DM_TMR_BT_HOOK_TIMER	  ,  DM_TASK_ID,   0,	0)
DM_TIMER_DEF(DM_TMR_BT_AUDIO_PATH_CHANGE_TIMER	  ,  DM_TASK_ID,   0,	0)
DM_TIMER_DEF(DM_TMR_BT_TX_POLLING_TIMER	  ,  DM_TASK_ID,   0,	0)
DM_TIMER_DEF(DM_TMR_BT_TIMEOUT_TIMER	  ,  DM_TASK_ID,   0,	0)
DM_TIMER_DEF(DM_TMR_BT_ON_TIMER	  ,  DM_TASK_ID,   0,	0)
DM_TIMER_DEF(DM_TMR_BT_POPUP_TIMER	  ,  DM_TASK_ID,   0,	0)
DM_TIMER_DEF(DM_TMR_BT_PCM_TIMER	  ,  DM_TASK_ID,   0,	0)
#if defined(LGBX_INCLUDE)
	DM_TIMER_DEF(DM_TMR_BT_LGBX_TIMER,  DM_TASK_ID,   0,	0)
#endif
#endif /*End of DM_USE_NEW_STRUCTURE*/
/* EOF */
