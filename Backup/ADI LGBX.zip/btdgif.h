/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:			 Btdgif.h

DESCRIPTION:		 Utility & Dial Up & SPP  Interface Functions Definition for Bluetooth Stack

History:
2006/09/26	$Revision: 1.0 $  :: Dial Up & SPP Interface Functions Definition for Bluetooth  
							 $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/
#if !defined(BTDGIF_H)
#define BTDGIF_H

#if defined(LGE_L1_BLUETOOTH)
#include <stdlib.h>
#include <string.h>

#ifndef BTTASK_SIG_H
#include "bttask_sig.h"
#endif /*BTTASK_SIG_H*/

#ifndef BTQUEUE_H
#include "btqueue.h"
#endif

#if defined(LGBX_INCLUDE)	
#ifndef DATA_TYPES_H
#include "data_types.h"
#endif/*DATA_TYPES_H*/
#endif /* LGBX_INCLUDE */

#if defined(LGE_BRCM_BLUETOOTH)
#include "bta_api.h"
#endif

extern void BtCommonDGWriteData(UINT8 * data, int nbytes);
#if 1 // noti_011227 recommand from Sean_071114: BtCommonDGReadData has to support length limitation for the data to read.
extern void BtCommonDGReadData(Int8 * data, Int16 * nbytes, Int16 maxLength);
#else
extern void BtCommonDGReadData(Int8 * data, Int16 * nbytes);
#endif
UINT8* BtCommonDGGetBufferInfo(UINT16* max_size);
extern UINT8* BtCommonDGGetData(int* size, UINT8 app_id);

/* LOUIS job00003_3 removed */
extern void BtCommonSPPGenieReadData(UINT8 * data, Int16 *nbytes);
extern void BtCommonSPPGenieWriteData(UINT8 * data, int nbytes);
extern void BtSPPConnect(void);
extern void BtSppGenieProcessEMMIRxData(void);
/* LOUIS job00003_3 removed */

#if 1 /* myung_1227 - addition for DUN */
#ifndef MAX_DG_APP_INDEX
#define MAX_DG_APP_INDEX    5
#endif

/* LOUIS job00003_1 */
/* BCM_070410 JOB 00002 CHRIS */
#define GSP_DATA_OVERHEAD				3  /* add 1 for checksum */
#define T_DURATION						30
#define LGE_ATF_RFCOMM_MTU_SIZE 		504//(2 *(BTA_SPP_MTU -GSP_DATA_OVERHEAD))
#define PCSYNC_MTU_BLOCK_SIZE		25600//	(T_DURATION * LGE_ATF_RFCOMM_MTU_SIZE)
/* end of BCM_070410 JOB 00002 CHRIS */

/* values for state */
enum
{
    BTA_DG_DUN_INIT,
    BTA_DG_DUN_LISTEN
};

typedef void (*tDTRChangeEventHandler)(UINT8 app_id, BOOLEAN on);
/* BCM_070410 JOB 00002 CHRIS */
typedef struct
{
#if defined(LGBX_INCLUDE)
    LGBX_BD_ADDR_TYPE	bd_addr; 		// bd addr
    LGBX_SERVICE_TYPE	serviceID;		//  LGBX_SVC_TYPE 
#endif
    void (*dtr_cback) (UINT8);   	/* dtr callback function */
//    UINT8 app_id;                	/* app_id */
    UINT16 port_handle;         	/* handle used at ci/co */
    UINT8 signals;               	/* RS232 signals */
    UINT8 values;              		/* RS232 signal values */
    UINT8 state;                		/* open/close state of bluetooth connection */
    BOOLEAN dtr;                	/* TRUE if DTR set, FALSE otherwise */
    BOOLEAN inbound_flow;       /* TRUE if inbound flow is enabled, FALSE otherwise - for PULL interface*/
    BOOLEAN rx_flow;                /* TRUE if remote enable rx, FALSE otherwise */
    BOOLEAN rtscts;
    BOOLEAN ri;
    BOOLEAN cd;
    BOOLEAN app_rtscts;

    //tBTA_SERVICE_ID service;	/* Service */	
    UINT16 mtu;			/* MTU size */

    UINT8 * Txbuffer;
    UINT16 TxLength;	
}BT_COMMON_DG_APP_CB;

#ifndef LGBX_DG_MAX_PORTS
#define LGBX_DG_MAX_PORTS 5
#endif


/* end of BCM_070410 JOB 00002 CHRIS */

/*---------------------------------------------------------------------------
 SIO IOCTL command type.  These are the commands which can be carried out by
 sio_ioctl.
---------------------------------------------------------------------------*/
typedef enum
{
   SIO_IOCTL_DCD_ON=0,             /* Assert Carrier Detection Indicator   */
  SIO_IOCTL_DCD_OFF,             /* Deassert Carrier Detection Indicator */
  SIO_IOCTL_RI_ON,               /* Assert Ring Indication               */
  SIO_IOCTL_RI_OFF,
  SIO_IOCTL_CTSRTS_ON,
  SIO_IOCTL_CTSRTS_OFF,
  SIO_IOCTL_DTR_ON,
  SIO_IOCTL_DTR_OFF

} sio_ioctl_cmd_type;

#endif

#endif /* end of LGE_L1_BLUETOOTH */

#endif /* BTDGIF_H */

