/***************************************************************************
 * LG Electronics Copyright (c) KEVIN_BT job100503
 ***************************************************************************
 * $Id: //central/releases/Branch_release_16/tplgsm/BLUETOOTH/Btqueue.c#1 $
 * $Revision: #1 $
 * $DateTime: 2006/08/14 09:25:26 $
 ***************************************************************************
 *	File Description :
 *		Bluetooth layer 2 and layer 1 protocol elements.(bte_hcisu_task)
 *		task runs at high priority (just under timers)
 *		interrupts run at high priority
 *
 *		The BLUETOOTH protocol is taken from BTE 3.0
 *
 * $Author : KEVIN PIEN(KYUE SUP BYUN) :-), KIM SANG JIN, KANG HYUNG WOOK
 *
 **************************************************************************/


#if defined(LGE_L1_BLUETOOTH)

#if !defined(LGE_CSR_BLUETOOTH) /* Sean_070823: CSR uses their own queue */

#include <stdlib.h>
#include <string.h>

#if !defined(BTQUEUE_H) 
#include "btqueue.h"
#endif

#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

/****************************************************************************
** Queue for UART Rx Buffer
****************************************************************************/

void BQ_Init( BtQueue *queue )
{
  queue->Head = 0;
  queue->Tail = 0;
}

#if defined(LGE_BRCM_BLUETOOTH)
void *bt_malloc( bt_uint32 size )
{

}
#endif /* LGE_BRCM_BLUETOOTH */

BtQueue *BQ_Create(bt_uint16 size)
{
	BtQueue * queue;

	queue = (BtQueue *)bt_malloc(sizeof(BtQueue) + sizeof(bt_uint8) * size);
	queue->Buffer = (bt_uint8 *)(queue + 1);
	BQ_Reset(queue);

	return queue;
}


// full check must be done by the caller
int BQ_WriteData(BtQueue * queue, bt_uint8 * data, int nbytes)
{
	if (queue != NULL && data != NULL && nbytes > 0)
	{

		int head = queue->Head;
		int size = queue->Size;
		if (queue->Count + nbytes > size)
			nbytes = size - queue->Count;

		if (head + nbytes < size)
		{
			memcpy(queue->Buffer + head, data, nbytes);
			queue->Head += nbytes;
		}
		else
		{
			int first = size - head;
			int remain = nbytes - first;
			memcpy(queue->Buffer + head, data, first);
			if (remain > 0)
				memcpy(queue->Buffer, data + first, remain);
			queue->Head = remain;
		}			

		queue->Count += nbytes;
		
		return nbytes;
	}
	
	return 0;
}

//-----------------------------------------------------------------------------
//	Reads given number of data from the queue and returns actually read number of data.
//-----------------------------------------------------------------------------
int BQ_ReadData(BtQueue * queue, bt_uint8 * data, int nbytes)
{
	if (queue != NULL && data != NULL && nbytes > 0)
	{
		int tail = queue->Tail;
		int size = queue->Size;

		if (queue->Count < nbytes)
			nbytes = queue->Count;

		if (tail + nbytes < size)
		{
			memcpy(data, queue->Buffer + tail, nbytes);
			queue->Tail += nbytes;
		}
		else
		{
			int half = size - tail;
			int remain = nbytes - half;
			memcpy(data, queue->Buffer + tail, half);
			if (remain > 0)
				memcpy(data + half, queue->Buffer, remain);
			queue->Tail = remain;
		}

		queue->Count -= nbytes;
		
		return nbytes;
	}
	return 0;
}


// empty check must be done by the caller
Int8 BQ_Delete( BtQueue* queue )
{
  Int8 item;
  /*
  if ( queue->head == queue->tail ) // queue empty
    return NULL;
  */
  item = queue->Buffer[queue->Head];
  queue->Head = (queue->Head + 1) % QUEUE_SIZE;
  return item;
}
/* BT_L1_KIMSANGJIN_060814 :Add from GB2 old model*/
Int16 QGetNum( BtQueue *queue )
{
  if (queue->Tail >= queue->Head)
    return queue->Tail - queue->Head;
  else
    return queue->Tail - queue->Head + QUEUE_SIZE;
}
/* end of BT_L1_KIMSANGJIN_060814 */

Int16 BQ_GetContents(BtQueue *queue, char *buf)
{
	Int16 i;
	Int16 idx;
	Int16 num;

	idx = queue->Head;
	num = QGetNum(queue);
	for (i = 0; i < num; i++) {
		buf[i] = queue->Buffer[idx++];
		if (idx >= QUEUE_SIZE)
			idx = 0;
	}
		
	return i;
}

Int8 BQ_GetHead( BtQueue *queue )
{
  if ( queue->Head == queue->Tail ) // queue empty
    return NULL;
  else
  	return queue->Buffer[queue->Head];
}

Boolean BQ_IsEmpty( BtQueue *queue )
{
  if ( queue->Head == queue->Tail ) 
  	return TRUE;
  else 
  	return FALSE;
}

Boolean BQ_IsFull( BtQueue *queue )
{
  if ( (queue->Tail+1) % QUEUE_SIZE == queue->Head ) // queue full
    return TRUE;
  else
    return FALSE;
}


Int16 BQ_GetNum( BtQueue *queue )
{
  if (queue->Tail >= queue->Head)
    return queue->Tail - queue->Head;
  else
    return queue->Tail - queue->Head + QUEUE_SIZE;
}

Int16 BQ_GetFreeNum(BtQueue *queue)
{
  return QUEUE_SIZE - QGetNum(queue);
}

//-----------------------------------------------------------------------------
//	Initializes the queue to its initial state.
//-----------------------------------------------------------------------------
void	BQ_Reset(BtQueue * queue)
{
	if (queue==NULL)
		return;
	queue->Count  = 0;
	queue->Head   = 0;
	queue->Tail   = 0;
}

#endif /* !LGE_CSR_BLUETOOTH */
#endif

