/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     btftp_task.c

DESCRIPTION:	     LGE Bluetooth FTP Task with File System

History:
2006/08/28  $Revision: 1.0 $  :: Created for LeMans
			 			     $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/

/* Tiburona_BT_060828 */
#define MODULE_NAME "BTFTP_TASK"

#if defined(LGE_L1_BLUETOOTH)

/****************************************************************************
* Include Files
****************************************************************************/
#include <stdio.h>
#include <system.h>
#include <kernel.h>

#if !defined(BTFSIF_H)
#include "btfsif.h"
#endif

#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/

/****************************************************************************
* Type Definitions
****************************************************************************/

/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Local Function Prototypes
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/

/****************************************************************************
* Global Functions
****************************************************************************/
void BtFTP_InitTask(void)
{
	SignalBuffer signal = kiNullBuffer;

	KiCreateSignal(SIG_INITIALISE, sizeof(KiInitialiseTask), &signal);
	KiSendSignal(BTFTP_TASK_QUEUE_ID, &signal);
}

/****************************************************************************
 * Processes
 ****************************************************************************/

/***************************************************************************
 * Task : BTFTPTask
 * Desc : This task is responsible for managing Bluetooth FTP Functions
 **************************************************************************/
 KI_ENTRY_POINT BtFtpTask(KI_TASK_ARGS);

KI_SINGLE_TASK(BtFtpTask, BTFTP_TASK_QUEUE_ID, BTFTP_TASK_ID)
	
KI_ENTRY_POINT BtFtpTask(KI_TASK_ARGS)
{
	SignalBuffer signal = kiNullBuffer;
	Boolean initialized = FALSE;

	while ( initialized == FALSE )
	{
		signal = kiNullBuffer;
		
		KiReceiveSignal( BTFTP_TASK_QUEUE_ID, &signal );
		
		switch (*signal.type)
		{
			case SIG_INITIALISE:
				initialized = TRUE;
				break;
			
			default:
				BT_DEBUG(("BtFtpTask(): waiting SIG_INITIALISE, but received=0x%X", *(signal.type)));
				break;
		}		
		KiDestroySignal( &signal );
	}

	/* Initialize data structure */
	//DEBUG0("BTFTPTask()");
	BTFS_INIT_CS();

#if 0	
	while( TRUE )
	{
		signal = kiNullBuffer;
		
		KiReceiveSignal( BTFTP_TASK_QUEUE_ID, &signal );

		switch ( *signal.type )
		{
				
			default:
				/* do nothing */
				break;		
		}
		
		if( signal.sig != kiNullBuffer.sig )
		{
			KiDestroySignal( &signal );
		}
		
	}
#endif	
	
}

#endif /* LGE_L1_BLUETOOTH */

/* End Of File */

