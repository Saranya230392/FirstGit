/***************************************************************************
 * LG Electronics Copyright (c)
 ***************************************************************************
 * $Id: //central/releases/Branch_release_/BLUETOOTH/BTfs_exfs.c $
 * $Revision: #1 $
 * $DateTime: 2005/07/01 16:30:37 $
 * $ModifyTime: 2007/03/15 15:30:37 $
 ***************************************************************************
 *  File Description :
 *      Bluetooth AIT File System Interface
 *
 * 
 * $Author : HYUNG-WOOK KANG(TIBURONA, KIMSANGJIN
 **************************************************************************/
#define MODULE_NAME "BTFS_EXFS"

/* Temp : Have to fix the mystuff using AIT file system */
#include <stdio.h>
#include <string.h>
#include <kernel.h>
#include <system.h>
#include <ki_sig.h>
#include "fs_fat.h"


sFILEINFO *aitFileInfo=PNULL;	
Int32 gExfsFilecounts = 0;

#if defined(LGE_EXFS_FS_BLUETOOTH)
/***************************************************************************
* Include Files
 ***************************************************************************/
#include <stdio.h>
#include <string.h>
#include <kernel.h>
#include <system.h>
#include <ki_sig.h>

//#include "a810h_ebibus.h"
//#include "a810h_system.h"

//#include "exfs_sig.h"
//#include "Exfs_io.h"
#include "fs_fat.h"
//#include "aits_fs.h"

#include "btfsif.h"
//#include "dlgpio.h"
//#include "afgl_fnc.h"
//#include "l1exfs_typ.h"	
#include "l1exfs_sig.h"	
#include "L1al_sig.h"
#include "afmf_ext.h"
//#include "afjv_typ.h"
//#include "afbt_fnc.h"
#include "Btfs_exfs.h"
#include "udebug.h"

/*LGE_KP230_LEE HYOUNG WOO_070806  model fixed*/
#if !defined (AFMF_TYP_H)
#include "afmf_typ.h"
#endif
#if !defined (APPLAYER_H)
#include "applayer.h"
#endif

union Signal
{
	L1ExFsTaskInitInd			l1ExFsTaskInitInd;
	L1ExFsInitReq               	   	l1ExFsInitReq;
	L1ExFsOpenReq                 	l1ExFsOpenReq;
	L1ExFsCreateReq                 	l1ExFsCreateReq;	
	L1ExFsReadReq                 	l1ExFsReadReq;
	L1ExFsWriteReq                	l1ExFsWriteReq;
	L1ExFsCloseReq                	l1ExFsCloseReq;
	L1ExFsRemoveReq               	l1ExFsRemoveReq;
	L1ExFsFseekReq                	l1ExFsFseekReq;
	L1ExFsRenameReq               	l1ExFsRenameReq;
	L1ExFsStatisticsReq                 l1ExFsStatisticsReq;
	L1ExFsFileGetsizeReq			l1ExFsFileGetsizeReq;
	L1ExFsCreateDirReq			l1ExFsCreateDirReq;
	L1ExFsDeleteAllReq			l1ExFsDeleteAllReq;	
	L1ExFsFileGetlistReq			l1ExFsFileGetlistReq;
	L1ExFsFileCountReq			l1ExFsFileCountReq;
	L1ExFsActiveReq			       l1ExFsActiveReq;
	L1ExFsDeactiveReq			l1ExFsDeactiveReq;
	L1ExFsFindFirstReq			l1ExFsFindFirstReq;
	L1ExFsFormatReq			l1ExFsFormatReq;
	L1ExFsDirGetlistReq			l1ExFsDirGetlistReq;
	L1ExFsDirInitReq				l1ExFsDirInitReq;
#if defined(btfs_exfs_temp) /* To Do : l1exfs have to add*/	
	L1ExFsGetFileInfoReq			l1ExFsGetFileInfoReq;/* KG290_YOONSOO_070414 :Getinfo function */
#endif
	L1ExFsInitCnf              		 l1ExFsInitCnf;
	L1ExFsOpenCnf                 		l1ExFsOpenCnf;
	L1ExFsCreateCnf                 	l1ExFsCreateCnf;	
	L1ExFsReadCnf                 		l1ExFsReadCnf;
	L1ExFsWriteCnf                		l1ExFsWriteCnf;
	L1ExFsCloseCnf                		l1ExFsCloseCnf;
	L1ExFsRemoveCnf               	l1ExFsRemoveCnf;
	L1ExFsRenameCnf               	l1ExFsRenameCnf;
	L1ExFsStatisticsCnf                	l1ExFsStatisticsCnf;
	L1ExFsFseekCnf                		l1ExFsFseekCnf;
  	L1ExFsFileGetsizeCnf			l1ExFsFileGetsizeCnf;
	L1ExFsCreateDirCnf			l1ExFsCreateDirCnf;
	L1ExFsDeleteAllCnf			l1ExFsDeleteAllCnf;	
	L1ExFsFileGetlistCnf			l1ExFsFileGetlistCnf;
	L1ExFsFileCountCnf			l1ExFsFileCountCnf;
	L1ExFsActiveCnf				l1ExFsActiveCnf;
	L1ExFsDeactiveCnf			l1ExFsDeactiveCnf;
	L1ExFsFindFirstCnf			l1ExFsFindFirstCnf;
	L1ExFsFormatCnf				l1ExFsFormatCnf;
	L1ExFsDirGetlistCnf			l1ExFsDirGetlistCnf;
	L1ExFsDirInitCnf				l1ExFsDirInitCnf;
#if defined(btfs_exfs_temp) /* To Do : l1exfs have to add*/		
	L1ExFsGetFileInfoCnf			l1ExFsGetFileInfoCnf;/* KG290_YOONSOO_070414 :Getinfo function */
#endif
	KiTimerExpiry					kiTimerExpiry;

};	


/***************************************************************************
 * Variables
 ***************************************************************************/
#if defined ( LGE_L1_USE_AIT )
#define LGE_EXT_FILESYS_TASK_ID L1EXFS_TASK_ID
#else
#define LGE_EXT_FILESYS_TASK_ID UNKNOWN_TASK_ID
#endif

static TaskId Target_TaskId = BTFTP_TASK_ID;
static Int32 gAitFileErrCode;
static KiUnitQueue BtExfsFTPPendigQueue;
//sFILEINFO aitFileInfo[EXFS_NUM_OF_GET_FILELIST];	
sFILEINFO *aitFileInfo=PNULL;	
Int32     exfs_idx =0;
Int32     read_idx =0;
/* BT_COMMON_KIMSANGJIN_070419 */
Aitfiledepth       gdir_path;



Boolean aitActiveFlag = FALSE;
Int32 gExfsFilecounts = 0;

FILEINFO_LIST			*gfolderList_p;
FILEINFO_LIST			*gfileList_p;

/***************************************************************************
 * Local Functions
 ***************************************************************************/
//extern void SetBtPathName(char *folderName, char *fileName);	
//extern F_HANDLE GetAITFHandleFromFid(int fid);
//extern Int16 SaveAITFHandle(Int16 type, F_HANDLE hfile, const char *folderName, const char *name);
//extern u_short fs_Init(void);  
extern Int8 *utCompressStrcpy (Int8 *strDst_p, const Int16 *strSrc_p);
extern Int16 *utExpandStrcpy(Int16  *strDst_p, const Char  *strSrc_p);
extern void afmfExfsConvertFileNameToUTF8Type(Int16 *longFileName, char *utf8FileName);
extern	SignedInt32	utStrcmpUcs2(const Int16 *str1_p, const Int16 *str2_p);
	
	
/* BT_COMMON_KIMSANGJIN_070315 */
/////////////////////////////////////////////////////////////////////////////////////////
#define MAX_TABLE_SIZE		8
#define AIT_FILE_ID 0x7F
Int16 AITFIDOffset = AIT_FILE_ID;

typedef struct
{
	Int16 type; /* folder type */
	int   fid; /* file id */
       F_HANDLE hfile;
	char  name[AIT_MAX_FILE_NAME_LEN]; 	/* file name */
	//char  folderName[BT_MMI_FILENAME_SIZE+1]; /* folder name */
}
MappingTable;

static Int16 gTableCnt = 0;
static MappingTable gMappingTable[MAX_TABLE_SIZE];

static Int16 GetSeperateCounts(char *str)
{
    Int8 i;
    Int16 cnt =0;	
	
    for(i=0; i<strlen(str); i++)
    {
		if(str[i] == '\\')
		{
			cnt++;
		}
    }
    BT_DEBUG(("GetSeperateCounts[%d]",cnt));
    return cnt;
}
void initExfsFid(void)
{
	int i;
	for (i = 0; i < MAX_TABLE_SIZE; i++)
	{
		memset(&gMappingTable[i],0x00,sizeof(MappingTable));
	}	
}
	
F_HANDLE GetAITFHandleFromFid(int fid)
{
	F_HANDLE hfile = {0,0};
	Int16 i;

	for (i = 0; i < gTableCnt; i++)
	{
		if (gMappingTable[i].fid == fid)
		{
			return gMappingTable[i].hfile;
		}
	}	
	return hfile;
}

int SaveAITFHandle(Int16 type, F_HANDLE hfile/*, const char *folderName*/, const char *name)
{
	if (gTableCnt < MAX_TABLE_SIZE)
	{
		gMappingTable[gTableCnt].type = type;
		gMappingTable[gTableCnt].fid  = hfile.file_handle + AITFIDOffset;
		gMappingTable[gTableCnt].hfile = hfile;
		//strcpy(gMappingTable[gTableCnt].folderName, folderName);
		strcpy(gMappingTable[gTableCnt].name, name);
		gTableCnt++;

		return (hfile.file_handle + AITFIDOffset);
	}
	else
	{
		BT_DEBUG(("SaveAITFHandle(): no more space"));
		return -1; /* Tiburona BT_050928 */
	}
}

void DeleteFid(int fid)
{
	Int16 i;

	for (i = 0; i < gTableCnt; i++)
	{
		if (gMappingTable[i].fid == fid)
		{
			for (; i < gTableCnt; i++)
				memcpy(&(gMappingTable[i]), &(gMappingTable[i+1]), sizeof(MappingTable));
			gTableCnt--;
			return;
		}
	}
	
	BT_DEBUG(("DeleteFid(): invalid fid=%d", fid));
}

char *GetNameByFid(int fid)
{
	Int16 i;

	for (i = 0; i < gTableCnt; i++)
	{
		if (gMappingTable[i].fid == fid)
			return gMappingTable[i].name;
	}
	return NULL;
}
#if 0
void SaveFid(Int16 type, int fid /*,const char *folderName */,const char *name)
{
	if (gTableCnt < MAX_TABLE_SIZE)
	{
		gMappingTable[gTableCnt].type = type;
		gMappingTable[gTableCnt].fid  = fid;
		gMappingTable[gTableCnt].hfile.cluster = 0;
		gMappingTable[gTableCnt].hfile.file_handle = 0;
		//strcpy(gMappingTable[gTableCnt].folderName, folderName);
		strcpy(gMappingTable[gTableCnt].name, name);
		gTableCnt++;
	}
	else
		BT_DEBUG0("SaveFid(): no more space");
}
char *GetFolderNameByFid(int fid)
{
	Int16 i;

	for (i = 0; i < gTableCnt; i++)
	{
		if (gMappingTable[i].fid == fid)
			return gMappingTable[i].folderName;
	}
	return NULL;
}

Int16 GetFolderTypeByFid(int fid)
{
	Int16 i;

	for (i = 0; i < gTableCnt; i++)
	{
		if (gMappingTable[i].fid == fid)
			return gMappingTable[i].type;
	}
	return BT_FOLDER_TYPE_INVALID;
}
#endif
/////////////////////////////////////////////////////////////////////////////////////////
L1ExfsOpenMode GetExfsOpenMode(char *mode)
{
     if((strcmp(mode,"w") == 0) ||(strcmp(mode,"w+") == 0) ||(strcmp(mode,"a") == 0) ||(strcmp(mode,"a+") == 0))
     {
	 	return AIT_NOT_IF_EXIST;
     }
     else if((strcmp(mode,"r") == 0) || (strcmp(mode,"r+") == 0))
     {
	 	return AIT_OPEN_R;
     }
     else
     {
               BT_DEBUG(("GetExfsOpenMode Error [%s]",mode));
		 return NUM_OF_AIT_OPENMODE;
     }
}

static void ParsePathName(const char *fullPath, char *folderName, char *fileName)
{
	Int16 i;
	char *last; /* pointer to the last occurrence of '\\' */
	const char *ptr;

	last = strrchr(fullPath, '\\');
	if (last == fullPath)
	{
		strcpy(folderName, "\\");
		strcpy(fileName, fullPath+1);
	}
	else
	{
		i = 0;		
		for (ptr = fullPath; *ptr != '\0'; ptr++)
		{
			if (*ptr == '\\')
			{
				if (ptr == last)
				{
					folderName[i] = '\0';
					break;
				}
				else
				{
#if 0				
					i = 0;
#else
					folderName[i] = *ptr;
					i++;
#endif				
				}
			}
			else
			{
				folderName[i] = *ptr;
				i++;
			}
		}
		strcpy(fileName, ptr+1);
		BT_DEBUG(("ParsePathName() folderName[%s] filename[%s]",folderName,fileName));
	}
}

static void BtStrUpr(char *string)
{
	for (; *string; string++)
	{
		if ('a' <= *string && *string <= 'z')
			*string = *string - 'a' + 'A';
	}
}

static void ExfsConvertInt16ToUTF8(Int16 *Int16FileName, char *utf8FileName)
{
	char *temp_string1 = PNULL;
	Int16 len = 0, i;
	Int8 gap = 'a' - 'A';
	
	KiAllocZeroMemory(utStrlenUcs2(Int16FileName)*3+2, &temp_string1);
	ConvertUCS2toUTF8(Int16FileName, utStrlenUcs2(Int16FileName), (unsigned char*)temp_string1);
	len = strlen(temp_string1);
	for( i=0; i<len; i++ )
	{
		{
			if(temp_string1[i] >= 'a' && temp_string1[i] <= 'z')
       			*utf8FileName++ = temp_string1[i] -gap;
			else
				*utf8FileName++ = temp_string1[i];
		}
	}
	*utf8FileName = 0x00;

	KiFreeMemory(&temp_string1);
}

/* end of BT_COMMON_KIMSANGJIN_070315 */

static Int32 BtAitFTP_FileError(void)
{
	return gAitFileErrCode;
}


void BtSetaitActiveFlag(Boolean flag)
{
	aitActiveFlag=flag;
}

Boolean Exfs_state_flag = FALSE;
Boolean BtgetExfsState(void)
{
	return Exfs_state_flag;
}

void BtsetExfsState(Boolean flag)
{
	Exfs_state_flag=flag;
  	BT_DEBUG(("BtsetExfsState ACTIVE Setting Exfs_state_flag=%d", Exfs_state_flag));	
}

/*---------------------------------------------------------------/
 * Func Name : 	Btexfs_Activate
 * Desc          :      AIT ex File System Activate       
 * Return       :       
 *---------------------------------------------------------------*/
void Btexfs_activate (void)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	Boolean keepGoing = TRUE;
	if (BtgetExfsState() == TRUE)
        {
                BT_DEBUG(("Btaitfs.c> =====<User already using a AIT module so does not activation>====="));
                return;
        }

	BT_DEBUG(("<<<<<<<<<<<<<<Btexfs_Activate Start>>>>>>>>>>>>>>>>>>"));
	KiCreateSignal(SIG_L1EXFS_ACTIVE_REQ, sizeof(L1ExFsActiveReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1ExFsActiveReq));
	sendSignal.sig->l1ExFsActiveReq.taskId = Target_TaskId;
	sendSignal.sig->l1ExFsActiveReq.commandRef = commandRef;
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{  
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_ACTIVE_CNF &&	
			recvSignal.sig->l1ExFsActiveCnf.commandRef == commandRef ) 
		{
			keepGoing = FALSE;
		}
		else									
		{
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	}
	errCode = recvSignal.sig->l1ExFsActiveCnf.fsError;
	gAitFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);
	if (errCode != AIT_SUCCESS)
	{
  	  	BT_DEBUG(("<<<<<<<<<<<<<<Btexfs_Activate Error [%d]>>>>>>>>>>>>>>>>>>",errCode));	
	}
	else
	{
  	  	BT_DEBUG(("<<<<<<<<<<<<<<Btexfs_Activate SUCCESS>>>>>>>>>>>>>>>>>>"));
		BtSetaitActiveFlag(TRUE);
		BtsetExfsState(TRUE); 
	}
}

/*---------------------------------------------------------------/
 * Func Name : 	Btexfs_Deactivate
 * Desc          :      AIT ex File System Deactivate       
 * Return       :       
 *---------------------------------------------------------------*/
void Btexfs_deactivate (void)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	Boolean keepGoing = TRUE;
       /*Need keep AIT activate when multimedia was running sjkim_need*/
	   
	BT_DEBUG(("<<<<<<<<<<<<<< Btexfs_Deactivate Start>>>>>>>>>>>>>>>>>>"));
	KiCreateSignal(SIG_L1EXFS_DEACTIVE_REQ, sizeof(L1ExFsDeactiveReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1ExFsDeactiveReq));
	sendSignal.sig->l1ExFsDeactiveReq.taskId = Target_TaskId;
	sendSignal.sig->l1ExFsDeactiveReq.commandRef = commandRef;
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_DEACTIVE_CNF &&	
			recvSignal.sig->l1ExFsDeactiveCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->l1ExFsDeactiveCnf.fsError;
	gAitFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);
	if (errCode != AIT_SUCCESS)
	{
  	  	BT_DEBUG(("<<<<<<<<<<<<<< Btexfs_Deactivate Error>>>>>>>>>>>>>>>>>>"));	
	}
	else
	{
  	  	BT_DEBUG(("<<<<<<<<<<<<<< Btexfs_Deactivate SUCCESS>>>>>>>>>>>>>>>>>>"));
		BtSetaitActiveFlag(FALSE);
		BtsetExfsState(FALSE); /* Tiburona BT_050920 */
	}
}

/*---------------------------------------------------------------/
 * Func Name : 	btfs_exfs_open
 * Desc          :      AIT ex File Open    
 				fmode - open mode (AIT_ALWAYS_CREATE,AIT_NOT_IF_EXIST,AIT_OPEN_R,AIT_OPEN_W)
 * Return       :       hfile (F_HANDLE)
 *---------------------------------------------------------------*/
int  btfs_exfs_open(char  *short_filename_p, char *mode)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 long_filename[BT_AIT_FILE_NAME_LENGTH+1];
	char  folderpath[BT_AIT_FILE_NAME_LENGTH+1];
	char  filename[BT_AIT_FILE_NAME_LENGTH+1];
	FileNameChar		sourceFileFullPath[BT_AIT_FILE_NAME_LENGTH+1];
	FileNameChar		currentPath[BT_AIT_FILE_NAME_LENGTH+1];
	FileNameChar		srcFileName[BT_AIT_FILE_NAME_LENGTH+1];
	
	L1ExfsOpenMode fmode;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	Boolean keepGoing = TRUE;
	Boolean default_path =TRUE;
  	F_HANDLE h_file;
	int fid;
	Int8 idx;
	
       initExfsFid(); /*need to initialise*/
	Btexfs_activate();
	memset(long_filename, '\0',sizeof(Int16)*(BT_AIT_FILE_NAME_LENGTH+1));
	memset(folderpath, '\0',sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	memset(filename, '\0',sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	
	fmode =GetExfsOpenMode(mode); /*Coverting to file open mode*/

	ParsePathName(short_filename_p, folderpath, filename);
	BT_DEBUG(("btfs_exfs_open() folderpath :[%s]  filename[%s] mode[%d]",folderpath,filename,fmode));
	//utExpandStrcpy(long_filename, filename); /*noti_011084*/
	utUtf8ToUcs2(filename, strlen(filename), long_filename, BT_AIT_FILE_NAME_LENGTH+1);
	BtStrUpr(folderpath); 
	
	KiCreateSignal(SIG_L1EXFS_OPEN_REQ, sizeof(L1ExFsOpenReq), &sendSignal);
	memset(sendSignal.sig, 0x00, sizeof(L1ExFsOpenReq));
	
	sendSignal.sig->l1ExFsOpenReq.taskId =  Target_TaskId;
	sendSignal.sig->l1ExFsOpenReq.commandRef = commandRef;
	if( (fmode ==AIT_NOT_IF_EXIST) ||(fmode ==AIT_ALWAYS_CREATE) )
	{
		sendSignal.sig->l1ExFsOpenReq.short_filename_ptr = folderpath;
		sendSignal.sig->l1ExFsOpenReq.long_filename_ptr = long_filename;
	}
	else if((fmode ==AIT_OPEN_R))
	{
              for(idx = 0; idx< gExfsFilecounts; idx++)
              {     
                     /*Generally this routine need when BT FTS operation*/
			if(utStrcmpUcs2(aitFileInfo[idx].long_name,long_filename) == 0) 
			{
			       default_path =FALSE;
				BtStrUpr(filename); 
				strcat(folderpath, "\\");
				strcat(folderpath, aitFileInfo[idx].short_name);
				break;
			}
              }
			  
	       if(default_path == TRUE) /*If user send via BT then file path already set with short_name [FTC]*/
	       {
			   BtStrUpr(filename); 
			   strcat(folderpath, "\\");
			   strcat(folderpath, filename);
	       }
	       BT_DEBUG(("short_filename_ptr (folderpath) :[%s]",folderpath));
		sendSignal.sig->l1ExFsOpenReq.short_filename_ptr = folderpath;
		sendSignal.sig->l1ExFsOpenReq.long_filename_ptr = PNULL; /*not use when file read mode*/
	}
	else
	{
              BT_DEBUG(("Error case----------------------->"));
		sendSignal.sig->l1ExFsOpenReq.short_filename_ptr = folderpath;
		sendSignal.sig->l1ExFsOpenReq.long_filename_ptr = long_filename;
	}
	sendSignal.sig->l1ExFsOpenReq.mode = fmode;
	KiSendSignal(LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_OPEN_CNF &&	
			recvSignal.sig->l1ExFsOpenCnf.commandRef == commandRef ) 
			{
				BT_DEBUG(("recvSignal.sig->l1ExFsOpenCnf [%s]",recvSignal.sig->l1ExFsOpenCnf.return_short_newname_ptr));
				keepGoing = FALSE;
			}
			
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	
	h_file = recvSignal.sig->l1ExFsOpenCnf.hfile;
	errCode = recvSignal.sig->l1ExFsOpenCnf.fsError;
	gAitFileErrCode = errCode;
	
	fid=SaveAITFHandle(BT_FOLDER_TYPE_AIT, h_file, short_filename_p);

	//BT_DEBUG(("btfs_exfs_open short_path=%s open mode=%d, long_path=%d", short_filename_p, fmode, long_filename_p));
	KiDestroySignal (&recvSignal);
	if (errCode != AIT_SUCCESS)
	{
		BT_DEBUG(("btfs_exfs_open file_handle:%d, cluster:%d Error%d[FAIL]", h_file.file_handle, h_file.cluster,errCode));
		return EINVAL;
	}
	else
	{
		BT_DEBUG(("btfs_exfs_open file_handle[%d],h_file.cluster[%d], fid:%d[SUCCESS]", h_file.file_handle,h_file.cluster, fid));
		return fid;
	}	

}

/*---------------------------------------------------------------/
 * Func Name : 	btfs_exfs_write
 * Desc          :      AIT ex File Write       
 * Return       :       
 *---------------------------------------------------------------*/
int   btfs_exfs_write(int handle, void *buf, Int32 len)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int32 errCode;
	Boolean keepGoing = TRUE;
	Int16 commandRef = afglGetUniqueId();
	
	F_HANDLE hfile = GetAITFHandleFromFid(handle);

	BT_DEBUG(("btfs_exfs_write() file_handle[%d],h_file.cluster[%d], fid:%d[SUCCESS]", hfile.file_handle,hfile.cluster, handle));
	KiCreateSignal(SIG_L1EXFS_WRITE_REQ, sizeof(L1ExFsWriteReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1ExFsWriteReq));
	sendSignal.sig->l1ExFsWriteReq.taskId = Target_TaskId;
	sendSignal.sig->l1ExFsWriteReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsWriteReq.hfile =hfile;
	sendSignal.sig->l1ExFsWriteReq.buffer_ptr = buf;
	sendSignal.sig->l1ExFsWriteReq.count = len;	
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_WRITE_CNF &&	
			recvSignal.sig->l1ExFsWriteCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->l1ExFsWriteCnf.fsError;
	gAitFileErrCode = errCode;
	
	if (errCode != AIT_SUCCESS)
	{
  	 	BT_DEBUG(("btfs_exfs_write Error>errCode:%d", errCode));	
		return EINVAL;
	}
	else
	{
  	 	BT_DEBUG(("btfs_exfs_write SUCCESS size[%d]",len));
	       return len; /*If writing was success than return writed size*/
	}	
	KiDestroySignal (&recvSignal);
}

/*---------------------------------------------------------------/
 * Func Name : 	btfs_exfs_read
 * Desc          :      AIT ex File Read  (read the contents from file to buffer_p)
			  	hfile: handle of opened file
				buffer_p: data buffer pointer that should be read from the disk
			 	count: data size that shoul be read from the disk
			 	p_read_count (result): data size that was read from the disk
 * Notes:
 *  				buffer_p must be prepared for the bytes lager than "count"	 	
 * Return       :       
 *---------------------------------------------------------------*/ 
int btfs_exfs_read(int handle, void *buf, Int32 len)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int32 errCode;
	Boolean keepGoing = TRUE;
       int p_read_count=0;/* BT_COMMON_KIMSANGJIN_070430 */
	Int16 commandRef = afglGetUniqueId();
	F_HANDLE hfile = GetAITFHandleFromFid(handle);

	//BT_DEBUG(("btfs_exfs_read Start  handle[%d] hfile[%d]",handle,hfile));
	KiCreateSignal(SIG_L1EXFS_READ_REQ, sizeof(L1ExFsReadReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1ExFsReadReq));
	sendSignal.sig->l1ExFsReadReq.taskId = Target_TaskId;
	sendSignal.sig->l1ExFsReadReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsReadReq.hfile = hfile;
	sendSignal.sig->l1ExFsReadReq.buffer_ptr = buf;
	sendSignal.sig->l1ExFsReadReq.count = len;	
 	//BT_DEBUG(("btfs_exfs_read count=%d", len)); 
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_READ_CNF &&	
			recvSignal.sig->l1ExFsReadCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	p_read_count =(int) recvSignal.sig->l1ExFsReadCnf.p_read_count;
	errCode = recvSignal.sig->l1ExFsReadCnf.fsError;
	gAitFileErrCode = errCode;
	KiDestroySignal (&recvSignal);
	
/* BT_COMMON_KIMSANGJIN_070430 noti_011061 */
	if (errCode == AIT_SUCCESS || errCode ==AIT_ERR_EOF)
	{
		BT_DEBUG(("btfs_exfs_read( req size[%d]) cnf size[%d]",len,p_read_count));
		return p_read_count;
	}
	else
	{
  	 	BT_DEBUG(("btfs_exfs_read Error>errCode:%d", errCode));	
		return EINVAL;
	}	
/* end of BT_COMMON_KIMSANGJIN_070430 */
}

/*---------------------------------------------------------------/
 * Func Name : 	btfs_exfs_close
 * Desc          :      AIT ex File Close       
 * Return       :       
 *---------------------------------------------------------------*/
 int btfs_exfs_close (int handle)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int32 errCode;
	
	Int16 commandRef = afglGetUniqueId();
	Boolean keepGoing = TRUE;
	
	F_HANDLE hfile = GetAITFHandleFromFid(handle);
	
	BT_DEBUG(("btfs_exfs_close Start"));
	//BT_DEBUG1("BtAitFileClose()> file path :%s", GetNameByFid(fid));
	DeleteFid(handle);
	
	KiCreateSignal(SIG_L1EXFS_CLOSE_REQ, sizeof(L1ExFsCloseReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1ExFsCloseReq));
	sendSignal.sig->l1ExFsCloseReq.taskId = Target_TaskId;
	sendSignal.sig->l1ExFsCloseReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsCloseReq.hfile =hfile;
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_CLOSE_CNF &&	
			recvSignal.sig->l1ExFsCloseCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->l1ExFsCloseCnf.fsError;
	gAitFileErrCode = errCode;
	KiDestroySignal (&recvSignal);
	Btexfs_deactivate();
	if (errCode != AIT_SUCCESS)
	{
  	 	BT_DEBUG(("btfs_exfs_close Error>errCode[%d]", errCode));	
		return EINVAL;
	}
	else
	{
  	 	BT_DEBUG(("btfs_exfs_close SUCCESS"));
		return 0;
	}
}

/*---------------------------------------------------------------/
 * Func Name : 	btfs_exfs_remove
 * Desc          :      AIT ex File Remove       
 * Return       :       
 *---------------------------------------------------------------*/
int btfs_exfs_remove (char *fileNamepath)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	Int8 idx;
	Int16 *long_filename =PNULL;
	char  folderpath[AIT_SHORTNAME_SIZE+1];
	char  filename[BT_AIT_FILE_NAME_LENGTH+1];
	
	Boolean keepGoing = TRUE;
	Btexfs_activate(); /*noti_011072*/

	BT_DEBUG(("btfs_exfs_remove Start() %s",fileNamepath));
	
	KiAllocZeroMemory ( (BT_AIT_FILE_NAME_LENGTH+1) * sizeof (Int16), (void **) &long_filename );
       if(long_filename == PNULL)  return EINVAL;
	   
	memset(folderpath,0x00,sizeof(char)*(AIT_SHORTNAME_SIZE+1));
	memset(filename,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	
	ParsePathName(fileNamepath, folderpath, filename);
	BtStrUpr(folderpath); /*noti_011079*/
	//utExpandStrcpy(long_filename, filename);
	utUtf8ToUcs2(filename, strlen(filename), long_filename, BT_AIT_FILE_NAME_LENGTH+1); /*noti_011072*/
#if 1
	for(idx = 0; idx< gExfsFilecounts; idx++)
	{
		if(utStrcmpUcs2(aitFileInfo[idx].long_name,long_filename) == 0)
		{
			BtStrUpr(filename); 
			strcat(folderpath, "\\");
			strcat(folderpath, aitFileInfo[idx].short_name);
			break;
		}
	}
#else
	BtStrUpr(folderpath); 
	BtStrUpr(filename);  /*check sjkim*/
	strcat(folderpath, "\\");
	strcat(folderpath, filename);/*make full path it need check sjkim*/
#endif	
	BT_DEBUG(("btfs_exfs_remove() filename:%s ",folderpath));
	
	KiCreateSignal(SIG_L1EXFS_REMOVE_REQ, sizeof(L1ExFsRemoveReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1ExFsRemoveReq));
	sendSignal.sig->l1ExFsRemoveReq.taskId = Target_TaskId;
	sendSignal.sig->l1ExFsRemoveReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsRemoveReq.filename_ptr= folderpath; /*It is a full path short name (Not folderpath)*/
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_REMOVE_CNF &&	
			recvSignal.sig->l1ExFsRemoveCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->l1ExFsRemoveCnf.fsError;
	gAitFileErrCode = errCode;
	
	KiFreeMemory ((void**)&long_filename );
	KiDestroySignal (&recvSignal);
	Btexfs_deactivate(); /*noti_011072*/
	if (errCode != AIT_SUCCESS)
	{
  	 	BT_DEBUG(("btfs_exfs_remove Error>errCode:%d", errCode));	
		return EINVAL;
	}
	else
	{
  	 	BT_DEBUG(("btfs_exfs_remove SUCCESS"));
		return 0;
	}
}

/*---------------------------------------------------------------/
 * Func Name : 	btfs_exfs_stat
 * Desc          :      AIT ex File Statistics    
 * Return       :       
 *---------------------------------------------------------------*/
 
/*sjkim_need check char *fileName, Stat *statBuf_pt*/
int btfs_exfs_stat(char *fileName, FileInform *fileInform)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	Boolean keepGoing = TRUE;
	Int32 free_cluster_number;
	Int32 free_byte_number;
	Int32 total_cluster_number;
	Int32 total_byte_number;
	Int32 freeSpace=0;

	BT_DEBUG(("btfs_exfs_stat Start"));
	KiCreateSignal(SIG_L1EXFS_STATISTICS_REQ, sizeof(L1ExFsStatisticsReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1ExFsStatisticsReq));
	sendSignal.sig->l1ExFsStatisticsReq.taskId = Target_TaskId;
	sendSignal.sig->l1ExFsStatisticsReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsStatisticsReq.device= AIT_EXTERNAL; /* AIT_EXTERNAL only support for BT FTP*/
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_STATISTICS_CNF &&	
			recvSignal.sig->l1ExFsStatisticsCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}

	free_cluster_number = recvSignal.sig->l1ExFsStatisticsCnf.free_cluster_number;
	free_byte_number = recvSignal.sig->l1ExFsStatisticsCnf.free_byte_number;
	total_cluster_number = recvSignal.sig->l1ExFsStatisticsCnf.total_cluster_number;
	total_byte_number = 	recvSignal.sig->l1ExFsStatisticsCnf.total_byte_number;	
	errCode = recvSignal.sig->l1ExFsStatisticsCnf.fsError;
	gAitFileErrCode = errCode;
	freeSpace = free_byte_number;
	KiDestroySignal (&recvSignal);

	if (errCode != AIT_SUCCESS)
	{
  	 	BT_DEBUG(("btfs_exfs_stat Error>errCode:%d", errCode));	
		return EINVAL;
	}
	else
	{
  	 	BT_DEBUG(("btfs_exfs_stat SUCCESS freeSpace[%d]",freeSpace));
		return freeSpace;
	}
}

static void CopyAgChar2Char(char *chStr, AgCharCode *agStr, Int16 len)
{
	Int16 i;

	for (i = 0; i < len; i++)
		chStr[i] = (char) agStr[i];
	chStr[i] = '\0';
}

/* BT_COMMON_KIMSANGJIN_070418 */
int btfs_exfs_info(char *fileName, FileInform *fileInform)
{
#if defined(btfs_exfs_temp) /* To Do : l1exfs have to add*/	
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	Boolean keepGoing = TRUE;
	Boolean found_name = FALSE;
	Int8 idx;
	Int16 long_filename[BT_AIT_FILE_NAME_LENGTH+1];
	char  folderpath[BT_AIT_FILE_NAME_LENGTH+1];
	char  filename[BT_AIT_FILE_NAME_LENGTH+1];
	
	char  tmpstr[BT_AIT_FILE_NAME_LENGTH+1];
	memset(tmpstr,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
		
	BT_DEBUG(("btfs_exfs_info [%s]",fileName));
	
	memset(long_filename, '\0',sizeof(Int16)*(BT_AIT_FILE_NAME_LENGTH+1));
	memset(folderpath, '\0',sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	memset(filename, '\0',sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	   
	ParsePathName(fileName, folderpath, filename);
	BT_DEBUG(("btfs_exfs_info() folderpath :[%s]  filename[%s] ",folderpath,filename));
	
		
	//utExpandStrcpy(long_filename, filename); /*noti_011084*/
	utUtf8ToUcs2(filename, strlen(filename), long_filename, BT_AIT_FILE_NAME_LENGTH+1);
	BtStrUpr(folderpath); 

#if 1	
	/*need folder check with filename */
	if(strlen(filename) == 0) /*It means request a folder informations or */
	{
	        BT_DEBUG(("I want see this debug message, if it does not apear I will remove below code until #endif huhuhu~~>>>>>>"));
	        for(idx = 0; idx< gExfsFilecounts; idx++)
	        {     
			if(utStrcmpUcs2(aitFileInfo[idx].long_name,long_filename) == 0) 
			{
			       found_name=TRUE;
				break;
			}
			else
			{
				found_name =FALSE;
			}
	        }
			
	        if(found_name == TRUE)
	        {
			fileInform->attribute=aitFileInfo[idx].stat.attr;
			fileInform->size =aitFileInfo[idx].stat.size;
			memcpy(fileInform->file_name,aitFileInfo[idx].long_name,(sizeof(u_short)*(AIT_MAX_FILE_NAME_LEN>>1) + 1 ));
			
			   /*Time information setting*/
			fileInform->year=aitFileInfo[idx].stat.time.year; 		
			fileInform->month=aitFileInfo[idx].stat.time.month;
			fileInform->day=aitFileInfo[idx].stat.time.day;
			fileInform->hours=aitFileInfo[idx].stat.time.hour;
			fileInform->minutes=aitFileInfo[idx].stat.time.min;
			fileInform->seconds=aitFileInfo[idx].stat.time.sec;
			BT_DEBUG(("End of btfs_exfs_info() was success in Folder side 1"));
			//Btexfs_deactivate();
		 	return AIT_SUCCESS;
	        }
	        else
	        {
	              //Btexfs_deactivate();
	              BT_DEBUG(("End of btfs_exfs_info() was fail in Folder side"));
			return EINVAL;
	        }
	}
#endif

	 CopyAgChar2Char(tmpstr,long_filename,utStrlenUcs2(long_filename));
        BT_DEBUG(("long_filename[%s]   gExfsFilecounts(%d)",tmpstr,gExfsFilecounts));
	 for(idx = 0; idx< gExfsFilecounts; idx++)
        {     
		BT_DEBUG(("---------------------------------------------------------"));
		memset(tmpstr,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
		CopyAgChar2Char(tmpstr,aitFileInfo[idx].long_name,utStrlenUcs2(aitFileInfo[idx].long_name));
		BT_DEBUG(("aitFileInfo[%d].long_name[%s]",idx,tmpstr));
		
               /*Generally this routine need when BT FTS operation*/
		if(utStrcmpUcs2(aitFileInfo[idx].long_name,long_filename) == 0) 
		{
		       BT_DEBUG(("Found same long name & aitFileInfo[idx].stat.attr [0x%x]",aitFileInfo[idx].stat.attr));
			fileInform->attribute=(Int32)aitFileInfo[idx].stat.attr;
			fileInform->size =(Int32)aitFileInfo[idx].stat.size;
			if(utStrlenUcs2(aitFileInfo[idx].long_name) >FILE_NAME_SIZE)
			{
				   BT_DEBUG(("Exception case.......................................Error length[%s] was big",utStrlenUcs2(aitFileInfo[idx].long_name) ));
				memcpy(fileInform->file_name,aitFileInfo[idx].long_name,sizeof(u_short)*(utStrlenUcs2(aitFileInfo[idx].long_name) ));
			}
			else
			{
			 memcpy(fileInform->file_name,aitFileInfo[idx].long_name,sizeof(u_short)*(utStrlenUcs2(aitFileInfo[idx].long_name) ));
			}
			/*Time information setting*/ 
			fileInform->year=(Int16)aitFileInfo[idx].stat.time.year;	
			fileInform->month=(int)aitFileInfo[idx].stat.time.month;
			fileInform->day=(int)aitFileInfo[idx].stat.time.day;
			fileInform->hours=(int)aitFileInfo[idx].stat.time.hour;
			fileInform->minutes=(int)aitFileInfo[idx].stat.time.min;
			fileInform->seconds=(int)aitFileInfo[idx].stat.time.sec;
			BT_DEBUG(("End of btfs_exfs_info() was success in Folder side 2"));
			//Btexfs_deactivate();
			return AIT_SUCCESS;
		}
		else
		{
			found_name=FALSE;
		}
        }
		
       if(found_name == FALSE) /*Use defualt file name which should be short name type*/
       {
		   BtStrUpr(filename); 
		   strcat(folderpath, "\\");
		   strcat(folderpath, filename);
       }
	   
#if 1 /*noti_011087*/
	fileInform->attribute=0X207;//recvSignal.sig->l1ExFsGetFileInfoCnf.p_file_attribute; /*noti_011085 0x7 ->0x207*/
	fileInform->size=0;
	fileInform->year=  0;
	fileInform->month=0;
	fileInform->day=0;
	fileInform->hours=0;
	fileInform->minutes=0;
	fileInform->seconds=0;
	BT_DEBUG(("End of btfs_exfs_info SUCCESS "));
	return AIT_SUCCESS;
#endif
       Btexfs_activate();
	   	
	BT_DEBUG(("l1ExFsGetFileInfoReq.filename_ptr [%s] commandRef[%d]",folderpath,commandRef));
	KiCreateSignal(SIG_L1EXFS_GET_FILE_INFO_REQ, sizeof(L1ExFsGetFileInfoReq), &sendSignal);
	
	memset(sendSignal.sig, 0, sizeof(L1ExFsGetFileInfoReq));
	sendSignal.sig->l1ExFsGetFileInfoReq.taskId = Target_TaskId;
	sendSignal.sig->l1ExFsGetFileInfoReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsGetFileInfoReq.filename_ptr= folderpath;
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_GET_FILE_INFO_CNF &&	
			recvSignal.sig->l1ExFsGetFileInfoCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}

	BT_DEBUG(("Rcv SIG_L1EXFS_GET_FILE_INFO_CNF.....................we guess this is a directory"));
	fileInform->attribute=0X207;//recvSignal.sig->l1ExFsGetFileInfoCnf.p_file_attribute; /*noti_011085 0x7 ->0x207*/
	fileInform->size=(Int32)recvSignal.sig->l1ExFsGetFileInfoCnf.p_size;
	fileInform->year=  (Int16)recvSignal.sig->l1ExFsGetFileInfoCnf.p_time.year;
	fileInform->month=(int)recvSignal.sig->l1ExFsGetFileInfoCnf.p_time.month;
	fileInform->day=(int)recvSignal.sig->l1ExFsGetFileInfoCnf.p_time.day;
	fileInform->hours=(int)recvSignal.sig->l1ExFsGetFileInfoCnf.p_time.hour;
	fileInform->minutes=(int)recvSignal.sig->l1ExFsGetFileInfoCnf.p_time.min;
	fileInform->seconds=(int)recvSignal.sig->l1ExFsGetFileInfoCnf.p_time.sec;
	
	errCode = recvSignal.sig->l1ExFsGetFileInfoCnf.fsError;	
	gAitFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);

	if (errCode != AIT_SUCCESS)
	{
		Btexfs_deactivate();
		BT_DEBUG(("End of btfs_exfs_info Error>errCode:%d", errCode));	
		return EINVAL;
	}
	else
	{
		Btexfs_deactivate();
		BT_DEBUG(("End of btfs_exfs_info SUCCESS "));
		return AIT_SUCCESS;
	}
#else
  	 	BT_DEBUG(("[btfs_exfs.c] To Do : Add the signal for btfs_exfs_info() "));
	return AIT_SUCCESS;
#endif /* btfs_exfs_temp */	
}
/* end of BT_COMMON_KIMSANGJIN_070418 */

/*---------------------------------------------------------------/
 * Func Name : 	btfs_exfs_size
 * Desc          :      AIT ex File Size       
 * Return       :       
 *---------------------------------------------------------------*/
Int32 btfs_exfs_size(char * filename_p)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	Boolean keepGoing = TRUE;
	Int32 p_size=0;

	//BT_DEBUG(("btfs_exfs_size Start"));
	KiCreateSignal(SIG_L1EXFS_FILE_GETSIZE_REQ, sizeof(L1ExFsFileGetsizeReq), &sendSignal);
	memset(sendSignal.sig, 0x00, sizeof(L1ExFsFileGetsizeReq));

	sendSignal.sig->l1ExFsFileGetsizeReq.filename_ptr = filename_p;
	sendSignal.sig->l1ExFsFileGetsizeReq.taskId =  Target_TaskId;
	sendSignal.sig->l1ExFsFileGetsizeReq.commandRef = commandRef;
	KiSendSignal (LGE_EXT_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_FILE_GETSIZE_CNF &&	
			recvSignal.sig->l1ExFsFileGetsizeCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	p_size = recvSignal.sig->l1ExFsFileGetsizeCnf.p_size;
	errCode = recvSignal.sig->l1ExFsFileGetsizeCnf.fsError;
	gAitFileErrCode = errCode;
	KiDestroySignal (&recvSignal);

	if (errCode != AIT_SUCCESS)
	{
  	 	BT_DEBUG(("btfs_exfs_size Error>errCode:%d", errCode));	
		return EINVAL;
	}
	else
	{
  	 	BT_DEBUG(("btfs_exfs_size  size[%d] -> SUCCESS", p_size));
		return p_size;
	}
}

/*==============================================================================
**  Function    : btfs_exfs_getlist
**  Parameters:
**			   dirname_p - the folder name for searching.
** 			   fileIndex - start file index of file list
**			   file_num - the number of file-info wish to have
**  Returns: None
**  Descreation : Get file list in specific folder
**                      Get the file_num file lists from fileIndex among total file list in specific folder
**==============================================================================*/
Int32 btfs_exfs_filegetlist(Char * dirname_p, Int16 file_Index, Int16 file_num)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	u_short i;
	Boolean keepGoing = TRUE;
	char  dirpath[BT_AIT_FILE_NAME_LENGTH+1];
	char  filename[BT_AIT_FILE_NAME_LENGTH+1];
	sFILEINFO *file_list_ptr = PNULL;

	KiAllocZeroMemory ( EXFS_NUM_OF_GET_FILELIST * sizeof (sFILEINFO), (void **) &file_list_ptr );
       if(file_list_ptr == PNULL)  return EINVAL;
	   
	memset(dirpath,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	memset(filename,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	
	BT_DEBUG(("btfs_exfs_getlist path [%s] idx[%d] num[%d]",dirname_p,file_Index,file_num));
	
	KiCreateSignal(SIG_L1EXFS_FILE_GETLIST_REQ, sizeof(L1ExFsFileGetlistReq), &sendSignal);
	memset(sendSignal.sig, 0x00, sizeof(L1ExFsFileGetlistReq));

	sendSignal.sig->l1ExFsFileGetlistReq.dirname_ptr = dirname_p;
	sendSignal.sig->l1ExFsFileGetlistReq.file_index = file_Index;	
	sendSignal.sig->l1ExFsFileGetlistReq.file_num = file_num;
	sendSignal.sig->l1ExFsFileGetlistReq.taskId =  Target_TaskId;
	sendSignal.sig->l1ExFsFileGetlistReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsFileGetlistReq.file_list = file_list_ptr;
	KiSendSignal( LGE_EXT_FILESYS_TASK_ID, &sendSignal );  

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_FILE_GETLIST_CNF &&	
			recvSignal.sig->l1ExFsFileGetlistCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->l1ExFsFileGetlistCnf.fsError;
	gAitFileErrCode = errCode;

	if( errCode == AIT_SUCCESS )
	{
		BT_DEBUG(("<SIG_L1EXFS_FILE_GETLIST_CNF File  OK get_file_num[%d]>", recvSignal.sig->l1ExFsFileGetlistCnf.get_file_num));
		//BT_DEBUG(("============================================================"));
		for(i=0; i<recvSignal.sig->l1ExFsFileGetlistCnf.get_file_num; i++)
		{	
		
			//BT_DEBUG(("btfs_exfs_getlist  short_name[%d][%s]",i,file_list_ptr[i].short_name));
			memset( &aitFileInfo[exfs_idx], 0x00, sizeof(sFILEINFO) );
			memcpy( aitFileInfo[exfs_idx].short_name, file_list_ptr[i].short_name, 14 );

			if( file_list_ptr[i].long_name[0] == 0 ) /*If there is no long name, make long name with short name*/
			{
				ConvertUTF8toUCS2(aitFileInfo[exfs_idx].short_name, strlen(aitFileInfo[exfs_idx].short_name), aitFileInfo[exfs_idx].long_name);
			}
			else
			{
				utStrcpyUcs2(aitFileInfo[exfs_idx].long_name, file_list_ptr[i].long_name);
			}
			
			aitFileInfo[exfs_idx].stat.attr = 0X7;//file_list_ptr[i].stat.attr; /*make same with FDI*/
			aitFileInfo[exfs_idx].stat.size= file_list_ptr[i].stat.size;
			aitFileInfo[exfs_idx].stat.time.year = file_list_ptr[i].stat.time.year;
			aitFileInfo[exfs_idx].stat.time.month = file_list_ptr[i].stat.time.month;
			aitFileInfo[exfs_idx].stat.time.day = file_list_ptr[i].stat.time.day;
			aitFileInfo[exfs_idx].stat.time.hour= file_list_ptr[i].stat.time.hour;
			aitFileInfo[exfs_idx].stat.time.min= file_list_ptr[i].stat.time.min;
			aitFileInfo[exfs_idx].stat.time.sec= file_list_ptr[i].stat.time.sec;
			aitFileInfo[exfs_idx].stat.time.msec= file_list_ptr[i].stat.time.msec;
#if 0		/*debug option*/	
			BT_DEBUG(("aitFileInfo[i].stat.attr [0x%x]",aitFileInfo[exfs_idx].stat.attr));
			BT_DEBUG(("aitFileInfo[i].stat.size [%d]",aitFileInfo[exfs_idx].stat.size));
			BT_DEBUG(("file_list_ptr[i].stat.attr [0x%x]",file_list_ptr[i].stat.attr));
			BT_DEBUG(("file_list_ptr[i].stat.size [%d]",file_list_ptr[i].stat.size));
			BT_DEBUG(("============================================================"));
#endif			
			exfs_idx++;
		}
	}
	else
	{
  	 	BT_DEBUG(("btfs_exfs_getlist Error> errCode:%d", errCode));	
		Btexfs_deactivate();
		KiFreeMemory ((void**)&file_list_ptr );
		KiDestroySignal (&recvSignal);
		return EINVAL;
	}
	KiFreeMemory ((void**)&file_list_ptr );
	KiDestroySignal (&recvSignal);
	return errCode;
}

/*==============================================================================
**  Function    : btfs_exfs_dirgetlist
**  Parameters:
**			   dirname_p - the folder name for searching.
** 			   fileIndex - start file index of file list
**			   file_num - the number of file-info wish to have
**  Returns: None
**  Descreation : Get dir list in specific folder
**                      Get the file_num file lists from fileIndex among total file list in specific folder
**==============================================================================*/
Int32 btfs_exfs_dirgetlist(Char * dirname_p, Int16 file_Index, Int16 file_num)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	u_short i;
	Boolean keepGoing = TRUE;
	sFILEINFO *file_list_ptr = PNULL;
	char  dirpath[BT_AIT_FILE_NAME_LENGTH+1];
	char  filename[BT_AIT_FILE_NAME_LENGTH+1];
	/////
	Int8   strDst_p[BT_AIT_FILE_NAME_LENGTH];
	
	BT_DEBUG(("btfs_exfs_dirgetlist Start :%s",dirname_p));
	
	KiAllocZeroMemory ( EXFS_NUM_OF_GET_DIRLIST * sizeof (sFILEINFO), (void **) &file_list_ptr );
       if(file_list_ptr == PNULL)  
	{
		Btexfs_deactivate();
	   	return EINVAL;
       }
	   
	memset(dirpath,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	memset(filename,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	
	BT_DEBUG(("btfs_exfs_dirgetlist() dirname_ptr[%s] idx[%d] num[%d]",dirname_p,file_Index,file_num));
	
	KiCreateSignal(SIG_L1EXFS_DIR_GETLIST_REQ, sizeof(L1ExFsDirGetlistReq), &sendSignal);
	memset(sendSignal.sig, 0x00, sizeof(L1ExFsDirGetlistReq));

	sendSignal.sig->l1ExFsDirGetlistReq.dirname_ptr = dirname_p;
	sendSignal.sig->l1ExFsDirGetlistReq.file_index = file_Index;	
	sendSignal.sig->l1ExFsDirGetlistReq.file_num = file_num;
	sendSignal.sig->l1ExFsDirGetlistReq.taskId =  Target_TaskId;
	sendSignal.sig->l1ExFsDirGetlistReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsDirGetlistReq.file_list = file_list_ptr;
	KiSendSignal( LGE_EXT_FILESYS_TASK_ID, &sendSignal );  

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_DIR_GETLIST_CNF &&	
			recvSignal.sig->l1ExFsDirGetlistCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->l1ExFsDirGetlistCnf.fsError;
	gAitFileErrCode = errCode;
	

	if( errCode == AIT_SUCCESS )
	{
		BT_DEBUG(("Rcv btfs_exfs_dirgetlist() cnf <OK> get_file_num[%d]", recvSignal.sig->l1ExFsDirGetlistCnf.get_file_num));
		//BT_DEBUG(("============================================================"));
		for(i=0; i<recvSignal.sig->l1ExFsDirGetlistCnf.get_file_num; i++)
		{	
			//BT_DEBUG(("btfs_exfs_dirgetlist() short_name[%d][%s]",i,file_list_ptr[i].short_name));
			memset( &aitFileInfo[exfs_idx], 0x00, sizeof(sFILEINFO));
			memcpy( aitFileInfo[exfs_idx].short_name, file_list_ptr[i].short_name, 14 );
			
			if( file_list_ptr[i].long_name[0] == 0 ) /*If there is no long name, make long name with short name*/
			{
				ConvertUTF8toUCS2(aitFileInfo[exfs_idx].short_name, strlen(aitFileInfo[exfs_idx].short_name), aitFileInfo[exfs_idx].long_name);
			}
			else
			{
			       utStrcpyUcs2(aitFileInfo[exfs_idx].long_name, file_list_ptr[i].long_name);
			}
			aitFileInfo[exfs_idx].stat.attr =  0X207;//file_list_ptr[i].stat.attr;  /*make same with FDI*/
			aitFileInfo[exfs_idx].stat.size= file_list_ptr[i].stat.size;
			aitFileInfo[exfs_idx].stat.time.year = file_list_ptr[i].stat.time.year;
			aitFileInfo[exfs_idx].stat.time.month = file_list_ptr[i].stat.time.month;
			aitFileInfo[exfs_idx].stat.time.day = file_list_ptr[i].stat.time.day;
			aitFileInfo[exfs_idx].stat.time.hour= file_list_ptr[i].stat.time.hour;
			aitFileInfo[exfs_idx].stat.time.min= file_list_ptr[i].stat.time.min;
			aitFileInfo[exfs_idx].stat.time.sec= file_list_ptr[i].stat.time.sec;
			aitFileInfo[exfs_idx].stat.time.msec= file_list_ptr[i].stat.time.msec;

#if 0             /*debug option*/
			memset(strDst_p,0x00,sizeof(strDst_p));
			utCompressStrcpy(strDst_p,aitFileInfo[exfs_idx].long_name);
		       BT_DEBUG(("long file_name [%s]",strDst_p));
			BT_DEBUG(("aitFileInfo[%d] short_name[%d][%s]",exfs_idx,aitFileInfo[exfs_idx].short_name));
			BT_DEBUG(("aitFileInfo[i].stat.attr [0x%x]",aitFileInfo[exfs_idx].stat.attr));
			BT_DEBUG(("aitFileInfo[i].stat.size [%d]",aitFileInfo[exfs_idx].stat.size));
			BT_DEBUG(("============================================================"));
#endif			
			exfs_idx++;
			
		}
	}
	else
	{
  	 	BT_DEBUG(("btfs_exfs_dirgetlist Error> errCode:%d", errCode));	
		Btexfs_deactivate();
		KiFreeMemory ((void**)&file_list_ptr );
		KiDestroySignal (&recvSignal);
		return EINVAL;
	}
	BT_DEBUG(("End of btfs_exfs_dirgetlist was success"));
	KiFreeMemory ((void**)&file_list_ptr );
	KiDestroySignal (&recvSignal);
	return errCode;
}


/****************************************************************************
** Function:    btfs_exfs_count
** Parameters: 
**			  dirname_p - the name of directory requested to get the number of files
**			  attribute -EXFS_FILE : 0, EXFS_DIRECTORY : 1
** Returns:     Total File count
** Description: send ExFsFileCountReq signal
**                   
*****************************************************************************/
Int16 btfs_exfs_filecount (char * dirname_p, L1ExfsAttribMode attribute)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 file_count;
	Int32 errCode;
	char  dirpath[AIT_SHORTNAME_SIZE+1];
	char  filename[BT_AIT_FILE_NAME_LENGTH+1];
	Int16 commandRef = afglGetUniqueId();
	Boolean keepGoing = TRUE;

	BT_DEBUG(("btfs_exfs_count Start :%s [%d]",dirname_p,attribute));
	KiCreateSignal(SIG_L1EXFS_FILE_COUNT_REQ, sizeof(L1ExFsFileCountReq), &sendSignal);
	memset(sendSignal.sig, 0x00, sizeof(L1ExFsFileCountReq));

	sendSignal.sig->l1ExFsFileCountReq.taskId =  Target_TaskId;	
	sendSignal.sig->l1ExFsFileCountReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsFileCountReq.dirname_ptr = dirname_p;
	sendSignal.sig->l1ExFsFileCountReq.attribute = attribute;	
	KiSendSignal( LGE_EXT_FILESYS_TASK_ID, &sendSignal );

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_FILE_COUNT_CNF &&	
			recvSignal.sig->l1ExFsFileCountCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	file_count = recvSignal.sig->l1ExFsFileCountCnf.total_file_count;	
	errCode = recvSignal.sig->l1ExFsFileCountCnf.fsError;
	gAitFileErrCode = errCode;
	KiDestroySignal (&recvSignal);
	
	if (errCode != AIT_SUCCESS)
	{
  	  	BT_DEBUG(("BtafexfsSendFileCount Error>errCode:%d", errCode));	
		Btexfs_deactivate();
		return EINVAL;
	}
	else
	{
  	  	BT_DEBUG(("BtafexfsSendFileCount SUCCESS file_count=%d", file_count));
	}
	return file_count;
}

Int32 btfs_exfs_opendir(char *dirname_p)
{
       Boolean Stop =FALSE;
       Int16 file_count=0;
       Int16 dir_count=0;
	Int16 search_idx=0;   
	Int32 exfs_list;
	char dirpath[BT_AIT_FILE_NAME_LENGTH+1];
	Int8 idx;
	Int16 long_filename[BT_AIT_FILE_NAME_LENGTH+1];
	char  folderpath[BT_AIT_FILE_NAME_LENGTH+1];
	char  filename[BT_AIT_FILE_NAME_LENGTH+1];
	Boolean found_shortname =FALSE;
	Int16 depthcount;
	
	exfs_idx =0;   
	read_idx =0;
	
	Btexfs_activate();

	BT_DEBUG(("btfs_exfs_opendir [%s]...1",dirname_p));
	
/////////////////////////[making shortname with previous buffer information]//////////////////////////
	  memset(long_filename, '\0',sizeof(Int16)*(BT_AIT_FILE_NAME_LENGTH+1));
	  memset(folderpath, '\0',sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	  memset(filename, '\0',sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	  memset(dirpath,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
	  
	  ParsePathName(dirname_p, folderpath, filename);
	  BT_DEBUG(("btfs_exfs_opendir() folderpath :[%s]	filename[%s] ",folderpath,filename));
	  utExpandStrcpy(long_filename, filename);
	  BtStrUpr(folderpath); 

	  for(idx = 0; idx< gExfsFilecounts; idx++)
	  { 	
		if(utStrcmpUcs2(aitFileInfo[idx].long_name,long_filename) == 0) 
		{
			found_shortname =TRUE;
			BtStrUpr(filename); 
			sprintf(dirpath, "%s\\%s\\", folderpath, aitFileInfo[idx].short_name);
			break;
		}
	  }
//////////////////////////////////////////////////////////////////////////////////////	  

       if(found_shortname == FALSE)
       {
                BT_DEBUG(("[found_shortname] was not found so try to open dir with default path information"));
		  /*making dirpath which add a " \\" to last of dirname_p*/
		  BtStrUpr(filename); 
		  sprintf(dirpath, "%s\\%s", folderpath,filename); /*noti_011085*/
       }
	   
       BT_DEBUG(("btfs_exfs_opendir [%s]...2",dirpath));
	   

	////////////////[determine gdir_path] ////////////
	depthcount=GetSeperateCounts(dirpath);
	
	if(depthcount >= GetSeperateCounts(gdir_path.short_dir_path)) /*path was increase or indicate another folder in same directory*/
	{
        	/*use defualt dir path & copy current dir path*/
		memset(gdir_path.long_dir_path,0x00,sizeof(Int16)*(BT_AIT_FILE_NAME_LENGTH+1));
		memset(gdir_path.short_dir_path,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
		
		utStrcpyUcs2(gdir_path.long_dir_path,long_filename);
		
              if(found_shortname==TRUE)	/*noti_011085*/	
              {
		sprintf(gdir_path.short_dir_path, "%s\\%s", folderpath, aitFileInfo[idx].short_name);
              }
		else
		{
			sprintf(gdir_path.short_dir_path, "%s", dirpath); /*noti_011086 folderpath ->dirpath */
		}
		BT_DEBUG(("=====>Move to sub directory [%s]",gdir_path.short_dir_path));
	}
	else if(depthcount < GetSeperateCounts(gdir_path.short_dir_path))
	{
	       /*Move to previous directory*/
              BT_DEBUG(("Move to previous directory [%s]",gdir_path.short_dir_path));
		memset(folderpath, '\0',sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
		memset(filename, '\0',sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
		memset(dirpath,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
		
	       ParsePathName(gdir_path.short_dir_path, folderpath, filename);
		sprintf(dirpath, "%s\\", folderpath);   
		memset(gdir_path.short_dir_path,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
		strcpy(gdir_path.short_dir_path,folderpath);
		   
		BT_DEBUG(("<=====Move path :%s gdir_path.short_dir_path[%s]",dirpath,gdir_path.short_dir_path));
	}
	//////////////////////////////////////////////	

	if(aitFileInfo != PNULL) 
	{
		gExfsFilecounts =0;
		KiFreeMemory ((void**)&aitFileInfo ); /*Free memalloc*/
	}

	dir_count = btfs_exfs_filecount(dirpath,AIT_ATTRIBUTE_DIR); /*count dir*/
	file_count = btfs_exfs_filecount(dirpath,AIT_ATTRIBUTE_FILE); /*count file*/
	
	if((file_count == EINVAL) || (dir_count == EINVAL))  /*noti_011085*/
	{
	       Btexfs_deactivate();
		return EINVAL; /*if each count was EINVAL then return Error */
	}
	
	gExfsFilecounts = dir_count+file_count;
	
	BT_DEBUG(("btfs_exfs_opendir(%d) Dir counts[%d] file counts[%d]",gExfsFilecounts,dir_count,file_count));
	
	KiAllocZeroMemory ( (gExfsFilecounts )* sizeof (sFILEINFO), (void **) &aitFileInfo ); 
       if(aitFileInfo == PNULL) 
	{
	       BT_DEBUG(("Memalloc was fail................................................>>"));
		Btexfs_deactivate();
	   	return EINVAL;
       }
	   

	if(dir_count > 0)   
	{
	while(Stop == FALSE)
	{
		if(dir_count <EXFS_NUM_OF_GET_DIRLIST+1)
		{
				exfs_list=btfs_exfs_dirgetlist(dirpath, search_idx, dir_count);
				if(exfs_list == EINVAL)
				{
					Btexfs_deactivate();
					return EINVAL;
				}
			search_idx= search_idx+dir_count;
			Stop =TRUE;
		}
		else
		{     
		       dir_count=dir_count-EXFS_NUM_OF_GET_DIRLIST;
				exfs_list=btfs_exfs_dirgetlist(dirpath, search_idx, EXFS_NUM_OF_GET_DIRLIST);
				if(exfs_list == EINVAL) 
				{
					Btexfs_deactivate();
					return EINVAL;
				}
			search_idx= search_idx+EXFS_NUM_OF_GET_DIRLIST;
		}
	}
	}
	
	Stop =FALSE;
	search_idx =0;
	
	if(file_count > 0)
	{
	while(Stop == FALSE)
	{
		if(file_count <EXFS_NUM_OF_GET_FILELIST+1)
		{
				exfs_list=btfs_exfs_filegetlist(dirpath, search_idx, file_count);
				if(exfs_list == EINVAL) 
				{
					Btexfs_deactivate();
					return EINVAL;
				}
			search_idx= search_idx+file_count;
			Stop =TRUE;
		}
		else
		{     
		       file_count=file_count-EXFS_NUM_OF_GET_FILELIST;
				exfs_list=btfs_exfs_filegetlist(dirpath, search_idx, EXFS_NUM_OF_GET_FILELIST);
				if(exfs_list == EINVAL) 
				{
					Btexfs_deactivate();
					return EINVAL;
				}
			search_idx= search_idx+EXFS_NUM_OF_GET_FILELIST;
		}
	}
	}
	return gExfsFilecounts;
}

FileInform *btfs_exfs_readdir(DirId dir_p) 
{
	static FileInform fileinfo;
	char debugstr[FILE_NAME_SIZE];
	memset(&fileinfo,0x00,sizeof(FileInform));
	fileinfo.attribute=aitFileInfo[read_idx].stat.attr;
	fileinfo.size =aitFileInfo[read_idx].stat.size;
/* BT_COMMON_KIMSANGJIN_070418 */
       BT_DEBUG(("read_idx[%d] /gExfsFilecounts[%d]",read_idx,gExfsFilecounts));
	if(read_idx == gExfsFilecounts)  /*noti_011085*/
	{
	       read_idx =0; /*when opendir was called, it initialise to 0 and this routine also initialise to 0*/
		return PNULL;
	}

	if(utStrlenUcs2(aitFileInfo[read_idx].long_name) >FILE_NAME_SIZE)
	{
	       BT_DEBUG(("btfs_exfs_readdir> file name length[%d] was too long..........................error case",utStrlenUcs2(aitFileInfo[read_idx].long_name)));
		memcpy(fileinfo.file_name,aitFileInfo[read_idx].long_name,sizeof(u_short)*(FILE_NAME_SIZE ));
	}
	else
	{
		memcpy(fileinfo.file_name,aitFileInfo[read_idx].long_name,sizeof(u_short)*(utStrlenUcs2(aitFileInfo[read_idx].long_name) ));
	}
/* end of BT_COMMON_KIMSANGJIN_070418 */
	
       /*Time information setting*/
	fileinfo.year=aitFileInfo[read_idx].stat.time.year;			
	fileinfo.month=aitFileInfo[read_idx].stat.time.month;
	fileinfo.day=aitFileInfo[read_idx].stat.time.day;
	fileinfo.hours=aitFileInfo[read_idx].stat.time.hour;
	fileinfo.minutes=aitFileInfo[read_idx].stat.time.min;
	fileinfo.seconds=aitFileInfo[read_idx].stat.time.sec;
	memset(debugstr,0x00,sizeof(char)*FILE_NAME_SIZE);
	CopyAgChar2Char(debugstr, fileinfo.file_name, utStrlenUcs2(fileinfo.file_name));
       BT_DEBUG(("btfs_exfs_readdir() fileinfo.attribute[0x%x] aitFileInfo[%d].stat.attr[0x%x] name [%s]"
	   	             ,fileinfo.attribute,read_idx,aitFileInfo[read_idx].stat.attr,debugstr));
	read_idx++;
#if 0	/*noti_011085*/
	if(read_idx == gExfsFilecounts +1) 
	{
	       read_idx =0; /*when opendir was called, it initialise to 0 and this routine also initialise to 0*/
		return PNULL;
	}
#endif	
	return &fileinfo;
}

int btfs_exfs_closedir(DirId dir_p)
{
       Btexfs_deactivate();
	return AIT_SUCCESS;
}

int btfs_exfs_mkdir(char *path)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int32 errCode;
	Int16 long_dirame[BT_AIT_FILE_NAME_LENGTH+1];
	Int16 commandRef = afglGetUniqueId();
	Boolean keepGoing = TRUE;

	BT_DEBUG(("btfs_exfs_mkdir :%s",path));
	
	memset(long_dirame,0x00,sizeof(Int16)*(BT_AIT_FILE_NAME_LENGTH+1));
	
	ConvertUTF8toUCS2(path, strlen(path), long_dirame);
	BtStrUpr(path); 
	BT_DEBUG(("path :%s",path));
	KiCreateSignal(SIG_L1EXFS_CREATE_DIR_REQ, sizeof(L1ExFsCreateDirReq), &sendSignal);
	memset(sendSignal.sig, 0x00, sizeof(L1ExFsCreateDirReq));

	sendSignal.sig->l1ExFsCreateDirReq.taskId =  Target_TaskId;	
	sendSignal.sig->l1ExFsCreateDirReq.commandRef = commandRef;
	sendSignal.sig->l1ExFsCreateDirReq.short_dirname_ptr = path;
	sendSignal.sig->l1ExFsCreateDirReq.long_dirname_ptr = long_dirame;	 /*Need to conveting*/
	KiSendSignal( LGE_EXT_FILESYS_TASK_ID, &sendSignal );

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1EXFS_CREATE_DIR_CNF &&	
			recvSignal.sig->l1ExFsCreateDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&BtExfsFTPPendigQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->l1ExFsCreateDirCnf.fsError;
	gAitFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);

	if (errCode != AIT_SUCCESS)
	{
  	  	BT_DEBUG(("BtafexfsSendFileCount Error>errCode:%d", errCode));	
		Btexfs_deactivate();
		return EINVAL;
	}
	else
	{
  	  	BT_DEBUG(("BtafexfsSendFileCount SUCCESS "));
		return AIT_SUCCESS;
	}
}



#if 0 /*End of dummy_code*/

char *GetAitShortDirForFolderIndex(Int16 folderIdx)
{
	char *short_dirname=PNULL;

	if( folderIdx > BT_SOUND_FOLDER_IDX )
	{
		switch (folderIdx)
		{
			case BT_VIDEO_FOLDER_IDX:	//3
				short_dirname = AIT_NAND_VIDEOS_DIR_PATH;
				break;
			case BT_PHOTO_FOLDER_IDX:	//4
				short_dirname = AIT_NAND_PHOTOS_DIR_PATH;
				break;
			case BT_MUSIC_FOLDER_IDX:
				short_dirname = AIT_NAND_MUSIC_DIR_PATH;
				break;
#if defined(LGE_BLUETOOTH_P7200)
			case BT_TEXT_FOLDER_IDX:
				short_dirname = AIT_NAND_TEXT_DIR_PATH;
				break;
#endif
			case BT_OTHER_FOLDER_IDX:
				short_dirname = AIT_NAND_OTHERS_DIR_PATH;
				break;
			default:
				BT_DEBUG(("GetAitShortDirForFolderIndex() : invalid folder Idx for AIT NAND=%d", folderIdx));
				break;
		}

	}
	else
	{
		BT_DEBUG(("GetAitShortDirForFolderIndex() : invalid folder Idx for AIT NAND=%d", folderIdx));
	}
	return short_dirname;	
}

char *GetAitShortDirName(char *folderName)
{
	char *short_dirname=PNULL;

	Int16 folderType = BtGetFolderType(folderName);
	Int16 folderIdx = BtGetFolderIdx(folderName);

	if(folderType == BT_FOLDER_TYPE_AIT)
	{
		switch (folderIdx)
		{
			case BT_ROOT_FOLDER_IDX:
				short_dirname = AIT_NAND_MEDIA_DIR_PATH;
				break;
			case BT_VIDEO_FOLDER_IDX:
				short_dirname = AIT_NAND_VIDEOS_DIR_PATH;
				break;
			case BT_PHOTO_FOLDER_IDX:
				short_dirname = AIT_NAND_PHOTOS_DIR_PATH;
				break;
			case BT_MUSIC_FOLDER_IDX:
				short_dirname = AIT_NAND_MUSIC_DIR_PATH;
				break;
#if defined(LGE_BLUETOOTH_P7200)
			case BT_TEXT_FOLDER_IDX:
				short_dirname = AIT_NAND_TEXT_DIR_PATH;
				break;
#endif
			case BT_OTHER_FOLDER_IDX:
				short_dirname = AIT_NAND_OTHERS_DIR_PATH;
				break;
			default:
				BT_DEBUG(("GetAitShortDirName() : invalid folder Idx for AIT NAND=%d", folderIdx));
				break;
		}
		
	}		
	else
	{
		BT_DEBUG(("GetAitShortDirName() : invalid folder folderType for AIT NAND=%d", folderType));
	}
	return short_dirname;	
}

void BtGetListAIT(char *folderName, char *fileName, char *short_filename)
{
	u_short i;
	char  long_fileName[BT_MMI_FILENAME_SIZE+1];
	char  *searchPattern=PNULL;
	u_short			fileIndex=0;	
	Int16			total_file_count=0;
	Int16			totalPageNum=0;
	Int16			remainFileNum=0;
	Int16			currentPageNum=0;
	Int16			wishFileNum=0;
	Int16 			fileCount=0;
	Int16 folderIdx = BtGetFolderIdx(folderName);
	
	searchPattern = GetAitShortDirForFolderIndex(folderIdx);
	if( BtgetExfsState() == FALSE)
        {
		BT_DEBUG(("BtGetListAIT(): ACTIVE"));        
		Btexfs_Activate();
        }

	total_file_count = btfs_exfs_count(searchPattern, AIT_ATTRIBUTE_FILE);
	if (BtAitFTP_FileError() == AIT_SUCCESS)
	{
		if( total_file_count > 0 )
		{
			totalPageNum = total_file_count / EXFS_NUM_OF_GET_FILELIST;
			remainFileNum = total_file_count % EXFS_NUM_OF_GET_FILELIST;
			if( remainFileNum > 0 )
				totalPageNum++;
			fileCount = total_file_count;
			for(currentPageNum=0; currentPageNum<totalPageNum; currentPageNum++)
			{
				if( fileCount >= EXFS_NUM_OF_GET_FILELIST )
				{
					wishFileNum = EXFS_NUM_OF_GET_FILELIST;
					fileCount -= EXFS_NUM_OF_GET_FILELIST;					
				}
				else
				{
					wishFileNum = fileCount;
				}

				fileIndex = EXFS_NUM_OF_GET_FILELIST * currentPageNum;
				if( (btfs_exfs_getlist(searchPattern, fileIndex, wishFileNum)) == AIT_SUCCESS)
				{
					for(i=0; i<wishFileNum; i++)
					{
    						if(STRLEN(aitFileInfo[i].long_name) <BT_AIT_FILE_NAME_LENGTH+1) /* Tiburona BT_051016 */
    						{
						memset(long_fileName,0x00,sizeof(char)*(BT_MMI_FILENAME_SIZE+1));
						ConvertUCS2toUTF8(aitFileInfo[i].long_name, STRLEN(aitFileInfo[i].long_name), long_fileName);
						BT_DEBUG(("%d, A:=%s", i, long_fileName));
						if( strcmp(long_fileName, fileName)==0 )
						{
							BT_DEBUG(("%d, B:=%s", i, fileName));
							memcpy( short_filename, aitFileInfo[i].short_name, strlen(aitFileInfo[i].short_name)*sizeof(char)); 
								i=wishFileNum;
								currentPageNum = totalPageNum;								
							if( BtgetExfsState() == TRUE)
							{
								BT_DEBUG(("BtGetListAIT(): DE-ACTIVE(1)"));        
								Btexfs_Deactivate();
							}
							return;
						}
					}
						else
						{
							BT_DEBUG(("Check the file name length to view the file list (fileName length=%d)", STRLEN(aitFileInfo[i].long_name)));
						}							
					}
				}
				else
				{
					BT_DEBUG(("BtOpenAitSubFolder(): btfs_exfs_getlist() : ERROR=%d -> FAIL", BtAitFTP_FileError()));
				}
				
			}
		}
		else
		{
			BT_DEBUG(("BtOpenAitSubFolder(): total_file_count=%d", total_file_count));
			total_file_count = 0;
		}
	}
	else
	{
		BT_DEBUG(("BtOpenAitSubFolder(): btfs_exfs_count() : ERROR=%d -> FAIL", BtAitFTP_FileError()));
		total_file_count = 0;
	}

	if( BtgetExfsState() == TRUE)
	{
		BT_DEBUG(("BtGetListAIT(): DE-ACTIVE(2)"));        
		Btexfs_Deactivate();
	}
}

void ConvertToAitForm(char *folderName, char *fileName, char *aitshortFileName, Int16 *aitlongFileName, ModeBTFTP mode)
{
	Int16 folderType = BtGetFolderType(folderName);
	Int16 folderIdx = BtGetFolderIdx(folderName);
	char  *short_dirname=PNULL;
	char  short_filename[BT_MMI_FILENAME_SIZE+1]; /* Tiburona BT_051003 */
	char  long_fileName[BT_MMI_FILENAME_SIZE+1];
	Int16 dest_byte=0;

	memset(short_filename,0x00,sizeof(char)*(BT_MMI_FILENAME_SIZE+1));
	memset(long_fileName,0x00,sizeof(char)*(BT_MMI_FILENAME_SIZE+1));
	
	BT_DEBUG(("ConvertToAitForm(): \r\n folderName=%s, mode=%d", folderName, mode));
	if (BtIsValidFolderIdx(folderIdx) == FALSE)
	{
		BT_DEBUG(("ConvertToAitForm(): invalid folderNmae=%s", folderName));
	}
	else
	{
		if(folderType == BT_FOLDER_TYPE_AIT)
		{
			short_dirname = GetAitShortDirForFolderIndex(folderIdx);
			if( (mode==BT_READ) || (mode==BT_DELETE) ) /* Tiburona BT_051003 */
			{
				BtGetListAIT(folderName, fileName, short_filename);
#if 1 /* Tiburona BT_051015 TD#16444*/			
				if( strcmp(short_filename, "")==0 )
				{
				       strcpy(short_filename, "NotExist.txt");
				}
#endif				
			}
			else
			{
				memcpy(short_filename, fileName, strlen(fileName)*sizeof(char)); 
				BtStrUpr(short_filename);
			}

			sprintf(aitshortFileName, "%s\\%s", short_dirname, short_filename);
			BT_DEBUG(("short_filename=%s", short_filename));
			ConvertUTF8toUCS2(fileName, strlen(fileName), aitlongFileName);
			dest_byte = ConvertUCS2toUTF8(aitlongFileName, STRLEN(aitlongFileName), long_fileName);
		}
		else
		{
			BT_DEBUG(("ConvertToAitForm(): invalid folderType=%s", folderType));
		}
	}	
	BT_DEBUG(("\r\n aitshortFileName=%s, \r\n aitlongFileName=%s, \r\n dest_byte=%d \r\n ", 
				aitshortFileName, long_fileName, dest_byte));
}



static Int32 BtAit_ConvertTimeInfo(sFILEINFO *src)
{
	BTK_FileTimeType time;

	time.year = src->stat.time.year;
	time.mon  = src->stat.time.month;
	time.day  = src->stat.time.day;
	time.hour = src->stat.time.hour;
	time.min  = src->stat.time.min;
	time.sec  = src->stat.time.sec;
	return BTK_PackFileTime(&time);
}

static void BtAit_CopyFileInfo(BTMMI_FileInfo *dest, sFILEINFO *src)
{
#if 1 /* LGE_MERGE_BLUETOOTH : 2005.08.12 Tiburona */ 
	memset(dest, 0x00, sizeof(BTMMI_FileInfo));
	ConvertUCS2toUTF8(src->long_name, STRLEN(src->long_name), dest->name);
#else
	strcpy(dest->name, src->short_name);
#endif
	dest->time   = BtAit_ConvertTimeInfo(src);
	dest->size   = src->stat.size;
	dest->folder = FALSE;
	dest->m4ObjId = 0; /* Tiburona 050716 */
}

Boolean BtAit_AddFileInfo(BTMMI_FileList *fileList, BTMMI_FileInfo *info)
{
	/* Tiburona BT_051004 */
	if (fileList->count < BT_MAX_NUM_OF_FILES)
	{
		memcpy(&(fileList->list[fileList->count]), info, sizeof(BTMMI_FileInfo));
		(fileList->count)++;
		return TRUE;
	}
	else
	{
		BT_DEBUG(("BtAit_AddFileInfo() : fileList->count:%d = BT_MAX_NUM_OF_FILES", fileList->count));
		return FALSE;
	}
}
	
/*----------------------------------------------------------------
 * Func Name : 	BtOpenAitSubFolder
 * Desc          :      AIT ex File System Open SubFolder
 * Return       :       fid
 *---------------------------------------------------------------*/
void BtOpenAitSubFolder(BTMMI_FileList *fileList, Int16 folderIdx)
{
	u_short i;
	BTMMI_FileInfo info;
	char  	*searchPattern=PNULL;
/* Tiburona BT_051001 */
	u_short	fileIndex=0;	
	Int16	total_file_count=0;
	Int16	totalPageNum=0;
	Int16	remainFileNum=0;
	Int16	currentPageNum=0;
	Int16	wishFileNum=0;
	Int16 	fileCount=0;

	//BT_DEBUG(("BtOpenAitSubFolder(): %s", BtGetFolderName(folderIdx)));
	BtInitFileList(fileList);
	searchPattern = GetAitShortDirForFolderIndex(folderIdx);

	if( BtgetExfsState() == FALSE)
        {
		BT_DEBUG(("btfs_exfs_count(): ACTIVE"));        
		Btexfs_Activate();
        }

/* LGE_MERGE_BLUETOOTH Tiburona BT_050820 >>*/	
	total_file_count = btfs_exfs_count(searchPattern, AIT_ATTRIBUTE_FILE);
	if (BtAitFTP_FileError() == AIT_SUCCESS)
	{
/* BT_MMI_KIMSANGJIN_051015 */
		char extName	[BT_MAX_EXTNAME_SIZE+1];
		char fileName	[BT_MMI_FILENAME_SIZE+1];
		
		memset(fileName,0x00,sizeof(char)*(BT_MMI_FILENAME_SIZE+1));
		memset(extName,0x00,sizeof(char)*(BT_MAX_EXTNAME_SIZE+1));
/* end of BT_MMI_KIMSANGJIN_051015 */
		
		   
		if( total_file_count > 0 )
		{
			totalPageNum = total_file_count / EXFS_NUM_OF_GET_FILELIST;
			remainFileNum = total_file_count % EXFS_NUM_OF_GET_FILELIST;
			if( remainFileNum > 0 )
				totalPageNum++;
			fileCount = total_file_count;
			//BT_DEBUG(("BtOpenAitSubFolder(): btfs_exfs_count() -> SUCCESS")); 
			//BT_DEBUG(("BtOpenAitSubFolder(): total_file_count=%d, totalPageNum=%d, remainFileNum=%d ", 
			//			total_file_count, totalPageNum, remainFileNum));
			//BT_DEBUG(("File List START======================================="));	
			for(currentPageNum=0; currentPageNum<totalPageNum; currentPageNum++)
			{
				//BT_DEBUG(("currentPageNum=#%d",  currentPageNum));
				if( fileCount >= EXFS_NUM_OF_GET_FILELIST )
				{
					//BT_DEBUG(("fileCount=%d", fileCount)); 
					wishFileNum = EXFS_NUM_OF_GET_FILELIST;
					fileCount -= EXFS_NUM_OF_GET_FILELIST;					
					//BT_DEBUG(("wishFileNum=%d", wishFileNum)); 
				}
				else
				{
					//BT_DEBUG(("fileCount=%d", fileCount)); 
					wishFileNum = fileCount;
					//BT_DEBUG(("wishFileNum=%d", wishFileNum)); 
				}

				fileIndex = EXFS_NUM_OF_GET_FILELIST * currentPageNum;
				//BT_DEBUG(("fileIndex=%d", fileIndex)); 
				if( (btfs_exfs_getlist(searchPattern, fileIndex, wishFileNum)) == AIT_SUCCESS)
				{
					for(i=0; i<wishFileNum; i++)
					{
						/* Tiburona BT_051004 */
/* BT_MMI_KIMSANGJIN_051015 */
						strcpy(fileName,aitFileInfo[i].short_name);
						GetExtName(fileName,extName);
    						if(STRLEN(aitFileInfo[i].long_name) <BT_AIT_FILE_NAME_LENGTH+1 && (strcmp(extName,"DM") !=0)) 
/* end of BT_MMI_KIMSANGJIN_051015 */
    						{
						BtAit_CopyFileInfo(&info, &aitFileInfo[i]);
						if( BtAit_AddFileInfo(fileList, &info) == FALSE) /* Tiburona BT_051003 */
						{
					    		BT_DEBUG(("It is limited that file number(BT_MAX_NUM_OF_FILES=%d) can list up.", BT_MAX_NUM_OF_FILES));
								i=wishFileNum;
							currentPageNum = totalPageNum;
								if( BtgetExfsState() == TRUE) /* Tiburona BT_051004 */
								{
									BT_DEBUG(("btfs_exfs_getlist(): DE-ACTIVE(1)"));        
									Btexfs_Deactivate();
								}
							return;
						}
					}
						else
						{
							BT_DEBUG(("Check the file name length to view the file list (fileName length=%d)", STRLEN(aitFileInfo[i].long_name)));
						}	
					}
					//BT_DEBUG(("BtOpenAitSubFolder(): folderName=%s, total_file_count=%d -> SUCCEED ", BtGetFolderName(folderIdx), total_file_count));
				}
				else
				{
					BT_DEBUG(("BtOpenAitSubFolder(): btfs_exfs_getlist() -> FAIL"));
				}
				
			}
			//BT_DEBUG(("File List END======================================="));		
		}
		else
		{
			BT_DEBUG(("BtOpenAitSubFolder(): total_file_count=%d -> FAIL", total_file_count));
			total_file_count = 0;
		}
	}
	else
	{
		BT_DEBUG(("BtOpenAitSubFolder(): btfs_exfs_count() :  total_file_count=%d -> FAIL", total_file_count));
		total_file_count = 0;
	}
/* LGE_MERGE_BLUETOOTH Tiburona BT_050820 <<*/

	if( BtgetExfsState() == TRUE)
	{
		BT_DEBUG(("btfs_exfs_getlist(): DE-ACTIVE(2)"));        
		Btexfs_Deactivate();
	}
}
#endif /*End of dummy_code*/
#define TEST_STRING				"0123456789"
#define TEST_STRING_SIZE		(strlen(TEST_STRING))
#define MAX_BUFFER_SIZE		(100*1024) 			/* 100 KB */

static char gBuffer[MAX_BUFFER_SIZE];

static Int32 FillBuffer(char *buffer, Int32 num)
{
	Int32 i;
	
	for (i = 0; i < num; i++)
	{
		memcpy(buffer + i * TEST_STRING_SIZE, TEST_STRING, TEST_STRING_SIZE);
	}
	return TEST_STRING_SIZE * num;
}

void exfs_file_readwrite(void)
{
	int  fid=0;
	Int32 size_in=0, size_out=0;
	FileInform *info;
	Int16 retVal;
	Btexfs_activate();
	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\OTHERS\\test.txt", "a");
	BT_DEBUG(("End of btfs_exfs_open fid = %d \n", fid));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 300);	
	size_out = btfs_exfs_write(fid, gBuffer, size_in);
	btfs_exfs_close(fid);
	
	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\OTHERS\\test.txt", "r");
	BT_DEBUG(("End of btfs_exfs_open fid = %d \n", fid));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_out = btfs_exfs_read(fid, gBuffer, size_out);
	btfs_exfs_close(fid);
	
	BT_DEBUG(("DEV0:\\MYMEDI~1\\OTHERS\\test.txt[%s]", gBuffer));
	
	btfs_exfs_remove("DEV0:\\MYMEDI~1\\OTHERS\\test.txt");
	
	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\OTHERS\\test.txt", "r");
	if(fid  <= 127)
	{
            BT_DEBUG(("File open error is ==ok== End of file write and read and remove test"));
	}
	else
      {
		BT_DEBUG(("Btfs_Open fid = %d  it is Error situation", fid));
		memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
		size_out = btfs_exfs_read(fid, gBuffer, size_out);
		BT_DEBUG(("2 DEV0:\\MYMEDI~1\\OTHERS\\test.txt[%s]", gBuffer));
		btfs_exfs_close(fid);
	}
	Btexfs_deactivate();

}

void exfs_file_write(void)
{
	int  fid=0;
	Int32 size_in=0, size_out=0;
	Int16 retVal;
	Btexfs_activate();
	
	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\OTHERS\\test1.txt", "a");
	BT_DEBUG(("btfs_exfs_open fid = %d \n", fid));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 300);	
	size_out = btfs_exfs_write(fid, gBuffer, size_in);
	btfs_exfs_close(fid);
	
	BT_DEBUG((" "));
	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\OTHERS\\test2.txt", "a");
	BT_DEBUG(("btfs_exfs_open fid = %d \n", fid));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 300);	
	size_out = btfs_exfs_write(fid, gBuffer, size_in);
	btfs_exfs_close(fid);
	
	BT_DEBUG((" "));
	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\OTHERS\\test3.txt", "a");
	BT_DEBUG(("btfs_exfs_open fid = %d \n", fid));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 300);	
	size_out = btfs_exfs_write(fid, gBuffer, size_in);
	btfs_exfs_close(fid);
	
	BT_DEBUG((" "));
	btfs_exfs_filecount("DEV0:\\MYMEDI~1\\OTHERS\\",AIT_ATTRIBUTE_FILE); /*count file*/
	btfs_exfs_filecount("DEV0:\\MYMEDI~1\\",AIT_ATTRIBUTE_DIR); /*count dir*/
	
	BT_DEBUG((" "));
	Btexfs_deactivate();
}
void exfs_get_list(void)
{
	int  fid=0;
	Int32 size_in=0, size_out=0;
	Int16 retVal;
	FileInform *tmpinfor =NULL;
	Int8   strDst_p[FILE_NAME_SIZE];
//	Btexfs_activate();
	BT_DEBUG((" "));
	//btfs_exfs_filegetlist("DEV0:\\MYMEDI~1\\OTHERS\\",0,3); /*list file*/
	
	BT_DEBUG((" "));
	//btfs_exfs_dirgetlist("DEV0:\\MYMEDI~1\\",0,4); /*list dir*/
       btfs_exfs_opendir("DEV0:\\MYMEDI~1\\IMAGES\\");//"DEV0:\\MYMEDI~1\\");            //"DEV0:\\MYMEDI~1\\IMAGES\\");
	tmpinfor=btfs_exfs_readdir(NULL);
	
	if(tmpinfor !=PNULL)
	{
	       memset(strDst_p,0x00,sizeof(strDst_p));
		utCompressStrcpy(strDst_p,tmpinfor->file_name);
		BT_DEBUG(("long file_name [%s]size[%d] attr[0x%x]",strDst_p,tmpinfor->size,tmpinfor->attribute));
		BT_DEBUG(("====================================="));
	}

	while(tmpinfor !=PNULL)
	{
		tmpinfor=btfs_exfs_readdir(NULL);
		
		if(tmpinfor !=PNULL)
		{	      
		       memset(strDst_p,0x00,sizeof(strDst_p));
			utCompressStrcpy(strDst_p,tmpinfor->file_name);
			BT_DEBUG(("long file_name [%s] size[%d] attr[0x%x]",strDst_p,tmpinfor->size,tmpinfor->attribute));
			BT_DEBUG(("====================================="));
		}
	}
	btfs_exfs_closedir(NULL);
	
	BT_DEBUG((" "));
	//Btexfs_deactivate();
}

void exfs_open_remove(void)
{
	int  fid=0;
	Btexfs_activate();
	
	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\IMAGES\\d61m.jpg", "r");
	BT_DEBUG(("btfs_exfs_open fid = %d \n", fid));
	btfs_exfs_close (fid);
	btfs_exfs_remove("DEV0:\\MYMEDI~1\\IMAGES\\d61m.jpg");
	BT_DEBUG((" "));
	exfs_get_list();
	BT_DEBUG((" "));
	
	Btexfs_deactivate();
}
void exfs_dir_make(void)
{
	int  fid=0;
	Int32 size_in=0, size_out=0;
	
	Btexfs_activate();
	
	btfs_exfs_mkdir("DEV0:\\MYMEDI~1\\OTHERS\\BT_FOLDER");

	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\OTHERS\\BT_FOLDER\\Bt_test.txt", "a");
	BT_DEBUG(("btfs_exfs_open fid = %d \n", fid));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 300);	
	size_out = btfs_exfs_write(fid, gBuffer, size_in);
	btfs_exfs_close(fid);
	
	Btexfs_deactivate();
}
void exfs_remove_Dirfile(void)
{
	int  fid=0;
	
	Btexfs_activate();
	
	btfs_exfs_remove("DEV0:\\MYMEDI~1\\OTHERS\\BT_FOLDER\\Bt_test.txt");
	fid = btfs_exfs_open("DEV0:\\MYMEDI~1\\OTHERS\\BT_FOLDER\\Bt_test.txt", "r");
	
	Btexfs_deactivate();
}
#endif /* LGE_EXFS_FS_BLUETOOTH */


