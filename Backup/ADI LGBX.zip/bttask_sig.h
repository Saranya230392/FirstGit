/***************************************************************************
* FILE: bttask_sig.h
* DESC: Type definition for signals exchanged between Bluetooth task and MMI task
***************************************************************************/

#ifndef BTTASK_SIG_H
#define BTTASK_SIG_H

#if defined(LGE_L1_BLUETOOTH) /*Do not change this define option :: for bte lib comile error*/

/***************************************************************************
** Include Files
***************************************************************************/
#if !defined (SYSTEM_H)
#include <system.h>
#endif 

#if !defined (KERNEL_H)
#include <kernel.h>
#endif

//#include <data_types.h> /* LEMANS_KANGHYUNGWOOK_061122 */

#if !defined (AFBT_TYP_H)
#include "afbt_typ.h"
#endif

/***************************************************************************
* Manifest Constants / Defines
***************************************************************************/

/***************************************************************************
** Type definitions
***************************************************************************/
#if defined(LGE_MMI_BLUETOOTH) /*Do not change this define option :: for bte lib comile error*/
typedef struct BtMmiMessageTag
{	
	Int32 Message;
	Int32 IParam;
	void * VParam;
}
BtMmiMessage;

typedef struct AfbtActionSigTag
{
    HandlerId		handlerId;
    AfbtAction		action;
    AgElementId	tokenId;
}
AfbtActionSig;

/* BT_070720_reset_setting */
typedef struct AfbtResetSettingCnfTag
{
	Int16		commandRef;
	Boolean		success;
}AfbtResetSettingCnf;
#endif /* LGE_MMI_BLUETOOTH */

#endif /* LGE_L1_BLUETOOTH */

#endif /* BTTASK_SIG_H */

