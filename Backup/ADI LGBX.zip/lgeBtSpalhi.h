/***************************************************************************
 * LG Electronics Copyright (c) KEVIN_BT job100502
 ***************************************************************************
 * $Id: //central/releases/Branch_release_8/tplgsm/BLUETOOTH/lgeBtSpalhi.h#2 $
 * $Revision: #2 $
 * $DateTime: 2004/11/15 09:25:26 $
 * $DateTime: 2005/03/02 13:17:12 $
 ***************************************************************************
 *  File Description :
 *      Bluetooth layer 2 and layer 1 protocol elements.
 *      task runs at high priority (just under timers)
 *      interrupts run at high priority
 *
 *      The BLUETOOTH protocol is taken from BTE 3.0 
 *
 * $Author : KANE S. PIEN(KYUE SUP BYUN) :-), KANE HYUNG WOOK, KIM SANG JIN
 *
  **************************************************************************/
#if !defined (LGEBTSPALHI_H)
#define       LGEBTSPALHI_H

#if defined(LGE_L1_BLUETOOTH)

/****************************************************************************
* Include Files
****************************************************************************/
#include <Ki_sig.h>

#if !defined (DLSPALIF_H)
#include <dlspalif.h>
#endif

#if !defined (BTQUEUE_H)
#include <Btqueue.h>
#endif

/****************************************************************************
* Mainfest Constants / Defines
****************************************************************************/\
/********************************************************************************/
/* Use the "LOOPBACK_TEST" define to do UART Loopback Test for verifying bluetooth UART port */
//#define	LOOPBACK_TEST 			1
/********************************************************************************/

/********************************************************************************/
/* Define the "GENIE_VIA_BLUETOOTH" to use genie via bluetooth instead of serial cable */ /* KANE_BT job050103 */
//#define	GENIE_VIA_BLUETOOTH 	1
/********************************************************************************/

/*******************************************************************************
* Define: BT_ACK_TIMEOUT_USER_VALUE
* Description: User value for the BT ACK timeout GKI timer.
*******************************************************************************/
#define BT_ACK_TIMEOUT_USER_VALUE       	(5)

/*******************************************************************************
* Define: BT_RETRANS_USER_VALUE
* Description: User value for the BT Retransmission GKI timer.
*******************************************************************************/
#define BT_RETRANS_USER_VALUE           		(6)
#define BT_RX_POLL_TIMER_USER_VALUE    	(7)
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 07Aug2006 */
#define BT_TEST_START_TIMER_USER_VALUE  	(8)
#endif
//#define DM_TMR_BT_SEMA_TIMER 			(9) /*noti_010426*/

#if 0
#define BT_RX_NOTIFY				 	4
#else
#define BT_NEXT_NOTIF_115200       		4
#define BT_NEXT_NOTIF_460800       		128 //Optimal value - HY's good finding 64->128!!
#define BT_NEXT_NOTIF_921600       		256
#endif

/* BT_COMMON_KIMSANGJIN_071016 */
#define BT_RX_POLL_IDLE_TIME_MAX       3000  /* 30 seconds -> 3seconds :  30000->3000*/

/* DMA buffer size */
#if defined(LGE_BRCM_BLUETOOTH)
#if defined (LGE_LEMANS_BLUETOOTH)
#define BT_TX_BUFF_SIZE         1024       /*   CHECK_HY  061030   */
#define BT_RX_BUFF_SIZE         1024
#elif defined(LGE_ATLAS_BLUETOOTH)
//BCM_CHANGE_070306 debugUART460K
#define BT_TX_BUFF_SIZE         1024 //512
#define BT_RX_BUFF_SIZE         1024 //512
//END_OF_BCM_CHANGE
#elif defined(LGE_ATLAS_2H_BLUETOOTH)
#define BT_TX_BUFF_SIZE         1024
#define BT_RX_BUFF_SIZE         1024
#endif
#endif /* LGE_BRCM_BLUETOOTH */

#if defined(LGE_CSR_BLUETOOTH) /* Dolphin2_PER_070808 */
#if defined (LGE_LEMANS_BLUETOOTH)
#define BT_TX_BUFF_SIZE         1024
#define BT_RX_BUFF_SIZE         1024
#elif defined(LGE_ATLAS_BLUETOOTH)
#define BT_TX_BUFF_SIZE         4096 //512
#define BT_RX_BUFF_SIZE         4096 //512
#elif defined(LGE_ATLAS_2H_BLUETOOTH)
#define BT_TX_BUFF_SIZE         16384
#define BT_RX_BUFF_SIZE         16384
#endif
#endif /* LGE_CSR_BLUETOOTH */

/* DMA Poll Period in ms */
#define BT_RX_DATA_POLL_PERIOD_9600			320
#define BT_RX_DATA_POLL_PERIOD_19200		160
#define BT_RX_DATA_POLL_PERIOD_38400		80
#define BT_RX_DATA_POLL_PERIOD_57600		40
#define BT_RX_DATA_POLL_PERIOD_115200		20
#define BT_RX_DATA_POLL_PERIOD_230400		10
#define BT_RX_DATA_POLL_PERIOD_460800		5
#define BT_RX_DATA_POLL_PERIOD_921600		3	

#if defined(LGE_BRCM_BLUETOOTH)
#if defined (LGE_LEMANS_BLUETOOTH)
#define BT_RX_QUEUE_SIZE	2048 //1024, myung    /*  CHECK_HY  071108  previous value was 1024  */
#elif defined(LGE_ATLAS_2H_BLUETOOTH)
#define BT_RX_QUEUE_SIZE 	2048        	/*  CHECK_HY   070314   for fix FTP Rx issue previous value was 1024   */
#elif defined(LGE_ATLAS_BLUETOOTH)
#define BT_RX_QUEUE_SIZE 	2048	    /* BCM_CHANGE_070307 debugUART460K */
#endif
#endif /* LGE_BRCM_BLUETOOTH */

#if !defined (BT_MAX_NUM_RX_BLOCKS)
#define BT_MAX_NUM_RX_BLOCKS           		(2)
#endif

#define BT_L3_BLOCK_MAX_MESSAGE_SIZE  	(254)
#define BT_L3_BLOCK_MAX_PREAMBLE_SIZE   	(3)

/* KANE_BT job050228 for GENIE :: start */
#if !defined (BT_MAX_NUM_RX_BLOCKS)
#define BT_MAX_NUM_RX_BLOCKS           		(2)	
#endif	/* KANE_BT job050228 for GENIE :: end */

#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 04Aug2006 */
#define BT_TEST_RX_TEMP_BUF_SIZE        	1024
#define BT_TEST_TX_LENGTH_AT_ONE_TIME   	512
#define BT_TEST_CMD_FLAG                		0x7E
#define BT_TEST_CMD_SIZE                		1
#define BT_TEST_ERR_BUF_SIZE            		1024
#define BT_TEST_115200_NEXT_NOTIF       	64
#define BT_TEST_460600_NEXT_NOTIF       	512
#define BT_TEST_921200_NEXT_NOTIF       	512
#endif /*BT_UART_PERFORMANCE_TEST*/

/****************************************************************************
* Type Definitions
****************************************************************************/
#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 04Aug2006 */
typedef enum 
{
    BT_UART_NO_STATE_S,
    BT_UART_IDLE_S,
    BT_UART_CONNECTING_S,
    BT_UART_CONNECTED_S,
    BT_UART_BAUDRATE_CHANGING_S
} BT_TEST_STATE_TYPE;

typedef enum
{
    BT_TEST_NOT_CMD,
    BT_TEST_CONNECT_CMD,
    BT_TEST_CONNECT_ACK_CMD,
    BT_TEST_TX_END_CMD,
    BT_TEST_BAUDRATE_CHANGE_CMD,
    BT_TEST_BAUDRATE_CHANGE_ACK_CMD,
    BT_TEST_CMD_MAX,
    BT_TEST_CMD_ERR
} BT_TEST_UART_CMD_TYPE;

typedef enum
{
    BT_TEST_TX_END,
    BT_TEST_RX_END
} BT_TEST_CHECK_COMPLETION_TYPE;
#endif	/* BT_UART_PERFORMANCE_TEST */

#if defined(GENIE_VIA_BLUETOOTH)
typedef struct BtGenieTxInterruptBlockTag
{
    Int8            blockLength;      /* including preamble and MI */
    Int8            mi;
    Int8            preambleLength;   /* 1 for ttp MIs (3 for first) */
    Int8            preamble[BT_L3_BLOCK_MAX_PREAMBLE_SIZE]; /* seq, len*2 */
    Int8           *data;
}
BtGenieTxInterruptBlock;

typedef struct BtGenieRxInterruptBlockTag
{
    Boolean         empty;
    Int8            blockLength;      /* including preamble and MI */
    Int8            mi;
    Int8            data[BT_L3_BLOCK_MAX_MESSAGE_SIZE];
}
BtGenieRxInterruptBlock;

typedef enum BtBlockStateTag
{
    BT_IDLE,
    BT_LENGTH,
    BT_MI,
    BT_IN_PREAMBLE,
    BT_IN_BODY,
    BT_CHECKSUM,
    BT_END_OF_FRAME,
    BT_LAST_BYTE

} BtBlockState;

typedef enum BtTxStateTag
{
    BT_TX_IDLE,
    BT_TX_SENDING_BLOCK,
    BT_TX_START_ACK_TIMER,
    BT_TX_WAITING_FOR_ACK,
    BT_TX_WAITING_FOR_RETRANS

} BtTxState;
#endif /* GENIE_VIA_BLUETOOTH */

typedef enum BtHighEvent
{
/* KANE_BT job0500302 for GENIE USING BT :: START */
/* This defined Events is that for not DMA so, blocked, If U want to use DMA, use below events */
#if 0
    BT_RECEIVED_ACK_EVENT         = 0x0020,
    BT_RECEIVED_NAK_EVENT         = 0x0021,
    BT_FAILED_RECEIVE_EVENT       = 0x0022,
    BT_RECEIVED_BLOCK_EVENT       = 0x0023,
    BT_TRANSMIT_BLOCK_COMPLETE    = 0x0024,
#endif
/* KANE_BT job0500302 for GENIE USING BT :: END */    

#if defined(BT_UART_PERFORMANCE_TEST) /* JHS2 01Aug2006 */   
    BT_DMA_RX_EVENT             = 0x0001,
    BT_DMA_TX_EVENT             = 0x0002,
    BT_DMA_POLL_RX_EVENT        = 0x0004,

    BT_UART_TEST_START          = 0x0008,
    BT_UART_CHANGE_BAUDRATE     = 0x0010,
    BT_TEST_START_EVENT         = 0x0020,

    BT_HIGH_ALL_EVENTS          = 0x004F, /* Ensure this is updated when new events are added */
    END_OF_EVENTS_TO_BT_HIGH    = 0x0040,  /* next in binary sequence */

    BT_ACK_TIMEOUT_EVENT        = 0x0080, /* no response from host so re-try */
    BT_RETRANS_TIMEOUT_EVENT    = 0x0100, /* give host time to bin last block */ 
    BT_PUT_TX_BLOCK_EVENT       = 0x0200,
#else
    BT_ACK_TIMEOUT_EVENT        = 0x0080, /* no response from host so re-try */
    BT_RETRANS_TIMEOUT_EVENT    = 0x0100, /* give host time to bin last block */ 
    BT_PUT_TX_BLOCK_EVENT       = 0x0040,
    
    BT_DMA_RX_EVENT             = 0x0001,
    BT_DMA_TX_EVENT             = 0x0002,
    BT_DMA_POLL_RX_EVENT        = 0x0004,
    /* events from low pri task, the value of these
     ** must not change based on conditional compiles. */

    BT_HIGH_ALL_EVENTS          = 0x01FF, /* Ensure this is updated when new events are added */
    
    END_OF_EVENTS_TO_BT_HIGH    = 0x0200  /* next in binary sequence */
#endif     /*BT_UART_PERFORMANCE_TEST*/
}
BtHighEvent;

/****************************************************************************
* Global Function Prototypes
****************************************************************************/
#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
void bluetoothDteEnable_UART(Boolean enable, DlSpalPortId port);
#endif

void BtHighSendEvent (BtHighEvent theEvent);
void BtDmaCheckForTxData(void);
Int16 BtDmaCheckForRxData(void);
void BtDmaResetRxBuffer(void);
void BtDisableRxDataReadyInt(void);
void BtRxInterrupt(void);
void BtTxInterrupt(void);
void BtInitSerialPort(void);
void BtConfigSerialPort(DlSpalBaudRate baud, DlSpalParity parity);
void BtPortInvalidate(void);
void EmmiPortInvalidate(void);
void BTSetRxNotify(void);
void BtUartChangeConfig(DlSpalBaudRate baudrate, DlSpalParity parity);

#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
void BtUartCleanupAfterChangeBaudrate(void);
#endif

#if defined(LGE_CSR_BLUETOOTH) /* Sean_070823: added new API for the changed uart callback structure */
void BtRegisterUartCallbacks( void (*txCallback)(void), void (*rxCallback)(void*, int));
#endif

#if defined(LGE_BRCM_BLUETOOTH) /* myung */
int Trigger_ReadDMABuffer(void);
void Trigger_CheckTxData(void);
#endif

void BtSpalInitTask(void);

#endif /* LGE_L1_BLUETOOTH */

#endif /* LGEBTSPALHI_H */
