/***************************************************************************
* FILE: btflag.c
* AUTH: Sang-Kwon Lee, KIM SANG JIN
* DATE: 2004/10/01
             2006/08/21
* DESC: Global flags for Bluetooth Service
****************************************************************************/

#if defined(LGE_L1_BLUETOOTH)

/***************************************************************************
* Include File
***************************************************************************/
#if !defined(BTFLAG_H)
#include "btflag.h"
#endif

#if !defined(L1BTIF_H)
#include "l1btif.h"
#endif

#if !defined ( LGEBTTYPE_H )
#include "lgebttype.h"
#endif

#if !defined ( UDEBUG_H )
#include "Udebug.h"
#endif

#if defined(LGE_LEMANS_BLUETOOTH)
#if defined(LGBX_INCLUDE)
#if !defined(__LGBX_A2SRC_API_H__) 
#include "LGBXA2srcApi.h"
#endif
#endif /* LGBX_INCLUDE */
#endif /* LGE_LEMANS_BLUETOOTH */

/***************************************************************************
* Type Definitions
***************************************************************************/

typedef struct BtFlagProfileTag
{
	volatile Boolean activated;
	volatile Boolean connected;
} BtFlagProfile;

/***************************************************************************
* Global Variables
***************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/
/* gBtFlag_Enabled: default FALSE, must be initialized with the same value as BtPower */
static volatile Boolean gBtFlag_Enabled; 

static volatile Boolean gBtFlag_Audio;
static volatile Boolean gBtFlag_AudioPathPhone;
static volatile Boolean gBtFlag_SpeechEn;
static volatile Boolean gBtFlag_AudioMicMute;
static volatile Boolean gBtFlag_ChangeSpkGainFromAg;	/* BT_COMMON_TIBURONA_080116 */

static volatile Boolean gBtFlag_TimeOutFlag;
static volatile Boolean gBtFlag_ShutdownFromTimer;

static volatile BtFlagProfile gBtFlag_Profiles[BT_PROFILE_NUMS];
#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
Boolean gBtFlag_usclock =FALSE; /*noti_010434*/
#endif
Boolean gBtFlag_extendedError = FALSE; /*hfp15 20071001 baeheejung*/
extern Boolean afmmGetNoServiceStatus (Boolean isForCall, Boolean displayRssi);  /*noti_011114*/

/***************************************************************************
* Initialization
***************************************************************************/
/* BtFlag_Init(): Bluetooth=ON �� ������ ��� flag ���� �ʱ�ȭ �Ѵ� */
void BtFlag_Init(void)
{
	Int16 i;
	static Boolean oneTimeInitDone = FALSE;

	gBtFlag_Enabled  				= FALSE; 
	gBtFlag_Audio          				= FALSE;
	gBtFlag_AudioPathPhone 			= TRUE;
	gBtFlag_SpeechEn				= FALSE;
	gBtFlag_AudioMicMute			= FALSE;
	gBtFlag_ChangeSpkGainFromAg	= FALSE;	/* BT_COMMON_TIBURONA_080116 */
	gBtFlag_TimeOutFlag				= FALSE;

	if (oneTimeInitDone == FALSE)
	{
		/* oneTimeInitDone: 
		*  ���� ���� �� �� �ѹ��� flag ���� �ʱ�ȭ�ϱ� ���� ����Ѵ�.
		*  ���⼭ �ʱ�ȭ �ϴ� ������ Bluetooth=ON �� ������ flag ���� �ʱ�ȭ���� �ʴ´�. 
		*/
		gBtFlag_ShutdownFromTimer = FALSE;
		oneTimeInitDone = TRUE;
	}
	
	for (i = 0; i < BT_PROFILE_NUMS; i++)
	{
		gBtFlag_Profiles[i].activated = FALSE;
		gBtFlag_Profiles[i].connected = FALSE;
	}
}

/***************************************************************************
* Profiles
***************************************************************************/
/* BT_COMMON_KIMSANGJIN_070503 noti_011066*/
void BtFlag_SetActivated(Int16 id, Boolean flag)
{
	gBtFlag_Profiles[id].activated = flag;
}

Boolean BtFlag_IsActivated(Int16 id)
{
	return gBtFlag_Profiles[id].activated;
}
/* end of BT_COMMON_KIMSANGJIN_070503 */

void BtFlag_SetConnected(Int16 id, Boolean flag)
{
	if(afmmGetNoServiceStatus(FALSE,FALSE) == FALSE) /*noti_011114 network enable*/
	{
#if defined(LGBX_INCLUDE)
		BtSetNetworkState(LGBX_AG_NET_ON_TYPE);
#endif
	}
       else
       {
#if defined(LGBX_INCLUDE)
		   BtSetNetworkState(LGBX_AG_NET_OFF_TYPE);
#endif
       }
	   
	gBtFlag_Profiles[id].connected = flag;
}

Boolean BtFlag_IsConnected(Int16 id)
{
	return gBtFlag_Profiles[id].connected;
}

/***************************************************************************
* Bluetooth
***************************************************************************/

void BtFlag_SetEnabled(Boolean flag)
{
	gBtFlag_Enabled = flag;
}

Boolean BtFlag_IsEnabled(void)
{
	return gBtFlag_Enabled;
}

/* BT_COMMON_KIMSANGJIN_070124 noti_010434 */
#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
void BtFlag_SetUscLock(Boolean flag)
{
        gBtFlag_usclock= flag;
}

Boolean BtFlag_isUscLock(void)
{
	return gBtFlag_usclock;
}
#endif

/***************************************************************************
* A2DP
***************************************************************************/
#if defined(LGE_LEMANS_BLUETOOTH) /* Tiburona_071025 For Bluetooth A2DP */
static Boolean gA2dpStreamRequest = FALSE;
void BtSetA2dpStreamRequest(Boolean flag)
{
	if(flag==TRUE)
		BT_DEBUG(("\x1b[37m [MMI] BtSetA2dpStreamRequest() Start Streaming ***********\x1b[0m"));
	else
		BT_DEBUG(("\x1b[37m [MMI] BtSetA2dpStreamRequest() Stop Streaming ***********\x1b[0m"));
	gA2dpStreamRequest = flag;
}

Boolean BtGetA2dpStreamRequest(void)
{
	return gA2dpStreamRequest;
}

static Boolean gA2dp_PathChange = FALSE;
void BtSetA2dpPathChange(Boolean flag)
{
	gA2dp_PathChange = flag;
	BT_DEBUG(("\x1b[31m [MMI] BtSetA2dpPathChange() gA2dp_PathChange=%s \x1b[0m", gA2dp_PathChange?"True":"False"));	
}

Boolean BtGetA2dpPathChange(void)
{
	return gA2dp_PathChange;
}
#endif /* LGE_LEMANS_BLUETOOTH */

/****************************************************************************
** PCM Control
****************************************************************************/
/****************************************************************************
** TRUE:  PCM ����� ����
** FALSE: PCM ������� ���� �ʱ� 
****************************************************************************/
static Boolean gEnablePcm = TRUE;
void BtSetEnablePcm(Boolean flag)
{
	gEnablePcm = flag;
}

Boolean BtGetEnablePcm(void)
{
	return gEnablePcm;
}

/***************************************************************************
* Audio
***************************************************************************/
/* Normal call On or OFF : Set audio path Phone(FALSE) or Bluetooth Device(TRUE)*/
void BtFlag_SetSpeechEn(Boolean flag)
{
	BT_DEBUG(("[MMI] BtFlag_SetSpeechEn flag=%d", flag));
	gBtFlag_SpeechEn = flag;
}

Boolean BtFlag_IsSpeechEn(void)
{
	BT_DEBUG(("[MMI] BtFlag_IsSpeechEn, gBtFlag_SpeechEn=%d", gBtFlag_SpeechEn));
	return gBtFlag_SpeechEn;
}

/* PCM ON or OFF */
void BtFlag_SetAudioOpen(Boolean flag)
{
	gBtFlag_Audio = flag;
}

Boolean BtFlag_IsAudioOpen(void)
{
	return gBtFlag_Audio;
}

void BtFlag_SetAudioMicMute(Boolean flag)
{
	gBtFlag_AudioMicMute = flag;
}

Boolean BtFlag_IsAudioMicMute(void)
{
	BT_DEBUG(("[MMI] BtFlag_IsAudioMicMute:%d", gBtFlag_AudioMicMute));
	return gBtFlag_AudioMicMute;
}

void BtFlag_SetSpkGainFromAg(Boolean flag) /* BT_COMMON_TIBURONA_080116 */
{
	gBtFlag_ChangeSpkGainFromAg = flag;
	BT_DEBUG(("[MMI] BtFlag_SetSpkGainFromAg():%s", gBtFlag_ChangeSpkGainFromAg?"True":"False"));	
}

Boolean BtFlag_ChangeSpkGainFromAg(void)
{
	return gBtFlag_ChangeSpkGainFromAg;
}

/***************************************************************************
* Connection
***************************************************************************/
/* GX_LEEJINBAEK_070211 */
Boolean BTFlag_IsHeadsetConnected(void)
{
	if(BtFlag_IsConnected(BT_PROFILE_HEADSET) || BtFlag_IsConnected(BT_PROFILE_HANDSFREE))
	{
		return TRUE;
	}
       else
       {
		return FALSE;
       }
}

Boolean BtFlag_IsAnyAudioDevConnected(void)
{
	if (BtFlag_IsConnected(BT_PROFILE_HEADSET) ||BtFlag_IsConnected(BT_PROFILE_HANDSFREE) ||BtFlag_IsConnected(BT_PROFILE_A2DP))
	{
		return TRUE;
	}
       else
       {
		return FALSE;
       }
}

/***************************************************************************
* Audio Path: Phone or Bluetooth Device
***************************************************************************/
	
/* LGE_MERGE_BLUETOOTH : 2004.11.03 IRON Insert for AGW/HFK control */
void BtFlag_SetAudioPathPhone(Boolean flag)
{
	BT_DEBUG(("BtFlag_SetAudioPathPhone flag=%d", flag));
	gBtFlag_AudioPathPhone = flag;
}

Boolean BtFlag_IsAudioPathPhone(void)
{
	return gBtFlag_AudioPathPhone;
}

/* BT_MMI_KIMSANGJIN_050913 */
Boolean IsUseBTAudio(void)
{
	   if((BtFlag_IsEnabled() == TRUE) 
	   	 &&(BtFlag_IsConnected(BT_PROFILE_HEADSET) == TRUE ||BtFlag_IsConnected(BT_PROFILE_HANDSFREE) == TRUE))
	   {
#if 0	   
	               if(BtFlag_IsAudioPathPhone() == TRUE)
			     return FALSE;
		        else
#endif					
			     return TRUE;
	   }
	   else
	   {
                       return FALSE;
	   }
}
/* end of BT_MMI_KIMSANGJIN_050913 */


/*-------------------------------------------------------------------------*/
/* Flag for Bluetooth operation timeout                                    */
/*-------------------------------------------------------------------------*/

void BtFlag_SetTimeOutFlag(Boolean flag)
{
	gBtFlag_TimeOutFlag = flag;
}

Boolean BtFlag_GetTimeOutFlag(void)
{
	return gBtFlag_TimeOutFlag;
}

/*-------------------------------------------------------------------------*/
/* Flag for Bluetooth ON                                  */
/*-------------------------------------------------------------------------*/

void BtFlag_SetShutdownFromTimer(Boolean flag)
{
	gBtFlag_ShutdownFromTimer = flag;
	BT_DEBUG(("Set(ShutdownFromTimer)=%c", gBtFlag_ShutdownFromTimer ? 'T' : 'F'));
}

Boolean BtFlag_GetShutdownFromTimer(void)
{
	BT_DEBUG(("Get(ShutdownFromTimer)=%c", gBtFlag_ShutdownFromTimer ? 'T' : 'F'));
	return gBtFlag_ShutdownFromTimer;
}

Boolean IsBtPcmClosewait=FALSE;
Boolean BtGetPCMCloseWait(void)
{
	return IsBtPcmClosewait;
}
void BtSetPCMCloseWait(Boolean flag)
{
	IsBtPcmClosewait=flag;
}

Boolean IsBtaudio=TRUE;
Boolean IsAudioPathBt(void)
{
	return IsBtaudio;
}
void BtSetAudioPath2BT(Boolean flag)
{
	IsBtaudio=flag;
}

Boolean IsExistWaitCall=FALSE;
void IsSetExistWaitCall(Boolean flag)
{
	IsExistWaitCall = flag;
}
Boolean IsGetExistWaitCall(void)
{
	return IsExistWaitCall;
}

Boolean gTextualUI= FALSE;
void BTSetTextualUI(Boolean flag)
{
	 gTextualUI= flag;
}
Boolean BTGetTextualUI(void)
{
	return gTextualUI;
}

/*Start of hfp15 20071001 baeheejung*/
void BTSetExtendedErrorFlag(Boolean flag)
{
	gBtFlag_extendedError = flag;
	BT_DEBUG(("[MMI]BTSetExtendedErrorFlag : gBtFlag_extendedError: %s",gBtFlag_extendedError?"TRUE":"FALSE"));
}

Boolean BTGetExtendedErrorFlag(void)
{
	return gBtFlag_extendedError;
}
/*End of hfp15 20071001 baeheejung*/
#endif /* LGE_L1_BLUETOOTH */

/* End Of File */

