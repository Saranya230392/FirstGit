/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfs_apex.c

DESCRIPTION:	     Functions of TTPCom File Sytem for Bluetooth

History:
**************************************************************************/

#define MODULE_NAME "BTFS_APEX"

#if defined(LGE_APEX_FS_BLUETOOTH)
#if defined(UPGRADE_FSYSTEM)
/****************************************************************************
* Include Files
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <kernel.h>
#include <system.h>
#include <ki_sig.h>

#if !defined (LGEBTTYPE_H)
#include "Lgebttype.h"
#endif

#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

#if !defined (BTFS_APEX_H)
#include "btfs_apex.h"
#endif

#if !defined (ABFS_SIG_H)
#include "abfs_sig.h"
#endif

#if !defined (ABFS_TYP_H)
#include <abfs_typ.h>
#endif

#if !defined (__STANDTYP_H)
#include "standtyp.h"
#endif

#if !defined (__FFS_CMN_H)
#include "Ffs_cmn.h"
#endif

#if !defined (AFGL_FNC_H)
#include "afgl_fnc.h"
#endif

#if defined(LGE_MMI_EXTERNAL_MEMORY)
#include <Afsh_lcl.h>
#endif

union Signal
{
	ApexFsStatusReq              		apexFsStatusReq;
	ApexFsStatusCnf               		apexFsStatusCnf;
	ApexFsStatusInd               		apexFsStatusInd;
	ApexFsOpenReq                 		apexFsOpenReq;
	ApexFsOpenCnf                 		apexFsOpenCnf;
	ApexFsReadReq                 		apexFsReadReq;
	ApexFsReadCnf                 		apexFsReadCnf;
	ApexFsWriteReq                		apexFsWriteReq;
	ApexFsWriteCnf                		apexFsWriteCnf;
	ApexFsCloseReq                		apexFsCloseReq;
	ApexFsCloseCnf                		apexFsCloseCnf;
	ApexFsRemoveReq            		apexFsRemoveReq;
	ApexFsRemoveCnf            		apexFsRemoveCnf;
	ApexFsMkfsReq                 		apexFsMkfsReq;
	ApexFsMkfsCnf                 		apexFsMkfsCnf;
	ApexFsMkdirReq                		apexFsMkdirReq;
	ApexFsMkdirCnf                		apexFsMkdirCnf;
	ApexFsRmdirReq                		apexFsRmdirReq;
	ApexFsRmdirCnf                		apexFsRmdirCnf;
	ApexFsOpenDirReq              	apexFsOpenDirReq;
	ApexFsOpenDirCnf              		apexFsOpenDirCnf;
	ApexFsCloseDirReq             		apexFsCloseDirReq;
	ApexFsCloseDirCnf             		apexFsCloseDirCnf;
	ApexFsReadDirReq              		apexFsReadDirReq;
	ApexFsReadDirCnf              		apexFsReadDirCnf;
	ApexFsRewindDirReq          		apexFsRewindDirReq;
	ApexFsRewindDirCnf           	 	apexFsRewindDirCnf;
	ApexFsStatReq                		apexFsStatReq;
	ApexFsStatCnf                 		apexFsStatCnf;
	ApexFsTruncateReq          		apexFsTruncateReq;
	ApexFsTruncateCnf          		apexFsTruncateCnf;
	ApexFsFseekReq              		apexFsFseekReq;
	ApexFsFseekCnf                		apexFsFseekCnf;
	ApexFsRenameReq            		apexFsRenameReq;
	ApexFsRenameCnf            		apexFsRenameCnf;
	ApexFsLabelReq              		apexFsLabelReq;
	ApexFsLabelCnf              		apexFsLabelCnf;
	ApexFsInitialisedInd        		apexFsInitialisedInd;
/* LEMAN_HYUNGMOON.KIM_061226 : Add code for FS. */     
	ApexFsFtellReq              		apexFsFtellReq;
	ApexFsFtellCnf               		apexFsFtellCnf;   
	ApexFsFstatReq              		apexFsFstatReq;
	ApexFsFstatCnf              		apexFsFstatCnf;
	ApexFsDiskSizeInfoReq             	apexFsDiskSizeInfoReq;
	ApexFsDiskSizeInfoCnf            	apexFsDiskSizeInfoCnf;    
	ApexFsGetNumOfEntryInDirReq	apexFsGetNumOfEntryInDirReq;
	ApexFsGetNumOfEntryInDirCnf	apexFsGetNumOfEntryInDirCnf;
	ApexFsGetFileListReq			apexFsGetFileListReq;
	ApexFsGetFileListCnf			apexFsGetFileListCnf;
};

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/

#if defined(LGE_MMI_EXTERNAL_MEMORY)
	Boolean OpenRootDir = FALSE;
	Boolean OneCycle = FALSE;
#endif
static TaskId 		RequesterTaskId = BTFTP_TASK_ID;
static Int32 		gFileErrCode;
static KiUnitQueue	FTPPendingQueue;

#if defined(ENABLE_LGE_EXFS_TASK) 
static TaskId		fileSystemTaskId = L1EXFS_TASK_ID;
#else
static TaskId  	fileSystemTaskId = TASK_FS_ID;
#endif /*ENABLE_LGE_EXFS_TASK*/

// BT_COMMON LEEJINBAEK 20071205 : we need to know changed file name in LGBX for copying DRM contents
#if defined (LGE_DRM)
static Int16	latestOpendFileName[MAX_FILE_PATH_LEN];
#endif
/****************************************************************************
* Type Definitions
****************************************************************************/

/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Global Variables
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/
// BT_COMMON LEEJINBAEK 20071205 : we need to know changed file name in LGBX for copying DRM contents
#if defined (LGE_DRM)
Int16 * BtfsGetLatestOpendFileName(void)
{
	return latestOpendFileName;
}
#endif
/*-----------------27/04/99 12:19-------------------
 * UCS2 version of strlen
 * The function returns the number of Int16 characters
 * in the string string_p, not including its terminating
 * null character.
 * --------------------------------------------------*/
Int16
BtutStrlenUcs2(const Int16  *string_p)
{
  Int16 strLength = 0;

  DevAssert (string_p != PNULL);

  while(*string_p != 0)
  {
     string_p++;
     strLength++;
  }

  return(strLength);
}

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
* Global Functions
****************************************************************************/
/****************************************************************************

				TTPCOM File System Interface for Bluetooth
				
	O_RDONLY 	: open for reading only
	O_WRONLY	: open for writing only
	O_RDWR		: open for reading and writing

	O_CREAT 	: create if nonexistent
	O_TRUNC 	: truncate to zero length
	O_EXCL		: error if already exists
	O_APPEND 	: set append mode

'w' - ���� �������� �����ϴ�; ���� �����͸� ������ �� �տ� �����ϴ� �׸��� ������ ũ�⸦ 0���� ����ϴ�. ������ ������ ����ϴ�. 
'w+' - �б� ���Ⱑ �����մϴ�; ���������͸� ������ �� �տ� �����ϴ�. �׸��� ������ ũ�⸦0���� ����ϴ�. ������ ������ ����ϴ�. 

'a' - ���� �������� �����ϴ�; ���� �����͸� ������ ���� �����ϴ�. ������ ������ ����ϴ�. 
'a+' - �б� ���Ⱑ �����մϴ�; ���� �����͸� ������ ���� �����ϴ�. ������ ������ ����ϴ�. 

'r' - �б��������� �����ϴ�; ���������͸� ������ �� �տ� �����ϴ�. 
'r+' - �б� ���Ⱑ �����մϴ�.; ���� �����͸� ������ �� �տ� �����ϴ�. 

****************************************************************************/\
FileID *btfs_apex_open(char *fileName, char *mode)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( fileName );	/* BT_COMMON_KIMSANGJIN_071025 */
	Int16 commandRef = afglGetUniqueId();
  	FileID *file_p=PNULL;
	SignedInt32 errCode;
	Boolean keepGoing = TRUE;

	DevAssert(fileName != PNULL);
	DevAssert(mode != PNULL);

	BT_DEBUG(("btfs_apex_open() fileName=[%s], mode[%s]", fileName, mode));

	/*Check mode is valid */
	if ( *mode != 'r' && *mode != 'a' && *mode != 'w' )
	{
		/*Invalid mode */
    		BT_DEBUG(("btfs_apex_open() BadMode %c should be r,a or w", *mode));
		KiFreeMemory ((void**)&ucs2FileName); /* BT_COMMON_KIMSANGJIN_071025 */
		return PNULL;
	}	
	
	KiCreateSignal ( SIG_APEX_FS_OPEN_REQ, sizeof (ApexFsOpenReq), &sendSignal );
	sendSignal.sig->apexFsOpenReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsOpenReq.commandRef = commandRef;	
	STRCPY(sendSignal.sig->apexFsOpenReq.filePathString.name, ucs2FileName); /* BT_COMMON_KIMSANGJIN_071025 */
	// BT_COMMON LEEJINBAEK 20071205 : backup changed file name for MMI handler
	#if defined (LGE_DRM)
	memset(latestOpendFileName, 0x00, sizeof(Int16)*(MAX_FILE_PATH_LEN));
	STRCPY(latestOpendFileName, ucs2FileName);
	#endif
	//BtutExpandStrcpy(&sendSignal.sig->apexFsOpenReq.filePathString.name[0], fileName);	
	sendSignal.sig->apexFsOpenReq.filePathString.length = BtutStrlenUcs2(&sendSignal.sig->apexFsOpenReq.filePathString.name[0]);
	strcpy(sendSignal.sig->apexFsOpenReq.accessOptions, mode);
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_OPEN_CNF &&	
			recvSignal.sig->apexFsOpenCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	errCode = recvSignal.sig->apexFsOpenCnf.fsError;
	if(errCode==0)
		file_p = (FileID *)recvSignal.sig->apexFsOpenCnf.fileStructurePtr;
	gFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName); /* BT_COMMON_KIMSANGJIN_071025 */

	if (errCode != 0)
	{
		BT_DEBUG(("\x1b[31m btfs_apex_open() Failure errCode=[%ld] errCode(PNULL) \x1b[0m ", errCode));
	  	file_p = PNULL;
	}
	else
	{ 	
		BT_DEBUG(("=============== btfs_apex_open() fid [%p]", file_p));
		BT_DEBUG(("btfs_apex_open() Success errCode=[%ld], file_p=%p", errCode, file_p));
	}
	
	return file_p;
}

SignedInt32 btfs_apex_read(FileID *file_p, void *buf, Int32 len)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef =afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 retVal=0;	
	Boolean keepGoing = TRUE;	

	DevAssert(file_p != PNULL);
	DevAssert(buf != PNULL);

	KiCreateSignal ( SIG_APEX_FS_READ_REQ, sizeof (ApexFsReadReq), &sendSignal );
	sendSignal.sig->apexFsReadReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsReadReq.commandRef = commandRef;
	sendSignal.sig->apexFsReadReq.fileStructurePtr = file_p;
	sendSignal.sig->apexFsReadReq.numBytes = len;
	sendSignal.sig->apexFsReadReq.readBufferPtr = buf;
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_READ_CNF &&	
			recvSignal.sig->apexFsReadCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsReadCnf.fsError;
	if(errCode==0)
		retVal = recvSignal.sig->apexFsReadCnf.numBytesRead;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);
	
	if (errCode != 0)
	{
		BT_DEBUG(("\x1b[31m btfs_apex_read() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}
	else
	{ 	
		BT_DEBUG(("btfs_apex_read() numBytesRead=[%ld] ", retVal));	
		BT_DEBUG(("btfs_apex_read() Success errCode=[%ld]", errCode));
	}

	return retVal;
}

SignedInt32 btfs_apex_write(FileID *file_p, void *buf, Int32 len)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef =afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 retVal=0;	
	Boolean keepGoing = TRUE;	

	DevAssert(file_p != PNULL);
	DevAssert(buf != PNULL);

	KiCreateSignal ( SIG_APEX_FS_WRITE_REQ, sizeof (ApexFsWriteReq), &sendSignal );
	sendSignal.sig->apexFsWriteReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsWriteReq.commandRef = commandRef;
	sendSignal.sig->apexFsWriteReq.fileStructurePtr = file_p;
	sendSignal.sig->apexFsWriteReq.numBytes = len;
	sendSignal.sig->apexFsWriteReq.writeBufferPtr = buf;
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_WRITE_CNF &&	
			recvSignal.sig->apexFsWriteCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsWriteCnf.fsError;
	if(errCode==0)
		retVal = recvSignal.sig->apexFsWriteCnf.numBytesWritten;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);
	
	if (errCode != 0)
	{
		BT_DEBUG(("\x1b[31m btfs_apex_write() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}
	else
	{ 	
		BT_DEBUG(("btfs_apex_write() numBytesWritten=[%ld] ", retVal));
		BT_DEBUG(("btfs_apex_write() Success errCode=[%ld]", errCode));
	}

	return retVal;
}

SignedInt32 btfs_apex_close(FileID *file_p)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId ();
	SignedInt32 errCode;
	SignedInt32 retVal=0;	
	Boolean keepGoing = TRUE;

	DevAssert(file_p != PNULL);

	KiCreateSignal(SIG_APEX_FS_CLOSE_REQ, sizeof(ApexFsCloseReq), &sendSignal);
	sendSignal.sig->apexFsCloseReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsCloseReq.commandRef = commandRef;
	sendSignal.sig->apexFsCloseReq.fileStructurePtr = file_p;
	KiSendSignal(fileSystemTaskId, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_CLOSE_CNF && 
			recvSignal.sig->apexFsCloseCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsCloseCnf.fsError;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);

	if (errCode==0)
	{
		BT_DEBUG(("btfs_apex_close() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_close() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_stat(char *fileName, Stat *statBuf_p)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef =afglGetUniqueId();
	Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( fileName );	/* BT_COMMON_KIMSANGJIN_071025 */
	SignedInt32 errCode;
	SignedInt32 retVal=0;	
	Boolean keepGoing = TRUE;	

	DevAssert(fileName != PNULL);
	DevAssert(statBuf_p != PNULL);

	BT_DEBUG(("btfs_apex_stat() start fileName=%s", fileName));
	KiCreateSignal ( SIG_APEX_FS_STAT_REQ, sizeof (ApexFsStatReq), &sendSignal );
	sendSignal.sig->apexFsStatReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsStatReq.commandRef = commandRef;
	STRCPY(sendSignal.sig->apexFsStatReq.filePathString.name, ucs2FileName); /* BT_COMMON_KIMSANGJIN_071025 */
	//BtutExpandStrcpy(&sendSignal.sig->apexFsStatReq.filePathString.name[0], fileName);	
	sendSignal.sig->apexFsStatReq.filePathString.length = BtutStrlenUcs2(&sendSignal.sig->apexFsStatReq.filePathString.name[0]);
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_STAT_CNF &&	
			recvSignal.sig->apexFsStatCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsStatCnf.fsError;

	if(errCode==0)
	{
	    	memcpy(statBuf_p, &recvSignal.sig->apexFsStatCnf.fsStat, sizeof(Stat)); /* check again */
		BT_DEBUG(("btfs_apex_stat() ========================="));
		BT_DEBUG((" 1. st_dev(Logical drive number)=%d  ", statBuf_p->st_dev));
		BT_DEBUG((" 2. st_ino(Unique file number)=%d  ", statBuf_p->st_ino));
		BT_DEBUG((" 3. st_nlink(Number of links to file)=%d  ", statBuf_p->st_nlink));
		BT_DEBUG((" 4. st_mode(File permissions)=0x%x  ", statBuf_p->st_mode));
		BT_DEBUG((" 5. st_rdev(Device file)=%d  ", statBuf_p->st_rdev));
		BT_DEBUG((" 6. st_size(File size in bytes)=%d  ", statBuf_p->st_size));
		BT_DEBUG((" 7. st_mtime(File modification time)=%d  ", statBuf_p->st_mtime));
		BT_DEBUG((" 8. st_atime(File access time)=%d  ", statBuf_p->st_atime));
		BT_DEBUG((" 9. st_ctime(File create time)=%d  ", statBuf_p->st_ctime));
		BT_DEBUG((" 10. st_uid(File owner)=%d  ", statBuf_p->st_uid));	
		BT_DEBUG((" 11. st_gid(File owner's group)=%d  ", statBuf_p->st_gid));	
		BT_DEBUG(("======================================="));
	}			
	gFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName); /* BT_COMMON_KIMSANGJIN_071025 */

	if(errCode==0)
	{
		BT_DEBUG(("btfs_apex_stat() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_stat() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_fstat(FileID *file_p, Stat *statBuf_p)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 retVal=0;	
	Boolean keepGoing = TRUE;	

	DevAssert(file_p != PNULL);
	DevAssert(statBuf_p != PNULL);

	KiCreateSignal ( SIG_APEX_FS_FSTAT_REQ, sizeof (ApexFsFstatReq), &sendSignal );
	sendSignal.sig->apexFsFstatReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsFstatReq.commandRef = commandRef;
	sendSignal.sig->apexFsFstatReq.fileStructurePtr = (void *)file_p;
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_FSTAT_CNF &&	
			recvSignal.sig->apexFsStatCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsFstatCnf.fsError;

	if(errCode==0)
	    	memcpy(statBuf_p, &recvSignal.sig->apexFsFstatCnf.fsStat, sizeof(Stat)); /* check again */
	gFileErrCode = errCode;

	BT_DEBUG(("btfs_apex_stat() ========================="));
	BT_DEBUG((" 1. st_dev(Logical drive number)=%d  ", statBuf_p->st_dev));
	BT_DEBUG((" 2. st_ino(Unique file number)=%d  ", statBuf_p->st_ino));
	BT_DEBUG((" 3. st_nlink(Number of links to file)=%d  ", statBuf_p->st_nlink));
	BT_DEBUG((" 4. st_mode(File permissions)=%d  ", statBuf_p->st_mode));
	BT_DEBUG((" 5. st_rdev(Device file)=%d  ", statBuf_p->st_rdev));
	BT_DEBUG((" 6. st_size(File size in bytes)=%d  ", statBuf_p->st_size));
	BT_DEBUG((" 7. st_mtime(File modification time)=%d  ", statBuf_p->st_mtime));
	BT_DEBUG((" 8. st_atime(File access time)=%d  ", statBuf_p->st_atime));
	BT_DEBUG((" 9. st_ctime(File create time)=%d  ", statBuf_p->st_ctime));
	BT_DEBUG((" 10. st_uid(File owner)=%d  ", statBuf_p->st_uid));	
	BT_DEBUG((" 11. st_gid(File owner's group)=%d  ", statBuf_p->st_gid));	
	BT_DEBUG(("======================================="));
	
	KiDestroySignal (&recvSignal);

	if(errCode==0)
	{
		BT_DEBUG(("btfs_apex_stat() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_stat() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_ftell(FileID *file_p)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 retVal=0;
	Int32 newPos=0;
	Boolean keepGoing = TRUE;	

	DevAssert(file_p != PNULL);

	KiCreateSignal ( SIG_APEX_FS_FTELL_REQ, sizeof (ApexFsFtellReq), &sendSignal );
	sendSignal.sig->apexFsFtellReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsFtellReq.commandRef = commandRef;
	sendSignal.sig->apexFsFtellReq.fileStructurePtr = (void *)file_p;
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_FTELL_CNF &&	
			recvSignal.sig->apexFsFtellCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsFtellCnf.fsError;

	if(errCode==0)
		newPos = recvSignal.sig->apexFsFseekCnf.newPos;
	gFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);

	if(errCode==0)
	{
		BT_DEBUG(("btfs_apex_ftell() Success errCode=[%ld], newPos=%d", errCode, newPos));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_ftell() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_diskinfo_free_space(char driverLetter)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 totalSize=0;		/* bytes */
	SignedInt32 freeSize=0;		/* bytes */
	SignedInt32 usedSize=0;		/* bytes */  
	Boolean keepGoing = TRUE;	


	KiCreateSignal ( SIG_APEX_FS_DISKINFO_REQ, sizeof (ApexFsDiskSizeInfoReq), &sendSignal );
	sendSignal.sig->apexFsDiskSizeInfoReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsDiskSizeInfoReq.commandRef = commandRef;
	sendSignal.sig->apexFsDiskSizeInfoReq.driveLetter = driverLetter; /* a volume (partition - e.g. C:\) label */
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_DISKINFO_CNF &&	
			recvSignal.sig->apexFsDiskSizeInfoCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	errCode = recvSignal.sig->apexFsDiskSizeInfoCnf.fsError;
	if(errCode==0)
	{
		totalSize = recvSignal.sig->apexFsDiskSizeInfoCnf.totalSize;
		freeSize = recvSignal.sig->apexFsDiskSizeInfoCnf.freeSize;
		usedSize = recvSignal.sig->apexFsDiskSizeInfoCnf.usedSize;
	}
	gFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);

	if(errCode==0)
	{
		BT_DEBUG(("btfs_apex_diskinfo_free_space() Success errCode=[%ld], freeSize=%d", errCode, freeSize));	
	}
	else
	{
		freeSize = EINVAL;	
		BT_DEBUG(("\x1b[31m btfs_apex_diskinfo_free_space() Failure errCode=[%ld] freeSize=%d \x1b[0m", errCode, freeSize));
	}
	return freeSize;
}

SignedInt32 btfs_apex_get_num_of_entry_in_dir(char *dirPathNamePtr, char *fileNamePtr)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 *ucs2dirPathNamePtr = BtconvertFileNameToUcs2 ( dirPathNamePtr );
	Int16 *ucs2fileNamePtr = BtconvertFileNameToUcs2 ( fileNamePtr );	
	Int16 commandRef = afglGetUniqueId ();
	SignedInt32 errCode;
	Int16 numOfEntryInDir=0;
	Boolean keepGoing = TRUE;

	DevAssert(dirPathNamePtr != PNULL);
	DevAssert(fileNamePtr != PNULL);

	BT_DEBUG(("btfs_apex_get_num_of_entry_in_dir() dirPathNamePtr=[%s] ", dirPathNamePtr));
	BT_DEBUG(("btfs_apex_get_num_of_entry_in_dir() fileNamePtr=[%s] ", fileNamePtr));
	
	KiCreateSignal ( SIG_APEX_FS_GET_NUM_OF_ENTRY_IN_DIR_REQ, sizeof (ApexFsGetNumOfEntryInDirReq), &sendSignal );
	sendSignal.sig->apexFsGetNumOfEntryInDirReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsGetNumOfEntryInDirReq.commandRef = commandRef;
	sendSignal.sig->apexFsGetNumOfEntryInDirReq.dirPathNamePtr = ucs2dirPathNamePtr;
	sendSignal.sig->apexFsGetNumOfEntryInDirReq.fileNamePtr = ucs2fileNamePtr;	
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_GET_NUM_OF_ENTRY_IN_DIR_CNF &&	
			recvSignal.sig->apexFsGetNumOfEntryInDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsGetNumOfEntryInDirCnf.fsError;
	if(errCode==0)
		numOfEntryInDir = recvSignal.sig->apexFsGetNumOfEntryInDirCnf.numOfEntryInDir;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2dirPathNamePtr );
	KiFreeMemory ((void**)&ucs2fileNamePtr );
	
	if (errCode==0)
	{
		BT_DEBUG(("btfs_apex_get_num_of_entry_in_dir() numOfEntryInDir=[%ld]", numOfEntryInDir));
		BT_DEBUG(("btfs_apex_get_num_of_entry_in_dir() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_get_num_of_entry_in_dir() Failure errCode=[%ld] \x1b[0m", errCode));
		numOfEntryInDir = EINVAL;
	}

	return numOfEntryInDir;
}

FileLIST *btfs_apex_get_file_list(Int16 numOfEntryRequested, Int16 startingIndexOfEntry, char *dirPathNamePtr, char *fileNamePtr)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 *ucs2dirPathNamePtr = BtconvertFileNameToUcs2(dirPathNamePtr);
	Int16 *ucs2fileNamePtr = BtconvertFileNameToUcs2(fileNamePtr);
	Int16 commandRef = afglGetUniqueId();
	SignedInt32 errCode;
	Int16 numOfEntryReturned;	/* num of entries returned */	
	FileLIST *fileListPtr=PNULL;
	Boolean keepGoing = TRUE;

	DevAssert(dirPathNamePtr != PNULL);
	DevAssert(fileNamePtr != PNULL);

	BT_DEBUG(("btfs_apex_get_file_list() dirPathNamePtr=[%s] ", dirPathNamePtr));
	BT_DEBUG(("btfs_apex_get_file_list() fileNamePtr=[%s] ", fileNamePtr));
	
	KiCreateSignal ( SIG_APEX_FS_GET_FILE_LIST_REQ, sizeof (ApexFsGetFileListReq), &sendSignal );
	sendSignal.sig->apexFsGetFileListReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsGetFileListReq.commandRef = commandRef;
	sendSignal.sig->apexFsGetFileListReq.numOfEntryRequested = numOfEntryRequested; 	/* num of entry we want */
	sendSignal.sig->apexFsGetFileListReq.startingIndexOfEntry = startingIndexOfEntry;		/* starting index of entry */
	sendSignal.sig->apexFsGetFileListReq.dirPathNamePtr = ucs2dirPathNamePtr;
	sendSignal.sig->apexFsGetFileListReq.fileNamePtr = ucs2fileNamePtr;
	sendSignal.sig->apexFsGetFileListReq.fileListPtr = fileListPtr;
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_GET_FILE_LIST_CNF &&	
			recvSignal.sig->apexFsGetFileListReq.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsGetFileListCnf.fsError;
	if(errCode==0)
	{
		startingIndexOfEntry = recvSignal.sig->apexFsGetFileListCnf.startingIndexOfEntry;
		numOfEntryReturned = recvSignal.sig->apexFsGetFileListCnf.numOfEntryReturned;
		fileListPtr = recvSignal.sig->apexFsGetFileListCnf.fileListPtr;
		BT_DEBUG(("btfs_apex_get_file_list() startingIndexOfEntry=[%d], numOfEntryReturned=[%d]", startingIndexOfEntry, numOfEntryReturned));
	}
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2dirPathNamePtr );
	KiFreeMemory ((void**)&ucs2fileNamePtr );
	
	if (errCode != 0)
	{
		BT_DEBUG(("\x1b[31m btfs_apex_get_file_list() Failure errCode=[%ld] errCode(PNULL) \x1b[0m", errCode));
	  	fileListPtr = PNULL;
	}
	else
	{ 	
		BT_DEBUG(("btfs_apex_get_file_list() Success errCode=[%ld], fileListPtr=%p", errCode, fileListPtr));
	}
	
	return fileListPtr;
}


SignedInt32 btfs_apex_remove(char *fileName)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( fileName );	  /* BT_COMMON_KIMSANGJIN_071025 */
	Int16 commandRef = afglGetUniqueId ();
	SignedInt32 errCode;
	SignedInt32 retVal=0;
	Boolean keepGoing = TRUE;

	DevAssert(fileName != PNULL);

	BT_DEBUG(("btfs_apex_remove() fileName=[%s] ", fileName));

	KiCreateSignal ( SIG_APEX_FS_REMOVE_REQ, sizeof (ApexFsRemoveReq), &sendSignal );
	sendSignal.sig->apexFsRemoveReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsRemoveReq.commandRef = commandRef;
	//BtutExpandStrcpy(&sendSignal.sig->apexFsRemoveReq.filePathString.name[0], fileName);	
	//sendSignal.sig->apexFsRemoveReq.filePathString.length = BtutStrlenUcs2(&sendSignal.sig->apexFsRemoveReq.filePathString.name[0]);
	STRCPY(sendSignal.sig->apexFsRemoveReq.filePathString.name, ucs2FileName); /* BT_COMMON_KIMSANGJIN_071025 */
	sendSignal.sig->apexFsRemoveReq.filePathString.length = BtutStrlenUcs2(ucs2FileName);
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_REMOVE_CNF &&	
			recvSignal.sig->apexFsRemoveCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsRemoveCnf.fsError;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName); /* BT_COMMON_KIMSANGJIN_071025 */

	if (errCode==0)
	{
		BT_DEBUG(("btfs_apex_remove() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_remove() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_rename(char *oldName, char *newName)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId ();
	SignedInt32 errCode;
	SignedInt32 retVal=0;
	Boolean keepGoing = TRUE;

	DevAssert(oldName != PNULL);
	DevAssert(newName != PNULL);

	BT_DEBUG(("btfs_apex_rename() oldName=[%s] ", oldName));
	BT_DEBUG(("btfs_apex_rename() newName=[%s] ", newName));
	
	KiCreateSignal ( SIG_APEX_FS_RENAME_REQ, sizeof (ApexFsRenameReq), &sendSignal );
	sendSignal.sig->apexFsRenameReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsRenameReq.commandRef = commandRef;
	BtutExpandStrcpy(&sendSignal.sig->apexFsRenameReq.oldFilePathString.name[0], oldName);	
	sendSignal.sig->apexFsRenameReq.oldFilePathString.length = BtutStrlenUcs2(&sendSignal.sig->apexFsRenameReq.oldFilePathString.name[0]);
	BtutExpandStrcpy(&sendSignal.sig->apexFsRenameReq.newFilePathString.name[0], newName);	
	sendSignal.sig->apexFsRenameReq.newFilePathString.length = BtutStrlenUcs2(&sendSignal.sig->apexFsRenameReq.newFilePathString.name[0]);
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_RENAME_CNF &&	
			recvSignal.sig->apexFsRenameCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsRenameCnf.fsError;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);

	if (errCode==0)
	{
		//Char* BtutUcs2ToUtf8(const Int16* strSrc_p, const Int16 srcLen, Char* strDst_p, const Int16 dstLen);
		BT_DEBUG((" %s name was changed to %s ",(char *)oldName, (char *)newName));	
		BT_DEBUG(("btfs_apex_rename() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_rename() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_seek(FileID *file_p, Int8 offset, FseekDir fromwhere)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef =afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 retVal=0;	
	Int32 newPos=0;
	Boolean keepGoing = TRUE;	

	DevAssert(file_p != PNULL);

	KiCreateSignal ( SIG_APEX_FS_FSEEK_REQ, sizeof (ApexFsFseekReq), &sendSignal );
	sendSignal.sig->apexFsFseekReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsFseekReq.commandRef = commandRef;
	sendSignal.sig->apexFsFseekReq.fileStructurePtr = file_p;
	sendSignal.sig->apexFsFseekReq.offset = offset;
	sendSignal.sig->apexFsFseekReq.whence = fromwhere;
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_FSEEK_CNF &&	
			recvSignal.sig->apexFsFseekCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsFseekCnf.fsError;
	if(errCode==0)
		newPos = recvSignal.sig->apexFsFseekCnf.newPos;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);

	if (errCode==0)
	{
		BT_DEBUG(("btfs_apex_seek() Success errCode=[%ld], newPos=%d", errCode, newPos));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_seek() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

Boolean btfs_apex_exists(const char *fileName)
{
	struct stat statBuf_p;
	Boolean exist=FALSE;
	int  fsError=0;	

	if ( !fsysStat(fileName, &statBuf_p ) )
	{
		exist = TRUE;
	}
	else
	{
		exist = FALSE;
	}

	if (fserrno)
	{
		fsError = fserrno;
		/*kp230 20071029 baeheejung: C_00024*/
		//exist = TRUE;
		BT_DEBUG(("\x1b[31m btfs_apex_exists() Failure [%ld] \x1b[0m", fsError));
	}
	else
	{
		BT_DEBUG(("btfs_apex_exists() Success [%ld]", fsError));
	}
	
	return exist;
}

SignedInt32 btfs_apex_status(AbfsMountInfo *info_p)	
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 retVal=0;	
	Boolean keepGoing = TRUE;
	Int8 mountEntries=0;
	Int8 i;
	
	DevAssert(info_p != PNULL);

	KiCreateSignal ( SIG_APEX_FS_STATUS_REQ, sizeof (ApexFsStatusReq), &sendSignal );
	sendSignal.sig->apexFsStatusReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsStatusReq.commandRef = commandRef;
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_STATUS_CNF &&	
			recvSignal.sig->apexFsStatusCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	BT_DEBUG(("btfs_apex_status() ================"));
	mountEntries = recvSignal.sig->apexFsStatusCnf.mountEntries;	
    	memcpy(info_p, &recvSignal.sig->apexFsStatusCnf.mountInfo[1], sizeof(AbfsMountInfo)); /* check again */

	BT_DEBUG((" 1. mountEntries=%d  ", mountEntries));
	BT_DEBUG((" 2. driveLetter=[%c]  ", info_p->driveLetter));
	BT_DEBUG((" 3. physicalDevice=%d  ", info_p->physicalDevice));
	BT_DEBUG((" 4. partition=%d  ", info_p->partition));	
	BT_DEBUG((" 5. type=%d  ", info_p->type));	
	BT_DEBUG((" 6. blockSize=%d  ", info_p->blockSize));	
	BT_DEBUG((" 7. totalBlocks=%d  ", info_p->totalBlocks));		
	BT_DEBUG((" 8. freeBlocks=%d  ", info_p->freeBlocks));		
	BT_DEBUG((" 9. volName=%s  ", info_p->volName));			
	BT_DEBUG((" 10. properties.numberOfEntries=%d  ", info_p->properties.numberOfEntries));
	for(i=0; i<info_p->properties.numberOfEntries; i++)
		BT_DEBUG((" == 10-[%d] properties.list[%d]=%d  ", i+1, i, info_p->properties.list[i]));
	BT_DEBUG(("==============================="));
		
	KiDestroySignal (&recvSignal);

	BT_DEBUG(("btfs_apex_status() Success"));

	return retVal;
}

DirID btfs_apex_opendir(char *dirName)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	Int16 *ucs2DirName = BtconvertFileNameToUcs2 ( dirName );	/* BT_COMMON_KIMSANGJIN_071025 */
  	DirID dirRef=0;
	SignedInt32 errCode;
	Boolean keepGoing = TRUE;

	DevAssert(dirName != PNULL);

	BT_DEBUG(("btfs_apex_opendir() dirName=[%s] ", dirName));

#if defined(LGE_MMI_EXTERNAL_MEMORY)
#if defined(LGE_L1_DOUBLE_DRV)
if((strcmp(dirName, "B:/") == 0) || (strcmp(dirName, "b:/") == 0))
#else
if((strcmp(dirName, "A:/") == 0) || (strcmp(dirName, "a:/") == 0))
#endif /* LGE_L1_DOUBLE_DRV */
{
	OpenRootDir = TRUE;
	OneCycle = FALSE;
	BT_DEBUG(("strcmp:: dirName=[%s]", dirName));
}
#endif /* LGE_MMI_EXTERNAL_MEMORY */

	KiCreateSignal ( SIG_APEX_FS_OPEN_DIR_REQ, sizeof (ApexFsOpenDirReq), &sendSignal );
	sendSignal.sig->apexFsOpenDirReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsOpenDirReq.commandRef = commandRef;
	STRCPY(sendSignal.sig->apexFsOpenDirReq.filePathString.name, ucs2DirName); /* BT_COMMON_KIMSANGJIN_071025 */
	sendSignal.sig->apexFsOpenDirReq.filePathString.length = BtutStrlenUcs2(&sendSignal.sig->apexFsOpenDirReq.filePathString.name[0]);
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_OPEN_DIR_CNF &&	
			recvSignal.sig->apexFsOpenDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsOpenDirCnf.fsError;
	if(errCode==0)
		dirRef = recvSignal.sig->apexFsOpenDirCnf.dirRef;
	BT_DEBUG(("=============== btfs_apex_opendir() dirRef [%d]", dirRef));
	gFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2DirName); /* BT_COMMON_KIMSANGJIN_071025 */

	if (errCode != 0)
	{
		BT_DEBUG(("\x1b[31m btfs_apex_opendir() Failure errCode=[%ld] \x1b[0m", errCode));
		dirRef = EINVAL;
	}
	else
	{ 	
		BT_DEBUG(("btfs_apex_opendir() Success errCode=[%ld], dirRef=%d", errCode, dirRef));
	}

	return dirRef;
}

BtApexFsReadDir *btfs_apex_readdir(DirID dirRef)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	SignedInt32 errCode;
	Boolean keepGoing = TRUE;
	static BtApexFsReadDir readDir;
#if 0	
	char debugstr[MAX_FILE_PATH_LEN];
#endif

	BT_DEBUG((" "));
	BT_DEBUG(("btfs_apex_readdir() start dirRef=[%d] ", dirRef));

	KiCreateSignal ( SIG_APEX_FS_READ_DIR_REQ, sizeof (ApexFsReadDirReq), &sendSignal );
	sendSignal.sig->apexFsReadDirReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsReadDirReq.commandRef = commandRef;
	sendSignal.sig->apexFsReadDirReq.dirRef = dirRef;
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_READ_DIR_CNF &&	
			recvSignal.sig->apexFsReadDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	errCode = recvSignal.sig->apexFsReadDirCnf.fsError;
	if(errCode==0)
	{	
		memset(&readDir, 0x00, sizeof(BtApexFsReadDir));	
		readDir.nameTruncated = recvSignal.sig->apexFsReadDirCnf.nameTruncated;		
		memcpy(&readDir.filePathString, &recvSignal.sig->apexFsReadDirCnf.filePathString, sizeof(FilePath));
		memcpy(&readDir.fsStat, &recvSignal.sig->apexFsReadDirCnf.fsStat, sizeof(Stat));

		BT_DEBUG((" 04. st_mode(File permissions)=0x%x  ", readDir.fsStat.st_mode));
#if 0
/*==== For Debugging ===========================================================================*/
		BT_DEBUG(("btfs_apex_readdir() ==== Data Information Start =============="));
		memset(debugstr, 0x00, sizeof(char)*(MAX_FILE_PATH_LEN));
		BtconvertFileNameToChar(recvSignal.sig->apexFsReadDirCnf.filePathString.name, debugstr);
		BT_DEBUG((" 00-0. name=%s", debugstr));
		BT_DEBUG((" 00-0. length=%d, nameTruncated=%s", recvSignal.sig->apexFsReadDirCnf.filePathString.length, recvSignal.sig->apexFsReadDirCnf.nameTruncated?"True":"False"));		
		BT_DEBUG((" 01-0. st_dev(Logical drive number)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_dev));
		BT_DEBUG((" 02-0. st_ino(Unique file number)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_ino));
		BT_DEBUG((" 03-0. st_nlink(Number of links to file)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_nlink));
		BT_DEBUG((" 04-0. st_mode(File permissions)=0x%x  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_mode));
		BT_DEBUG((" 05-0. st_rdev(Device file)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_rdev));
		BT_DEBUG((" 06-0. st_size(File size in bytes)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_size));
		BT_DEBUG((" 07-0. st_mtime(File modification time)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_mtime));
		BT_DEBUG((" 08-0. st_atime(File access time)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_atime));
		BT_DEBUG((" 09-0. st_ctime(File create time)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_ctime));
		BT_DEBUG((" 10-0. st_uid(File owner)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_uid));	
		BT_DEBUG((" 11-0. st_gid(File owner's group)=%d  ", recvSignal.sig->apexFsReadDirCnf.fsStat.st_gid));	
		
		memset(debugstr, 0x00, sizeof(char)*(MAX_FILE_PATH_LEN));
		BtconvertFileNameToChar(readDir.filePathString.name, debugstr);
		BT_DEBUG((" 00. name=%s", debugstr));
		BT_DEBUG((" 00-0. length=%d, nameTruncated=%s", readDir.filePathString.length, readDir.nameTruncated?"True":"False"));		
		BT_DEBUG((" 01. st_dev(Logical drive number)=%d  ", readDir.fsStat.st_dev));
		BT_DEBUG((" 02. st_ino(Unique file number)=%d  ", readDir.fsStat.st_ino));
		BT_DEBUG((" 03. st_nlink(Number of links to file)=%d  ", readDir.fsStat.st_nlink));
		BT_DEBUG((" 04. st_mode(File permissions)=0x%x  ", readDir.fsStat.st_mode));
		BT_DEBUG((" 05. st_rdev(Device file)=%d  ", readDir.fsStat.st_rdev));
		BT_DEBUG((" 06. st_size(File size in bytes)=%d  ", readDir.fsStat.st_size));
		BT_DEBUG((" 07. st_mtime(File modification time)=%d  ", readDir.fsStat.st_mtime));
		BT_DEBUG((" 08. st_atime(File access time)=%d  ", readDir.fsStat.st_atime));
		BT_DEBUG((" 09. st_ctime(File create time)=%d  ", readDir.fsStat.st_ctime));
		BT_DEBUG((" 10. st_uid(File owner)=%d  ", readDir.fsStat.st_uid));	
		BT_DEBUG((" 11. st_gid(File owner's group)=%d  ", readDir.fsStat.st_gid));		
		BT_DEBUG(("btfs_apex_readdir() ==== Data Information End =============="));
/*==============================================================================================*/		
#endif
	}

	gFileErrCode = errCode;
	
	KiDestroySignal(&recvSignal);
#if defined(LGE_MMI_EXTERNAL_MEMORY)
	if( (errCode != 0)||((OneCycle == TRUE) &&(SDCardIsPresent() == SDCARD_IN)))
	{
		if((OpenRootDir==TRUE)&&(SDCardIsPresent() == SDCARD_IN))
		{
			OneCycle = TRUE;
			OpenRootDir = FALSE;
			memset(&readDir, 0x00, sizeof(BtApexFsReadDir));	
			readDir.fsStat.st_mode=S_IFDIR;
			readDir.fsStat.st_size=0;
			BtutExpandStrcpy(readDir.filePathString.name, "External memory");
			BT_DEBUG(("End of btfs_common_readdir() external was exist !!! "));

			return &readDir;
		}
		else
		{
		       OneCycle = FALSE;
			BT_DEBUG(("\x1b[31m btfs_apex_readdir() Failure errCode=[%ld] \x1b[0m", errCode));
			return PNULL;
		}
	}
#else /*LGE_MMI_EXTERNAL_MEMORY*/
	if (errCode != 0)
	{
		BT_DEBUG(("\x1b[31m btfs_apex_readdir() Failure errCode=[%ld] \x1b[0m", errCode));
              return PNULL;
	}
#endif/*LGE_MMI_EXTERNAL_MEMORY*/
	else
	{ 	
		if(readDir.filePathString.length==0)
		{
			BT_DEBUG(("\x1b[31m btfs_apex_readdir() errCode=[%ld], filePathString.length is zero[%d]. \x1b[0m", errCode, readDir.filePathString.length));
			return PNULL;	
		}
		else
		{
			BT_DEBUG(("btfs_apex_readdir() Success errCode=[%ld], dirRef=%d", errCode, dirRef));
		}
	}

	return &readDir;
}

SignedInt32 btfs_apex_closedir(DirID dirRef)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	SignedInt32 retVal=0;
	SignedInt32 errCode;
	Boolean keepGoing = TRUE;

	BT_DEBUG(("btfs_apex_closedir() dirRef=[%d] ", dirRef));

	KiCreateSignal ( SIG_APEX_FS_CLOSE_DIR_REQ, sizeof (ApexFsCloseDirReq), &sendSignal );
	sendSignal.sig->apexFsCloseDirReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsCloseDirReq.commandRef = commandRef;
	sendSignal.sig->apexFsCloseDirReq.dirRef = dirRef;
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_CLOSE_DIR_CNF &&	
			recvSignal.sig->apexFsCloseDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsCloseDirCnf.fsError;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);

	if (errCode==0)
	{
		BT_DEBUG(("btfs_apex_closedir() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_closedir() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_rewinddir(DirID dirRef)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
	SignedInt32 retVal=0;
	SignedInt32 errCode;
	Boolean keepGoing = TRUE;

	BT_DEBUG(("btfs_apex_rewinddir() dirRef=[%d] ", dirRef));
	
	KiCreateSignal ( SIG_APEX_FS_REWIND_DIR_REQ, sizeof (ApexFsRewindDirReq), &sendSignal );
	sendSignal.sig->apexFsRewindDirReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsRewindDirReq.commandRef = commandRef;
	sendSignal.sig->apexFsRewindDirReq.dirRef = dirRef;
	KiSendSignal(fileSystemTaskId, &sendSignal);   

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_REWIND_DIR_CNF &&	
			recvSignal.sig->apexFsRewindDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	errCode = recvSignal.sig->apexFsRewindDirCnf.fsError;
	if(errCode==0)
		dirRef = recvSignal.sig->apexFsRewindDirCnf.dirRef;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);

	if (errCode==0)
	{
		BT_DEBUG(("btfs_apex_rewinddir() Success errCode=[%ld], dirRef=%d", errCode, dirRef));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_rewinddir() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_rmdir(char *path)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef =afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 retVal=0;
	Boolean keepGoing = TRUE;	

	DevAssert(path!= PNULL);

	KiCreateSignal ( SIG_APEX_FS_RMDIR_REQ, sizeof (ApexFsRmdirReq), &sendSignal );
	sendSignal.sig->apexFsRmdirReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsRmdirReq.commandRef = commandRef;
	BtutExpandStrcpy(&sendSignal.sig->apexFsRmdirReq.filePathString.name[0], path);	
	sendSignal.sig->apexFsRmdirReq.filePathString.length = BtutStrlenUcs2(&sendSignal.sig->apexFsRmdirReq.filePathString.name[0]);
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_RMDIR_CNF &&	
			recvSignal.sig->apexFsRmdirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsRmdirCnf.fsError;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);

	if (errCode==0)
	{
		BT_DEBUG(("btfs_apex_rmdir() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_rmdir() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

SignedInt32 btfs_apex_mkdir(char *path)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef =afglGetUniqueId();
	SignedInt32 errCode;
	SignedInt32 retVal=0;	
	Boolean keepGoing = TRUE;	

	DevAssert(path!= PNULL);

	BT_DEBUG(("btfs_apex_mkdir() start dir name=[%s]", path));

	KiCreateSignal ( SIG_APEX_FS_MKDIR_REQ, sizeof (ApexFsMkdirReq), &sendSignal );
	sendSignal.sig->apexFsMkdirReq.taskId = RequesterTaskId;
	sendSignal.sig->apexFsMkdirReq.commandRef = commandRef;
	BtutExpandStrcpy(&sendSignal.sig->apexFsMkdirReq.filePathString.name[0], path);	
	sendSignal.sig->apexFsMkdirReq.filePathString.length = BtutStrlenUcs2(&sendSignal.sig->apexFsMkdirReq.filePathString.name[0]);
	KiSendSignal(fileSystemTaskId, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_APEX_FS_MKDIR_CNF &&	
			recvSignal.sig->apexFsMkdirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	errCode = recvSignal.sig->apexFsMkdirCnf.fsError;
	gFileErrCode = errCode;

	KiDestroySignal (&recvSignal);

	if (errCode==0)
	{
		BT_DEBUG(("btfs_apex_mkdir() Success errCode=[%ld]", errCode));	
	}
	else
	{ 
		BT_DEBUG(("\x1b[31m btfs_apex_mkdir() Failure errCode=[%ld] \x1b[0m", errCode));
		retVal = EINVAL;
	}

	return retVal;
}

Boolean btfs_apex_isdir(char *path)
{
	struct stat statBuf_p;
	SignedInt32 retVal=0;
	SignedInt32 fsError=0;
	
	retVal = fsysStat(path, &statBuf_p);

	if (fserrno)
		retVal = EINVAL;

	if (retVal < 0)
	{
		fsError = fserrno;
		BT_DEBUG(("btfs_apex_isdir() Failure [%ld]", fsError));
		//BT_DEVCHECK(TRUE, fsError, __FILE__, __LINE__);
		return FALSE;
	}
	else
	{
		fsError = 0;
		BT_DEBUG(("btfs_apex_isdir() Success [%ld]", fsError));		
		if ( statBuf_p.st_mode & S_IFDIR) 
		{
			BT_DEBUG(("btfs_apex_isdir() This is Directory"));
			return TRUE;
		}
		else 
		{
			BT_DEBUG(("btfs_apex_isdir() This is File"));		
			return FALSE;
		}
	}
}

#if defined(FILESYSTEM_TEST) /* Test Utilities(Used for verifying basic functions for File System) */
#define TEST_STRING				"0123456789"
#define TEST_STRING_SIZE		(strlen(TEST_STRING))
#define MAX_BUFFER_SIZE		(100*1024) 			/* 100 KB */

static char gBuffer[MAX_BUFFER_SIZE];

static Int32 FillBuffer(char *buffer, Int32 num)
{
	Int32 i;
	
	for (i = 0; i < num; i++)
	{
		memcpy(buffer + i * TEST_STRING_SIZE, TEST_STRING, TEST_STRING_SIZE);
	}
	return TEST_STRING_SIZE * num;
}

#define BTFS_ROOT_DIR_TEST	"b:/" 			
#define BTFS_DIR_TEST	"b:/bt" 			
#define BTFS_FILE_TEST	"b:/bt/1.txt" 

void apex_file_readwrite(void)
{
  	FileID *file_p=PNULL;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
	SignedInt32 retVal=0;

/* =============================================== */
	retVal = btfs_apex_mkdir(BTFS_DIR_TEST);
	BT_DEBUG(("btfs_apex_mkdir() = %d \n", retVal));
/* =============================================== */

/* =============================================== */
	file_p = btfs_apex_open(BTFS_FILE_TEST, "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	BT_DEBUG(("btfs_apex_write() start \n"));
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
/* =============================================== */

/* =============================================== */
	file_p = btfs_apex_open(BTFS_FILE_TEST, "r");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_out = btfs_apex_read(file_p, gBuffer, size_out);
	BT_DEBUG(("btfs_apex_read() retVal = [%d] \n", size_out));
	
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
	
	BT_DEBUG(("file name==[%s] : [%s]", BTFS_FILE_TEST, gBuffer));
/* =============================================== */	
	
	retVal = btfs_apex_remove(BTFS_FILE_TEST);
	BT_DEBUG(("btfs_apex_remove() retVal = [%d] \n", retVal));
}

void apex_file_write(void)
{
  	FileID *file_p=PNULL;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
	SignedInt32 retVal=0;
	SignedInt32 retVal_num=0;
	
	file_p = btfs_apex_open("b:/bt/test_1.txt" , "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
	
	BT_DEBUG((" "));
	file_p = btfs_apex_open("b:/bt/test_2.txt" , "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
	
	BT_DEBUG((" "));
	file_p = btfs_apex_open("b:/bt/test_3.txt" , "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));

	retVal_num = btfs_apex_get_num_of_entry_in_dir("b:/bt", "test_1.txt"); 			/*count file*/
	BT_DEBUG(("btfs_apex_get_num_of_entry_in_dir() dir name=[%s] retVal_num=[%d] \n", "b:/bt", retVal_num));
	retVal_num = btfs_apex_get_num_of_entry_in_dir("b:/bt", "b:/bt/test_1.txt"); /*count file*/
	BT_DEBUG(("btfs_apex_get_num_of_entry_in_dir() dir name=[%s] retVal_num=[%d]  \n", "a:/bt", retVal_num));	
	
}

void apex_get_list(void)
{
  	DirID retVal_opendir;
	BtApexFsReadDir *retVal_readdir=PNULL;
	char debugstr[MAX_FILE_PATH_LEN];
	SignedInt32 retVal_closedir;	
	SignedInt32 retVal_mkdir;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
  	FileID *file_p=PNULL;
	SignedInt32 retVal=0;
	char temp_string[MAX_FILE_PATH_LEN];
	Stat statBuf_p ={0,};

	retVal_mkdir = btfs_apex_mkdir(BTFS_DIR_TEST);
	BT_DEBUG(("btfs_apex_mkdir() = %d \n", retVal_mkdir));

	file_p = btfs_apex_open("b:/bt/Bt_test.txt", "a");	
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));

	retVal_opendir = btfs_apex_opendir(BTFS_ROOT_DIR_TEST);
	BT_DEBUG(("btfs_apex_opendir = [%d]", retVal_opendir));
		
	while ((retVal_readdir = btfs_apex_readdir(retVal_opendir)) != PNULL)
	{
		BT_DEBUG(("#1 apex_get_list() ========================="));
		memset(debugstr, 0x00, sizeof(char)*(MAX_FILE_PATH_LEN));
		BtconvertFileNameToChar(retVal_readdir->filePathString.name, debugstr);
		BT_DEBUG((" 0. dir name=%s", debugstr));
		BT_DEBUG((" 0. length=%d, nameTruncated=%s", retVal_readdir->filePathString.length, retVal_readdir->nameTruncated?"True":"False"));		
#if 0		
		BT_DEBUG((" 1. st_dev(Logical drive number)=%d  ", retVal_readdir->fsStat.st_dev));
		BT_DEBUG((" 2. st_ino(Unique file number)=%d  ", retVal_readdir->fsStat.st_ino));
		BT_DEBUG((" 3. st_nlink(Number of links to file)=%d  ", retVal_readdir->fsStat.st_nlink));
		BT_DEBUG((" 4. st_mode(File permissions)=%d  ", retVal_readdir->fsStat.st_mode));
		BT_DEBUG((" 5. st_rdev(Device file)=%d  ", retVal_readdir->fsStat.st_rdev));
		BT_DEBUG((" 6. st_size(File size in bytes)=%d  ", retVal_readdir->fsStat.st_size));
		BT_DEBUG((" 7. st_mtime(File modification time)=%d  ", retVal_readdir->fsStat.st_mtime));
		BT_DEBUG((" 8. st_atime(File access time)=%d  ", retVal_readdir->fsStat.st_atime));
		BT_DEBUG((" 9. st_ctime(File create time)=%d  ", retVal_readdir->fsStat.st_ctime));
		BT_DEBUG((" 10. st_uid(File owner)=%d  ", retVal_readdir->fsStat.st_uid));	
		BT_DEBUG((" 11. st_gid(File owner's group)=%d  ", retVal_readdir->fsStat.st_gid));	
#endif
		//BT_DEBUG(("======================================="));

		memset(temp_string, 0x00, sizeof(char)*(MAX_FILE_PATH_LEN));

		strcpy(temp_string, BTFS_ROOT_DIR_TEST);
		strcat(temp_string, debugstr);
		//BT_DEBUG(("temp_string=%s, debugstr=%s", temp_string, debugstr));
		retVal = btfs_apex_stat(temp_string, &statBuf_p);
		BT_DEBUG(("btfs_apex_stat() end retVal = [%d]", retVal));	
		BT_DEBUG(("#2 apex_get_list() ========================="));
		BT_DEBUG((" 1. st_dev(Logical drive number)=%d  ", statBuf_p.st_dev));
		BT_DEBUG((" 2. st_ino(Unique file number)=%d  ", statBuf_p.st_ino));
		BT_DEBUG((" 3. st_nlink(Number of links to file)=%d  ", statBuf_p.st_nlink));
		BT_DEBUG((" 4. st_mode(File permissions)=%d  ", statBuf_p.st_mode));
		BT_DEBUG((" 5. st_rdev(Device file)=%d  ", statBuf_p.st_rdev));
		BT_DEBUG((" 6. st_size(File size in bytes)=%d  ", statBuf_p.st_size));
		BT_DEBUG((" 7. st_mtime(File modification time)=%d  ", statBuf_p.st_mtime));
		BT_DEBUG((" 8. st_atime(File access time)=%d  ", statBuf_p.st_atime));
		BT_DEBUG((" 9. st_ctime(File create time)=%d  ", statBuf_p.st_ctime));
		BT_DEBUG((" 10. st_uid(File owner)=%d  ", statBuf_p.st_uid));	
		BT_DEBUG((" 11. st_gid(File owner's group)=%d  ", statBuf_p.st_gid));	
		BT_DEBUG(("======================================="));

	}

	retVal_closedir = btfs_apex_closedir(retVal_opendir);
	BT_DEBUG(("btfs_apex_closedir() = [%d]", retVal_closedir));
}

void apex_open_remove(void)
{
  	FileID *file_p=PNULL;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
	SignedInt32 retVal=0;

	file_p = btfs_apex_open("b:/bt/5.txt", "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
	
	retVal = btfs_apex_remove("b:/bt/5.txt");
	BT_DEBUG(("btfs_apex_remove() retVal = [%d] \n", retVal));
	
	BT_DEBUG((" "));
	apex_get_list();	
}

void apex_dir_make(void)
{
  	FileID *file_p=PNULL;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
	SignedInt32 retVal=0;
	SignedInt32 retVal_mkdir=0;

	retVal_mkdir = btfs_apex_mkdir(BTFS_DIR_TEST);
	BT_DEBUG(("btfs_apex_mkdir() = %d \n", retVal_mkdir));

	file_p = btfs_apex_open("b:/bt/Bt_test.txt", "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
}

void apex_remove_Dirfile(void)
{
  	FileID *file_p=PNULL;
	SignedInt32 retVal=0;

	retVal = btfs_apex_remove("b:/bt/Bt_test.txt");
	BT_DEBUG(("btfs_apex_remove() retVal = [%d] \n", retVal));
	
	file_p = btfs_apex_open("b:/bt/Bt_test.txt", "r");
}

void apex_free_space(void)
{
	SignedInt32 freeSize=0;		/* bytes */

	freeSize = btfs_apex_diskinfo_free_space('b');
	BT_DEBUG(("btfs_apex_diskinfo_free_space(b:) freeSize = [%d] \n", freeSize));
}

#define BTFS_ROOT_DIR_TEST_EXTERNAL		"e:/" 			
#define BTFS_DIR_TEST_EXTERNAL			"e:/bt" 			
#define BTFS_FILE_TEST_EXTERNAL			"e:/bt/1.txt" 

void apex_file_readwrite_external(void)
{
  	FileID *file_p=PNULL;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
	SignedInt32 retVal=0;

/* =============================================== */
	retVal = btfs_apex_mkdir(BTFS_DIR_TEST_EXTERNAL);
	BT_DEBUG(("btfs_apex_mkdir() = %d \n", retVal));
/* =============================================== */

/* =============================================== */
	file_p = btfs_apex_open(BTFS_FILE_TEST_EXTERNAL, "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	BT_DEBUG(("btfs_apex_write() start \n"));
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
/* =============================================== */

/* =============================================== */
	file_p = btfs_apex_open(BTFS_FILE_TEST_EXTERNAL, "r");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_out = btfs_apex_read(file_p, gBuffer, size_out);
	BT_DEBUG(("btfs_apex_read() retVal = [%d] \n", size_out));
	
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
	
	BT_DEBUG(("file name==[%s] : [%s]", BTFS_FILE_TEST_EXTERNAL, gBuffer));
/* =============================================== */	
	
	retVal = btfs_apex_remove(BTFS_FILE_TEST_EXTERNAL);
	BT_DEBUG(("btfs_apex_remove() retVal = [%d] \n", retVal));
}

void apex_file_write_external(void)
{
  	FileID *file_p=PNULL;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
	SignedInt32 retVal=0;
	SignedInt32 retVal_num=0;
	
	file_p = btfs_apex_open("e:/bt/test_1.txt" , "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
	
	BT_DEBUG((" "));
	file_p = btfs_apex_open("e:/bt/test_2.txt" , "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
	
	BT_DEBUG((" "));
	file_p = btfs_apex_open("e:/bt/test_3.txt" , "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));

	retVal_num = btfs_apex_get_num_of_entry_in_dir("e:/bt", "test_1.txt"); 			/*count file*/
	BT_DEBUG(("btfs_apex_get_num_of_entry_in_dir() dir name=[%s] retVal_num=[%d] \n", "a:/bt", retVal_num));
	retVal_num = btfs_apex_get_num_of_entry_in_dir("e:/bt", "e:/bt/test_1.txt"); /*count file*/
	BT_DEBUG(("btfs_apex_get_num_of_entry_in_dir() dir name=[%s] retVal_num=[%d]  \n", "a:/bt", retVal_num));	
	
}

void apex_get_list_external(void)
{
  	DirID retVal_opendir;
	BtApexFsReadDir *retVal_readdir=PNULL;
	char debugstr[MAX_FILE_PATH_LEN];
	SignedInt32 retVal_closedir;	
	SignedInt32 retVal_mkdir;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
  	FileID *file_p=PNULL;
	SignedInt32 retVal=0;
	char temp_string[MAX_FILE_PATH_LEN];
	Stat statBuf_p ={0,};

	retVal_mkdir = btfs_apex_mkdir(BTFS_DIR_TEST_EXTERNAL);
	BT_DEBUG(("btfs_apex_mkdir() = %d \n", retVal_mkdir));

	file_p = btfs_apex_open("e:/bt/Bt_test.txt", "a");	
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));

	retVal_opendir = btfs_apex_opendir(BTFS_ROOT_DIR_TEST_EXTERNAL);
//	retVal_opendir = btfs_apex_opendir(BTFS_DIR_TEST_EXTERNAL);
	BT_DEBUG(("btfs_apex_opendir = [%d]", retVal_opendir));
		
	while ((retVal_readdir = btfs_apex_readdir(retVal_opendir)) != PNULL)
	{
		BT_DEBUG(("#1 apex_get_list() ========================="));
		memset(debugstr, 0x00, sizeof(char)*(MAX_FILE_PATH_LEN));
		BtconvertFileNameToChar(retVal_readdir->filePathString.name, debugstr);
		BT_DEBUG((" 0. dir name=%s", debugstr));
		BT_DEBUG((" 0. length=%d, nameTruncated=%s", retVal_readdir->filePathString.length, retVal_readdir->nameTruncated?"True":"False"));		
#if 0		
		BT_DEBUG((" 1. st_dev(Logical drive number)=%d  ", retVal_readdir->fsStat.st_dev));
		BT_DEBUG((" 2. st_ino(Unique file number)=%d  ", retVal_readdir->fsStat.st_ino));
		BT_DEBUG((" 3. st_nlink(Number of links to file)=%d  ", retVal_readdir->fsStat.st_nlink));
		BT_DEBUG((" 4. st_mode(File permissions)=%d  ", retVal_readdir->fsStat.st_mode));
		BT_DEBUG((" 5. st_rdev(Device file)=%d  ", retVal_readdir->fsStat.st_rdev));
		BT_DEBUG((" 6. st_size(File size in bytes)=%d  ", retVal_readdir->fsStat.st_size));
		BT_DEBUG((" 7. st_mtime(File modification time)=%d  ", retVal_readdir->fsStat.st_mtime));
		BT_DEBUG((" 8. st_atime(File access time)=%d  ", retVal_readdir->fsStat.st_atime));
		BT_DEBUG((" 9. st_ctime(File create time)=%d  ", retVal_readdir->fsStat.st_ctime));
		BT_DEBUG((" 10. st_uid(File owner)=%d  ", retVal_readdir->fsStat.st_uid));	
		BT_DEBUG((" 11. st_gid(File owner's group)=%d  ", retVal_readdir->fsStat.st_gid));	
#endif
		//BT_DEBUG(("======================================="));

		memset(temp_string, 0x00, sizeof(char)*(MAX_FILE_PATH_LEN));

		strcpy(temp_string, BTFS_ROOT_DIR_TEST_EXTERNAL);
//		strcpy(temp_string, BTFS_DIR_TEST_EXTERNAL);
		//strcat(temp_string, "/");
		strcat(temp_string, debugstr);
		//BT_DEBUG(("temp_string=%s, debugstr=%s", temp_string, debugstr));
		retVal = btfs_apex_stat(temp_string, &statBuf_p);
		BT_DEBUG(("btfs_apex_stat() end retVal = [%d]", retVal));	
		BT_DEBUG(("#2 apex_get_list() ========================="));
		BT_DEBUG((" 1. st_dev(Logical drive number)=%d  ", statBuf_p.st_dev));
		BT_DEBUG((" 2. st_ino(Unique file number)=%d  ", statBuf_p.st_ino));
		BT_DEBUG((" 3. st_nlink(Number of links to file)=%d  ", statBuf_p.st_nlink));
		BT_DEBUG((" 4. st_mode(File permissions)=0x%x  ", statBuf_p.st_mode));
		BT_DEBUG((" 5. st_rdev(Device file)=%d  ", statBuf_p.st_rdev));
		BT_DEBUG((" 6. st_size(File size in bytes)=%d  ", statBuf_p.st_size));
		BT_DEBUG((" 7. st_mtime(File modification time)=%d  ", statBuf_p.st_mtime));
		BT_DEBUG((" 8. st_atime(File access time)=%d  ", statBuf_p.st_atime));
		BT_DEBUG((" 9. st_ctime(File create time)=%d  ", statBuf_p.st_ctime));
		BT_DEBUG((" 10. st_uid(File owner)=%d  ", statBuf_p.st_uid));	
		BT_DEBUG((" 11. st_gid(File owner's group)=%d  ", statBuf_p.st_gid));	
		BT_DEBUG(("======================================="));

	}

	retVal_closedir = btfs_apex_closedir(retVal_opendir);
	BT_DEBUG(("btfs_apex_closedir() = [%d]", retVal_closedir));
}

void apex_open_remove_external(void)
{
  	FileID *file_p=PNULL;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
	SignedInt32 retVal=0;

	file_p = btfs_apex_open("e:/bt/5.txt", "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
	
	retVal = btfs_apex_remove("e:/bt/5.txt");
	BT_DEBUG(("btfs_apex_remove() retVal = [%d] \n", retVal));
	
	BT_DEBUG((" "));
	apex_get_list_external();	
}

void apex_dir_make_external(void)
{
  	FileID *file_p=PNULL;
	static Int32 size_in=0;
	SignedInt32 size_out=0;
	SignedInt32 retVal=0;
	SignedInt32 retVal_mkdir=0;

	retVal_mkdir = btfs_apex_mkdir(BTFS_DIR_TEST_EXTERNAL);
	BT_DEBUG(("btfs_apex_mkdir() = %d \n", retVal_mkdir));

	file_p = btfs_apex_open("e:/bt/Bt_test.txt", "a");
	BT_DEBUG(("btfs_apex_open() file_p = [0x%p] \n", file_p));
	memset(gBuffer,0x00,sizeof(char)*MAX_BUFFER_SIZE);
	size_in = FillBuffer(gBuffer, 10);	
	size_out = btfs_apex_write(file_p, gBuffer, size_in);
	BT_DEBUG(("btfs_apex_write() retVal = [%d] \n", size_out));
	retVal = btfs_apex_close(file_p);
	BT_DEBUG(("btfs_apex_close() retVal = [%d] \n", retVal));
}

void apex_remove_Dirfile_external(void)
{
  	FileID *file_p=PNULL;
	SignedInt32 retVal=0;

	retVal = btfs_apex_remove("e:/bt/Bt_test.txt");
	BT_DEBUG(("btfs_apex_remove() retVal = [%d] \n", retVal));
	
	file_p = btfs_apex_open("e:/bt/Bt_test.txt", "r");
}

void apex_free_space_external(void)
{
	SignedInt32 freeSize=0;		/* bytes */

	freeSize = btfs_apex_diskinfo_free_space('e');
	BT_DEBUG(("btfs_apex_diskinfo_free_space(e:) freeSize = [%d] \n", freeSize));
}

#endif /* Test Utilities(Used for verifying basic functions for File System) */

#endif /* UPGRADE_FSYSTEM */
#endif /* LGE_APEX_FS_BLUETOOTH */

