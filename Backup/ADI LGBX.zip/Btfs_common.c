/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfs_ttp.c

DESCRIPTION:	     Functions of Spansion File Sytem for Bluetooth

History:
2006/08/28  $Revision: 1.0 $  :: Created for Spansion File System Functions
			 			     $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK. YOON JONG WOOK
**************************************************************************/

#define MODULE_NAME "BTFS_COMMON"

#if defined(LGE_COMMON_FS_BLUETOOTH)
/****************************************************************************
* Include Files
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <kernel.h>
#include <system.h>
#include <ki_sig.h>
#include <L1al_sig.h>

#include "afgl_fnc.h"
#include "uDebug.h"
#include "btfsif.h"
#include "btfs_ttp.h"

#if defined (LGE_TFFS) /*noti_011013*/
#include "Tffs_lg_fun.h"
#elif defined(LGE_FDI)
#include "Fim_err.h"
#endif /*LGE_TFFS*/

/* BT_COMMON_KIMSANGJIN_070412 noti_011047*/
#if !defined (AFSH_FNC_H)
#include "afsh_fnc.h"
#endif /*AFSH_FNC_H*/

#if !defined (AFBT_TYP_H)  /*noti_011084*/
#include "afbt_typ.h"
#endif /*AFBT_TYP_H*/

/* BT_COMMON_KIMSANGJIN_070419 */
#if defined(LGE_MMI_EXTERNAL_MEMORY)
#if !defined(BTFS_EXFS_H)
#include "Btfs_exfs.h"
#endif /*BTFS_EXFS_H*/
#endif /*LGE_MMI_EXTERNAL_MEMORY*/

union Signal
{
  L1AlNvramFileOpenReq			l1AlNvramFileOpenReq;
  L1AlNvramFileOpenCnf			l1AlNvramFileOpenCnf;
  L1AlNvramFileReadReq			l1AlNvramFileReadReq;
  L1AlNvramFileReadCnf			l1AlNvramFileReadCnf;
  L1AlNvramFileWriteReq 		l1AlNvramFileWriteReq;
  L1AlNvramFileWriteCnf 		l1AlNvramFileWriteCnf;
  L1AlNvramFileCloseReq 		l1AlNvramFileCloseReq;
  L1AlNvramFileCloseCnf 		l1AlNvramFileCloseCnf;
  L1AlNvramFileSeekReq			l1AlNvramFileSeekReq;
  L1AlNvramFileSeekCnf			l1AlNvramFileSeekCnf;
  L1AlNvramFileTellReq			l1AlNvramFileTellReq;
  L1AlNvramFileTellCnf			l1AlNvramFileTellCnf;
  L1AlNvramFileRemoveReq		l1AlNvramFileRemoveReq;
  L1AlNvramFileRemoveCnf		l1AlNvramFileRemoveCnf;
  L1AlNvramFileStatisticsReq	l1AlNvramFileStatisticsReq;
  L1AlNvramFileStatisticsCnf	l1AlNvramFileStatisticsCnf;
  L1AlNvramFileRenameReq		l1AlNvramFileRenameReq;
  L1AlNvramFileRenameCnf		l1AlNvramFileRenameCnf;
  L1AlNvramFileFindfirstReq 	l1AlNvramFileFindfirstReq;
  L1AlNvramFileFindfirstCnf 	l1AlNvramFileFindfirstCnf;
  L1AlNvramFileFindnextReq		l1AlNvramFileFindnextReq;
  L1AlNvramFileFindnextCnf		l1AlNvramFileFindnextCnf;
  L1AlNvramFileStatReq			l1AlNvramFileStatReq;
  L1AlNvramFileStatCnf			l1AlNvramFileStatCnf;
  L1AlNvramFileFstatReq 		l1AlNvramFileFstatReq;
  L1AlNvramFileFstatCnf 		l1AlNvramFileFstatCnf;
  L1AlNvramFileGetsizeReq		l1AlNvramFileGetsizeReq;
  L1AlNvramFileGetsizeCnf		l1AlNvramFileGetsizeCnf;

  L1AlNvramMakeDirReq			l1AlNvramMakeDirReq;
  L1AlNvramMakeDirCnf			l1AlNvramMakeDirCnf;
  L1AlNvramRemoveDirReq			l1AlNvramRemoveDirReq;
  L1AlNvramRemoveDirCnf			l1AlNvramRemoveDirCnf;
  L1AlNvramOpenDirReq			l1AlNvramOpenDirReq;
  L1AlNvramOpenDirCnf			l1AlNvramOpenDirCnf;
  L1AlNvramReadDirReq			l1AlNvramReadDirReq;
  L1AlNvramReadDirCnf			l1AlNvramReadDirCnf;
  L1AlNvramCloseDirReq			l1AlNvramCloseDirReq;
  L1AlNvramCloseDirCnf			l1AlNvramCloseDirCnf;
  L1AlNvramRewindDirReq			l1AlNvramRewindDirReq;
  L1AlNvramRewindDirCnf			l1AlNvramRewindDirCnf;
  L1AlNvramFileGetListReq		l1AlNvramFileGetListReq;
  L1AlNvramFileGetListCnf		l1AlNvramFileGetListCnf;
  L1AlNvramFileCountReq			l1AlNvramFileCountReq;
  L1AlNvramFileCountCnf     	l1AlNvramFileCountCnf;
  L1AlNvramChangeModeReq		l1AlNvramChangeModeReq;
  L1AlNvramChangeModeCnf		l1AlNvramChangeModeCnf;
 
};


/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/
static Int32 gFileErrCode;
static KiUnitQueue FTPPendingQueue; /* L1al internal ations queue */


/****************************************************************************
* Type Definitions
****************************************************************************/

/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Global Variables
****************************************************************************/
 /*LGE_KP230_LEE HYOUNG WOO_070806  model fixed*/
#if defined(LGE_MMI_EXTERNAL_MEMORY)
/* BT_COMMON_KIMSANGJIN_070419 */
extern Aitfiledepth 	  gdir_path;
#endif
/****************************************************************************
* Local Functions
****************************************************************************/
#if defined (LGE_TFFS) /*noti_011013*/
char *BtGetErrMsg(FLStatus FsErrId);
#elif defined(LGE_FDI)
char *BtGetErrMsg(FIMErrCode FsErrId);
#endif /*LGE_TFFS*/

/* BT_COMMON_KIMSANGJIN_070412 noti_011047*/
Boolean OpenRootDir = FALSE;
Boolean OneCycle = FALSE;

#if 0
/*-----------------27/04/99 12:20-------------------
 * A version of strcpy with a twist
 * The function copies the 8-bit string strSrc_p,
 * including its null terminator, to successive
 * elements of the array of Int16s whose first element
 * has the address strDst_p.
 *
 * (See utCompressStrCpy for the reverse operation.)
 *
 * It returns strDst_p.
 * --------------------------------------------------*/
Int16 *
BtutExpandStrcpy(Int16  *strDst_p, Char *strSrc_p)
{
  Int16 *originalStrDst_p = strDst_p;

  DevAssert(strDst_p != PNULL);
  DevAssert(strSrc_p != PNULL);

  do
  {
	*strDst_p = *strSrc_p++;
  } while(*strDst_p++ != '\0');

  return(originalStrDst_p);
}

/*********************************************************************************
 * Function: convertFileNameToUcs2
 *
 * Parameter:
 *			   fileName   IN	Filename as an ASCII string
 *
 * Return:
 *		   Pointer to a dynamically allocated UCS2 string containing the file name
 *		   This pointer must be freed after use.
 *
 * *********************************************************************************/
Int16 *BtconvertFileNameToUcs2 ( char *fileName )
{
  Int16 *ucs2FileName = PNULL;

  /*Convert file name to UCS2 */
  //KiAllocZeroMemory ( (strlen ( fileName )+1) * sizeof (Int16), (void **) &ucs2FileName );
  //BtutExpandStrcpy( ucs2FileName, (Char *) fileName );
  KiAllocZeroMemory ( AFBT_FILENAME_SIZE * sizeof (Int16), (void **) &ucs2FileName ); /*noti_011084*/
  utUtf8ToUcs2(fileName, strlen( fileName ), ucs2FileName, AFBT_FILENAME_SIZE);
  return ucs2FileName;
}

static void BtconvertFileNameToChar(Int16 *Srcstr,char *Dststr)
{
	Int16 len;
       len=STRLEN(Srcstr);
   	KiAllocZeroMemory( (len+1) * sizeof (char), (void**)&Dststr );				
	do
	{
	  *Dststr = (char)*Srcstr++;
	} while(*Srcstr++ != '\0');
}
#endif

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
* Global Functions
****************************************************************************/
int btfs_common_file_error(void)
{
	return gFileErrCode;
}


/****************************************************************************

				spansion File System Interface for Bluetooth
				
	O_RDONLY 	: open for reading only
	O_WRONLY	: open for writing only
	O_RDWR		: open for reading and writing

	O_CREAT 	: create if nonexistent
	O_TRUNC 	: truncate to zero length
	O_EXCL		: error if already exists
	O_APPEND 	: set append mode

'w' - ���� �������� �����ϴ�; ���� �����͸� ������ �� �տ� �����ϴ� �׸��� ������ ũ�⸦ 0���� ����ϴ�. ������ ������ ����ϴ�. 
'w+' - �б� ���Ⱑ �����մϴ�; ���������͸� ������ �� �տ� �����ϴ�. �׸��� ������ ũ�⸦0���� ����ϴ�. ������ ������ ����ϴ�. 

'a' - ���� �������� �����ϴ�; ���� �����͸� ������ ���� �����ϴ�. ������ ������ ����ϴ�. 
'a+' - �б� ���Ⱑ �����մϴ�; ���� �����͸� ������ ���� �����ϴ�. ������ ������ ����ϴ�. 

'r' - �б��������� �����ϴ�; ���������͸� ������ �� �տ� �����ϴ�. 
'r+' - �б� ���Ⱑ �����մϴ�.; ���� �����͸� ������ �� �տ� �����ϴ�. 

****************************************************************************/
int btfs_common_open(char *fileName, char *mode)
{
	SignalBuffer sendSignal = kiNullBuffer; 
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( fileName );	
	Int16 commandRef= afglGetUniqueId();
	FileId fid;
	Int32 errCode;
	int retVal=0;
	Boolean keepGoing = TRUE;	
	BT_DEBUG(("btfs_common_open:%s [%s]",fileName,mode));
	KiCreateZeroSignal(SIG_L1AL_NVRAM_FILE_OPEN_REQ, sizeof(L1AlNvramFileOpenReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramFileOpenReq));
	sendSignal.sig->l1AlNvramFileOpenReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileOpenReq.commandRef = commandRef;
    sendSignal.sig->l1AlNvramFileOpenReq.filename_ptr = ucs2FileName;
	sendSignal.sig->l1AlNvramFileOpenReq.mode =  mode;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal); /*noti_011013*/

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_OPEN_CNF &&	
			recvSignal.sig->l1AlNvramFileOpenCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}	
	fid = recvSignal.sig->l1AlNvramFileOpenCnf.fileId;
	errCode = recvSignal.sig->l1AlNvramFileOpenCnf.errCode;
	gFileErrCode = errCode;
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName );

	if (errCode != 0)
	{
/* BT_COMMON_KIMSANGJIN_070402 noti_011044 */
		BT_DEBUG(("Open Error code :%s",BtGetErrMsg(errCode)));
	       if(errCode == FIM_EEXIST)
	       {

			   return FILE_ALREADY_EXIST;
	       }
		else
		{
	  retVal = EINVAL;
		return retVal;
	}
/* end of BT_COMMON_KIMSANGJIN_070402 */
	}
	else
	{ 	
		//DEBUG0("******************************");
		 DEBUG1(" %s was opened",(char *)fileName);
	}

	return fid;
	
}


int btfs_common_read(int handle, void *buf, Int32 len)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef =afglGetUniqueId ();
	Int32 status;
	Int32 errCode;	
	int retVal=0;	
	Boolean keepGoing = TRUE;	

	KiCreateZeroSignal(SIG_L1AL_NVRAM_FILE_READ_REQ, sizeof(L1AlNvramFileReadReq), &sendSignal);
	sendSignal.sig->l1AlNvramFileReadReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileReadReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramFileReadReq.stream = handle;
	sendSignal.sig->l1AlNvramFileReadReq.buffer_ptr = buf;
	sendSignal.sig->l1AlNvramFileReadReq.element_size = 1;
	sendSignal.sig->l1AlNvramFileReadReq.count = len;

	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		DEBUG1("Recv commandRef 1: %d ", recvSignal.sig->l1AlNvramFileOpenCnf.commandRef );
	
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_READ_CNF && 
			recvSignal.sig->l1AlNvramFileReadCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}


	retVal = recvSignal.sig->l1AlNvramFileReadCnf.size; 
	errCode = recvSignal.sig->l1AlNvramFileReadCnf.errCode;
	gFileErrCode = errCode;
	

	KiDestroySignal (&recvSignal);

	if (errCode != 0)
	{
		BT_DEBUG(("Read Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}

	DEBUG0("SIG_L1AL_NVRAM_FILE_READ_CNF OK");
	return retVal;


}

int btfs_common_write(int handle, void *buf, Int32 len)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef=afglGetUniqueId();
	Int32 status;
	Int32 errCode;	
	int retVal=0;	
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal(SIG_L1AL_NVRAM_FILE_WRITE_REQ, sizeof(L1AlNvramFileWriteReq), &sendSignal);
	sendSignal.sig->l1AlNvramFileWriteReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileWriteReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramFileWriteReq.stream = handle;
	sendSignal.sig->l1AlNvramFileWriteReq.buffer_ptr = buf;
	sendSignal.sig->l1AlNvramFileWriteReq.element_size = 1;
	sendSignal.sig->l1AlNvramFileWriteReq.count = len;
	
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_WRITE_CNF && 
			recvSignal.sig->l1AlNvramFileWriteCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	printf("SIG_L1AL_NVRAM_FILE_WRITE_CNF : ok...!!");	
	retVal = recvSignal.sig->l1AlNvramFileWriteCnf.size;	
	errCode = recvSignal.sig->l1AlNvramFileWriteCnf.errCode;
	gFileErrCode = errCode;

	DEBUG1("Write Error Code : %d ", errCode);
	BT_DEBUG((">>Write data size :%d",retVal));
	KiDestroySignal (&recvSignal);
	
	if (errCode != 0)
	{
		BT_DEBUG(("Write Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}
	
	return retVal;

}

int btfs_common_close(int handle)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef =afglGetUniqueId ();
	Int32 errCode;
	int status;
	int retVal=0;	
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal(SIG_L1AL_NVRAM_FILE_CLOSE_REQ, sizeof(L1AlNvramFileCloseReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramFileCloseReq));	
	sendSignal.sig->l1AlNvramFileCloseReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileCloseReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramFileCloseReq.stream = handle;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_CLOSE_CNF && 
			recvSignal.sig->l1AlNvramFileCloseCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	
	//printf("SIG_L1AL_NVRAM_FILE_CLOSE_CNF : ok...!!");
	
	status = recvSignal.sig->l1AlNvramFileCloseCnf.status;	
	errCode = recvSignal.sig->l1AlNvramFileCloseCnf.errCode;
	gFileErrCode = errCode;

	BT_DEBUG(("Close Error code :%s",BtGetErrMsg(errCode)));
	
	KiDestroySignal (&recvSignal);
	
	if (errCode != 0)
	{
		retVal = EINVAL;
	}
	
	return retVal;

}

int btfs_common_stat(char *fileName, Stat *statBuf_p)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 commandRef = afglGetUniqueId();
    Int32 free_space, used_space; 	
	Int32 errCode;
	Boolean keepGoing = TRUE;
	Int32 status;
	int retVal=0;	
//	Int32 memtotal=GetBtTotalMemSpace(); 
	
	DEBUG0("btfs_common_stat Start");

	KiCreateZeroSignal(SIG_L1AL_NVRAM_FILE_STATISTICS_REQ, sizeof(L1AlNvramFileStatisticsReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramFileStatisticsReq));
	sendSignal.sig->l1AlNvramFileStatisticsReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileStatisticsReq.commandRef = commandRef;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_STATISTICS_CNF &&	
			recvSignal.sig->l1AlNvramFileStatisticsCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

    used_space = recvSignal.sig->l1AlNvramFileStatisticsCnf.usedSpace;
    free_space = recvSignal.sig->l1AlNvramFileStatisticsCnf.freeSpace;
    status = recvSignal.sig->l1AlNvramFileStatisticsCnf.status;
    errCode= recvSignal.sig->l1AlNvramFileStatisticsCnf.errCode;	
	gFileErrCode = errCode;

    DEBUG1("Used Space = %4d", used_space);
    DEBUG1("Free Space = %4d", free_space);
	
	KiDestroySignal (&recvSignal);
	
	if (errCode == 0)
	{
		DEBUG0("LGE_BT_FTP_FileStatistics end SUCCESS");
	}
	else
	{
		BT_DEBUG(("Stat Error code :%s",BtGetErrMsg(errCode)));
		DEBUG1("LGE_BT_FTP_FileStatistics Error>errCode:%d", errCode);	  
		retVal = EINVAL;		
	}
	
	return free_space;

}

/* BT_COMMON_KIMSANGJIN_070226 noti_011019 */
static void btfsGetInformation( FileInform *context_p )
{
	Int8	attribute;
	int time;

	Int16	year;			
	int		month;
	int		day;
	int		hours;
	int		minutes;
	int		seconds;



	year = ((context_p->date & 0xFE00) >> 9) + 1980;	/* bits 9 ~ 15 (from 1980) */
	month = (context_p->date & 0x01E0) >> 5;			/* bits 5 ~ 8 (1~12)*/
	day = context_p->date & 0x001F;					/* bits 0 ~ 4 (1~31)*/
	time = context_p->time ;					/* bits 0 ~ 4 (1~31)*/
	attribute = context_p->attribute;
	hours = (context_p->time & 0xF800) >> 11;		/* bits 11 ~ 15 (0~23) */
	minutes = (context_p->time & 0x07E0) >> 5;		/* bits 5 ~ 10 (0-59) */
	seconds = (context_p->time & 0x001F) * 2;		/* bits 0 ~ 4 (0~29 divide by 2) */

}

int btfs_common_info( char *fileName, FileInform *fileInform)
{

       SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;

	Int16 commandRef = afglGetUniqueId();
	Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( fileName ); 
	Int32 errCode;
	Boolean keepGoing = TRUE;
	Int32 status;
	int retVal=0;	
	char *debugstr = PNULL; /*noti_011021*/
	
	DEBUG0("btfs_common_info Start");
        /*noti_011021*/
        KiCreateZeroSignal(SIG_L1AL_NVRAM_FILE_STAT_REQ, sizeof(L1AlNvramFileStatReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramFileStatReq));
	sendSignal.sig->l1AlNvramFileStatReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileStatReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramFileStatReq.filenamePtr=ucs2FileName;	
	sendSignal.sig->l1AlNvramFileStatReq.fileInformPtr=fileInform;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
             	KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_STAT_CNF &&	
			recvSignal.sig->l1AlNvramFileStatCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
		KiEnqueue(&FTPPendingQueue, &recvSignal);	
	}
        errCode = recvSignal.sig->l1AlNvramFileStatCnf.errCode;
	//////////////////////////////////////////////////////////////////////////////////////////	
	BtconvertFileNameToChar(fileInform->file_name, debugstr);
	fileInform->attribute=fileInform->permissions;

	BT_DEBUG(("************ btfs_common_information **************** "));
	BT_DEBUG((" btfs_common_info() size = %d",fileInform->size));
	BT_DEBUG((" btfs_common_info() time = %d",fileInform->time));
	BT_DEBUG((" btfs_common_info() ownerId = %x",fileInform->ownerId));
	BT_DEBUG((" btfs_common_info() permissions = %x",fileInform->permissions));
	BT_DEBUG((" btfs_common_info() attribute = %x",fileInform->attribute));
	//BT_DEBUG((" btfs_common_info() file_name %s",debugstr));
	if(debugstr != PNULL) KiFreeMemory ((void**)&debugstr ); /*noti_011021*/
	//////////////////////////////////////////////////////////////////////////////////////////

	KiDestroySignal (&recvSignal);   
	KiFreeMemory ((void**)&ucs2FileName );

       // btfsGetInformation(fileInform);

	if(errCode == 0)
	{
		DEBUG0("SIG_L1AL_NVRAM_FILE_STAT_CNF ::: SUCCESS");
	}
	else
	{
		BT_DEBUG(("Inform Error code :%s",BtGetErrMsg(errCode)));
		DEBUG1("SIG_L1AL_NVRAM_FILE_STAT_CNF::: Error>errCode:%d", errCode);	  
		retVal = EINVAL;		
	}

	
 return retVal;	        
}
/* end of BT_COMMON_KIMSANGJIN_070226 */
int btfs_common_chmod( char *fileName, char *mode)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 
	Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( fileName ); 
	Int16 *ucs2mode = BtconvertFileNameToUcs2 ( mode ); 
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	int retVal=0;
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal (SIG_L1AL_NVRAM_CHANGE_MODE_REQ, sizeof(L1AlNvramChangeModeReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramChangeModeReq)); 
	sendSignal.sig->l1AlNvramChangeModeReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramChangeModeReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramChangeModeReq.filenamePtr = ucs2FileName;
	sendSignal.sig->l1AlNvramChangeModeReq.attribute = (Int8)ucs2mode;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_CHANGE_MODE_CNF && 
			recvSignal.sig->l1AlNvramChangeModeCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	
	errCode = recvSignal.sig->l1AlNvramChangeModeCnf.errCode;
		
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName );
	KiFreeMemory ((void**)&ucs2mode );
	
	if (errCode != 0)
	{
		retVal = EINVAL;
	}
	
	return retVal;

}

int btfs_common_remove(char *fileName)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
	Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( fileName );		
	Int16 commandRef = afglGetUniqueId ();
	Int32 status;
	Int32 errCode;
	int retVal=0;	
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal(SIG_L1AL_NVRAM_FILE_REMOVE_REQ, sizeof(L1AlNvramFileRemoveReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramFileRemoveReq));	
	sendSignal.sig->l1AlNvramFileRemoveReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileRemoveReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramFileRemoveReq.filename_ptr = ucs2FileName;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_REMOVE_CNF && 
			recvSignal.sig->l1AlNvramFileRemoveCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	status = recvSignal.sig->l1AlNvramFileRemoveCnf.status; 
	errCode = recvSignal.sig->l1AlNvramFileRemoveCnf.errCode;
	gFileErrCode = errCode;
	
	DEBUG1("Remove Error Code : %d ", errCode);	
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName );
	
	if (errCode != 0)
	{
		BT_DEBUG(("Remove Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}
	else
	{	
		DEBUG0("******************************* ");
		DEBUG1(" %s was Removed",(char *)fileName);
	}
	
	return retVal;

}

int btfs_common_rename(char *oldName, char *newName)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer 			 recvSignal = kiNullBuffer;
	Int16 *ucs2FileNameOld = BtconvertFileNameToUcs2 ( oldName );
	Int16 *ucs2FileNameNew = BtconvertFileNameToUcs2 ( newName );	
	Int16 commandRef = afglGetUniqueId();
	int status;
	Int32 errCode;
	int retVal=0;	
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal(SIG_L1AL_NVRAM_FILE_RENAME_REQ, sizeof(L1AlNvramFileRenameReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramFileRenameReq));
	sendSignal.sig->l1AlNvramFileRenameReq.taskId= BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileRenameReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramFileRenameReq.oldname_ptr=  ucs2FileNameOld;
	sendSignal.sig->l1AlNvramFileRenameReq.newname_ptr=  ucs2FileNameNew;
	KiSendSignal(LGE_FILESYS_TASK_ID, &sendSignal);

	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_RENAME_CNF && 
			recvSignal.sig->l1AlNvramFileRenameCnf.commandRef == commandRef ) 
			{
				keepGoing = FALSE;
				DEBUG2(" %s name was changed to %s ",(char *)oldName, (char *)newName);
			}
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileNameOld );
	KiFreeMemory ((void**)&ucs2FileNameNew );

	if (errCode != 0)
	{
		BT_DEBUG(("Rename Error code :%s [%d]",BtGetErrMsg(errCode),errCode));
		retVal = EINVAL;
	}
	else
	{ 	
	}
	return retVal;

}

int btfs_common_seek(int handle, int offset, Int32 fromwhere)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 	
	Int16 commandRef = afglGetUniqueId();
	int status;
	Int32 errCode;
	int retVal=0;	
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal (SIG_L1AL_NVRAM_FILE_SEEK_REQ, sizeof(L1AlNvramFileSeekReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramFileSeekReq));	
	sendSignal.sig->l1AlNvramFileSeekReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileSeekReq.commandRef = commandRef;	
	sendSignal.sig->l1AlNvramFileSeekReq.stream = handle;
	sendSignal.sig->l1AlNvramFileSeekReq.offset= offset;
	sendSignal.sig->l1AlNvramFileSeekReq.wherefrom = fromwhere;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_SEEK_CNF && 
			recvSignal.sig->l1AlNvramFileSeekCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	
	KiDestroySignal (&recvSignal);
	
	if (errCode != 0)
	{
		BT_DEBUG(("Seek Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}
	
	return retVal;

}

Boolean btfs_common_exists(char *fileName)
{
    int handle; /* BT_COMMON_KIMSANGJIN_070403 noti_011044 */ 

    BT_DEBUG((" btfs_common_exists:%s ",fileName));
    handle= btfs_common_open(fileName,"r");

    if(handle < 0)
    {
		BT_DEBUG(("btfs_common_exists Not exist"));
		return FALSE;
    }
    else 
    {
		handle=btfs_common_close(handle);
		if(handle != 0)
		{
		       BT_DEBUG(("btfs_common_exists fail case===>"));
			return FALSE;
		}
		else
		{
		       BT_DEBUG(("btfs_common_exists OK"));
			return TRUE;
		}
    }
/* end of BT_COMMON_KIMSANGJIN_070403 */

}

	
DirId btfs_common_opendir(char *dirname_p)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 
	Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( dirname_p );	
	Int16 commandRef = afglGetUniqueId();
	int status;
	Int32 errCode;
	int retVal=0;
	DirId dir_handler;
	Boolean keepGoing = TRUE;
	
/* BT_COMMON_KIMSANGJIN_070419 */
#if defined(LGE_MMI_EXTERNAL_MEMORY)
	if( strcmp(dirname_p,"A:/") == 0)
	{
	       BT_DEBUG(("btfs_common_opendir() Read Root dir>>>"));
	       memset(gdir_path.long_dir_path,0x00,sizeof(Int16)*(BT_AIT_FILE_NAME_LENGTH+1));
	       memset(gdir_path.short_dir_path,0x00,sizeof(char)*(BT_AIT_FILE_NAME_LENGTH+1));
		OpenRootDir = TRUE;
		OneCycle = FALSE;
	}
#endif  /*LGE_MMI_EXTERNAL_MEMORY*/

	KiCreateZeroSignal (SIG_L1AL_NVRAM_OPEN_DIR_REQ, sizeof(L1AlNvramOpenDirReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramOpenDirReq));	
	sendSignal.sig->l1AlNvramOpenDirReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramOpenDirReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramOpenDirReq.DirectoryName = ucs2FileName;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_OPEN_DIR_CNF && 
			recvSignal.sig->l1AlNvramOpenDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	errCode = recvSignal.sig->l1AlNvramOpenDirCnf.errCode;
	dir_handler = recvSignal.sig->l1AlNvramOpenDirCnf.dirhandler;
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName );
	
	if (errCode != FIM_OK)
	{
		BT_DEBUG(("OpenDir Error code :%s[%d]",BtGetErrMsg(errCode),errCode));
		retVal =EINVAL;
		return retVal;
	}
	
	return dir_handler;
	
}

FileInform *btfs_common_readdir(DirId dir_p)
{
    SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 	
	Int16 commandRef = afglGetUniqueId();
	int status;
	Int32 errCode;
	static FileInform Finfo;
	DirId dir_handler;
	Boolean keepGoing = TRUE;
	char *debugstr = PNULL; /*noti_011021*/
	
	memset(&Finfo,0x00,sizeof(FileInform));
	KiCreateZeroSignal (SIG_L1AL_NVRAM_READ_DIR_REQ, sizeof(L1AlNvramReadDirReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramReadDirReq));	
	sendSignal.sig->l1AlNvramReadDirReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramReadDirReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramReadDirReq.dirhandler= dir_p;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_READ_DIR_CNF && 
			recvSignal.sig->l1AlNvramReadDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	errCode = recvSignal.sig->l1AlNvramReadDirCnf.errCode;
	dir_handler = recvSignal.sig->l1AlNvramReadDirCnf.dirhandler;
/* BT_COMMON_KIMSANGJIN_070425 */
#if 0	
	//////////////////////////////////FOR DEBUG/////////////////////////////////////////////////
	BtconvertFileNameToChar(recvSignal.sig->l1AlNvramReadDirCnf.dirEntry->file_name, debugstr);
	BT_DEBUG(("************ DIR Entry Information **************** "));
	BT_DEBUG((" DIR Entry attribute = 0X%x",recvSignal.sig->l1AlNvramReadDirCnf.dirEntry->attribute));
	BT_DEBUG((" DIR Entry file_name = [%s]",&debugstr[0]));
	BT_DEBUG((" DIR Entry size = %d",recvSignal.sig->l1AlNvramReadDirCnf.dirEntry->size));
	BT_DEBUG((" DIR Entry permissions = %x",recvSignal.sig->l1AlNvramReadDirCnf.dirEntry->permissions));
	if(debugstr != PNULL) KiFreeMemory ((void**)&debugstr ); /*noti_011021*/
	///////////////////////////////////FOR DEBUG/////////////////////////////////////////////////	
#endif	
	//Finfo=recvSignal.sig->l1AlNvramReadDirCnf.dirEntry;
	memcpy(&Finfo,recvSignal.sig->l1AlNvramReadDirCnf.dirEntry,sizeof(FileInform));
	KiDestroySignal (&recvSignal);
	/*LGE_KP230_LEE HYOUNG WOO_070806  model fixed*/
#if defined(LGE_MMI_EXTERNAL_MEMORY)
	if (errCode != 0 ||((OneCycle == TRUE) &&(SDCardIsPresent() == SDCARD_IN)))
	{
/* BT_COMMON_KIMSANGJIN_070412 noti_011047 */
	      if((OpenRootDir == TRUE) && (SDCardIsPresent() == SDCARD_IN))
	      	{
			//Int16 *tempstr=PNULL;
			OneCycle =TRUE;
			OpenRootDir =FALSE;
			memset(&Finfo,0x00,sizeof(FileInform));
			Finfo.attribute=0x207; /*Directory*/
			Finfo.size=0;
			BtutExpandStrcpy(Finfo.file_name, "External memory");
                     BT_DEBUG(("End of btfs_common_readdir() external was exist !!! "));

			return &Finfo;
	      	}
		else
	{
		       OneCycle =FALSE;
		BT_DEBUG(("ReadDir Error code :%s",BtGetErrMsg(errCode)));
              return PNULL;
	}
/* end of BT_COMMON_KIMSANGJIN_070412 */
	}
#endif
	return &Finfo;

}

int btfs_common_closedir(DirId dir_p)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 	
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	int retVal=0;
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal (SIG_L1AL_NVRAM_CLOSE_DIR_REQ, sizeof(L1AlNvramCloseDirReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramCloseDirReq)); 
	sendSignal.sig->l1AlNvramCloseDirReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramCloseDirReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramCloseDirReq.dirhandler = dir_p;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_CLOSE_DIR_CNF && 
			recvSignal.sig->l1AlNvramCloseDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	
	errCode = recvSignal.sig->l1AlNvramCloseDirCnf.errCode;
	
	KiDestroySignal (&recvSignal);
	
	if (errCode != 0)
	{
		BT_DEBUG(("CloseDir Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}
	
	return retVal;

}

void btfs_common_rewinddir(DirId   dir_p)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	DirId *dir_handler;	
	int retVal=0;
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal (SIG_L1AL_NVRAM_REWIND_DIR_REQ, sizeof(L1AlNvramRewindDirReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramRewindDirReq)); 
	sendSignal.sig->l1AlNvramRewindDirReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramRewindDirReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramRewindDirReq.dirhandler= dir_p;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_REWIND_DIR_CNF && 
			recvSignal.sig->l1AlNvramRewindDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	
	errCode = recvSignal.sig->l1AlNvramRewindDirCnf.errCode;
	
	KiDestroySignal (&recvSignal);
	
	if (errCode != 0)
	{
		BT_DEBUG(("RewindDir Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}	
	
}

int btfs_common_rmdir(char *path)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 
       Int16 *ucs2FileName = BtconvertFileNameToUcs2 ( path );	
	Int16 commandRef = afglGetUniqueId();
	Int32 errCode;
	int retVal=0;
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal (SIG_L1AL_NVRAM_REMOVE_DIR_REQ, sizeof(L1AlNvramRemoveDirReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramRemoveDirReq)); 
	sendSignal.sig->l1AlNvramRemoveDirReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramRemoveDirReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramRemoveDirReq.DirectoryName= ucs2FileName;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_REMOVE_DIR_CNF && 
			recvSignal.sig->l1AlNvramRemoveDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	
	errCode = recvSignal.sig->l1AlNvramRemoveDirCnf.errCode;
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName );
	
	if (errCode != 0)
	{
		BT_DEBUG(("RmDir Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}
	
	return retVal;

}

int btfs_common_mkdir(char *path)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 
    Int16 *ucs2FileName = BtconvertFileNameToUcs2 (path);	
	Int16 commandRef = afglGetUniqueId();
	int status;
	Int32 errCode;
	int retVal=0;
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal (SIG_L1AL_NVRAM_MAKE_DIR_REQ, sizeof(L1AlNvramMakeDirReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramMakeDirReq)); 
	sendSignal.sig->l1AlNvramMakeDirReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramMakeDirReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramMakeDirReq.DirectoryName = ucs2FileName;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_MAKE_DIR_CNF && 
			recvSignal.sig->l1AlNvramMakeDirCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	
	errCode = recvSignal.sig->l1AlNvramMakeDirCnf.errCode;
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName );
	
	if (errCode != 0)
	{
	       BT_DEBUG(("MK DIR Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}
	
	return retVal;

}

Boolean btfs_common_isdir(char *path)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 
	Boolean                       isDir = FALSE;
	DirId                            retDirId;
	int                                retVal=0;
	
	retDirId=btfs_common_opendir(path);
	
	if(retDirId != EINVAL)
	{
	        //BT_DEBUG(("btfs_common_closedir(%d)",retDirId));
		retVal= btfs_common_closedir(retDirId);
		if(retVal !=EINVAL)
	{
			isDir= TRUE;
	}
	}
	BT_DEBUG(("End of btfs_common_isdir :%s",isDir?"TRUE":"FALSE"));
	return isDir;
}	   

/* BT_L1_KIMSANGJIN_061001 */
DirId btfs_common_DirGetfileList(char *Dirname,Int32 file_num,DirId Id,FileInform *dirEntry)
{
	SignalBuffer			 sendSignal = kiNullBuffer;
	SignalBuffer			 recvSignal = kiNullBuffer; 
	Int16 *Dir_name = BtconvertFileNameToUcs2 ( Dirname );	
	Int16 commandRef = afglGetUniqueId();
	int status;
	Int32 errCode;
	Int32      Rcvfilenum;
	int retVal=0;
	DirId dir_handler;
	Boolean keepGoing = TRUE;
	
	KiCreateZeroSignal (SIG_L1AL_NVRAM_FILE_GETLIST_REQ, sizeof(L1AlNvramFileGetListReq), &sendSignal);
	memset(sendSignal.sig, 0, sizeof(L1AlNvramFileCountReq));	
	sendSignal.sig->l1AlNvramFileGetListReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileGetListReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramFileGetListReq.DirectoryName = Dir_name;
	sendSignal.sig->l1AlNvramFileGetListReq.file_num =file_num;
	sendSignal.sig->l1AlNvramFileGetListReq.dirhandler=Id;
	sendSignal.sig->l1AlNvramFileGetListReq.dirEntry=dirEntry;
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_GETLIST_CNF && 
			recvSignal.sig->l1AlNvramFileGetListCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}

	errCode = recvSignal.sig->l1AlNvramFileGetListCnf.errCode;
	dir_handler = recvSignal.sig->l1AlNvramFileGetListCnf.dirhandler;
	Rcvfilenum=recvSignal.sig->l1AlNvramFileGetListCnf.file_num;
	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&Dir_name );
	
	if (errCode != FIM_OK)
	{
		BT_DEBUG(("DirGetfileList Error code :%s[%d]",BtGetErrMsg(errCode),errCode));
		retVal =EINVAL;
		return retVal;
	}
	
	return dir_handler;
	
}
/* end of BT_L1_KIMSANGJIN_061001 */

Int32 btfs_common_filegetsize(FileId fid, char *filename)
{
	SignalBuffer sendSignal = kiNullBuffer;
	SignalBuffer recvSignal = kiNullBuffer;
    Int16 *ucs2FileName = BtconvertFileNameToUcs2 (filename);	
	Int16 commandRef = afglGetUniqueId();
	Int32 filenum;
	Int32 errCode;
	Int32 file_size;
	int retVal=0;	
	Boolean keepGoing = TRUE;	
	
	KiCreateZeroSignal (SIG_L1AL_NVRAM_FILE_GETSIZE_REQ, sizeof(L1AlNvramFileGetsizeReq), &sendSignal);
	sendSignal.sig->l1AlNvramFileGetsizeReq.taskId = BTFTP_TASK_ID;
	sendSignal.sig->l1AlNvramFileGetsizeReq.commandRef = commandRef;
	sendSignal.sig->l1AlNvramFileGetsizeReq.stream=fid;
	sendSignal.sig->l1AlNvramFileGetsizeReq.filenamePtr=ucs2FileName;	
	KiSendSignal (LGE_FILESYS_TASK_ID, &sendSignal);
	
	while(keepGoing) 
	{
		KiReceiveSignal (BTFTP_TASK_QUEUE_ID, &recvSignal);
		if (  *(recvSignal.type) == SIG_L1AL_NVRAM_FILE_GETSIZE_CNF && 
			recvSignal.sig->l1AlNvramFileRenameCnf.commandRef == commandRef ) 
			keepGoing = FALSE;
		else									
			KiEnqueue(&FTPPendingQueue, &recvSignal);		
	}
	file_size = recvSignal.sig->l1AlNvramFileGetsizeCnf.size; 
	errCode = recvSignal.sig->l1AlNvramFileGetsizeCnf.errCode;
	gFileErrCode = errCode;
	filenum=recvSignal.sig->l1AlNvramFileGetsizeCnf.filenum;

	
	KiDestroySignal (&recvSignal);
	KiFreeMemory ((void**)&ucs2FileName );
	
	if (errCode != 0)
	{
		BT_DEBUG(("FileGetSize Error code :%s",BtGetErrMsg(errCode)));
		retVal = EINVAL;
	}
	
	return file_size;

}

/* BT_L1_KIMSANGJIN_061001 */
#if defined (LGE_TFFS)
typedef struct SpansionErrTableTag
{
	FLStatus errid;
	char *    errname;
} 
SpansionErr;

const  SpansionErr gErrMsgTable[] =
{
	{FIM_OK,              "FIM_OK"},             
	{flBadFunction,            "flBadFunction"},    
		
	{NVRAM_REC_NOT_FOUND,           "NVRAM_REC_NOT_FOUND"},          
	{flPathNotFound,        "flPathNotFound"},       
	{flTooManyOpenFiles,       "flTooManyOpenFiles"},      
	{flNoWriteAccess,      "flNoWriteAccess"},     
	{flBadFileHandle,    "flBadFileHandle"},   
	{flDriveNotAvailable,            "flDriveNotAvailable"},        

	{flNonFATformat,        "flNonFATformat"},       
	{flFormatNotSupported,         "flFormatNotSupported"},        
	{flNoMoreFiles,          "flNoMoreFiles"},       
	{flWriteProtect,        "flWriteProtect"},        
	{flBadDriveHandle,         "flBadDriveHandle"},        
	{flDriveNotReady,            "flDriveNotReady"},  
	{flUnknownCmd,     "flUnknownCmd"},    
	{flBadFormat,    "flBadFormat"},
	{flBadLength,    "flBadLength"}, 
	{flDataError,    "flDataError"},

	{flUnknownMedia,             "flUnknownMedia"},            
	{flSectorNotFound,           "flSectorNotFound"},          
	{flOutOfPaper,      "flOutOfPaper"},     
	{flWriteFault,      "flWriteFault"},     
	{flReadFault,            "flReadFault"},           
	{flGeneralFailure,           "flGeneralFailure"},          
	{flDiskChange,          "flDiskChange"},         
	{flVppFailure,            "flVppFailure"},           
	{flBadParameter,              "flBadParameter"},              
	{flNoSpaceInVolume,      "flNoSpaceInVolume"},     
	{flInvalidFATchain,       "flInvalidFATchain"},      
	{flRootDirectoryFull,       "flRootDirectoryFull"},      
	{flNotMounted,       "flNotMounted"},   

	{flPathIsRootDirectory,             "flPathIsRootDirectory"},
	{flNotADirectory,           "flNotADirectory"},
	{flDirectoryNotEmpty,              "flDirectoryNotEmpty"},
	{flFileIsADirectory,           "flFileIsADirectory"},
		
	{flAdapterNotFound,       "flAdapterNotFound"},
	{flFormattingError,    "flFormattingError"},
	{flNotEnoughMemory,          "flNotEnoughMemory"},
	{flVolumeTooSmall,  "flVolumeTooSmall"},
		

       {flBufferingError,      "flBufferingError"},
       {flFileAlreadyExists, 	  "flFileAlreadyExists"},
	{flIncomplete,             "flIncomplete"},
       {flTimedOut,    " flTimedOut"},    
	{flTooManyComponents,       "flTooManyComponents"},
	{flTooManyDrives,       "flTooManyDrives"},
	{flTooManyBinaryPartitions,       "flTooManyBinaryPartitions"},
	{flPartitionNotFound,      "flPartitionNotFound"},
		
	{flFeatureNotSupported,             "flFeatureNotSupported"},            
	{flWrongVersion,           "flWrongVersion"},          
	{flTooManyBadBlocks,              "flTooManyBadBlocks"},             
	{flNotProtected,           "flNotProtected"},          
	{flUnchangeableProtection,          "flUnchangeableProtection"},         
	{flBadDownload,          "flBadDownload"},    

	{flBadBBT,             "flBadBBT"},            
	{flInterleaveError,           "flInterleaveError"},          
	{flWrongKey,           "flWrongKey"},          
	{flHWProtection,          "flHWProtection"},         
	{flLeftForCompetability,          "flLeftForCompetability"},  

	{flMultiDocContradiction,             "flMultiDocContradiction"},		
	{flCanNotFold,           "flCanNotFold"}, 
	{flBadIPLBlock,           "flBadIPLBlock"},
	{flIOCommandBlocked,              "flIOCommandBlocked"},
	{flCannotCreateShortName,              "flCannotCreateShortName"},

	{flInvalidCharSet,         "flInvalidCharSet"},
	{flOverwriteExistingEntry,          "flOverwriteExistingEntry"},
	{flBufferTooShort,              "flBufferTooShort"},
	{flPathTooLong,              "flPathTooLong"}
};

char *BtGetErrMsg(FLStatus FsErrId)
{
	Int16 i;
	i = 0;
	
	while (1)
	{
	       if(i>flPathTooLong) /*Lase error message*/
	       {
                   return "unknown Error message";
	       }
		   
		if (gErrMsgTable[i].errid == FsErrId )
			return gErrMsgTable[i].errname;
		
		i++;
	}
}
#elif defined(LGE_FDI)
typedef struct FileSystemErrTableTag
{
	FIMErrCode errid;
	char *    errname;
} 
FileSystemErr;

const  FileSystemErr gErrMsgTable[] =
{
	{FIM_OK,              "FIM_OK"},             
	{FIM_EINVDRV,            "FIM_EINVDRV"},    
		
	{NVRAM_REC_NOT_FOUND,           "NVRAM_REC_NOT_FOUND"},          
	{FIM_ENOPATH,        "FIM_ENOPATH"},       
	{FIM_EEXCLOPEN,       "FIM_EEXCLOPEN"},      
	{FIM_EEXIST,      "FIM_EEXIST"},     
	{FIM_EMFILE,    "FIM_EMFILE"},   
	{FIM_EACCES,            "FIM_EACCES"},        

	{FIM_EBADF,        "FIM_EBADF"},       
	{FIM_EINVALPARAM,         "FIM_EINVALPARAM"},        
	{FIM_ENOFILE,          "FIM_ENOFILE"},       
	{FIM_ECREATE,        "FIM_ECREATE"},        
	{FIM_EDEVREAD,         "FIM_EDEVREAD"},        
	{FIM_EFULL,            "FIM_EFULL"},  
	{FIM_ENOMEM,     "FIM_ENOMEM"},    
	{FIM_EDEVWRITE,    "FIM_EDEVWRITE"},
	{FIM_ENOENT,    "FIM_ENOENT"}, 
	{FIM_ENOTEMPTY,    "FIM_ENOTEMPTY"},

	{FIM_EBUSY,             "FIM_EBUSY"},            
	{FIM_EISDIR,           "FIM_EISDIR"},          
	{FIM_EFORMAT,      "FIM_EFORMAT"},     
	{FIM_EINIT,      "FIM_EINIT"}
};

char *BtGetErrMsg(FIMErrCode FsErrId)
{
	Int16 i;
	i = 0;
	
	while (1)
	{
	       if(i>FIM_EINIT) /*Lase error message*/
	       {
                   return "unknown Error message";
	       }
		   
		if (gErrMsgTable[i].errid == FsErrId )
			return gErrMsgTable[i].errname;
		
		i++;
	}
}
#endif /*LGE_TFFS*/
/* end of BT_L1_KIMSANGJIN_061001 */


#endif /* LGE_COMMON_FS_BLUETOOTH */

