/***************************************************************************
* FILE: Mmi_stackif.h
* AUTH: KIM SANGJIN,LEE JINBACK
* DATE: 2006/10/14 ~ 
* DESC: This file only use in converting stack function call, from MMI to BT stack
             we should independent from stack sw
****************************************************************************/


#if !defined(MMI_STACKIF)
#define MMI_STACKIF

#if defined(LGE_MMI_BLUETOOTH)

#if defined (LGBX_INCLUDE)

/***************************************************************************
* Include Files
***************************************************************************/
#if !defined (APPLAYER_H)
#include "applayer.h"
#endif

#if !defined ( LGEBTTYPE_H )
#include "lgebttype.h"
#endif

#if !defined ( UDEBUG_H )
#include "uDebug.h"
#endif

#if !defined(MMIBXIF_H)
#include "Mmibxif.h"
#endif

#if !defined ( AFBT_TYP_H )
#include "afbt_typ.h"
#endif

/* BT_COMMON_TIBURONA_090117 */
#define AG_UISPK_MAXLVL			5	// For AG via SCO
#define FM_UISPK_MAXLVL			20	// For FM Radio via SCO

/****************************************************************************
** BT Stack Control
****************************************************************************/

void BtSetLocalName(AgCharCode *name);
void BtSetRemoteNickName(LGBX_BD_ADDR_TYPE bdAddr, Int8 * name);
void BtSetVisibility(Boolean visibility);
Boolean IsBtSetVisibility(void);
void BtLaunchTask(void);
void BtShutdownTask(void);

Boolean BtIsEnabled(void);
void BtEnterTestMode(void);

void BtBxSendPasskey(LGBX_BD_ADDR_TYPE bd_addr, Int8 len, Int8* number);
void BtGetServiceList(LGBX_BD_ADDR_TYPE bd_addr);
void BtSDPQuerySomeSvc(LGBX_BD_ADDR_TYPE *bd_addr);

void BtSDPQueryStopReq(void);

/****************************************************************************
** Service Activation/Deactivation
****************************************************************************/

void	BtAgwActivate(void);
void BtAgwDeactivate(void);
void	BtHfgActivate(void);
void BtHfgDeactivate(void);
void	BtSppActivate(Int16 instId);
void BtSppDeactivate(Int16 instId);
void	BtDunActivate(void);
void BtDunDeactivate(void);
void	BtOpsActivate(void);
void BtOpsDeactivate(void);


/****************************************************************************
** Security DB
****************************************************************************/
void BtOpenSecurityDB(void);
void BtCloseSecurityDB(void);

/****************************************************************************
** Inquiry & Pairing
****************************************************************************/

void BtStartInquiry(AfbtProfile profile);
void BtStopInquiry(void);
LGBX_DEVICEINFO_LIST_TYPE BtRetrieveSearchList(void);
void BtSendPasskey(Int8 passkey[], Boolean flag, LGBX_BD_ADDR_TYPE bd_addr);
void BtBondDevice(LGBX_BD_ADDR_TYPE *bd_addr);
LGBX_RESULT_TYPE BtDebondDevice(LGBX_BD_ADDR_TYPE *bd_addr);
LGBX_RESULT_TYPE BtDebondAllDevice(LGBX_SERVICE_TYPE *service);

LGBX_RESULT_TYPE BtSetAuthorize(LGBX_BD_ADDR_TYPE BdAddr, Boolean bAuthorize);
LGBX_RESULT_TYPE BtIsAuthorized(LGBX_BD_ADDR_TYPE BdAddr);

void BtGetSVCdiscover(LGBX_BD_ADDR_TYPE bd_addr);
void BtSendConnect(LGBX_DEVICEINFO_TYPE *dev, LGBX_SERVICE_TYPE reqSvcType); /* BT_LEEJINBAEK 20071019 : AV connect */
void BtSvcSendConnect(LGBX_DEVICEINFO_TYPE *dev, UINT8_T devClass, LGBX_SERVICE_TYPE reqSvcType); //BT_KIMJAEHUN_20080318 discovery service everytime before connect device	

void BtConnectCancel(LGBX_DEVICEINFO_TYPE *dev);
void BtSendDisconnect(LGBX_DEVICEINFO_TYPE *dev);
void  BtSendAGDisConnect(void); /*noti_011183*/

void BtDisableServer(LGBX_SERVICE_TYPE Service); /*noti_011056: merge from MG280*/
void BtEnableServer(LGBX_SERVICE_TYPE Service); /*noti_011066*/

void BtSetVisibleConnectableState (Boolean flag); /*BT_COMMON 20071126 baeheejung*/
void BtSetConnectableState (Boolean flag); /*BT_COMMON 20071127 baeheejung*/

LGBX_SERVICE_TYPE BtIsConnected(LGBX_BD_ADDR_TYPE addr);
LGBX_SERVICE_TYPE BtIsPaired(LGBX_BD_ADDR_TYPE addr);
Boolean BtIsAnyDevConnected(void);

/*KF300_KIMJAEHUN_071030 BT COMMON UI*/ 
UINT8_T BtConnectedDevClass(void);

/****************************************************************************
** Audio Gateway
****************************************************************************/
/* BT_L1_KIMSANGJIN_061116 */
void BtSetCallState(LGBX_AG_CALLSTATE_TYPE state);
/* BT_COMMON_KIMSANGJIN_070528 noti_011118*/
LGBX_AG_CALLSTATE_TYPE BtGetCallState(void);


void BtSetAudioSpeakerPerVolume(Int8 perVol);
void BtRecordHfgSpeakerVol(Int16 volume);
void BtSetSpkGain(Int8 level);
void BtSetPcmMute(Boolean Spk, Boolean Mic);
void afbtCheckVolumeLevelChange(Int16 volume);
/* end of BT_L1_KIMSANGJIN_061226 */
/* BT_COMMON_KIMSANGJIN_070308 noti_011029*/
void BtSetCID(char* num, Int8 len);
/* end of BT_COMMON_KIMSANGJIN_070308 */
void BtAgwOpenPcmAudio(void);
void BtAgwClosePcmAudio(void);
void BtAgwStartRing(void);
void BtAgwStopRing(void);
void BtEnableAudio(void);
void BtDisableAudio(void);

/****************************************************************************
** Hands-Free
****************************************************************************/
void BtHfgOpenPcmAudio(void);
void BtHfgClosePcmAudio(void);
void BtHfgInCallSetup(void);
void BtHfgInCallAlert(char *callerId);
void BtHfgOutCallSetup(void);
void BtHfgOutCallAlert(void);
void BtHfgCallAccept(void);
void BtHfgCallReject(void);
void BtHfgCallEnd(void);
void BtInCallAlert(char *callerId); 	/* BT_COMMON_KIMSANGJIN_070507 noti_011076 */
void BtSetCallWait(Boolean flag); /* BT_COMMON_KIMSANGJIN_070620 noti_011148*/
void BtFreeCallWait(void);


/****************************************************************************
** Hands-Free 1.5		// $suhui HFP1.5
****************************************************************************/
//** Description 	Signal Strength ���� 
void BtHfgSetSignalStrength(Int8 Level);

//** Description 	Roaming Status ���� 
void BtHfgSetRoamingStatus(Int8 Level);

//** Description 	Battery Level ���� 
void BtHfgSetBatteryLevel(Int8 Level);

//** Description 	Callheld Status ���� 
void BtHfgSetCallHeldStatus(LGBX_AG_CALL_HELD_TYPE value);

/*hfp15 20071001 baeheejung*/
//** Description	Call Waiting ���� ���� 
void BtHfgSetCallWaiting(UINT8_T* Num, UINT8_T Len);

//** Description 	Operator ���� ���� 
void BtHfgSetOperatorSelection(LGBX_AG_NETMODE_TYPE  Netmode, char *OpName);

//** Description 	Extended AG error result code ���� 
void BtHfgSetExtendedError(LGBX_AG_CME_ERR_TYPE ErrorCode);

//** Description 	Subscriber Number�� �����Ѵ�. 
//**				���� 2�� �̻��� Subscriber Number�� �����ϴ� ��� �ش� ������ŭ �� �Լ��� ȣ���Ͽ��� �Ѵ�. 
void BtHfgSetSubscriberNumber(UINT8_T* Num, Int8 Len, Int8 Type, 
									LGBX_AG_SERVICE_TYPE Service, Boolean FinalFlag);

//** Description 	OK�� �����Ѵ�. 
//**			    AT Command�� ���� OK�� ���� �� �� �Լ��� ȣ���Ѵ�.
Boolean BtHfgSendOK(void);

//** Description 	CIND�� �����Ѵ�. 
//**			    HF CONNECT�߿� CIND�� ���� �� �Լ��� ȣ���Ѵ�.
#if 1 /*kp230 20071107 baeheejung - HFP15*/
Boolean BtHfgSetCIND(void);
#else
Boolean BtHfgSetCIND(Int8 SignalLevel, Int8 RoamingStatus, Int8 BatteryLevel, LGBX_AG_CALL_HELD_TYPE value);
#endif

//** Description 	Current call list�� �����Ѵ�.
//**				���� 2�� �̻��� Call �� �����ϴ� ��� �ش� ������ŭ �� �Լ��� ȣ���Ͽ��� �Ѵ�. 
void BtHfgSetCurrentCallList(Int8 Idx, LGBX_AG_CL_DIR_TYPE Dir, LGBX_AG_CL_STATUS_TYPE Status,
								LGBX_AG_CL_MODE_TYPE Mode, LGBX_AG_CL_MPRTY_TYPE Mprty, UINT8_T* Num,
								Int8 Len, Int8 Type, Boolean FinalFlag);

/****************************************************************************
** Object Push Client
****************************************************************************/
void BtOpsPutAuthReply(Boolean allow);
void BtOpsPutMethodReply(Int8 * p_buf, Int32 size_buf, char* p_path);
/* GX_LEEJINBAEK_070227 */
void BtOpsGetAuthReply(Boolean allow);
void BtOpsGetMethodReply(Int8 * p_obj, Int32 size_obj, char* p_path);
/* end of GX_LEEJINBAEK_070227 */
void BtOpcPutObject(LGBX_DEVICEINFO_TYPE *dev, FileNameChar * fileFullPath, AfmfFileType  type, Int8 *p_obj, Int32 fileSize);
void BtOpcSendCancel(void);
void BtOpsSendCancel(void);

/****************************************************************************
** File Transfer Profile
****************************************************************************/
void BtFtcRemoteGetDir(char *name);
void BtFtcRemoteChDir(char *name);
void BtFtcGetFile(char *name);
void BtFtcPutFile(char *name);
void BtFtcSendCancel(void);
void BtFtsSendAuthAccept(Boolean isAccepted);
void BtFtsSendCancel(void);

void BtFtsDisconnectReq(void);	/* Don't USE this function */
/****************************************************************************
** Basic Printing Profile
****************************************************************************/
void BtBppPutObject(LGBX_DEVICEINFO_TYPE *dev, FileNameChar * fileFullPath, AfmfFileType  type, Int8 *p_obj, Int32 fileSize);
void BtBppSendCancel(void);
/****************************************************************************
**  Phonebook
****************************************************************************/


/***************************************************************************
* A2DP & AVRCP(Audio & Video Remote Control Profile)
***************************************************************************/
#if defined(LGE_LEMANS_BLUETOOTH)
Boolean BtA2dpIsStreaming(void);

/* Tiburona_071025 For Bluetooth A2DP */
void BtA2dpPlay(void);
void BtA2dpStop(void);
void BtA2dpPause(void);
void BtA2dpResume(void);
void BtA2dpForwardRewind(void);
void BtA2dpSetMp3PathAsBluetooth(BOOLEAN path);

void BtAvrcpSendEvent(LGBX_AVRCP_PASS_THROUGH_CMD_TYPE cmd);	/* LEMANS_Tiburona_070105 : add the AVRCP interface */
#endif /* LGE_LEMANS_BLUETOOTH */

/****************************************************************************
** Message Debugging
****************************************************************************/
char *BtGetMmiMsgName(BTMMIMSG msgid); 

#endif /* LGBX_INCLUDE */

#endif /* LGE_MMI_BLUETOOTH */

#endif  /* MMI_STACKIF */


