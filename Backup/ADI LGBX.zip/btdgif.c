/******************************************************************************* 
	Copyright by LG Electronics Inc.

FILE:			 Btdgif.c

DESCRIPTION:		 Utility & Dial Up & SPP  Interface Functions Definition for Bluetooth Stack

History:
2006/09/26	$Revision: 1.0 $  :: File System Interface Functions Definition for Bluetooth  
							 $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/
#if defined(LGE_L1_BLUETOOTH)
	
#include <stdlib.h> 
#include <string.h>

#if !defined(BTDGIF_H)
#include "btdgif.h"
#endif

#if defined(UPGRADE_430_PLATFORM)
#if !defined (DL430IRQ_H)
#include "Dl430irq.h"
#endif
#elif defined(UPGRADE_500_PLATFORM)
#if !defined (DLIRQDEF_H)
#include "Dlirqdef.h"
#endif
#endif

#if !defined (DLGPIO_H)
#include "dlgpio.h"
#endif

//#include "btqueue.h"
#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

#if !defined (LGEBTTYPE_H)
#include "Lgebttype.h"
#endif

#if !defined (BTTASK_SIG_H)
#include "bttask_sig.h"
#endif

#if !defined(VGMXDTECFG_H)
#include "Vgmxdtecfg.h"
#endif

#if !defined(MMI_STACKIF)
#include "Mmi_stackif.h"
#endif

#if defined(LGBX_INCLUDE)
#include "LGBXDunType.h"
#include "LGBXDunApi.h"
#include "LGBXSppType.h"
#include "LGBXSppApi.h"
#endif

#if defined(LGE_CSR_BLUETOOTH)
#include "sched/pmalloc.h"
#endif
UINT16_T			gLength=0;
BYTE_T				gBuf[1024]={0,};
LGBX_BD_ADDR_TYPE  gAddr=NULL;

#if 1 // noti_011227 recommand from Sean_071114: BtCommonDGReadData has to support length limitation for the data to read.
void BtCommonDGReadData(Int8 * data, Int16 * nbytes, Int16 maxLength)
{
    if(gLength>0)
    {
        Int16 data_size=maxLength;
        
        if(data_size > gLength)
        {
            data_size = gLength;
        }
        
        memcpy(data,gBuf,data_size);
        *nbytes=data_size;
        BT_DEBUG(("BtCommonDGReadData( [%d])",*nbytes));

        if(gLength>data_size)
        {
            memcpy(gBuf, &gBuf[data_size], gLength-data_size);
        }
        gLength -= data_size;
    }
}
#else
void BtCommonDGReadData(Int8 * data, Int16 * nbytes)
{
      Int16 data_size=0;

       if(gLength>0)
       {
		data_size =gLength;
		memcpy(data,gBuf,gLength);
		*nbytes=data_size;
		BT_DEBUG(("BtCommonDGReadData( [%d])",*nbytes));
       }
        gLength=0;  
}
#endif


Boolean TXSwIntStopState = FALSE;

void BtCommonDGWriteData(bt_uint8 * data, int nbytes)
{
#if defined(LGBX_INCLUDE)

BT_DEBUG(("BtCommonDGWriteData()  %d",nbytes));

if(BtFlag_IsConnected(BT_PROFILE_SERIAL_PORT) == TRUE)
      LGBX_SPP_SendData(gAddr, nbytes, data);
if(BtFlag_IsConnected(BT_PROFILE_DIAL_UP) == TRUE)	
	LGBX_DUN_WriteData(nbytes,data);	


#endif /* LGBX_INCLUDE */
		
}


#if defined(LGBX_INCLUDE)
LGBX_CBACK VOID_T LGBX_DUN_Cback(
	UINT32_T		Evt,
	UINT16_T		Size,
	VOID_T			*data )
{
	switch(Evt)
	{
		case LGBX_DUN_RECEIVED_DATA_EVT:
#if 1 // noti_011227 recommand from Sean_071114: There can be remained data in gBuf. So, new data has to be added to the end of old data.
				memcpy(&gBuf[gLength],data,Size);
                            gLength+=Size;
#else
				gLength=Size;
				memcpy(gBuf,data,Size);
#endif
			       BT_DEBUG(("gLength %d", gLength));				
			       BT_DEBUG(("BUF[0,1,2]=%x %x %x", gBuf[0],gBuf[1],gBuf[2] ));
				BtSPP_DUNProcessRxData();
				break;
			
		default:
			BT_DEBUG(("LGBX_DUN_Cback() unknown Event(%d)", Evt));
			break;
	}
}

LGBX_CBACK VOID_T LGBX_SPP_Cback(UINT32_T  Evt, UINT16_T Result, VOID_T *Info )
{
	LGBX_SPP_RCVDATA_TYPE* RcvData;
	RcvData = (LGBX_SPP_RCVDATA_TYPE*)Info;	

	switch( Evt )
	{

		case LGBX_SPP_RECEIVED_DATA_EVT:  
#if 1 // noti_011227 recommand from Sean_071114: There can be remained data in gBuf. So, new data has to be added to the end of old data.
		             memcpy(&gBuf[gLength],RcvData->Buf,RcvData->Length);
		             gLength+=RcvData->Length;
#else
				gLength=RcvData->Length;
				memcpy(gBuf, RcvData->Buf, RcvData->Length);
#endif
				memcpy(gAddr ,RcvData->BdAddr,LGBX_BD_ADDR_LEN);
			       BT_DEBUG(("gLength %d", gLength));				
			       BT_DEBUG(("BUF[0,1,2]=%x %x %x", gBuf[0],gBuf[1],gBuf[2] ));
				BtSPP_DUNProcessRxData();
			break;
			
		default:
			BT_DEBUG(("LGBX_SPP_Cback() unknown Event(%d)", Evt));
				break;
	}

}
#endif /* LGBX_INCLUDE */

#endif /* end of LGE_L1_BLUETOOTH */

