/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:			 Btdgif.c

DESCRIPTION:		 Utility & Dial Up & SPP  Interface Functions Definition for Bluetooth Stack

History:
2006/09/26	$Revision: 1.0 $  :: File System Interface Functions Definition for Bluetooth  
							 $ YOON JONG WOOK, KYUESUP BYUN
**************************************************************************/
#if !defined(BTDUTIF_H)
#define BTDUTIF_H

#if defined(LGE_L1_BLUETOOTH)

#if !defined (L1AL_TYP_H)
#include <l1al_typ.h>	 /* LEMANS_KANGHYUNGWOOK_061122 */
#endif

typedef enum BtTestModeStateTag
{
   BT_TEST_MODE_NULL,
   BT_TEST_MODE_AUDIO,
   BT_TEST_MODE_RF,
   BT_TEST_MODE_NUM   
} BtTestModeState;

/*Btdutif.c*/
void L1AlSendAudioChannelSetupReq (L1AudioChannel channel);

void L1AlSendAudioChannelTerminateReq (L1AudioChannel channel);

void L1AlSendAudioLoopBackReq (Boolean active, Int16 audioCodec );

void audioLoopBackTestStart(void);

void audioLoopBackTestStop(void);

 

#if 0
/*btapp_test.c*/
extern void btapp_EnableDUTMode(void);

extern void btapp_ExitDutMode(void);

extern void btapp_EnablePCMLoopbackMode(unsigned char);
#endif

#endif /* LGE_L1_BLUETOOTH */

#endif /* BTDUTIF_H */

