/*******************************************************************************

			Copyright by LG Electronics Inc.

FILE
				 L1BTIF.c	 

DESCRIPTION:
				 Bluetooth BCM1200 Interface functions 
				 & Lemans Interface Functions, BTE 3.0
				$Revision: 1.0 $ by $Author: Kyue Sup Byun & Sang-Jin KIM $
				2006/08/11	: Definition for Base Functions

History: job100502
2006/08/11 $Revision: 1.0 $  :: $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
		   
**************************************************************************/
#if !defined (LGEBTTIMERS_H)
#define       LGEBTTIMERS_H

#if defined(LGE_L1_BLUETOOTH)
/***************************************************************************
 * Nested Include Files
 **************************************************************************/
#include  <system.h>
#include  <kernel.h>
/* BT_L1_KIMSANGJIN_060818 */
#include <dmtmrid.h>
/* end of BT_L1_KIMSANGJIN_060818 */

/***************************************************************************
 * Manifest Constants
 **************************************************************************/

/***************************************************************************
 * Type Definitions
 **************************************************************************/
#define BTK_SCHED_TIMER_USER_VALUE	  100
/* On adding a timer to L1TimerNum you must add entries to the following tables
 * l1TimerTaskId                 - l1timers.c
 * cfL1TimerInaccuracyPercentage - l1alcfg.c
 * */
typedef enum LgeBtTimerNumTag
{
	BT_TIMER_TYPE_SEMA_TIMER = 0,
	BT_TIMER_TYPE_TEST_TIMER,
	BT_TIMER_TYPE_DEBUG_DISPLAY_TIMER,
	BT_TIMER_TYPE_HOOK_TIMER,
	BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER,
	BT_TIMER_TYPE_TX_POLLING_TIMER,
	BT_TIMER_TYPE_TIMEOUT_TIMER,
	BT_TIMER_TYPE_BT_ON_TIMER,
	BT_TIMER_TYPE_BT_POPUP_TIMER,
	BT_TIMER_TYPE_BT_PCM_TIMER,
	/*------------------------------------*/
	NUM_OF_BT_TIMERS
}
LgeBtTimerNum;

/***************************************************************************
 *  Global Variables
 **************************************************************************/
extern KiTimer lgeBtTimer [ NUM_OF_BT_TIMERS ];

/***************************************************************************
 *  Global Functions
 **************************************************************************/
extern void lgeBtTimersInitialise ( void );
extern void lgeBtStartTimer( LgeBtTimerNum btTimerNum,Int32 sec );
extern void lgeBtStopTimer( LgeBtTimerNum btTimerNum );
extern void lgeBtTimerExpiry( LgeBtTimerNum btTimerNum );
extern void lgeBtMsStartTimer( LgeBtTimerNum btTimerNum, Int16 timeInMs );
extern void lgeBtHandleTimerExpiry( void );
#if defined (LGBX_INCLUDE)
	extern void lgeLGBXHandleTimerExpiry( void );
#endif

/**************************************************************************/
/* Local wait milliseconds function implemented using a timer and a semaphore
 * to ensure that the code waits for the desired period but does not hold out 
 * other operations. */
extern void lgeBtDelayMilliseconds( Int16 waitTime );

#if defined (LGBX_INCLUDE)
	extern void lgeLGBXDelayMilliseconds( Int16 waitTime );
#endif

/* LGE_MERGE_BLUETOOTH : 2004.07.19 IRON Adds Hook&PCM audio fuctions */
void startBTHOOKTimer(void);
void stopBTHOOKTimer(void);
void BTHOOKTimerExpiry(void);

void startBTDebugDisplayTimer(void);
void stopBTDebugDisplayTimer(void);
void BTvTimerExpiry(void);

void startBTTestTimer(void);
void stopBTTestTimer(void);
void BTTestTimerExpiry(void);

void startBTInquiryTimer(void);
void stopBTInquiryTimer(void);


#if 1 /* LGE_BT_Tiburona_060831 */
void startBTAudioPathChangeTimer(Int16 msec);
#else
/* LGE_MERGE_BLUETOOTH : 2004.12.18 SKLEE Insert for audio timing */		
#if 1
void startBTAudioPathChangeTimer(Boolean isPhonePath);
#else
void startBTAudioPathChangeTimer(void);
#endif
#endif

void stopBTAudioPathChangeTimer(void);
void BTAudioPathChangeTimerExpiry(void);


/* LOUIS job00003_1 */
/* BCM_070410 JOB 00002 CHRIS */
void startBTTxPollingTimer(Int8 timeout);
//void startBTTxPollingTimer(void);
void RestartBTTxPollingTimer(void);
void killBTTxPollingTimer(void);

/* end of BCM_070410 JOB 00002 CHRIS */

void stopBTTxPollingTimer(void);
void BTTxPollingTimerExpiry(void);


/* LGE_MERGE_BLUETOOTH : 2004.12.30 SKLEE inserts for BT operation timeout */
#if 1
void startBTTimeOutTimer(void);
void stopBTTimeOutTimer(void);
void BTTimeOutTimerExpiry(void);
#endif

#if 1 /* LGE_MERGE_BLUETOOTH: SKLEE_050109_BTON */
void InitBtOnTimer(void);
void StartBtOnTimer(void);
void StopBtOnTimer(void);
void HandleBtOnTimerExpiry(void);
#endif

/* LGE_K_JIN100_WARNING_050316 */
Boolean RetryBtOn(void);

#endif /* LGE_L1_BLUETOOTH */

#endif
/* END OF FILE */
