/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:			 Btdgif.c

DESCRIPTION:		 Utility & Dial Up & SPP  Interface Functions Definition for Bluetooth Stack

History:
2006/09/26	$Revision: 1.0 $  :: File System Interface Functions Definition for Bluetooth  
							 $ YOON JONG WOOK, KYUESUP BYUN
**************************************************************************/

#define MODULE_NAME "BTDUTIF"

#if defined(LGE_L1_BLUETOOTH)
/****************************************************************************
* Include Files
****************************************************************************/
#include <kernel.h>
#include "gsmdatds.h"

#if !defined (L1AL_SIG_H)
#include <l1al_sig.h>
#endif

#if defined (UPGRADE_AUDIO_MANAGER)
#if !defined (L1AM_SIG_H)
#include <l1am_sig.h>	/* LEMANS_KANGHYUNGWOOK_061122 */
#endif
#endif

#if !defined(BTDUTIF_H)
#include <btdutif.h>
#endif

#define AUDIO_INPUT_CHANNEL  	0
#define AUDIO_OUTPUT_CHANNEL 	1

union Signal
{
  L1AlAudioChannelSetupReq      l1AlAudioChannelSetupReq;
  L1AlAudioChannelSetupCnf      l1AlAudioChannelSetupCnf;
  L1AlAudioChannelTerminateReq  l1AlAudioChannelTerminateReq;
  L1AlAudioChannelTerminateCnf  l1AlAudioChannelTerminateCnf;
  L1AlAudioLoopBackReq          l1AlAudioLoopBackReq;
  L1AmAudioLoopbackReq		l1AmAudioLoopbackReq;
};
 

 void L1AlSendAudioChannelSetupReq (L1AudioChannel channel)
 {
   SignalBuffer signalToSend = kiNullBuffer;
 
   /* Create signal */
   KiCreateSignal (SIG_L1AL_AUDIO_CHANNEL_SETUP_REQ,
				   sizeof(L1AlAudioChannelSetupReq),
				   &signalToSend);
   signalToSend.sig ->l1AlAudioChannelSetupReq.taskId = TASK_FL_ID;
   signalToSend.sig ->l1AlAudioChannelSetupReq.commandRef  = 0;
   signalToSend.sig ->l1AlAudioChannelSetupReq.channel	  = channel;
#if !defined(btdutif_temp)
   signalToSend.sig ->l1AlAudioChannelSetupReq.volume.MonoOrLeft = 100;
   signalToSend.sig ->l1AlAudioChannelSetupReq.volume.Right = 100;
#else
#if defined (LGE_LEMANS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
   signalToSend.sig ->l1AlAudioChannelSetupReq.volume.MonoOrLeft = 100;
   signalToSend.sig ->l1AlAudioChannelSetupReq.volume.Right = 100;
#elif defined(LGE_ATLAS_BLUETOOTH)
   signalToSend.sig ->l1AlAudioChannelSetupReq.volume.= 100;
#endif /*LGE_LEMANS_BLUETOOTH*/
#endif

   /* Configure for input */
   if (channel == AUDIO_INPUT_CHANNEL)
   {
	 signalToSend.sig->l1AlAudioChannelSetupReq.audioFormat = ENCODED_DATA_RECORD;
#if defined(btdutif_temp)
#if defined (LGE_LEMANS_BLUETOOTH) || defined(LGE_ATLAS_BLUETOOTH)
	 signalToSend.sig->l1AlAudioChannelSetupReq.audioDevice = MAIN_MIC;
#endif
#endif
	 
   }
   /* Configure for output */
   else if (channel == AUDIO_OUTPUT_CHANNEL)
   {
	 signalToSend.sig->l1AlAudioChannelSetupReq.audioFormat = ENCODED_DATA_PLAYBACK;
#if defined(btdutif_temp)
#if defined (LGE_LEMANS_BLUETOOTH) || defined(LGE_ATLAS_BLUETOOTH)
	 signalToSend.sig->l1AlAudioChannelSetupReq.audioDevice = MAIN_SPEAKER;
#endif
#endif	 
   }
   /* Invalid */
   else
   {
	 DevFail("Invalid channel");
   }
 
   KiSendSignal (L1_AL_TASK_ID,&signalToSend);
 }



  void L1AlSendAudioChannelTerminateReq (L1AudioChannel channel)
 {
   SignalBuffer signalToSend = kiNullBuffer;
 
   /* Create signal */
   KiCreateSignal (SIG_L1AL_AUDIO_CHANNEL_TERMINATE_REQ,
				   sizeof(L1AlAudioChannelTerminateReq),
				   &signalToSend);
   signalToSend.sig->l1AlAudioChannelTerminateReq.taskId	  = TASK_FL_ID;
   signalToSend.sig->l1AlAudioChannelTerminateReq.commandRef  = 0;
   signalToSend.sig->l1AlAudioChannelTerminateReq.channel	  = channel;
 
   /* Send signal */
   KiSendSignal (L1_AL_TASK_ID,&signalToSend);
 
 }


   void L1AlSendAudioLoopBackReq (Boolean active, Int16 audioCodec)
 {
   SignalBuffer signalToSend = kiNullBuffer;
 
   /* Create signal */
   KiCreateSignal (SIG_L1AL_AUDIO_LOOPBACK_REQ,
				   sizeof(L1AlAudioLoopBackReq),
				   &signalToSend);
   signalToSend.sig->l1AlAudioLoopBackReq.taskId			= TASK_FL_ID;
   signalToSend.sig->l1AlAudioLoopBackReq.commandRef		= 0;
   signalToSend.sig->l1AlAudioLoopBackReq.loopbackIsOn		= active;
   signalToSend.sig->l1AlAudioLoopBackReq.inputChannel		= AUDIO_INPUT_CHANNEL;
   signalToSend.sig->l1AlAudioLoopBackReq.outputChannel 	= AUDIO_OUTPUT_CHANNEL;
   signalToSend.sig->l1AlAudioLoopBackReq.audioCodec		= audioCodec;
   signalToSend.sig->l1AlAudioLoopBackReq.delayBufferLength = 0;
   /* Send signal */
   KiSendSignal (L1_AL_TASK_ID,&signalToSend);
 
 }

#if defined (LGE_LEMANS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH) /* LEMANS_KANGHYUNGWOOK_061122 */
void audioLoopBackTestStart(void)
{
    SignalBuffer signalToSend = kiNullBuffer;
    
    /* Create signal */
    KiCreateSignal (SIG_L1AM_AUDIO_LOOPBACK_REQ,
                    sizeof(L1AmAudioLoopbackReq),
                    &signalToSend);
    signalToSend.sig->l1AmAudioLoopbackReq.taskId       = TASK_FL_ID;
    signalToSend.sig->l1AmAudioLoopbackReq.commandRef   = 0;
    signalToSend.sig->l1AmAudioLoopbackReq.isOn         = TRUE;
    signalToSend.sig->l1AmAudioLoopbackReq.audioCodec   = AU_CODEC_FR;
    /* Send signal */
    KiSendSignal (L1AM_TASK_ID, &signalToSend);
}

void audioLoopBackTestStop(void)
{
    SignalBuffer signalToSend = kiNullBuffer;
    
    /* Create signal */
    KiCreateSignal (SIG_L1AM_AUDIO_LOOPBACK_REQ,
                    sizeof(L1AmAudioLoopbackReq),
                    &signalToSend);
    signalToSend.sig->l1AmAudioLoopbackReq.taskId       = TASK_FL_ID;
    signalToSend.sig->l1AmAudioLoopbackReq.commandRef   = 0;
    signalToSend.sig->l1AmAudioLoopbackReq.isOn         = FALSE;
    signalToSend.sig->l1AmAudioLoopbackReq.audioCodec   = AU_CODEC_FR;
    /* Send signal */
    KiSendSignal (L1AM_TASK_ID, &signalToSend);
}
#elif defined(LGE_ATLAS_BLUETOOTH)
void audioLoopBackTestStart(void)
 {
	   L1AlSendAudioChannelSetupReq(AUDIO_INPUT_CHANNEL);
	   L1AlSendAudioChannelSetupReq(AUDIO_OUTPUT_CHANNEL);
	   L1AlSendAudioLoopBackReq (TRUE, AU_CODEC_FR);
 }
 void audioLoopBackTestStop(void)
 {
	   L1AlSendAudioLoopBackReq (FALSE, AU_CODEC_FR);
	   L1AlSendAudioChannelTerminateReq(AUDIO_INPUT_CHANNEL);	   
	   L1AlSendAudioChannelTerminateReq(AUDIO_OUTPUT_CHANNEL);	   
}
#endif

#endif /* LGE_L1_BLUETOOTH */

/* END OF FILE */

