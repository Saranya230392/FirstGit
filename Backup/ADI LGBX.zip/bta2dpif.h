/*******************************************************************************

			Copyright by LG Electronics Inc.

FILE
			     bta2dpif.h    

DESCRIPTION:
			     A2DP Interface functions for LeMans

History:
2006/09/13 $Revision: 1.0 $  :: $ release by SONG JONG-HYUK(TTPCOM Korea)
							 modified by KANG HYUNG-WOOK
**************************************************************************/

#if !defined(BTA2DPIF_H)
#define BTA2DPIF_H

///////////////////////////////////////////////////////////////////////////
#if defined(LGE_L1_BLUETOOTH)
///////////////////////////////////////////////////////////////////////////

#if defined(LGE_LEMANS_BLUETOOTH)

/****************************************************************************
 * Test Utilities
 *     : used for verifying A2DP API operations(). it's very useful, don't delete
****************************************************************************/
/* WAV_SAVE define�� PCM_AUDIO_TEST define�� ���ÿ� ���Ұ� */
/* WAV_SAVE define
: Mp3 decoding�� PCM data�� wav format���� file system(external memory)�� ���ϸ��� pcm.wav���� ���� */
//#define WAV_SAVE	/* Check this define in the amrsp_api.c(for AMR decoder) */

/* PCM_AUDIO_TEST define
: Mp3 decoding�� PCM data�� audio�� �ٷ� Ȯ�ΰ��� */
//#define PCM_AUDIO_TEST

#if defined(WAV_SAVE) /* JHS2 13Sep2006 */
/****************************************************************************
* Include Files
****************************************************************************/
#include <stdio.h>

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/
#define BT_A2DP_PCM_BUFFER_SIZE     (1024 * 32 * 5)
#define BT_A2DP_PCM_BUFFER_LO_WM    (1024 * 24)	// WAV_SAVE	for test
#define BT_A2DP_PCM_BUFFER_HI_WM    (1024 * 32)	// WAV_SAVE	for test
//#define BT_A2DP_PCM_BUFFER_LO_WM    (1024 * 32)		// normal
//#define BT_A2DP_PCM_BUFFER_HI_WM    (1024 * 32 * 3)	// normal

/****************************************************************************
* Type Definitions
****************************************************************************/
typedef struct
{
	SignedInt16   	buffer[BT_A2DP_PCM_BUFFER_SIZE];
	SignedInt32   	wrIndex;                    		/* Buffer read index.*/
	SignedInt32   	rdIndex;                    		/* Buffer write index.*/

	SignedInt32   	length;                     		/* Circular length.*/
	SignedInt32   	lowWaterMark;               	/* Low water mark to schedule trigger the data generator.*/
	SignedInt32   	highWaterMark;              	/* High water mark to schedule trigger the data generator.*/
	Boolean       	bFlowOn;

	SignedInt32   	mediaLength_ms;
	Int32         	audioSamplingRate;
	Int16         	numAudioChannels;
} BtA2dpBuffer;

/****************************************************************************
* Exported Variables
****************************************************************************/
extern volatile BtA2dpBuffer *const btA2dpBuffer_p;
extern Int32 wave_data_size;
//extern FILE *wavefile_p;

/****************************************************************************
* Macros
****************************************************************************/

/****************************************************************************
* Global Function Prototypes
****************************************************************************/
extern void BtA2dpBufferInitialise(void);
extern void BtA2dpNotifyCodecSetupComplete(SignedInt32 mediaLength_ms, Int32 audioSamplingRate, Int16 numAudioChannels);
extern void BtA2dpNotifyAudioChannelEnabled(void);
extern void BtA2dpNotifyMmacEndOfData(void);
extern void BtA2dpPcmBufferWmCheck(void);
extern Int32 BtA2dpPcmDataRead(SignedInt16* buff, SignedInt32 buffLength);
extern Int16* BtA2dpPcmGetBuf(void);
Boolean BtA2dpPcmCheckDataReady(void);
extern Int16 BtA2dpSamplingFrequency(void);
extern Int16 BtA2dpNumChannels(void);
extern void mmacA2dpDecoderPauseReq(void);
extern void mmacA2dpDecoderResumeReq(void);
extern void transferDataToA2dpPcmbuffer (SignedInt16  *srcBuffer_p, SignedInt32 numSamplesToTransfer);
#endif /* WAV_SAVE */

#if 1 /* Tiburona_071025 For Bluetooth A2DP */
extern void BtA2dpSetSamplingRate(Int32 audioSamplingRate);
extern Int32 BtA2dpGetSamplingRate(void);
extern void BtA2dpSetNumAuioChannel(Int16 numAudioChannels);
extern Int16 BtA2dpGetNumAuioChannel(void);
extern void BtA2dpSetNumSamplesToTransfer(SignedInt32 numSamplesToTransfer);
extern SignedInt32 BtA2dpGetNumSamplesToTransfer(void);
#endif

#endif /* LGE_LEMANS_BLUETOOTH */

///////////////////////////////////////////////////////////////////////////
#endif /* LGE_L1_BLUETOOTH */
///////////////////////////////////////////////////////////////////////////

#endif /* L1BTIF_H */


