/***************************************************************************
* FILE: btconfig.h
* AUTH: Sang-Kwon Lee
* DATE: 2004/10/05
* DESC: Configuration Constants for Bluetooth
***************************************************************************/

#if !defined(BTCONFIG_H)
#define BTCONFIG_H

#if defined(LGE_L1_BLUETOOTH)

/***************************************************************************
* Include File
***************************************************************************/

#include "system.h"
#if 1 /* M4300_BT_FTP_050207 : 2005.02.07 SKLEE inserts for FTP profile */
#include "l1al_sig.h"
#endif

/***************************************************************************
* Manifest Constants / Defines
***************************************************************************/

/* Profile list */
#define BT_FLAG_NONE        	0
#define BT_FLAG_SPP_1         	1
#define BT_FLAG_SPP_2         	2
#define BT_FLAG_SPP_3         	3
#define BT_FLAG_DUN         	4
#define BT_FLAG_SYNC        	5
#define BT_FLAG_OPP         	6
#define BT_FLAG_FTP         	7
#define BT_FLAG_CTP         	8
#define BT_FLAG_ICP         	9
#define BT_FLAG_FAX         	10
#define BT_FLAG_AGW        		11
#define BT_FLAG_PAN_PANU    	12
#define BT_FLAG_PAN_NAP     	13
#define BT_FLAG_PAN_GN      	14
#define BT_FLAG_BIP         	15
#define BT_FLAG_BIPS       		16
#define BT_FLAG_HF          	17
#define BT_FLAG_HFG				18
#define BT_FLAG_BPP				19 
#define BT_FLAG_A2DP				20

/*------------------------------*/
#define BT_NUM_OF_PROFILES		21

/* COD: Class of device */
#define BT_COD_HEADSET			0
#define BT_COD_HANDSFREE		1
#define BT_COD_MOBILE_PHONE		2
#define BT_COD_COMPUTER			3
#define BT_COD_PRINTER			4 /* JIN100_BT_BPP 050601 */
#define BT_COD_OTHER			5
/*-----------------------------*/
#define BT_NUM_OF_COD			6

/* Service mask values */
#define BT_SVC_MASK_INIT_VALUE	0X0000
#define BT_SVC_MASK_VALID_LIST	0x0001
#define BT_SVC_MASK_HEADSET		0x0002
#define BT_SVC_MASK_HANDSFREE	0x0004

 /* Timeout value used for inquiry: 1 second */
#define	BT_INQUIRY_TIMEOUT		1000

 /* Progress Bar Count used in Inquiry */
/* BT_MMI_KIMSANGJIN_050831 */
#define BT_PROGRESS_BAR_COUNT	60
/* end of BT_MMI_KIMSANGJIN_050831 */

/* Number of retries for passcode input */
#define BT_NUM_PASSCODE_RETRY	2

/* Number of software UARTs used for Bluetooth: GSPA and GSPB
 *   - GSPA is used for PC Synch and DUN
 *   - GSPB is used for Genie 
 */
#define BT_NUM_OF_SW_UARTS		2

#define BT_MAX_FOUND_DEVICE		16
#define BT_MMI_LINK_KEY_SIZE	16
#define BT_MMI_PASS_KEY_SIZE	16
#define BT_MMI_DEVICE_NAME_SIZE	50 /* Tiburona BT_050816 equal to MMI_DEVICE_NAME_SIZE 64->50 */
#define BT_MMI_DBASE_SIZE		16

#if 1 /* Tiburona BT_051004 for common library */
#define BT_MMI_FILENAME_SIZE	127 /* Tiburona BT_051006 */
#else
#if 1 /* M4300_BT_FTP_050207 : 2005.02.07 SKLEE inserts for FTP profile */
#define BT_MMI_FILENAME_SIZE	FILE_NAME_SIZE
#else
#define BT_MMI_FILENAME_SIZE	64
#endif
#endif

#define BT_MAX_PAIRDED_DEVICE	16
#define BT_INVALID_DEVICE_INDEX	(BT_MAX_PAIRDED_DEVICE+1)

/* maximum length of VCard in string format */
#define BT_MAX_VCARD_STRING_SIZE	1024

#endif /* LGE_L1_BLUETOOTH */
#define BT_SUBLCD_PASSKEY_IND       4
#define BT_SUBLCD_ACCESS_FILE       5 
#define BT_SUBLCD_CONNECT_IND       6 
#define BT_SUBLCD_DISCONNECT_IND 7
#define BT_SUBLCD_ADD_PB            8
#define BT_SUBLCD_SEND_VCARD        9 
/* M4300_KIMSANGJIN_050422 */
#define BT_BUF_SIZE			128
#define DELETE_POP_TIMEOUT 				MILLISECONDS_TO_TICKS(1000)
#define BT_POPUP_TIME		SECONDS_TO_TICKS(30)

/* end of M4300_KIMSANGJIN_050422 */
#endif  /* BTCONFIG_H */

