/*******************************************************************************

			Copyright by LG Electronics Inc.

FILE				
				L1BTIF.c    

DESCRIPTION:
				Bluetooth Module Interface & Control Functions 
	            2006/08/11  : Definition for Base Functions for BCM(BTE 3.0)
	            2006/08/14  : Merged from btutil.* to l1btif.* file from old source code 
	            2007/06/23  : Added the functions to control the BlueCore(BCHS 15.0)

History: job100502
2006/08/11 $Revision: 1.0 $  :: $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
2007/06/23 $Revision: 2.0 $  :: $ KANG HYUNG WOOK
**************************************************************************/

#define MODULE_NAME "L1BTIF"

///////////////////////////////////////////////////////////////////////////
#if defined(LGE_L1_BLUETOOTH)
///////////////////////////////////////////////////////////////////////////

/****************************************************************************
* Include Files
****************************************************************************/
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if !defined (SYSTEM_H)
#include <system.h>
#endif

#if !defined (KERNEL_H)
#include <kernel.h>
#endif

#if !defined(L1BTIF_H)
#include "l1btif.h"
#endif

#if !defined (KITQID_H)
#include "kitqid.h"
#endif

#if defined(UPGRADE_500_PLATFORM)
#include <Pdgpio500.h>
#include <Pdgpiotypes500.h>
#include <Dl500tick.h>
#include "dlegsppcm.h"
#endif


#if defined( UPGRADE_AD6528 ) || defined ( UPGRADE_500_PLATFORM )
#if !defined (DLEGSP_H)
#include <dlegsp.h>
#endif
#endif

#if !defined (DLAUACQCFG_H)
#include <dlauacqcfg.h>
#endif

#if !defined( DLDSPAUDIO_H )
#include <dldspaudio.h>
#endif

#if !defined (DLMCLK_H)
#include <dlmclk.h>	/* BT_L1_KIMSANGJIN_060814 :for MCLK_MUXOUT*/
#endif

#if !defined (DLEMMIHI_H)
#include "dlemmihi.h"
#endif

#if !defined (LGEBTSPALHI_H)
#include <lgebtspalhi.h>
#endif

#if !defined (UDEBUG_H)
#include "uDebug.h"
#endif

#if !defined (LGEBTTIMERS_H)
#include "lgebttimers.h"
#endif

#if !defined(BTFLAG_H)
#include "btflag.h"
#endif

#if defined (UPGRADE_AUDIO_MANAGER)
#if !defined (L1AM_SIG_H)
#include "l1am_sig.h" /* ABB power on/off during sleep mode */
#endif
#endif

#if !defined (DMACC_SIG_H)
#include "dmacc_sig.h"
#endif

#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
#if !defined (DLMMICFG_H)
#include "Dlmmicfg.h"
#endif
#endif

#if !defined (L1UT_SIG_H)
#include  <l1ut_sig.h> 
#endif

#if !defined (L1BGCFG_H)
#include  <l1bgcfg.h>
#endif

#if !defined (AFNV_TYP_H)
#include "afnv_typ.h"
#endif

#if defined(LGE_BRCM_BLUETOOTH)
#include "target.h"
#endif

#if defined(LGE_CSR_BLUETOOTH)
#include "sched/sched.h"
#include "bccmd_lib.h"
#endif
/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/
#define CONTROL_DELAY_TIME 1

/****************************************************************************
* Type Definitions
****************************************************************************/
union Signal
{
	/* BT -> Layer1 signals */
	L1Dont32kSleepReq           l1Dont32kSleepReq;
	L1AmMixExternalAudioReq	l1AmMixExternalAudioReq;	/* ABB power on/off during sleep mode */
	L1AmRoutingChangeReq        l1AmRoutingChangeReq; 
};

/****************************************************************************
* Variables
****************************************************************************/
static volatile Boolean gIsBtTaskReady = FALSE;

/****************************************************************************
* Extern Functions
****************************************************************************/
extern DlSpalHandle     btPortHandle;

#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
extern void DlCfUscRouting ( UscRouteConfig paramMode );
#if defined(UPGRADE_430_PLATFORM)
extern void DefaultUscRoutingForBT(void);
extern void DataUscRoutingForBT(void);
extern void AudioUscRoutingForBT(void);
#endif /* UPGRADE_430_PLATFORM */
#endif

#if defined(LGE_ATLAS_2H_BLUETOOTH) /* BT_COMMON_KIMSANGJIN_070209 noti_011003 */
/*Avoid USC6 32Khz clk, and Use a GPIO_40 [32Khz Clk_mux1]*/
extern void BT_SLEEP_CLK_ON(void); 
extern void BT_SLEEP_CLK_OFF(void);
#endif /*LGE_ATLAS_2H_BLUETOOTH*/

#if defined(LGE_BRCM_BLUETOOTH)
extern BT_API int BootEntry( void );
extern void stopBTTimer (void); /*noti_010314*/
extern void startBTTimer (void); /*noti_01234500*/
#endif

#if defined(LGE_CSR_BLUETOOTH)
extern void BtInitCsrTask( void );
#endif

extern void agauSetBluetooth(Boolean bEnableBluetooth); /* KP230_KIMDAEWOO_20071129_BT_AUDIO */		

#if defined(LGE_L1_FM) /* BT_COMMON_Tiburona_080126 */	
extern BOOLEAN LGE_fm_is_enabled(void);
extern FMRadioDevice LGE_fm_is_device(void);
#endif /* LGE_L1_FM */

/****************************************************************************
* Local Function Prototypes
****************************************************************************/
static void BtUartErrorFlagInit(void);
static void BtPcmInit(void);
#if defined(LGE_LEMANS_BLUETOOTH)
static void BtPcmDeconfig(void);
#endif /* LGE_LEMANS_BLUETOOTH */
#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
void BtPcmOn(void); /*BT_COMMON_KIMSANGJIN_080102 noti_011248*/
static void BtPcmOff(void);
#endif

#if defined(LGE_BRCM_BLUETOOTH)
static void BtWakeUpInit(void);
#endif

static void BtInterruptEnable(void);
static void BtInterruptDisable(void);

static void BtPowerOn(void);
static void BtPowerOff(void);
static void BtResetOn(void);
static void BtResetOff(void);

#if defined(LGE_BRCM_BLUETOOTH)
static void BtSleepClkOn(void);
static void BtSleepClkOff(void);
#endif /* LGE_BRCM_BLUETOOTH */

static void BtDeconfig(void);

#if defined(LGE_BRCM_BLUETOOTH)
static void BtPowerUpConfigForBRCM(void);;
static void BtPowerDownConfigForBRCM(void);
#endif /* LGE_BRCM_BLUETOOTH */

#if defined(LGE_CSR_BLUETOOTH)
static void BtPowerUpConfigForCSR(void);
static void BtPowerDownConfigForCSR(void);
#endif /* LGE_CSR_BLUETOOTH */

/***************************************************************************
* Check the BT Task (For SPAL/FTP/BX)
***************************************************************************/
void BtFlag_SetRunTask(Boolean flag)
{
	gIsBtTaskReady = flag;
    	BT_DEBUG(("BtFlag_SetRunTask() flag=%c", flag? 'T' : 'F'));
    	
/* BT_COMMON_KIMSANGJIN_071224 noti_011244*/
/*************************************************************************************************
- <Description about noti_011244 Tag>
* If we use CSR bluetooth chipset, somtimes BT_DBB_INT pin's state is High(1.8V) so we re-configurate a BT_DBB_INT 
* pin to OUTPUT mode and make deassert
* It was request from HW (������J/��â��S) for Dolphin2 models.
**************************************************************************************************/
#if defined (LGE_CSR_BLUETOOTH)
	if(flag == TRUE)
	{
		PdGpioConfigure(GPIO_BT_INT_DISABLE);
		PdGpioDeassertLine(M_DLGpioLine(GPIO_BT_INT_DISABLE));
	}
#endif /*LGE_CSR_BLUETOOTH*/
/* end of BT_COMMON_KIMSANGJIN_071224 */
}

Boolean BtFlag_IsRunTask(void)	
{
	return gIsBtTaskReady;
}

/****************************************************************************
* Global Functions
****************************************************************************/
/****************************************************************************	
* Test Functions using GPIO
****************************************************************************/
#if defined(GPIO_FLAG_FOR_UART_TEST)
#define GPIO_FOR_BT_TEST	GPIO_9,   PIN_MODE_NORMAL,  GPIO_OUTPUT, ACTIVE_HIGH

static void BtUartErrorFlagInit(void)
{
	PdGpioConfigure(GPIO_FOR_BT_TEST);
	PdGpioDeassertLine(M_DLGpioLine(GPIO_FOR_BT_TEST));
}

void BtUartErrorFlagOn(void)
{
	PdGpioAssertLine(M_DLGpioLine(GPIO_FOR_BT_TEST));
    	//BT_DEBUG(("EnableUartErrorFlag()"));
}

void BtUartErrorFlagOff(void)
{
	PdGpioDeassertLine(M_DLGpioLine(GPIO_FOR_BT_TEST));
    	//BT_DEBUG(("DisableUartErrorFlag()"));	
}
#endif /*End of GPIO_FLAG_FOR_UART_TEST*/

/****************************************************************************	
* Sleep mode Control
****************************************************************************/
void BtSendSleepAllowedReq(Boolean canSleep)
{
	SignalBuffer sendSignal = kiNullBuffer;
	KiCreateSignal(SIG_L1_DONT_32K_SLEEP_REQ,sizeof(L1Dont32kSleepReq),&sendSignal);
	sendSignal.sig->l1Dont32kSleepReq.sourceModule = BT_DRIVER_MODULE;

	if( (curBTTestModeIsRF()==TRUE)
#if defined(LGE_L1_FM) /* BT_COMMON_Tiburona_080126 */		
		|| ((LGE_fm_is_enabled()==TRUE) && (LGE_fm_is_device()==FM_RADIO_DEV_BT_HEADSET))
#endif		
	)
	{
		/* Don't sleep is TRUE, ie the target is not allowed to sleep. */
		sendSignal.sig->l1Dont32kSleepReq.active = TRUE;	
		BT_DEBUG(("\x1b[31m [BT] ============> BtSendSleepAllowedReq() : RF TEST mode or FM Radio via SCO \x1b[0m"));
		BT_DEBUG(("\x1b[31m [BT] ============> BtSendSleepAllowedReq() : %s", "Baseband Don't Sleep \x1b[0m"));
	}
	else
	{	
		if(canSleep)
		{
			/* Don't sleep is FALSE, ie the target is allowed to sleep. */
			sendSignal.sig->l1Dont32kSleepReq.active = FALSE;
		}
		else /* Power saving not allowed. */
		{
			/* Don't sleep is TRUE, ie the target is not allowed to sleep. */
			sendSignal.sig->l1Dont32kSleepReq.active = TRUE;
		}	
		//BT_DEBUG(("\x1b[31m [BT] ============> BtSendSleepAllowedReq() : %s \x1b[0m", canSleep?"Baseband Can Sleep":"Baseband Don't Sleep"));
	}
	KiSendSignal(cfL1BgTaskId, &sendSignal);    
}

void SendBtSleepSig(SleepDeviceState sate)
{
	SignalBuffer sendSignal = kiNullBuffer;
       DMSleepInd *sig_p;

	sig_p = (DMSleepInd *)sendSignal.sig;
	KiCreateSignal ( SIG_DM_SLEEP_IND, sizeof(DMSleepInd), &sendSignal );

	sig_p->sourceModule = BLUETOOTH_MODULE;
	sig_p->state = sate;

	KiSendSignal (DM_TASK_ID, &sendSignal);
}

/******************************************************************************************
* ABB(Audio Base Band) Control : This funection is to do ABB power on/off during sleep mode when ABB(AIN3 pin) is used.				
 ******************************************************************************************/
void BtSendAbbPowerOnReq(Boolean onoff) /* ABB power on/off during sleep mode */
{
	SignalBuffer sendSignal = kiNullBuffer;
	KiCreateZeroSignal(SIG_L1AM_MIX_EXTERNAL_AUDIO_REQ, sizeof(L1AmMixExternalAudioReq), &sendSignal);
	sendSignal.sig->l1AmMixExternalAudioReq.taskId = KiThisTask();
	sendSignal.sig->l1AmMixExternalAudioReq.enableExtAudio = onoff; /* TRUE : ABB power ON during sleep, FALSE : ABB power OFF during sleep */
	BT_DEBUG(("\x1b[31m [BT] ============> BtSendAbbPowerOnReq() : %s \x1b[0m", onoff?"ABB power on during sleep":"ABB power down during sleep"));
	KiSendSignal(L1AM_TASK_ID, &sendSignal);    
}

#if defined(LGE_BRCM_BLUETOOTH)
/****************************************************************************
** UART Flow Control(Broadcom only)
****************************************************************************/
void BtSetRTS(void)
{
	//BT_DEBUG(("BtSetRTS LOW"));
	PdGpioAssertLine(M_DLGpioLine(GPIO_BT_UART_RTS));
}

void BtClearRTS(void)
{
	//BT_DEBUG(("BtClearRTS HIGH"));
	PdGpioDeassertLine(M_DLGpioLine(GPIO_BT_UART_RTS));
}

Boolean BtGetCTS(void) /* True : Low, False : High */
{
#if defined(LGE_LEMANS_BLUETOOTH)
	return (((M_DlGdReadEGSPPort(EGSPB, EGSP_PDATA_SET) & 0x1000)) ? 0:1);	/* HW Flow Control for CTS line (not GPIO)*/
#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
	return PdGpioReadInputLine(M_DLGpioLine(GPIO_BT_UART_CTS));
#endif
}

Boolean BtGetRTS(void)
{
	return PdGpioReadOutputLine(M_DLGpioLine(GPIO_BT_UART_RTS));
}

void BtFlowControlInit(void)
{
#if defined(LGE_LEMANS_BLUETOOTH)

#elif defined(LGE_ATLAS_BLUETOOTH)

	BT_UscRouteOutput(4,9);	// set USC[4] -> GPIO29(ATLAS RTS output), (2048 CTS)	/* BT_L1_KIMSANGJIN_061227  noti_010310*/
	BT_UscRouteInput(5,9);    // set USC[5] -> GPIO30(ATLAS CTS input),   (2048 RTS)	/* BT_L1_KIMSANGJIN_061227  noti_010310*/

#elif defined(LGE_ATLAS_2H_BLUETOOTH)

#if !defined(BT_RTS_CTS_GPIO)
	BT_UscRouteOutput(4,9);	// set USC[4] -> GPIO29(ATLAS RTS output), (2048 CTS)	/* BT_L1_KIMSANGJIN_061227  noti_011011*/
	BT_UscRouteInput(5,9);    // set USC[5] -> GPIO30(ATLAS CTS input),   (2048 RTS)	/* BT_L1_KIMSANGJIN_061227  noti_011011*/
#endif	

#else

	BT_DEBUG(("To do (Not Define)"));

#endif

#if defined(UART_HW_RTS_TEST) /* JHS2 15Aug2006 for LeMans */
	PdGpioConfigure(GPIO_BT_UART_RTS_HW);
#else
	PdGpioConfigure(GPIO_BT_UART_RTS);

	BtSetRTS();	// set RTS=0: this triggers initialization of bluetooth baseband
#endif	
	PdGpioConfigure(GPIO_BT_UART_CTS);

	/*
	 * time dealy is needed for completion of initialization of bluetooth baseband
	 * it takes about 3.128ms in GS3
	 */
	DelayMilliseconds(5);

}
#endif /* LGE_BRCM_BLUETOOTH */

void BtNotifyCallWait(void)
{
	BT_DEBUG((" BtNotifyCallWait"));
}

/****************************************************************************
** PCM Control
****************************************************************************/
#if defined(LGE_LEMANS_BLUETOOTH)
void BtAudioRoutingChangeReq(Boolean isActivated)
{
      SignalBuffer signal = kiNullBuffer;

  
	if(isActivated==TRUE)
	{
	     BtFlag_SetAudioPathPhone(FALSE);
	}
	else
	{
	     BtFlag_SetAudioPathPhone(TRUE);
	}


#if 1
	KiCreateSignal (SIG_L1AM_ROUTING_CHANGE_REQ,
	sizeof (L1AmRoutingChangeReq),
	&signal);

	signal.sig->l1AmRoutingChangeReq.routingStates = L1AM_STATE_BLUETOOTH;
	signal.sig->l1AmRoutingChangeReq.isActivated   = isActivated;
	KiSendSignal (L1AM_TASK_ID, &signal);


#else
	KiCreateSignal (SIG_L1AM_ROUTING_CHANGE_REQ,
	sizeof (L1AmRoutingChangeReq),
	&signal);

	/* Use noise reduction and echo cancellation? */
	if (abBtAuContext_p->enableNrec)
	{
	signal.sig->l1AmRoutingChangeReq.routingStates = L1AM_STATE_BLUETOOTH;
	}
	else /* Disable noise reduction and echo cancellation for this device. */
	{
	signal.sig->l1AmRoutingChangeReq.routingStates = (L1AM_STATE_BLUETOOTH | L1AM_STATE_DISABLE_EC_NS);	
	}
	signal.sig->l1AmRoutingChangeReq.isActivated   = isActivated;
	KiSendSignal (L1AM_TASK_ID, &signal);
#endif

}
#endif

static void BtPcmInit(void)
{
#if defined(LGE_LEMANS_BLUETOOTH)

	/* Bluetooth PCM on eGSPc */
	DlEgspConfigurePcmInterface(EGSPC);	
	PdGpioConfigure(GPIO_BT_PCM_CLK);
	PdGpioConfigure(GPIO_BT_PCM_RX);
	PdGpioConfigure(GPIO_BT_PCM_SYNC);
	PdGpioConfigure(GPIO_BT_PCM_TX);
	
#elif defined(LGE_ATLAS_BLUETOOTH)

#if defined(LGE_BRCM_BLUETOOTH)
	PdGpioConfigure(GPIO_BT_PCM_EN);
#endif

#elif defined(LGE_ATLAS_2H_BLUETOOTH)

#if defined(LGE_BRCM_BLUETOOTH)
	PdGpioConfigure(GPIO_BT_PCM_EN);
#endif

#else

	BT_DEBUG(("To do (Not Define)"));

#endif
}

extern Boolean isbtmakecall; /*BT_COMMON_KIMSANGJIN_080125 noti_011116*/

#if defined(LGE_LEMANS_BLUETOOTH)
static void BtPcmDeconfig(void)
{
	DlEgspDeconfigurePcmInterface(EGSPC);
}
#endif

#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
 void BtPcmOn(void) /* BT_COMMON_KIMSANGJIN_080102 noti_011248 Analog Switch Control For PCM  */
{
	agauSetBluetooth(TRUE);		

	if (BtGetEnablePcm() == TRUE)
{
#if defined(LGE_CSR_BLUETOOTH)
	BccmdSetPio(EXTERNAL_TASK_MASK, 0xEEEE, 0x0200); /* Sean_070824: set PIO9 of BC to high */ /* Sean_071009: change seq. num. */
#endif

#if defined(LGE_BRCM_BLUETOOTH)
	DLGpioAssertLine(M_DLGpioLine(GPIO_BT_PCM_EN)); /* PCM_EN = 1 */ 
#endif
}
       else
       {
              BT_DEBUG(("BtPcmOn() but BtGetEnablePcm() was false"));
       }
}

static void BtPcmOff(void) /* Analog Switch Control For PCM  */
{
#if defined(LGE_CSR_BLUETOOTH)
	BccmdSetPio(EXTERNAL_TASK_MASK, 0xDDDD, 0x0000); /* Sean_070824: set PIO9 of BC to low */ /* Sean_071009: change seq. num. */
#endif

#if defined(LGE_BRCM_BLUETOOTH)
	DLGpioDeassertLine(M_DLGpioLine(GPIO_BT_PCM_EN));
#endif
}
#endif

void BtDummyStopPCM(void)
{
	if (BtGetEnablePcm() == TRUE)
	{
		/* To Do More */
	}
}

void BtStopPCM(void)
{
#if defined(LGE_LEMANS_BLUETOOTH)

	/* Clcok : 128KHz - Frame Sync : 8KHz */
	BT_DEBUG(("[BLUETOOTH] BtStopPCM()"));
	if(BtFlag_IsAudioOpen() == TRUE
#if defined(LGE_L1_FM) 		
		&& (LGE_fm_is_enabled() == FALSE)
#endif
	)
	{
		BtAudioRoutingChangeReq(FALSE);
		BtFlag_SetAudioOpen(FALSE);
		//agauSetBluetooth(FALSE); /* Tiburona_071029 */		
#if 0 /*Tiburona_071029 : This function cannot use in Audio Manager v2. Check the dlAuTyp_GetAudioAcqDeviceId() in auddr_typhoon.c */
		DlDspSelectAudioAcqDevice (AU_DATA_ACQ_DEVICE_AD65XX);
		BT_DEBUG(("\x1b[33m [BLUETOOTH] set DlDspSelectAudioAcqDevice (AU_DATA_ACQ_DEVICE_AD65XX) \x1b[0m"));
#endif
	}
	else
	{
#if defined(LGE_L1_FM)	
		if(LGE_fm_is_enabled()==TRUE)
		{
			BT_DEBUG(("\x1b[33m FM Radio is ENABLE.\x1b[0m"));
		}
		else
#endif			
		{
		BT_DEBUG((""));
		BT_DEBUG(("\x1b[33m Already PCM Closed......Check Who calling this function....> \x1b[0m"));
	}
	}
	
#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH) /*!= LGE_LEMANS_BLUETOOTH*/

	if(BtFlag_IsAudioOpen() == TRUE
#if defined(LGE_L1_FM) 		
		&& (LGE_fm_is_enabled() == FALSE)
#endif
	)
	{
		/* Clcok : 256KHz - Frame Sync : 8KHz */
		lgeBtStopTimer (BT_TIMER_TYPE_BT_PCM_TIMER); /*BT_COMMON_KIMSANGJIN_080102 noti_011248*/
		BtFlag_SetAudioOpen(FALSE);
		if (BtGetEnablePcm() == TRUE)
		{
			agauSetBluetooth(FALSE);	
			DefaultUscRoutingForBT();
			DataUscRoutingForBT();
			BtPcmOff();
#if defined(LGE_BRCM_BLUETOOTH)
			BtFlowControlInit();
#endif
		}
		BT_DEBUG((""));
		BT_DEBUG(("BtStopPCM()"));
	}
	else
	{
#if defined(LGE_L1_FM)	
		if(LGE_fm_is_enabled()==TRUE)
		{
			BT_DEBUG(("\x1b[33m FM Radio is ENABLE.\x1b[0m"));
		}
		else
#endif			
		{
			BT_DEBUG((""));
			BT_DEBUG(("\x1b[33m Already PCM Closed......Check Who calling this function....> \x1b[0m"));
		}		
	}
	
#else

	BT_DEBUG(("To do (Not Define)"));

#endif
}

void BtStartMasterModePCM(void)	/* Host : Master, BT : Slave */
{
#if defined(LGE_LEMANS_BLUETOOTH)	/* Clcok : 128KHz - Frame Sync : 8KHz */ 

	BT_DEBUG((""));
	BT_DEBUG(("[BLUETOOTH] BtStartMasterModePCM()"));
	if(BtFlag_IsAudioOpen() == FALSE 
#if defined(LGE_L1_FM) 		
		&& (LGE_fm_is_enabled() == FALSE)
#endif		
	)
	{
		BtFlag_SetAudioOpen(TRUE);
		BtAudioRoutingChangeReq(TRUE);
		//agauSetBluetooth(TRUE); /* Tiburona_071029 */		
#if 0 /*Tiburona_071029 : This function cannot use in Audio Manager v2. Check the dlAuTyp_GetAudioAcqDeviceId() in auddr_typhoon.c */		
		DlDspSelectAudioAcqDevice (AU_DATA_ACQ_DEVICE_BLUETOOTH);	
		BT_DEBUG(("\x1b[33m [BLUETOOTH] set DlDspSelectAudioAcqDevice (AU_DATA_ACQ_DEVICE_BLUETOOTH) \x1b[0m "));	
#endif
	}
	else
	{
#if defined(LGE_L1_FM)	
		if(LGE_fm_is_enabled()==TRUE)
		{
			BT_DEBUG(("\x1b[33m FM Radio is ENABLE.\x1b[0m"));
		}
		else
#endif			
		{
		BT_DEBUG((""));
		BT_DEBUG(("\x1b[33m Already PCM open......Check Who calling this function....> \x1b[0m"));
	}
	}
	
#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH) /* Clcok : 256KHz - Frame Sync : 16KHz */ 
	if(BtFlag_IsAudioOpen() == FALSE 
#if defined(LGE_L1_FM) 		
		&& (LGE_fm_is_enabled() == FALSE)
#endif		
	)
	{
		BT_DEBUG((""));
		BT_DEBUG(("BtStartMasterModePCM()"));	
		BtFlag_SetAudioOpen(TRUE);
		if (BtGetEnablePcm() == TRUE)
		{
			/***************************************************************
			 <Tip> 
			 1. PCM_EN (BtPcmOn()) pin is controled at BT lib , 
			     reason why after check the PCM_EN BX determine the PCM configuration
			     
			 2. Replace the USC routing API to Local API
			     - DlCfUscRouting( USC_CF_HANDSFREE ) -> AudioUscRoutingForBT();
			     - DlCfUscRouting( USC_CF_DEFAULT ) -> DefaultUscRoutingForBT();
			      -DlCfUscRouting( USC_CF_DATA ) -> DataUscRoutingForBT();
			 ***************************************************************/		
			/*BT_COMMON_KIMSANGJIN_080125 noti_011116*/	
			if(isbtmakecall == TRUE) /*If we do not use this flag , incoming call receiving is too late*/
			{
			       isbtmakecall =FALSE;
			AudioUscRoutingForBT();  		
			DefaultUscRoutingForBT();
			DataUscRoutingForBT();
			StartBtPCMTimer();
		}
		else
		{
                          /*********************************************************************************************
                            If the incoming call processing or call conversation state was happen, we start PCM routing right now
                            <Reason>
                              1. audio path was allocate at the phone side, even though it was connected with bluetooth headset.
                              2. it takes a long time to convert a audio path (to bt headset)
                           **********************************************************************************************/
                           AudioUscRoutingForBT();  	
			}
		}
		else
		{
			StartBtPCMTimer();
		}
	}
	else
	{
#if defined(LGE_L1_FM)	
		if(LGE_fm_is_enabled()==TRUE)
		{
			BT_DEBUG(("\x1b[33m FM Radio is ENABLE.\x1b[0m"));
		}
		else
#endif			
		{
		BT_DEBUG((""));
			BT_DEBUG(("\x1b[33m Already PCM open......Check Who calling this function....> \x1b[0m"));
		}
	}
	
#else

	BT_DEBUG(("To do (Not Define)"));

#endif

}

void BtStartSlaveModePCM(void)	/* Host : Slave, BT : Master */
{
#if defined(LGE_LEMANS_BLUETOOTH)

	BT_DEBUG(("BtStartSlaveModePCM() LeMans have to DO"));

#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH) /*!= LGE_LEMANS_BLUETOOTH*/

	/* Clcok : 128KHz - Frame Sync : 8KHz */
	DlCfUscRouting( USC_CF_HANDSFREE_EXTCLK );

#else

	BT_DEBUG(("To do (Not Define)"));

#endif
}

#if defined(LGE_BRCM_BLUETOOTH)
/****************************************************************************
** Bluetooth Chip Control For Wakeup & Interrupt
****************************************************************************/
static void BtWakeUpInit(void)
{
	PdGpioConfigure(GPIO_BT_WAKEUP);
	PdGpioDeassertLine(M_DLGpioLine(GPIO_BT_WAKEUP));
}

void BtWakeUpOn(void)
{
    	PdGpioAssertLine(M_DLGpioLine(GPIO_BT_WAKEUP));
}

void BtWakeUpOff(void)
{
	PdGpioDeassertLine(M_DLGpioLine(GPIO_BT_WAKEUP));
}
#endif /* LGE_BRCM_BLUETOOTH */

/****************************************************************************
** Bluetooth Chip Control For BB(Host) Interrupt
****************************************************************************/
static void BtInterruptEnable(void)
{
#if 0
	PdGpioIntSetUp enableInt;
#endif

	BT_DEBUG(("[BT INT] BtInterruptEnable()"));
#if 1
#if defined(LGE_BRCM_BLUETOOTH)
	PdGpioConfigure(GPIO_BT_INT);
	PdGpioSendGpioChangeInd(DM_GPIOREF_BT_INT, PdGpioReadInputLine(M_DLGpioLine(GPIO_BT_INT)), DM_TASK_ID, FALSE);
	PdGpioIntConfigAndEnable(GPIO_INT_BT_DBB_DET);
#endif /* LGE_BRCM_BLUETOOTH */

#if defined(LGE_CSR_BLUETOOTH)
#if defined(LGE_ATLAS_BLUETOOTH)
#if defined (LGE_L1_ABB_INT_FOR_GPIO) /* KP230_Tiburona_070917 */	/* ABB interrupt is used for Bluetooth */
	PdGpioConfigure(GPIO_ABB_INTERRUPT);
	PdGpioSendGpioChangeInd(DM_GPIOREF_ABB_INT, PdGpioReadInputLine(M_DLGpioLine(GPIO_ABB_INTERRUPT)), DM_TASK_ID, FALSE);
	PdGpioIntConfigAndEnable(GPIO_INT_ABB_INTERRUPT);
#endif	/* LGE_L1_ABB_INT_FOR_GPIO */
#endif /* LGE_ATLAS_BLUETOOTH */
#endif /* LGE_CSR_BLUETOOTH */
#else
	PdGpioConfigure(GPIO_BT_INT);
	PdGpioSendGpioChangeInd(DM_GPIOREF_BT_INT, PdGpioReadInputLine(M_DLGpioLine(GPIO_BT_INT)), DM_TASK_ID, FALSE);
#if defined(LGE_LEMANS_BLUETOOTH) && defined(UPGRADE_500_PLATFORM)
	enableInt.gpioLine        	= GPIO_55;
	enableInt.triggerType     	= TRIGGER_BOTH_EDGES;
	enableInt.triggerLevel    	= TRUE;
	enableInt.deBouncePeriod  	= 1;
	PdGpioIntEnable(&enableInt);
#elif defined(LGE_ATLAS_BLUETOOTH) && defined(UPGRADE_430_PLATFORM)
	enableInt.intRef = GPIO_8_LEVEL_INT;
	enableInt.triggerType	 = TRIGGER_LEVEL;
	enableInt.triggerLevel = TRUE;
	enableInt.deBouncePeriod =1;
	DlGpioIntEnable(&enableInt);
#elif defined(LGE_ATLAS_2H_BLUETOOTH) && defined(UPGRADE_430_PLATFORM)
	enableInt.gpioLine        = GPIO_36;
	enableInt.intRef          = GPIO_INT_12;
	enableInt.triggerType     = TRIGGER_BOTH_EDGES;
	enableInt.triggerLevel    = TRUE;
	enableInt.deBouncePeriod  = 1;
	PdGpioIntEnable(&enableInt);
#endif
#endif
}

static void BtInterruptDisable(void)
{
	BT_DEBUG(("[BT INT] BtInterruptDisable()"));
#if 1
#if defined(LGE_BRCM_BLUETOOTH)
  	PdGpioIntDisable(M_DLGpioIrqGetRegBit(GPIO_INT_BT_DBB_DET));
#endif /* LGE_BRCM_BLUETOOTH */

#if defined(LGE_CSR_BLUETOOTH)
#if defined (LGE_ATLAS_BLUETOOTH)
#if defined (LGE_L1_ABB_INT_FOR_GPIO) /* KP230_Tiburona_070917 */	/* ABB interrupt is used for Bluetooth */
    	PdGpioIntDisable(M_DLGpioIrqGetRegBit(GPIO_INT_ABB_INTERRUPT));

    	
/* BT_COMMON_KIMSANGJIN_071220 noti_011244*/
	PdGpioConfigure(GPIO_BT_INT_DISABLE);
	PdGpioDeassertLine(M_DLGpioLine(GPIO_BT_INT_DISABLE));
/* end of BT_COMMON_KIMSANGJIN_071220 */
#endif	/* LGE_L1_ABB_INT_FOR_GPIO */
#endif /* LGE_ATLAS_BLUETOOTH */
#endif /* LGE_CSR_BLUETOOTH */
#else
#if defined (LGE_LEMANS_BLUETOOTH)
  	PdGpioIntDisable(M_DLGpioIrqGetRegBit(GPIO_INT_BT_DBB_DET));
#elif defined(LGE_ATLAS_BLUETOOTH)
	DlGpioIntDisable(GPIO_8_REG_BIT);
#elif defined(LGE_ATLAS_2H_BLUETOOTH)
    	DlGpioIntDisable(M_DLGpioIrqGetRegBit(GPIO_INT_BT_DBB_DET));
#endif
#endif
}
 
/****************************************************************************
** Bluetooth Chip Control For LDO Power
****************************************************************************/
static void BtPowerOn(void)
{
	PdGpioConfigure(GPIO_BT_LDO_EN);
	PdGpioAssertLine(M_DLGpioLine(GPIO_BT_LDO_EN)); 
}

static void BtPowerOff(void)
{
	PdGpioDeassertLine(M_DLGpioLine(GPIO_BT_LDO_EN));
}

/****************************************************************************
** Bluetooth Chip Control For Chip Reset
****************************************************************************/
static void BtResetOn(void)
{
/* BT_COMMON_KIMSANGJIN_071004 noti_011219 */ 
#if defined(LGE_ATLAS_BLUETOOTH)
	PdGpoConfigure(GPIO_BT_RESET);
#else
	PdGpioConfigure(GPIO_BT_RESET);
#endif /*End of LGE_ATLAS_BLUETOOTH*/
/* end of BT_COMMON_KIMSANGJIN_071004 */

	PdGpioAssertLine(M_DLGpioLine(GPIO_BT_RESET));
	/* Have to set 2.8V level and got a enough time to initialise the UART Configuration */	
	DelayMilliseconds(100);
	
	PdGpioDeassertLine(M_DLGpioLine(GPIO_BT_RESET)); 
	DelayMilliseconds(50);	
}

static void BtResetOff(void)
{
	PdGpioDeassertLine(M_DLGpioLine(GPIO_BT_RESET));
}

#if defined(LGE_BRCM_BLUETOOTH)
/****************************************************************************
** Bluetooth Chip Control For Sleep Clock (Broadcom only)
****************************************************************************/
static void BtSleepClkOn(void)  /*32KHz Sleep Clock Enable */
{
	BT_DEBUG(("BtSleepClkOn() : 32KHz Sleep Clock Enable"));

#if defined(LGE_LEMANS_BLUETOOTH)

	PdGpioConfigure(GPIO_BT_32K);	/* GPIO_54 */
	*MCLK_MUXOUT = ((*MCLK_MUXOUT & 0xFF0F) | (MCLK_MUX_CLK32K << 4));
	
#elif defined(LGE_ATLAS_BLUETOOTH)

	/* set USC[6] Port Fuction = 12, Monitor[6], BT_CLKOUTMUX Bluetooth 32.768KHz Sleep Clock */
	BT_UscRouteOutput(6,12);
	(*(volatile Int16 *)(MMI_MON_MODULE_SELECT_REG) = 16);
	(*(volatile Int16 *)(MMI_MON_SELECT_REG) = 1);

#elif defined(LGE_ATLAS_2H_BLUETOOTH)

	BT_SLEEP_CLK_ON();	/* GPIO_40 */

#else

	BT_DEBUG(("To do (Not Define)"));

#endif

}

static void BtSleepClkOff(void)	/*32KHz Sleep Clock Disable */
{
	BT_DEBUG(("BtSleepClkOff() : 32KHz Sleep Clock Disable"));

#if defined(LGE_LEMANS_BLUETOOTH)

	*MCLK_MUXOUT &= 0xFF0F;
	PdGpioConfigure(GPIO_BT_32K_UNUSED);	/* GPIO_54 */

#elif defined(LGE_ATLAS_BLUETOOTH)

	(*(volatile Int16 *)(MMI_MON_MODULE_SELECT_REG) = 0);
	(*(volatile Int16 *)(MMI_MON_SELECT_REG) = 0);

#elif defined(LGE_ATLAS_2H_BLUETOOTH)

	BT_SLEEP_CLK_OFF();
	PdGpioConfigure(GPIO_BT_32K_UNUSED);	/* GPIO_40 */

#else

	BT_DEBUG(("To do (Not Define)"));

#endif
}
#endif /* LGE_BRCM_BLUETOOTH */

static void BtDeconfig(void)
{

	BT_DEBUG(("BtDeconfig() : I/O disable"));

#if defined(LGE_BRCM_BLUETOOTH)
	PdGpioConfigure(GPIO_BT_WAKEUP_UNUSED);
	PdGpioConfigure(GPIO_BT_INT_UNUSED);
#endif /* LGE_BRCM_BLUETOOTH */

	PdGpioConfigure(GPIO_BT_UART_TX_UNUSED);
	PdGpioConfigure(GPIO_BT_UART_RX_UNUSED);
#if defined(LGE_BRCM_BLUETOOTH)
	PdGpioConfigure(GPIO_BT_UART_RTS_UNUSED);
	PdGpioConfigure(GPIO_BT_UART_CTS_UNUSED);
#endif /* LGE_BRCM_BLUETOOTH */

#if defined(LGE_LEMANS_BLUETOOTH)

	BtPcmDeconfig();
	PdGpioConfigure(GPIO_BT_PCM_CLK_UNUSED);
	PdGpioConfigure(GPIO_BT_PCM_RX_UNUSED);
	PdGpioConfigure(GPIO_BT_PCM_SYNC_UNUSED);
	PdGpioConfigure(GPIO_BT_PCM_TX_UNUSED);
	
#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)

#if defined(LGE_BRCM_BLUETOOTH)
	PdGpioConfigure(GPIO_BT_PCM_EN_UNUSED);
#endif

#if 0 /* check point */
	DefaultUscRoutingForBT();				/*noti_010417*/ /* LOUIS job90005 */
	DataUscRoutingForBT(); 					/*noti_010417*/ /* LOUIS job90005 */
#endif

#else

	BT_DEBUG(("To do (Not Define)"));

#endif

#if !defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
	DelayMilliseconds(50);
	BtPortInvalidate();
#endif	
}

/****************************************************************************
* I/O Configuration For Broadcom Chip
****************************************************************************/
#if defined(LGE_BRCM_BLUETOOTH)
static void BtPowerUpConfigForBRCM(void)
{
	BT_DEBUG(("BtPowerUpConfigForBRCM() start"));

	BtSendSleepAllowedReq(FALSE);

	BtSleepClkOn();
	
	BtPowerOn();

	BtResetOn();

	BtInterruptEnable();

	BtWakeUpInit();

	BtPcmInit();

	BtFlowControlInit();
	
#if defined(GPIO_FLAG_FOR_UART_TEST)	
	BtUartErrorFlagInit();
#endif

	BT_DEBUG(("End of BtPowerUpConfigForBRCM()"));
}

static void BtPowerDownConfigForBRCM(void)
{
	BT_DEBUG(("BtPowerDownConfigForBRCM() start"));

	BtSleepClkOff();

	BtPowerOff();
	
	BtResetOff();

	BtInterruptDisable();

	BtDeconfig();
	
	BtSendSleepAllowedReq(TRUE);

	BT_DEBUG(("End of BtPowerDownConfigForBRCM()"));
}
#endif /* LGE_BRCM_BLUETOOTH */

/****************************************************************************
* I/O Configuration For CSR Chip
****************************************************************************/
#if defined(LGE_CSR_BLUETOOTH)
static void BtPowerUpConfigForCSR(void)
{
	BT_DEBUG(("BtPowerUpConfigForCSR() start"));

	BtPowerOn();

	BtResetOn();

	BtInterruptEnable();
		
	BtPcmInit();
	
	BT_DEBUG(("End of BtPowerUpConfigForCSR()"));
}

static void BtPowerDownConfigForCSR(void)
{
	BT_DEBUG(("BtPowerDownConfigForCSR() start"));

	BtPowerOff();
	
	BtResetOff();

	BtInterruptDisable();	

	BtDeconfig();
	
	BT_DEBUG(("End of BtPowerDownConfigForCSR()"));
}
#endif /* LGE_CSR_BLUETOOTH */

/****************************************************************************
* Power Up/Down For BT Chip
****************************************************************************/
void BtPowerUp(void)
{
    	BT_DEBUG(("Start BtPowerUp()"));

#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
	BtFlag_SetUscLock(TRUE); /*noti_010434*/
#endif

	BtFlag_Init();

#if 1 /* check */
	 bt_os_startup(); 
#else
	if(BtFlag_IsRunTask() == FALSE)   bt_os_startup(); 
#endif

#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
#if defined(LGE_LEMANS_BLUETOOTH)
#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
	BluetoothDteOnoff(TRUE);
#endif
#endif /* LGE_L1_SINGLE_UART */

#if defined(LGE_BRCM_BLUETOOTH)
	BtPowerUpConfigForBRCM();
	BT_DEBUG(("[BRCM] BootEntry() start"));
	BootEntry();
#endif /* LGE_BRCM_BLUETOOTH */
	
#if defined(LGE_CSR_BLUETOOTH)
	BtFlag_SetEnabled(TRUE);	
	BtPowerUpConfigForCSR();
	BT_DEBUG(("[CSR] Boot() start"));
	bcx_change_into_active(); /* Sean_070823: change API name from BtActivateCsrTask() to bcx_change_into_active() */
#endif /*LGE_CSR_BLUETOOTH */

	BT_DEBUG(("End of BtPowerUp()"));
}

void BtPowerDown(void)
{
#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
	BtFlag_SetUscLock(FALSE); /*noti_010434*/
#endif

	bt_os_shutdown(); 

#if defined(LGE_BRCM_BLUETOOTH)
	BtPowerDownConfigForBRCM();
	stopBTTimer(); /* check */
#endif /* LGE_BRCM_BLUETOOTH */
	
#if defined(LGE_CSR_BLUETOOTH )
	BtPowerDownConfigForCSR();
	/* To do : to diable BCHS stack if it is.*/
	bcx_change_into_idle(); /* Sean_070823: change API name from BtDeactivateCsrTask() to bcx_change_into_idle() */
#endif /*LGE_CSR_BLUETOOTH */

#if defined(LGE_L1_SINGLE_UART) /* TIBURONA_070821 */
#if defined(LGE_LEMANS_BLUETOOTH)
	BtPortInvalidate();
#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
	BluetoothDteOnoff(FALSE);
#endif
#endif /* LGE_L1_SINGLE_UART */

	BT_DEBUG(("End of BtPowerDown()"));
}



#endif /* LGE_L1_BLUETOOTH */
