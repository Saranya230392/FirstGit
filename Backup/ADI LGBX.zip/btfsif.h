/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfsif.h
 
DESCRIPTION:	     Utility & File System Interface Functions Definition for Bluetooth Stack

History:
2006/08/28  $Revision: 1.0 $  :: File System Interface Functions Definition for Bluetooth  
			 			     $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/
#if !defined(BTFSIF_H)
#define BTFSIF_H

#if defined(LGE_L1_BLUETOOTH)
#if defined(LGE_TTPCOM_FS_BLUETOOTH)
#ifndef UPGRADE_FSYSTEM
#define UPGRADE_FSYSTEM
#endif /*UPGRADE_FSYSTEM*/
#endif /*LGE_TTPCOM_FS_BLUETOOTH*/

//#define  FS_OVERWRITE_EN      1 

/****************************************************************************
* Include Files
****************************************************************************/
#include <fs_io.h>
#include <Dirent.h>
#include <l1al_sig.h>
#include <ut_ucs2.h>
#if defined(LGE_APEX_FS_BLUETOOTH)
#include <abfs_typ.h>
#endif

/****************************************************************************
* Mainfest Constants / Defines
****************************************************************************/
#define BT_FS_FAIL				(-1)

#if defined( LGE_FS_SUPPORT_LONG_FILE_NAME )
#define StrCopy		utStrcpyUcs2
#define StrnCopy		utStrncpyUcs2
#define StrSprintf		utSprintfUcs2
#define StrLength		utStrlenUcs2
#define StrCompare	utStrcmpUcs2
#define StrnCompare	utStrncmpUcs2
#define StrCat			utStrcatUcs2
#else
#define StrCopy		strcpy
#define StrnCopy		strncpy
#define StrSprintf		sprintf
#define StrLength		strlen
#define StrCompare	strcmp
#define StrnCompare	strncmp
#define StrCat			strcat
#endif

/****************************************************************************
* Type Definitions
****************************************************************************/
typedef struct FsdirTag
{
  SignedInt32 fd;            /*File descriptor for open directory file*/
  struct  wdirent  thisDirent; /*Structure to hold current entries name*/
  Int16   entryNumber;        /*Current entry number we are on */
} Fsdir;

#if defined(LGE_APEX_FS_BLUETOOTH)
typedef void FileID;
typedef Int32 DirID;
typedef void FileLIST;

typedef struct BtApexFsReadDirTag
{
	Boolean		nameTruncated;
	FilePath      	filePathString;
	Stat          	fsStat;  
} BtApexFsReadDir;
#endif

/****************************************************************************
* Exported Variables
****************************************************************************/

/****************************************************************************
* Macros
****************************************************************************/
/* BT_COMMON_KIMSANGJIN_070402 noti_011044 */
#define FILE_ALREADY_EXIST    -10
/****************************************************************************
* Global Function Prototypes
****************************************************************************/
extern void BTFS_INIT_CS(void);

/* GX_LEEJINBAEK_070309 */
extern Int16 *BtutExpandStrcpy(Int16  *strDst_p, Char *strSrc_p);
extern Int16 *BtconvertFileNameToUcs2 ( char *fileName );
extern void BtconvertFileNameToChar(Int16 *Srcstr,char *Dststr);
/* end of GX_LEEJINBAEK_070309 */

#if defined(LGE_APEX_FS_BLUETOOTH)

extern FileID *Btfs_Open(char *fileName, char *mode);
extern SignedInt32 Btfs_Read (FileID *file_p, void *buf, Int32 len);
extern SignedInt32 Btfs_Write(FileID *file_p, void *buf, Int32 len);
extern SignedInt32 Btfs_Close(FileID *file_p);
extern SignedInt32 Btfs_Stat(char *fileName, Stat *statBuf_p);
extern SignedInt32 Btfs_FStat(FileID *file_p, Stat *statBuf_p);
extern SignedInt32 Btfs_Ftell(FileID *file_p);
extern SignedInt32 Btfs_diskinfo_free_space(char driverLetter);
extern SignedInt32 Btfs_get_num_of_entry_in_dir(char *dirPathNamePtr, char *fileNamePtr);
extern FileLIST *Btfs_get_file_list(Int16 numOfEntryRequested, Int16 startingIndexOfEntry, char *dirPathNamePtr, char *fileNamePtr);
extern SignedInt32 Btfs_Remove(char *fileName);
extern SignedInt32 Btfs_Rename(char *oldName, char *newName);
extern SignedInt32 Btfs_seek(FileID *file_p, Int8 offset, FseekDir fromwhere);
extern Boolean Btfs_exists(char *fileName);
extern SignedInt32 Btfs_Status(AbfsMountInfo *info_p);
extern BtApexFsReadDir *Btfs_Readdir(DirID dirRef);
extern DirID Btfs_Opendir(char *dirName);
extern SignedInt32 Btfs_Closedir (DirID dirRef);
extern SignedInt32 Btfs_Rewinddir(DirID dirRef);
extern SignedInt32 Btfs_Rmdir(char *path);
extern SignedInt32 Btfs_Mkdir(char *path);
extern Boolean Btfs_Isdir(char *path);
extern SignedInt32 Btfs_Getfilesize(int fid, char *filename);

#else /* LGE_APEX_FS_BLUETOOTH */

extern int Btfs_Open(char *fileName, char *mode);
extern int Btfs_Read ( int handle, void *buf, Int32 len );
extern int Btfs_Write ( int handle, void *buf, Int32 len );
extern int Btfs_Close ( int handle );
extern int Btfs_Stat (char *fileName, Stat *statBuf_p);
extern Int32 Btfs_Statistics(char *deviceLabel);
extern int Btfs_Inform ( char *fileName, FileInform *fileInform); /*noti_011019*/ 

int Btfs_Chmod ( char *fileName, char *mode);
extern int Btfs_Remove ( char *fileName );
extern int Btfs_Rename( char *oldName, char *newName);
extern int Btfs_seek(int handle, int offset, Int32 fromwhere);
extern Boolean Btfs_exists(char *fileName);

 #if defined(LGE_TTPCOM_FS_BLUETOOTH)	
 extern struct dirent * Btfs_Readdir(DIR *dir_p);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
extern FileInform *Btfs_Readdir(DirId dir_p);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
extern FileInform *Btfs_Readdir(DirId dir_p);
#endif

#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
extern DIR *Btfs_Opendir(const char *dirname_p);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
extern DirId Btfs_Opendir( char *dirname_p);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
extern DirId Btfs_Opendir( char *dirname_p);
#endif


#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
 int Btfs_Closedir (DIR *dir_p);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
int Btfs_Closedir (DirId dir_p);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
int Btfs_Closedir (DirId dir_p);
#endif

 #if defined(LGE_TTPCOM_FS_BLUETOOTH)	
extern void Btfs_Rewinddir(DIR  *dir_p);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
extern void Btfs_Rewinddir(DirId  dir_p);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
extern void Btfs_Rewinddir(DirId  dir_p);
#endif

#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
extern int Btfs_Rmdir(const char *path);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
extern int Btfs_Rmdir(char *path);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
extern int Btfs_Rmdir(char *path);
#endif

#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
extern int Btfs_Mkdir(const char *path);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
extern int Btfs_Mkdir(char *path);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
extern int Btfs_Mkdir(char *path);
#endif

extern Boolean Btfs_Isdir(char *path);
extern Int32 Btfs_Getfilesize(int fid, char *filename);

#endif /* LGE_APEX_FS_BLUETOOTH */

/* GX_061216_LEEJINBAEK */
void Btfs_GetFolderNameToSave(char* folderName, char *fileName);

#endif /* LGE_L1_BLUETOOTH */

#endif /* BTFSIF_H */

