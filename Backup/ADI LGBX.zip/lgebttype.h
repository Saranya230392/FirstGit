/***************************************************************************
 * LG Electronics Copyright (c) KEVIN_BT job100503
 ***************************************************************************
 * $Id: //central/releases/Branch_release_16/tplgsm/BLUETOOTH/Btqueue.c#1 $
 * $Revision: #1 $
 * $DateTime: 2006/08/14 09:25:26 $
 ***************************************************************************
 *	File Description :
 *		Bluetooth layer 2 and layer 1 protocol elements.(bte_hcisu_task)
 *		task runs at high priority (just under timers)
 *		interrupts run at high priority
 *
 *		The BLUETOOTH protocol is taken from BTE 3.0
 *
 * $Author : KEVIN PIEN(KYUE SUP BYUN) :-), KIM SANG JIN, KANG HYUNG WOOK
 *
 **************************************************************************/

#if !defined ( LGEBTTYPE_H )
#define LGEBTTYPE_H

#if defined(LGE_L1_BLUETOOTH) || defined(LGE_MMI_BLUETOOTH)
//***LGE_L1_BLUETOOTH should be defined in Phone side.

#if defined (LGBX_INCLUDE)
#include "Sys_LGBX.h"
#else
#include "afbt_sys.h"	/*If start a compile without LG BX, we shoud open below header file(afbt_sys.h)*/
#endif /*LGBX_INCLUDE*/

/****************************************************************************
* Include Files
****************************************************************************/

/****************************************************************************
* Mainfest Constants / Defines
****************************************************************************/

/****************************************************************************
* Type Definitions
****************************************************************************/
#define BT_NAME_SIZE		32
#define BT_ADDRESS_SIZE 	6
#define BT_PINCODE_SIZE 	16

/* BT_L1_KIMSANGJIN_061017 */
#define LGADI_BD_ADDR_LEN   6
#define LGADI_PASSKEY_LEN	16
#define LGADI_LINKKEY_LEN	16
#define LGADI_MAX_BT_DEVICE 16
#define LGADI_BD_NAME_LEN	32


/*Registration about the useful function*/
#define BT_COPY_BD_NAME(a, b) 		        memcpy(a, b, LGBX_BD_NAME_LEN) /*noti_011098*/
#define BT_COPY_BD_NAME_AG(a, b) 	        memcpy(a, b, sizeof(AgCharCode)*(LGBX_BD_NAME_LEN)) /*noti_011098*/
#define BT_COPY_BD_ADDR(a, b)		        memcpy(a, b, sizeof(LGBX_BD_ADDR_TYPE)) /*noti_010100*/
#define BT_COPY_PINCODE(a, b)		        memcpy(a, b, LGBX_PINCODE_LEN+1)
#define BT_COPY_DEV_INFO(a, b)		        memcpy(a, b, sizeof(LGBX_DEVICEINFO_TYPE))
#define BT_COPY_LINKKEY(a, b)		        memcpy(a, b, LGBX_LINKKEY_LEN)
#define BT_COPY_USERID(a, b)		        /*memcpy(a, b, MMI_USER_ID_SIZE+1) */
#define BT_CMP_BD_ADDR(pDst,pSrc)       ( (pDst)[0]==(pSrc)[0] && (pDst)[1]==(pSrc)[1] && (pDst)[2]==(pSrc)[2] && (pDst)[3]==(pSrc)[3] && (pDst)[4]==(pSrc)[4] && (pDst)[5]==(pSrc)[5] )

typedef enum BTPowerTypeTag
{	
	BT_POWER_OFF,
	BT_POWER_ON,
	BT_POWER_NUMS
}
BTPowerType;

typedef enum BTVisibilityTypeTag
{	
	BT_VISIBILITY_HIDDEN,
	BT_VISIBILITY_SHOW_ALL,
	BT_VISIBILITY_NUMS
}
BTVisibilityType;

typedef enum BTAuthenticateTypeTag
{	
	BT_AUTH_NO,
	BT_AUTH_USER,
	BT_AUTH_NUMS
}
BTAuthenticateType;

typedef enum BTProfilesTypeTag
{	
	BT_PROFILE_HEADSET,
/* BT_L1_KIMSANGJIN_060821 */
	BT_PROFILE_HANDSFREE,	
	BT_PROFILE_A2DP,
	BT_PROFILE_SERIAL_PORT_LOOP,
	BT_PROFILE_SERIAL_PORT,
/* KEVIN_BT job100606 for SPP & DUN */
	BT_PROFILE_SERIAL_PORT_GENIE,	
	BT_PROFILE_DIAL_UP,
	BT_PROFILE_FTP_SERVER,	
	BT_PROFILE_FTP_CLIENT,	
	BT_PROFILE_FAX, 	
	BT_PROFILE_IMAGING, 		
	BT_PROFILE_OBJECT_PUSH, 
	BT_PROFILE_SYNCHRONIZATION, 	
	BT_PROFILE_PBAP_SERVER,		// $suhui PBAP
	BT_PROFILE_NUMS
}
BTProfilesType;

typedef enum BTStatusTypeTag
{	
	BT_STATUS_FAIL,
	BT_STATUS_OK,
	BT_STATUS_NUMS
}
BTStatusType;

typedef enum BTConnectStatusTypeTag
{	
	BT_C_STATUS_NOT_CONNECTED,
	BT_C_STATUS_CONNECTING,
	BT_C_STATUS_CONNECTED,
	BT_C_STATUS_NUMS
}
BTConnectStatusType;

//BT_COMMON LEEJINBAEK 20071116 : set storage
typedef enum BTStorageTypeTag{
	BT_STORAGE_TYPE_PHONE = 0,
	BT_STORAGE_TYPE_EXTERNAL,

	NUM_OF_BT_STORAGE_TYPE
}BTStorageType;

/****************************************************************************
* Exported Variables
****************************************************************************/

/****************************************************************************
* Macros
****************************************************************************/

/****************************************************************************
* Global Function Prototypes
****************************************************************************/
#ifndef UINT8
typedef unsigned char   	UINT8;
#endif

#ifndef UINT16
typedef unsigned short		UINT16;
#endif

#ifndef UINT32
typedef unsigned long		UINT32;
#endif

#ifndef INT32
typedef signed long   		INT32;
#endif

#ifndef INT8
typedef signed char   		INT8;
#endif

#ifndef INT16
typedef signed short  		INT16;
#endif

#ifndef BOOLEAN
typedef unsigned char 		BOOLEAN;
#endif

typedef     char				Char_t ;
typedef     signed long int        	Int32_t ;
typedef     unsigned char         	UInt8_t;
typedef     unsigned short       	Uint16_t;
typedef     signed char           	Int8_t;

typedef UInt8_t LGADI_BD_ADDR_TYPE[LGADI_BD_ADDR_LEN];		   /* Device address : LGBX_BD_ADDR_LEN */
typedef UInt8_t LGADI_LINK_KEY_TYPE[LGADI_LINKKEY_LEN];	          /*finetree, 050401, link key Ÿ���� �����༭. nvdb �� ui �������� ���� ����ϵ��� ���� :LGADI_LINKKEY_LEN*/
typedef unsigned int LGADI_SERVICE_TYPE;

typedef	struct _LGADI_COD_Tag			
{
	Uint16_t	       Service;
	UInt8_t		MajorDevice;
	UInt8_t		MinorDevice;
}LGADI_COD_TYPE;  

typedef struct LGADI_GAPDB_TYPE_Tag
{
	LGADI_BD_ADDR_TYPE  BdAddr; 			                            /*��ġ�� �ּ��̴�.*/
	UInt8_t 			           DevClass;			                            /*��ġ�� device class�̴�.*/
	Uint16_t				    szName[LGADI_BD_NAME_LEN];		/*20�̶� ���ڴ� ���߿� ����, ��ġ�� �̸��̴�.*/
	Uint16_t				    szNicName[LGADI_BD_NAME_LEN];	/*20�̶� ���ڴ� ���߿� ����, ��ġ�� nick name�̴�. �ٸ� ��ġ �������� �ǹ�*/
	UInt8_t 			           bAuthorized;
	UInt8_t 			           bKeyPresent;					       /*Key�� ���� �ϴ��� �˷��ִ� flag�̴�. 1: Key�� �ǹ�, 0: Key�ǹ� ���� */
	UInt8_t 			           LinkKey[LGADI_LINKKEY_LEN];		/*Security Link Key �̴�.*/
	LGADI_SERVICE_TYPE    Services;			                            /*��ġ���� �����Ǵ� ���񽺵� (��ϵ� ���񽺵� )*/
	LGADI_COD_TYPE	    COD;                                                   /*Class of device*/
}LGADI_GAPDB_TYPE;

typedef struct LGADI_MYINFO_TYPE_Tag
{
	Int8_t	                            bPowerOn;
	Int8_t	                            Visibility;
	LGADI_GAPDB_TYPE         Myinfo;
}LGADI_MYINFO_TYPE;
/* end of BT_L1_KIMSANGJIN_061017 */

#endif /* LGE_L1_BLUETOOTH */

#endif /* LGEBTTYPE_H */

/* End Of File */

