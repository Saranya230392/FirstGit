/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfs_apex.h

DESCRIPTION:	     Functions of TTPCom File Sytem for Bluetooth

History:
**************************************************************************/

#if !defined(BTFS_APEX_H)
#define BTFS_APEX_H

#if defined(LGE_APEX_FS_BLUETOOTH)
/****************************************************************************
* Include Files
****************************************************************************/
//#include <fs_io.h>
//#include <Dirent.h>
#if !defined(BTFSIF_H)
#include "btfsif.h"
#endif

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/
/* Test Utilities(Used for verifying basic functions for File System) */
//#define	FILESYSTEM_TEST 		1

/****************************************************************************
* Type Definitions
****************************************************************************/

/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/

/****************************************************************************
* Global Variables
****************************************************************************/

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
 * 	TTPCOM File System Interface for Bluetooth
****************************************************************************/
FileID *btfs_apex_open(char *fileName, char *mode);
#if 0 /* Check */
FileID *btfs_apex_fopen(char *fileName, char *mode);
#endif
SignedInt32 btfs_apex_read(FileID *file_p, void *buf, Int32 len);
SignedInt32 btfs_apex_write(FileID *file_p, void *buf, Int32 len);
SignedInt32 btfs_apex_close(FileID *file_p);
SignedInt32 btfs_apex_stat(char *fileName, Stat *statBuf_p);
SignedInt32 btfs_apex_fstat(FileID *file_p, Stat *statBuf_p);
SignedInt32 btfs_apex_ftell(FileID *file_p);
SignedInt32 btfs_apex_diskinfo_free_space(char driverLetter);
SignedInt32 btfs_apex_get_num_of_entry_in_dir(char *dirPathNamePtr, char *fileNamePtr);
FileLIST *btfs_apex_get_file_list(Int16 numOfEntryRequested, Int16 startingIndexOfEntry, char *dirPathNamePtr, char *fileNamePtr);
SignedInt32 btfs_apex_remove(char *fileName);
SignedInt32 btfs_apex_rename(char *oldName, char *newName);
SignedInt32 btfs_apex_seek(FileID *file_p, Int8 offset, FseekDir fromwhere);
Boolean btfs_apex_exists(const char *fileName);
SignedInt32 btfs_apex_status(AbfsMountInfo *info_p);
DirID btfs_apex_opendir(char *dirName);
BtApexFsReadDir *btfs_apex_readdir(DirID dirRef);
SignedInt32 btfs_apex_closedir(DirID dirRef);
SignedInt32 btfs_apex_rewinddir(DirID dirRef);
SignedInt32 btfs_apex_rmdir(char *path);
SignedInt32 btfs_apex_mkdir(char *path);
Boolean btfs_apex_isdir(char *path);

#if defined(FILESYSTEM_TEST) /* Test Utilities(Used for verifying basic functions for File System) */
extern void apex_file_readwrite(void);
extern void apex_file_write(void);
extern void apex_get_list(void);
extern void apex_dir_make(void);
extern void apex_remove_Dirfile(void);
extern void apex_free_space(void);

extern void apex_file_readwrite_external(void);
extern void apex_file_write_external(void);
extern void apex_get_list_external(void);
extern void apex_dir_make_external(void);
extern void apex_remove_Dirfile_external(void);
extern void apex_free_space_external(void);

#endif /* Test Utilities(Used for verifying basic functions for File System) */

#endif /* LGE_APEX_FS_BLUETOOTH */

#endif /* end of */
