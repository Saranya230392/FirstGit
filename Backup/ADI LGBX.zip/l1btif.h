/*******************************************************************************

			Copyright by LG Electronics Inc.

FILE				
				L1BTIF.h 

DESCRIPTION:
				Bluetooth Module Interface & Control Functions 
	            2006/08/11  : Definition for Base Functions for BCM(BTE 3.0)
	            2006/08/14  : Merged from btutil.* to l1btif.* file from old source code 
	            2007/06/23  : Added the functions to control the BlueCore(BCHS 15.0)

History: job100502
2006/08/11 $Revision: 1.0 $  :: $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
2007/06/23 $Revision: 2.0 $  :: $ KANG HYUNG WOOK
**************************************************************************/

#if !defined(L1BTIF_H)
#define L1BTIF_H

#if defined(LGE_L1_BLUETOOTH)

/****************************************************************************
* Include Files
****************************************************************************/
#if !defined (DLSPALIF_H)
#include <dlspalif.h>
#endif

#if !defined (DLGPIO_H)
#include <dlgpio.h>
#endif

#if !defined (DLMCLK_H)
#include <dlmclk.h>	/* for MCLK_MUXOUT */
#endif

#if !defined (DLUSC_H)
#include <dlusc.h>
#endif

#if !defined (SYSTEM_H)
#include <system.h>
#endif

#if !defined (DLSPALIF_H)
#include "dlspalif.h"
#endif

#if !defined(APPLAYER_H)
#include "applayer.h"
#endif

#if !defined (LGEBTTYPE_H)
#include "Lgebttype.h"
#endif

#if !defined (DMACC_TYP_H)
#include "dmacc_typ.h"
#endif

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/
/* Register addresses */
#define BT_USC_SELLO_REGISTER			(volatile Int16 *)( USC_BASE + 0x08 )
#define BT_USC_SELHI_REGISTER			(volatile Int16 *)( USC_BASE + 0x0A )
#define BT_USC_POL_REGISTER			(volatile Int16 *)( USC_BASE + 0x0c )
#define BT_USC_ENIN_REGISTER			(volatile Int16 *)( USC_BASE + 0x10 )
#define BT_USC_INSEL_REGISTER			(volatile Int16 *)( USC_BASE + 0x0e )

/*Add a extern function*/
extern void dlDisableIrq(void);
extern void dlEnableIrq(void);

#define BtEnterCS()		                 		dlDisableIrq()
#define BtLeaveCS()		             		dlEnableIrq()

/* Set the USC SELECT port pin to the given mode from USC_Mnn_XXX */
#define BT_UscSwitchSelect(pIN,mODE) 									  \
		 if( (pIN)<4)													  \
		 {																  \
			*(BT_USC_SELLO_REGISTER) = (*(BT_USC_SELLO_REGISTER)				  \
									& ~(0x000f<<(pIN<<2)))				  \
									| ((mODE)<<((pIN)<<2)); 			  \
		 }																  \
		 else															  \
		 {																  \
			char avoidCompilerWarning = (char)((pIN) - 4);				  \
			*(BT_USC_SELHI_REGISTER) = (*(BT_USC_SELHI_REGISTER)				  \
					 & ~(0x000f<<(avoidCompilerWarning<<2)))			  \
					 | ((mODE)<<(avoidCompilerWarning<<2)); 			  \
		 }


/* Enable / disable USC inputs */
#define BT_UscEnableInput(pIN)											  \
			(*(BT_USC_ENIN_REGISTER) |= (0x0001<<(pIN)))
#define BT_UscDisableInput(pIN)											  \
			(*(BT_USC_ENIN_REGISTER) &= ~(0x0001<<(pIN)))

/* Combined convenience macros - sets both mode and direction for a pin */
#define BT_UscRouteInput(pIN2,mODE2) 		  \
{											  \
  BT_UscSwitchSelect(pIN2,mODE2);			  \
  BT_UscEnableInput(pIN2);					  \
}

#define BT_UscRouteOutput(pIN2,mODE2)		  \
{											  \
  BT_UscSwitchSelect(pIN2,mODE2);			  \
  BT_UscDisableInput(pIN2);					  \
}

#if defined(LGE_LEMANS_BLUETOOTH)

#define BT_CTS_GPIO3	1

#define GPIO_BT_LDO_EN							GPIO_167,	PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_HIGH
#define GPIO_BT_32K        						GPIO_54,		PIN_MODE_ALT_3,   	GPIO_OUTPUT, 	ACTIVE_LOW 		/* Bluetooth Sleep Clock, 32.768KHz : GPIO_CLKOUTMUX2 */
#define GPIO_BT_RESET							GPIO_161, 	PIN_MODE_ALT_3,   	GPIO_OUTPUT, 	ACTIVE_LOW
#define GPIO_BT_INT								GPIO_55,  	PIN_MODE_NORMAL,  	GPIO_INPUT,  	ACTIVE_HIGH		/* BT_DBB_INT */
#define GPIO_BT_WAKEUP							GPIO_172, 	PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_HIGH		/* DBB_BT_INT */

/* Bluetooth UART on eGSPb */
#define GPIO_BT_UART_TX          					GPIO_0,   	PIN_MODE_ALT_1,   	GPIO_OUTPUT, 	ACTIVE_LOW 
#define GPIO_BT_UART_RX           					GPIO_1,   	PIN_MODE_ALT_1,   	GPIO_INPUT,  	ACTIVE_LOW 
#define GPIO_BT_UART_RTS_HW					GPIO_4,   	PIN_MODE_ALT_1,   	GPIO_OUTPUT, 	ACTIVE_LOW		/* RTS line is set as UART HW RTS */
#define GPIO_BT_UART_RTS						GPIO_4,   	PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_LOW		/* RTS line is set as GPIO */
#if defined ( BT_CTS_GPIO3 )
#define GPIO_BT_UART_CTS						GPIO_3,   	PIN_MODE_ALT_1,   	GPIO_INPUT,  	ACTIVE_LOW 		/* GPIO 3 */
#else
#define GPIO_BT_UART_CTS						GPIO_5,   	PIN_MODE_ALT_1,   	GPIO_INPUT,  	ACTIVE_LOW		/* GPIO 5 */
#endif

/* Bluetooth PCM on eGSPc */
#define GPIO_BT_PCM_CLK        					GPIO_14,  	PIN_MODE_ALT_1,   	GPIO_OUTPUT, 	ACTIVE_HIGH
#define GPIO_BT_PCM_RX            					GPIO_15,  	PIN_MODE_ALT_1,   	GPIO_INPUT,  	ACTIVE_HIGH
#define GPIO_BT_PCM_SYNC        					GPIO_16,  	PIN_MODE_ALT_1,   	GPIO_OUTPUT, 	ACTIVE_HIGH
#define GPIO_BT_PCM_TX            					GPIO_17,	  	PIN_MODE_ALT_1,   	GPIO_OUTPUT, 	ACTIVE_HIGH

/* unused */
#define GPIO_BT_32K_UNUSED			         	GPIO_54,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH 
#define GPIO_BT_INT_UNUSED						GPIO_55,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_WAKEUP_UNUSED		          	GPIO_172,	PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_TX_UNUSED               		GPIO_0, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH 
#define GPIO_BT_UART_RX_UNUSED               		GPIO_1, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH 
#define GPIO_BT_UART_RTS_UNUSED              		GPIO_4, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH 
#if defined ( BT_CTS_GPIO3 )
#define GPIO_BT_UART_CTS_UNUSED              		GPIO_3, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH 
#else
#define GPIO_BT_UART_CTS_UNUSED              		GPIO_5, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH 
#endif
#define GPIO_BT_PCM_CLK_UNUSED		          	GPIO_14,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_PCM_RX_UNUSED		           		GPIO_15,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_PCM_SYNC_UNUSED		      		GPIO_16,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_PCM_TX_UNUSED		           		GPIO_17,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH

#define GPIO_INT_BT_DBB_DET					GPIO_55,		TRIGGER_BOTH_EDGES,	TRUE, 	1

#elif defined(LGE_ATLAS_BLUETOOTH)

#if defined(LGE_BRCM_BLUETOOTH)
#define GPIO_BT_LDO_EN							GPIO_21,		PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_HIGH	
#define GPIO_BT_RESET 							GPO_11, 		PIN_MODE_NORMAL,  	GPO_ACTIVE, 	ACTIVE_LOW 	
#define GPIO_BT_INT								GPIO_8, 		PIN_MODE_NORMAL, 	GPIO_INPUT, 		ACTIVE_HIGH 	/* BT_DBB_INT */
#define GPIO_BT_WAKEUP							GPIO_19,		PIN_MODE_NORMAL, 	GPIO_OUTPUT, 	ACTIVE_HIGH		/* DBB_BT_INT */

#define GPIO_BT_UART_TX          					GPIO_3, 		PIN_MODE_ALT_1,  	GPIO_OUTPUT, 	ACTIVE_LOW
#define GPIO_BT_UART_RX           					GPIO_1, 		PIN_MODE_ALT_1,  	GPIO_INPUT, 		ACTIVE_LOW
#define GPIO_BT_UART_TX_NORMAL				GPIO_3, 		PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_LOW
#define GPIO_BT_UART_RTS						GPIO_29,		PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_LOW 		/* RTS USC[4] */
#define GPIO_BT_UART_CTS						GPIO_30,		PIN_MODE_NORMAL,  	GPIO_INPUT, 		ACTIVE_LOW		/* CTS USC[5] */

#define GPIO_BT_PCM_EN      						GPO_2, 		PIN_MODE_NORMAL,  	GPO_ACTIVE,  	ACTIVE_HIGH

/* unused */
#define GPIO_BT_INT_UNUSED				            	GPIO_8, 		PIN_MODE_NORMAL, 	GPIO_UNUSED, 	ACTIVE_HIGH 
#define GPIO_BT_WAKEUP_UNUSED				GPIO_19,		PIN_MODE_NORMAL, 	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_TX_UNUSED          			GPIO_3, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_RX_UNUSED           			GPIO_1, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_RTS_UNUSED				GPIO_29,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_CTS_UNUSED				GPIO_30,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_PCM_EN_UNUSED					GPO_2, 		PIN_MODE_NORMAL,  	GPIO_UNUSED,  	ACTIVE_HIGH
#elif defined(LGE_CSR_BLUETOOTH)
#if defined(LGE_L1_MODEL_KP230_REV_C)
#define GPIO_BT_LDO_EN							GPIO_19,		PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_HIGH
#else
#define GPIO_BT_LDO_EN							GPIO_0,		PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_HIGH
#endif
#define GPIO_BT_RESET 							GPO_8, 		PIN_MODE_NORMAL,  	GPO_ACTIVE, 	ACTIVE_LOW 
#define GPIO_BT_INT								GPIO_30,		PIN_MODE_NORMAL,  	GPIO_INPUT, 		ACTIVE_HIGH		/* BT_DBB_INT USC[5] : temp(TBD) */

#define GPIO_BT_UART_TX          					GPIO_3, 		PIN_MODE_ALT_1,  	GPIO_OUTPUT, 	ACTIVE_LOW
#define GPIO_BT_UART_RX           					GPIO_1, 		PIN_MODE_ALT_1,  	GPIO_INPUT, 		ACTIVE_LOW
#define GPIO_BT_UART_TX_NORMAL				GPIO_3, 		PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_LOW
/* BT_COMMON_KIMSANGJIN_071220 noti_011244*/
#define GPIO_BT_INT_DISABLE				      	GPIO_4,		       PIN_MODE_NORMAL, 	GPIO_OUTPUT, 	ACTIVE_HIGH
#define GPIO_BT_PCM_EN							GPIO_29,		PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_HIGH 	/* PCM_EN USC[4] : temp(TBD)*/

/* unused */
#define GPIO_BT_INT_UNUSED				            	GPIO_30,		PIN_MODE_NORMAL, 	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_TX_UNUSED          			GPIO_3, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_RX_UNUSED           			GPIO_1, 		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_PCM_EN_UNUSED					GPIO_29,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#else
# error These signals should be defined.
#endif

#elif defined(LGE_ATLAS_2H_BLUETOOTH)

#define BT_RTS_CTS_GPIO		1	/* For KG290 Rev.D */

#define GPIO_BT_LDO_EN							GPIO_2, 		PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_HIGH 
#define GPIO_BT_32K               					GPIO_40, 	PIN_MODE_ALT_2,  	GPIO_OUTPUT, 	ACTIVE_LOW		/* Bluetooth Sleep Clock, 32.768KHz : GPIO_CLKOUTMUX1*/
#define GPIO_BT_RESET							GPIO_8,		PIN_MODE_NORMAL,   	GPIO_OUTPUT, 	ACTIVE_LOW
#define GPIO_BT_INT								GPIO_36, 	PIN_MODE_NORMAL, 	GPIO_INPUT, 		ACTIVE_HIGH 	/* BT_DBB_INT */
#define GPIO_BT_WAKEUP							GPIO_37, 	PIN_MODE_NORMAL, 	GPIO_OUTPUT, 	ACTIVE_HIGH 	/* DBB_BT_INT */

#define GPIO_BT_UART_TX          					GPIO_34, 	PIN_MODE_ALT_3,  	GPIO_OUTPUT, 	ACTIVE_LOW
#define GPIO_BT_UART_RX           					GPIO_33, 	PIN_MODE_ALT_3,  	GPIO_INPUT,  	ACTIVE_LOW
#define GPIO_BT_UART_TX_NORMAL				GPIO_34, 	PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_LOW
#if defined(BT_RTS_CTS_GPIO)
#define GPIO_BT_UART_RTS 					     	GPO_3, 		PIN_MODE_NORMAL, 	GPO_ACTIVE, 	ACTIVE_LOW
#define GPIO_BT_UART_CTS			                   	GPIO_24,		PIN_MODE_NORMAL, 	GPIO_INPUT, 	     	ACTIVE_LOW
#else
#define GPIO_BT_UART_RTS						GPIO_29, 	PIN_MODE_NORMAL,  	GPIO_OUTPUT, 	ACTIVE_LOW 		/* RTS USC[4] */
#define GPIO_BT_UART_CTS					     	GPIO_30, 	PIN_MODE_NORMAL,  	GPIO_INPUT, 		ACTIVE_LOW		/* CTS USC[5] */
#endif

#define GPIO_BT_PCM_EN      						GPO_18, 		PIN_MODE_NORMAL,  	GPO_ACTIVE,  	ACTIVE_HIGH

/* unused */
#define GPIO_BT_32K_UNUSED			  		GPIO_40,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_INT_UNUSED				            	GPIO_36,		PIN_MODE_NORMAL, 	GPIO_UNUSED, 	ACTIVE_HIGH 
#define GPIO_BT_WAKEUP_UNUSED				GPIO_37,		PIN_MODE_NORMAL, 	GPIO_UNUSED, 	ACTIVE_HIGH 
#define GPIO_BT_UART_TX_UNUSED          			GPIO_34,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_RX_UNUSED           			GPIO_33,		PIN_MODE_NORMAL,  	GPIO_UNUSED,  	ACTIVE_HIGH
#define GPIO_BT_UART_RTS_UNUSED				GPIO_29,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_UART_CTS_UNUSED				GPIO_30,		PIN_MODE_NORMAL,  	GPIO_UNUSED, 	ACTIVE_HIGH
#define GPIO_BT_PCM_EN_UNUSED					GPO_18, 		PIN_MODE_NORMAL,  	GPIO_UNUSED,  	ACTIVE_HIGH

#define GPIO_INT_BT_DBB_DET					GPIO_36_INT_CFG, 	TRIGGER_BOTH_EDGES, 	TRUE, 	1

#else

# error The Bluetooth Pin Configuration should be defined.

#endif

/****************************************************************************
* Type Definitions
****************************************************************************/
typedef enum BTCallStateTag
{	
	BT_STATE_CALL_IDLE,
	BT_STATE_INCALL_SETUP,
	BT_STATE_INCALL_ALERT,
	BT_STATE_OUTCALL_SETUP,
	BT_STATE_OUTCALL_ALERT,
	BT_STATE_CALL_ACTIVE
}
BTCallStateType;

typedef enum BTPcmOnModeTag
{
	BT_SPEECH_DI = 0,
	BT_SPEECH_EN = 1,
	BT_MIC_MUTE_OFF = 2,
	BT_MIC_MUTE_ON = 3
} BTPcmOnMode;

typedef struct
{
    Boolean	inbandRing;
    Boolean	callerId;
    Int16		size;
    Int8		buffer[1];
} BTRing;

/****************************************************************************	
* Test Functions using GPIO
****************************************************************************/
//#define GPIO_FLAG_FOR_UART_TEST
#if defined(GPIO_FLAG_FOR_UART_TEST)
extern void BtUartErrorFlagOn(void);
extern void BtUartErrorFlagOff(void);
#endif

/****************************************************************************	
* Sleep mode Control
****************************************************************************/
extern void BtSendSleepAllowedReq(Boolean canSleep);
extern void SendBtSleepSig(SleepDeviceState sate);

/****************************************************************************	
* ABB(Audio Base Band) Control
****************************************************************************/
extern void BtSendAbbPowerOnReq(Boolean onoff);

#if defined(LGE_BRCM_BLUETOOTH)
/****************************************************************************	
** UART Flow Control(Broadcom only)
****************************************************************************/
extern void BtSetRTS(void);
extern void BtClearRTS(void);
extern Boolean BtGetCTS(void);
extern Boolean BtGetRTS(void);
extern void BtFlowControlInit(void);
#endif /* LGE_BRCM_BLUETOOTH */

/****************************************************************************
** PCM Control
****************************************************************************/
extern void BtDummyStopPCM(void);
extern void BtStopPCM(void);
extern void BtStartMasterModePCM(void);
extern void BtStartSlaveModePCM(void);

#if defined(LGE_BRCM_BLUETOOTH)
/****************************************************************************
** Bluetooth Chip Control For Wakeup & Interrup(Broadcom only)
****************************************************************************/
extern void BtWakeUpOn(void);
extern void BtWakeUpOff(void);
#endif /* LGE_BRCM_BLUETOOTH */

/****************************************************************************
* Power Up/Down For BT Chip
****************************************************************************/
/* BT_COMMON_KIMSANGJIN_080102 noti_011248:refer from SEAN Analog Switch Control For PCM*/
#if defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH) 
extern void BtPcmOn(void);
#endif
/* end of BT_COMMON_KIMSANGJIN_080102 */
extern void BtPowerUp(void);
extern void BtPowerDown(void);

#if defined(LGE_LEMANS_BLUETOOTH)
extern void BtAudioRoutingChangeReq(Boolean isActivated);
#endif

#endif /* LGE_L1_BLUETOOTH */

#endif /* L1BTIF_H */


