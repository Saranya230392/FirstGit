/***************************************************************************
 * LG Electronics Copyright (c) KEVIN_BT job100503
 ***************************************************************************
 * $Id: //central/releases/Branch_release_16/tplgsm/BLUETOOTH/Btqueue.c#1 $
 * $Revision: #1 $
 * $DateTime: 2006/08/14 09:25:26 $
 ***************************************************************************
 *	File Description :
 *		Bluetooth layer 2 and layer 1 protocol elements.(bte_hcisu_task)
 *		task runs at high priority (just under timers)
 *		interrupts run at high priority
 *
 *		The BLUETOOTH protocol is taken from BTE 3.0
 *
 * $Author : KEVIN PIEN(KYUE SUP BYUN) :-), KIM SANG JIN, KANG HYUNG WOOK
 *
 **************************************************************************/


#ifndef BTQUEUE_H
#define BTQUEUE_H

#ifdef LGE_L1_BLUETOOTH

/***************************************************************************
* Include Files
***************************************************************************/

/* BT_L1_KIMSANGJIN_060814 */
#if defined(UPGRADE_500_PLATFORM)
#include <Dl500tick.h>
#elif defined(UPGRADE_430_PLATFORM)
#include "dl430delay.h"
//#include <system.h>
#endif

extern void dlDisableIrq(void);
extern void dlEnableIrq(void);

/***************************************************************************
* Manifest Constants / Defines
***************************************************************************/

#define QUEUE_SIZE		512

/***************************************************************************
* Type Definitions
***************************************************************************/

typedef unsigned		char	bt_uint8;
typedef unsigned short	int 	bt_uint16;
typedef unsigned long	int 	bt_uint32;


typedef struct
{
	bt_uint16	Size;
	bt_uint16	Count;
	bt_uint16	Head;
	bt_uint16	Tail;
	bt_uint8 *	Buffer; 
} BtQueue;


/***************************************************************************
* Exported Variables
***************************************************************************/

extern BtQueue BtRxBuffer;
extern Boolean gBtEngMode;

/***************************************************************************
* Macros
***************************************************************************/

//#define DELAY_1MS()		DELAY(10000)
#define BtEnterCS()		dlDisableIrq()
#define BtLeaveCS()		dlEnableIrq()

/***************************************************************************
* Global Function Prototypes
***************************************************************************/

void BQ_Init( BtQueue *queue );
// full check must be done by the caller
int BQ_WriteData(BtQueue * queue, bt_uint8 * data, int nbytes);
int BQ_ReadData(BtQueue * queue, bt_uint8 * data, int nbytes);
// empty check must be done by the caller
Int8 BQ_Delete( BtQueue* queue );
Int16 BQ_GetContents(BtQueue *queue, char *buf);
Int8 BQ_GetHead( BtQueue *queue );
Boolean BQ_IsEmpty( BtQueue *queue );
Boolean BQ_IsFull( BtQueue *queue );
Int16 BQ_GetNum( BtQueue *queue );
Int16 BQ_GetFreeNum(BtQueue *queue);
void BQ_Reset(BtQueue *queue);

#endif /* LGE_L1_BLUETOOTH */

#endif  /* QUEUE_H */

