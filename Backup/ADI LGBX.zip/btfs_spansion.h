/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfs_ttp.h

DESCRIPTION:	     Functions of spansion File Sytem for Bluetooth

History:
2006/08/28  $Revision: 1.0 $  :: Created for spansion File System Functions
			 			     $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/

#if !defined(BTFS_SPANSION_H)
#define BTFS_SPANSION_H

#if defined(LGE_SPANSION_FS_BLUETOOTH)
/****************************************************************************
* Include Files
****************************************************************************/
#include <fs_io.h>
#include <Dirent.h>
#include "l1al_sig.h"

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/

/****************************************************************************
* Type Definitions
****************************************************************************/
#define MAX_SHORT_NAME_LEN	16
typedef struct FileRenameTag
{
	int 	 index;
	short    *org_fname;
	char	*short_oldname_ptr;
	short	*long_oldname_ptr;	
	char	*short_newname_ptr;
	short	*long_newname_ptr;	
	char	ret_short_name[MAX_SHORT_NAME_LEN];
	char 	*src_fname;
	char 	*dst_fname;
} FileRenameParams;


/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/

/****************************************************************************
* Global Variables
****************************************************************************/

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
 * 	spansion File System Interface for Bluetooth
****************************************************************************/
int btfs_spansion_file_error(void);
int btfs_spansion_open(char *fileName, char *mode);
int btfs_spansion_read ( int handle, void *buf, Int32 len );
int btfs_spansion_write ( int handle, void *buf, Int32 len );
int btfs_spansion_close ( int handle );
int btfs_spansion_stat (char *fileName, Stat *statBuf_p);
int btfs_spansion_info( char *fileName, FileInform *fileInform);
int btfs_spansion_chmod ( char *fileName, char *mode);
int btfs_spansion_remove ( char *fileName );
int btfs_spansion_rename ( char *oldName, char *newName);
int btfs_spansion_seek(int handle, int offset, Int32 fromwhere);
Boolean btfs_spansion_exists(char *fileName);

DirId btfs_spansion_opendir(char *dirname_p);
FileInform *btfs_spansion_readdir(DirId dir_p);
DirId btfs_spansion_closedir(DirId dir_p);
void btfs_spansion_rewinddir(DirId   dir_p);
int btfs_spansion_rmdir(char *path);
int btfs_spansion_mkdir(char *path);
Boolean btfs_spansion_isdir(char *path);
/* BT_L1_KIMSANGJIN_061001 */
DirId btfs_spansion_DirGetfileList(char *Dirname,Int32 file_num,DirId Id,FileInform *dirEntry);
/* end of BT_L1_KIMSANGJIN_061001 */
Int32 btfs_spansion_filegetsize(FileId fid, char *filename);

#endif /* LGE_spansion_FS_BLUETOOTH */

#endif /* end of */
