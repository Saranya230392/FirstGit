/************************************************ 
 *** For Debug Using UART Directly
*************************************************/
#if !defined ( UDEBUG_H )
#define UDEBUG_H

#if defined(LGE_L1_BLUETOOTH)

/****************************************************************************
* Include Files
****************************************************************************/

/****************************************************************************
* Mainfest Constants / Defines
****************************************************************************/
#define DEBUG_BUF_SIZE			256  /* BT_COMMON_KIMSANGJIN_071204 noti_011235 1024->256*/

#if defined(LGE_LEMANS_BLUETOOTH)

#if 0 /* Tiburona_070326 defined(HW_REV_D) || defined(EMMI_ON_PORT_4) */ /* Tiburona_070115*/ 
/* GspZ */
#define 	uGSP_BASE					0x80600000UL
#define 	uGSP_ISTAT_ERRLCK			0x0004
#define 	uGSP_ISTAT_OVRRUN			0x0002
#define 	uGSP_ISTAT_REG				(uGSP_BASE + 0x0c)
#define 	uGSP_ISTAT_TBRE			0x0008
#define 	uGSP_ISTAT_RBRF			0x0001
#define 	uGSP_TBR_REG 				(uGSP_BASE + 0x00)
#define 	uGSP_RBR_REG 				(uGSP_BASE + 0x05)
#else
#define 	uGSP_ISTAT_TBRE			0x0010
#define 	uGSP_ISTAT_RBRF			0x0008
#if 0
/* Egspf */
#define   uUART_ISTAT        			0x804C0034 
#define   uUART_TBR        				0x804C0002 
#define   uUART_RBR        				0x804C0006 
#else
/* Egspa */
#define 	uUART_ISTAT           			0x803C0034
#define 	uUART_TBR        	    			0x803C0002
#define 	uUART_RBR             			0x803C0006
#endif
#endif

/* KIMSANGJIN_060810 */
#define  vinput_w(a)  (*(volatile Int16*)(a))
#define  voutput_b(a,d)  (*(volatile Int8*)(a))=((Int8)d)
/* end of KIMSANGJIN_060810 */
#elif defined(LGE_ATLAS_BLUETOOTH)
//#define uGSP_BASE					0x80400000UL
#define uGSP_BASE					0x803C0000UL

#define uGSP_ISTAT_ERRLCK			0x0004
#define uGSP_ISTAT_OVRRUN			0x0002
#define uGSP_ISTAT_REG				(uGSP_BASE + 0x0c)
#define uGSP_ISTAT_TBRE				0x0008
#define uGSP_TBR_REG 				(uGSP_BASE + 0x00)
#elif defined(LGE_ATLAS_2H_BLUETOOTH)
#define uGSP_BASE					0x80400000UL
//#define uGSP_BASE					0x803C0000UL

#define uGSP_ISTAT_ERRLCK			0x0004
#define uGSP_ISTAT_OVRRUN			0x0002
#define uGSP_ISTAT_REG				(uGSP_BASE + 0x0c)
#define uGSP_ISTAT_TBRE				0x0008
#define uGSP_TBR_REG 				(uGSP_BASE + 0x00)
#endif /*LGE_LEMANS_BLUETOOTH*/

/**************************************************************************/
#define BT_DEBUG_ENABLE	/* For Hyper-terminal */

/* Debugging Tool(LeMans Bluetooth can choice the tool for debugging) */
//#define BT_DEBUG_GENIE				/* For Genie */
#define BT_DEBUG_HYPER				/* For Hyperterminal */

#define LGBT_DEBUG_ENABLE			/* For Phone Log */
#define LGBX_DEBUG_ENABLE			/* For LGBX Log */
#define BRCM_DEBUG_ENABLE 		/* For Broadcom(BTE Stack) Log */
#define CSR_DEBUG_ENABLE			/* For CSR(BCHS Stack) Log */

/**************************************************************************/

/****************************************************************************
* Macros
****************************************************************************/
#if defined(BT_DEBUG_ENABLE)
#define DEBUG0(m)							DebugLn(m)
#define DEBUG1(m,p1)						DebugLn(m,p1)
#define DEBUG2(m,p1,p2) 						DebugLn(m,p1,p2)
#define DEBUG3(m,p1,p2,p3)					DebugLn(m,p1,p2,p3)
#define DEBUG4(m,p1,p2,p3,p4)				DebugLn(m,p1,p2,p3,p4)
#define DEBUG5(m,p1,p2,p3,p4,p5)				DebugLn(m,p1,p2,p3,p4,p5)
#define DEBUG6(m,p1,p2,p3,p4,p5,p6) 			DebugLn(m,p1,p2,p3,p4,p5,p6)
#define DEBUG7(m,p1,p2,p3,p4,p5,p6,p7)		DebugLn(m,p1,p2,p3,p4,p5,p6,p7)
#define DEBUG8(m,p1,p2,p3,p4,p5,p6,p7,p8)	DebugLn(m,p1,p2,p3,p4,p5,p6,p7,p8)
#else
#define DEBUG0(m)				
#define DEBUG1(m,p1)			
#define DEBUG2(m,p1,p2) 		
#define DEBUG3(m,p1,p2,p3)		
#define DEBUG4(m,p1,p2,p3,p4)	
#define DEBUG5(m,p1,p2,p3,p4,p5)
#define DEBUG6(m,p1,p2,p3,p4,p5,p6)
#define DEBUG7(m,p1,p2,p3,p4,p5,p6,p7)
#define DEBUG8(m,p1,p2,p3,p4,p5,p6,p7,p8)
#endif
/* BT_L1_KIMSANGJIN_060815 */

#if defined(LGE_LEMANS_BLUETOOTH)

#if defined(LGBT_DEBUG_ENABLE)
#if defined(BT_DEBUG_GENIE)
#define BT_DEBUG(s)		printf s
#elif defined(BT_DEBUG_HYPER)
#define BT_DEBUG(s)		DebugLn s
#else /* LeMans_YOONSOO_061122 : To use DOM msg  */
#define BT_DEBUG(s)
#endif
#else
#define BT_DEBUG(s)
#endif /* LGBT_DEBUG_ENABLE */

#if 0
#if defined(LGBX_DEBUG_ENABLE)
#if defined(BT_DEBUG_GENIE)
#define BX_DEBUG(s)		printf s
#elif defined(BT_DEBUG_HYPER)
#define BX_DEBUG(s)		DebugLn s
#endif
#else
#define BX_DEBUG(s)
#endif /* LGBX_DEBUG_ENABLE */

#if defined(BRCM_DEBUG_ENABLE)
#if defined(BT_DEBUG_GENIE)
#define BRCM_DEBUG(s)	printf s
#elif defined(BT_DEBUG_HYPER)
#define BRCM_DEBUG(s)	DebugLn s
#else
#define BRCM_DEBUG(s)
#endif
#endif /* BRCM_DEBUG_ENABLE */
#endif

#else /* LGE_LEMANS_BLUETOOTH */

#define BT_DEBUG(s)		DebugLn s
#define BX_DEBUG(s)		DebugLn s
#define BRCM_DEBUG(s)	DebugLn s

#endif /* LGE_LEMANS_BLUETOOTH */

/* LeMans_Tiburona_060816 */
/**  ERROR EXAMPLE **/
#define     EXAMPLE_BT_SUCCESS       		0       	/* No Error */
#define     HCI_COMMAND_TIMEOUT       		100       	/* HCI command timeout */
#define     HCI_CONTROL_HW_ERROR      		101       	/* HCI control HW error */

/* LeMans_Tiburona_060816 */
#if defined ( DEVELOPMENT_VERSION )
           /*BT_DEVCHECK(TRUE, error, BT_TRACE_ARGS)*/
#define BT_DEVCHECK(hANDLE, aSSERTCODE, fILE,lINE)	BT_DevAssert(hANDLE, aSSERTCODE, fILE,lINE)
#else
#define BT_DEVCHECK(hANDLE, aSSERTCODE, fILE,lINE)
#endif


/****************************************************************************
* Global Function Prototypes
****************************************************************************/
void BRCM_bt_debug(const char *format,...);
#if defined(LGBX_INCLUDE)
void LGBX_debug(const char *format,...); /*For LGBX debug message*/
#endif
void DebugLn(const char *format,...);

#define BT_TRACE_ARGS  __FILE__, __LINE__
//void BTDebugOut( char *sFile, int  nLine,const char  *format,...  ); /*BT_COMMON_KIMSANGJIN_071204 noti_011235*/

#ifdef BT_TRACE_ENABLE
void BtDebugN(const char *buf, Int16 len);
void	BtTrace(const char *format, ...);
char     *BtGetLastTrace(void);
int		BtGetMaxTraceSize(void);
int		BtGetCurTraceSize(void);
int		BtGetTraceCount(void);
void	BtInitTrace(void);
void	BtPrintTrace(void);
void	BtDisplayLCD(Int8 row, const char *format,...);
#endif /*BT_TRACE_ENABLE*/

void       BtSetDebugFlag(Boolean flag);
Boolean BtGetDebugFlag(void);

#if defined (LGBX_INCLUDE)
void BtSetBxDebugFlag(Boolean flag);
Boolean BtGetBxDebugFlag(void);
#endif

#if defined(LGE_BRCM_BLUETOOTH)
void BtSetBcmDebugFlag(Boolean flag);
Boolean BtGetBcmDebugFlag(void);
#endif

#if defined(LGE_CSR_BLUETOOTH)
void BtSetCsrDebugFlag(Boolean flag);
Boolean BtGetCsrDebugFlag(void);
#endif

/* BT_L1_KIMSANGJIN_060815 */
void            bt_os_startup(void);
void            bt_os_shutdown(void);
/* end of BT_L1_KIMSANGJIN_060815 */

#if 0 //defined (LGE_MEMLEAK_CHECK) for dev version tiburona_080114
/*Error number values */
#define BTOK			0   /*No error*/
#define EOUTQ 		1   /*outQ fulled, drop 1 packet*/

void BtDisplayLineForDev(Int32 v1, Int32 v2, Int32 v3);
void BtDisplayLCDForDev(const char *format,...);
#endif

#endif /* LGE_L1_BLUETOOTH */

#endif /* UDEBUG_H */

/* End Of File */
