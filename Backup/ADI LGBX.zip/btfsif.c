/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfsif.c

DESCRIPTION:	     Utility & File System Interface Functions Definition for Bluetooth Stack

History:
2006/08/28  $Revision: 1.0 $  :: File System Interface Functions Definition for Bluetooth  
			 			     $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/

#define MODULE_NAME "BTFSIF"

#if defined(LGE_L1_BLUETOOTH)
/****************************************************************************
* Include Files
****************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "kiamxos.h"
#include "kioslow.h"

#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

#if !defined(BTFSIF_H)
#include "btfsif.h"
#endif

#if defined(LGE_APEX_FS_BLUETOOTH)
#if !defined(BTFS_APEX_H)
#include "btfs_apex.h"
#endif
#endif

#if defined(LGE_TTPCOM_FS_BLUETOOTH)
#if !defined(BTFS_TTP_H)
#include "btfs_ttp.h"
#endif
#endif

#if defined(LGE_SPANSION_FS_BLUETOOTH)
#if !defined(BTFS_SPANSION_H)
#include "btfs_spansion.h"
#endif
#endif

#if defined(LGE_COMMON_FS_BLUETOOTH)
#if !defined(BTFS_COMMON_H)
#include "btfs_common.h"
#endif
#endif

#if defined(LGE_EXFS_FS_BLUETOOTH)	/* BT_COMMON_KIMSANGJIN_070411 */
#if !defined(BTFS_EXFS_H)
#include "btfs_exfs.h"
#endif
#endif

#if !defined(AFMF_LCL_H)
#include "afmf_lcl.h"
#endif

#if !defined(AFGL_FNC_H)
#include "afgl_fnc.h"
#endif

#if !defined (AFBT_TYP_H)  /*noti_011084*/
#include "afbt_typ.h"
#endif /*AFBT_TYP_H*/

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/

/****************************************************************************
* Type Definitions
****************************************************************************/

/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Global Variables
****************************************************************************/

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/
/*------------------------------------------------------------------------------
 * Semaphore for protecting critical section:
 *     To prevent BTK_ functions beging called by a number tasks at the same time
 *------------------------------------------------------------------------------*/
static CJ_ID gSemaphore;

void BTFS_INIT_CS(void)
{
	cjsmcreate(&gSemaphore,  "BTFTP", 1);
}

static void BTFS_ENTER_CS(void)
{
	cjsmwait(gSemaphore, KI_AMX_PRIORITY_NORMAL, KI_AMX_TIMEOUT_INFINITE_WAIT);
}

static void BTFS_LEAVE_CS(void)
{
	cjsmsignal(gSemaphore);
}

/* BT_COMMON_KIMSANGJIN_070411 */
AfmfFileStorageType gbtstoragetype=AFMF_FILE_STORAGE_TYPE_NOR;
/* end of BT_COMMON_KIMSANGJIN_070411 */

/****************************************************************************
 * Utilities Functions
****************************************************************************/
static AfmfFileStorageType BtGetStorageType( char *filePath )
{
      AfmfFileStorageType storageType;
	switch( filePath[0] )
	{
		case 'A':
			storageType = AFMF_FILE_STORAGE_TYPE_NOR;
		break;
#if defined(LGE_MMI_EXTERNAL_MEMORY)
		case 'E':
			storageType = AFMF_FILE_STORAGE_TYPE_EXTERNAL;
		break;
#endif

		default :
			storageType = AFMF_FILE_STORAGE_TYPE_NOR;
		break;
	}
	return storageType;
}

#if 0
void BtStrUpr(char *string)	/* Convert a string to uppercase. */
{
	for (; *string; string++)
	{
		if ('a' <= *string && *string <= 'z')
			*string = *string - 'a' + 'A';
	}
}

void BtStrDpr(char *string)
{
	for (string+1; *string; string++)
	{
		if ('A' <= *string && *string <= 'Z')
			*string = *string + 'a' - 'A';
	}
}
#endif

/***************************************************************************
 * Global Functions
 ***************************************************************************/
/*************************For Changing type*************************/
static Int16 utStrlenUcs2(const Int16  *string_p)
{
  Int16 strLength = 0;

  DevAssert (string_p != PNULL);

  while(*string_p != 0)
  {
     string_p++;
     strLength++;
  }

  return(strLength);
}

/*-----------------27/04/99 12:20-------------------
 * A version of strcpy with a twist
 * The function copies the 8-bit string strSrc_p,
 * including its null terminator, to successive
 * elements of the array of Int16s whose first element
 * has the address strDst_p.
 *
 * (See utCompressStrCpy for the reverse operation.)
 *
 * It returns strDst_p.
 * --------------------------------------------------*/
Int16 *
BtutExpandStrcpy(Int16  *strDst_p, Char *strSrc_p)
{
  Int16 *originalStrDst_p = strDst_p;

  DevAssert(strDst_p != PNULL);
  DevAssert(strSrc_p != PNULL);

  do
  {
	*strDst_p = *strSrc_p++;
  } while(*strDst_p++ != '\0');

  return(originalStrDst_p);
}

/*********************************************************************************
 * Function: convertFileNameToUcs2
 *
 * Parameter:
 *			   fileName   IN	Filename as an UTF8 string
 *
 * Return:
 *		   Pointer to a dynamically allocated UCS2 string containing the file name
 *		   This pointer must be freed after use.
 *
 * *********************************************************************************/
Int16 *BtconvertFileNameToUcs2 ( char *fileName )
{
  Int16 *ucs2FileName = PNULL;

#if defined(LGE_MMI_BLUETOOTH)
  /*Convert file name to UCS2 */
  //KiAllocZeroMemory ( (strlen ( fileName )+1) * sizeof (Int16), (void **) &ucs2FileName );
  //BtutExpandStrcpy( ucs2FileName, (Char *) fileName );
  KiAllocZeroMemory ( AFBT_FILENAME_SIZE * sizeof (Int16), (void **) &ucs2FileName ); /*noti_011084*/
  utUtf8ToUcs2(fileName, strlen( fileName ), ucs2FileName, AFBT_FILENAME_SIZE);
#endif

  return ucs2FileName;
}

void BtconvertFileNameToChar(Int16 *Srcstr,char *Dststr)
{
	Int16 i,len;
       len=utStrlenUcs2(Srcstr);
	for (i = 0; i < len; i++)
		Dststr[i] = (char) Srcstr[i];
	Dststr[i] = '\0';
}

/****************************************************************************
 * 	File System Interface for Bluetooth
 *    	The following functions are automatically called by Bluetooth stack when needed.
****************************************************************************/
#if defined(LGE_APEX_FS_BLUETOOTH)

/***************************************************************************
 * Function: Btfs_Open
 *
 * Parameters:
 *             fileName  	IN  Full pathname of file to open
 *             mode    		IN  mode required to file
 *
 * Return: Valid file handle if successful or INVALID_FILE_HANDLE if it fails
 *
 * Description:
 * This function opens the requested file for the specified access method.
 * The path name is parsed to determine the drive letter and hence the logical
 * drive number. The file system dependent function is then called which if
 * successful returns a fileStruct. A file table entry is then allocated and
 * the index into this table is returned as the file handle.
 * Checks are made to see if the type of access is allowed or if the file is
 * already opened exclusively.
 *
 * If the file was opened for writing record it in our special lock file so
 * that if the system goes down before it is properly closed then we will
 * know at start up next time to clean it up.
 * ****************************************************************************/
FileID *Btfs_Open(char *fileName, char *mode)
{
  	FileID *file_p=PNULL;

	DevAssert(fileName != PNULL);
	DevAssert(mode != PNULL);
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Open() %s [%s] \x1b[0m",fileName,mode));

#if 1 /*kp230 20071029 baeheejung: C_00024*/
	if((strcmp(mode,"w") == 0) ||(strcmp(mode,"w+") == 0) ||(strcmp(mode,"a") == 0) ||(strcmp(mode,"a+") == 0))	
	{
		if(Btfs_exists(fileName) == TRUE)
		{
			file_p =(FileID *)FILE_ALREADY_EXIST;
		}
		else
		{
			BTFS_ENTER_CS();

			file_p = btfs_apex_open(fileName, mode);

			BTFS_LEAVE_CS();
		}
	}
	else
	{
		BTFS_ENTER_CS();

		file_p = btfs_apex_open(fileName, mode);

		BTFS_LEAVE_CS();
	}
#else
	BTFS_ENTER_CS();
	
	file_p = btfs_apex_open(fileName, mode);

	BTFS_LEAVE_CS();
#endif

	if(file_p == PNULL)
		BT_DEBUG(("Btfs_Open() Failure [PNULL]"));
	else if(file_p == (FileID *)FILE_ALREADY_EXIST)
		BT_DEBUG(("Btfs_Open() Failure [File Already Exist]"));
	else
		BT_DEBUG(("Btfs_Open() Success [0x%p]", file_p));
	
	return file_p;
}

/****************************************************************************
 * Function: Btfs_Read
 *
 * Parameters:
 *              handle	IN   File handle
 *              buf        	IN   Buffer to copy data to
 *              len        	IN   NUmber of bytes to copy
 *
 * Description:
 * Calls file system dependent read using offset from. Update the offset.
 * ***************************************************************************/
SignedInt32 Btfs_Read(FileID *file_p, void *buf, Int32 len)
{
	SignedInt32 retVal=0;

	DevAssert(file_p != PNULL);
	DevAssert(buf != PNULL);

	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Read() start \x1b[0m"));
	
	BTFS_ENTER_CS();
	
       retVal = btfs_apex_read(file_p, buf, len);
	
	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_Read() Failure [%d]", retVal));
	//else
	//	BT_DEBUG(("Btfs_Read() Success [Read=%d]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_Write
 *
 * Parameters:
 *             handle	IN   File handle
 *             buf     	IN   Buffer to write
 *             len     		IN   NUmber of bytes to write
 *
 * Description:
 * Check access to the file and if OK use file system dependent write function
 * to write bytes to the file.
 * ************************************************************************/
SignedInt32 Btfs_Write(FileID *file_p, void *buf, Int32 len)
{
	SignedInt32 retVal=0;

	DevAssert(file_p != PNULL);
	DevAssert(buf != PNULL);

	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Write() start \x1b[0m"));
	
	BTFS_ENTER_CS();

       retVal = btfs_apex_write(file_p, buf, len);

	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_Write() Failure [%d]", retVal));
	//else
	//	BT_DEBUG(("Btfs_Write() Success [Write=%d]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_Close
 *
 * Parameter:
 *            handle   IN  Handle of file to close
 *
 * Returns:
 *           0  If successful, INVALID if failed
 *
 * Description:
 * Frees the file struct associated with the file. The frees the file handle.
 * ************************************************************************/
SignedInt32 Btfs_Close(FileID *file_p)
{
	SignedInt32 retVal=0;

	DevAssert(file_p != PNULL);

	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Close() start \x1b[0m"));

	BTFS_ENTER_CS();
	
      retVal = btfs_apex_close(file_p);
	
	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_Close() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Close() Success [%d]", retVal));

	return retVal;
}

/**********************************************************************
 * Function: Btfs_Stat
 *
 * Parameters:
 *              fileName  		IN   	File name
 *              statBuf_p 	OUT  Returned stat data
 *
 * Description:
 * Opens the file for reading and gets the stat info. Closes the file.
 * ********************************************************************/
SignedInt32 Btfs_Stat(char *fileName, Stat *statBuf_p)
{
	SignedInt32 retVal=0;

	DevAssert(fileName != PNULL);
	DevAssert(statBuf_p != PNULL);
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Stat() start name:%s \x1b[0m",fileName));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_stat(fileName, statBuf_p);
	
	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_Stat() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Stat() Success [%d]", retVal));

	return retVal;
}

/**********************************************************************
 * Function: Btfs_fStat
 *
 * Parameters:
 *              fileName  		IN   	File name
 *              statBuf_p 	OUT  Returned stat data
 *
 * Description:
 * Opens the file for reading and gets the stat info. Closes the file.
 * ********************************************************************/
SignedInt32 Btfs_FStat(FileID *file_p, Stat *statBuf_p)
{
	SignedInt32 retVal=0;

	DevAssert(file_p != PNULL);
	DevAssert(statBuf_p != PNULL);

	BT_DEBUG(("\x1b[33m \r\n============= Btfs_FStat() start \x1b[0m"));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_fstat(file_p, statBuf_p);
	
	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_FStat() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_FStat() Success [%d]", retVal));

	return retVal;
}

/**********************************************************************
 * Function: Btfs_Ftell
 *
 * Parameters:
 *              FileID  	IN   	File pointer
 *              statBuf_p 	OUT  Returned stat data
 *
 * Description:
 * ********************************************************************/
SignedInt32 Btfs_Ftell(FileID *file_p)
{
	SignedInt32 retVal=0;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Ftell() start \x1b[0m"));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_ftell(file_p);

	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_Ftell() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Ftell() Success [%d]", retVal));

	return retVal;
}

/**********************************************************************
 * Function: Btfs_diskinfo_free_space
 *
 * Parameters: IN a volume (partition - e.g. C:) label
 *
 * Description:
 *				a:	 	=> Internal memory driver for system
 *				c:		=> Internal memory driver for user
 *				e:		=> External memory driver
 * ********************************************************************/
SignedInt32 Btfs_diskinfo_free_space(char driverLetter) /* a volume (partition - e.g. C:) label */
{
	SignedInt32 retVal=0;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_diskinfo_free_space() start \x1b[0m"));

	BTFS_ENTER_CS();

	retVal = btfs_apex_diskinfo_free_space(driverLetter);

	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_Ftell() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Ftell() Success [%d]", retVal));

	return retVal;
}

/**********************************************************************
 * Function: Btfs_get_num_of_entry_in_dir
 *
 * Parameters:
 *
 * Description:
 * ********************************************************************/
SignedInt32 Btfs_get_num_of_entry_in_dir(char *dirPathNamePtr, char *fileNamePtr)
{
	SignedInt32 retVal=0;
	
	DevAssert(dirPathNamePtr != PNULL);
	DevAssert(fileNamePtr != PNULL);
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_get_num_of_entry_in_dir() dirPathNamePtr=%s, fileNamePtr=%s \x1b[0m", 
				dirPathNamePtr, fileNamePtr));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_get_num_of_entry_in_dir(dirPathNamePtr, fileNamePtr);

	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_get_num_of_entry_in_dir() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_get_num_of_entry_in_dir() Success [%d]", retVal));

	return retVal;
}

/**********************************************************************
 * Function: Btfs_get_file_list
 *
 * Parameters:
 *
 * Description:
 * ********************************************************************/
FileLIST *Btfs_get_file_list(Int16 numOfEntryRequested, Int16 startingIndexOfEntry, char *dirPathNamePtr, char *fileNamePtr)
{
	FileLIST *fileListPtr=PNULL;

	DevAssert(dirPathNamePtr != PNULL);
	DevAssert(fileNamePtr != PNULL);
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_get_file_list() fileNamePtr=%s, fileNamePtr=%s \x1b[0m", dirPathNamePtr, fileNamePtr));
	
	BTFS_ENTER_CS();
	
	fileListPtr = btfs_apex_get_file_list(numOfEntryRequested, startingIndexOfEntry, dirPathNamePtr, fileNamePtr);

	BTFS_LEAVE_CS();
	
	if(fileListPtr == PNULL)
		BT_DEBUG(("Btfs_Opendir() Failure [PNULL]"));
	else
		BT_DEBUG(("Btfs_Opendir() Success [0x%p]", fileListPtr));
	
	return fileListPtr;
}

/************************************************************************
 * Function: Btfs_Remove
 *
 * Parameters:
 *             fileName  IN   File name to delete
 *
 * Returns:
 *          0      		Success
 *          INVALID 	Failed to delete file
 *
 * Description:
 * The functions finds the file and assuming it exists and is not already
 * open it marks the file for deletion then frees the file struct.
 * ************************************************************************/
SignedInt32 Btfs_Remove(char *fileName)
{
	SignedInt32 retVal=0;

	DevAssert(fileName != PNULL);
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Remove() file name:%s \x1b[0m",fileName));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_remove(fileName);
	
	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_Remove() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Remove() Success [%d]", retVal));

	return retVal;
}

/******************************************************************
 * Function: Btfs_Rename
 *
 * Parameters:
 *              oldName 	IN  	Old file name
 *              newName 	IN  	New name for file
 *
 * Description:
 * Renames a file on a file system Both files must be on the same
 * file system. The function checks that both are on the same file
 * system then calls the file system dependent function.
 * ****************************************************************/
SignedInt32 Btfs_Rename(char *oldName, char *newName)
{
	SignedInt32 retVal=0;
	
	DevAssert(oldName != PNULL);
	DevAssert(newName != PNULL);
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Rename() %s => %s \x1b[0m", oldName, newName));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_rename(oldName, newName);
	
	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_Rename() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Rename() Success [%d]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_seek
 *
 * Parameters:
 *              handle    	IN  	File handle
 *              offset    	IN  	Number of bytes to move current pointer by.
 *              fromwhere 	IN Place to move pointer to
 *
 *          	   0      		Success
 *              INVALID 	Failed to seek file
 *
 *		<Lseek modes>
 *		FSEEK_SET  - ��ġ�� offset����Ʈ�� ���� �մϴ�. 
 *		FSEEK_CUR - ���� ��ġ�� offset�� ���Ͽ� ��ġ�� ���մϴ�. 
 *		FSEEK_END - ������ ���� offset�� ���Ͽ� ��ġ�� ���մϴ�. 
 *
 * Description:
 * 		Move the offset in the file table entry. Check that the offset is not negative.
 ***************************************************************************/
SignedInt32 Btfs_seek(FileID *file_p, Int8 offset, FseekDir fromwhere)
{
	SignedInt32 retVal=0;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_seek() start \x1b[0m"));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_seek(file_p, offset, fromwhere);
	
	BTFS_LEAVE_CS();

	if(retVal < 0)
		BT_DEBUG(("Btfs_seek() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_seek() Success [%d]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_exists
 *
 * Parameters:
 *              fileName	IN  		Full pathname of file*              
 *		   Return 		TRUE 	if the file specified by filename,
 *              			FALSE 	otherwise
 *
 * Description:
 * 		To check an existing for file.
 ***************************************************************************/
Boolean Btfs_exists(char *fileName)
{
	Boolean retVal=FALSE;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_exists() fileName :%s \x1b[0m",fileName));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_exists(fileName);
	
	BTFS_LEAVE_CS();

	if(retVal==TRUE)
		BT_DEBUG(("Btfs_exists() [%s] exist ", fileName));
	else
		BT_DEBUG(("Btfs_exists() [%s] not exist ", fileName));

	return retVal;
}

/**********************************************************************
 * Function: Btfs_Status
 *
 * Parameters:
 *              info_p 	IN/OUT  Returned status data
 *
 * Description:
 * Place holder for array of mount information array.
 * ********************************************************************/
SignedInt32 Btfs_Status(AbfsMountInfo *info_p)
{	
	SignedInt32 retVal=0;

	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Status() start \x1b[0m"));
	
	BTFS_ENTER_CS();
	
	retVal = btfs_apex_status(info_p);

	BTFS_LEAVE_CS();
	
	if(retVal < 0)
		BT_DEBUG(("Btfs_Status() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Status() Success [%d]", retVal));
	
	return retVal;
}

/**************************************************************************
 * Function: Btfs_Opendir
 *
 * Parameter:
 *             dirname  IN   Full path of directory to be opened
 *
 * Return:
 *        Pointer to DIR structure
 *        PNULL   if open fails
 *
 * Description:
 * Opens the file specified in the path parameter. Allocates a directory
 * structure and stores the file descriptor.
 * **************************************************************************/
DirID Btfs_Opendir(char *dirName)
{
  	DirID retVal=0;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Opendir() dirName: %s \x1b[0m", dirName));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_opendir(dirName);

	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Opendir() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Opendir() Success [%d]", retVal));

	return retVal;
}

/****************************************************************
 * Function: Btfs_Readdir
 *
 * Paramter:
 *             dir_p  IN   Open directory struture
 *
 * Parameter:
 *            Pointer to a dirent struture containing a directory entry
 *            PNULL if no directory entry found
 *
 * Description:
 * Returns a pointer to a directory entry structure containing the
 * name of the entry.
 * ****************************************************************/
BtApexFsReadDir *Btfs_Readdir(DirID dirRef)
{
	BtApexFsReadDir *retVal=PNULL;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Readdir() start \x1b[0m"));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_readdir(dirRef);
	
	BTFS_LEAVE_CS();

	if (retVal == PNULL)
		BT_DEBUG(("Btfs_Readdir() Failure [PNULL]"));
	else
		BT_DEBUG(("Btfs_Readdir() Success [0x%p]", retVal));

	return retVal;
}

/************************************************************************
 * Function: Btfs_Closedir
 *
 * Parameter:
 *             dir_p  IN    Pointer to open directory structure
 *
 * Return: 0   Success
 *
 * Description:
 * Closes the file associated with the open directory.
 * ************************************************************************/
SignedInt32 Btfs_Closedir(DirID dirRef)
{
	SignedInt32 retVal=0;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Closedir() start \x1b[0m"));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_closedir(dirRef);

	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Closedir() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Closedir() Success [%d]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_Rewinddir
 *
 * Parameter:
 *             dir_p  IN    Pointer to open directory structure
 *
 * Description:
 * Sets the directiry entry number back to zero
 * *************************************************************************/
SignedInt32 Btfs_Rewinddir(DirID dirRef)
{
	SignedInt32 retVal=0;

	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Rewinddir() \x1b[0m"));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_rewinddir(dirRef);	
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Rewinddir() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Rewinddir() Success [%d]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_Rmdir
 *
 * Parameter:
 *             path   IN   Full path of directory to be removed
 *
 * Return:
 *         0   Successfully deleted
 *         EOF Directory has not been deleted
 *
 * Description:
 * Removes a directory. The directory must be empty and cannot be the root directory
 * *************************************************************************/
SignedInt32 Btfs_Rmdir(char *path)
{
	SignedInt32 retVal=0;

	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Rmdir() start: %s \x1b[0m", path));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_rmdir(path);
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Rmdir() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Rmdir() Success [%d]", retVal));

	return retVal;
}

/********************************************************************
 * Function: Btfs_Mkdir
 *
 * Parameter:
 *             path   IN   Name of directory to create
 *
 * Return:
 *          0 => success
 *          EINVAL => failure
 *
 * Description:
 * Creates a directory using the low level fsysCreat function.
 * ******************************************************************/
SignedInt32 Btfs_Mkdir(char *path)
{
	SignedInt32 retVal=0;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Mkdir() start: %s \x1b[0m", path));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_mkdir(path);
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Mkdir() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Mkdir() Success [%d]", retVal));

	return retVal;
}

/********************************************************************
 * Function: Btfs_Isdir
 *
 * Parameter:
 *             path   IN   Name of path to check
 *
 * Return:
 *          	TRUE if the directory exists, 
 *		FALSE if the file is
 *
 * Description:
 * 		Check if the directory exits or not
 * ******************************************************************/
Boolean Btfs_Isdir(char *path)
{
	Boolean retVal=0;
	
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Isdir() start: %s \x1b[0m", path));

	BTFS_ENTER_CS();
	
	retVal = btfs_apex_isdir(path);
	
	BTFS_LEAVE_CS();

	if (retVal ==TRUE)
		BT_DEBUG(("Btfs_Isdir() This is Directory"));
	else
		BT_DEBUG(("Btfs_Isdir() This is File"));

	return retVal;
}

SignedInt32 Btfs_Getfilesize(int fid, char *filename)
{
       SignedInt32  retVal=0; /*return file size*/
	   
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Getfilesize() does not implemented. \x1b[0m"));

	if (retVal == EINVAL)
		BT_DEBUG(("Btfs_Getfilesize() Failure [%d]", retVal));
	else
		BT_DEBUG(("Btfs_Getfilesize() Success [size=%d]", retVal));

	return retVal;
}

#if 1 /* To Do : LGBX lib. have to remove*/	
int Btfs_Inform(char *fileName, FileInform *fileInform)
{
	BT_DEBUG(("\x1b[33m \r\n============= Btfs_Inform() does not implemented. Use other function(stat). \x1b[0m"));
}
#endif

#else /* LGE_APEX_FS_BLUETOOTH */

/*********************************************************/
/* You can use the file system interface of other types. 					*/
/* LGE_TTPCOM_FS_BLUETOOTH : TTPCom file system (function call) 		*/
/* LGE_SPANSION_FS_BLUETOOTH : Spansion file system 				*/
/* LGE_COMMON_FS_BLUETOOTH :  FDI or TFFS file system 				*/
/* LGE_EXFS_FS_BLUETOOTH : AIT file system 						*/
/*********************************************************/
/* BT_COMMON_KIMSANGJIN_070405 */
#if defined(FS_OVERWRITE_EN)
static void SeperatePathName(const char *fullPath, char *pathName, char *fileName)
{
	Int16 i;
	char *last; /* pointer to the last occurrence of '\\' */
	const char *ptr;

	last = strrchr(fullPath, '/');
	if (last == fullPath)
	{
		strcpy(pathName, "/");
		strcpy(fileName, fullPath+1);
	}
	else
	{
		i = 0;		
		for (ptr = fullPath; *ptr != '\0'; ptr++)
		{
			if (*ptr == '/')
			{
				if (ptr == last)
				{
					pathName[i] = '\0';
					break;
				}
				else
				{
					pathName[i] = *ptr;
					i++;
				}
			}
			else
			{
				pathName[i] = *ptr;
				i++;
			}
		}
		strcpy(fileName, ptr+1);
		BT_DEBUG(("SeperatePathName() pathName :[%s] filename:[%s]",pathName,fileName));
	}
}

static void GetNameNExt( char *fileName, char *realname, char *extName)
{
	char *ptr; /* pointer to the last occurrence of '\\' */
	char *last = strrchr(fileName, '.');
	Int16 i; 

	if (last != NULL)   strcpy(extName, last+1);
	else	                      extName[0] = '\0';

       i=0;
	for (ptr = fileName; *ptr != '.'; ptr++)
	{
	       if (*ptr == '.')
	       {
			   realname[i]='\0';
			   break;
	       }
		else
		{
			realname[i] = *ptr;
			BT_DEBUG(("GetNameNExt realname[%s]",realname));
			i++;
		}
	}
	realname[i]='\0';
	BT_DEBUG(("GetNameNExt realname[%s]",realname));
	
}

static int Btfs_OverWriteOpen(char *fileName, char *mode)
{
	int  retVal=0;
	
       if((strcmp(mode,"w+") == 0) || (strcmp(mode,"w") == 0) || (strcmp(mode,"a") == 0) ||(strcmp(mode,"a+") == 0))
       {
            Int8 i;
	     char str;
	     Int8  *pathname=PNULL;
 	     Int8  *filename=PNULL;
	     Int8  *orgfilename=PNULL;
	     Int8  *tmpstr=PNULL;
	     Int8  *onlyname=PNULL;
	     Int8  *extstr=PNULL;

	     KiAllocZeroMemory ( (255) * sizeof (Int8), (void **) &pathname );
	     KiAllocZeroMemory ( (255) * sizeof (Int8), (void **) &filename );
	     KiAllocZeroMemory ( (255) * sizeof (Int8), (void **) &orgfilename );
	     KiAllocZeroMemory ( (255) * sizeof (Int8), (void **) &tmpstr );
	     KiAllocZeroMemory ( (255) * sizeof (Int8), (void **) &onlyname );
	     KiAllocZeroMemory ( (255) * sizeof (Int8), (void **) &extstr );
	     if(pathname == PNULL ||filename == PNULL ||tmpstr == PNULL ||onlyname == PNULL || extstr == PNULL) 
	    {
	          if(pathname != PNULL) KiFreeMemory ((void**)&pathname );
		   if(filename != PNULL)   KiFreeMemory ((void**)&filename );
		   if(orgfilename != PNULL) 	KiFreeMemory ((void**)&orgfilename );
		   if(tmpstr != PNULL)		  KiFreeMemory ((void**)&tmpstr );
		   if(onlyname != PNULL)	  KiFreeMemory ((void**)&onlyname );
		   if(extstr != PNULL)		  KiFreeMemory ((void**)&extstr );
		   
		   BTFS_LEAVE_CS();
                 return EINVAL;
	     } 
	     memcpy(tmpstr,fileName,sizeof(Int8)*(strlen(fileName)));
	     SeperatePathName(fileName, pathname, orgfilename);
	     BT_DEBUG((">>Original file name:%s",orgfilename));
	     for(i=1; i<100; i++)
	     {
	            if(Btfs_exists(tmpstr) == TRUE)
	            { 
	                     SeperatePathName(fileName, pathname, orgfilename);
			       GetNameNExt(orgfilename, onlyname, extstr);
				BT_DEBUG((">> orgfilename [%s] onlyname[%s] extstr[%s]",orgfilename,onlyname,extstr));
				strcat(onlyname,"_");
				sprintf(&str,"%d",i);
   				strcat(onlyname,&str);
   				strcat(onlyname,".");
   				strcat(onlyname,extstr);
   				strcat(pathname,"/");
   				strcat(pathname,onlyname);
				BT_DEBUG((">>Current file name:[%s]",pathname));
				memcpy(tmpstr,pathname,sizeof(Int8)*(strlen(pathname)));
				
				memcpy(orgfilename,'\0',(sizeof(Int8)*strlen(orgfilename)));
				memcpy(pathname,'\0',(sizeof(Int8)*strlen(pathname)));
				memcpy(onlyname,'\0',(sizeof(Int8)*strlen(onlyname)));
				memcpy(extstr,'\0',(sizeof(Int8)*strlen(extstr)));
				memcpy(pathname,'\0',(sizeof(Int8)*strlen(pathname)));
				
				if(i == 99) /*No more space to increasing file idx*/
				{
					BTFS_LEAVE_CS();
			     		retVal= FILE_ALREADY_EXIST;		
				}
	            }
		     else
		     {        
				memcpy(fileName,tmpstr,sizeof(Int8)*(strlen(tmpstr)));
			       retVal = btfs_common_open(tmpstr,mode);
			        
				KiFreeMemory ((void**)&pathname );
				KiFreeMemory ((void**)&filename );
				KiFreeMemory ((void**)&tmpstr );
				KiFreeMemory ((void**)&orgfilename );
				KiFreeMemory ((void**)&onlyname );
				KiFreeMemory ((void**)&extstr );
				 break;
	     	     }
	       }
		KiFreeMemory ((void**)&pathname );
		KiFreeMemory ((void**)&filename );
		KiFreeMemory ((void**)&tmpstr );
		KiFreeMemory ((void**)&orgfilename );
		KiFreeMemory ((void**)&onlyname );
		KiFreeMemory ((void**)&extstr );
       }
	else
	{
	      retVal = btfs_common_open(fileName,mode);
	}
	return retVal;
}
#endif /*FS_OVERWRITE_EN*/
/* end of BT_COMMON_KIMSANGJIN_070405 */


/***************************************************************************
 * Function: Btfs_Open
 *
 * Parameters:
 *             fileName  	IN  Full pathname of file to open
 *             mode    		IN  mode required to file
 *
 * Return: Valid file handle if successful or INVALID_FILE_HANDLE if it fails
 *
 * Description:
 * This function opens the requested file for the specified access method.
 * The path name is parsed to determine the drive letter and hence the logical
 * drive number. The file system dependent function is then called which if
 * successful returns a fileStruct. A file table entry is then allocated and
 * the index into this table is returned as the file handle.
 * Checks are made to see if the type of access is allowed or if the file is
 * already opened exclusively.
 *
 * If the file was opened for writing record it in our special lock file so
 * that if the system goes down before it is properly closed then we will
 * know at start up next time to clean it up.
 * ****************************************************************************/
 int Btfs_Open(char *fileName, char *mode)
{
	int  retVal=0;
	
	BT_DEBUG(("Btfs_Open() :%s [%s]",fileName,mode));
	
	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_open(fileName, mode);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_open(fileName, mode);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
/* BT_COMMON_KIMSANGJIN_070403 noti_011044 test code */
#if defined(FS_OVERWRITE_EN) /*use over write option*/
       switch(BtGetStorageType(fileName))
       {
		case AFMF_FILE_STORAGE_TYPE_NOR:
		{
			gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
			retVal= Btfs_OverWriteOpen(fileName, mode);
			break;
		}
		case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		{
			gbtstoragetype =AFMF_FILE_STORAGE_TYPE_EXTERNAL;
			retVal= btfs_exfs_open(fileName, mode);
			break;
		}
		default :
		{
			gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
       retVal= Btfs_OverWriteOpen(fileName, mode);
			break;
		}
       }
#else	
	switch(BtGetStorageType(fileName))
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		{
			gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
	//$ retVal = btfs_common_open(fileName, mode);
       if((strcmp(mode,"w+") == 0) || (strcmp(mode,"w") == 0) || (strcmp(mode,"a") == 0) ||(strcmp(mode,"a+") == 0))
       {
            if(Btfs_exists(fileName) == TRUE)	// $suhui 070402 FTP ���� ���� name ���� ����
	     		 retVal= FILE_ALREADY_EXIST;		
	     else
		        retVal = btfs_common_open(fileName,mode);
       }
	else
	{
	retVal = btfs_common_open(fileName, mode);
	}
			break;
		}
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_EXTERNAL;
			 retVal= btfs_exfs_open(fileName, mode);
			 break;
		 }
		 default :
		 {
		 	gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
			 retVal= btfs_common_open(fileName, mode);
			 break;
		 }
	}
#endif	   
/* end of BT_COMMON_KIMSANGJIN_070403 */
#endif

	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Open() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Open() Success [%ld]", retVal));

	return retVal;
}

/****************************************************************************
 * Function: Btfs_Read
 *
 * Parameters:
 *              handle	IN   File handle
 *              buf        	IN   Buffer to copy data to
 *              len        	IN   NUmber of bytes to copy
 *
 * Description:
 * Calls file system dependent read using offset from. Update the offset.
 * ***************************************************************************/
int Btfs_Read ( int handle, void *buf, Int32 len )
{
	int  retVal=0;

	//BT_DEBUG(("Btfs_Read() start"));
	
	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
//	retVal = btfs_ttpcom_read(handle, buf, len);    /*   CHECK_HY   061002  */
       retVal = btfs_ttpcom_read((handle-1), buf, len);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)
	retVal = btfs_spansion_read(handle, buf, len);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	

switch(gbtstoragetype)
{
	 case AFMF_FILE_STORAGE_TYPE_NOR:
	 {
	retVal = btfs_common_read(handle, buf, len);
		 break;
	 }
	 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
	 {
		 retVal = btfs_exfs_read(handle, buf, len);
		 break;
	 }
	 default :
	 {
		 retVal = btfs_common_read(handle, buf, len);
		 break;
	 }
}
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Read() Failure [%ld]", retVal));
	//else
	//	BT_DEBUG(("Btfs_Read() Success [Read=%ld]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_Write
 *
 * Parameters:
 *             handle	IN   File handle
 *             buf     	IN   Buffer to write
 *             len     		IN   NUmber of bytes to write
 *
 * Description:
 * Check access to the file and if OK use file system dependent write function
 * to write bytes to the file.
 * ************************************************************************/
int Btfs_Write ( int handle, void *buf, Int32 len )
{
	int  retVal=0;

	//BT_DEBUG(("Btfs_Write() start"));
	
	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
//	retVal = btfs_ttpcom_write(handle, buf, len);      /*   CHECK_HY   061002     */
       retVal = btfs_ttpcom_write((handle-1), buf, len);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_write(handle, buf, len);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
       switch(gbtstoragetype)
       {
		case AFMF_FILE_STORAGE_TYPE_NOR:
		{
			retVal = btfs_common_write(handle, buf, len);
			break;
		}
		case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		{
			retVal = btfs_exfs_write(handle, buf, len);
			break;
		}
		default :
		{
	retVal = btfs_common_write(handle, buf, len);
			break;
		}
       }
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Write() Failure [%ld]", retVal));
	//else
	//	BT_DEBUG(("Btfs_Write() Success [Write=%ld]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_Close
 *
 * Parameter:
 *            handle   IN  Handle of file to close
 *
 * Returns:
 *           0  If successful, INVALID if failed
 *
 * Description:
 * Frees the file struct associated with the file. The frees the file handle.
 * ************************************************************************/
int Btfs_Close(int handle)
{
	int  retVal=0;

	BT_DEBUG(("Btfs_Close() start handle: %d",handle));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
      retVal = btfs_ttpcom_close(handle);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_close(handle);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	switch(gbtstoragetype)
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		 {
			 retVal = btfs_common_close(handle);
			 break;
		 }
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
			 retVal = btfs_exfs_close(handle);
			 break;
		 }
		 default :
		 {
	retVal = btfs_common_close(handle);
			 break;
		 }
	}
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Close() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Close() Success [%ld]", retVal));

	return retVal;
}

/**********************************************************************
 * Function: Btfs_Stat
 *
 * Parameters:
 *              fileName  		IN   	File name
 *              statBuf_p 	OUT  Returned stat data
 *
 * Description:
 * Opens the file for reading and gets the stat info. Closes the file.
 * ********************************************************************/
int Btfs_Stat (char *fileName, Stat *statBuf_p)
{
	int  retVal=0;
	
	BT_DEBUG(("Btfs_Stat() start name:%s",fileName));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_stat(fileName, statBuf_p);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_stat(fileName, statBuf_p);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
/* BT_COMMON_KIMSANGJIN_070411 */
	switch(BtGetStorageType(fileName))
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
			 retVal= btfs_common_stat(fileName, statBuf_p);
			 break;
		 }
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_EXTERNAL;
			 /*Not impelmented*/
			 BT_DEBUG(("Btfs_Stat............................Not impelmented"));
			 break;
		 }
		 default :
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
	retVal = btfs_common_stat(fileName, statBuf_p);
			 break;
		 }
	}
/* end of BT_COMMON_KIMSANGJIN_070411 */
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Stat() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Stat() Success [%ld]", retVal));

	return retVal;
}

Int32 Btfs_Statistics(char *deviceLabel)
{
	int  		retVal=0;
	Int32 	freeSize=0;
	
	BT_DEBUG(("Btfs_Statistics() start name:%s", deviceLabel));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	freeSize = btfs_ttpcom_statistics(deviceLabel);
#endif
	
	BTFS_LEAVE_CS();

	if (freeSize <= 0)
		BT_DEBUG(("Btfs_Statistics() Failure or No more space [%ld]", freeSize));
	else
		BT_DEBUG(("Btfs_Statistics() Success [%ld]", retVal));

	return freeSize;
}

int Btfs_Inform ( char *fileName, FileInform *fileInform) /*noti_011019*/
{

 	int  retVal=0;
	
	BT_DEBUG(("Btfs_Inform() start name:%s",fileName));

	BTFS_ENTER_CS();

#if defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_info( fileName, fileInform);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
/* BT_COMMON_KIMSANGJIN_070411 */
	switch(BtGetStorageType(fileName))
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
			 retVal= btfs_common_info( fileName, fileInform);
			 break;
		 }
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_EXTERNAL;
			 /* BT_COMMON_KIMSANGJIN_070418 */
			 retVal= btfs_exfs_info( fileName, fileInform);
			 break;
		 }
		 default :
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
	retVal = btfs_common_info( fileName, fileInform);
			 break;
		 }
	}
/* end of BT_COMMON_KIMSANGJIN_070411 */
#endif

	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("End of Btfs_Inform() Failure [%ld]", retVal));
	else
		BT_DEBUG(("End of Btfs_Inform() Success [%ld]", retVal));

	return retVal;

}

/**********************************************************************
 * Function: Btfs_Chmod
 *
 * Parameters:
 *             fileName  	IN  Filename
 *             perms     	IN  Permissions to apply to the file
 *
 * Description:
 * Opens the file exclusively for reading. Sets the permissions using the
 * file system dependent function then closes it.
 * ********************************************************************/
int Btfs_Chmod( char *fileName, char *mode)
{
	int  retVal=0;
	
	BT_DEBUG(("Btfs_Chmod() start file name:%s mode%s",fileName,mode));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_chmod(fileName, mode);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_chmod(fileName, mode);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
/* BT_COMMON_KIMSANGJIN_070411 */
	switch(BtGetStorageType(fileName))
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
			 retVal= btfs_common_chmod(fileName, mode);
			 break;
		 }
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
		 	gbtstoragetype =AFMF_FILE_STORAGE_TYPE_EXTERNAL;
			 /*Not impelmented*/
			 BT_DEBUG(("Btfs_Chmod............................Not impelmented"));
			 break;
		 }
		 default :
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
	retVal = btfs_common_chmod(fileName, mode);
			 break;
		 }
	}
/* end of BT_COMMON_KIMSANGJIN_070411 */
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Chmod() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Chmod() Success [%ld]", retVal));

	return retVal;
}

/************************************************************************
 * Function: Btfs_Remove
 *
 * Parameters:
 *             fileName  IN   File name to delete
 *
 * Returns:
 *          0      		Success
 *          INVALID 	Failed to delete file
 *
 * Description:
 * The functions finds the file and assuming it exists and is not already
 * open it marks the file for deletion then frees the file struct.
 * ************************************************************************/
int Btfs_Remove( char *fileName )
{
	int  retVal=0;
	
	BT_DEBUG(("Btfs_Remove() file name:%s",fileName));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_remove(fileName);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_remove(fileName);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
/* BT_COMMON_KIMSANGJIN_070411 */
	switch(BtGetStorageType(fileName))
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
	retVal = btfs_common_remove(fileName);
			 break;
		 }
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
		 	gbtstoragetype =AFMF_FILE_STORAGE_TYPE_EXTERNAL;
		 	retVal= btfs_exfs_remove(fileName);
			 break;
		 }
		 default :
		 {
		 	 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
			 retVal= btfs_common_remove(fileName);
			 break;
		 }
	}
/* end of BT_COMMON_KIMSANGJIN_070411 */
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Remove() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Remove() Success [%ld]", retVal));

	return retVal;
}

/******************************************************************
 * Function: Btfs_Rename
 *
 * Parameters:
 *              oldName 	IN  	Old file name
 *              newName 	IN  	New name for file
 *
 * Description:
 * Renames a file on a file system Both files must be on the same
 * file system. The function checks that both are on the same file
 * system then calls the file system dependent function.
 * ****************************************************************/
int Btfs_Rename( char *oldName, char *newName)
{
	int  retVal=0;
	
	BT_DEBUG(("Btfs_Rename() %s => %s",oldName,newName));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_rename(oldName, newName);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_rename(oldName, newName);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	retVal = btfs_common_rename(oldName, newName);
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Rename() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Rename() Success [%ld]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_seek
 *
 * Parameters:
 *              handle    	IN  	File handle
 *              offset    	IN  	Number of bytes to move current pointer by.
 *              fromwhere 	IN Place to move pointer to
 *
 *          	   0      		Success
 *              INVALID 	Failed to seek file
 *
 *		<Lseek modes>
 *		FSEEK_SET  - ��ġ�� offset����Ʈ�� ���� �մϴ�. 
 *		FSEEK_CUR - ���� ��ġ�� offset�� ���Ͽ� ��ġ�� ���մϴ�. 
 *		FSEEK_END - ������ ���� offset�� ���Ͽ� ��ġ�� ���մϴ�. 
 *
 * Description:
 * 		Move the offset in the file table entry. Check that the offset is not negative.
 ***************************************************************************/
int Btfs_seek(int handle, int offset, Int32 fromwhere)
{
	int  retVal=0;
	
	BT_DEBUG(("Btfs_seek() start"));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
//	retVal = btfs_ttpcom_seek(handle, offset, fromwhere);      /*   CHECK_HY    061002   */
      retVal = btfs_ttpcom_seek((handle-1), offset, fromwhere);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_seek(handle, offset, fromwhere);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	retVal = btfs_common_seek(handle, offset, fromwhere);
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_seek() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_seek() Success [%ld]", retVal));

	return retVal;
}


/**************************************************************************
 * Function: Btfs_exists
 *
 * Parameters:
 *              fileName	IN  		Full pathname of file*              
 *		   Return 		TRUE 	if the file specified by filename,
 *              			FALSE 	otherwise
 *
 * Description:
 * 		To check an existing for file.
 ***************************************************************************/
Boolean Btfs_exists(char *fileName)
{
	Boolean retVal=FALSE;
	
	BT_DEBUG(("Btfs_exists() fileName :%s",fileName));

//	BTFS_ENTER_CS(); /*noti_011044*/
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_exists(fileName);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_exists(fileName);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	retVal = btfs_common_exists(fileName);
#endif
	
//	BTFS_LEAVE_CS(); /*noti_011044*/

	if (retVal==TRUE)
		BT_DEBUG(("Btfs_exists() [%s] exist ", fileName));
	else
		BT_DEBUG(("Btfs_exists() [%s] not exist ", fileName));

	return retVal;
}


/**************************************************************************
 * Function: Btfs_Opendir
 *
 * Parameter:
 *             dirname  IN   Full path of directory to be opened
 *
 * Return:
 *        Pointer to DIR structure
 *        PNULL   if open fails
 *
 * Description:
 * Opens the file specified in the path parameter. Allocates a directory
 * structure and stores the file descriptor.
 * **************************************************************************/
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
DIR *Btfs_Opendir(const char *dirname_p)
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
DirId Btfs_Opendir( char *dirname_p)
#elif defined(LGE_COMMON_FS_BLUETOOTH)
DirId Btfs_Opendir( char *dirname_p)
#endif
{
 #if defined(LGE_TTPCOM_FS_BLUETOOTH)	
  	DIR *retVal=PNULL;
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	DirId retVal=NULL;
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	DirId retVal=NULL;
#endif
	
	BT_DEBUG(("Btfs_Opendir(), dirname_p: %s ", dirname_p));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_opendir(dirname_p);
	if (retVal == PNULL)
		BT_DEBUG(("Btfs_Opendir() Failure [PNULL]"));
	else
		BT_DEBUG(("Btfs_Opendir() Success [0x%p], %s", retVal, retVal));
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
        //BTFS_ENTER_CS();
	retVal = btfs_spansion_opendir(dirname_p);
	//BTFS_LEAVE_CS();
	if (retVal < 0 )
		BT_DEBUG(("Btfs_Opendir() Failure :%d",retVal));
	else
		BT_DEBUG(("Btfs_Opendir() Success DirId:%d",retVal));
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	//BTFS_ENTER_CS();
	switch(BtGetStorageType(dirname_p))
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		 {
			 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
			 retVal = btfs_common_opendir(dirname_p);
			 break;
		 }
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
			 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_EXTERNAL;
			 retVal = btfs_exfs_opendir(dirname_p);
			 break;
		 }
		 default :
		 {
			 gbtstoragetype =AFMF_FILE_STORAGE_TYPE_NOR;
	retVal = btfs_common_opendir(dirname_p);
			 break;
		 }
	}
	//BTFS_LEAVE_CS();
	if (retVal < 0 )
		BT_DEBUG(("Btfs_Opendir() Failure :%d",retVal));
	else
		BT_DEBUG(("Btfs_Opendir() Success DirId:%d",retVal));
#endif

	BTFS_LEAVE_CS();

	return retVal;
}

/****************************************************************
 * Function: Btfs_Readdir
 *
 * Paramter:
 *             dir_p  IN   Open directory struture
 *
 * Parameter:
 *            Pointer to a dirent struture containing a directory entry
 *            PNULL if no directory entry found
 *
 * Description:
 * Returns a pointer to a directory entry structure containing the
 * name of the entry.
 * ****************************************************************/
 #if defined(LGE_TTPCOM_FS_BLUETOOTH)	
struct dirent * Btfs_Readdir(DIR *dir_p)
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
FileInform *Btfs_Readdir(DirId dir_p)
#elif defined(LGE_COMMON_FS_BLUETOOTH)
FileInform *Btfs_Readdir(DirId dir_p)
#endif
{
 #if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	struct dirent *retVal=PNULL;
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	 FileInform *retVal;
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	FileInform *retVal;
#endif
	
	BT_DEBUG(("Btfs_Readdir() start"));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_readdir(dir_p);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_readdir(dir_p);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	
	switch(gbtstoragetype)
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		 {
			 retVal = btfs_common_readdir(dir_p);
			 break;
		 }
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
			 retVal = btfs_exfs_readdir(dir_p);
			 break;
		 }
		 default :
		 {
	retVal = btfs_common_readdir(dir_p);
			 break;
		 }
	}
#endif
	
	BTFS_LEAVE_CS();

	if (retVal == PNULL)
		BT_DEBUG(("Btfs_Readdir() Failure [PNULL]"));
	else
		BT_DEBUG(("Btfs_Readdir() Success [0x%p], %s", retVal, retVal));

	return retVal;
}

/************************************************************************
 * Function: Btfs_Closedir
 *
 * Parameter:
 *             dir_p  IN    Pointer to open directory structure
 *
 * Return: 0   Success
 *
 * Description:
 * Closes the file associated with the open directory.
 * ************************************************************************/

#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
int Btfs_Closedir (DIR *dir_p)
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
int Btfs_Closedir (DirId dir_p)
#elif defined(LGE_COMMON_FS_BLUETOOTH)
int Btfs_Closedir (DirId dir_p)
#endif
{
	int  retVal=0;
	
	BT_DEBUG(("Btfs_Closedir() start"));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_closedir(dir_p);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_closedir(dir_p);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	switch(gbtstoragetype)
	{
		 case AFMF_FILE_STORAGE_TYPE_NOR:
		 {
	retVal = btfs_common_closedir(dir_p);
			 break;
		 }
		 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
		 {
			 retVal = btfs_exfs_closedir(dir_p);
			 break;
		 }
		 default :
		 {
			 retVal = btfs_common_closedir(dir_p);
			 break;
		 }
	}
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Closedir() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Closedir() Success [%ld]", retVal));

	return retVal;
}

/**************************************************************************
 * Function: Btfs_Rewinddir
 *
 * Parameter:
 *             dir_p  IN    Pointer to open directory structure
 *
 * Description:
 * Sets the directiry entry number back to zero
 * *************************************************************************/
 #if defined(LGE_TTPCOM_FS_BLUETOOTH)	
void Btfs_Rewinddir(DIR  *dir_p)
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
void Btfs_Rewinddir(DirId  dir_p)
#elif defined(LGE_COMMON_FS_BLUETOOTH)
void Btfs_Rewinddir(DirId  dir_p)
#endif
{
	BT_DEBUG(("Btfs_Rewinddir()"));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	btfs_ttpcom_rewinddir(dir_p);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	btfs_spansion_rewinddir(dir_p);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
switch(gbtstoragetype)
{
	 case AFMF_FILE_STORAGE_TYPE_NOR:
	 {
		 btfs_common_rewinddir(dir_p);
		 break;
	 }
	 case AFMF_FILE_STORAGE_TYPE_EXTERNAL:
	 {
               /*Do not anything*/
               BT_DEBUG(("Btfs_Rewinddir() does not need at EXFS "));
               break;
	 }
	 default :
	 {
	btfs_common_rewinddir(dir_p);
		 break;
	 }
}


#endif
	
	BTFS_LEAVE_CS();
}

/**************************************************************************
 * Function: Btfs_Rmdir
 *
 * Parameter:
 *             path   IN   Full path of directory to be removed
 *
 * Return:
 *         0   Successfully deleted
 *         EOF Directory has not been deleted
 *
 * Description:
 * Removes a directory. The directory must be empty and cannot be the root directory
 * *************************************************************************/
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
int Btfs_Rmdir(const char *path)
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
int Btfs_Rmdir(char *path)
#elif defined(LGE_COMMON_FS_BLUETOOTH)
int Btfs_Rmdir(char *path)
#endif
{
	int  retVal=0;

	BT_DEBUG(("Btfs_Rmdir() start: %s", path));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_rmdir(path);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_rmdir(path);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	retVal = btfs_common_rmdir(path);
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Rmdir() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Rmdir() Success [%ld]", retVal));

	return retVal;
}

/********************************************************************
 * Function: Btfs_Mkdir
 *
 * Parameter:
 *             path   IN   Name of directory to create
 *
 * Return:
 *          0 => success
 *          EINVAL => failure
 *
 * Description:
 * Creates a directory using the low level fsysCreat function.
 * ******************************************************************/
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
int Btfs_Mkdir(const char *path)
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
int Btfs_Mkdir(char *path)
#elif defined(LGE_COMMON_FS_BLUETOOTH)
int Btfs_Mkdir(char *path)
#endif
{
	int  retVal=0;
	
	BT_DEBUG(("Btfs_Mkdir() start: %s", path));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_mkdir(path);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_mkdir(path);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	retVal = btfs_common_mkdir(path);
#endif
	
	BTFS_LEAVE_CS();

	if (retVal < 0)
		BT_DEBUG(("Btfs_Mkdir() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Mkdir() Success [%ld]", retVal));

	return retVal;
}

/********************************************************************
 * Function: Btfs_Isdir
 *
 * Parameter:
 *             path   IN   Name of path to check
 *
 * Return:
 *          	TRUE if the directory exists, 
 *		FALSE if the file is
 *
 * Description:
 * 		Check if the directory exits or not
 * ******************************************************************/
Boolean Btfs_Isdir(char *path)
{
	Boolean retVal=0;
	
	BT_DEBUG(("Btfs_Isdir() start: %s", path));

	BTFS_ENTER_CS();
	
#if defined(LGE_TTPCOM_FS_BLUETOOTH)	
	retVal = btfs_ttpcom_isdir(path);
#elif defined(LGE_SPANSION_FS_BLUETOOTH)	
	retVal = btfs_spansion_isdir(path);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	retVal = btfs_common_isdir(path);
#endif
	
	BTFS_LEAVE_CS();

	if (retVal ==TRUE)
		BT_DEBUG(("Btfs_Isdir() This is Directory"));
	else
		BT_DEBUG(("Btfs_Isdir() This is File"));

	return retVal;
}

Int32 Btfs_Getfilesize(int fid, char *filename)
{
       Int32  retVal; /*return file size*/

#if defined(LGE_SPANSION_FS_BLUETOOTH)	   
	retVal = btfs_spansion_filegetsize(fid, filename);
#elif defined(LGE_COMMON_FS_BLUETOOTH)
	retVal = btfs_common_filegetsize(fid, filename);
#endif /* LGE_SPANSION_FS_BLUETOOTH */

	if (retVal == EINVAL)
		BT_DEBUG(("Btfs_Getfilesize() Failure [%ld]", retVal));
	else
		BT_DEBUG(("Btfs_Getfilesize() Success [size=%ld]", retVal));

	return retVal;
}
#endif /* LGE_APEX_FS_BLUETOOTH */

extern FileNameChar afmfDefaultImageFolder[];
extern FileNameChar afmfDefaultSoundFolder[];
extern FileNameChar afmfDefaultOtherFolder[];
#ifdef LGE_MMI_VIDEO
extern FileNameChar afmfDefaultVideoFolder[];
#endif
//BT_COMMON LEEJINBAEK 20071116 : set storage
#if defined(LGE_MMI_EXTERNAL_MEMORY)
extern FileNameChar afmfExternalRoot[];
extern FileNameChar afmfExternalImageFolder[];
extern FileNameChar afmfExternalSoundFolder[];
extern FileNameChar afmfExternalOtherFolder[];
extern FileNameChar afmfExternalVideoFolder[];
extern FileNameChar afmfExternalTextFolder[];
#endif

/* BT_COMMON_KIMSANGJIN_071107 noti_011226 */
#if defined (LGE_CSR_BLUETOOTH)
static AfmfFileType CheckSupportMyStuff(AfmfFileType category, AfmfFileType file_type)
{
     AfmfFileType file_category;
     BT_DEBUG(("CheckSupportMyStuff() file_type [0x%x]",file_type));
     switch(file_type)
     {
		case AFMF_FILE_TYPE_THUMB:
		case AFMF_FILE_TYPE_SWF:
		case AFMF_FILE_TYPE_MP3:
		case AFMF_FILE_TYPE_AAC:
		case AFMF_FILE_TYPE_WMA:
		case AFMF_FILE_TYPE_M4A:
		case AFMF_FILE_TYPE_3GP:
		case AFMF_FILE_TYPE_MP4:
		case AFMF_FILE_TYPE_TXT:
		case AFMF_FILE_TYPE_RA:
		case AFMF_FILE_TYPE_RM:
              {
			 file_category =AFMF_FILE_TYPE_NULL; 
                      break;
		}

		default:
		{
		         file_category =category;
		break;
		}
     }
     return file_category;
}
#endif /*End of LGE_CSR_BLUETOOTH */
/* end of BT_COMMON_KIMSANGJIN_071107 */
//BT_COMMON LEEJINBAEK 20071116 : set storage [START]
void Btfs_GetFolderNameToSave(char* folderName, char *fileName)
{
	AfmfFileType fileType, fileCategory, eFiletype;
	FileNameChar tmpFolderName[32] = {0};
	FileNameChar tmpFileName[255] = {0};
	char	tmpFolderNameChar[32] = {0};
	BTStorageType	storageType = afbtGetStorageType();
	
	memset(&tmpFolderName[0], 0x00, sizeof(FileNameChar)*32);
	memset(&tmpFileName[0], 0x00, sizeof(FileNameChar)*255);
	memset(&tmpFolderNameChar[0], 0x00, sizeof(char)*32);
#if defined(LGE_FS_SUPPORT_LONG_FILE_NAME)
	ConvertUTF8toUCS2(fileName, strlen(fileName),tmpFileName);
	eFiletype = afmfGetFileTypeFromFileName( tmpFileName );
#else
	eFiletype = afmfGetFileTypeFromFileName( fileName );
#endif
/* change to fileCategory */
	fileCategory = GET_FILE_CATEGORY(eFiletype);
	fileType = GET_FILE_TYPE(eFiletype); 

	BT_DEBUG(("1 fileCategory [0x%x] fileType[0x%x] storageType[0x%x]",fileCategory,fileType, storageType));
/* BT_COMMON_KIMSANGJIN_071107 noti_011226 */
#if defined (LGE_CSR_BLUETOOTH)
	fileCategory = CheckSupportMyStuff(fileCategory,fileType);    
	BT_DEBUG(("2 fileCategory [0x%x] fileType[0x%x] storageType[0x%x]",fileCategory,fileType, storageType));
#endif /*LGE_CSR_BLUETOOTH*/
/* end of BT_COMMON_KIMSANGJIN_071107 */

	switch(storageType)
	{
		case BT_STORAGE_TYPE_EXTERNAL:
		{
#if defined(LGE_MMI_EXTERNAL_MEMORY)
			switch( fileCategory )
			{
				case AFMF_FILE_TYPE_IMAGE:
					memcpy(tmpFolderName, afmfExternalImageFolder, sizeof(FileNameChar)*StrLength(afmfExternalImageFolder));
					break;			
				case AFMF_FILE_TYPE_SOUND:
				case AFMF_FILE_TYPE_MUSIC:
					memcpy(tmpFolderName, afmfExternalSoundFolder, sizeof(FileNameChar)*StrLength(afmfExternalSoundFolder));
					break;
		#if defined (LGE_MMI_VIDEO)
				case AFMF_FILE_TYPE_VIDEO:
					memcpy(tmpFolderName, afmfExternalVideoFolder, sizeof(FileNameChar)*StrLength(afmfExternalVideoFolder));
					break;
		#endif		
				default:
					memcpy(tmpFolderName, afmfExternalOtherFolder, sizeof(FileNameChar)*StrLength(afmfExternalOtherFolder));
					break;
			}
			break;
#endif /* LGE_MMI_EXTERNAL_MEMORY */
		}
		default:
		{
			switch( fileCategory )
			{
				case AFMF_FILE_TYPE_IMAGE:
					memcpy(tmpFolderName, afmfDefaultImageFolder, sizeof(FileNameChar)*StrLength(afmfDefaultImageFolder));
					break;
				case AFMF_FILE_TYPE_SOUND:
				case AFMF_FILE_TYPE_MUSIC:
					memcpy(tmpFolderName, afmfDefaultSoundFolder, sizeof(FileNameChar)*StrLength(afmfDefaultSoundFolder));
					break;
#if defined (LGE_MMI_VIDEO)
#if defined (LGE_MMI_AIT_701)
				/* Save to Others folder in this case. We cannot play  */
#else
				case AFMF_FILE_TYPE_VIDEO:
					memcpy(tmpFolderName, afmfDefaultVideoFolder, sizeof(FileNameChar)*StrLength(afmfDefaultVideoFolder));
					break;
#endif
#endif /* LGE_MMI_VIDEO */
				default:
					memcpy(tmpFolderName, afmfDefaultOtherFolder, sizeof(FileNameChar)*StrLength(afmfDefaultOtherFolder));
					break;
			}	
			break;
		}
	}
	
#if defined(LGE_FS_SUPPORT_LONG_FILE_NAME)
	ConvertUCS2toUTF8(tmpFolderName, StrLength(tmpFolderName), tmpFolderNameChar);
	memcpy(folderName, tmpFolderNameChar, sizeof(char)*strlen(tmpFolderNameChar));
#else
	memcpy(folderName, tmpFolderName, sizeof(tmpFolderName));
#endif
	BT_DEBUG(("Btfs_GetFolderNameToSave() : folderName [%s], file name [%s]", folderName, fileName));
}
//BT_COMMON LEEJINBAEK 20071116 : set storage [END]

#endif /* LGE_L1_BLUETOOTH */

