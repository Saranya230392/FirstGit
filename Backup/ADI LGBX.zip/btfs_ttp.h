/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfs_ttp.h

DESCRIPTION:	     Functions of TTPCom File Sytem for Bluetooth

History:
2006/08/28  $Revision: 1.0 $  :: Created for TTPCom File System Functions
			 			     $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/

#if !defined(BTFS_TTP_H)
#define BTFS_TTP_H

#if defined(LGE_TTPCOM_FS_BLUETOOTH)
/****************************************************************************
* Include Files
****************************************************************************/
#if defined (UPGRADE_FSYSTEM)
#if !defined (FS_IO_H)
#include <fs_io.h>
#endif

#if !defined (DIRENT_H)
#include <Dirent.h>
#endif
#endif

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/
#define BTFSIF_DRIVE_SEPARATOR     		58    /*The : character */
#define BTFSIF_FILE_SEPARATOR      		92    /* The \ character */

#define BTFSIF_INT_SYS_MEMORY_DRIVER	 		"a:"		/* Internal memory driver for system */
#define BTFSIF_INT_USER_MEMORY_DRIVER	 		"c:"		/* Internal memory driver for user */
#define BTFSIF_EXT_MEMORY_DRIVER 			"e:"		/* External memory driver */
#define BTFSIF_FULL_MEMORY_DRIVER 			"z:"
#define BTFSIF_FULL_MEMORY_INDICATOR 			BTFSIF_FULL_MEMORY_DRIVER"\\"

/****************************************************************************
* Type Definitions
****************************************************************************/

/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/

/****************************************************************************
* Global Variables
****************************************************************************/

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
 * 	TTPCOM File System Interface for Bluetooth
****************************************************************************/
int btfs_ttpcom_open(const char *fileName, const char *mode);
int btfs_ttpcom_read ( int handle, void *buf, Int32 len );
int btfs_ttpcom_write ( int handle, void *buf, Int32 len );
int btfs_ttpcom_close ( int handle );
int btfs_ttpcom_stat (const char *fileName, Stat *statBuf_p);
Int32 btfs_ttpcom_statistics(char *deviceLabel);
int btfs_ttpcom_chmod ( const char *fileName, const char *mode);
int btfs_ttpcom_remove ( const char *fileName );
int btfs_ttpcom_rename ( const char *oldName, const char *newName);
int btfs_ttpcom_seek(int handle, int offset, Int32 fromwhere);
Boolean btfs_ttpcom_exists(const char *fileName);

DIR * btfs_ttpcom_opendir(const char *dirname_p);
struct dirent *btfs_ttpcom_readdir(DIR *dir_p);
int btfs_ttpcom_closedir(DIR *dir_p);
void btfs_ttpcom_rewinddir(DIR  *dir_p);
int btfs_ttpcom_rmdir(const char *path);
int btfs_ttpcom_mkdir(const char *path);
Boolean btfs_ttpcom_isdir(const char *path);

#endif /* LGE_TTPCOM_FS_BLUETOOTH */

#endif /* end of */
