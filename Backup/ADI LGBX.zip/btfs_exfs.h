/***************************************************************************
 * LG Electronics Copyright (c)
 ***************************************************************************
 * $Id: //central/releases/Branch_release_/BLUETOOTH/Btaitfs.h $
 * $Revision: #1 $
 * $DateTime: 2007/03/16 16:08:37 $
 ***************************************************************************
 *  File Description :
 *      Bluetooth AIT File System Interface
 *
 *      
 *
 * $Author : HYUNG-WOOK KANG(TIBURONA) ,KIMSANGJIN
 **************************************************************************/
#if !defined(BTFS_EXFS_H)
#define BTFS_EXFS_H

#if defined(LGE_EXFS_FS_BLUETOOTH)

#include <L1exfs_typ.h> 
#include <Fs_fat.h>
#include <btfsif.h>
#include <Btconfig.h>
/***********************************************************
#define EXFS_NUM_OF_GET_FILELIST   50
#define EXFS_NUM_OF_GET_DIRLIST    10

#define LGE_EXT_SYSTEM_DRIVE   "DEV0"
#define LGE_EXT_SYSTEM_DRIVE_PATH	"DEV0:"

#define LGE_EXT_MEDIA_DIR_PATH 	"DEV0:\\MYMEDI~1"
#define LGE_EXT_VIDEOS_DIR_PATH	"DEV0:\\MYMEDI~1\\VIDEOS"
#define LGE_EXT_IMAGES_DIR_PATH	"DEV0:\\MYMEDI~1\\IMAGES"
#define LGE_EXT_SOUNDS_DIR_PATH	"DEV0:\\MYMEDI~1\\SOUNDS"
#define LGE_EXT_TEXT_DIR_PATH	"DEV0:\\MYMEDI~1\\TEXTS"
#define LGE_EXT_OTHERS_DIR_PATH	"DEV0:\\MYMEDI~1\\OTHERS"


#define LGE_EXT_SYSTEM_DRIVE   "DEV0"
#define LGE_EXT_SYSTEM_DRIVE_PATH	"DEV0:"
#define LGE_EXT_VIDEOS_DIR_PATH	"DEV0:\\VIDEOS"
#define LGE_EXT_IMAGES_DIR_PATH	"DEV0:\\IMAGES"
#define LGE_EXT_SOUNDS_DIR_PATH	"DEV0:\\SOUNDS"
#define LGE_EXT_TEXT_DIR_PATH	"DEV0:\\TEXTS"
#define LGE_EXT_OTHERS_DIR_PATH	"DEV0:\\OTHERS"

************************************************************/
 #define AIT_SHORTNAME_SIZE 25
 #define BT_AIT_FILE_NAME_LENGTH 255  /*noti_011154 change 100 to 255 it must be same with AFBT_FILENAME_SIZE*/
 
#define BT_FOLDER_TYPE_ROOT		0 /* ROOT foler */
#define BT_FOLDER_TYPE_FDI		1 /* FDI-type folder */
#define BT_FOLDER_TYPE_M4		       2 /* M4-type folder */
#define BT_FOLDER_TYPE_AIT		3 /* AIT-type folder */
#define BT_FOLDER_TYPE_INVALID	10

typedef enum ModeBTFTPTag 
{
	BT_WRITE=0,
	BT_READ=1,
	BT_DELETE,
	NUM_OF_BTFTP
} ModeBTFTP;

 /* BT_COMMON_KIMSANGJIN_070419 */
 typedef struct Aitfildepth_Tag
 {
	 Int16		  long_dir_path[BT_AIT_FILE_NAME_LENGTH+1];
	 char		short_dir_path[BT_AIT_FILE_NAME_LENGTH+1];
 } Aitfiledepth;

 void Btexfs_activate (void);
 void Btexfs_deactivate (void);
 
 int btfs_exfs_open(char  *short_filename_p, char *mode);
 int btfs_exfs_write(int handle, void *buf, Int32 len);
 int btfs_exfs_read(int handle, void *buf, Int32 len);
 int btfs_exfs_close(int handle);
 int btfs_exfs_remove (char *fileNamepath);
 int btfs_exfs_stat(char *fileName, FileInform *fileInform);
/* BT_COMMON_KIMSANGJIN_070418 */
 int btfs_exfs_info(char *fileName, FileInform *fileInform);
/* end of BT_COMMON_KIMSANGJIN_070418 */
 Int32 btfs_exfs_size(char * filename_p);
 Int32 btfs_exfs_filegetlist(Char * dirname_p, Int16 file_Index, Int16 file_num);
 Int16 btfs_exfs_filecount (char * dirname_p, L1ExfsAttribMode attribute);
 Int32 btfs_exfs_opendir(char *dirname_p);
 FileInform *btfs_exfs_readdir(DirId dir_p) ;
 int btfs_exfs_closedir(DirId dir_p);
#if 0
//===========================================================//
void BtInitAitfsFolder(void);
static Int32 BtAitFTP_FileError(void);
Boolean BtGetaitActiveFlag(void);
void BtSetaitActiveFlag(Boolean flag);
/* Tiburona BT_050920 start >> */
Boolean BtGetaitActiveBTFlag(void);
void BtSetaitActiveBTFlag(Boolean flag);
/* Tiburona BT_050920 end << */
void ControlMHoldForBT(Boolean M_Hold);
//===========================================================//

//===========================================================//
static F_HANDLE BtexfsOpen(char  *short_filename_p, ExfsOpenMode  fmode, short *long_filename_p);
//===========================================================//

//===========================================================//
char *GetAitShortDirForFolderIndex(Int16 folderIdx);
char *GetAitShortDirName(char *folderName);
void BtGetListAIT(char *folderName, char *fileName, char *short_name); /* Tiburona BT_051003 */
void ConvertToAitForm(char *folderName, char *fileName, char *aitshortFileName, Int16 *aitlongFileName, ModeBTFTP mode);/* Tiburona BT_051003 */
//===========================================================//

//===========================================================//
Int16 BtAitFileOpen(char *folderName, char *fileName);
Int16 BtAitFileCreate(char *folderName, char *fileName);
void BtAitFileClose(int fid);
Int32 BtAitFileWrite(int fid, void *buffer, int size);
Int32 BtAitFileRead(int fid, void *buffer, int size);
bool_t BtAitFileExists(char *folderName, char *fileName);
Int32 BtAitFileLength(int fid);
bool_t BtAitFileRemove(char *folderName, char *fileName);
Int32 BtAitFileStatistics(void);
//===========================================================//

//===========================================================//
static Int32 BtAit_ConvertTimeInfo(sFILEINFO *src);
static void BtAit_CopyFileInfo(BTMMI_FileInfo *dest, sFILEINFO *src);
Boolean BtAit_AddFileInfo(BTMMI_FileList *fileList, BTMMI_FileInfo *info);
void BtOpenAitSubFolder(BTMMI_FileList *fileList, Int16 folderIdx);
//===========================================================//
#endif

#endif /* LGE_EXFS_FS_BLUETOOTH */

#endif /* end of */


