/*******************************************************************************
	Copyright by LG Electronics Inc.

FILE:		     Btfs_common.h

DESCRIPTION:	     Functions of common File Sytem for Bluetooth

History:
2007/02/24  $Revision: 1.0.1 $  :: Created for spansion File System Functions
			 			     $ KYUESUP BYUN, KIM SANG JIN, KANG HYUNG WOOK
**************************************************************************/
 
#if !defined(BTFS_COMMON_H)
#define BTFS_COMMON_H

#if defined(LGE_COMMON_FS_BLUETOOTH)
/****************************************************************************
* Include Files
****************************************************************************/
#include <fs_io.h>
#include <Dirent.h>
#include "l1al_sig.h"

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/

/****************************************************************************
* Type Definitions
****************************************************************************/
#define MAX_SHORT_NAME_LEN	16
typedef struct FileRenameTag
{
	int 	 index;
	short    *org_fname;
	char	*short_oldname_ptr;
	short	*long_oldname_ptr;	
	char	*short_newname_ptr;
	short	*long_newname_ptr;	
	char	ret_short_name[MAX_SHORT_NAME_LEN];
	char 	*src_fname;
	char 	*dst_fname;
} FileRenameParams;


/****************************************************************************
* Variables
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/

/****************************************************************************
* Global Variables
****************************************************************************/

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
 * 	spansion File System Interface for Bluetooth
****************************************************************************/
int btfs_common_file_error(void);
int btfs_common_open(char *fileName, char *mode);
int btfs_common_read ( int handle, void *buf, Int32 len );
int btfs_common_write ( int handle, void *buf, Int32 len );
int btfs_common_close ( int handle );
int btfs_common_stat (char *fileName, Stat *statBuf_p);
int btfs_common_info( char *fileName, FileInform *fileInform); /*noti_011019*/
int btfs_common_chmod ( char *fileName, char *mode);
int btfs_common_remove ( char *fileName );
int btfs_common_rename ( char *oldName, char *newName);
int btfs_common_seek(int handle, int offset, Int32 fromwhere);
Boolean btfs_common_exists(char *fileName);

DirId btfs_common_opendir(char *dirname_p);
FileInform *btfs_common_readdir(DirId dir_p);
DirId btfs_common_closedir(DirId dir_p);
void btfs_common_rewinddir(DirId   dir_p);
int btfs_common_rmdir(char *path);
int btfs_common_mkdir(char *path);
Boolean btfs_common_isdir(char *path);
DirId btfs_common_DirGetfileList(char *Dirname,Int32 file_num,DirId Id,FileInform *dirEntry);
Int32 btfs_common_filegetsize(FileId fid, char *filename);

#endif /* LGE_COMMON_FS_BLUETOOTH */

#endif /* end of */
