/*******************************************************************************

			Copyright by LG Electronics Inc.

FILE
				 L1BTIF.c	 

DESCRIPTION:
				 Bluetooth BCM1200 Interface functions 
				 & Lemans Interface Functions, BTE 3.0
				$Revision: 1.0 $ by $Author: Kyue Sup Byun & Sang-Jin KIM $ & KANE HYUNG WOOK $
				2006/08/11	: Definition for Base Functions

History: job100502
2006/08/11 $Revision: 1.0 $  :: $ KYUESUP BYUN, KIM SANG JIN
		   
**************************************************************************/

#define MODULE_NAME "LGEBTTIMERS"

#if defined(LGE_L1_BLUETOOTH)

#include <system.h>
#include <kernel.h>

#if !defined (LGEBTTIMERS_H)
#include <lgebttimers.h>
#endif


/* BT_L1_KIMSANGJIN_060818 */
#if defined(DM_USE_NEW_RTC_MODULE)
#if !defined (DMTIMERS_H)
#include <Dmtimers.h>
#endif
#endif

#if defined(UPGRADE_COARSE_TIMERS)
#if !defined (L1ALCFG_H)
#include <l1alcfg.h>
#endif
#endif

#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

/***************************************************************************
 * Manifest Constants
 ***************************************************************************/
/* BT_L1_KIMSANGJIN_060818 */
typedef struct DmBTtimerTypeTag
{
	LgeBtTimerNum	BtTimer;
	DmTimerId		   BtTimerId;
}DmBTtimerType;
/* end of BT_L1_KIMSANGJIN_060818 */


/***************************************************************************
 * Variables
 ***************************************************************************/
 
NO_SIGNALS_USED

KiTimer lgeBtTimer [ NUM_OF_BT_TIMERS ];

/***************************************************************************
 * Global Functions
 ***************************************************************************/
 
/* BT_L1_KIMSANGJIN_060818 */
static const DmBTtimerType BtTimeMapping[NUM_OF_BT_TIMERS] =
{
	{ BT_TIMER_TYPE_SEMA_TIMER, DM_TMR_BT_SEMA_TIMER },
	{ BT_TIMER_TYPE_TEST_TIMER, DM_TMR_BT_TEST_TIMER },                                                        /* Mapping for */
	{ BT_TIMER_TYPE_DEBUG_DISPLAY_TIMER, DM_TMR_BT_DEBUG_DISPLAY_TIMER },                     /* Mapping for */
	{ BT_TIMER_TYPE_HOOK_TIMER, DM_TMR_BT_HOOK_TIMER },                                                       /* Mapping for */
	{ BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER, DM_TMR_BT_AUDIO_PATH_CHANGE_TIMER },  /* Mapping for */
	{ BT_TIMER_TYPE_TX_POLLING_TIMER, DM_TMR_BT_TX_POLLING_TIMER },                    			/* Mapping for */
	{ BT_TIMER_TYPE_TIMEOUT_TIMER, DM_TMR_BT_TIMEOUT_TIMER },                                            /* Mapping for */
	{ BT_TIMER_TYPE_BT_ON_TIMER, DM_TMR_BT_ON_TIMER },                                                       /* Mapping for */
	{ BT_TIMER_TYPE_BT_POPUP_TIMER, DM_TMR_BT_POPUP_TIMER },                                             /* Mapping for */
	{ BT_TIMER_TYPE_BT_PCM_TIMER, DM_TMR_BT_PCM_TIMER },                                                   /* Mapping for */
};
/* end of BT_L1_KIMSANGJIN_060818 */
#if 0
/*******************************************************************************
 * Function:      lgeBtTimersInitialise
 *
 * Parameters:    none
 *
 * Returns:       none
 *
 * Description:   Initialsie function for BT Timers
 ******************************************************************************/
void lgeBtTimersInitialise ( void )
{
	LgeBtTimerNum btTimerNum = BT_TIMER_TYPE_FIRST;

	while ( btTimerNum < NUM_OF_BT_TIMERS )
	{
		lgeBtTimer [ btTimerNum ].userValue = btTimerNum;
		lgeBtTimer [ btTimerNum ].timerId   = KI_TIMER_NOT_RUNNING;
		lgeBtTimer [ btTimerNum ].myTaskId  = EMMI_LOW_PRI_TASK_ID; /* KANE_BT job050123 */
		btTimerNum = (LgeBtTimerNum) ( btTimerNum + 1 );
	}
}
#endif
/*******************************************************************************
 * Function:      lgeBtStopTimer
 *
 * Parameters:    lgeBtTimerNum btTimerNum
 *
 * Returns:       none
 *
 * Description:   Bluetooth timer stop function
 ******************************************************************************/
void lgeBtStopTimer ( LgeBtTimerNum btTimerNum )
{
	DmStopTimer(BtTimeMapping[ btTimerNum ].BtTimerId);
}

/*******************************************************************************
 * Function:      lgeBtStartTimer
 *
 * Parameters:    lgeBtTimerNum btTimerNum
 *
 * Returns:       none
 *
 * Description:   Bluetooth timer start function
 ******************************************************************************/
void lgeBtStartTimer ( LgeBtTimerNum btTimerNum,Int32 sec )
{
	/* BT_L1_KIMSANGJIN_060818 */
	Int32 Ms=0;
	Ms = sec*1000;
	//BT_DEBUG(("BtTimeMapping[ btTimerNum ].BtTimerId :%x",BtTimeMapping[ btTimerNum ].BtTimerId));
	DmStartTimer(BtTimeMapping[ btTimerNum ].BtTimerId, Ms);
	/* end of BT_L1_KIMSANGJIN_060818 */
}

/*******************************************************************************
 * Function:      lgeBtTimerExpiry
 *
 * Parameters:    lgeBtTimerNum btTimerNum
 *
 * Returns:       none
 *
 * Description:   Bluetooth timer expiry function
 ******************************************************************************/
void lgeBtTimerExpiry ( LgeBtTimerNum btTimerNum )
{
	lgeBtTimer [ btTimerNum ].timerId = KI_TIMER_NOT_RUNNING;
}

#if defined (LGBX_INCLUDE)
void lgeLGBXHandleTimerExpiry( void )
{
  /* Timer has expired, so release the semaphore */
  KiIncIntSemaphore( KI_LGBX_SEMAPHORE );    
}
#endif
/*******************************************************************************
 * Function:      lgeBtMsStartTimer
 *
 * Parameters:    lgeBtTimerNum btTimerNum
 *                timeInMs   Int16
 *
 * Returns:       none
 *
 * Description:   Bluetooth timer begin function with additional time value.
 *                Same as lgeBtStartTimer, but allows the timeout to be passed in
 ******************************************************************************/
void lgeBtMsStartTimer( LgeBtTimerNum btTimerNum, Int16 timeInMs )
{
/* BT_L1_KIMSANGJIN_060818 */
	DmStartTimer(BtTimeMapping[ btTimerNum ].BtTimerId, timeInMs);
}

/* job100506 */
/*******************************************************************************
 * Timer expiry function indicating that the desired delay has occured and 
 * the operations can resume.
 *******************************************************************************/
void lgeBtHandleTimerExpiry( void )
{
	/* Timer has expired, so release the semaphore */
	KiIncIntSemaphore( KI_BT_SEMAPHORE );    
}	 


/*******************************************************************************
 * Local wait milliseconds function implemented using a timer and a semaphore
 * to ensure that the code waits for the desired period but does not hold out 
 * other operations.
 *******************************************************************************/
void lgeBtDelayMilliseconds( Int16 waitTime )
{
	/* Stat the camera timer for the desired period */
	DmStartTimer( DM_TMR_BT_SEMA_TIMER, waitTime ); 

	/* Wait for the Camera timer expiry semaphore to complete */
	KiWaitSemaphore( KI_BT_SEMAPHORE );
}	 

#if defined (LGBX_INCLUDE)
void lgeLGBXDelayMilliseconds( Int16 waitTime )
{
  /* Stat the camera timer for the desired period */
  DmStartTimer( DM_TMR_BT_LGBX_TIMER, waitTime ); 

  /* Wait for the Camera timer expiry semaphore to complete */
  KiWaitSemaphore( KI_LGBX_SEMAPHORE );
}
#else
void lgeLGBXDelayMilliseconds( Int16 waitTime )
{
	//null
}
#endif

/****************************************************************************
* Hook Timer
****************************************************************************/

/* BT_MMI_LEEJINBAEK_070109 */
#if 0
static Boolean hookKeySend = FALSE;
static Boolean hookKeyVoiceSend = FALSE;

void startBTHOOKTimer(void)
{
	BT_DEBUG(("\r\n"));
	BT_DEBUG(("startBTHOOKTimer()"));
	
	if(hookKeySend == FALSE)
	{		
		//if(afshGetInCallFlag() == TRUE)
		{
			BT_DEBUG(("startBTHOOKTimer :: hookKeySend == FALSE"));
			hookKeyVoiceSend = FALSE;
		}
		hookKeySend = TRUE;

		//lgeBtTimer [ BT_TIMER_TYPE_HOOK_TIMER ].timeoutPeriod = MILLISECONDS_TO_TICKS(1500);
/* BT_L1_KIMSANGJIN_060818 */
		lgeBtMsStartTimer ( BT_TIMER_TYPE_HOOK_TIMER ,1500);  		
	}
}

void stopBTHOOKTimer(void)
{
	lgeBtStopTimer ( BT_TIMER_TYPE_HOOK_TIMER );  
}

void BTHOOKTimerExpiry(void)
{
	BT_DEBUG(("\r\n"));
	BT_DEBUG(("BTHOOKTimerExpiry()"));
	
	stopBTHOOKTimer();
	if(hookKeySend)
	{
		if(hookKeyVoiceSend == FALSE)
		{
			BT_DEBUG(("PadSendMmiKeypressInd (KEY_HOOK_ON)"));
		}
		else
		{
			BT_DEBUG(("PadSendMmiKeypressInd (KEY_HOOK_VOICE)"));
		}
		hookKeySend = FALSE;		
	}
}
#endif
/* end of BT_MMI_LEEJINBAEK_070109 */

/****************************************************************************
* Audio Open/Close Path Timer
****************************************************************************/
#if 1	/* LGE_BT_Tiburona_060831 */
void startBTAudioPathChangeTimer(Int16 msec)
{	
	//lgeBtTimer [ BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER ].timeoutPeriod = MILLISECONDS_TO_TICKS(msec);
	lgeBtMsStartTimer( BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER, msec); 
}

void stopBTAudioPathChangeTimer(void)
{
	lgeBtStopTimer ( BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER );  
}

void BTAudioPathChangeTimerExpiry(void)
{
	BT_DEBUG(("BTAudioPathChangeTimerExpiry"));
	lgeBtStopTimer ( BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER );

	if (BtFlag_IsAudioOpen() == TRUE)
	{
		BtStartMasterModePCM();
	}
	else
	{
		BtStopPCM();
	}
}
#else
static Boolean gIsPhonePath;

/* BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER*/
void startBTAudioPathChangeTimer(Boolean isPhonePath)
{	
	gIsPhonePath = isPhonePath;
	lgeBtTimer [ BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER ].timeoutPeriod = MILLISECONDS_TO_TICKS(20);
/* BT_L1_KIMSANGJIN_060818 */
	lgeBtMsStartTimer ( BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER ,20); 
}

void stopBTAudioPathChangeTimer(void)
{
	lgeBtStopTimer ( BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER );  
}

void BTAudioPathChangeTimerExpiry(void)
{
	BT_DEBUG(("BTAudioPathChangeTimerExpiry()"));
	lgeBtStopTimer ( BT_TIMER_TYPE_AUDIO_PATH_CHANGE_TIMER );
	//vgSetSpeechMode(TRUE);	
}
#endif

/****************************************************************************
* Tx Polling Timer
****************************************************************************/
/* LOUIS job00003_1 */

/* BCM_070410 JOB 00002 CHRIS */
extern Boolean TXSwIntStopState ;

extern Boolean  TXIRQ_SEMA;

Int8 CurrentTimeoutValue = 0;

/* LOUIS job00003_3 */
void startBTTxPollingTimer(Int8 timeout)
{	
    if( (timeout  == 0) || (TXSwIntStopState == TRUE) )
    {
        BT_DEBUG(("BT TIMER VALUE IS NULL OR TIMER STOPPED - CAN NOT START TIMER"));
        return;    
    }
    // Start timer only if RFCOMM buffers are available in POOL
    lgeBtStopTimer ( BT_TIMER_TYPE_TX_POLLING_TIMER );
    CurrentTimeoutValue  = timeout;
    lgeBtMsStartTimer( BT_TIMER_TYPE_TX_POLLING_TIMER ,timeout); 
}

void RestartBTTxPollingTimer(void)
{
/* LOUIS job00003_1 for DUN */
    if(CurrentTimeoutValue  == 0)
    {
        BT_DEBUG(("BT TIMER VALUE IS NULL - CAN NOT START TIMER"));
        return;    
    }

    if( TXSwIntStopState == TRUE)
    {
/* LOUIS job00003_1 for DUN */    
	   lgeBtStopTimer ( BT_TIMER_TYPE_TX_POLLING_TIMER );
 /* LOUIS job00003_2 removed */
       TXSwIntStopState = FALSE;
 /* LOUIS job00003_2 removed */
       lgeBtMsStartTimer( BT_TIMER_TYPE_TX_POLLING_TIMER ,CurrentTimeoutValue); 
}

}

// This function stops BT polling timer but keep the current timeout value
void stopBTTxPollingTimer(void)
{
    if( TXSwIntStopState == FALSE)
    {
/* LOUIS job00003_2 removed */
         TXSwIntStopState = TRUE;
/* LOUIS job00003_2 removed */
         lgeBtStopTimer ( BT_TIMER_TYPE_TX_POLLING_TIMER );  
    }
}

// CAUTION THIS FUNCTION MUST BE CALLED ONLY WHEN TIMER IS DEFINITIVELY STOPPED - DG CLOSE CALLOUT
// OTHERWISE CALL DIRECTLY stopBTTxPollingTimer
// This function stops BT polling timer and erase the current timeout value
void killBTTxPollingTimer(void)
{
      // BT_DEBUG(("KILL POLL TIMER"));
       CurrentTimeoutValue = 0;
       TXSwIntStopState = FALSE;
	lgeBtStopTimer ( BT_TIMER_TYPE_TX_POLLING_TIMER );  
}

void BTTxPollingTimerExpiry(void)
{
    if(TXIRQ_SEMA == TRUE)
    {
       //  BT_DEBUG(("TXIRQ_SEMA = TRUE"));
	lgeBtStopTimer ( BT_TIMER_TYPE_TX_POLLING_TIMER );

         startBTTxPollingTimer(CurrentTimeoutValue);
         if(TXSwIntStopState == FALSE)
             vgDataSentIntCallback(); // call vgDteifTxInterrupt
}	
    else
    {
    //    BT_DEBUG(("TXIRQ_SEMA = FALSE"));
        startBTTxPollingTimer(CurrentTimeoutValue);
//        lgeBtMsStartTimer( BT_TIMER_TYPE_TX_POLLING_TIMER ,4); 
}	

/* BCM_070410 JOB 00002 MACK */
//	lgeBtStopTimer ( BT_TIMER_TYPE_TX_POLLING_TIMER );
//	ReEntryMuxContextFromBTSPPnDUN(); /* LOUIS job00002 */

//	M_EnableSwInt(TxDataSWInt);
//	M_RaiseSwInt(TxDataSWInt);	
/* end of BCM_070410 JOB 00002 MACK */
}	

/* end of BCM_070410 JOB 00002 CHRIS */

/****************************************************************************
* Debug Display LCD Timer
****************************************************************************/

void startBTDebugDisplayTimer(void)
{
	//lgeBtTimer [BT_TIMER_TYPE_DEBUG_DISPLAY_TIMER ].timeoutPeriod = MILLISECONDS_TO_TICKS(500);
/* BT_L1_KIMSANGJIN_060818 */
	lgeBtMsStartTimer (BT_TIMER_TYPE_DEBUG_DISPLAY_TIMER,500);	
}

void stopBTDebugDisplayTimer(void)
{
	lgeBtStopTimer ( BT_TIMER_TYPE_DEBUG_DISPLAY_TIMER );  
}

void BTDebugDisplayTimerExpiry(void)
{
	stopBTDebugDisplayTimer();
}

/****************************************************************************
* Test Timer
****************************************************************************/

void startBTTestTimer(void)
{
	//lgeBtTimer [BT_TIMER_TYPE_TEST_TIMER ].timeoutPeriod = MILLISECONDS_TO_TICKS(500);
/* BT_L1_KIMSANGJIN_060818 */
	lgeBtMsStartTimer (BT_TIMER_TYPE_TEST_TIMER,500);
}

void stopBTTestTimer(void)
{
	lgeBtStopTimer ( BT_TIMER_TYPE_TEST_TIMER );  
}

void BTTestTimerExpiry(void)
{
	startBTTestTimer();
}

/****************************************************************************
* Timer for Bluetooth operation timeout
****************************************************************************/

Int16 gBtTimeOutTimerPeriod = 60; /* KANE_BT job050323 for BT On/Off */

void startBTTimeOutTimer(void)
{
	BT_DEBUG(("startBTTimeOutTimer(%d)", gBtTimeOutTimerPeriod));
		/* 20 seconds */
	//lgeBtTimer [BT_TIMER_TYPE_TIMEOUT_TIMER].timeoutPeriod = SECONDS_TO_TICKS(gBtTimeOutTimerPeriod);
/* BT_L1_KIMSANGJIN_060818 */
	lgeBtStartTimer (BT_TIMER_TYPE_TIMEOUT_TIMER,gBtTimeOutTimerPeriod);
}

void stopBTTimeOutTimer(void)
{
	BT_DEBUG(("stopBTTimeOutTimer()"));
	lgeBtStopTimer ( BT_TIMER_TYPE_TIMEOUT_TIMER );  
}

void BTTimeOutTimerExpiry(void)
{
	BT_DEBUG(("BTTimeOutTimerExpiry()"));
	#if 0
	if (BtFlag_GetTimeOutFlag() == TRUE)
	{
		BtFlag_SetTimeOutFlag(FALSE);
		/*BtShutdownTask();*/
	}
	#endif
}

/* LGE_MERGE_BLUETOOTH : 2004.12.30 SKLEE inserts for BT operation timeout */
/****************************************************************************
* Timer for Bluetooth operation timeout
****************************************************************************/

/*
h05: 
	BT_SDP_READ_SERVICE_LIST_CFM
	
h06: 
	BT_SDP_CANCEL_DISCOVERY_CFM
	
h07: 	
	BT_AGW_CONNECT_IND
	BT_AGW_DISCONNECT_IND
	BT_HFG_CONNECT_IND
	BT_HFG_DISCONNECT_IND

h11:
	BT_SDP_BOND_CFM

h15:
	BT_OPC_SEARCH_CFM
*/

#define MAX_BT_ON_RETRY_CNT		2

static Int16 gRetryCnt;

static void InitRetryCnt(void)
{
	gRetryCnt = 0;
	BT_DEBUG(("InitRetryCnt gRetryCnt=%d", gRetryCnt));
}

static void IncreaseRetryCnt(void)
{
	gRetryCnt++;
	BT_DEBUG(("IncreaseRetryCnt gRetryCnt=%d", gRetryCnt));
}

Boolean RetryBtOn(void)
{
	if (gRetryCnt < MAX_BT_ON_RETRY_CNT)
		return TRUE;
	else
		return FALSE;
}


/* BT_COMMON_KIMSANGJIN_070920 noti_011216 */
Int16 gBtOnTimerPeriod = 5;

void InitBtOnTimer(void)
{
	BT_DEBUG(("InitBtOnTimer()"));
	InitRetryCnt();
}

void StartBtOnTimer(void)
{
	BT_DEBUG(("StartBtOnTimer(%d)", gBtOnTimerPeriod));
       /* BT_COMMON_KIMSANGJIN_070920 noti_011216*/
	lgeBtTimer [BT_TIMER_TYPE_BT_ON_TIMER].timeoutPeriod = SECONDS_TO_TICKS(gBtOnTimerPeriod);
	lgeBtStartTimer (BT_TIMER_TYPE_BT_ON_TIMER,gBtOnTimerPeriod);
}

void StopBtOnTimer(void)
{
	BT_DEBUG(("StopBtOnTimer()"));
	/* BT_COMMON_KIMSANGJIN_070920 noti_011216*/
	lgeBtStopTimer ( BT_TIMER_TYPE_BT_ON_TIMER );  
}

void HandleBtOnTimerExpiry(void)
{
	BT_DEBUG(("HandleBtOnTimerExpiry()"));
	
	/*BtFlag_SetShutdownFromTimer(TRUE);*/
	/*BtShutdownTask();*/
}
void StartBtPopUpTimer(void)
{
	lgeBtStartTimer (BT_TIMER_TYPE_BT_POPUP_TIMER,1);
}

void StartBtPCMTimer(void)
{
	lgeBtStartTimer (BT_TIMER_TYPE_BT_PCM_TIMER, 2); /*BT_COMMON_KIMSANGJIN_080102 noti_011248 : change from 1ms to 2ms*/
}

#endif /* LGE_L1_BLUETOOTH */
/* END OF FILE */
