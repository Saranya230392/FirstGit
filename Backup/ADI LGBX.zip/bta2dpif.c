/*******************************************************************************

			Copyright by LG Electronics Inc.

FILE
			     bta2dpif.c    

DESCRIPTION:
			     A2DP Interface functions for LeMans

History:
2006/09/13 $Revision: 1.0 $  :: $ release by SONG JONG-HYUK(TTPCOM Korea)
							 modified by KANG HYUNG-WOOK
**************************************************************************/

#define MODULE_NAME "BTA2DPIF"

///////////////////////////////////////////////////////////////////////////
#if defined(LGE_L1_BLUETOOTH)
///////////////////////////////////////////////////////////////////////////

#if defined(LGE_LEMANS_BLUETOOTH)

/****************************************************************************
* Include Files
****************************************************************************/
#if !defined(APPLAYER_H)
#   include "applayer.h"
#endif

#if !defined (SYSTEM_H)
#  include <system.h>
#endif

#if !defined (KERNEL_H)
#  include <kernel.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if !defined(BTA2DPIF_H)
#include "bta2dpif.h"
#endif

#if !defined(UDEBUG_H)
#include "uDebug.h"
#endif

#if defined(WAV_SAVE) /* JHS2 13Sep2006 */
#if !defined(BTFSIF_H)
#include "btfsif.h"
#endif

#if !defined(MMAC_TYP_H)
#include "mmac_typ.h"
#endif

#if !defined(ABFS_TYP_H)
#include "abfs_typ.h"
#endif

#if !defined(FS_IO_H)
#include "fs_io.h"
#endif

#if !defined(FS_IO_H)
#include "afmusic_l1mm.h"
#endif

#endif /* WAV_SAVE */

#if !defined(LGBX_INCLUDE)
#if defined(LGE_BRCM_BLUETOOTH)
#if !defined(DATA_TYPES_H)
#include "data_types.h"
#endif
#include "bd.h"
#include "btapp_aa.h"
#endif
#endif

/****************************************************************************
* Manifest Constants / Defines
****************************************************************************/

/****************************************************************************
* Type Definitions
****************************************************************************/
#if defined(WAV_SAVE) /* JHS2 13Sep2006 */
typedef struct
{
	char		ChunkID[4];
	Int32	ChunkSize;
	char		Format[4];
} chunk_desc_type;

typedef struct
{
	char		Subchunk1ID[4];
	Int32	Subchunk1Size;
	Int16	AudioFormat;
	Int16	NumChannels;
	Int32	SampleRate;
	Int32	ByteRate;
	Int16	BlockAlign;
	Int16	BitsPerSample;
} format_subchunk_type;

typedef struct
{
	char		Subchunk2ID[4];
	Int32	Subchunk2Size;
} data_subchunk_type;

typedef struct
{
    chunk_desc_type         	chunk_desc;
    format_subchunk_type    fmt_subchunk;
    data_subchunk_type      data_subchunk;
} wav_format_header_type;
#endif /* WAV_SAVE */

/****************************************************************************
* Variables
****************************************************************************/
#if defined(WAV_SAVE) /* JHS2 13Sep2006 */
wav_format_header_type wave_file;
Int32 wave_data_size = 0;
FileID *wavefile_p=PNULL;

extern SignedInt16 tempBuff[BT_A2DP_PCM_BUFFER_SIZE];
extern SignedInt32 tempBuffLength;
extern SignedInt32 readLength;
extern SignedInt32 writeLength;

static volatile BtA2dpBuffer btA2dpBuffer;
volatile BtA2dpBuffer* const btA2dpBuffer_p = &(btA2dpBuffer);

#include "target.h"

#if defined BTUI_AV_DATA_FROM_MM_CHIP && BTUI_AV_DATA_FROM_MM_CHIP == TRUE
#if !defined(LGBX_INCLUDE)
extern void  btui_av_start_from_mm_chip(void);
#endif
#endif

#if defined(LGE_BRCM_BLUETOOTH) /* for BTE */
//Boolean SBCProcessStarted = FALSE;
Boolean FF_REW_state_flag = FALSE;
Boolean AV_restart_delay = TRUE;		
#endif /* LGE_BRCM_BLUETOOTH */
#endif /* WAV_SAVE */

/****************************************************************************
* Extern Functions
****************************************************************************/

/****************************************************************************
* Local Function Prototypes
****************************************************************************/

/****************************************************************************
* Local Functions
****************************************************************************/

/****************************************************************************
* Global Functions
****************************************************************************/
#if 1 /* Tiburona_071025 For Bluetooth A2DP */
static Int32 gAudioSamplingRate=0;
void BtA2dpSetSamplingRate(Int32 audioSamplingRate)
{
	BT_DEBUG(("\x1b[33m BtA2dpSetSamplingRate() audioSamplingRate=%d \x1b[0m", audioSamplingRate));
	gAudioSamplingRate = audioSamplingRate;
}

Int32 BtA2dpGetSamplingRate(void)
{
	//BT_DEBUG(("\x1b[33m BtA2dpGetSamplingRate() gAudioSamplingRate=%d \x1b[0m", gAudioSamplingRate));
	return (gAudioSamplingRate);
}

static Int16 gNumAudioChannel=0;
void BtA2dpSetNumAuioChannel(Int16 numAudioChannels)
{
	BT_DEBUG(("\x1b[33m BtA2dpSetNumAuioChannel() numAudioChannels=%d \x1b[0m", numAudioChannels));
	gNumAudioChannel = numAudioChannels;
}

Int16 BtA2dpGetNumAuioChannel(void)
{
	//BT_DEBUG(("\x1b[33m BtA2dpGetNumAuioChannel() gNumAudioChannel=%d \x1b[0m", gNumAudioChannel));
	return (gNumAudioChannel);
}

static SignedInt32 gNumSamplesToTransfer=0;
void BtA2dpSetNumSamplesToTransfer(SignedInt32 numSamplesToTransfer)
{
	gNumSamplesToTransfer = numSamplesToTransfer;
}

SignedInt32 BtA2dpGetNumSamplesToTransfer(void)
{
	//BT_DEBUG(("BtA2dpGetNumSamplesToTransfer() gNumSamplesToTransfer=%d", gNumSamplesToTransfer));
	return (gNumSamplesToTransfer);
}
#endif

/* LeMans_BT_Tiburona_060914 */
#if defined(WAV_SAVE) /* JHS2 13Sep2006 */
/****************************************************************************
 * Test Utilities
 *     : used for verifying A2DP API operations(). it's very useful, don't delete
****************************************************************************/
void save_wav_format_info(SignedInt32 mediaLength_ms, Int32 audioSamplingRate, Int16 numAudioChannels)
{
    char fileName1[MAX_FILE_PATH_LEN];
    char fileName2[MAX_FILE_PATH_LEN];
    char extension[10]=".wav";
    Int8 cnt=0;
    Int16 access=0, perms=0;

    wave_file.chunk_desc.ChunkID[0] = 'R';
    wave_file.chunk_desc.ChunkID[1] = 'I';
    wave_file.chunk_desc.ChunkID[2] = 'F';
    wave_file.chunk_desc.ChunkID[3] = 'F';

    wave_file.chunk_desc.ChunkSize = 4 + 24 + 8;
    wave_file.chunk_desc.Format[0] = 'W';
    wave_file.chunk_desc.Format[1] = 'A';
    wave_file.chunk_desc.Format[2] = 'V';
    wave_file.chunk_desc.Format[3] = 'E';

    wave_file.fmt_subchunk.Subchunk1ID[0] = 'f';
    wave_file.fmt_subchunk.Subchunk1ID[1] = 'm';
    wave_file.fmt_subchunk.Subchunk1ID[2] = 't';
    wave_file.fmt_subchunk.Subchunk1ID[3] = ' ';
    wave_file.fmt_subchunk.Subchunk1Size = 16;        
    wave_file.fmt_subchunk.AudioFormat = 1;
    wave_file.fmt_subchunk.NumChannels = numAudioChannels;
    wave_file.fmt_subchunk.SampleRate = audioSamplingRate;
    wave_file.fmt_subchunk.BitsPerSample = 16;
    wave_file.fmt_subchunk.ByteRate = audioSamplingRate * numAudioChannels * wave_file.fmt_subchunk.BitsPerSample / 8;
    wave_file.fmt_subchunk.BlockAlign = numAudioChannels * wave_file.fmt_subchunk.BitsPerSample / 8;

    wave_file.data_subchunk.Subchunk2ID[0] = 'd';
    wave_file.data_subchunk.Subchunk2ID[1] = 'a';
    wave_file.data_subchunk.Subchunk2ID[2] = 't';
    wave_file.data_subchunk.Subchunk2ID[3] = 'a';
    wave_file.data_subchunk.Subchunk2Size = 0;

    wave_data_size = 0;

	memset(fileName1, 0x00, sizeof(char)*(MAX_FILE_PATH_LEN));

	strcpy(fileName1, "e:/others/pcm");
	for(cnt=1; cnt<100; cnt++)
	{
		memset(fileName2, 0x00, sizeof(char)*(MAX_FILE_PATH_LEN));	
		sprintf((char *)fileName2, "%s_%d%s", fileName1, cnt, extension);

		if(Btfs_exists(fileName2) == FALSE) break;
	}

	wavefile_p = Btfs_Open("e:/others/pcm.wav", "wb");
	wavefile_p = Btfs_Open(fileName2, "wb");	
	Btfs_Write(wavefile_p, (void *)&wave_file, sizeof(wav_format_header_type)*1);
}	

void save_wav_data(void)
{
    readLength = BtA2dpPcmDataRead(tempBuff, tempBuffLength);
    Btfs_Write(wavefile_p, (void *)&tempBuff, sizeof(SignedInt16)*(readLength / 2));
    wave_data_size += readLength;
    BT_DEBUG(("write=%d, wave_data_size=%d", readLength, wave_data_size));
    wave_file.chunk_desc.ChunkSize += wave_data_size;
    wave_file.data_subchunk.Subchunk2Size = wave_data_size;
    BT_DEBUG(("ChunkSize=%d, Subchunk2Size=%d", wave_file.chunk_desc.ChunkSize, wave_file.data_subchunk.Subchunk2Size));
    Btfs_seek(wavefile_p, 0, ABFS_FSEEK_SET);
    Btfs_Write(wavefile_p, (void *)&wave_file, sizeof(wav_format_header_type)*1);
    Btfs_Close(wavefile_p);
}

/****************************************************************************
 * Function: BtA2dpBufferInitialise
 *
 * Parameters:
 *				NONE
 * Description:
 * 	Before MP3 decording, call this function and initialize buffer(btA2dpBuffer).
 * ***************************************************************************/
void BtA2dpBufferInitialise(void) /* JHS2/ADD/20060907 */
{
	btA2dpBuffer_p->wrIndex				= 0;
	btA2dpBuffer_p->rdIndex                   	= 0;
	btA2dpBuffer_p->length                    	= (SignedInt32) BT_A2DP_PCM_BUFFER_SIZE;
	btA2dpBuffer_p->highWaterMark            = (SignedInt32) BT_A2DP_PCM_BUFFER_HI_WM;
	btA2dpBuffer_p->lowWaterMark     		= (SignedInt32) BT_A2DP_PCM_BUFFER_LO_WM;
	btA2dpBuffer_p->mediaLength_ms		= 0;
	btA2dpBuffer_p->audioSamplingRate	= 0;
	btA2dpBuffer_p->numAudioChannels	= 0;
	btA2dpBuffer_p->bFlowOn                   	= FALSE;
	BT_DEBUG(("BtA2dpBufferInitialise() called"));
}

/****************************************************************************
 * Function: BtA2dpNotifyCodecSetupComplete
 *
 * Parameters:
 *				NONE
 * Description:
 * 	After Audio codec set up, this function called.
 *    This function inform of playing MP3 file's sampling rate and channel number.
 * ***************************************************************************/
void BtA2dpNotifyCodecSetupComplete(SignedInt32 mediaLength_ms, Int32 audioSamplingRate, Int16 numAudioChannels)
{
	BtA2dpBufferInitialise();
	
	btA2dpBuffer_p->mediaLength_ms = mediaLength_ms;
	btA2dpBuffer_p->audioSamplingRate = audioSamplingRate;
	btA2dpBuffer_p->numAudioChannels = numAudioChannels;
	BT_DEBUG(("BtA2dpNotifyCodecSetupComplete() mediaLength_ms=%d, audioSamplingRate=%d, numAudioChannels=%d", mediaLength_ms, audioSamplingRate, numAudioChannels));

	save_wav_format_info(mediaLength_ms, audioSamplingRate, numAudioChannels);
}

/****************************************************************************
 * Function: BtA2dpNotifyAudioChannelEnabled
 *
 * Parameters:
 *				NONE
 * Description:
 * 	This function inform of Audio codec decoding start.
 * 	From now on, you call BtA2dpPcmDataRead() function and you can get data.
 * ***************************************************************************/     
void BtA2dpNotifyAudioChannelEnabled(void)
{
	BT_DEBUG(("BtA2dpNotifyAudioChannelEnabled() called"));
}

/****************************************************************************
 * Function: BtA2dpNotifyMmacEndOfData
 *
 * Parameters:
 *				NONE
 * Description:
 * 	This function will be called, 
 *	when MP3 file decoding finished(At that time, PCM data copy to buffer).
 * ***************************************************************************/     
void BtA2dpNotifyMmacEndOfData(void)
{
	save_wav_data();
	BT_DEBUG(("BtA2dpNotifyMmacEndOfData() called"));
}

void BtA2dpPcmBufferWmCheck(void)
{
    SignedInt32 numSamplesInPcmBuffer = 0;

    /* Get the number of samples available in the MMAC output buffer. */
    numSamplesInPcmBuffer = btA2dpBuffer_p->wrIndex - btA2dpBuffer_p->rdIndex;
    MMAC_WRAP_CIRC_INDEX (numSamplesInPcmBuffer, btA2dpBuffer_p->length);

#if 1 /* Tiburona_071116 */
    if((numSamplesInPcmBuffer > btA2dpBuffer_p->highWaterMark) && (btA2dpBuffer_p->bFlowOn == FALSE))
    {
        btA2dpBuffer_p->bFlowOn = TRUE;
        mmacA2dpDecoderPauseReq();
	  BT_DEBUG(("BtA2dpPcmBufferWmCheck() tempBuffLength=%d", tempBuffLength));
        readLength = BtA2dpPcmDataRead(tempBuff, tempBuffLength);
	  BT_DEBUG(("BtA2dpPcmBufferWmCheck() readLength=%d", readLength));
	  writeLength = Btfs_Write(wavefile_p, (void *)&tempBuff, sizeof(SignedInt16)*(readLength / 2));
        wave_data_size += readLength;
        BT_DEBUG(("buffer=%d, readLength(From PCM buffer)=%d, writeLength(To FS)=%d, wave_data_size=%d", numSamplesInPcmBuffer, readLength, writeLength, wave_data_size));
    }

    if((numSamplesInPcmBuffer < btA2dpBuffer_p->lowWaterMark) && (btA2dpBuffer_p->bFlowOn == TRUE))
    {
        btA2dpBuffer_p->bFlowOn = FALSE;
        mmacA2dpDecoderResumeReq();
    }
#else
#if defined BTUI_AV_DATA_FROM_MM_CHIP && BTUI_AV_DATA_FROM_MM_CHIP == TRUE
    if((SBCProcessStarted == TRUE) && (numSamplesInPcmBuffer >= btA2dpBuffer_p->highWaterMark))
    {
	    BT_DEBUG(("High watermark reached"));
#if !defined(LGBX_INCLUDE)
           btui_av_start_from_mm_chip();
#endif
       SBCProcessStarted = FALSE;
    }
#endif
#endif	
}

Int16 BtA2dpNumChannels(void)
{
    return(btA2dpBuffer_p->numAudioChannels);
}

Int16 BtA2dpSamplingFrequency(void)
{
    return(btA2dpBuffer_p->audioSamplingRate);
}

Boolean BtA2dpPcmCheckDataReady(void)
{
    SignedInt32 numSamplesInPcmBuffer = 0;
    /* Get the number of samples available in the MMAC output buffer. */
    numSamplesInPcmBuffer = btA2dpBuffer_p->wrIndex - btA2dpBuffer_p->rdIndex;
    MMAC_WRAP_CIRC_INDEX (numSamplesInPcmBuffer, btA2dpBuffer_p->length);
	
    if(numSamplesInPcmBuffer < btA2dpBuffer_p->lowWaterMark) 
    {
        if(AV_restart_delay == FALSE)
        {
            return TRUE;
        }
        else
        {
            return FALSE;        
        } 
   }
    else
    {
         if((AV_restart_delay ==  FALSE) && (FF_REW_state_flag == FALSE) && (numSamplesInPcmBuffer > btA2dpBuffer_p->highWaterMark))
        {
               AV_restart_delay = TRUE;        
        }
        return TRUE;
    }
}
Int16* BtA2dpPcmGetBuf(void)
{
    Int16* pBuf;

    if(btA2dpBuffer_p->rdIndex > btA2dpBuffer_p->wrIndex)
    {
        if((btA2dpBuffer_p->rdIndex + btA2dpBuffer_p->lowWaterMark) > btA2dpBuffer_p->length)
        {
             BT_DEBUG(("ERROR - WRAP"));
        }
    }
    pBuf = (UINT16*) &btA2dpBuffer_p->buffer[btA2dpBuffer_p->rdIndex];
    btA2dpBuffer_p->rdIndex += btA2dpBuffer_p->lowWaterMark;
    MMAC_WRAP_CIRC_INDEX (btA2dpBuffer_p->rdIndex, btA2dpBuffer_p->length);
    //BT_DEBUG(("rdi = %d",btA2dpBuffer_p->rdIndex));

    return pBuf;
}

Int32 BtA2dpPcmDataRead(SignedInt16* buff, SignedInt32 buffLength)
{
    SignedInt32 numSamplesInPcmBuffer = 0;
    SignedInt32 numTotalSamplesToBeCopied = 0;
    SignedInt32 numSamplesToPcmCircBuffEnd = 0;

    numSamplesInPcmBuffer = btA2dpBuffer_p->wrIndex - btA2dpBuffer_p->rdIndex;
    MMAC_WRAP_CIRC_INDEX (numSamplesInPcmBuffer, btA2dpBuffer_p->length);
    
    if (numSamplesInPcmBuffer > buffLength / 2)
    {
      numTotalSamplesToBeCopied = buffLength / 2;
    }
    else
    {
      numTotalSamplesToBeCopied = numSamplesInPcmBuffer;
    }

    /* Transfer data to the audio downlink buffer. */
    if (btA2dpBuffer_p->wrIndex > btA2dpBuffer_p->rdIndex)
    {
      memcpy(buff, (SignedInt16*)&btA2dpBuffer_p->buffer[btA2dpBuffer_p->rdIndex], 
        numTotalSamplesToBeCopied * sizeof (SignedInt16));
    }
    else
    {
      numSamplesToPcmCircBuffEnd = btA2dpBuffer_p->length - btA2dpBuffer_p->rdIndex;

      if (numSamplesToPcmCircBuffEnd > numTotalSamplesToBeCopied)
      {
        memcpy(buff, (SignedInt16*)&btA2dpBuffer_p->buffer[btA2dpBuffer_p->rdIndex], 
            numTotalSamplesToBeCopied * sizeof (SignedInt16));
      }
      else
      {
        memcpy(buff, (SignedInt16*)&btA2dpBuffer_p->buffer[btA2dpBuffer_p->rdIndex], 
            numSamplesToPcmCircBuffEnd * sizeof (SignedInt16));
        memcpy(&buff[numSamplesToPcmCircBuffEnd],
            (SignedInt16*)&btA2dpBuffer_p->buffer[0], 
            (numTotalSamplesToBeCopied - numSamplesToPcmCircBuffEnd) * sizeof (SignedInt16));
      }
    }
	
#if 1 /* Tiburona_071116 */
	btA2dpBuffer_p->rdIndex += numTotalSamplesToBeCopied;
	MMAC_WRAP_CIRC_INDEX (btA2dpBuffer_p->rdIndex, btA2dpBuffer_p->length);
	
	BtA2dpPcmBufferWmCheck();
#else
   if((AV_restart_delay ==  FALSE) || (FF_REW_state_flag == TRUE))
   {
       if(numTotalSamplesToBeCopied >= btA2dpBuffer_p->lowWaterMark)
      {
           btA2dpBuffer_p->rdIndex += numTotalSamplesToBeCopied;
           MMAC_WRAP_CIRC_INDEX (btA2dpBuffer_p->rdIndex, btA2dpBuffer_p->length);
      }
   }
   else
   {
        btA2dpBuffer_p->rdIndex += numTotalSamplesToBeCopied;
        MMAC_WRAP_CIRC_INDEX (btA2dpBuffer_p->rdIndex, btA2dpBuffer_p->length);
   }
#endif

    return numTotalSamplesToBeCopied * 2;
}

void mmacA2dpDecoderPauseReq(void)
{
    //L1MmSendMusicPauseReqSig(UNKNOWN_TASK_ID, 0);
    BT_DEBUG(("BtA2dpDecoderPauseReq() called"));
    afMusicSendMusicPauseReqSig(2);
}

void mmacA2dpDecoderResumeReq(void)
{
    //L1MmSendMusicResumeReqSig(UNKNOWN_TASK_ID, 0);
    BT_DEBUG(("BtA2dpDecoderResumeReq() called"));
// BT_A2DP LEEJINBAEK 20071214 : AVRCP audio path control
    afMusicSendMusicResumeReqSig(2, TRUE);	
}

void transferDataToA2dpPcmbuffer (SignedInt16  *srcBuffer_p, SignedInt32 numSamplesToTransfer)
{
  SignedInt32      destBuffer_wrIndex;
  SignedInt32      numSamplesToDestBuffEnd;
  SignedInt16     *src = srcBuffer_p; 
  SignedInt32      freeSpaceInBtA2dpBuffer;
  
  if (numSamplesToTransfer > 0)
  {
    if (btA2dpBuffer_p->rdIndex == btA2dpBuffer_p->wrIndex)
    {
      freeSpaceInBtA2dpBuffer = btA2dpBuffer_p->length;
    }
    else
    {
      freeSpaceInBtA2dpBuffer = (btA2dpBuffer_p->rdIndex - btA2dpBuffer_p->wrIndex);
      MMAC_WRAP_CIRC_INDEX (freeSpaceInBtA2dpBuffer, btA2dpBuffer_p->length);
    }

#if 1
    if(freeSpaceInBtA2dpBuffer < numSamplesToTransfer)
    {
    	BT_DEBUG(("freeSpaceInBtA2dpBuffer=%d, numSamplesToTransfer=%d", freeSpaceInBtA2dpBuffer, numSamplesToTransfer));		
    }
#else	
    DevCheck(freeSpaceInBtA2dpBuffer >= numSamplesToTransfer, freeSpaceInBtA2dpBuffer, numSamplesToTransfer, 0);
#endif

    numSamplesToDestBuffEnd = btA2dpBuffer_p->length - btA2dpBuffer_p->wrIndex;
      
    if (numSamplesToDestBuffEnd > numSamplesToTransfer)
    {
      memcpy ((SignedInt16*)&btA2dpBuffer_p->buffer[btA2dpBuffer_p->wrIndex],
              src,
              (SignedInt16)numSamplesToTransfer * sizeof (SignedInt16));
      
      /* Increment the destination buffer write index. */
      destBuffer_wrIndex    = btA2dpBuffer_p->wrIndex;
      destBuffer_wrIndex   += numSamplesToTransfer;
      btA2dpBuffer_p->wrIndex = destBuffer_wrIndex;
    }
    else
    {
      memcpy ((SignedInt16*)&btA2dpBuffer_p->buffer[btA2dpBuffer_p->wrIndex],
              src,
              (SignedInt16)numSamplesToDestBuffEnd * sizeof (SignedInt16));

      memcpy ((SignedInt16*)&btA2dpBuffer_p->buffer[0],
              &src[numSamplesToDestBuffEnd],
              (SignedInt16)(numSamplesToTransfer - numSamplesToDestBuffEnd) * sizeof (SignedInt16));

      /* Increment the destination buffer write index. */
      btA2dpBuffer_p->wrIndex = numSamplesToTransfer - numSamplesToDestBuffEnd;
    }
//    if(SBCProcessStarted == FALSE)
    BtA2dpPcmBufferWmCheck();
  }
}

#endif /* WAV_SAVE */

#endif /* LGE_LEMANS_BLUETOOTH */

#endif /* LGE_L1_BLUETOOTH */
