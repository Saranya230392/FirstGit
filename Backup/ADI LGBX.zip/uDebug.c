/************************************************

	For Debug Using UART Directly  KANE_BT for GS3
	
*************************************************/

/****************************************************************************
* Include Files
****************************************************************************/

#if defined(LGE_L1_BLUETOOTH)

#if !defined (SYSTEM_H)
#include <system.h>
#endif

#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <Kiamxos.h>
#include  <cjzzz.h>

#if defined(UPGRADE_500_PLATFORM)
#include <pdgpioassign500.h>
#include <Pdgpio.h>
#elif defined(UPGRADE_430_PLATFORM)
#include <Dlgpio.h>
#endif

#if !defined (UDEBUG_H)
#include "udebug.h"
#endif

#if !defined (FS_IO_H)
#include  <Fs_io.h>
#endif

/****************************************************************************
* Mainfest Constants / Defines
****************************************************************************/
#define BUF_SIZE			128

/****************************************************************************
* Type Definitions
****************************************************************************/

/****************************************************************************
* Variables
****************************************************************************/
Boolean gDebugFlag = FALSE; /* default: FALSE  */

#if defined (LGBX_INCLUDE)
Boolean gBxDebugFlag = FALSE; /* default: FALSE  */
#endif

#if defined(LGE_BRCM_BLUETOOTH)
Boolean gBcmDebugFlag = FALSE; /* default: FALSE  */
#endif

#if defined(LGE_CSR_BLUETOOTH)
Boolean gCsrDebugFlag = FALSE; /* default: FALSE  */
#endif

static CJ_ID _os_guard_printf;

/****************************************************************************
* Functions
****************************************************************************/

static void CREATE_CRITICAL_SECTION(void)
{
    cjsmcreate(&_os_guard_printf, "BTPR", 1);
}
static void DELETE_CRITICAL_SECTION(void)
{
    cjsmdelete(_os_guard_printf);
}

static void ENTER_PRINTF_SECTION(void)
{
    cjsmwait(_os_guard_printf, KI_AMX_PRIORITY_NORMAL, KI_AMX_TIMEOUT_INFINITE_WAIT);
}

static void LEAVE_PRINTF_SECTION(void)
{
    cjsmsignal(_os_guard_printf);
}


void            bt_os_startup(void)
{
	CREATE_CRITICAL_SECTION();
}
void            bt_os_shutdown(void)
{
	DELETE_CRITICAL_SECTION();
}


#if defined(LGE_LEMANS_BLUETOOTH)
#if 0 /* Tiburona_070326 defined(HW_REV_D) || defined(EMMI_ON_PORT_4) */ /* Tiburona_070115*/ 
static Int16 ReadGSPDataPortStatus (void)
{
	return *((volatile Int16 *) (uGSP_BASE + 0x0c));
}

static void WriteGSPDataPortStatus (Int16 status)
{
	*((volatile Int16 *) uGSP_ISTAT_REG) = status;
}

static void ClearGSPDataPortErrors(void)
{
	WriteGSPDataPortStatus(*((volatile Int16 *)uGSP_ISTAT_REG)
	   & ~(uGSP_ISTAT_ERRLCK | uGSP_ISTAT_OVRRUN));
}
#endif /* EMMI_ON_PORT_4 */
#elif defined (LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)
static Int16 ReadGSPDataPortStatus (void)
{
	return *((volatile Int16 *) (uGSP_BASE + 0x0c));
}

static void WriteGSPDataPortStatus (Int16 status)
{
	*((volatile Int16 *) uGSP_ISTAT_REG) = status;
}

static void ClearGSPDataPortErrors(void)
{
	WriteGSPDataPortStatus(*((volatile Int16 *)uGSP_ISTAT_REG)
	   & ~(uGSP_ISTAT_ERRLCK | uGSP_ISTAT_OVRRUN));
}
#endif /*LGE_ATLAS_BLUETOOTH || LGE_ATLAS_2H_BLUETOOTH*/

void GSPData_PutByte (Int8 byte)
{

}

void GSPDebug_PutByte (Int8 byte)
{
	Int16 status=0;

#if((!defined(BT_DEBUG_ENABLE)) || defined(BT_DEBUG_GENIE))
	return;
#endif

	//if (BtGetDebugFlag() == FALSE) return; 

#if defined(LGE_LEMANS_BLUETOOTH)

#if 0 /* Tiburona_070326 defined(HW_REV_D) || defined(EMMI_ON_PORT_4) */ /* Tiburona_070115*/ 
	for (;;)
	{
	   status = ReadGSPDataPortStatus();
	   if (status & (uGSP_ISTAT_ERRLCK | uGSP_ISTAT_OVRRUN))
		  ClearGSPDataPortErrors();
	   if (status & uGSP_ISTAT_TBRE)
	   {
		  *((volatile Int8 *) uGSP_TBR_REG) = byte;
		  return;
	   }
	}
#else /* EMMI_ON_PORT_4 */
	do {
		status = vinput_w(uUART_ISTAT);
	} while ( (status & uGSP_ISTAT_TBRE) !=uGSP_ISTAT_TBRE);

	voutput_b(uUART_TBR, byte);
#endif /* EMMI_ON_PORT_4 */

#elif defined(LGE_ATLAS_BLUETOOTH) || defined(LGE_ATLAS_2H_BLUETOOTH)

	for (;;)
	{
	   status = ReadGSPDataPortStatus();
	   if (status & (uGSP_ISTAT_ERRLCK | uGSP_ISTAT_OVRRUN))
		  ClearGSPDataPortErrors();
	   if (status & uGSP_ISTAT_TBRE)
	   {
		  *((volatile Int8 *) uGSP_TBR_REG) = byte;
		  return;
	   }
	}
#endif /*LGE_LEMANS_BLUETOOTH*/	
}
void DebugLn(const char *format,...)
{
	static char buf[DEBUG_BUF_SIZE+1];
	va_list ap;
	Int16 i ,len;

#if !defined(BT_DEBUG_ENABLE)
	return;
#endif

	if (BtGetDebugFlag() == FALSE) return; 

	va_start (ap, format);
	vsprintf (buf, format, ap);
	va_end (ap);
	/* 20071009_Bluetooth_Whitebox (LEEJINBAEK) 
	 * Overrun of static array "buf" of size 1025 at position 1025 with index variable "1025"
	 * chage init position 'DEBUG_BUF_SIZE+1' to 'DEBUG_BUF_SIZE'
	 */
	buf[DEBUG_BUF_SIZE] = '\0';

	len =strlen(buf);
/* BT_COMMON_KIMSANGJIN_070329 noti_011042 */
	buf[DEBUG_BUF_SIZE] = '\0';
	if(len>DEBUG_BUF_SIZE) len=DEBUG_BUF_SIZE;	
	
	for (i = 0; i < len; i++)
	GSPDebug_PutByte(buf[i]);

	GSPDebug_PutByte('\r');
	GSPDebug_PutByte('\n');
}

#if defined(LGBX_INCLUDE)
void LGBX_debug(const char *format,...)
{
	Int16 i;
	Int16 len;
	static char buf[DEBUG_BUF_SIZE+1];
	va_list ap;

#if ((!defined(LGBX_DEBUG_ENABLE)) || (!defined(BT_DEBUG_ENABLE)))
	return;
#endif

	if (BtGetBxDebugFlag() == FALSE) return; 	/* BT_L1_KIMSANGJIN_061226 noti_010205*/

#if defined(LGE_LEMANS_BLUETOOTH)

# if defined(BT_DEBUG_GENIE)
	va_start (ap, format);
	len = KiPrintf(format,ap);
	va_end (ap);
# elif defined(BT_DEBUG_HYPER)
	va_start (ap, format);
	len=vsprintf (buf, format, ap);
	va_end (ap);
	buf[DEBUG_BUF_SIZE] = '\0';
	
	if(len>DEBUG_BUF_SIZE) len=DEBUG_BUF_SIZE;  /*noti_010407*/
	
	for (i = 0; i < len; i++)
	{
		GSPDebug_PutByte(buf[i]);
	}
	
	GSPDebug_PutByte('\r');
	GSPDebug_PutByte('\n');
# endif

#else
	va_start (ap, format);
	len=vsprintf (buf, format, ap);
	va_end (ap);
/* BT_COMMON_KIMSANGJIN_070329 noti_011042 */
	buf[DEBUG_BUF_SIZE] = '\0';
	if(len>DEBUG_BUF_SIZE) len=DEBUG_BUF_SIZE;  
	
	for (i = 0; i < len; i++)
	{
		GSPDebug_PutByte(buf[i]);
	}
	
	GSPDebug_PutByte('\r');
	GSPDebug_PutByte('\n');
#endif	/* LGE_LEMANS_BLUETOOTH */
	
}
#endif/*LGBX_INCLUDE*/

#if defined(LGE_BRCM_BLUETOOTH)
void BRCM_bt_debug(const char *format,...)
{
	Int16 i;
	Int16 len;
	static char buf[DEBUG_BUF_SIZE+1];
	va_list ap;
	
#if ((!defined(BRCM_DEBUG_ENABLE)) || (!defined(BT_DEBUG_ENABLE)))
	return;
#endif

	if (BtGetBcmDebugFlag() == FALSE) return; /* BT_L1_KIMSANGJIN_061226 noti_010205*/

#if defined(LGE_LEMANS_BLUETOOTH)

# if defined(BT_DEBUG_GENIE)
	va_start (ap, format);
	len = KiPrintf(format,ap);
	va_end (ap);
# elif defined(BT_DEBUG_HYPER)
      // dlDisableIrq();
	//ENTER_PRINTF_SECTION();
	va_start (ap, format);
	len=vsprintf (buf, format, ap);
	va_end (ap);
	/* BT_COMMON_KIMSANGJIN_070329 noti_011042 */
		buf[DEBUG_BUF_SIZE] = '\0';
		if(len>DEBUG_BUF_SIZE) len=DEBUG_BUF_SIZE;	
	
	for (i = 0; i < len; i++)
	{
		GSPDebug_PutByte(buf[i]);
	}
	
	GSPDebug_PutByte('\r');
	GSPDebug_PutByte('\n');

	//LEAVE_PRINTF_SECTION();
	//dlEnableIrq();
# endif

#else

      // dlDisableIrq();
	//ENTER_PRINTF_SECTION();
	va_start (ap, format);
	len=vsprintf (buf, format, ap);
	va_end (ap);
/* BT_COMMON_KIMSANGJIN_070329 noti_011042 */
	buf[DEBUG_BUF_SIZE] = '\0';
	if(len>DEBUG_BUF_SIZE) len=DEBUG_BUF_SIZE;	
	for (i = 0; i < len; i++)
	{
		GSPDebug_PutByte(buf[i]);
	}
	
	GSPDebug_PutByte('\r');
	GSPDebug_PutByte('\n');

	//LEAVE_PRINTF_SECTION();
	//dlEnableIrq();

#endif	/* LGE_LEMANS_BLUETOOTH */
}
#endif /* LGE_BRCM_BLUETOOTH */

#if defined(LGE_CSR_BLUETOOTH)
void CSR_debug(const char *format,...)
{
	Int16 i;
	Int16 len;
	static char buf[DEBUG_BUF_SIZE+1];
	va_list ap;
	
#if ((!defined(CSR_DEBUG_ENABLE)) || (!defined(BT_DEBUG_ENABLE)))
	return;
#endif

	if (BtGetCsrDebugFlag() == FALSE) return; /* BT_L1_KIMSANGJIN_061226 noti_010205*/

#if defined(LGE_LEMANS_BLUETOOTH)

# if defined(BT_DEBUG_GENIE)
	va_start (ap, format);
	len = KiPrintf(format,ap);
	va_end (ap);
# elif defined(BT_DEBUG_HYPER)
      // dlDisableIrq();
	//ENTER_PRINTF_SECTION();
	va_start (ap, format);
	len=vsprintf (buf, format, ap);
	va_end (ap);
	/* BT_COMMON_KIMSANGJIN_070329 noti_011042 */
		buf[DEBUG_BUF_SIZE] = '\0';
		if(len>DEBUG_BUF_SIZE) len=DEBUG_BUF_SIZE;	
	
	for (i = 0; i < len; i++)
	{
		GSPDebug_PutByte(buf[i]);
	}
	
	//noti_011227 recommand from  Sean_071116: '\r' and '\n' is added by calling statement. So, we don't need to add them here. <--
	//GSPDebug_PutByte('\r');
	//GSPDebug_PutByte('\n');
	// Sean_071116: -->

	//LEAVE_PRINTF_SECTION();
	//dlEnableIrq();
# endif

#else

      // dlDisableIrq();
	//ENTER_PRINTF_SECTION();
	va_start (ap, format);
	len=vsprintf (buf, format, ap);
	va_end (ap);
/* BT_COMMON_KIMSANGJIN_070329 noti_011042 */
	buf[DEBUG_BUF_SIZE] = '\0';
	if(len>DEBUG_BUF_SIZE) len=DEBUG_BUF_SIZE;	
	for (i = 0; i < len; i++)
	{
		GSPDebug_PutByte(buf[i]);
	}
	
	// noti_011227 recommand from Sean_071116: '\r' and '\n' is added by calling statement. So, we don't need to add them here. <--
	//GSPDebug_PutByte('\r');
	//GSPDebug_PutByte('\n');
	// Sean_071116: -->

	//LEAVE_PRINTF_SECTION();
	//dlEnableIrq();

#endif	/* LGE_LEMANS_BLUETOOTH */
}
#endif /* LGE_CSR_BLUETOOTH */

#if 0 /*BT_COMMON_KIMSANGJIN_071204 noti_011235*/
void BTDebugOut( char *sFile, int  nLine,const char  *format,...  )
{
    static char s[512], s2[512];
    char        *pS;
    va_list      ap;
    int           nr;
    Int8         i;

#if !defined(BT_DEBUG_ENABLE)
	return;
#endif

    if (BtGetDebugFlag() == FALSE) return; 

    va_start (ap, format);
    nr =_vsprintf (s, format, ap);
    va_end (ap);
    s[nr] = '\0';

    if ( sFile == PNULL )
    {
      DevAssert(0);
    }
    else
    {
        pS = sFile + strlen(sFile);
        while ( (pS > sFile) && ((Int8)(*(pS-1)) != 0x5c) ) pS --;

        nr = sprintf(s2, "[%s/%04d] %s",  pS, nLine, s);
	for (i = 0; i < strlen(s2); i++)
	      GSPDebug_PutByte(s2[i]);
	
	GSPDebug_PutByte('\r');
	GSPDebug_PutByte('\n');
    }
}
#endif
/* end of BT_COMMON_KIMSANGJIN_071204 */
/* BT_L1_KIMSANGJIN_060814 */
#ifdef BT_TRACE_ENABLE

/***************************************************************************
* Trace Implementation (Debugging Purpose)
* 
* Don't delete this part! It can be useful from time to time.
***************************************************************************/

#define BT_TRACE_MEM_SIZE	(32*1024)
#define NEWLINE_SIZE		2 /* CR + LF */
#define BT_TRACE_PRINT_SIZE		64

static char gTraceBuf[BUF_SIZE+1];
static char gTraceMem[BT_TRACE_MEM_SIZE+1];
static int  gTraceMemLength = 0; /* current size */
static int  gTraceCnt = 0; /* the count of BtTrace() function calls */
void BtDebugN(const char *buf, Int16 len)
{
	Int16 i;
	
	for (i = 0; i < len; i++)
	{
		GSPDebug_PutByte(buf[i]);
	}

}

void BtInitTrace(void)
{
	gTraceMemLength = 0;
	gTraceCnt = 0;
	memset(gTraceMem, '\0', BT_TRACE_MEM_SIZE+1);
}

int BtGetMaxTraceSize(void)
{
	return BT_TRACE_MEM_SIZE;
}

int BtGetCurTraceSize(void)
{
	return gTraceMemLength;
}

int BtGetTraceCount(void)
{
	return gTraceCnt;
}

char *BtGetLastTrace(void)
{
    if (gTraceMemLength == 0)
    	return NULL;
	else
    	return gTraceBuf;
}

void BtTrace(const char *format,...)
{
	int bufsize;
    va_list ap;

	gTraceCnt++;
	
    va_start (ap, format);
    vsprintf (gTraceBuf, format, ap);
    va_end (ap);
    gTraceBuf[BUF_SIZE] = '\0';
	bufsize = strlen(gTraceBuf);
	
	if (gTraceMemLength + bufsize + NEWLINE_SIZE < BT_TRACE_MEM_SIZE) 
	{
		strcat(gTraceMem, gTraceBuf);
		gTraceMemLength += bufsize;
		strcat(gTraceMem, "\r\n");
		gTraceMemLength += NEWLINE_SIZE;
	}
}

void BtPrintTrace(void)
{
	int i;
	int cnt;
	int remainder;
	char *ptr;
	
    /* Reset GSPB for debugging message on Hyper Terminal Program. */

	BT_DEBUG(("BtPrintTrace: %d", gTraceMemLength));
	gTraceMem[BT_TRACE_MEM_SIZE] = '\0';
	ptr       = gTraceMem;
	cnt       = gTraceMemLength / BT_TRACE_PRINT_SIZE;
	remainder = gTraceMemLength % BT_TRACE_PRINT_SIZE;
	
	for (i = 0; i < cnt; i++) 
	{
		BtDebugN(ptr, BT_TRACE_PRINT_SIZE);
		ptr += BT_TRACE_PRINT_SIZE;
	}
	
	BtDebugN(ptr, remainder);
}

void BtDisplayLCD(Int8 row, const char *format,...)
{
#if 1 /* LeMans_Tiburona_060818 For BT debug in ABap version */
	char buf[16+1]; /* ABA_MAX_CHARS_PER_LINE = 16 */
#else
	char buf[BUF_SIZE+1];
#endif
	va_list ap;
	//Int16 i; /* LGE_K_JIN100_WARNING_050316 */

	va_start (ap, format);
	vsprintf (buf, format, ap);
	va_end (ap);
#if 1 /* LeMans_Tiburona_060818 For BT debug in ABap version */
	buf[16] = '\0';
#else
	buf[BUF_SIZE] = '\0';
#endif

	//startBTDebugDisplayTimer();
	di_displayLine(row, buf);
}

#endif /* BT_TRACE_ENABLE */



#if 0
/***************************************************************************
 * Function    :
 * Group       :
 * Parameter   : None
 * Returns     : Nothing
 * Description :
 ***************************************************************************/
void AbaDisplayLine (Int8 line, const char *format, ...)
{
    static char tmpDisplayLine [ABA_MAX_CHARS_PER_LINE + 1];
    va_list ap;
    va_start (ap, format);

#if defined(USE_MPAPP_PMENU)
    if (pmenuOnDspMenu()) return;
#endif /* #if defined(USE_MPAPP_PMENU) */

    /* Check that the line number is valid */
    DevCheck (line < ABA_MAX_APP_DISP_LINES, line, ABA_MAX_APP_DISP_LINES, 0);

    vsprintf (tmpDisplayLine, format, ap);
    di_displayLine (line, tmpDisplayLine);
    va_end (ap);
}
#endif

void BtSetDebugFlag(Boolean flag)
{
	gDebugFlag = flag;
  	BT_DEBUG(("BtSetDebugFlag(%s)",flag?"Enable":"Disable"));	
}

Boolean BtGetDebugFlag(void)
{
	return gDebugFlag;
}

#if defined (LGBX_INCLUDE)
void BtSetBxDebugFlag(Boolean flag)
{
	gBxDebugFlag = flag;
  	BT_DEBUG(("BtSetBxDebugFlag(%s)",flag?"Enable":"Disable"));	
}

Boolean BtGetBxDebugFlag(void)
{
	return gBxDebugFlag;
}
#endif

#if defined(LGE_BRCM_BLUETOOTH)
void BtSetBcmDebugFlag(Boolean flag)
{
	gBcmDebugFlag = flag;
  	BT_DEBUG(("BtSetBcmDebugFlag(%s)",flag?"Enable":"Disable"));	
}

Boolean BtGetBcmDebugFlag(void)
{
	return gBcmDebugFlag;
}
#endif /* LGE_BRCM_BLUETOOTH */

#if defined(LGE_CSR_BLUETOOTH)
void BtSetCsrDebugFlag(Boolean flag)
{
	gCsrDebugFlag = flag;
  	BT_DEBUG(("BtSetCsrDebugFlag(%s)",flag?"Enable":"Disable"));	
}

Boolean BtGetCsrDebugFlag(void)
{
	return gCsrDebugFlag;
}
#endif /* LGE_CSR_BLUETOOTH */

#if defined (DEVELOPMENT_VERSION)
/***************************************************************************
 * FUNC : BT_DevAssert
 * PARA : 
 *  		- Boolean handle, int errCode
 * RET : void
 * DESC : DevCheck wrapper function for Bluetooth Module
 * HISTORY : 16.AUG.2006 Tiburona Create.
 ***************************************************************************/
void BT_DevAssert (Boolean handle, int errCode, char *file, Int32 line)
{
	char		devStr[128];

	memset(devStr, 0, sizeof(devStr));
	
	switch(errCode)
	{
		case EXAMPLE_BT_SUCCESS:
			/* No error */
			break;

		case HCI_COMMAND_TIMEOUT:
			/* HCI command timeout */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "HCI command timeout");
			DevFail(devStr);
			break;

		case HCI_CONTROL_HW_ERROR:
			/* HCI control HW error */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "HCI control HW error");
			DevFail(devStr);
			break;

/***************************************************************************
*	TTPCom File System Error START >>
 ***************************************************************************/
 #if 0
/*Error number values */
#define EINVDRV     	1   /*Specified drive no mounted*/
#define ENOPATH     	2   /*Invalid file name specified */
#define EEXCLOPEN   	3   /*File already open exclusively */
#define EEXIST      		4   /*File already exists */
#define EMFILE      		5   /*Too many open files */
#define EACCES      		6   /*Access denied to this file */
#define EBADF       		7   /*Bad file handle specified */
#define EINVALPARAM 	8   /*Invalid parameter */
#define ENOFILE     		9   /*File not found */
#define ECREATE     	10  /*File creation error */
#define EDEVREAD    	11  /*Low level device read error */
#define EFULL       		12  /*No space on device */
#define ENOMEM      	13  /*No memory available */
#define EDEVWRITE   	14  /*Low level device write error */
#define ENOENT      		15  /*Directory does not exist */
#endif

		case EINVDRV:		/* 1 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Specified drive no mounted");
			DevFail(devStr);
			break;
			
		case ENOPATH:	/* 2 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Invalid file name specified");
			DevFail(devStr);		
			break;

		case EEXCLOPEN:	/* 3 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "File already open exclusively");
			DevFail(devStr);
			break;

		case EEXIST:		/* 4 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "File already exists");
			DevFail(devStr);
			break;

		case EMFILE:		/* 5 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Too many open files");
			DevFail(devStr);
			break;
			
		case EACCES:		/* 6 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Access denied to this file");
			DevFail(devStr);
			break;

		case EBADF:		/* 7 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Bad file handle specified");
			DevFail(devStr);
			break;

		case EINVALPARAM:/* 8 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Invalid parameter");
			DevFail(devStr);
			break;

		case ENOFILE:		/* 9 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "File not found");
			DevFail(devStr);
			break;

		case ECREATE:		/* 10 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "File creation error");
			DevFail(devStr);
			break;

		case EDEVREAD:	/* 11 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Low level device read error");
			DevFail(devStr);
			break;

		case EFULL:		/* 12 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "No space on device");
			DevFail(devStr);
			break;

		case ENOMEM:		/* 13 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "No memory available");
			DevFail(devStr);
			break;
			
		case EDEVWRITE:	/* 14 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Low level device write error");
			DevFail(devStr);
			break;

		case ENOENT:		/* 15 */
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "Directory does not exist");
			DevFail(devStr);
			break;
/***************************************************************************
*	TTPCom File System Error END <<
 ***************************************************************************/

		default:
			sprintf(devStr, "[%s] [%ld] BT error : %s", file, line, "UNKNOWN");
			DevFail(devStr);			
			break;
	}
}
#endif /*DEVELOPMENT_VERSION */

#if 0 //defined (LGE_MEMLEAK_CHECK) for dev version tiburona_080114
extern void di_displayLineForDev(Int8 row, char* message);
void BtDisplayLineForDev(Int32 errCode, Int32 v1, Int32 v2)
{
	char errorMsg1[22];
	char errorMsg2[22];
	//sprintf(errorMsg,"v1=%d v2=%d v3=%d", v1, v2, v3);
	
	switch(errCode)
	{
		case BTOK:
			/* No error */
			sprintf(errorMsg1,"Frames In Buffer");
			sprintf(errorMsg2,"=%d/%d", v1, v2);
			break;

		case EOUTQ:
			/* outQ fulled, drop 1 packet */
			sprintf(errorMsg1,"outQ fulled, drop 1 packet");
			sprintf(errorMsg2,"%d,%d", v1, v2);
			break;

		default:
			sprintf(errorMsg1,"UNKNOWN ERROR");
			sprintf(errorMsg2,"UNKNOWN ERROR");
			break;			
	}
	
	di_displayLineForDev(38, errorMsg1);
	di_displayLineForDev(39, errorMsg2);
}

void BtDisplayLCDForDev(const char *format,...)
{
	char buf[22+1]; /* ABA_MAX_CHARS_PER_LINE = 16 */
	va_list ap;
	Int16 len;
	
	va_start (ap, format);
	len=vsprintf (buf, format, ap);
	va_end (ap);
	/* BT_COMMON_KIMSANGJIN_070329 noti_011042 */
		buf[22] = '\0';
		if(len>22) len=22;	

	di_displayLineForDev(38, buf);
}
#endif /* LGE_MEMLEAK_CHECK */

#endif /* LGE_L1_BLUETOOTH */

