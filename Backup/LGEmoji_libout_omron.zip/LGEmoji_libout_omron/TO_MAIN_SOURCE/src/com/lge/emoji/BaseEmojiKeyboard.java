package com.lge.emoji;

import android.inputmethodservice.InputMethodService;

public class BaseEmojiKeyboard extends EmojiKeyboard {

    public BaseEmojiKeyboard(InputMethodService ims) {
        super(ims);
    }
}
