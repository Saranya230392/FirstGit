package com.lge.my.mp3Test_remote;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteException;
import android.widget.Toast;

public class MP3Service extends Service {
	private final IMP3Service.Stub mBind = new IMP3Service.Stub() {

		@Override
		public void Stop() throws RemoteException {
			// TODO Auto-generated method stub
			mp.pause();
		}
		@Override
		public void Start() throws RemoteException {
			// TODO Auto-generated method stub
			mp.start();
		}
		@Override
		public void Seek(int pos) throws RemoteException {
			// TODO Auto-generated method stub
			mp.seekTo(pos * 1000);
		}
		@Override
		public int getPid() throws RemoteException {
			// TODO Auto-generated method stub
			// mp.release();
			return Process.myPid();
		}
	};

	@Override
	public void onRebind(Intent intent) {
		// TODO Auto-generated method stub
		Toast.makeText(MP3Service.this, "Service ReBinded", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		Toast.makeText(MP3Service.this, "Service Destroyed", Toast.LENGTH_SHORT).show();
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		Toast.makeText(MP3Service.this, "Service UnBinded", Toast.LENGTH_SHORT).show();
		return true;
	}

	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		Toast.makeText(MP3Service.this, "Service Created", Toast.LENGTH_SHORT).show();
	}

	MediaPlayer mp = null;

	@Override
	public IBinder onBind(Intent intent) {
		Toast.makeText(MP3Service.this, "Service Binded", Toast.LENGTH_SHORT).show();
		if (mp == null) {
			mp = MediaPlayer.create(MP3Service.this, R.raw.geek);
		}
		return mBind;
	}

}
