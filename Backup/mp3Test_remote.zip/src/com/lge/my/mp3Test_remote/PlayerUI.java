package com.lge.my.mp3Test_remote;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Process;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PlayerUI extends Activity {
	// NotificationManager nm;
	// Notification notification;
	IMP3Service mpService;

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		Toast.makeText(PlayerUI.this, "UI Destroy", Toast.LENGTH_SHORT).show();
		super.onDestroy();
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		Toast.makeText(PlayerUI.this, "UI Stop", Toast.LENGTH_SHORT).show();
		super.onStop();
	}

	ServiceConnection _conn;

	/** Called when the activity is first created. */
	MP3Service mp = null;
	Intent i;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
		Toast.makeText(PlayerUI.this, "UI Create", Toast.LENGTH_SHORT).show();
		super.onCreate(savedInstanceState);

		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ui);
		// setContentView((View)mc);
		final Button btn = (Button) findViewById(R.id.button01);
		i = new Intent(PlayerUI.this, MP3Service.class);
		_conn = new ServiceConnection() {

			@Override
			public void onServiceDisconnected(ComponentName name) {
				// TODO Auto-generated method stub
			}

			@Override
			public void onServiceConnected(ComponentName name, IBinder service) {
				// TODO Auto-generated method stub
				// mp = ((MP3Service.LocalBinder) service).getService();
				mpService = IMP3Service.Stub.asInterface(service);
			}
		};
		;
		;

		startService(new Intent("com.lge.my.mp3Test_remote.IMP3Service")); // �� �κ��� �ּ�ó�� �ϸ� UI activity�� ���� �ɶ�(bind�� �������) Service�� ����
		Log.i("xxxxxxxxxxxx", IMP3Service.class.getName());
		bindService(new Intent("com.lge.my.mp3Test_remote.IMP3Service"), _conn, Context.BIND_AUTO_CREATE);

		btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				try {

					mpService.Start();
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				// notification = new Notification(R.drawable.icon48x48_1, "text", System.currentTimeMillis());
				// CharSequence text = getText(R.string.local_service_started);
				// PendingIntent contentIntent = PendingIntent.getActivity(PlayerUI.this, 0, new Intent(PlayerUI.this, PlayerUI.class), 0);
				// //PendingIntent contentIntent = PendingIntent.getActivity(PlayerUI.this, 0, new Intent(Intent., uri), 0);
				// notification.setLatestEventInfo(PlayerUI.this, getText(R.string.local_service_label), text, contentIntent);
				//				
				// nm.notify(R.string.local_service_started, notification);
			}
		});
		findViewById(R.id.seek).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String Pos = ((EditText) findViewById(R.id.edittext)).getText().toString();
				// Toast.makeText(PlayerUI.this, "Seek to " + Pos + " Second", Toast.LENGTH_SHORT).show();
				try {
					mpService.Seek(Integer.parseInt(Pos));
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});

		findViewById(R.id.stopplay).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				try {
					mpService.Stop();
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		findViewById(R.id.remove).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				try {
					int pid = mpService.getPid();
					stopService(new Intent(IMP3Service.class.getName()));
					Process.killProcess(pid);
					_conn = null;
					btn.setEnabled(false);
					// unbindService(_conn);
					// stopService(new Intent("com.lge.my.mp3Test_remote.IMP3Service"));
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		});
		setResult(RESULT_OK, i);
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		Toast.makeText(PlayerUI.this, "UI Pause", Toast.LENGTH_SHORT).show();
		super.onPause();
		// stopService(new Intent(PlayerUI.this,notification.class));
		// nm.cancelAll();
	}

}
