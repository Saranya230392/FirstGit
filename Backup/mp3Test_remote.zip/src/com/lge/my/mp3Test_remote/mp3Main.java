package com.lge.my.mp3Test_remote;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class mp3Main extends Activity {
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		//stopService(i);
		super.onDestroy();
	}

	Intent i;
	MP3Service mp;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		findViewById(R.id.showmp3p).setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent i = new Intent(mp3Main.this, PlayerUI.class);
				startActivity(i);
			}
		});

	}
}