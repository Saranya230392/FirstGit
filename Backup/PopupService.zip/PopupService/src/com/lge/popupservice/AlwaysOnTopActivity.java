package com.lge.popupservice;

import com.lge.popupservice.R;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;

public class AlwaysOnTopActivity extends Activity implements OnClickListener {
	
	static EditText et2;
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		et2 = (EditText)findViewById(R.id.et2);	
		startService(new Intent(this, AlwaysOnTopService.class));
		findViewById(R.id.start).setOnClickListener(this);		//���۹�ư
		findViewById(R.id.end).setOnClickListener(this);		//�߽ù�ư
		findViewById(R.id.edit_button).setOnClickListener(this);//������ư
		et2.setText("");
	}
    
	@Override
	public void onClick(View v) {
		int view = v.getId();
		if( view == R.id.edit_button)
			AlwaysOnTopService.setTextView(et2.getText().toString());   //�ؽ�Ʈ ���� ���񽺰� ������� ���� �� ������ �ʴ´�.		
		else if(view == R.id.start)
			startService(new Intent(this, AlwaysOnTopService.class));	//���� ����				
		else
			stopService(new Intent(this, AlwaysOnTopService.class));	//���� ����		
	}
}