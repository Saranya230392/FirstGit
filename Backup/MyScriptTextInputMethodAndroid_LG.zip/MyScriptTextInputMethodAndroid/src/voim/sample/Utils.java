/*
 * Copyright (C) Vision Objects
 */

package voim.sample;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

public abstract class Utils
{
  // debugging support
  private static final String  TAG         = Utils.class.getSimpleName();
  private static final boolean DBG         = true;
  
  /**
   * Move splited resources from assets to application data folder 
   * 
   * @param context
   *          the application context
   */
  public static void unsplitResources(Context context)
  {
    try
    {      
      // list asset resources
      
      AssetManager manager = context.getAssets();
    
      // data folder 
      File path = context.getDir("Data", 0);
      String[] confs = manager.list("conf");
  
      File partial_ = new File(path.getAbsolutePath() + "/conf");
      
      partial_.mkdir();
      
      for(String conf : confs)
      {
        File complete = new File(partial_.getAbsolutePath(), conf);
        
        if (!complete.exists())
        {
          File source = new File("conf/" + conf);
          File destination = complete;
          simulateUnsplitResource(manager, source, destination);
        }
      }
      
    }
    catch (IOException e)
    {
      if (DBG)
        Log.e(TAG, e.getMessage());
    }
  }
  
  
  /**
   * Simulate a merge resource 
   * 
   * @param context
   *          the application context
   * @param source
   *          the resource file to merge       
   * @param destination
   *          the merged file destination
   * @param language
   *          the resource language
   * @param suffix
   *          ak or lk file suffix                              
   */
  private static void simulateUnsplitResource(AssetManager manager, File source, File destination) throws IOException
  {
    OutputStream os = new FileOutputStream(destination);
    InputStream is = manager.open(source.getPath());
    destination.createNewFile();
    int read = 0;
    byte[] bytes = new byte[1024];
    while ((read = is.read(bytes)) != -1)
      os.write(bytes, 0, read);
    is.close();
    os.close();
  }
}
