package voim.sample;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import android.util.Log;

import com.visionobjects.im.Engine;
import com.visionobjects.im.EventListener;
import com.visionobjects.im.IStroke;
import com.visionobjects.im.Language;
import com.visionobjects.im.LanguageManager;
import com.visionobjects.im.NativeException;
import com.visionobjects.im.Recognizer;
import com.visionobjects.im.Result;

/**
 * The <code>BackgroundRecognition</code> example code shows you how to perform
 * background recognition using the MyScript Text Input Method extension.
 *
 * <p>Please remember that in order to use MyScript Builder examples, you
 * first have to generate a user certificate using the
 * <code>certificate2src</code> tool (located in the edk/tools/ directory):<ul>
 * <li>go to the voim/api/java/examples directory</li>
 * <li>launch ../../../../edk/tools/bin/[platform]/certificate2src certificates/MyCertificate.java</li>
 * </ul>
 * This will create a <code>MyCertificate.java</code> source file used to
 * identify you as a legitimate MyScript Engine user.</p>
 */
public class BackgroundRecognition
{

  // -- application ------------------------------------------------------------

  private final Engine          engine;
  private final LanguageManager languageManager;
  private final Recognizer      recognizer;

  /**
   * Initializes the application.
   * @param confDir the configuration directory.
   * @param properties the properties to be overridden (optional).
   * @throws IOException 
   * @throws FileNotFoundException
   */
  public BackgroundRecognition(File confDir) throws FileNotFoundException, IOException
  {
    // -- prepare configuration
    
    confDir = confDir.getCanonicalFile();
    
    File enginePropertyFile = new File(confDir, "Engine.properties");
    boolean enginePropertyFileOK = enginePropertyFile.canRead();

    File languageManagerPropertyFile = new File(confDir, "LanguageManager.properties");
    boolean languageManagerPropertyFileOK = languageManagerPropertyFile.canRead();

    File recognizerPropertyFile = new File(confDir, "Recognizer.properties");
    boolean recognizerPropertyFileOK = recognizerPropertyFile.canRead();
   
    
    // -- check it
    
    if (!enginePropertyFileOK)
      throw new FileNotFoundException(enginePropertyFile.getPath());
    
    if (!languageManagerPropertyFileOK)
      throw new FileNotFoundException(languageManagerPropertyFile.getPath());
    
    if (!recognizerPropertyFileOK)
      recognizerPropertyFile = null;
    
    // -- initialize
    
    Log.d("voim.sample", "creating objects...");
    
    engine = Engine.create(MyCertificate.getBytes(), enginePropertyFile, new Properties());
    languageManager = engine.createLanguageManager(languageManagerPropertyFile);
    recognizer = engine.createRecognizer(languageManager, recognizerPropertyFile);
    recognizer.setEventListener(recognitionEventListener);
    
    Log.d("voim.sample", "initialization done.");
  }
  
  /**
   * Destroy the native resources held by the application.
   */
  public void destroy()
  {
    recognizer.destroy();
    languageManager.destroy();
    engine.destroy();
    Log.d("voim.sample", "done.");
  }
  
  @Override
  protected void finalize() throws Throwable
  {
    destroy();
  };
  
  /**
   * Process the specified ink files.
   * @param inkFiles the array of ink files to process.
   */
  public void run(File inkFile)
  {
    // -- perform recognition loop

    Log.d("voim.sample", "setting recognizer's mode...");

    try
    {
      recognizer.setMode("ko-KR", "text");

      final long delay = Long.parseLong(System.getProperty("delay", "500"));
      
        try
        {
          Ink.parse(inkFile, new Ink.IParseHandler()
          {
            @Override
            public void addStroke(IStroke stroke)
            {
              try
              {
                Thread.sleep(delay);
                recognizer.addStroke(stroke);
              }
              catch (Exception e)
              {
              }
            }
          });
          recognizer.commit();
        }
        catch (FileNotFoundException e)
        {
          Log.e("voim.sample", "no such file " + inkFile);
        }
        catch (IOException e)
        {
          Log.e("voim.sample", "error reading file " + inkFile);
          recognizer.cancel();
        }
    }
    catch (NativeException e)
    {
      Log.e("voim.sample", "failed to set mode.");
    }

  }

  /**
   * Recognition Event Listener
   */
  EventListener recognitionEventListener = new EventListener()
  {
    @Override
    public void onSetMode(Language language, String modeName)
    {
      Log.d("voim.sample", "mode \"" + language.getName() + "\" / \"" + modeName + "\" is set, ready to receive strokes.");
    }

    @Override
    public void onSetModeFailed(Language language, String modeName,
        RuntimeException exception)
    {
      Log.d("voim.sample", "failed to set mode");
    }

    @Override
    public void onRecognitionEnd()
    {
      Result result = recognizer.getResult(false, true);
      try
      {
        Log.d("voim.sample","\"" + result.toString() + "\"");
      }
      finally
      {
        result.destroy();
      }
    }

    @Override
    public void onCommit()
    {
      Log.d("voim.sample","recognition ended!");
    }
  };


  /**
   * main(): command line parsing
   * @param args
   * @throws IOException
   */
  public static final void main() throws IOException
  {   
    String confDir = "/data/data/voim.sample/app_Data/conf";
    String sdCard = android.os.Environment.getExternalStorageDirectory().toString();
    File inkFile = new File (sdCard + "/VO/ink/VisionObjects.ink");    
    
    // -- execute the application
    
    BackgroundRecognition app = null;
    try
    {
      app = new BackgroundRecognition(new File(confDir));

      app.run(inkFile);
    }
    catch (FileNotFoundException e)
    {
      System.err.println("failed to initialize, please check that you correctly set up the configuration");
      
      System.exit(1);
    }
    finally
    {
      if (app != null) app.destroy();
    }
  }

} // BackgroundRecognition
