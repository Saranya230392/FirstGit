package voim.sample;

import java.io.IOException;

import android.app.Activity;
import android.os.Bundle;

public class MyScriptTextInputMethodAndroidActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // To deploy conf files from assets to /data/data/voim.sample/app_Data/conf
        Utils.unsplitResources(getApplicationContext());

        try
        {
          BackgroundRecognition.main();
        }
        catch (IOException e)
        {
        }
        finally
        {
        }
    }
}