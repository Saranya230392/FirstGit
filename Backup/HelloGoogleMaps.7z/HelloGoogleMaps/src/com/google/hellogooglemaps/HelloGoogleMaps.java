package com.google.hellogooglemaps;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;

public class HelloGoogleMaps extends MapActivity {
	MapView mMap;
	MapController mControl;
	protected boolean isRouteDisplayed() {
		return false;
	}
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        MapView mapView = (MapView) findViewById(R.id.mapview);
        mapView.setBuiltInZoomControls(true);
    }

    /* Create the menu items */
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, 1, 0,"Map");
		menu.add(0, 2, 0,"Sat");
		menu.add(0, 3, 0,"Distance");
		menu.add(0, 4, 0,"Traffic");
		menu.add(0, 5, 0,"Point 1")
			.setIcon(R.drawable.arrow_0);
		menu.add(0, 6, 0,"Point 2")
			.setIcon(R.drawable.arrow_100);
		return true;
		//return false;		
	}

	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case 1:
			mMap.setSatellite(false);
			return true;
		case 2:
			mMap.setSatellite(true);
			return true;
		case 3:
			mMap.setStreetView(true);
			return true;
		case 4:
			mMap.setTraffic(true);
			return true;
		case 5:
			mControl.animateTo(new GeoPoint(37881311, 127729968));
			return true;
		case 6:
			mControl.animateTo(new GeoPoint(37885269, 127729592));
			return true;
		}
		return false;
	}
}