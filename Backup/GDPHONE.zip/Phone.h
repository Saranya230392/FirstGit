// Phone.h: interface for the CPhone class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PHONE_H__816C2770_78F5_4024_8536_ECD2707C27DE__INCLUDED_)
#define AFX_PHONE_H__816C2770_78F5_4024_8536_ECD2707C27DE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Serial.h"

// constance
#define TEST_OK_S             0
#define TEST_FAIL_S           1 
#define TEST_NOT_SUPPORTED_S  2
//

class CPhone : public CObject  
{
// Operation
public:
	CPhone();
	virtual ~CPhone();
	void SetSerial(CSerial *pSerial);

	virtual BOOL Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB = FALSE);
	virtual int OpenUSB(CString sDriverName);
	virtual BOOL Close();
	virtual BOOL Init() = 0;
	virtual BOOL Exit() = 0;
	virtual BOOL IsPhoneConnected() = 0;
	virtual BOOL GetSWVersion(CString &sSWVersion) = 0;
	virtual BOOL GetProductID(CString &sProductID) = 0;
	virtual BOOL SetProductID(CString sProductID) = 0;
	virtual BOOL GetESNIMEI(CString &sESNIMEI, BOOL bIsIMEI = FALSE) = 0;
	virtual BOOL GetMEID(CString &sMEID) = 0;
	virtual BOOL SetKeyPad(DWORD dwKeyStr, BOOL bLongKey = FALSE) = 0;
	virtual BOOL SetKeyPadLock(BOOL bLock) = 0;
	virtual BOOL CheckRegister(BOOL& bIsCAMP) = 0;
	virtual BOOL SetBand(int nBandIndex) = 0;
	virtual BOOL SetChannel(double dChannel) = 0;
	virtual BOOL SetMode(BYTE byMode) = 0;
	virtual BOOL SetDipSwitch(WORD wValue) = 0;
	virtual BOOL SetBluetoothMode(int nModeIndex, int nPreDelay, CString sCheckStatus = BTMODE_STATUS_BTTMOK) = 0;
	virtual BOOL PhoneReset() = 0;
	virtual BOOL GetPhoneState(int nSystemType, int *nState, CString &sStateDesc) = 0;
	virtual BOOL GetPhoneStatus(LPPHONESTATUS PhoneStatus) = 0;
	virtual BOOL ChangeDiagPath(WORD uMSM) = 0;
	virtual BOOL SetFTMNV(BOOL bSet) = 0;
	virtual BOOL SetTestMode(CString sItemName, CString &sResult) = 0;
	virtual BOOL SetVSIM() = 0;
	virtual BOOL SetEmergencyCall(BOOL bOnOff) = 0;															//  [4/9/2007] vivache : Emergency call
	virtual BOOL SetMRDMode(int nModeIndex, int nDelay = DEFAULT_MRD_DELAY) = 0;					//  [7/3/2007] vivache : MRD Mode ��ȯ
	virtual BOOL SetWLANMode(BOOL bState, int nPreDelay, int *pnErrCode, int nWlanType = INDEX_WLAN_802_11G) = 0;														//  [7/3/2007] vivache : WLAN Testmode ��ȯ/����
	virtual BOOL SetWLANRxMode(double& fPer, int nChannel, int nDelay = DEFAULT_WLANRX_DELAY) = 0;	//  [7/3/2007] vivache : WLAN Rx Mode
	virtual BOOL SetWLANTxMode(int nChannel, int nLevel) = 0;										//  [7/3/2007] vivache : WLAN Tx Mode
	virtual BOOL IsCalibration() = 0 ;	//  [7/16/2007] vivache : Calibration�� �Ǿ����� check�ϴ� Item�� ����Ͽ� cal ���� Ȯ��
	virtual BOOL GetRSSI(double& fRssi) = 0 ;	//  [10/23/2007] vivache : CDMA Rssi value �о����
	virtual BOOL ChangeUartPath(int nDirection) = 0 ;	//  [10/24/2008] vivache : Dual CPU Model�� ��� Master/Slave �� UART Path switching�� ���ؼ� �����.
	virtual BOOL BandChange(int bandItem) = 0; // [1/8/2009] By Karl. For ADI quad band chipset. Change main band from EUR to US or US to EUR by command.
	virtual BOOL ChangeSystem(int nDirection) = 0;	//  [01/16/2009] lupis : CDMA/UMTS�� ��� �����ϴ� Model�� ��� CDMA/UMTS �� System switching�� ���ؼ� �����.
	virtual BOOL SetCampRequest(int nBand) = 0;	//  [5/26/2009] vivache : GSM �� ���� ��� command.
	virtual BOOL SetSleepMode() = 0; //  [9/16/2009] vivache : Sleep mode
	virtual BOOL SetDetach() = 0; //  [9/18/2009] vivache : detach
	virtual BOOL SetOriginCall(WORD wMode = DIAG_VOICE_CALL) = 0;
	virtual BOOL SetEndCall() = 0;
	virtual BOOL SetMimoAntCheck(int nMode) = 0;
	virtual	BOOL SetLteAttach(BOOL bOn) = 0;
	virtual BOOL SetPidFlag(int nIndex, char cValue) = 0; //  [1/16/2010] lupis : PID Flag
	virtual	BOOL SetL2000Prepare(BOOL bIsVSIM) = 0;
	virtual BOOL SetFlightMode(BOOL bOnOff) = 0;		// [10/15/2010] JKPARK : Thunder Regi �ҷ� ����	
	virtual BOOL SetQEMmode(BOOL bMode) = 0;			// [4/14/2011] JKPARK : QEM Enable���� ���� �߰�	
	virtual BOOL SetLoopBackCall(BOOL bOnOff) = 0;		//  [7/23/2011] JKPARK : CDMA ���� AT������ Loopback Call function	
	virtual BOOL SetLcdOnOff(BOOL bOnOff) = 0;			// [11/10/2011] JKPARK : LCD ON/OFF �߰� 

// Attribute
protected:
	CSerial *m_pSerial;
	static const char phone_acp[][30];
	static const char phone_mcc[][30];
	static const char evdo_call_state[][30];
	static const char rel_a_call_state[][30];

// Util
public:
	void SetParent(CPhoneFactory* pPhoneFactory){ m_pPhoneFactory = pPhoneFactory; };

protected:
	CPhoneFactory* m_pPhoneFactory;	//  [4/4/2008] vivache : Multi
};

#endif // !defined(AFX_PHONE_H__816C2770_78F5_4024_8536_ECD2707C27DE__INCLUDED_)
