// GDPhoneImp.cpp: implementation of the CGDPhoneImp class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GDPhone.h"
#include "GDPhoneImp.h"
#include "PhoneFactory.h"
#include "Phone.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define BEGIN_USB \
if ( m_PhoneFactory.IsUSB() && !m_PhoneFactory.EnableUSB(TRUE) ) { m_cs.Unlock(); return FALSE; }

#define END_USB \
	if ( m_PhoneFactory.IsUSB() && !m_PhoneFactory.EnableUSB(FALSE) ) { m_cs.Unlock(); return FALSE; }


CGDPhoneImp::CGDPhoneImp()
{
}

CGDPhoneImp::~CGDPhoneImp()
{
	CPhoneFactory::DeleteInstance();
}

BOOL CGDPhoneImp::SearchSWVersion(int nPortNo, BOOL bIsCDMA, CString &sSWVersion)
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	BOOL bResult(FALSE);
	
	m_cs.Lock();

	BEGIN_USB

	bResult = m_PhoneFactory.SearchSWVersion(nPortNo, bIsCDMA, sSWVersion);

	END_USB

	m_cs.Unlock();

	return bResult;
}

BOOL CGDPhoneImp::InitPhone(int nCommMode)
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	BOOL bResult(FALSE);

	m_cs.Lock();
	BEGIN_USB

	bResult = m_PhoneFactory.InitPhone(nCommMode);

	END_USB
	m_cs.Unlock();

	return bResult;
}

BOOL CGDPhoneImp::ExitPhone()
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	BOOL bResult(FALSE);

	m_cs.Lock();
	BEGIN_USB

	bResult = m_PhoneFactory.ExitPhone();

	END_USB
	m_cs.Unlock();

	return bResult;
}

BOOL CGDPhoneImp::Open(int nPortNo, int nBaudRate, BOOL bUSB /* = FALSE */)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();

	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		if(!pPhone->Open(nPortNo, nBaudRate, bUSB))	//  [7/17/2006] vivache
		{
			s.Format("<PHONE>Port Open(%d) Fail!", nPortNo);
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);

			m_cs.Unlock();
			return FALSE;
		}

		s.Format("<PHONE>Port Open(%d)!", nPortNo);	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::Open";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	END_USB	// Prevent USB to interference measured value.

	return TRUE;
}

BOOL CGDPhoneImp::OpenUSB(CString &sDriverName)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		if(pPhone->OpenUSB(sDriverName) == -1)	//  [7/17/2006] vivache
		{
			s = "<PHONE>OpenUSB() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		s = "<PHONE>OpenUSB()!";	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::OpenUSB";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	END_USB	// Prevent USB to interference measured value.

	return TRUE;
}

BOOL CGDPhoneImp::Close()
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		if(!pPhone->Close())	//  [7/17/2006] vivache
		{
			s = "<PHONE>Close() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		s = "<PHONE>Close()!";	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::Close";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::Init()
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->Init())	//  [7/17/2006] vivache
		{
			s = "<PHONE>Init() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>Init()!";	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::Init";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::IsPhoneConnected()
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->IsPhoneConnected())	//  [7/17/2006] vivache
		{
			s = "<PHONE>IsPhoneConnected() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>IsPhoneConnected()!";	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::IsPhoneConnected";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::GetSWVersion(CString &sSWVersion)
{
	CString s(_T(""));	//  [7/17/2006] vivache
	
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->GetSWVersion(sSWVersion))	//  [7/17/2006] vivache
		{
			s = "<PHONE>GetSwVersion() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>GetSwVersion() : " + sSWVersion;	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::GetSWVersion";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::GetProductID(CString &sProductID)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->GetProductID(sProductID))	//  [7/17/2006] vivache
		{
			s = "<PHONE>GetProductID() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>GetProductID() : " + sProductID;	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::GetProductID";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetProductID(CString sProductID)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetProductID(sProductID))	//  [7/17/2006] vivache
		{
			s = "<PHONE>SetProductID() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>SetProductID() : " + sProductID;	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetProductID";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::GetESNIMEI(CString &sESNIMEI, BOOL bIsIMEI)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->GetESNIMEI(sESNIMEI, bIsIMEI))	//  [7/17/2006] vivache
		{
			s = "<PHONE>GetESNIMEI() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>GetESNIMEI() : " + sESNIMEI;	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::GetESNIMEI";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::GetMEID(CString &sMEID)
{
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->GetMEID(sMEID))
		{
			s = "<PHONE>GetMEID() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>GetMEID() : " + sMEID;
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::GetMEID";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetKeyPad(DWORD dwKeyStr, BOOL bLongKey)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetKeyPad(dwKeyStr, bLongKey))	//  [7/17/2006] vivache
		{
			s = "<PHONE>SetKeyPad() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetKeyPad(%d)!", dwKeyStr);	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetKeyPad";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetKeyPadLock(BOOL bLock)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetKeyPadLock(bLock))	//  [7/17/2006] vivache
		{
			s = "<PHONE>SetKeyPadLock() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>SetKeyPadLock()!";	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetKeyPadLock";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::CheckRegister(BOOL& bIsCAMP)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->CheckRegister(bIsCAMP))	//  [7/17/2006] vivache
		{
			s = "<PHONE>CheckRegister(bIsCAMP) Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		if(bIsCAMP) s = "<PHONE>CheckRegister(bIsCAMP)! CAMP OK";	//  [7/17/2006] vivache
		else	  s = "<PHONE>CheckRegister(bIsCAMP)! NO CAMP";	//  [7/17/2006] vivache

		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::CheckRegister";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetBand(int nBandIndex)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetBand(nBandIndex))	//  [7/17/2006] vivache
		{
			s = "<PHONE>SetBand() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>SetBand()!";	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetBand";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetChannel(double dChannel)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetChannel(dChannel))	//  [7/17/2006] vivache
		{
			s = "<PHONE>SetChannel() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>SetChannel()!";	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetChannel";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetMode(BYTE byMode)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetMode(byMode))	//  [7/17/2006] vivache
		{
			s = "<PHONE>SetMode() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetMode(%d)!", byMode);	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetDipSwitch(WORD wValue)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetDipSwitch(wValue))	//  [7/17/2006] vivache
		{
			s = "<PHONE>SetDipSwitch() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetDipSwitch(0x%04X)!", wValue);	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetDipSwitch";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetBluetoothMode(int nModeIndex, int nPreDelay, CString sCheckStatus)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetBluetoothMode(nModeIndex, nPreDelay, sCheckStatus))	//  [7/17/2006] vivache
		{
			s.Format("<PHONE>SetBluetoothMode(%d) Fail!", nModeIndex);
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetBluetoothMode(%d)!", nModeIndex);	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetBluetoothMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::PhoneReset()
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->PhoneReset())	//  [7/17/2006] vivache
		{
			s.Format("<PHONE>PhoneReset() Fail!");
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>PhoneReset()!");	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::PhoneReset";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::GetPhoneState(int nSystemType, int *nState, CString &sStateDesc)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->GetPhoneState(nSystemType, nState, sStateDesc))	//  [7/17/2006] vivache
		{
			s.Format("<PHONE>GetPhoneState() Fail!");
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>GetPhoneState()!");	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::GetPhoneState";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::GetPhoneStatus(LPPHONESTATUS PhoneStatus)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->GetPhoneStatus(PhoneStatus))	//  [7/17/2006] vivache
		{
			s.Format("<PHONE>GetPhoneStatus() Fail!");
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>GetPhoneStatus()!");	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::GetPhoneStatus";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::ChangeDiagPath(WORD uMSM)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->ChangeDiagPath(uMSM))	//  [7/17/2006] vivache
		{
			s.Format("<PHONE>ChangeDiagPath() Fail!");
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>ChangeDiagPath(%d)!", uMSM);	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::ChangeDiagPath";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetFTMNV(BOOL bSet)
{
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetFTMNV(bSet))	//  [7/17/2006] vivache
		{
			s.Format("<PHONE>SetFTMNV() Fail!");
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetFTMNV(%d)!", bSet?1:0);	//  [7/17/2006] vivache
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetFTMNV";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

void CGDPhoneImp::SetEventHandler(CInstrumentEvent* pSpy)
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return;
	m_cs.Lock();
	m_PhoneFactory.SetEventHandler(pSpy);
	m_cs.Unlock();
	return; 
}

BOOL CGDPhoneImp::SetTestMode(CString sItemName)
{
	CString sResult(_T(""));
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetTestMode(sItemName, sResult))	//  [7/18/2006] lupis
		{
			s = CString("<PHONE>SetTestMode(") + sItemName + ") Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = CString("<PHONE>SetTestMode(") + sItemName + ")!" + sResult;	//  [7/18/2006] lupis
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetTestMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetVSIM()
{
	CString sResult(_T(""));
	CString s(_T(""));	//  [7/17/2006] vivache

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetVSIM())	//  [7/18/2006] lupis
		{
			s = "<PHONE>SetVSIM() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>SetVSIM()!";	//  [7/18/2006] lupis
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetVSIM";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetEmergencyCall(BOOL bOnOff)
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetEmergencyCall(bOnOff))	
		{
			s.Format("<PHONE>SetEmergencyCall(%d) Fail!", (bOnOff ? 1 : 0) );
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetEmergencyCall(%d)!", (bOnOff ? 1 : 0) );
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetEmergencyCall";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetMRDMode(int nModeIndex, int nDelay)					//  [7/3/2007] vivache : MRD Mode ��ȯ
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetMRDMode(nModeIndex, nDelay))	
		{
			s = "<PHONE>SetMRDMode() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		(nModeIndex == 0 ? sResult = "Normal" : sResult = "Sub Rx");

		s = "<PHONE>SetMRDMode()! " + sResult;
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetMRDMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetWLANMode(BOOL bState, int nPreDelay, int *pnErrCode, int nWlanType /* = INDEX_WLAN_802_11G*/ )								//  [7/3/2007] vivache : WLAN Testmode ��ȯ/����
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetWLANMode(bState, nPreDelay, pnErrCode, nWlanType))	
		{
			s = "<PHONE>SetWLANMode() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		(bState ? sResult = "ON" : sResult = "OFF" );
		s = "<PHONE>SetWLANMode(" + sResult + ")!";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetWLANMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetWLANRxMode(double& fPer, int nChannel, int nDelay )	//  [7/3/2007] vivache : WLAN Rx Mode
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetWLANRxMode(fPer, nChannel, nDelay))	
		{
			s = "<PHONE>SetWLANRxMode() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB
		
		sResult.Format("(BER/PER : %f)", fPer);
		s = "<PHONE>SetWLANRxMode()!" + sResult;
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetWLANRxMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetWLANTxMode(int nChannel, int nLevel)					//  [7/3/2007] vivache : WLAN Tx Mode
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetWLANTxMode(nChannel, nLevel))	
		{
			s = "<PHONE>SetWLANTxMode() Fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB
		
		s = "<PHONE>SetWLANTxMode()!";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetWLANTxMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::IsCalibration()
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->IsCalibration())	
		{
			s = "<PHONE>IsCalibration() : No Cal Data!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s = "<PHONE>IsCalibration()! : Cal OK";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::IsCalibration";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::GetRSSI(double& fRssi)	//  [10/23/2007] vivache : CDMA Rssi value �о����
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->GetRSSI(fRssi))	
		{
			s = "<PHONE>GetRSSI() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>GetRSSI(%f)!", fRssi);
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::GetRSSI";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::ChangeUartPath(int nDirection)	//  [10/24/2008] vivache : Dual CPU Model�� ��� Master/Slave �� UART Path switching�� ���ؼ� �����.
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->ChangeUartPath(nDirection))	
		{
			s = "<PHONE>ChangeUartPath() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>ChangeUartPath(%d)!", nDirection);
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::ChangeUartPath";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::BandChange(int bandItem) // [1/8/2009] By Karl. For ADI quad band chipset. Change main band from EUR to US or US to EUR by command.
{
	CString sResult(_T(""));
	CString s(_T(""));


	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->BandChange(bandItem))	
		{
			s = "<PHONE>BandChange() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>BandChange(%d)!", bandItem);
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::BandChange";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::ChangeSystem(int nDirection)
{
	CString sResult(_T(""));
	CString s(_T(""));


	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB
			
		if(!pPhone->ChangeSystem(nDirection))	
		{
			s = "<PHONE>ChangeSystem() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>ChangeSystem(%d)!", nDirection);
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::ChangeSystem";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetCampRequest(int nBand)	//  [5/26/2009] vivache : GSM �� ���� ��� command.
{
	CString sResult(_T(""));
	CString s(_T(""));


	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetCampRequest(nBand))	
		{
			s = "<PHONE>SetCampRequest() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetCampRequest(%d)!", nBand);
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetCampRequest";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetSleepMode()	//  [9/16/2009] vivache : Sleep mode
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetSleepMode())	
		{
			s = "<PHONE>SetSleepMode() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetSleepMode()!");
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetSleepMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetDetach() //  [9/18/2009] vivache : detatch
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetDetach())	
		{
			s = "<PHONE>SetDetach() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetDetach()!");
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetDetach";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetOriginCall(WORD wMode /* = DIAG_VOICE_CALL */)
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetOriginCall(wMode))	
		{
			s = "<PHONE>SetOriginCall() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetOriginCall(%d)!", wMode);
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetOriginCall";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetEndCall()
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetEndCall())	
		{
			s = "<PHONE>SetEndCall() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetEndCall()!");
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetEndCall";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetMimoAntCheck(int nMode)
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetMimoAntCheck(nMode))	
		{
			s = "<PHONE>SetMimoAntCheck() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetMimoAntCheck()!");
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetMimoAntCheck";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetLteAttach(BOOL bOn)
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetLteAttach(bOn))	
		{
			s = "<PHONE>SetLteAttach() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetLteAttach()!");
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetLteAttach";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

// [7/19/2010] JKPARK : û�ְ��� ����
BOOL CGDPhoneImp::SetPidFlag(int nIndex, char cValue)
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetPidFlag(nIndex, cValue))	
		{
			s = "<PHONE>SetPidFlag() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetPidFlag()!");
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetPidFlag";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetL2000Prepare(BOOL bIsVSIM)
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetL2000Prepare(bIsVSIM))	
		{
			s = "<PHONE>SetL2000Prepare() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetL2000Prepare()!");
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetL2000Prepare";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

// [10/15/2010] JKPARK : P500/509 Registration �ҷ� ���� ���� �߰���.
BOOL CGDPhoneImp::SetFlightMode(BOOL bOnOff) 
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetFlightMode(bOnOff))	
		{
			s = "<PHONE>SetFlightMode() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		if(bOnOff)
			s.Format("<PHONE>SetFlightMode (ON)!");
		else
			s.Format("<PHONE>SetFlightMode (OFF)!");

		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetFlightMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

BOOL CGDPhoneImp::SetQEMmode(BOOL bMode)								//  [4/14/2011] JKPARK 
{
	CString sResult(_T(""));
	CString s(_T(""));

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetQEMmode(bMode))	
		{
			s = "<PHONE>SetQEMMode() fail!";
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		if(bMode)
			s.Format("<PHONE>SetQEMmode (ON)!");
		else
			s.Format("<PHONE>SetQEMmode (OFF)!");

		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetFlightMode";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}


	return TRUE;
}

// [7/23/2011] JKPARK : AT����ϴ� CDMA���� LB Call Function
BOOL CGDPhoneImp::SetLoopBackCall(BOOL bOnOff)
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetLoopBackCall(bOnOff))	
		{
			s.Format("<PHONE>SetLoopbackCall(%d) Fail!", (bOnOff ? 1 : 0) );
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetLoopbackCall(%d)!", (bOnOff ? 1 : 0) );
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetLoopbackCall";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}

// [11/10/2011] JKPARK 
BOOL CGDPhoneImp::SetLcdOnOff(BOOL bOnOff)
{
	CString sResult(_T(""));
	CString s(_T(""));

//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();
//	if (!pPhoneFactory)
//		return FALSE;

	CPhone *pPhone = m_PhoneFactory.GetPhone();
	if (!pPhone)
		return FALSE;

	try
	{
		m_cs.Lock();
		BEGIN_USB

		if(!pPhone->SetLcdOnOff(bOnOff))	
		{
			s.Format("<PHONE>SetLcdOnOff(%d) Fail!", (bOnOff ? 1 : 0) );
			if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
			m_cs.Unlock();
			return FALSE;
		}

		END_USB

		s.Format("<PHONE>SetLcdOnOff(%d)!", (bOnOff ? 1 : 0) );
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
	}
	catch(...)
	{
		s = "<PHONE>Exception Occurred in GDPhoneImp::SetEmergencyCall";
		if(m_PhoneFactory.m_pSpy != NULL)
				m_PhoneFactory.m_pSpy->SendSpyMessage(s);
		m_cs.Unlock();
		return FALSE;
	}

	return TRUE;
}