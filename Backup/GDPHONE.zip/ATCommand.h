// ATCommand.h: interface for the CATCommand class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ATCOMMAND_H__B9E291BB_02E9_41A9_9410_8B9D6CB0856F__INCLUDED_)
#define AFX_ATCOMMAND_H__B9E291BB_02E9_41A9_9410_8B9D6CB0856F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "serial.h"

// The instance of CATCommand class is use for AT command communication with phone

class CATCommand : public CSerial  
{
public:
	BOOL ReadOnly(int nTimeOut, int nPreDelay);
	BOOL WriteOnly(int nReqLength);
	BOOL AutoProcessing(int nReqLength, int nTimeOut, CString sReturn = "");
	int Processing(int nReqLength, int nTimeOut);
	BOOL Close();
	BOOL Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB = FALSE);
	CATCommand();
	virtual ~CATCommand();

};

#endif // !defined(AFX_ATCOMMAND_H__B9E291BB_02E9_41A9_9410_8B9D6CB0856F__INCLUDED_)
