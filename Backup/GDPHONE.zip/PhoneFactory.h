// PhoneFactory.h: interface for the CPhoneFactory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PHONEFACTORY_H__A05604C0_EE07_4881_BEF7_8179FC307091__INCLUDED_)
#define AFX_PHONEFACTORY_H__A05604C0_EE07_4881_BEF7_8179FC307091__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPhone;

class CSerial;

class CPhoneFactory : public CObject  
{
// Operation
public:
	CPhone * GetPhone();
	BOOL SearchSWVersion(int nPortNo, BOOL bIsCDMA, CString &sSWVersion);
	BOOL ExitPhone();
	BOOL InitPhone(int nCommMode);
	void SetEventHandler(CInstrumentEvent* pSpy);	//  [7/17/2006] vivache
	static CPhoneFactory *GetInstance();
	static void DeleteInstance();

public:
	CPhoneFactory();
	virtual ~CPhoneFactory();

// Attribuet
protected:
	static CPhoneFactory *m_pInstance;

	CPhone *m_pPhone;
	CSerial *m_pSerial;
public:
	BOOL EnableUSB(BOOL bOn);
	BOOL IsUSB();
	CInstrumentEvent* m_pSpy;	//  [7/17/2006] vivache
};

#endif // !defined(AFX_PHONEFACTORY_H__A05604C0_EE07_4881_BEF7_8179FC307091__INCLUDED_)
