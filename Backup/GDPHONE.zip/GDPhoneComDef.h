#ifndef _GDPHONECOMMONDEFINE
#define _GDPHONECOMMONDEFINE

//////////////////////////////////////////////////////////////////////////
// ftm, dmss test mode sub command
const byte SUB_WLAN_MODE_ON(4);				//802.11g 54M
const byte SUB_WLAN_MODE_OFF(5);
const byte SUB_WLAN_START_LOW_RX(6);
const byte SUB_WLAN_START_MID_RX(7);
const byte SUB_WLAN_START_HIGH_RX(8);
const byte SUB_WLAN_GET_RX_RESULT(9);
const byte SUB_WLAN_START_LOW_TX(10);
const byte SUB_WLAN_START_MID_TX(11);
const byte SUB_WLAN_START_HIGH_TX(12);
const byte SUB_WLAN_STOP_RX_TX_TEST(13);
const byte SUB_WLAN_802_11N_MODE_ON(76);	// 802.11n 64M
const byte SUB_WLAN_802_11A_MODE_ON(20);		// [8/8/2011] JKPARK : �ӽ�
const byte SUB_WLAN_START_802_11A_LOW_TX(17);

// AT String WLAN

const CString STRING_802_11G_54M(_T("G54"));
const CString STRING_802_11N_64M(_T("NML7"));
const CString STRING_802_11A_54M(_T("A54"));
//////////////////////////////////////////////////////////////////////////
// Spy ���� class
class CInstrumentEvent
{
public:
	CInstrumentEvent(){};
	virtual ~CInstrumentEvent(){};

public:
	virtual void SendSpyMessage(CString sSpyMsg, BOOL bShow = TRUE) = 0;
	virtual void SendLogMessage(CString sLogMsg) = 0;
};

#endif