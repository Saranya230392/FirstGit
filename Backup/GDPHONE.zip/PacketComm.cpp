// PacketComm.cpp: implementation of the CPacketComm class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GDPhone.h"
#include "PacketComm.h"
#include "PhoneFactory.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPacketComm::CPacketComm() : CSerial()
{

}

CPacketComm::~CPacketComm()
{

}

BOOL CPacketComm::Open(int nPortNo, DWORD dwBaudRate)
{
	return CSerial::Open(nPortNo, dwBaudRate);
}

BOOL CPacketComm::Close()
{
	return CSerial::Close();
}

int CPacketComm::Processing(int nReqLength, int nTimeOut)
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();	// For Spy
//	if (!pPhoneFactory)
//		return FALSE;

	BYTE *ReqBuff = NULL;
	BYTE TxBuff[MAX_PACKET_SIZE];
	BYTE RxBuff[MAX_PACKET_SIZE];
	BYTE RxTmp[MAX_PACKET_SIZE];

	// Buffer �ʱ�ȭ //
	ZeroMemory(TxBuff, MAX_PACKET_SIZE);
	ZeroMemory(RxTmp, MAX_PACKET_SIZE);

	int	 nTxLength=0;
	int	 nRxLength=0;
	int	 i,j,nReturn;
	// - 	
	WORD CRC;
	BYTE CRC_HIGH,CRC_LOW;
	BYTE Result;
	BOOL ESC_Received = FALSE;

	clock_t	Goal;

	ReqBuff = (BYTE *)&m_Request;

	// Compare data to ASYNC_HDLC_ESC or ASYNC_HDLC_FLAG
	for(i=0; i<nReqLength; i++) 
	{
		// �ش� ����(ReqBuff)�� ��� ����� �����̸� 0x20���� ����ũ 
		// �ƴϸ� �״�� ����
		if(IsControlCharacter(&Result,*ReqBuff++)) 
		{
			TxBuff[nTxLength++] = ASYNC_HDLC_ESC;
			TxBuff[nTxLength++] = Result;
		}
		else{ TxBuff[nTxLength++] = Result; }
	}

	CRC = CRC_SEED;
	ReqBuff = (BYTE *)&m_Request;
	
	for(i=0; i<nReqLength; i++) 
	{
		CRC = ComputeCRC(CRC,*ReqBuff++);
	}

	CRC		^= 0xFFFF;
	CRC_LOW  = (BYTE)CRC;
	CRC_HIGH = (BYTE)(CRC>>8);
	
	// CRC_LOW
	if(IsControlCharacter(&Result,CRC_LOW)) 
	{
		TxBuff[nTxLength++] = ASYNC_HDLC_ESC;
		TxBuff[nTxLength++] = Result;
	}
	else{ TxBuff[nTxLength++] = Result;}

	// CRC_HIGH
	if(IsControlCharacter(&Result,CRC_HIGH)) 
	{
		TxBuff[nTxLength++] = ASYNC_HDLC_ESC;
		TxBuff[nTxLength++] = Result;
	}
	else
	{ 
		TxBuff[nTxLength++] = Result; 
	}

	TxBuff[nTxLength++] = ASYNC_HDLC_FLAG;	// End of Packet Flag
	TxBuff[nTxLength++] = ASYNC_HDLC_FLAG;	// ����� �� �ǰ� �ϱ� ���� �ѹ� �� ���� (2006.8.22 ������)

	if(!WriteCommPort(TxBuff,nTxLength)) 
		return(ERROR_PACKET_WRITE);

	CString sTxMonitor(_T("[TX to Phone] ")); 
	CString sTemp(_T(""));
	int nMaxMonitor = min(nTxLength, 10);
	for( i=0 ; i < nMaxMonitor ; i++ ) 
	{
		sTemp.Format("%02x ", (int)TxBuff[i]);
		sTxMonitor += sTemp;
	}
	m_pPhoneFactory->m_pSpy->SendLogMessage(sTxMonitor);


	Goal = (clock_t)nTimeOut + clock();
    
    nRxLength = 0; //���� ����Ʈ�� �ʱ�ȭ 
	
	while(1) 
	{
		nReturn=ReadCommPort((LPSTR)&RxTmp[nRxLength],(DWORD*)&nRxLength);

		if(nReturn==FALSE)
			return(ERROR_PACKET_READ);
		else if(nReturn==ERROR_PACKET_OVERFLOW) 
			return(ERROR_PACKET_OVERFLOW);  
		
        if(nRxLength >0){ if(RxTmp[nRxLength-1] == ASYNC_HDLC_FLAG) break; } // ASYNC_HDLC_FLAG : 0x7E

        if(Goal <= clock()) 
			return(ERROR_PACKET_TIME_OVER);
	}
    
	// Control ���� ó��
	j = 0;
	for(i=0; i<nRxLength; i++) 
	{
		if(RxTmp[i]==ASYNC_HDLC_ESC) ESC_Received = TRUE;
		else 
		{
			if(ESC_Received) 
			{
				RxBuff[j++] = RxTmp[i] ^ ASYNC_HDLC_ESC_MASK;
				ESC_Received = FALSE;
			}
			else{ RxBuff[j++] = RxTmp[i]; }
		}
	}

	nRxLength = j;
	CRC = CRC_SEED;
	
	for(i=0; i<nRxLength; i++) CRC = ComputeCRC(CRC, RxBuff[i]);

	if(CRC==CRC_END) 
		return(ERROR_PACKET_CRC);
	
	if(RxBuff[0] != m_Request.req.cmd_code) 
		return(ERROR_PACKET_ACK);

	memcpy(&m_Response,RxBuff,nRxLength);

	CString sRxMonitor(_T("[RX From Phone] "));
	nMaxMonitor = min(nRxLength, 10);
	for( i=0 ; i < nMaxMonitor ; i++ )
	{
		sTemp.Format("%02x ", (int)RxBuff[i]);
		sRxMonitor += sTemp;
	}
	m_pPhoneFactory->m_pSpy->SendLogMessage(sRxMonitor);

	return TRUE;
}

BOOL CPacketComm::AutoProcessing(int nReqLength, int nTimeOut, CString sReturn)
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();	// For Spy
//	if (!pPhoneFactory)
//		return FALSE;
	
	int	nResultPacket;
	// MAX_PACKET_RETRY ������ ��õ�
	for (int i=0; i < MAX_PACKET_RETRY; i++) {
		nResultPacket = Processing(nReqLength, nTimeOut);

		switch(nResultPacket)
		{ 
			case 1 : case 2 : return TRUE; 
			
			// ���� ���� Data�� ���̰� MAX_PACKET_SIZE �̻�
			case ERROR_PACKET_OVERFLOW : continue;

			// ������ �ð����� ������ ������ ����ó��
			case ERROR_PACKET_TIME_OVER : 
				// Data ��Ÿ�带 DM ���� ��ȯ
				if( i % 3 == 0 )  // i < 10
				{ 
					if ( !DataToDM() )
					{
						m_pPhoneFactory->m_pSpy->SendLogMessage("[DataToDM Fail]");
						return FALSE; 
					}
					else
					{
						m_pPhoneFactory->m_pSpy->SendLogMessage("[DataToDM!]");
					}

					continue; 
				}
				break;

			case ERROR_PACKET_WRITE :	// For VX11K
				return FALSE;			// For VX11K
			
			default : // ��� noise���� ����
				// Data ��Ÿ�带 DM ���� ��ȯ
				if( i % 3 == 0 )  // i < 10
				{ 
					if ( !DataToDM() )
					{
						m_pPhoneFactory->m_pSpy->SendLogMessage("DataToDM Fail");
						return FALSE; 
					}
					else
					{
						m_pPhoneFactory->m_pSpy->SendLogMessage("DataToDM!");
					}

					continue; 
				}
		}
	}
	return FALSE;
}

BOOL CPacketComm::ReadOnly(int nTimeOut, int nPreDelay)
{
	return FALSE;
}

BOOL CPacketComm::WriteOnly(int nReqLength)
{
	return FALSE;
}
