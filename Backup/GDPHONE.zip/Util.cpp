// Util.cpp: implementation of the CUtil class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GDPhone.h"
#include "Util.h"
#include "EnumSerial.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CStringList CUtil::m_TraceQueue;
const int CUtil::m_nTraceQueueSize = 100;


CUtil::CUtil()
{

}

CUtil::~CUtil()
{

}

int CUtil::GetUSBPortNo(CString sDriverName)
{
	CArray<SSerInfo,SSerInfo&> asi;
	CString sComPortName(_T(""));
	int nPortNo = 0;
	BOOL bFind = FALSE;
	int nRetryCnt = 0;
	int nBeginIndex = -1;
	int nEndIndex = -1;

	if (sDriverName.IsEmpty())
		return 0;
	sDriverName.MakeUpper();

	// 7�ʴ� Device Driver�� �ε��Ǵµ� ���� ��ٸ��� Time Out �ð��̴�
	while(nRetryCnt < 7)
	{
		EnumSerialPorts(asi,FALSE/*include all*/);
		for (int i=0; i<asi.GetSize(); i++)
		{ 
//			EnumSerialPorts(asi,FALSE/*include all*/);
			sComPortName=asi[i].strFriendlyName;
			sComPortName.MakeUpper();
			if(sComPortName.Find(sDriverName) >= 0) 
			{
				bFind = TRUE;
				break;
			}
		}
		asi.RemoveAll();

		if (bFind) break;
		++nRetryCnt;
		Sleep(1000);
	}
	if (nRetryCnt == 7)
		return 0;
	// Port ��ȣ ����
	if ( (nBeginIndex = sComPortName.Find("(COM"))<=0 )
		return 0;
	if ( ((nEndIndex = sComPortName.Find(")",nBeginIndex+4))<=0) || (nEndIndex<nBeginIndex) )
		return 0;
	if ( (nPortNo = atoi(sComPortName.Mid(nBeginIndex+4,nEndIndex+4-nBeginIndex))) <=0 )
		return 0;

	return nPortNo;	
}

CString CUtil::AttachCR(CString sInputStr)
{
	CString sOutputStr(_T(""));
	sOutputStr.Format("%s%c",sInputStr,0x0d);

	return sOutputStr;
}

CString CUtil::AttachLF(CString sInputStr)
{
	CString sOutputStr(_T(""));
	sOutputStr.Format("%s%c",sInputStr,0x0a);

	return sOutputStr;
}

CString CUtil::ExtractBtwStxEtx(CString sInputStr)
{
	CString sOutputStr(_T(""));
	int nStart = -1;
	int nEnd = -1;

	nStart = sInputStr.Find(0x02);	// 0x02 (STX)
	nEnd = sInputStr.Find(0x03);	// 0x03 (ETX)
	if( nStart<0 || nEnd <0 )
		return CString(_T(""));
	sOutputStr = sInputStr.Mid(nStart+1, nEnd-nStart-1);

	return sOutputStr;
}

CString CUtil::ExtractBtwLFCR(CString sInputStr)
{
	CString sOutputStr(_T(""));
	int nStart = -1;
	int nEnd = -1;

	do{
		nStart = sInputStr.Find(0x0a, nEnd+1);	// 0x0d 0x0a (�����) 0x0d 0x0a
		nEnd = sInputStr.Find(0x0d, nStart+1);
	}while( nStart>=0 && nEnd>=0 && (nEnd-nStart)<=1 );	// 0x0d 0x0a �� �������� ���� ��츦 �ɷ���

	if( nStart<0 && nEnd<0 )
		return CString(_T(""));

	if( nStart>=0 && nEnd<0 )	// ������տ� 0x0d 0x0a�� �� ���� ���
	{
		nEnd = nStart - 1;
		nStart = -1;
	}

	sOutputStr = sInputStr.Mid(nStart+1, nEnd-nStart-1);

	return sOutputStr;
}

void CUtil::GDTrace(char *szFormat, ...)
{
	va_list argList;
	char szTraceBuffer[512];

	va_start(argList, szFormat);
	vsprintf(szTraceBuffer, szFormat, argList);

	CString sTraceBuffer(szTraceBuffer);

	if ( m_TraceQueue.GetCount() >= m_nTraceQueueSize )
		PopTrace();

	m_TraceQueue.AddTail(sTraceBuffer);
}

CString CUtil::PopTrace()
{
	if ( m_TraceQueue.GetCount() <= 0 )
		return CString(_T(""));

	CString sTraceItem;
	sTraceItem = m_TraceQueue.RemoveHead();

	return sTraceItem;
}

#define CAMPREQ_GSM900		1
#define CAMPREQ_GSM850		2
#define CAMPREQ_PCS			3
#define CAMPREQ_DCS			4
#define CAMPREQ_GSMONLY		6
#define CAMPREQ_WCDMA_I		7
#define CAMPREQ_WCDMA_II	8
#define CAMPREQ_WCDMA_III	9
#define CAMPREQ_WCDMA_IV	10
#define CAMPREQ_WCDMA_V		11
#define CAMPREQ_WCDMA_VI	12
#define CAMPREQ_WCDMA_VII	13
#define CAMPREQ_WCDMA_VIII	14
#define CAMPREQ_WCDMA_IX	15
#define CAMPREQ_WCDMA_X		16
#define CAMPREQ_WCDMAONLY	17
#define CAMPREQ_AUTOMATIC	18

#define CAMPREQ_CDMAONLY	23		// [7/1/2011] JKPARK : CDMA Only �߰�
#define CAMPREQ_EVDOONLY	24		// [7/21/2011] JKPARK : EVDO ONly �߰�
/*
#define	CAMPREQ_LTE_I		19
#define CAMPREQ_LTE_XVII	20
#define CAMPREQ_LTE_XX		25
#define CAMPREQ_LTE_XIII	30
#define CAMPREQ_LTE_V		35
#define CAMPREQ_LTE_IV		40
#define CAMPREQ_LTE_II		45
*/

//---------------------------------------------------------
// LTE band re-count.

#define CAMPREQ_LTE_I		51
#define CAMPREQ_LTE_II		52
#define CAMPREQ_LTE_III		53
#define CAMPREQ_LTE_IV		54
#define CAMPREQ_LTE_V		55
#define CAMPREQ_LTE_VII		57
#define CAMPREQ_LTE_VIII	58
#define CAMPREQ_LTE_IX		59
#define CAMPREQ_LTE_X		60
#define CAMPREQ_LTE_XI		61
#define CAMPREQ_LTE_XII		62
#define CAMPREQ_LTE_XIII	63
#define CAMPREQ_LTE_XIV		64
#define CAMPREQ_LTE_XVII	67
#define CAMPREQ_LTE_XVIII	68
#define CAMPREQ_LTE_XIX		69
#define CAMPREQ_LTE_XX		70
#define CAMPREQ_LTE_XXI		71
#define CAMPREQ_LTE_XXV		75





int CUtil::GetCampRequestBandIndex(int nBand)
{
	int nBandIndex(0);

	switch(nBand)
	{
	case INDEX_LTE_I_BAND:
	
		nBandIndex = CAMPREQ_LTE_I;
		break;
	case INDEX_LTE_II_BAND:
		nBandIndex = CAMPREQ_LTE_II;
		break;
	case INDEX_LTE_III_BAND:
		nBandIndex = CAMPREQ_LTE_III;
		break;
	case INDEX_LTE_IV_BAND:
		nBandIndex = CAMPREQ_LTE_IV;
		break;		
	case INDEX_LTE_V_BAND:
		nBandIndex = CAMPREQ_LTE_V;
		break;
	case INDEX_LTE_VII_BAND:
		nBandIndex = CAMPREQ_LTE_VII;
		break;
	case INDEX_LTE_VIII_BAND:
		nBandIndex = CAMPREQ_LTE_VIII;
		break;
	case INDEX_LTE_IX_BAND:
		nBandIndex = CAMPREQ_LTE_IX;
		break;		
	case INDEX_LTE_X_BAND:
		nBandIndex = CAMPREQ_LTE_X;
		break;
	case INDEX_LTE_XI_BAND:
		nBandIndex = CAMPREQ_LTE_XI;
		break;
	case INDEX_LTE_XII_BAND:
		nBandIndex = CAMPREQ_LTE_XII;
		break;	
	case INDEX_LTE_XIII_BAND:
		nBandIndex = CAMPREQ_LTE_XIII;
		break;
	case INDEX_LTE_XIV_BAND:
		nBandIndex = CAMPREQ_LTE_XIV;
		break;
		
	case INDEX_LTE_XVII_BAND:
		nBandIndex = CAMPREQ_LTE_XVII;
		break;
	case INDEX_LTE_XVIII_BAND:
		nBandIndex = CAMPREQ_LTE_XVIII;
		break;
	case INDEX_LTE_XIX_BAND:
		nBandIndex = CAMPREQ_LTE_XIX;
		break;	
	case INDEX_LTE_XX_BAND:
		nBandIndex = CAMPREQ_LTE_XX;
		break;	
	case INDEX_LTE_XXI_BAND:
		nBandIndex = CAMPREQ_LTE_XXI;
		break;
	case INDEX_LTE_XXV_BAND:
		nBandIndex = CAMPREQ_LTE_XXV;		
		break;

// �������� : ������ AD600, VL600, WM300 ������ L2000 �𵨵��� campreq ������� �ʰ� call connection ����
		//campreq �ؾ��ϴ� �𵨵��� ���� L2000 �𵨵�. 
		//MDM Ĩ���� ��� SIMOFF ���ɾ�� �ٷ� attach ��

		
		/*
	case INDEX_GSM900_BAND:
		nBandIndex = CAMPREQ_GSM900;
		break;
	case INDEX_GSM850_BAND:
		nBandIndex = CAMPREQ_GSM850;+
		break;
	case INDEX_PCS1900_BAND:l
		nBandIndex = CAMPREQ_PCS;
		break;
	case INDEX_DCS1800_BAND:
		nBandIndex = CAMPREQ_DCS;
		break;

	case INDEX_WCDMA_I_BAND:
		nBandIndex = CAMPREQ_WCDMA_I;
		break;
	case INDEX_WCDMA_II_BAND:
		nBandIndex = CAMPREQ_WCDMA_II;
		break;
	case INDEX_WCDMA_III_BAND:
		nBandIndex = CAMPREQ_WCDMA_III;
		break;
	case INDEX_WCDMA_IV_BAND:
		nBandIndex = CAMPREQ_WCDMA_IV;
		break;
	case INDEX_WCDMA_V_BAND:
		nBandIndex = CAMPREQ_WCDMA_V;
		break;
	case INDEX_WCDMA_VI_BAND:
		nBandIndex = CAMPREQ_WCDMA_VI;
		break;
	case INDEX_WCDMA_VIII_BAND:
		nBandIndex = CAMPREQ_WCDMA_VIII;
		break;
*/	
	case INDEX_USPCS_BAND:						// [7/1/2011] JKPARK 
	case INDEX_CDMA_BAND:
	case INDEX_KPCS_BAND:
		nBandIndex = CAMPREQ_CDMAONLY;	
		break;

	case INDEX_EVDOCDMA_BAND:					// [7/21/2011] JKPARK 
	case INDEX_EVDOUSPCS_BAND:
	case INDEX_EVDOKPCS_BAND:
		nBandIndex = CAMPREQ_EVDOONLY;
		break;
	//  [11/16/2011]
	case 25:
		nBandIndex = 25;
		break;
	case 20:
		nBandIndex = 20;
		break;
	case 40:
		nBandIndex = 40;
		break;
	// old version of campreq numbers. insert in order to prevent model issue.
	///////////////////////////////////////
	case INDEX_ALL_BAND:
		nBandIndex = CAMPREQ_AUTOMATIC;		

	default:
		nBandIndex = CAMPREQ_AUTOMATIC;	
		break;
	}

	return nBandIndex;
}

#define TESTMODE_CAMPREQ_GSM900		4
#define TESTMODE_CAMPREQ_GSM850		5
#define TESTMODE_CAMPREQ_PCS		6
#define TESTMODE_CAMPREQ_DCS		7
#define TESTMODE_CAMPREQ_GSMONLY	8
#define TESTMODE_CAMPREQ_WCDMA_I	9
#define TESTMODE_CAMPREQ_WCDMA_II	10
#define TESTMODE_CAMPREQ_WCDMA_III	11
#define TESTMODE_CAMPREQ_WCDMA_IV	12
#define TESTMODE_CAMPREQ_WCDMA_V	13
#define TESTMODE_CAMPREQ_WCDMA_VI	14
#define TESTMODE_CAMPREQ_WCDMA_VII	15
#define TESTMODE_CAMPREQ_WCDMA_VIII	16
#define TESTMODE_CAMPREQ_WCDMA_IX   17
#define TESTMODE_CAMPREQ_WCDMA_X	18
#define TESTMODE_CAMPREQ_WCDMAONLY	19
#define TESTMODE_CAMPREQ_AUTOMATIC	20
//-------------------------------------------
//  [6/4/2011] by karl. LTE band ����
/*
#define TESTMODE_CAMPREQ_LTE_I      22
#define TESTMODE_CAMPREQ_LTE_XVII   23
#define TESTMODE_CAMPREQ_LTE_XX     24
#define TESTMODE_CAMPREQ_LTE_XIII   25
#define TESTMODE_CAMPREQ_LTE_V      26
#define TESTMODE_CAMPREQ_LTE_IV		27
#define TESTMODE_CAMPREQ_LTE_II		28
*/

#define TESTMODE_CAMPREQ_LTE_I		51
#define TESTMODE_CAMPREQ_LTE_II		52
#define TESTMODE_CAMPREQ_LTE_III	53
#define TESTMODE_CAMPREQ_LTE_IV		54
#define TESTMODE_CAMPREQ_LTE_V		55
#define TESTMODE_CAMPREQ_LTE_VII	57
#define TESTMODE_CAMPREQ_LTE_VIII	58
#define TESTMODE_CAMPREQ_LTE_IX		59
#define TESTMODE_CAMPREQ_LTE_X		60
#define TESTMODE_CAMPREQ_LTE_XI		61
#define TESTMODE_CAMPREQ_LTE_XII	62
#define TESTMODE_CAMPREQ_LTE_XIII	63
#define TESTMODE_CAMPREQ_LTE_XIV	64
#define TESTMODE_CAMPREQ_LTE_XVII	67
#define TESTMODE_CAMPREQ_LTE_XVIII	68
#define TESTMODE_CAMPREQ_LTE_XIX	69
#define TESTMODE_CAMPREQ_LTE_XX		70
#define TESTMODE_CAMPREQ_LTE_XXI	71
#define TESTMODE_CAMPREQ_LTE_XXV	75


byte CUtil::GetCampRequestBandSubCommand(int nBand)
{
	byte byteBandIndex(0);

	switch(nBand)
	{


	case INDEX_LTE_I_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_I;
		break;
	case INDEX_LTE_II_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_II;
		break;
	case INDEX_LTE_III_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_III;
		break;
	case INDEX_LTE_IV_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_IV;
		break;
	case INDEX_LTE_V_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_V;
		break;
	case INDEX_LTE_VII_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_VII;
		break;
	case INDEX_LTE_XIII_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_XIII;
		break;
	case INDEX_LTE_XVII_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_XVII;
		break;
	case INDEX_LTE_XX_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_XX;
		break;
	case INDEX_LTE_XXV_BAND:
		byteBandIndex = TESTMODE_CAMPREQ_LTE_XXV;
		break;
	
/*
			case INDEX_GSM900_BAND:
			byteBandIndex = TESTMODE_CAMPREQ_GSM900;
			break;
			case INDEX_GSM850_BAND:
			byteBandIndex = TESTMODE_CAMPREQ_GSM850;
			break;
			case INDEX_PCS1900_BAND:
			byteBandIndex = TESTMODE_CAMPREQ_PCS;
			break;
			case INDEX_DCS1800_BAND:
			byteBandIndex = TESTMODE_CAMPREQ_DCS;
			break;
			case INDEX_WCDMA_I_BAND:
				byteBandIndex = TESTMODE_CAMPREQ_WCDMA_I;
				break;
			case INDEX_WCDMA_II_BAND:
				byteBandIndex = TESTMODE_CAMPREQ_WCDMA_II;
				break;
			case INDEX_WCDMA_III_BAND:
				byteBandIndex = TESTMODE_CAMPREQ_WCDMA_III;
				break;
			case INDEX_WCDMA_IV_BAND:
				byteBandIndex = TESTMODE_CAMPREQ_WCDMA_IV;
				break;
			case INDEX_WCDMA_V_BAND:
				byteBandIndex = TESTMODE_CAMPREQ_WCDMA_V;
				break;
			case INDEX_WCDMA_VI_BAND:
				byteBandIndex = TESTMODE_CAMPREQ_WCDMA_VI;
				break;
			case INDEX_WCDMA_VIII_BAND:
				byteBandIndex = TESTMODE_CAMPREQ_WCDMA_VIII;
				break;*/
		
	default:
		byteBandIndex = TESTMODE_CAMPREQ_AUTOMATIC;
		break;
	}

	return byteBandIndex;
}

byte CUtil::GetValueFromWlanType_Testmode(int nWlanType)
{
	byte btRetVal(SUB_WLAN_MODE_ON);

	switch(nWlanType)
		{
		case INDEX_WLAN_802_11G:
			btRetVal = SUB_WLAN_MODE_ON;		// 802.11g 54M
			break;

		case INDEX_WLAN_802_11N:
			btRetVal = SUB_WLAN_802_11N_MODE_ON;	// 802.11n 64M
			break;
		case INDEX_WLAN_802_11A:
			btRetVal = SUB_WLAN_802_11A_MODE_ON; //  [8/4/2011] 802.11a 54M
			break;


		default:
			break;
		}

	return btRetVal;
}


CString CUtil::GetValueFromeWlanType_Atcommand(int nWlanType)
{
	CString sRetVal(_T("G54"));

	switch(nWlanType)
		{
		case INDEX_WLAN_802_11G:
			sRetVal = STRING_802_11G_54M;		// 802.11g 54M
			break;

		case INDEX_WLAN_802_11N:
			sRetVal = STRING_802_11N_64M;	// 802.11n 64M
			break;
		case INDEX_WLAN_802_11A:
			sRetVal = STRING_802_11A_54M;
			break;

		default:
			break;
		}

	return sRetVal;
}

CString CUtil::GetLastError()
{
	LPVOID lpMsgBuf;
	FormatMessage( 
		FORMAT_MESSAGE_ALLOCATE_BUFFER | 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		::GetLastError(),
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		(LPTSTR) &lpMsgBuf,
		0,
		NULL 
	);

	CString sMsg = (char *)lpMsgBuf;

	LocalFree( lpMsgBuf );	

	return sMsg;
}