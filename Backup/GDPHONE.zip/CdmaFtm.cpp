// CdmaFtm.cpp: implementation of the CCdmaFtm class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GDPhone.h"
#include "CdmaFtm.h"
#include "Util.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CCdmaFtm::CCdmaFtm() : CPhone()
{

}

CCdmaFtm::~CCdmaFtm()
{

}

//============================================================================
//  1. Function Name : Open
//	2. Description : Phone�� ����� COM Port�� ����
//  3. Parameter : nPortNo - COM��Ʈ ��ȣ
//                 dwBaudRate - BaudRate
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : CDMA / UMTS ����
//============================================================================
BOOL CCdmaFtm::Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB)
{
	return CPhone::Open(nPortNo, dwBaudRate, bUSB);
}

//============================================================================
//  1. Function Name : OpenUSB
//	2. Description : Phone�� ����� USB Port�� ����.
//                   Driver�� Loading�Ǵ� �ð����� �ִ� 7�ʱ��� ��ٸ���.
//  3. Parameter : sDriverName - Phone�� ����ϴ� USB Driver�� �̸� �� �Ϻ��̴�.
//                               ���� CDMA ���� Driver, Qualcomm ���� Driver,
//                               EMP ���� Driver, NTT DOCOMO�� Driver�� 4������ �ִ�.
//  4. Return Value : Detect�� USB Port�� ��ȣ�� �����Ѵ�.
//	5. Remark : CDMA / UMTS ����
//============================================================================
int CCdmaFtm::OpenUSB(CString sDriverName)
{
	return CPhone::OpenUSB(sDriverName);
}

//============================================================================
//  1. Function Name : Close
//	2. Description : Phone�� ����� COM Port�� �ݴ´�
//  3. Return Value : ����
//	4. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::Close()
{
	return CPhone::Close();
}

//============================================================================
//  1. Function Name : Init
//	2. Description : ��Ÿ��(FTM/DMSS/QUALCOMM/EMP/ADITI) Ưȭ�� �ʱ��۾��� �����Ѵ�.
//  3. Return Value : �����ϸ� TRUE
//	4. Remark : FTM/DMSS/QUALCOMM/EMP/ADITI ���� ����
//============================================================================
BOOL CCdmaFtm::Init()
{
	m_pSerial->DataToDM();
	return TRUE;
}

BOOL CCdmaFtm::Exit()
{
	return TRUE;
}

//============================================================================
//  1. Function Name : IsPhoneConnected
//	2. Description : Phone�� ����Ǿ� �ִ��� Ȯ���Ѵ�
//  3. Return Value : �����ϸ� TRUE
//	4. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::IsPhoneConnected()
{
	CString sSWVersion(_T(""));

	return GetSWVersion(sSWVersion);
}

//============================================================================
//  1. Function Name : GetSWVersion
//	2. Description : Phone�� SW Version�� �о�´�
//  3. Parameter : sSWVersion - SW Version�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::GetSWVersion(CString &sSWVersion)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.verno.cmd_code = DIAG_VERNO_F;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_verno_req_type), 1500)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.verno.cmd_code != DIAG_VERNO_F)
		return FALSE;

	sSWVersion = _T("");
	sSWVersion.Format("%s",m_pSerial->m_Response.rsp.verno.ver_dir);		// [12/16/2011] JKPARK : IS11LG�� SW ver. ª�� ��쿡 ���� �߰��Ǿ� ezlooks error �߻�.	
//	for(int i=0; i<VERNO_DIR_STRLEN; i++) 
//		sSWVersion += m_pSerial->m_Response.rsp.verno.ver_dir[i];

	return TRUE;
}

//============================================================================
//  1. Function Name : GetProductID
//	2. Description : Phone�� Product ID�� �о�´�
//  3. Parameter : sProductID - Product ID�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::GetProductID(CString &sProductID)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.nv_read.cmd_code = DIAG_NV_READ_F;
	m_pSerial->m_Request.req.nv_read.item     = NV_FACTORY_INFO_I;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_nv_read_req_type), 3000)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.nv_read.cmd_code != DIAG_NV_READ_F )
		return FALSE;
	
	sProductID = m_pSerial->m_Response.rsp.nv_read.item_data.factory_info.pc_code[0];
	sProductID += m_pSerial->m_Response.rsp.nv_read.item_data.factory_info.pc_code[1];

	for(int i=0 ; i < 15 ; i++)	//  [10/22/2008] vivache : 18 --> 15���� (20�ڸ����� 17�ڸ��� ��Ȯ�ϰ� �е��� ����)
		sProductID += m_pSerial->m_Response.rsp.nv_read.item_data.factory_info.sys_time[i];

	return TRUE;
}

//============================================================================
//  1. Function Name : SetProductID
//	2. Description : Phone�� Product ID�� ����
//  3. Parameter : sProductID - Phone�� �� Product ID
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::SetProductID(CString sProductID)
{
	if ( m_pSerial == NULL )
		return FALSE;

	if ( sProductID.GetLength() < 17 )	//  [10/22/2008] vivache : PID�� 17�ڸ��� �����.
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

    m_pSerial->m_Request.req.nv_write.cmd_code = DIAG_NV_WRITE_F;
    m_pSerial->m_Request.req.nv_write.item = NV_FACTORY_INFO_I;
    m_pSerial->m_Request.req.nv_write.item_data.factory_info.pc_code[0] = sProductID[0];
    m_pSerial->m_Request.req.nv_write.item_data.factory_info.pc_code[1] = sProductID[1];
	
	//  [10/22/2008] vivache : 20 --> 17�� ����. ��Ȯ�ϰ� 17�ڸ��� write �ϵ��� ������.
	for(int i = 2 ; i < 17 ; i++) 
		m_pSerial->m_Request.req.nv_write.item_data.factory_info.sys_time[i-2] = sProductID[i];

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_nv_write_req_type), 1500)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.nv_write.cmd_code != DIAG_NV_WRITE_F )
		return FALSE;

	return TRUE;
}

//============================================================================
//  1. Function Name : GetESNIMEI
//	2. Description : Phone�� ESN�� �о�´�
//  3. Parameter : sESNIMEI - ESN�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::GetESNIMEI(CString &sESNIMEI, BOOL bIsIMEI)
{
/*
////////////////////////////////////////////////////////
// ESN Reading by DIAG_ESN_F Command
////////////////////////////////////////////////////////
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.stat.cmd_code  = DIAG_ESN_F;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_status_req_type), 1500)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.stat.cmd_code != DIAG_ESN_F )
		return FALSE;

	sESNIMEI.Format("%08x",m_pSerial->m_Response.rsp.stat.esn);

	return TRUE;
*/
	if ( bIsIMEI == FALSE )
	{
		////////////////////////////////////////////////////////
		// ESN Reading by DIAG_STATUS_F Command
		////////////////////////////////////////////////////////
		if ( m_pSerial == NULL )
			return FALSE;

		memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
		memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

		m_pSerial->m_Request.req.stat.cmd_code  = DIAG_STATUS_F;

		if(!m_pSerial->AutoProcessing((int)sizeof(diag_status_req_type), 1500)) 
			return FALSE; 

		if ( m_pSerial->m_Response.rsp.stat.cmd_code != DIAG_STATUS_F )
			return FALSE;

		sESNIMEI.Format("%08x",m_pSerial->m_Response.rsp.stat.esn);

		return TRUE;
	}
	else	// [01/19/2011] lupis : LTE
	{
		////////////////////////////////////////////////////////
		// ESN Reading by DIAG_NV_READ_F Command
		////////////////////////////////////////////////////////
		if ( m_pSerial == NULL )
			return FALSE;

		memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
		memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

		m_pSerial->m_Request.req.nv_read.cmd_code = DIAG_NV_READ_F;
		m_pSerial->m_Request.req.nv_read.item     = NV_IMEI_I;
		
		if(!m_pSerial->AutoProcessing((int)sizeof(diag_nv_read_req_type), 1500)) 
			return FALSE;

		if(m_pSerial->m_Response.rsp.nv_read.cmd_code != DIAG_NV_READ_F) 
			return FALSE;

		int _aint_IMEI[9];
		char sReadIMEI[17];
		ZeroMemory(_aint_IMEI, 9 * sizeof(int));
		ZeroMemory(sReadIMEI, 17 * sizeof(char));

		// 9���о���
		for (int ii = 0; ii < 9; ii++)
		{
			_aint_IMEI[ii] = m_pSerial->m_Response.rsp.nv_read.item_data.imei_type.imei[ii];
		}

		// �ɰ���
		sReadIMEI[0] = (char)('0' + _aint_IMEI[1] / 0x10);

		for (int jj = 1; jj < 8; jj++)
		{
			sReadIMEI[2*jj - 1] = (char)('0' + _aint_IMEI[jj + 1] % 0x10);
			sReadIMEI[2*jj] = (char)('0' + _aint_IMEI[jj + 1] / 0x10);
		}

		sReadIMEI[16] = '\0';    

		sESNIMEI.Format(_T("%s"), sReadIMEI);

		return TRUE;
	}
}

//============================================================================
//  1. Function Name : GetMEID
//	2. Description : Phone�� MEID�� �о�´�
//  3. Parameter : sMEID - MEID�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����	/ UMTS ������� ����
//============================================================================
BOOL CCdmaFtm::GetMEID(CString &sMEID)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.nv_read.cmd_code = DIAG_NV_READ_F;
	m_pSerial->m_Request.req.nv_read.item     = NV_MEID_I;
	
	if(!m_pSerial->AutoProcessing((int)sizeof(diag_nv_read_req_type), 1500)) 
		return FALSE;
	
	if(m_pSerial->m_Response.rsp.nv_read.cmd_code != DIAG_NV_READ_F) 
		return FALSE;

	sMEID.Format("%06x%08x", m_pSerial->m_Response.rsp.nv_read.item_data.meid_type.hi,
							 m_pSerial->m_Response.rsp.nv_read.item_data.meid_type.lo );

	return TRUE;
}

//============================================================================
//  1. Function Name : SetKeyPad
//	2. Description : Phone�� Ű�е带 ������
//  3. Parameter : sKeyStr - Ű�е� �� (EX. 1, 112...)
//                 bLongKey - TRUE�� Long Key�� ��
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::SetKeyPad(DWORD dwKeyStr, BOOL bLongKey)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.hs_key.cmd_code = DIAG_HS_KEY_F;
	m_pSerial->m_Request.req.hs_key.key    = (BYTE)dwKeyStr;
	m_pSerial->m_Request.req.hs_key.hold   = bLongKey;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_hs_lock_req_type), 1500)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.hs_key.cmd_code != DIAG_HS_KEY_F )
		return FALSE;

	return TRUE;
}

//============================================================================
//  1. Function Name : SetKeyPadLock
//	2. Description : Phone�� Ű�е� ����� �����Ѵ�
//  3. Parameter : bLock - TRUE�� Ű�е� ǰ, FALSE�� Ű�е� ���
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::SetKeyPadLock(BOOL bLock)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.hs_lock.cmd_code = DIAG_HS_LOCK_F;
	m_pSerial->m_Request.req.hs_lock.lock  = (diag_hs_lock_type) bLock;	

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_hs_lock_req_type), 1500)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.hs_lock.cmd_code != DIAG_HS_LOCK_F )
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::CheckRegister(BOOL& bIsCAMP)
{
	bIsCAMP = FALSE;
	
	if ( m_pSerial == NULL )
		return FALSE;

	CString szCmd;
	BOOL bReturn=TRUE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_VSIM;
	m_pSerial->m_Request.req.test_mode.test_mode_req.Camp = (byte)3;
	
	if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),2500)) // 1500 -> 2500
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
	   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_VSIM)
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == 0)
		bIsCAMP = TRUE;
	else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == 1)
		bIsCAMP = FALSE;
	else 
		return FALSE;

	return TRUE;
}

//============================================================================
//  1. Function Name : SetBand
//	2. Description : Phone�� BAND�� �����Ѵ�
//  3. Parameter : nBandIndex - Band Index��
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ���� ����
//============================================================================
BOOL CCdmaFtm::SetBand(int nBandIndex)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.ftm_req.cmd_code = DIAG_SUBSYS_CMD_F;
	m_pSerial->m_Request.req.ftm_req.subsys_id = DIAG_SUBSYS_FTM;
	m_pSerial->m_Request.req.ftm_req.subsys_cmd = FTM_1X_C;
	m_pSerial->m_Request.req.ftm_req.cmd_ptr.rf_params.rf_test_cmd = FTM_SET_MODE;

	switch(nBandIndex)
	{
	case INDEX_AMPS_BAND :	// AMPS
		m_pSerial->m_Request.req.ftm_req.cmd_ptr.rf_params.ftm_rf_factory_data.mode = PHONE_MODE_FM;
		break;
	case INDEX_CDMA_BAND : // USC (DCN)
		m_pSerial->m_Request.req.ftm_req.cmd_ptr.rf_params.ftm_rf_factory_data.mode = PHONE_MODE_CDMA;
		break;
	case INDEX_KPCS_BAND : // KPCS (Korea PCS)
		m_pSerial->m_Request.req.ftm_req.cmd_ptr.rf_params.ftm_rf_factory_data.mode = PHONE_MODE_CDMA_1800;
		break;
	case INDEX_USPCS_BAND : // USPCS
		m_pSerial->m_Request.req.ftm_req.cmd_ptr.rf_params.ftm_rf_factory_data.mode = PHONE_MODE_CDMA_800;
		break;
	default :
		return FALSE;
	}

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_ftm_req_pkt_type), 1500)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.ftm_rsp.cmd_code != DIAG_SUBSYS_CMD_F )
		return FALSE;

	return TRUE;
}

//============================================================================
//  1. Function Name : SetChannel
//	2. Description : Phone�� Call Channel�� �����Ѵ�
//  3. Parameter : dChannel - Call Channel��
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ���� ����
//============================================================================
BOOL CCdmaFtm::SetChannel(double dChannel)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));
	
	m_pSerial->m_Request.req.ftm_req.cmd_code = DIAG_SUBSYS_CMD_F;
	m_pSerial->m_Request.req.ftm_req.subsys_id = DIAG_SUBSYS_FTM;
    m_pSerial->m_Request.req.ftm_req.subsys_cmd = FTM_1X_C; //RF CAL
	m_pSerial->m_Request.req.ftm_req.cmd_ptr.rf_params.rf_test_cmd = FTM_SET_CHAN;
	m_pSerial->m_Request.req.ftm_req.cmd_ptr.rf_params.ftm_rf_factory_data.chan = (WORD)(int)dChannel;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_ftm_req_pkt_type), 1500)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.ftm_rsp.cmd_code != DIAG_SUBSYS_CMD_F )
		return FALSE;

	return TRUE;
}

//============================================================================
//  1. Function Name : SetMode
//	2. Description : Phone�� MODE�� ������ (������ mode�� �� �� �ִ�)
//                   MODE_OFFLINE_A_F	0	// Go to offline analog 
//                   MODE_OFFLINE_D_F	1	// Go to offline digital 
//                   MODE_RESET_F		2	// Reset. Only exit from offline 
//                   MODE_FTM_F			3	// FTM mode - if supported 
//                   MODE_ONLINE_F		4	// Online mode - if supported 
//                   MODE_LPM_F			5	// LPM mode - if supported 
//                   MODE_MAX_F			6	// Last (and invalid) mode enum value 
//  3. Parameter : byMode - Mode��
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::SetMode(BYTE byMode)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request, 0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.cont.cmd_code = DIAG_CONTROL_F;
	m_pSerial->m_Request.req.cont.mode 	= byMode;
		
	if(!m_pSerial->AutoProcessing((int)sizeof(diag_control_req_type), 5000)) 
		return FALSE; 

	if ( m_pSerial->m_Response.rsp.cont.cmd_code != DIAG_CONTROL_F )
		return FALSE;

	return TRUE;
}

//============================================================================
//  1. Function Name : SetDipSwitch
//	2. Description : Phone�� DIP ����ġ�� ������
//  3. Parameter : wValue - DIP ����ġ �� (EX. 0x00, 0x4100)
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::SetDipSwitch(WORD wValue)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.dipsw_req.cmd_code = DIAG_SET_DIPSW_F;
	m_pSerial->m_Request.req.dipsw_req.switches = wValue;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_dipsw_req_type), 1500)) 
		return FALSE;

	if ( m_pSerial->m_Response.rsp.dipsw_rsp.cmd_code != DIAG_SET_DIPSW_F )
		return FALSE;
	
	return TRUE;
}

//============================================================================
//  1. Function Name : SetBluetoothMode
//	2. Description : Phone�� Bluetooth TestMode�� ���Խ�Ŵ
//  3. Parameter : nModeIndex - CDMA������ ������
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::SetBluetoothMode(int nModeIndex, int nPreDelay, CString sCheckStatus)
{
	
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_BT_MODE;

	if(nModeIndex == INDEX_QUIT_BTTESTMODE)	//  [3/30/2010] lupis : For VS740
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = 5;
	else
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = 1;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_test_mode_rsp_type), 10000))	//+ BT Test mode Time out �ð��� ��� �ʿ���.%
		return FALSE;

	if ( m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F )
		return FALSE;

	if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code != 0 )
		return FALSE;

	return TRUE;
}

//============================================================================
//  1. Function Name : PhoneReset
//	2. Description : Phone�� ���½�Ų �� ���� ���¸� Ȯ����
//  3. Return Value : �����ϸ� TRUE
//	4. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::PhoneReset()
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.cont.cmd_code = DIAG_CONTROL_F;
	m_pSerial->m_Request.req.cont.mode = MODE_OFFLINE_D_F;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_control_req_type), 1500)) 
		return FALSE;

	if ( m_pSerial->m_Response.rsp.cont.cmd_code != DIAG_CONTROL_F )
		return FALSE;
	
	Sleep(3000);

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.cont.cmd_code = DIAG_CONTROL_F;
    m_pSerial->m_Request.req.cont.mode = MODE_RESET_F;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_control_req_type), 1500)) 
		return FALSE;

	if ( m_pSerial->m_Response.rsp.cont.cmd_code != DIAG_CONTROL_F )
		return FALSE;

	return TRUE;
}

//============================================================================
//  1. Function Name : GetPhoneState
//	2. Description : Phone�� State���� �о��
//  3. Parameter : nSystemType - AMPS / CDMA2000 / EVDO
//				   nState - State���� �о�� ����
//				   sStateDesc - �����ڵ��� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ���� ����
//============================================================================
BOOL CCdmaFtm::GetPhoneState(int nSystemType, int *nState, CString &sStateDesc)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	sStateDesc = _T("");
	
	switch(nSystemType)
	{
	case INDEX_EVDO_SYSTEM :
		m_pSerial->m_Request.req.cm_state.cmd_code = DIAG_SUBSYS_CMD_F;
		m_pSerial->m_Request.req.cm_state.subsys_id = DIAG_SUBSYS_HDR;
		m_pSerial->m_Request.req.cm_state.subsys_cmd = HDR_STATE;

		if(!m_pSerial->AutoProcessing((int)sizeof(diag_cm_state_type), 1500)) 
			return FALSE;

		if ( m_pSerial->m_Response.rsp.cm_state.cmd_code != DIAG_SUBSYS_CMD_F )
			return FALSE;
		
		if(m_pSerial->m_Response.rsp.hdr_state.session_state == 0)
			*nState = 6;
		else
			*nState = m_pSerial->m_Response.rsp.hdr_state.at_state;
		
		if ( *nState >=0 && *nState <=6 )
			sStateDesc.Format("%-26s", evdo_call_state[*nState]);

		break;

/*
	case IS2000_RELA :
		m_pSerial->m_Request.req.cm_state.cmd_code = DIAG_SUBSYS_CMD_F;
		m_pSerial->m_Request.req.cm_state.subsys_id = DIAG_SUBSYS_CM;
		m_pSerial->m_Request.req.cm_state.subsys_cmd = CM_STATE_INFO;

		if(!m_pSerial->AutoProcessing((int)sizeof(diag_cm_state_type), 1500)) 
			return FALSE;

		*nState = m_pSerial->m_Response.rsp.cm_state.call_state;

		if ( *nState >=0 && *nState <=6 )
			sStateDesc.Format("%-26s", rel_a_call_state[*nState]);

		break;
*/

	default :
		m_pSerial->m_Request.req.state_req.cmd_code = DIAG_STATE_F;

		if(!m_pSerial->AutoProcessing((int)sizeof(diag_state_req_type), 1500)) 
			return FALSE;

		if ( m_pSerial->m_Response.rsp.state_rsp.cmd_code != DIAG_STATE_F )
			return FALSE;

		*nState = m_pSerial->m_Response.rsp.state_rsp.phone_state;

		if ( *nState >=0 && *nState <=8 )
			sStateDesc.Format("%-26s", phone_acp[*nState]);
		if ( *nState >=128 && *nState <=141 )
			sStateDesc.Format("%-26s", phone_mcc[*nState-128]);
	}

	return TRUE;
}

//============================================================================
//  1. Function Name : GetPhoneStatus
//	2. Description : Phone�� Status�� �о��
//  3. Parameter : PhoneStatus - Status ����ü�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����
//============================================================================
BOOL CCdmaFtm::GetPhoneStatus(LPPHONESTATUS pPhoneStatus)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.stat.cmd_code = DIAG_STATUS_F;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_status_req_type), 1500)) 
		return FALSE;

	if ( m_pSerial->m_Response.rsp.stat.cmd_code != DIAG_STATUS_F )
		return FALSE;

	CopyMemory(pPhoneStatus, &(m_pSerial->m_Response.rsp.stat), (int)sizeof(PHONESTATUS));

	return TRUE;
}

BOOL CCdmaFtm::ChangeDiagPath(WORD uMSM)
{
	if(uMSM <= 6275)
		uMSM = 6275;
	else
		uMSM = 6500;

	if ( m_pSerial == NULL )
		return FALSE;

	// ���� ���� Ȯ�� �ٲ� �ʿ� ������ �ٷ� TRUE ����
	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.cmd_code = DIAG_LGF_GET_DIAG_PATH_F;

	if( !m_pSerial->AutoProcessing((int)sizeof(byte), 1500) )
		return FALSE;


	if( m_pSerial->m_Response.rsp.cmd_code != DIAG_LGF_GET_DIAG_PATH_F )
		return FALSE;


//	g_bDiagPktToMSM6275 = (m_pSerial->m_Response.rsp.byte_and_word.gen_word == 6275) ? TRUE : FALSE;
	if( m_pSerial->m_Response.rsp.byte_and_word.gen_word == uMSM )
	{
		//Message ó��
		return TRUE;
	}
	
	// ���ڰ���� ��ȯ
	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.byte_and_word.cmd_code = DIAG_LGF_CHANGE_DIAG_PATH_F;
	m_pSerial->m_Request.req.byte_and_word.gen_word = uMSM;

	if( !m_pSerial->AutoProcessing((int)sizeof(gen_byte_and_word_type), 1500) )
		return FALSE;
	if( m_pSerial->m_Response.rsp.cmd_code != DIAG_LGF_CHANGE_DIAG_PATH_F )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.cmd_code = DIAG_LGF_GET_DIAG_PATH_F;

	if( !m_pSerial->AutoProcessing((int)sizeof(byte), 1500) )
		return FALSE;

	if( m_pSerial->m_Response.rsp.byte_and_word.cmd_code != DIAG_LGF_GET_DIAG_PATH_F )
		return FALSE;

//	g_bDiagPktToMSM6275 = (m_pSerial->m_Response.rsp.byte_and_word.gen_word == 6275) ? TRUE : FALSE;
	if(m_pSerial->m_Response.rsp.byte_and_word.gen_word != uMSM)
		return FALSE;
		
	return TRUE;
}

BOOL CCdmaFtm::SetFTMNV(BOOL bSet)
{
	nv_item_type	nvData;
	WORD			uCurrentMSM = 6500;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.cmd_code = DIAG_LGF_GET_DIAG_PATH_F;

	if( !m_pSerial->AutoProcessing((int)sizeof(byte), 1500) )
		return FALSE;

	if( m_pSerial->m_Response.rsp.byte_and_word.cmd_code != DIAG_LGF_GET_DIAG_PATH_F )
		return FALSE;

	uCurrentMSM = m_pSerial->m_Response.rsp.byte_and_word.gen_word;
		
	ZeroMemory(&nvData, sizeof(nv_item_type));
	nvData.ftm_mode = bSet;

	if(!ChangeDiagPath(TO_MSM6275))
		return FALSE;
	if(!NVWrite(NV_FTM_MODE_I, &nvData))
		return FALSE;
	if(!ChangeDiagPath(TO_MSM6500))
		return FALSE;
	if(!NVWrite(NV_FTM_MODE_I, &nvData))
		return FALSE;

	if(!ChangeDiagPath(((uCurrentMSM == 6275) ? TO_MSM6275 : TO_MSM6500)))
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::NVWrite(nv_items_enum_type Item,nv_item_type *Data)
{
	BOOL	bReturn=TRUE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	// load data to packet
	memcpy(&m_pSerial->m_Request.req.nv_write.item_data, Data, sizeof(nv_item_type));

	m_pSerial->m_Request.req.nv_write.cmd_code = DIAG_NV_WRITE_F;
	m_pSerial->m_Request.req.nv_write.item		= Item;	

	if( !m_pSerial->AutoProcessing((int)sizeof(diag_nv_write_req_type), 1500) )
		return FALSE;
	
	if( m_pSerial->m_Response.rsp.nv_write.cmd_code != DIAG_NV_WRITE_F ) 
		return FALSE;

	if( m_pSerial->m_Response.rsp.nv_write.nv_stat != NV_DONE_S ) 
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetTestMode(CString sItemName, CString &sResult)
{
	CString szCmd;
	BOOL bReturn=TRUE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;


	sItemName.MakeUpper();

	if ( sItemName == "IRDA" )
	{
		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_IRDA;
		m_pSerial->m_Request.req.test_mode.test_mode_req.IrDA = (byte)1;
		
		if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),1500)) 
		{
			sResult = "Fail";
			return FALSE;
		}

		if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
		   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_IRDA)
		{ 
			sResult = "Fail";
			return FALSE;
		}

		if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
		{
			sResult = "OK";
			return TRUE;
		}
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
		{
			sResult = "Not_Support";
			return FALSE;
		}
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
		{
			sResult = "Fail";
			return FALSE;
		}
	}
	else if ( sItemName == "SDMB" || sItemName == "TUTEST" )
	{
		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_SDMB;
		m_pSerial->m_Request.req.test_mode.test_mode_req.sdmb = (byte)0;
		
		if(!m_pSerial->AutoProcessing(sizeof(diag_test_mode_rsp_type), 3000))
		{
			sResult = "Fail";
			return FALSE;
		}

	}
	else if ( sItemName == "TDMB" || sItemName == "DMB")	//  [10/31/2006] vivache : DBM Test Mode ����. (SDMB, TDMB, MFLO, DBV-H)
	{
		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_TDMB;
		m_pSerial->m_Request.req.test_mode.test_mode_req.tdmb= (byte)0;

		if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),1500))
		{
			sResult = "Fail";
			return FALSE;
		}

		if( (m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F )  ||
			(m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_TDMB) )
		{
			sResult = "Fail";
			return FALSE;
		}

		if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
		{
			sResult = "OK!";
			return TRUE;
		}
		else if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
		{
			sResult = "Fail!";
			return FALSE;
		}
		else if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
		{
			sResult = "Not_Supported!";	
			return FALSE;
		}
		else
		{
			sResult = "����� �� ����";
			return FALSE;
		}

	}
	else if ( sItemName == "PHOTO" )	//  [10/31/2006] Lupis3 : Photo sensor �˻��
	{
		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_PHOTO;
		m_pSerial->m_Request.req.test_mode.test_mode_req.photo= (byte)1;

		if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),1500))
		{
			sResult = "Fail";
			return FALSE;
		}

		if( (m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F )  ||
			(m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_PHOTO) )
		{
			sResult = "Fail";
			return FALSE;
		}

		if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
		{
			sResult = "OK!";
			return TRUE;
		}
		else if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
		{
			sResult = "Fail!";
			return FALSE;
		}
		else if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
		{
			sResult = "Not_Supported!";	
			return FALSE;
		}
		else
		{
			sResult = "����� �� ����";
			return FALSE;
		}

	}
	else if ( sItemName == "MANUAL" )	//  [10/31/2006] Lupis3 : MANUAL Mode�� ���⼭�� VX9900 Qwerty key �˻縦 ���� ������.
	{
		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_MANUAL;
		m_pSerial->m_Request.req.test_mode.test_mode_req.manual= (byte)0;

		if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),1500))
		{
			sResult = "Fail";
			return FALSE;
		}

		if( (m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F )  ||
			(m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_MANUAL) )
		{
			sResult = "Fail";
			return FALSE;
		}

		if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
		{
			sResult = "OK!";
			return TRUE;
		}
		else if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
		{
			sResult = "Fail!";
			return FALSE;
		}
		else if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
		{
			sResult = "Not_Supported!";	
			return FALSE;
		}
		else
		{
			sResult = "����� �� ����";
			return FALSE;
		}

	}
	else if ( sItemName == "MIC2" )	//  [7/3/2007] vivache : Mic2 ON for Camcorder Test
	{
		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_IRDA;
		m_pSerial->m_Request.req.test_mode.test_mode_req.Mic2On = (byte)6;
		
		if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),1500)) 
		{
			sResult = "Fail";
			return FALSE;
		}

		if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
		   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_IRDA)
		{ 
			sResult = "Fail";
			return FALSE;
		}

		if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
		{
			sResult = "OK";
			return TRUE;
		}
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
		{
			sResult = "Not_Support";
			return FALSE;
		}
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
		{
			sResult = "Fail";
			return FALSE;
		}

	}
	else if ( sItemName == "USBFACTORY" )	//  [7/3/2007] vivache : USB FACTORY MODE
	{
		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_MRD;
		m_pSerial->m_Request.req.test_mode.test_mode_req.UsbFactory = (byte)3;
		
		if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),1500)) 
		{
			sResult = "Fail";
			return FALSE;
		}

		if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
		   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_MRD)
		{ 
			sResult = "Fail";
			return FALSE;
		}

		if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
		{
			sResult = "OK";
			return TRUE;
		}
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
		{
			sResult = "Not_Support";
			return FALSE;
		}
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
		{
			sResult = "Fail";
			return FALSE;
		}

	}

	return TRUE;
}

BOOL CCdmaFtm::SetVSIM()
{
	CString szCmd;
	BOOL bReturn=TRUE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_VSIM;
	m_pSerial->m_Request.req.test_mode.test_mode_req.VSIM = (byte)1;
	
	if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),2500)) // 1500 -> 2500
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
	   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_VSIM)
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code != 0)
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetEmergencyCall(BOOL bOnOff)
{
	return TRUE;
}

BOOL CCdmaFtm::SetMRDMode(int nModeIndex, int nDelay)					//  [7/3/2007] vivache : MRD Mode ��ȯ
{
	CString szCmd(_T(""));
	CString sResult(_T("Fail"));
	BOOL bReturn=TRUE;

	if(nModeIndex != MRD_NORMAL_MODE && nModeIndex != MRD_SUB_RX_PATH)
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;

	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_MRD;
	m_pSerial->m_Request.req.test_mode.test_mode_req.MRD = (byte)nModeIndex;	// 0 : Normal, 1 : Sub Mode
		
	if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),5000))		//  [5/12/2009] vivache : MRD mode ��ȯ Time out �ð� ���� 1500 -> 5000
	{
		sResult = "Fail";
		return FALSE;
	}

	if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
	   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_MRD)
	{ 
		sResult = "Fail";
		return FALSE;
	}

	if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
	{
		sResult = "OK";
	}
	else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
	{
		sResult = "Not_Support";
		return FALSE;
	}
	else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
	{
		sResult = "Fail";
		return FALSE;
	}

	if(nDelay <= 0)
		nDelay = 50;	//  Sleep(0)����context switching�Ǵ� ���� ����

	Sleep(nDelay);
	
	return TRUE;
}

BOOL CCdmaFtm::SetWLANMode(BOOL bState, int nPreDelay, int *pnErrCode, int nWlanType /* = INDEX_WLAN_802_11G*/ )								//  [7/3/2007] vivache : WLAN Testmode ��ȯ/����
{
	//////////////////////////////////////////////////////////////////////////
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_TDMB;	// TEST_MODE_TDMB (33) - WiFi(WLAN)�� - 4,5,6,7,8,9,10,11,12,13
	if(bState) //TRUE : ON
	{
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = CUtil::GetValueFromWlanType_Testmode(nWlanType);;
	}
	else	// FALSE : OFF
	{
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = SUB_WLAN_MODE_OFF;
	}

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_test_mode_rsp_type), 10000))	//+ BT Test mode Time out �ð��� ��� �ʿ���.%
	{
		*pnErrCode = GDERR_PHONE_TIMEOUT;
		return FALSE;
	}

	Sleep(500);	// [6/17/2009] vivache : tunning 1000 -> 500

	if ( m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F )
	{
		*pnErrCode = GDERR_PHONE_NG;
		return FALSE;
	}

	if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code != TEST_OK_S )
	{
		*pnErrCode = GDERR_PHONE_NG;
		return FALSE;
	}

	return TRUE;
}

BOOL CCdmaFtm::SetWLANRxMode(double& fPer, int nChannel, int nDelay )	//  [7/3/2007] vivache : WLAN Rx Mode
{
	//////////////////////////////////////////////////////////////////////////
	int nLowChanLimit(4), nMidChannel(7), nHighChanLimit(10);

	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_TDMB;	// TEST_MODE_TDMB (33) - WiFi(WLAN)�� - 4,5,6,7,8,9,10,11,12,13

	if( nChannel > 0 && nChannel <= nLowChanLimit )			// Low channel 1 ~ 4 Channel�� Low channel
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = SUB_WLAN_START_LOW_RX;
	else if( nChannel >= nHighChanLimit && nChannel <= 13 )	// High channel : 10 ~ 13
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = SUB_WLAN_START_HIGH_RX;
	else									//mid channel : 5 ~ 9
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = SUB_WLAN_START_MID_RX;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_test_mode_rsp_type), 10000))	//+ BT Test mode Time out �ð��� ��� �ʿ���.%
		return FALSE;

	Sleep(500);

	if ( m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F )
		return FALSE;

	if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code != TEST_OK_S )
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetWLANTxMode(int nChannel, int nLevel)					//  [7/3/2007] vivache : WLAN Tx Mode
{
	//////////////////////////////////////////////////////////////////////////
	int nLowChanLimit(4), nMidChannel(7), nHighChanLimit(10);

	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_TDMB;	// TEST_MODE_TDMB (33) - WiFi(WLAN)�� - 4,5,6,7,8,9,10,11,12,13

	if( nChannel > 0 && nChannel <= nLowChanLimit )			// Low channel 1 ~ 4 Channel�� Low channel
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = SUB_WLAN_START_LOW_TX;
	else if( nChannel >= nHighChanLimit && nChannel <= 13 )	// High channel : 10 ~ 13
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = SUB_WLAN_START_HIGH_TX;
	else if (nChannel > 35)
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = SUB_WLAN_START_802_11A_LOW_TX; // set 802.11a test channel but only low Tx(36ch)
	else									//mid channel : 5 ~ 9
		m_pSerial->m_Request.req.test_mode.test_mode_req.btmode = SUB_WLAN_START_MID_TX;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_test_mode_rsp_type), 10000))	//+ BT Test mode Time out �ð��� ��� �ʿ���.%
		return FALSE;

	Sleep(500);

	if ( m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F )
		return FALSE;

	if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code != TEST_OK_S )
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::IsCalibration()
{
	CString szCmd(_T(""));
	int RFCAL_PASS(99);

	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.nv_read.cmd_code = DIAG_NV_READ_F;
	m_pSerial->m_Request.req.nv_read.item     = NV_RF_CAL_VER_I;
	
	if(!m_pSerial->AutoProcessing((int)sizeof(diag_nv_read_req_type), 2000)) 
		return FALSE;
	
	if(m_pSerial->m_Response.rsp.nv_read.cmd_code != DIAG_NV_READ_F) 
		return FALSE;

	if(m_pSerial->m_Response.rsp.nv_read.item_data.rf_cal_ver[NV_SIZE_OF_VERSION-1] != RFCAL_PASS)
		return FALSE;	
	
	return TRUE;
}

BOOL CCdmaFtm::GetRSSI(double& fRssi)	//  [10/23/2007] vivache : CDMA Rssi value �о����
{
	if ( m_pSerial == NULL )
		return FALSE;

	signed char scTemp(0);

	fRssi = -115;

	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.stat.cmd_code = DIAG_TAGRAPH_F;

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_tagraph_rsp_type), 1500)) 
		return FALSE;

	if ( m_pSerial->m_Response.rsp.stat.cmd_code != DIAG_TAGRAPH_F )
		return FALSE;

	scTemp  = m_pSerial->m_Response.rsp.tagraph.rx_rssi;

	//////////////////////////////////////////////////////////////////////////
	// Formula to convert to dBm:
	//	(value / 3) - 63.248, where value is signed twos
	//	complement 
	//
	// Note:
	//	.. If value = -128, the dbm_value can be less than or equal to the calculated value.
	//	.. If value = 127, the dbm_value can be greater than or equal to -21 dBm.
	//////////////////////////////////////////////////////////////////////////
	//if(scTemp & 0x80)
	//	scTemp = (BYTE)(-1)*((scTemp^(0xff)) + 1);
	
	fRssi = (scTemp/3) - 63.248;

	return TRUE;
}

BOOL CCdmaFtm::ChangeUartPath(int nDirection)	//  [10/24/2008] vivache : Dual CPU Model�� ��� Master/Slave �� UART Path switching�� ���ؼ� �����.
{
	if ( m_pSerial == NULL )
		return FALSE;

	return FALSE;
}

BOOL CCdmaFtm::BandChange(int bandItem)
{
	if ( m_pSerial == NULL )
		return FALSE;

	return FALSE;
}

BOOL CCdmaFtm::ChangeSystem(int nDirection)
{
	if ( m_pSerial == NULL )
		return FALSE;

	byte nSub2 = 0;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;

	switch(nDirection)
	{
	case CHANGE_CDMA_TO_UMTS_SYSTEM :
	case CHANGE_UMTS_TO_CDMA_SYSTEM :
		nSub2 = (byte)nDirection;
		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_SYSTEM_CHANGE;
		m_pSerial->m_Request.req.test_mode.test_mode_req.SystemChange = nSub2;
		
		if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),3000)) 
			return FALSE;

		if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
		   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_SYSTEM_CHANGE)
			return FALSE;

		if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
			return TRUE;
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
			return FALSE;
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
			return FALSE;
		break;

	case CHANGE_LTE_ON_RF_ON :
	case CHANGE_LTE_ON_RF_OFF :
	case CHANGE_LTE_OFF_RF_ON :
		if ( nDirection == CHANGE_LTE_ON_RF_ON )
			nSub2 = (byte)0;
		else if ( nDirection == CHANGE_LTE_ON_RF_OFF )
			nSub2 = (byte)1;
		else if ( nDirection == CHANGE_LTE_OFF_RF_ON )
			nSub2 = (byte)2;

		m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_SYSTEM_LTE_RF_CHANGE;
		m_pSerial->m_Request.req.test_mode.test_mode_req.SystemChange = nSub2;
		
		if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),3000)) 
			return FALSE;

		if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
		   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_SYSTEM_LTE_RF_CHANGE)
			return FALSE;

		if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_OK_S)
			return TRUE;
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_NOT_SUPPORTED_S)
			return FALSE;
		else if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code == TEST_FAIL_S)
			return FALSE;
		break;		
	}

	return FALSE;
}

BOOL CCdmaFtm::SetCampRequest(int nBand)	//  [5/26/2009] vivache : GSM �� ���� ��� command.
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString szCmd;
	BOOL bReturn=TRUE;
	byte TESTMODE_CAMPREQ_AUTOMATIC(20);
	

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	byte nBandIndex = CUtil::GetCampRequestBandSubCommand(nBand);
	

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_VSIM;
	m_pSerial->m_Request.req.test_mode.test_mode_req.CampReq = nBandIndex; // CUtil::GetCampRequestBandSubCommand(nBand);
	
	if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),2500)) // 1500 -> 2500
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
	   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_VSIM)
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code != 0)
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetSleepMode()	//  [9/16/2009] vivache : Sleep mode
{
		if ( m_pSerial == NULL )
		return FALSE;

	CString szCmd;
	BOOL bReturn=TRUE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_SLEEP;
	m_pSerial->m_Request.req.test_mode.test_mode_req.Sleep = (byte)0;
	
	if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode),2500)) // 1500 -> 2500
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
	   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_SLEEP)
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code != 0)
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetDetach() //  [9/18/2009] vivache : detatch
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString szCmd;
	BOOL bReturn=TRUE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_VSIM;
	m_pSerial->m_Request.req.test_mode.test_mode_req.CampReq = (byte)21;	//Detach
	
	if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode), 2500)) // 1500 -> 2500
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
	   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_VSIM)
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code != 0)
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetOriginCall(WORD wMode /* = DIAG_VOICE_CALL */)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.orig.cmd_code = DIAG_ORIG_F;  //#define DIAG_ORIG_F 53 
	m_pSerial->m_Request.req.orig.so = wMode;		// 1 : VOICE (IS96), 2 : Loppback
	m_pSerial->m_Request.req.orig.cnt = 10;
	strcpy(m_pSerial->m_Request.req.orig.dialed_digits, "0101234567");

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_orig_req_type), 1500)) 
		return FALSE; 

	if ( m_pSerial->m_Request.req.orig.cmd_code != DIAG_ORIG_F )
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetEndCall()
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,  0, sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response, 0, sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.orig.cmd_code = DIAG_END_F;  //#define DIAG_ORIG_F 53 

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_end_req_type), 5000)) 
		return FALSE; 

	if ( m_pSerial->m_Request.req.orig.cmd_code  != DIAG_END_F )
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetMimoAntCheck(int nMode)
{
	if ( m_pSerial == NULL )
		return FALSE;

	if ( nMode >= 3 )	// QXDM Command For MDM Chip
	{
		BYTE nWrite[8] = {75, 68, 00, 64, nMode, 0x29, 0x3C, 0x7E};
		if ( nMode == 5 )
		{
			nWrite[5] = 0x29; nWrite[6] = 0x3C;
		}
		else if ( nMode == 6 )
		{
			nWrite[5] = 0xB2; nWrite[6] = 0x0E;
		}
		else if ( nMode == 3 )
		{
			nWrite[5] = 0x1F; nWrite[6] = 0x59;
		}
		m_pSerial->WriteCommPort(nWrite, 8);
		Sleep(1000);
//		m_pSerial->ReadCommPort(cReadBuf, &dwReadCnt, 3000);

		//
		BYTE RxTmp[MAX_PACKET_SIZE] = {0,};
		int nRxLength = 0;
		BOOL bResult = FALSE;
		DWORD Goal = (clock_t)3000 + clock();
 		
		while(1) 
		{
			bResult=m_pSerial->ReadCommPort((LPSTR)&RxTmp[nRxLength],(DWORD*)&nRxLength);

			if(bResult==FALSE)
				continue;
			
			if( nRxLength >0 && RxTmp[nRxLength-1] == ASYNC_HDLC_FLAG) 
				break; 

			if(Goal <= clock()) 
				return FALSE;
		}

		BOOL bSame = FALSE;
		for ( int i = 0; i < 5 ; i++ )
		{
			if ( nWrite[i] != RxTmp[i] )
				break;
			if ( i == 4 )
				bSame = TRUE;
		}
		//

		return bSame;
	}

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_MIMO_ANT_CHECK;
	m_pSerial->m_Request.req.test_mode.test_mode_req.antenna = (byte)nMode;
	
	if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode), 2500))
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
	   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_MIMO_ANT_CHECK)
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code != 0)
		return FALSE;

	return TRUE;
}

BOOL CCdmaFtm::SetLteAttach(BOOL bOn)
{
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_LTE_CALL;
	
	if ( bOn )
		m_pSerial->m_Request.req.test_mode.test_mode_req.calltype = (byte)0;
	else
		m_pSerial->m_Request.req.test_mode.test_mode_req.calltype = (byte)1;
	
	if(!m_pSerial->AutoProcessing(sizeof(m_pSerial->m_Request.req.test_mode), 2500))
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F	|| 
	   m_pSerial->m_Response.rsp.test_mode.sub_cmd_code != TEST_MODE_LTE_CALL)
		return FALSE;

	if(m_pSerial->m_Response.rsp.test_mode.ret_stat_code != 0)
		return FALSE;

	return TRUE;
}

// [7/19/2010] JKPARK : û�ְ��� ����
BOOL CCdmaFtm::SetPidFlag(int nIndex, char cValue)
{
	return TRUE;
}

BOOL CCdmaFtm::SetL2000Prepare(BOOL bIsVSIM)
{
	return TRUE;
}

// [10/15/2010] JKPARK : P500/509 Registration �ҷ� ���� ���� �߰���.
BOOL CCdmaFtm::SetFlightMode(BOOL bOnOff) 
{
	return TRUE;
}

BOOL CCdmaFtm::SetQEMmode(BOOL bMode)								//  [4/14/2011] JKPARK 
{

	return TRUE;
}

// [7/23/2011] JKPARK : AT����ϴ� CDMA���� LB Call Function
BOOL CCdmaFtm::SetLoopBackCall(BOOL bOnOff)
{
	return TRUE;
}

// [11/10/2011] JKPARK : LCD ON�� DCN ���� �޴� ��� ����.
BOOL CCdmaFtm::SetLcdOnOff(BOOL bOnOff)
{
	//////////////////////////////////////////////////////////////////////////
	if ( m_pSerial == NULL )
		return FALSE;

	memset(&m_pSerial->m_Request,0,sizeof(diag_req_pkt_type));
	memset(&m_pSerial->m_Response,0,sizeof(diag_rsp_pkt_type));

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;
	m_pSerial->m_Request.req.test_mode.sub_cmd_code = TEST_MODE_LCD;	// TEST_MODE_LCD(1)
	if(bOnOff) //TRUE : ON
	{
		m_pSerial->m_Request.req.test_mode.test_mode_req.lcd = 4;
	}
	else	// FALSE : OFF
	{
		m_pSerial->m_Request.req.test_mode.test_mode_req.lcd = 5;
	}

	if(!m_pSerial->AutoProcessing((int)sizeof(diag_test_mode_rsp_type), 2500))	//+ BT Test mode Time out �ð��� ��� �ʿ���.%
	{
		return FALSE;
	}

	Sleep(500);	

	if ( m_pSerial->m_Response.rsp.test_mode.cmd_code != DIAG_TEST_MODE_F )
	{
		return FALSE;
	}

	if( m_pSerial->m_Response.rsp.test_mode.ret_stat_code != TEST_OK_S )
	{
		return FALSE;
	}

	return TRUE;
}