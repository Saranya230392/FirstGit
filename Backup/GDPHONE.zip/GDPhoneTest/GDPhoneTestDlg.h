// GDPhoneTestDlg.h : header file
//

#if !defined(AFX_GDPHONETESTDLG_H__F7DCD89E_7469_4CCC_BFA0_65933BB40CEF__INCLUDED_)
#define AFX_GDPHONETESTDLG_H__F7DCD89E_7469_4CCC_BFA0_65933BB40CEF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CGDPhoneTestDlg dialog

#include "GDPhoneInterface.h"
#include "Event.h"

class CGDPhoneTestDlg : public CDialog
{
// Construction
public:
	CGDPhoneTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CGDPhoneTestDlg)
	enum { IDD = IDD_GDPHONETEST_DIALOG };
	CListBox	m_listSpy;
	CListBox	m_listResult;
	int		m_nCommMode;
	int		m_nBaudRate;
	int		m_nComPort;
	CString	m_sDriverName;
	CString	m_sParameter;
	CString m_sParameter2;
	int		m_nRadio;
	BOOL	m_bIsCdma;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGDPhoneTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	GDPhoneInterface *m_pGDPhone;

	CEvent m_Event;

	// Generated message map functions
	//{{AFX_MSG(CGDPhoneTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonInitPhone();
	afx_msg void OnButtonExitPhone();
	afx_msg void OnButtonOpen();
	afx_msg void OnButtonClose();
	afx_msg void OnButtonRun();
	afx_msg void OnClear();
	afx_msg void OnButtonSearch();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GDPHONETESTDLG_H__F7DCD89E_7469_4CCC_BFA0_65933BB40CEF__INCLUDED_)
