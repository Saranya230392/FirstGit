// IPCEvent.h: interface for the CIPCEvent class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IPCEVENT_H__D0F73FC2_C005_4161_B69B_A4D5A96B9D61__INCLUDED_)
#define AFX_IPCEVENT_H__D0F73FC2_C005_4161_B69B_A4D5A96B9D61__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CIPCHandler;

class CIPCEvent 
{
protected :
	CIPCHandler *m_pParent;

public:
	void OnGetModel(CString sSender);
	void SetParent(CIPCHandler *pParent);
	// For Common Event
	virtual void OnIPCDisconnect(BOOL bIsServer, CString sClientName = _T(""));
	virtual void OnIPCConnect(BOOL bIsServer);

	// For Manufacturing SW Side Event
	virtual void OnProgramCheck();
	virtual void OnSetSystem();
	virtual void OnSetLoss(int nJigNo);
	virtual void OnEndTest_Res(int nJigNo);
	virtual void OnProgress_Res(int nJigNo);
	virtual void OnStartTest(int nJigNo, CString sBarcode);
	virtual void OnSetModel(CString sModel, CString sBuyer, CString sWorkOrder, CString sColor, CString sCommType, int nBaudrate);
	virtual void OnIdentity_Res(BOOL bResult);
	virtual void OnInstrumentInfo(CString sSender, CString sName1, CString sAddr1, CString sName2, CString sAddr2, CString sName3, CString sAddr3, CString sName4, CString sAdder4, CString sName5, CString sAddr5, CString sName6, CString sAddr6, CString sName7, CString sAddr7);
	// For Celmelt Side Event
	virtual void OnProgramCheck_Res(CString sSender);
	virtual void OnSetSystem_Res(CString sSender, int nJigNo);
	virtual void OnSetLoss_Res(CString sSender, int nJigNo, BOOL bResult);
	virtual void OnEndTest(CString sSender, int nJigNo, BOOL bResult, CString sMsg);
	virtual void OnProgress(CString sSender, int nJigNo, int nPercent, CString sMsg);
	virtual void OnStartTest_Res(CString sSender, int nJigNo, BOOL bResult, CString sMsg);
	virtual void OnSetModel_Res(CString sSender, BOOL bResult, CString sMsg);
	virtual void OnIdentity(CString sProgramName, CString sSWVersion);

	CIPCEvent();
	virtual ~CIPCEvent();
};

#endif // !defined(AFX_IPCEVENT_H__D0F73FC2_C005_4161_B69B_A4D5A96B9D61__INCLUDED_)
