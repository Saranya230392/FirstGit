// IPCSocket.cpp : implementation file
//

#include "stdafx.h"

#include "IPCSocket.h"
#include "SocketThread.h"
#include "SocketManager.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CIPCSocket

CIPCSocket::CIPCSocket()
{
	m_pSockThread = NULL;
	m_pParent = NULL;
}

CIPCSocket::~CIPCSocket()
{
}


// Do not edit the following lines, which are needed by ClassWizard.
#if 0
BEGIN_MESSAGE_MAP(CIPCSocket, CSocket)
	//{{AFX_MSG_MAP(CIPCSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// CIPCSocket member functions

void CIPCSocket::OnReceive(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class

	m_pParent->OnMessage(this);
	
	CSocket::OnReceive(nErrorCode);
}

void CIPCSocket::OnClose(int nErrorCode) 
{
	// TODO: Add your specialized code here and/or call the base class

	m_pParent->OnDisconnect(this);

	CSocket::OnClose(nErrorCode);
}
