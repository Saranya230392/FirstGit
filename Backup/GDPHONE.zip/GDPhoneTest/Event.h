// Event.h: interface for the CEvent class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EVENT_H__1494DC9A_8EF7_41BD_8EB1_AA5426404B7C__INCLUDED_)
#define AFX_EVENT_H__1494DC9A_8EF7_41BD_8EB1_AA5426404B7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GDPhoneComDef.h"

class CEvent : public CInstrumentEvent
{
public:
	void SendLogMessage(CString sMsg);
	void SendSpyMessage(CString sMsg, BOOL bShow);
	CEvent();
	virtual ~CEvent();

};

#endif // !defined(AFX_EVENT_H__1494DC9A_8EF7_41BD_8EB1_AA5426404B7C__INCLUDED_)
