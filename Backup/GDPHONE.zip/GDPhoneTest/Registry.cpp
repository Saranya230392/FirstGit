// Registry.cpp: implementation of the CRegistry class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Registry.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRegistry::CRegistry()
{
	SetKeyInfo();
	OpenRegistry();
}

CRegistry::~CRegistry()
{
	if ( m_mapRegistry.GetCount() > 0 )
		m_mapRegistry.RemoveAll();

	if ( m_mapValueToKey.GetCount() > 0 )
		m_mapValueToKey.RemoveAll();
}

void CRegistry::SetKeyInfo()
{
	if ( m_mapValueToKey.GetCount() > 0 )
		m_mapValueToKey.RemoveAll();

	m_mapValueToKey.SetAt("path", _T("SOFTWARE\\LG Inspection SW"));
	m_mapValueToKey.SetAt("BinPath", _T("SOFTWARE\\LG Inspection SW\\GD"));
	m_mapValueToKey.SetAt("EnvPath", _T("SOFTWARE\\LG Inspection SW\\GD"));
	m_mapValueToKey.SetAt("LogPath", _T("SOFTWARE\\LG Inspection SW\\GD"));
	m_mapValueToKey.SetAt("ModelPath",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation"));
	m_mapValueToKey.SetAt("LogPath",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation"));
	//Low
	m_mapValueToKey.SetAt("CDMA Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("CDMA Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("KPCS Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("KPCS Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("USPCS Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("USPCS Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("GSM850 Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("GSM850 Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("GSM900 Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("GSM900 Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("DCS1800 Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("DCS1800 Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("PCS1900 Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("PCS1900 Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_I Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_I Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_II Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_II Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_III Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_III Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_IV Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_IV Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_V Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_V Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_VI Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WCDMA_VI Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("BLUETOOTH Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("TDSCDMA_I Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));	//  [9/17/2007] TD-SCDMA
	m_mapValueToKey.SetAt("TDSCDMA_I Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("TDSCDMA_II Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("TDSCDMA_II Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("TDSCDMA_III Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("TDSCDMA_III Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));
	m_mapValueToKey.SetAt("WLAN Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"));	//  [9/17/2007] WLAN
	//Med
	m_mapValueToKey.SetAt("CDMA Rx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("CDMA Tx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("KPCS Rx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("KPCS Tx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("USPCS Rx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("USPCS Tx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("GSM850 Rx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("GSM850 Tx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("GSM900 Rx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("GSM900 Tx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("DCS1800 Rx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("DCS1800 Tx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("PCS1900 Rx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("PCS1900 Tx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_I Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_I Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_II Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_II Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_III Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_III Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_IV Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_IV Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_V Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_V Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_VI Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WCDMA_VI Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("BLUETOOTH Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("TDSCDMA_I Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));	//  [9/17/2007] TD-SCDMA
	m_mapValueToKey.SetAt("TDSCDMA_I Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("TDSCDMA_II Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("TDSCDMA_II Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("TDSCDMA_III Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("TDSCDMA_III Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));
	m_mapValueToKey.SetAt("WLAN Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"));	//  [9/17/2007] WLAN
	//High
	m_mapValueToKey.SetAt("CDMA Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("CDMA Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("KPCS Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("KPCS Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("USPCS Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("USPCS Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("GSM850 Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("GSM850 Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("GSM900 Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("GSM900 Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("DCS1800 Rx High",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("DCS1800 Tx High",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("PCS1900 Rx High",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("PCS1900 Tx High",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_I Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_I Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_II Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_II Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_III Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_III Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_IV Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_IV Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_V Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_V Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_VI Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WCDMA_VI Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("BLUETOOTH High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("TDSCDMA_I Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));	//  [9/17/2007] TD-SCDMA
	m_mapValueToKey.SetAt("TDSCDMA_I Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("TDSCDMA_II Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("TDSCDMA_II Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("TDSCDMA_III Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("TDSCDMA_III Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));
	m_mapValueToKey.SetAt("WLAN High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"));	//  [9/17/2007] WLAN
	/////////////////////////////////////////////////////////////////////////	
	m_mapValueToKey.SetAt("COM Port",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("USB Port",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("ReportCreate",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("UseCustomReportPath",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("ReportPath",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("ShowSpyMsg",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("Voltage",				_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("Voltage Limit",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("Current Limit",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("Temcell Test",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("Continue Failure",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("PID Checking",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("MEID Using",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("IMEI Checking",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));	//  [4/26/2007] vivache : IMEI Check
	m_mapValueToKey.SetAt("Cal Checking",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));	//  [8/15/2007] vivache : Cal Checking
	m_mapValueToKey.SetAt("Voltage Preset",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));	//  [11/1/2007] vivache : Voltage preset (Qualcomm PMIC Dead)
	m_mapValueToKey.SetAt("Preset Voltage Value",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));	//  [11/1/2007] vivache : Voltage preset (Qualcomm PMIC Dead)
	m_mapValueToKey.SetAt("Report Duration",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("Log Duration",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"));
	m_mapValueToKey.SetAt("Tbl Delete",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option")); //  [6/12/2007] vivache
	m_mapValueToKey.SetAt("Tbl Duration",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option")); //  [6/12/2007] lupis3
	m_mapValueToKey.SetAt("ModelName",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Recent Model"));
	m_mapValueToKey.SetAt("Buyer",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Recent Model"));
	m_mapValueToKey.SetAt("ModelFile",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Recent Model"));
	m_mapValueToKey.SetAt("Use EzLooks",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\EZLOOKS"));
	m_mapValueToKey.SetAt("Use LIMO",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"));
	m_mapValueToKey.SetAt("PLCMode",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"));
	m_mapValueToKey.SetAt("Limo Port",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"));
	m_mapValueToKey.SetAt("PC No",			_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"));
	m_mapValueToKey.SetAt("Limo Baudrate",	_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"));
	m_mapValueToKey.SetAt("Show Spy",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"));
	m_mapValueToKey.SetAt("Time Out",		_T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"));
	
	//////////////////////////////////////////////////////////////////////////
	// about Loss Measurement
	// 1. common
	m_mapValueToKey.SetAt("SampleType",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure"));
	m_mapValueToKey.SetAt("SampleNumber",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure"));
	m_mapValueToKey.SetAt("AllChannelSame",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure"));
	// 2. Golden Sample Data
	m_mapValueToKey.SetAt("CDMA Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("CDMA Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("CDMA Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("CDMA Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("CDMA Rx Sensitivity CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("CDMA Rx Sensitivity CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("CDMA Rx Sensitivity CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("CDMA Rx Sensitivity Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("USPCS Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("USPCS Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("USPCS Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("USPCS Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("USPCS Rx Sensitivity CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("USPCS Rx Sensitivity CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("USPCS Rx Sensitivity CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("USPCS Rx Sensitivity Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("KPCS Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("KPCS Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("KPCS Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("KPCS Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("KPCS Rx Sensitivity CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("KPCS Rx Sensitivity CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("KPCS Rx Sensitivity CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("KPCS Rx Sensitivity Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
		//GSM
	m_mapValueToKey.SetAt("GSM850 Tx Output Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM850 Tx Output Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM850 Tx Output Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM850 Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM850 Rx Reported Level CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM850 Rx Reported Level CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM850 Rx Reported Level CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM850 Rx Reported Level Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("GSM900 Tx Output Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM900 Tx Output Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM900 Tx Output Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM900 Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM900 Rx Reported Level CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM900 Rx Reported Level CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM900 Rx Reported Level CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("GSM900 Rx Reported Level Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("DCS1800 Tx Output Power CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("DCS1800 Tx Output Power CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("DCS1800 Tx Output Power CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("DCS1800 Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("DCS1800 Rx Reported Level CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("DCS1800 Rx Reported Level CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("DCS1800 Rx Reported Level CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("DCS1800 Rx Reported Level Tolerance",_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
		//WCDMA
	m_mapValueToKey.SetAt("PCS1900 Tx Output Power CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("PCS1900 Tx Output Power CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("PCS1900 Tx Output Power CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("PCS1900 Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("PCS1900 Rx Reported Level CH1",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("PCS1900 Rx Reported Level CH2",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("PCS1900 Rx Reported Level CH3",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("PCS1900 Rx Reported Level Tolerance",_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("WCDMA_I Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_I Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_I Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_I Max RF Power Tolerance",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_I BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_I BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_I BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_I BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("WCDMA_II Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_II Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_II Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_II Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_II BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_II BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_II BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_II BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("WCDMA_III Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_III Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_III Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_III Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_III BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_III BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_III BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_III BER Tolerance",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("WCDMA_IV Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("WCDMA_V Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_V Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_V Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_V Max RF Power Tolerance",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_V BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_V BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_V BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_V BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("WCDMA_VI Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
		//TDSCDMA
	m_mapValueToKey.SetAt("TDSCDMA_I Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));	//  [10/16/2007] vivache : TDSCDMA
	m_mapValueToKey.SetAt("TDSCDMA_I Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I Max RF Power Tolerance",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("TDSCDMA_II Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));

	m_mapValueToKey.SetAt("TDSCDMA_III Max RF Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III Max RF Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III Max RF Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III BER CH1",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III BER CH2",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III BER CH3",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III BER Tolerance",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
		//Bluetooth
	m_mapValueToKey.SetAt("Bluetooth BT Output Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("Bluetooth BT Output Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("Bluetooth BT Output Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("Bluetooth BT Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
		//WLAN
	m_mapValueToKey.SetAt("WLAN Tx Output Power CH1",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));	//  [10/16/2007] vivache : WLAN
	m_mapValueToKey.SetAt("WLAN Tx Output Power CH2",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WLAN Tx Output Power CH3",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	m_mapValueToKey.SetAt("WLAN Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"));
	// 3. General Sample Data
	m_mapValueToKey.SetAt("CDMA Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("CDMA Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("CDMA Rx Sensitivity Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("CDMA Rx Sensitivity Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("USPCS Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("USPCS Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("USPCS Rx Sensitivity Target",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("USPCS Rx Sensitivity Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("KPCS Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("KPCS Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("KPCS Rx Sensitivity Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("KPCS Rx Sensitivity Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
		//GSM
	m_mapValueToKey.SetAt("GSM850 Tx Output Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("GSM850 Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("GSM850 Rx Reported Level Target",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("GSM850 Rx Reported Level Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("GSM900 Tx Output Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("GSM900 Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("GSM900 Rx Reported Level Target",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("GSM900 Rx Reported Level Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("DCS1800 Tx Output Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("DCS1800 Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("DCS1800 Rx Reported Level Target",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("DCS1800 Rx Reported Level Tolerance",_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("PCS1900 Tx Output Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("PCS1900 Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("PCS1900 Rx Reported Level Target",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("PCS1900 Rx Reported Level Tolerance",_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
		//WCDMA
	m_mapValueToKey.SetAt("WCDMA_I Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_I Max RF Power Tolerance",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_I BER Target",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_I BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("WCDMA_II Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_II Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_II BER Target",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_II BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("WCDMA_III Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_III Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_III BER Target",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_III BER Tolerance",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("WCDMA_IV Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV BER Target",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_IV BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("WCDMA_V Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_V Max RF Power Tolerance",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_V BER Target",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_V BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("WCDMA_VI Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI BER Target",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WCDMA_VI BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
		//TDSCDMA
	m_mapValueToKey.SetAt("TDSCDMA_I Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I Max RF Power Tolerance",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I BER Target",					_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_I BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("TDSCDMA_II Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II BER Target",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_II BER Tolerance",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));

	m_mapValueToKey.SetAt("TDSCDMA_III Max RF Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III Max RF Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III BER Target",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("TDSCDMA_III BER Tolerance",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
		//bluetooth
	m_mapValueToKey.SetAt("BLUETOOTH BT Output Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("BLUETOOTH BT Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
		//WLAN
	m_mapValueToKey.SetAt("WLAN Tx Output Power Target",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	m_mapValueToKey.SetAt("WLAN Tx Output Power Tolerance",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"));
	//4. Measured Loss Table
	//Low
	m_mapValueToKey.SetAt("Measured CDMA Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured CDMA Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured KPCS Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured KPCS Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured USPCS Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured USPCS Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured GSM850 Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured GSM850 Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured GSM900 Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured GSM900 Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured DCS1800 Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured DCS1800 Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured PCS1900 Rx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured PCS1900 Tx Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_I Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_I Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_II Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_II Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_III Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_III Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_IV Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_IV Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_V Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_V Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_VI Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WCDMA_VI Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured BLUETOOTH Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_I Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));	//  [9/18/2007] TD-SCDMA
	m_mapValueToKey.SetAt("Measured TDSCDMA_I Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_II Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_II Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_III Rx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_III Tx Low",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));
	m_mapValueToKey.SetAt("Measured WLAN Low",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"));	//  [9/18/2007] WLAN
	//Med
	m_mapValueToKey.SetAt("Measured CDMA Rx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured CDMA Tx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured KPCS Rx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured KPCS Tx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured USPCS Rx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured USPCS Tx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured GSM850 Rx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured GSM850 Tx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured GSM900 Rx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured GSM900 Tx Med",				_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured DCS1800 Rx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured DCS1800 Tx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured PCS1900 Rx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured PCS1900 Tx Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_I Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_I Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_II Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_II Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_III Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_III Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_IV Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_IV Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_V Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_V Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_VI Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WCDMA_VI Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured BLUETOOTH Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_I Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));	//  [9/18/2007] TD-SCDMA
	m_mapValueToKey.SetAt("Measured TDSCDMA_I Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_II Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_II Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_III Rx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_III Tx Med",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));
	m_mapValueToKey.SetAt("Measured WLAN Med",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"));	//  [9/18/2007] WLAN
	//High
	m_mapValueToKey.SetAt("Measured CDMA Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured CDMA Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured KPCS Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured KPCS Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured USPCS Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured USPCS Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured GSM850 Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured GSM850 Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured GSM900 Rx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured GSM900 Tx High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured DCS1800 Rx High",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured DCS1800 Tx High",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured PCS1900 Rx High",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured PCS1900 Tx High",		_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_I Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_I Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_II Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_II Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_III Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_III Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_IV Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_IV Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_V Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_V Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_VI Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WCDMA_VI Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured BLUETOOTH High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_I Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));	//  [9/18/2007] TD-SCDMA
	m_mapValueToKey.SetAt("Measured TDSCDMA_I Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_II Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_II Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_III Rx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured TDSCDMA_III Tx High",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));
	m_mapValueToKey.SetAt("Measured WLAN High",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"));	//  [9/18/2007] WLAN
	
	//////////////////////////////////////////////////////////////////////////
	//  [12/8/2006] vivache : Advanced Set
	// Common
	m_mapValueToKey.SetAt("Loss Table",			_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));
	m_mapValueToKey.SetAt("Measure Timeout",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));
	m_mapValueToKey.SetAt("Measure Loss Limit",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));

	// General sample measure
	m_mapValueToKey.SetAt("Range Tx Power Lower",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));
	m_mapValueToKey.SetAt("Range Tx Power Upper",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));

	m_mapValueToKey.SetAt("Range Rx FER Lower",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));
	m_mapValueToKey.SetAt("Range Rx FER Upper",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));

	m_mapValueToKey.SetAt("Range Rx Level Lower",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));
	m_mapValueToKey.SetAt("Range Rx Level Upper",	_T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"));

}

void CRegistry::OpenRegistry()
{
	if ( m_mapRegistry.GetCount() > 0 )
		m_mapRegistry.RemoveAll();

	HKEY hKey;

	// GD Value ==================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL);

	m_mapRegistry.SetAt("path", GetRegValue(hKey, "path", _T("C:\\GDMV")));

	RegCloseKey(hKey);

	// Path Value =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL);

	m_mapRegistry.SetAt("BinPath", GetRegValue(hKey, "BinPath", _T("\\BIN")));
	m_mapRegistry.SetAt("EnvPath", GetRegValue(hKey, "EnvPath", _T("\\Env")));
	m_mapRegistry.SetAt("LogPath", GetRegValue(hKey, "LogPath", _T("\\Log")));

	RegCloseKey(hKey);

	// Radiation Value =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL);

	m_mapRegistry.SetAt("ModelPath", GetRegValue(hKey, "ModelPath", _T("\\Model\\Radiation")));
	m_mapRegistry.SetAt("LogPath", GetRegValue(hKey, "LogPath", _T("\\Log\\Radiation")));

	RegCloseKey(hKey);

	// Loss Value (LOW) =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Low"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("CDMA Rx Low", GetRegValue(hKey, "CDMA Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("CDMA Tx Low", GetRegValue(hKey, "CDMA Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("KPCS Rx Low", GetRegValue(hKey, "KPCS Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("KPCS Tx Low", GetRegValue(hKey, "KPCS Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("USPCS Rx Low", GetRegValue(hKey, "USPCS Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("USPCS Tx Low", GetRegValue(hKey, "USPCS Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("GSM850 Rx Low", GetRegValue(hKey, "GSM850 Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("GSM850 Tx Low", GetRegValue(hKey, "GSM850 Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("GSM900 Rx Low", GetRegValue(hKey, "GSM900 Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("GSM900 Tx Low", GetRegValue(hKey, "GSM900 Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("DCS1800 Rx Low", GetRegValue(hKey, "DCS1800 Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("DCS1800 Tx Low", GetRegValue(hKey, "DCS1800 Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("PCS1900 Rx Low", GetRegValue(hKey, "PCS1900 Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("PCS1900 Tx Low", GetRegValue(hKey, "PCS1900 Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_I Rx Low", GetRegValue(hKey, "WCDMA_I Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_I Tx Low", GetRegValue(hKey, "WCDMA_I Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_II Rx Low", GetRegValue(hKey, "WCDMA_II Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_II Tx Low", GetRegValue(hKey, "WCDMA_II Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_III Rx Low", GetRegValue(hKey, "WCDMA_III Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_III Tx Low", GetRegValue(hKey, "WCDMA_III Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_IV Rx Low", GetRegValue(hKey, "WCDMA_IV Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_IV Tx Low", GetRegValue(hKey, "WCDMA_IV Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_V Rx Low", GetRegValue(hKey, "WCDMA_V Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_V Tx Low", GetRegValue(hKey, "WCDMA_V Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_VI Rx Low", GetRegValue(hKey, "WCDMA_VI Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_VI Tx Low", GetRegValue(hKey, "WCDMA_VI Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("BLUETOOTH Low", GetRegValue(hKey, "BLUETOOTH Low", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_I Rx Low", GetRegValue(hKey, "TDSCDMA_I Rx Low", _T("1.4")));	//  [9/17/2007] TDSCDMA
	m_mapRegistry.SetAt("TDSCDMA_I Tx Low", GetRegValue(hKey, "TDSCDMA_I Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_II Rx Low", GetRegValue(hKey, "TDSCDMA_II Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_II Tx Low", GetRegValue(hKey, "TDSCDMA_II Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_III Rx Low", GetRegValue(hKey, "TDSCDMA_III Rx Low", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_III Tx Low", GetRegValue(hKey, "TDSCDMA_III Tx Low", _T("1.4")));
	m_mapRegistry.SetAt("WLAN Low", GetRegValue(hKey, "WLAN Low", _T("1.4")));	//  [9/17/2007] WLAN
	

	RegCloseKey(hKey);

	// Loss Value (MED) =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\Med"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("CDMA Rx Med", GetRegValue(hKey, "CDMA Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("CDMA Tx Med", GetRegValue(hKey, "CDMA Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("KPCS Rx Med", GetRegValue(hKey, "KPCS Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("KPCS Tx Med", GetRegValue(hKey, "KPCS Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("USPCS Rx Med", GetRegValue(hKey, "USPCS Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("USPCS Tx Med", GetRegValue(hKey, "USPCS Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("GSM850 Rx Med", GetRegValue(hKey, "GSM850 Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("GSM850 Tx Med", GetRegValue(hKey, "GSM850 Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("GSM900 Rx Med", GetRegValue(hKey, "GSM900 Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("GSM900 Tx Med", GetRegValue(hKey, "GSM900 Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("DCS1800 Rx Med", GetRegValue(hKey, "DCS1800 Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("DCS1800 Tx Med", GetRegValue(hKey, "DCS1800 Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("PCS1900 Rx Med", GetRegValue(hKey, "PCS1900 Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("PCS1900 Tx Med", GetRegValue(hKey, "PCS1900 Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_I Rx Med", GetRegValue(hKey, "WCDMA_I Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_I Tx Med", GetRegValue(hKey, "WCDMA_I Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_II Rx Med", GetRegValue(hKey, "WCDMA_II Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_II Tx Med", GetRegValue(hKey, "WCDMA_II Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_III Rx Med", GetRegValue(hKey, "WCDMA_III Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_III Tx Med", GetRegValue(hKey, "WCDMA_III Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_IV Rx Med", GetRegValue(hKey, "WCDMA_IV Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_IV Tx Med", GetRegValue(hKey, "WCDMA_IV Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_V Rx Med", GetRegValue(hKey, "WCDMA_V Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_V Tx Med", GetRegValue(hKey, "WCDMA_V Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_VI Rx Med", GetRegValue(hKey, "WCDMA_VI Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_VI Tx Med", GetRegValue(hKey, "WCDMA_VI Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("BLUETOOTH Med", GetRegValue(hKey, "BLUETOOTH Med", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_I Rx Med", GetRegValue(hKey, "TDSCDMA_I Rx Med", _T("1.4")));	//  [9/17/2007] TDSCDMA
	m_mapRegistry.SetAt("TDSCDMA_I Tx Med", GetRegValue(hKey, "TDSCDMA_I Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_II Rx Med", GetRegValue(hKey, "TDSCDMA_II Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_II Tx Med", GetRegValue(hKey, "TDSCDMA_II Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_III Rx Med", GetRegValue(hKey, "TDSCDMA_III Rx Med", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_III Tx Med", GetRegValue(hKey, "TDSCDMA_III Tx Med", _T("1.4")));
	m_mapRegistry.SetAt("WLAN Med", GetRegValue(hKey, "WLAN Med", _T("1.4")));	//  [9/17/2007] WLAN

	RegCloseKey(hKey);

	// Loss Value (HIGH) =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Loss\\High"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("CDMA Rx High", GetRegValue(hKey, "CDMA Rx High", _T("1.4")));
	m_mapRegistry.SetAt("CDMA Tx High", GetRegValue(hKey, "CDMA Tx High", _T("1.4")));
	m_mapRegistry.SetAt("KPCS Rx High", GetRegValue(hKey, "KPCS Rx High", _T("1.4")));
	m_mapRegistry.SetAt("KPCS Tx High", GetRegValue(hKey, "KPCS Tx High", _T("1.4")));
	m_mapRegistry.SetAt("USPCS Rx High", GetRegValue(hKey, "USPCS Rx High", _T("1.4")));
	m_mapRegistry.SetAt("USPCS Tx High", GetRegValue(hKey, "USPCS Tx High", _T("1.4")));
	m_mapRegistry.SetAt("GSM850 Rx High", GetRegValue(hKey, "GSM850 Rx High", _T("1.4")));
	m_mapRegistry.SetAt("GSM850 Tx High", GetRegValue(hKey, "GSM850 Tx High", _T("1.4")));
	m_mapRegistry.SetAt("GSM900 Rx High", GetRegValue(hKey, "GSM900 Rx High", _T("1.4")));
	m_mapRegistry.SetAt("GSM900 Tx High", GetRegValue(hKey, "GSM900 Tx High", _T("1.4")));
	m_mapRegistry.SetAt("DCS1800 Rx High", GetRegValue(hKey, "DCS1800 Rx High", _T("1.4")));
	m_mapRegistry.SetAt("DCS1800 Tx High", GetRegValue(hKey, "DCS1800 Tx High", _T("1.4")));
	m_mapRegistry.SetAt("PCS1900 Rx High", GetRegValue(hKey, "PCS1900 Rx High", _T("1.4")));
	m_mapRegistry.SetAt("PCS1900 Tx High", GetRegValue(hKey, "PCS1900 Tx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_I Rx High", GetRegValue(hKey, "WCDMA_I Rx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_I Tx High", GetRegValue(hKey, "WCDMA_I Tx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_II Rx High", GetRegValue(hKey, "WCDMA_II Rx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_II Tx High", GetRegValue(hKey, "WCDMA_II Tx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_III Rx High", GetRegValue(hKey, "WCDMA_III Rx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_III Tx High", GetRegValue(hKey, "WCDMA_III Tx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_IV Rx High", GetRegValue(hKey, "WCDMA_IV Rx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_IV Tx High", GetRegValue(hKey, "WCDMA_IV Tx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_V Rx High", GetRegValue(hKey, "WCDMA_V Rx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_V Tx High", GetRegValue(hKey, "WCDMA_V Tx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_VI Rx High", GetRegValue(hKey, "WCDMA_VI Rx High", _T("1.4")));
	m_mapRegistry.SetAt("WCDMA_VI Tx High", GetRegValue(hKey, "WCDMA_VI Tx High", _T("1.4")));
	m_mapRegistry.SetAt("BLUETOOTH High", GetRegValue(hKey, "BLUETOOTH High", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_I Rx High", GetRegValue(hKey, "TDSCDMA_I Rx High", _T("1.4")));	//  [9/17/2007] TDSCDMA
	m_mapRegistry.SetAt("TDSCDMA_I Tx High", GetRegValue(hKey, "TDSCDMA_I Tx High", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_II Rx High", GetRegValue(hKey, "TDSCDMA_II Rx High", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_II Tx High", GetRegValue(hKey, "TDSCDMA_II Tx High", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_III Rx High", GetRegValue(hKey, "TDSCDMA_III Rx High", _T("1.4")));
	m_mapRegistry.SetAt("TDSCDMA_III Tx High", GetRegValue(hKey, "TDSCDMA_III Tx High", _T("1.4")));
	m_mapRegistry.SetAt("WLAN High", GetRegValue(hKey, "WLAN High", _T("1.4")));	//  [9/17/2007] WLAN

	RegCloseKey(hKey);

	// Option Value =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Option"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("COM Port", GetRegValue(hKey, "COM Port", _T("2")));
	m_mapRegistry.SetAt("USB Port", GetRegValue(hKey, "USB Port", _T("6")));
	m_mapRegistry.SetAt("ReportCreate", GetRegValue(hKey, "ReportCreate", _T("1")));
	m_mapRegistry.SetAt("UseCustomReportPath", GetRegValue(hKey, "UseCustomReportPath", _T("0")));
	m_mapRegistry.SetAt("ReportPath", GetRegValue(hKey, "ReportPath", _T("\\Report\\Radiation")));
	m_mapRegistry.SetAt("ShowSpyMsg", GetRegValue(hKey, "ShowSpyMsg", _T("NO")));
	m_mapRegistry.SetAt("Voltage", GetRegValue(hKey, "Voltage", _T("4.2")));
	m_mapRegistry.SetAt("Voltage Limit", GetRegValue(hKey, "Voltage Limit", _T("5.5")));	//  [9/23/2007] vivache : Max Voltage ����. Registry ���� ����.
	m_mapRegistry.SetAt("Current Limit", GetRegValue(hKey, "Current Limit", _T("3.0")));
	m_mapRegistry.SetAt("Temcell Test", GetRegValue(hKey, "Temcell Test", _T("NO")));
	m_mapRegistry.SetAt("Continue Failure", GetRegValue(hKey, "Continue Failure", _T("NO")));
	m_mapRegistry.SetAt("PID Checking", GetRegValue(hKey, "PID Checking", _T("NO")));
	m_mapRegistry.SetAt("MEID Using", GetRegValue(hKey, "MEID Using", _T("NO")));
	m_mapRegistry.SetAt("IMEI Checking", GetRegValue(hKey, "IMEI Checking", _T("NO")));	//  [4/26/2007] vivache : IMEI Check
	m_mapRegistry.SetAt("Cal Checking", GetRegValue(hKey, "Cal Checking", _T("YES")));	//  [8/15/2007] vivache : Cal Check
	m_mapRegistry.SetAt("Voltage Preset", GetRegValue(hKey, "Voltage Preset", _T("NO")));	//  [11/1/2007] vivache : Voltage preset (Qualcomm PMIC Dead)
	m_mapRegistry.SetAt("Preset Voltage Value", GetRegValue(hKey, "Preset Voltage Value", _T("3.4")));	//  [11/1/2007] vivache : Voltage preset (Qualcomm PMIC Dead)
	m_mapRegistry.SetAt("Report Duration", GetRegValue(hKey, "Report Duration", _T("4")));
	m_mapRegistry.SetAt("Log Duration", GetRegValue(hKey, "Log Duration", _T("4")));
	m_mapRegistry.SetAt("Tbl Duration", GetRegValue(hKey, "Tbl Duration", _T("5")));	//  [6/12/2007] lupis3
	m_mapRegistry.SetAt("Tbl Delete", GetRegValue(hKey, "Tbl Delete", _T("YES")));	//  [6/12/2007] lupis3

	RegCloseKey(hKey);

	// Recent Model =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Recent Model"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\Recent Model"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("ModelName", GetRegValue(hKey, "ModelName", _T("")));
	m_mapRegistry.SetAt("Buyer", GetRegValue(hKey, "Buyer", _T("")));
	m_mapRegistry.SetAt("ModelFile", GetRegValue(hKey, "ModelFile", _T("")));

	RegCloseKey(hKey);

	// EZLOOKS =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\EZLOOKS"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\EZLOOKS"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("Use EzLooks", GetRegValue(hKey, "Use EzLooks", _T("YES")));

	RegCloseKey(hKey);

	// LIMO =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Radiation\\LIMO"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("Use LIMO", GetRegValue(hKey, "Use LIMO", _T("NO")));
	m_mapRegistry.SetAt("PLCMode", GetRegValue(hKey, "PLCMode", _T("NO")));
	m_mapRegistry.SetAt("Limo Port", GetRegValue(hKey, "Limo Port", _T("1")));
	m_mapRegistry.SetAt("PC No", GetRegValue(hKey, "PC No", _T("1")));
	m_mapRegistry.SetAt("Limo Baudrate", GetRegValue(hKey, "Limo Baudrate", _T("115200")));
	m_mapRegistry.SetAt("Show Spy", GetRegValue(hKey, "Show Spy", _T("NO")));
	m_mapRegistry.SetAt("Time Out", GetRegValue(hKey, "Time Out", _T("2000")));

	RegCloseKey(hKey);

	//////////////////////////////////////////////////////////////////////////
	// about Loss Measurement
	// 1. common
	// Loss Measure
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("SampleType",		GetRegValue(hKey, "SampleType", _T("0")));
	m_mapRegistry.SetAt("SampleNumber",		GetRegValue(hKey, "SampleNumber", _T("10")));
	m_mapRegistry.SetAt("AllChannelSame",	GetRegValue(hKey, "AllChannelSame", _T("0")));

	RegCloseKey(hKey);

	// 2. Golden Sample Data
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Golden Sample"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("CDMA Max RF Power CH1",		GetRegValue(hKey, "CDMA Max RF Power CH1", _T("24.0")));
	m_mapRegistry.SetAt("CDMA Max RF Power CH2",		GetRegValue(hKey, "CDMA Max RF Power CH2", _T("24.0")));
	m_mapRegistry.SetAt("CDMA Max RF Power CH3",		GetRegValue(hKey, "CDMA Max RF Power CH3", _T("24.0")));
	m_mapRegistry.SetAt("CDMA Max RF Power Tolerance",	GetRegValue(hKey, "CDMA Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("CDMA Rx Sensitivity CH1",		GetRegValue(hKey, "CDMA Rx Sensitivity CH1", _T("-106.0")));
	m_mapRegistry.SetAt("CDMA Rx Sensitivity CH2",		GetRegValue(hKey, "CDMA Rx Sensitivity CH2", _T("-106.0")));
	m_mapRegistry.SetAt("CDMA Rx Sensitivity CH3",		GetRegValue(hKey, "CDMA Rx Sensitivity CH3", _T("-106.0")));
	m_mapRegistry.SetAt("CDMA Rx Sensitivity Tolerance",GetRegValue(hKey, "CDMA Rx Sensitivity Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("USPCS Max RF Power CH1",		GetRegValue(hKey, "USPCS Max RF Power CH1", _T("24.0")));
	m_mapRegistry.SetAt("USPCS Max RF Power CH2",		GetRegValue(hKey, "USPCS Max RF Power CH2", _T("24.0")));
	m_mapRegistry.SetAt("USPCS Max RF Power CH3",		GetRegValue(hKey, "USPCS Max RF Power CH3", _T("24.0")));
	m_mapRegistry.SetAt("USPCS Max RF Power Tolerance",	GetRegValue(hKey, "USPCS Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("USPCS Rx Sensitivity CH1",		GetRegValue(hKey, "USPCS Rx Sensitivity CH1", _T("-106.0")));
	m_mapRegistry.SetAt("USPCS Rx Sensitivity CH2",		GetRegValue(hKey, "USPCS Rx Sensitivity CH2", _T("-106.0")));
	m_mapRegistry.SetAt("USPCS Rx Sensitivity CH3",		GetRegValue(hKey, "USPCS Rx Sensitivity CH3", _T("-106.0")));
	m_mapRegistry.SetAt("USPCS Rx Sensitivity Tolerance",GetRegValue(hKey, "USPCS Rx Sensitivity Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("KPCS Max RF Power CH1",		GetRegValue(hKey, "KPCS Max RF Power CH1", _T("24.0")));
	m_mapRegistry.SetAt("KPCS Max RF Power CH2",		GetRegValue(hKey, "KPCS Max RF Power CH2", _T("24.0")));
	m_mapRegistry.SetAt("KPCS Max RF Power CH3",		GetRegValue(hKey, "KPCS Max RF Power CH3", _T("24.0")));
	m_mapRegistry.SetAt("KPCS Max RF Power Tolerance",	GetRegValue(hKey, "KPCS Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("KPCS Rx Sensitivity CH1",		GetRegValue(hKey, "KPCS Rx Sensitivity CH1", _T("-106.0")));
	m_mapRegistry.SetAt("KPCS Rx Sensitivity CH2",		GetRegValue(hKey, "KPCS Rx Sensitivity CH2", _T("-106.0")));
	m_mapRegistry.SetAt("KPCS Rx Sensitivity CH3",		GetRegValue(hKey, "KPCS Rx Sensitivity CH3", _T("-106.0")));
	m_mapRegistry.SetAt("KPCS Rx Sensitivity Tolerance",GetRegValue(hKey, "KPCS Rx Sensitivity Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("GSM850 Tx Output Power CH1",			GetRegValue(hKey, "GSM850 Tx Output Power CH1", _T("33.0")));
	m_mapRegistry.SetAt("GSM850 Tx Output Power CH2",			GetRegValue(hKey, "GSM850 Tx Output Power CH2", _T("33.0")));
	m_mapRegistry.SetAt("GSM850 Tx Output Power CH3",			GetRegValue(hKey, "GSM850 Tx Output Power CH3", _T("33.0")));
	m_mapRegistry.SetAt("GSM850 Tx Output Power Tolerance",		GetRegValue(hKey, "GSM850 Tx Output Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("GSM850 Rx Reported Level CH1",			GetRegValue(hKey, "GSM850 Rx Reported Level CH1", _T("-90.0")));
	m_mapRegistry.SetAt("GSM850 Rx Reported Level CH2",			GetRegValue(hKey, "GSM850 Rx Reported Level CH2", _T("-90.0")));
	m_mapRegistry.SetAt("GSM850 Rx Reported Level CH3",			GetRegValue(hKey, "GSM850 Rx Reported Level CH3", _T("-90.0")));
	m_mapRegistry.SetAt("GSM850 Rx Reported Level Tolerance",	GetRegValue(hKey, "GSM850 Rx Reported Level Tolerance", _T("0.1")));

	m_mapRegistry.SetAt("GSM900 Tx Output Power CH1",			GetRegValue(hKey, "GSM900 Tx Output Power CH1", _T("33.0")));
	m_mapRegistry.SetAt("GSM900 Tx Output Power CH2",			GetRegValue(hKey, "GSM900 Tx Output Power CH2", _T("33.0")));
	m_mapRegistry.SetAt("GSM900 Tx Output Power CH3",			GetRegValue(hKey, "GSM900 Tx Output Power CH3", _T("33.0")));
	m_mapRegistry.SetAt("GSM900 Tx Output Power Tolerance",		GetRegValue(hKey, "GSM900 Tx Output Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("GSM900 Rx Reported Level CH1",			GetRegValue(hKey, "GSM900 Rx Reported Level CH1", _T("-90.0")));
	m_mapRegistry.SetAt("GSM900 Rx Reported Level CH2",			GetRegValue(hKey, "GSM900 Rx Reported Level CH2", _T("-90.0")));
	m_mapRegistry.SetAt("GSM900 Rx Reported Level CH3",			GetRegValue(hKey, "GSM900 Rx Reported Level CH3", _T("-90.0")));
	m_mapRegistry.SetAt("GSM900 Rx Reported Level Tolerance",	GetRegValue(hKey, "GSM900 Rx Reported Level Tolerance", _T("0.1")));

	m_mapRegistry.SetAt("DCS1800 Tx Output Power CH1",			GetRegValue(hKey, "DCS1800 Tx Output Power CH1", _T("30.0")));
	m_mapRegistry.SetAt("DCS1800 Tx Output Power CH2",			GetRegValue(hKey, "DCS1800 Tx Output Power CH2", _T("30.0")));
	m_mapRegistry.SetAt("DCS1800 Tx Output Power CH3",			GetRegValue(hKey, "DCS1800 Tx Output Power CH3", _T("30.0")));
	m_mapRegistry.SetAt("DCS1800 Tx Output Power Tolerance",	GetRegValue(hKey, "DCS1800 Tx Output Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("DCS1800 Rx Reported Level CH1",		GetRegValue(hKey, "DCS1800 Rx Reported Level CH1", _T("-90.0")));
	m_mapRegistry.SetAt("DCS1800 Rx Reported Level CH2",		GetRegValue(hKey, "DCS1800 Rx Reported Level CH2", _T("-90.0")));
	m_mapRegistry.SetAt("DCS1800 Rx Reported Level CH3",		GetRegValue(hKey, "DCS1800 Rx Reported Level CH3", _T("-90.0")));
	m_mapRegistry.SetAt("DCS1800 Rx Reported Level Tolerance",	GetRegValue(hKey, "DCS1800 Rx Reported Level Tolerance", _T("0.1")));

	m_mapRegistry.SetAt("PCS1900 Tx Output Power CH1",			GetRegValue(hKey, "PCS1900 Tx Output Power CH1", _T("30.0")));
	m_mapRegistry.SetAt("PCS1900 Tx Output Power CH2",			GetRegValue(hKey, "PCS1900 Tx Output Power CH2", _T("30.0")));
	m_mapRegistry.SetAt("PCS1900 Tx Output Power CH3",			GetRegValue(hKey, "PCS1900 Tx Output Power CH3", _T("30.0")));
	m_mapRegistry.SetAt("PCS1900 Tx Output Power Tolerance",	GetRegValue(hKey, "PCS1900 Tx Output Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("PCS1900 Rx Reported Level CH1",		GetRegValue(hKey, "PCS1900 Rx Reported Level CH1", _T("-90.0")));
	m_mapRegistry.SetAt("PCS1900 Rx Reported Level CH2",		GetRegValue(hKey, "PCS1900 Rx Reported Level CH2", _T("-90.0")));
	m_mapRegistry.SetAt("PCS1900 Rx Reported Level CH3",		GetRegValue(hKey, "PCS1900 Rx Reported Level CH3", _T("-90.0")));
	m_mapRegistry.SetAt("PCS1900 Rx Reported Level Tolerance",	GetRegValue(hKey, "PCS1900 Rx Reported Level Tolerance", _T("0.1")));

	m_mapRegistry.SetAt("WCDMA_I Max RF Power CH1",			GetRegValue(hKey, "WCDMA_I Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_I Max RF Power CH2",			GetRegValue(hKey, "WCDMA_I Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_I Max RF Power CH3",			GetRegValue(hKey, "WCDMA_I Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_I Max RF Power Tolerance",	GetRegValue(hKey, "WCDMA_I Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_I BER CH1",					GetRegValue(hKey, "WCDMA_I BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_I BER CH2",					GetRegValue(hKey, "WCDMA_I BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_I BER CH3",					GetRegValue(hKey, "WCDMA_I BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("WCDMA_I BER Tolerance",			GetRegValue(hKey, "WCDMA_I BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_II Max RF Power CH1",		GetRegValue(hKey, "WCDMA_II Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_II Max RF Power CH2",		GetRegValue(hKey, "WCDMA_II Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_II Max RF Power CH3",		GetRegValue(hKey, "WCDMA_II Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_II Max RF Power Tolerance",	GetRegValue(hKey, "WCDMA_II Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_II BER CH1",					GetRegValue(hKey, "WCDMA_II BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_II BER CH2",					GetRegValue(hKey, "WCDMA_II BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_II BER CH3",					GetRegValue(hKey, "WCDMA_II BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("WCDMA_II BER Tolerance",			GetRegValue(hKey, "WCDMA_II BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_III Max RF Power CH1",		GetRegValue(hKey, "WCDMA_III Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_III Max RF Power CH2",		GetRegValue(hKey, "WCDMA_III Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_III Max RF Power CH3",		GetRegValue(hKey, "WCDMA_III Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_III Max RF Power Tolerance",	GetRegValue(hKey, "WCDMA_III Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_III BER CH1",				GetRegValue(hKey, "WCDMA_III BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_III BER CH2",				GetRegValue(hKey, "WCDMA_III BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_III BER CH3",				GetRegValue(hKey, "WCDMA_III BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("WCDMA_III BER Tolerance",			GetRegValue(hKey, "WCDMA_III BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_IV Max RF Power CH1",		GetRegValue(hKey, "WCDMA_IV Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_IV Max RF Power CH2",		GetRegValue(hKey, "WCDMA_IV Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_IV Max RF Power CH3",		GetRegValue(hKey, "WCDMA_IV Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_IV Max RF Power Tolerance",	GetRegValue(hKey, "WCDMA_IV Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_IV BER CH1",					GetRegValue(hKey, "WCDMA_IV BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_IV BER CH2",					GetRegValue(hKey, "WCDMA_IV BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_IV BER CH3",					GetRegValue(hKey, "WCDMA_IV BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("WCDMA_IV BER Tolerance",			GetRegValue(hKey, "WCDMA_IV BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_V Max RF Power CH1",			GetRegValue(hKey, "WCDMA_V Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_V Max RF Power CH2",			GetRegValue(hKey, "WCDMA_V Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_V Max RF Power CH3",			GetRegValue(hKey, "WCDMA_V Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_V Max RF Power Tolerance",	GetRegValue(hKey, "WCDMA_V Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_V BER CH1",					GetRegValue(hKey, "WCDMA_V BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_V BER CH2",					GetRegValue(hKey, "WCDMA_V BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_V BER CH3",					GetRegValue(hKey, "WCDMA_V BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("WCDMA_V BER Tolerance",			GetRegValue(hKey, "WCDMA_V BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_VI Max RF Power CH1",		GetRegValue(hKey, "WCDMA_VI Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_VI Max RF Power CH2",		GetRegValue(hKey, "WCDMA_VI Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_VI Max RF Power CH3",		GetRegValue(hKey, "WCDMA_VI Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_VI Max RF Power Tolerance",	GetRegValue(hKey, "WCDMA_VI Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_VI BER CH1",					GetRegValue(hKey, "WCDMA_VI BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_VI BER CH2",					GetRegValue(hKey, "WCDMA_VI BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_VI BER CH3",					GetRegValue(hKey, "WCDMA_VI BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("WCDMA_VI BER Tolerance",			GetRegValue(hKey, "WCDMA_VI BER Tolerance", _T("0.5")));

	  // TDSCDMA
	m_mapRegistry.SetAt("TDSCDMA_I Max RF Power CH1",			GetRegValue(hKey, "TDSCDMA_I Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_I Max RF Power CH2",			GetRegValue(hKey, "TDSCDMA_I Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_I Max RF Power CH3",			GetRegValue(hKey, "TDSCDMA_I Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_I Max RF Power Tolerance",	GetRegValue(hKey, "TDSCDMA_I Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("TDSCDMA_I BER CH1",					GetRegValue(hKey, "TDSCDMA_I BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_I BER CH2",					GetRegValue(hKey, "TDSCDMA_I BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_I BER CH3",					GetRegValue(hKey, "TDSCDMA_I BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("TDSCDMA_I BER Tolerance",			GetRegValue(hKey, "TDSCDMA_I BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("TDSCDMA_II Max RF Power CH1",		GetRegValue(hKey, "TDSCDMA_II Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_II Max RF Power CH2",		GetRegValue(hKey, "TDSCDMA_II Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_II Max RF Power CH3",		GetRegValue(hKey, "TDSCDMA_II Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_II Max RF Power Tolerance",	GetRegValue(hKey, "TDSCDMA_II Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("TDSCDMA_II BER CH1",					GetRegValue(hKey, "TDSCDMA_II BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_II BER CH2",					GetRegValue(hKey, "TDSCDMA_II BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_II BER CH3",					GetRegValue(hKey, "TDSCDMA_II BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("TDSCDMA_II BER Tolerance",			GetRegValue(hKey, "TDSCDMA_II BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("TDSCDMA_III Max RF Power CH1",		GetRegValue(hKey, "TDSCDMA_III Max RF Power CH1", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_III Max RF Power CH2",		GetRegValue(hKey, "TDSCDMA_III Max RF Power CH2", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_III Max RF Power CH3",		GetRegValue(hKey, "TDSCDMA_III Max RF Power CH3", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_III Max RF Power Tolerance",	GetRegValue(hKey, "TDSCDMA_III Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("TDSCDMA_III BER CH1",				GetRegValue(hKey, "TDSCDMA_III BER CH1", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_III BER CH2",				GetRegValue(hKey, "TDSCDMA_III BER CH2", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_III BER CH3",				GetRegValue(hKey, "TDSCDMA_III BER CH3", _T("-106.")));
	m_mapRegistry.SetAt("TDSCDMA_III BER Tolerance",			GetRegValue(hKey, "TDSCDMA_III BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("BLUETOOTH BT Output Power CH1",		GetRegValue(hKey, "BLUETOOTH BT Output Power CH1", _T("0.0")));
	m_mapRegistry.SetAt("BLUETOOTH BT Output Power CH2",		GetRegValue(hKey, "BLUETOOTH BT Output Power CH2", _T("0.0")));
	m_mapRegistry.SetAt("BLUETOOTH BT Output Power CH3",		GetRegValue(hKey, "BLUETOOTH BT Output Power CH3", _T("0.0")));
	m_mapRegistry.SetAt("BLUETOOTH BT Output Power Tolerance",	GetRegValue(hKey, "BLUETOOTH BT Output Power Tolerance", _T("0.1")));
	
		//WLAN
	m_mapRegistry.SetAt("WLAN Tx Output Power CH1",		GetRegValue(hKey, "WLAN Tx Output Power CH1", _T("0.0")));
	m_mapRegistry.SetAt("WLAN Tx Output Power CH2",		GetRegValue(hKey, "WLAN Tx Output Power CH2", _T("0.0")));
	m_mapRegistry.SetAt("WLAN Tx Output Power CH3",		GetRegValue(hKey, "WLAN Tx Output Power CH3", _T("0.0")));
	m_mapRegistry.SetAt("WLAN Tx Output Power Tolerance",	GetRegValue(hKey, "WLAN Tx Output Power Tolerance", _T("0.1")));

	RegCloseKey(hKey);

	// 3. General Sample Data
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\General Sample"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("CDMA Max RF Power Target",			GetRegValue(hKey, "CDMA Max RF Power Target", _T("24.0")));
	m_mapRegistry.SetAt("CDMA Max RF Power Tolerance",		GetRegValue(hKey, "CDMA Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("CDMA Rx Sensitivity Target",		GetRegValue(hKey, "CDMA Rx Sensitivity Target", _T("-106.0")));
	m_mapRegistry.SetAt("CDMA Rx Sensitivity Tolerance",	GetRegValue(hKey, "CDMA Rx Sensitivity Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("USPCS Max RF Power Target",		GetRegValue(hKey, "USPCS Max RF Power Target", _T("24.0")));
	m_mapRegistry.SetAt("USPCS Max RF Power Tolerance",		GetRegValue(hKey, "USPCS Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("USPCS Rx Sensitivity Target",		GetRegValue(hKey, "USPCS Rx Sensitivity Target", _T("-106.0")));
	m_mapRegistry.SetAt("USPCS Rx Sensitivity Tolerance",	GetRegValue(hKey, "USPCS Rx Sensitivity Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("KPCS Max RF Power Target",			GetRegValue(hKey, "KPCS Max RF Power Target", _T("24.0")));
	m_mapRegistry.SetAt("KPCS Max RF Power Tolerance",		GetRegValue(hKey, "KPCS Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("KPCS Rx Sensitivity Target",		GetRegValue(hKey, "KPCS Rx Sensitivity Target", _T("-106.0")));
	m_mapRegistry.SetAt("KPCS Rx Sensitivity Tolerance",	GetRegValue(hKey, "KPCS Rx Sensitivity Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("GSM850 Tx Output Power Target",		GetRegValue(hKey, "GSM850 Tx Output Power Target", _T("33.0")));
	m_mapRegistry.SetAt("GSM850 Tx Output Power Tolerance",		GetRegValue(hKey, "GSM850 Tx Output Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("GSM850 Rx Reported Level Target",		GetRegValue(hKey, "GSM850 Rx Reported Level Target", _T("-90.0")));
	m_mapRegistry.SetAt("GSM850 Rx Reported Level Tolerance",	GetRegValue(hKey, "GSM850 Rx Reported Level Tolerance", _T("0.1")));

	m_mapRegistry.SetAt("GSM900 Tx Output Power Target",		GetRegValue(hKey, "GSM900 Tx Output Power Target", _T("33.0")));
	m_mapRegistry.SetAt("GSM900 Tx Output Power Tolerance",		GetRegValue(hKey, "GSM900 Tx Output Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("GSM900 Rx Reported Level Target",		GetRegValue(hKey, "GSM900 Rx Reported Level Target", _T("-90.0")));
	m_mapRegistry.SetAt("GSM900 Rx Reported Level Tolerance",	GetRegValue(hKey, "GSM900 Rx Reported Level Tolerance", _T("0.1")));

	m_mapRegistry.SetAt("DCS1800 Tx Output Power Target",		GetRegValue(hKey, "DCS1800 Tx Output Power Target", _T("30.0")));
	m_mapRegistry.SetAt("DCS1800 Tx Output Power Tolerance",	GetRegValue(hKey, "DCS1800 Tx Output Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("DCS1800 Rx Reported Level Target",		GetRegValue(hKey, "DCS1800 Rx Reported Level Target", _T("-90.0")));
	m_mapRegistry.SetAt("DCS1800 Rx Reported Level Tolerance",	GetRegValue(hKey, "DCS1800 Rx Reported Level Tolerance", _T("0.1")));

	m_mapRegistry.SetAt("PCS1900 Tx Output Power Target",		GetRegValue(hKey, "PCS1900 Tx Output Power Target", _T("30.0")));
	m_mapRegistry.SetAt("PCS1900 Tx Output Power Tolerance",	GetRegValue(hKey, "PCS1900 Tx Output Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("PCS1900 Rx Reported Level Target",		GetRegValue(hKey, "PCS1900 Rx Reported Level Target", _T("-90.0")));
	m_mapRegistry.SetAt("PCS1900 Rx Reported Level Tolerance",	GetRegValue(hKey, "PCS1900 Rx Reported Level Tolerance", _T("0.1")));

	m_mapRegistry.SetAt("WCDMA_I Max RF Power Target",			GetRegValue(hKey, "WCDMA_I Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_I Max RF Power Tolerance",		GetRegValue(hKey, "WCDMA_I Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_I BER Target",					GetRegValue(hKey, "WCDMA_I BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_I BER Tolerance",				GetRegValue(hKey, "WCDMA_I BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_II Max RF Power Target",			GetRegValue(hKey, "WCDMA_II Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_II Max RF Power Tolerance",		GetRegValue(hKey, "WCDMA_II Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_II BER Target",					GetRegValue(hKey, "WCDMA_II BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_II BER Tolerance",				GetRegValue(hKey, "WCDMA_II BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_III Max RF Power Target",		GetRegValue(hKey, "WCDMA_III Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_III Max RF Power Tolerance",		GetRegValue(hKey, "WCDMA_III Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_III BER Target",					GetRegValue(hKey, "WCDMA_III BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_III BER Tolerance",				GetRegValue(hKey, "WCDMA_III BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_IV Max RF Power Target",			GetRegValue(hKey, "WCDMA_IV Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_IV Max RF Power Tolerance",		GetRegValue(hKey, "WCDMA_IV Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_IV BER Target",					GetRegValue(hKey, "WCDMA_IV BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_IV BER Tolerance",				GetRegValue(hKey, "WCDMA_IV BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_V Max RF Power Target",			GetRegValue(hKey, "WCDMA_V Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_V Max RF Power Tolerance",		GetRegValue(hKey, "WCDMA_V Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_V BER Target",					GetRegValue(hKey, "WCDMA_V BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_V BER Tolerance",				GetRegValue(hKey, "WCDMA_V BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("WCDMA_VI Max RF Power Target",			GetRegValue(hKey, "WCDMA_VI Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("WCDMA_VI Max RF Power Tolerance",		GetRegValue(hKey, "WCDMA_VI Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("WCDMA_VI BER Target",					GetRegValue(hKey, "WCDMA_VI BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("WCDMA_VI BER Tolerance",				GetRegValue(hKey, "WCDMA_VI BER Tolerance", _T("0.5")));

		//TDSCDMA
	m_mapRegistry.SetAt("TDSCDMA_I Max RF Power Target",			GetRegValue(hKey, "TDSCDMA_I Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_I Max RF Power Tolerance",		GetRegValue(hKey, "TDSCDMA_I Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("TDSCDMA_I BER Target",					GetRegValue(hKey, "TDSCDMA_I BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_I BER Tolerance",				GetRegValue(hKey, "TDSCDMA_I BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("TDSCDMA_II Max RF Power Target",			GetRegValue(hKey, "TDSCDMA_II Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_II Max RF Power Tolerance",		GetRegValue(hKey, "TDSCDMA_II Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("TDSCDMA_II BER Target",					GetRegValue(hKey, "TDSCDMA_II BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_II BER Tolerance",				GetRegValue(hKey, "TDSCDMA_II BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("TDSCDMA_III Max RF Power Target",		GetRegValue(hKey, "TDSCDMA_III Max RF Power Target", _T("23.0")));
	m_mapRegistry.SetAt("TDSCDMA_III Max RF Power Tolerance",		GetRegValue(hKey, "TDSCDMA_III Max RF Power Tolerance", _T("0.1")));
	m_mapRegistry.SetAt("TDSCDMA_III BER Target",					GetRegValue(hKey, "TDSCDMA_III BER Target", _T("-106.0")));
	m_mapRegistry.SetAt("TDSCDMA_III BER Tolerance",				GetRegValue(hKey, "TDSCDMA_III BER Tolerance", _T("0.5")));

	m_mapRegistry.SetAt("BLUETOOTH BT Output Power Target",		GetRegValue(hKey, "BLUETOOTH BT Output Power Target", _T("0")));
	m_mapRegistry.SetAt("BLUETOOTH BT Output Power Tolerance",	GetRegValue(hKey, "BLUETOOTH BT Output Power Tolerance", _T("0.1")));

		//WLAN
	m_mapRegistry.SetAt("WLAN Tx Output Power Target",		GetRegValue(hKey, "WLAN Tx Output Power Target", _T("13")));
	m_mapRegistry.SetAt("WLAN Tx Output Power Tolerance",	GetRegValue(hKey, "WLAN Tx Output Power Tolerance", _T("0.1")));

	RegCloseKey(hKey);

	//4. Measure Loss Table
	// Loss Value (LOW) =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Low"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("Measured CDMA Rx Low", GetRegValue(hKey, "Measured CDMA Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured CDMA Tx Low", GetRegValue(hKey, "Measured CDMA Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured KPCS Rx Low", GetRegValue(hKey, "Measured KPCS Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured KPCS Tx Low", GetRegValue(hKey, "Measured KPCS Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured USPCS Rx Low", GetRegValue(hKey, "Measured USPCS Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured USPCS Tx Low", GetRegValue(hKey, "Measured USPCS Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured GSM850 Rx Low", GetRegValue(hKey, "Measured GSM850 Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured GSM850 Tx Low", GetRegValue(hKey, "Measured GSM850 Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured GSM900 Rx Low", GetRegValue(hKey, "Measured GSM900 Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured GSM900 Tx Low", GetRegValue(hKey, "Measured GSM900 Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured DCS1800 Rx Low", GetRegValue(hKey, "Measured DCS1800 Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured DCS1800 Tx Low", GetRegValue(hKey, "Measured DCS1800 Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured PCS1900 Rx Low", GetRegValue(hKey, "Measured PCS1900 Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured PCS1900 Tx Low", GetRegValue(hKey, "Measured PCS1900 Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_I Rx Low", GetRegValue(hKey, "Measured WCDMA_I Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_I Tx Low", GetRegValue(hKey, "Measured WCDMA_I Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_II Rx Low", GetRegValue(hKey, "Measured WCDMA_II Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_II Tx Low", GetRegValue(hKey, "Measured WCDMA_II Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_III Rx Low", GetRegValue(hKey, "Measured WCDMA_III Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_III Tx Low", GetRegValue(hKey, "Measured WCDMA_III Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_IV Rx Low", GetRegValue(hKey, "Measured WCDMA_IV Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_IV Tx Low", GetRegValue(hKey, "Measured WCDMA_IV Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_V Rx Low", GetRegValue(hKey, "Measured WCDMA_V Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_V Tx Low", GetRegValue(hKey, "Measured WCDMA_V Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_VI Rx Low", GetRegValue(hKey, "Measured WCDMA_VI Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_VI Tx Low", GetRegValue(hKey, "Measured WCDMA_VI Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured BLUETOOTH Low", GetRegValue(hKey, "Measured BLUETOOTH Low", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_I Rx Low", GetRegValue(hKey, "Measured TDSCDMA_I Rx Low", _T("0")));	//  [9/17/2007] TDSCDMA
	m_mapRegistry.SetAt("Measured TDSCDMA_I Tx Low", GetRegValue(hKey, "Measured TDSCDMA_I Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_II Rx Low", GetRegValue(hKey, "Measured TDSCDMA_II Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_II Tx Low", GetRegValue(hKey, "Measured TDSCDMA_II Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_III Rx Low", GetRegValue(hKey, "Measured TDSCDMA_III Rx Low", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_III Tx Low", GetRegValue(hKey, "Measured TDSCDMA_III Tx Low", _T("0")));
	m_mapRegistry.SetAt("Measured WLAN Low", GetRegValue(hKey, "Measured WLAN Low", _T("0")));	//  [9/17/2007] WLAN

	RegCloseKey(hKey);

	// Loss Value (MED) =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\Med"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("Measured CDMA Rx Med", GetRegValue(hKey, "Measured CDMA Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured CDMA Tx Med", GetRegValue(hKey, "Measured CDMA Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured KPCS Rx Med", GetRegValue(hKey, "Measured KPCS Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured KPCS Tx Med", GetRegValue(hKey, "Measured KPCS Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured USPCS Rx Med", GetRegValue(hKey, "Measured USPCS Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured USPCS Tx Med", GetRegValue(hKey, "Measured USPCS Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured GSM850 Rx Med", GetRegValue(hKey, "Measured GSM850 Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured GSM850 Tx Med", GetRegValue(hKey, "Measured GSM850 Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured GSM900 Rx Med", GetRegValue(hKey, "Measured GSM900 Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured GSM900 Tx Med", GetRegValue(hKey, "Measured GSM900 Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured DCS1800 Rx Med", GetRegValue(hKey, "Measured DCS1800 Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured DCS1800 Tx Med", GetRegValue(hKey, "Measured DCS1800 Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured PCS1900 Rx Med", GetRegValue(hKey, "Measured PCS1900 Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured PCS1900 Tx Med", GetRegValue(hKey, "Measured PCS1900 Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_I Rx Med", GetRegValue(hKey, "Measured WCDMA_I Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_I Tx Med", GetRegValue(hKey, "Measured WCDMA_I Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_II Rx Med", GetRegValue(hKey, "Measured WCDMA_II Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_II Tx Med", GetRegValue(hKey, "Measured WCDMA_II Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_III Rx Med", GetRegValue(hKey, "Measured WCDMA_III Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_III Tx Med", GetRegValue(hKey, "Measured WCDMA_III Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_IV Rx Med", GetRegValue(hKey, "Measured WCDMA_IV Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_IV Tx Med", GetRegValue(hKey, "Measured WCDMA_IV Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_V Rx Med", GetRegValue(hKey, "Measured WCDMA_V Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_V Tx Med", GetRegValue(hKey, "Measured WCDMA_V Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_VI Rx Med", GetRegValue(hKey, "Measured WCDMA_VI Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_VI Tx Med", GetRegValue(hKey, "Measured WCDMA_VI Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured BLUETOOTH Med", GetRegValue(hKey, "Measured BLUETOOTH Med", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_I Rx Med", GetRegValue(hKey, "Measured TDSCDMA_I Rx Med", _T("0")));	//  [9/17/2007] TDSCDMA
	m_mapRegistry.SetAt("Measured TDSCDMA_I Tx Med", GetRegValue(hKey, "Measured TDSCDMA_I Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_II Rx Med", GetRegValue(hKey, "Measured TDSCDMA_II Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_II Tx Med", GetRegValue(hKey, "Measured TDSCDMA_II Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_III Rx Med", GetRegValue(hKey, "Measured TDSCDMA_III Rx Med", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_III Tx Med", GetRegValue(hKey, "Measured TDSCDMA_III Tx Med", _T("0")));
	m_mapRegistry.SetAt("Measured WLAN Med", GetRegValue(hKey, "Measured WLAN Med", _T("0")));	//  [9/17/2007] WLAN

	RegCloseKey(hKey);

	// Loss Value (HIGH) =================
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Loss\\High"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL); 

	m_mapRegistry.SetAt("Measured CDMA Rx High", GetRegValue(hKey, "Measured CDMA Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured CDMA Tx High", GetRegValue(hKey, "Measured CDMA Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured KPCS Rx High", GetRegValue(hKey, "Measured KPCS Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured KPCS Tx High", GetRegValue(hKey, "Measured KPCS Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured USPCS Rx High", GetRegValue(hKey, "Measured USPCS Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured USPCS Tx High", GetRegValue(hKey, "Measured USPCS Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured GSM850 Rx High", GetRegValue(hKey, "Measured GSM850 Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured GSM850 Tx High", GetRegValue(hKey, "Measured GSM850 Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured GSM900 Rx High", GetRegValue(hKey, "Measured GSM900 Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured GSM900 Tx High", GetRegValue(hKey, "Measured GSM900 Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured DCS1800 Rx High", GetRegValue(hKey, "Measured DCS1800 Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured DCS1800 Tx High", GetRegValue(hKey, "Measured DCS1800 Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured PCS1900 Rx High", GetRegValue(hKey, "Measured PCS1900 Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured PCS1900 Tx High", GetRegValue(hKey, "Measured PCS1900 Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_I Rx High", GetRegValue(hKey, "Measured WCDMA_I Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_I Tx High", GetRegValue(hKey, "Measured WCDMA_I Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_II Rx High", GetRegValue(hKey, "Measured WCDMA_II Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_II Tx High", GetRegValue(hKey, "Measured WCDMA_II Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_III Rx High", GetRegValue(hKey, "Measured WCDMA_III Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_III Tx High", GetRegValue(hKey, "Measured WCDMA_III Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_IV Rx High", GetRegValue(hKey, "Measured WCDMA_IV Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_IV Tx High", GetRegValue(hKey, "Measured WCDMA_IV Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_V Rx High", GetRegValue(hKey, "Measured WCDMA_V Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_V Tx High", GetRegValue(hKey, "Measured WCDMA_V Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_VI Rx High", GetRegValue(hKey, "Measured WCDMA_VI Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured WCDMA_VI Tx High", GetRegValue(hKey, "Measured WCDMA_VI Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured BLUETOOTH High", GetRegValue(hKey, "Measured BLUETOOTH High", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_I Rx High", GetRegValue(hKey, "Measured TDSCDMA_I Rx High", _T("0")));	//  [9/17/2007] TDSCDMA
	m_mapRegistry.SetAt("Measured TDSCDMA_I Tx High", GetRegValue(hKey, "Measured TDSCDMA_I Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_II Rx High", GetRegValue(hKey, "Measured TDSCDMA_II Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_II Tx High", GetRegValue(hKey, "Measured TDSCDMA_II Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_III Rx High", GetRegValue(hKey, "Measured TDSCDMA_III Rx High", _T("0")));
	m_mapRegistry.SetAt("Measured TDSCDMA_III Tx High", GetRegValue(hKey, "Measured TDSCDMA_III Tx High", _T("0")));
	m_mapRegistry.SetAt("Measured WLAN High", GetRegValue(hKey, "Measured WLAN High", _T("0")));	//  [9/17/2007] WLAN

	RegCloseKey(hKey);

	//////////////////////////////////////////////////////////////////////////
	//  [12/8/2006] vivache : Advanced Set
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"), 0, KEY_ALL_ACCESS, &hKey) != ERROR_SUCCESS)
		RegCreateKeyEx(HKEY_LOCAL_MACHINE, _T("SOFTWARE\\LG Inspection SW\\GD\\Loss Measure\\Advanced"),0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL);

	// Common
	m_mapRegistry.SetAt("Loss Table", GetRegValue(hKey, "Loss Table", _T("0")));
	m_mapRegistry.SetAt("Measure Timeout", GetRegValue(hKey, "Measure Timeout", _T("300")));
	m_mapRegistry.SetAt("Measure Loss Limit", GetRegValue(hKey, "Measure Loss Limit", _T("40")));

	// General sample measure
	m_mapRegistry.SetAt("Range Tx Power Lower",	GetRegValue(hKey, "Range Tx Power Lower", _T("5")));
	m_mapRegistry.SetAt("Range Tx Power Upper",	GetRegValue(hKey, "Range Tx Power Upper", _T("5")));

	m_mapRegistry.SetAt("Range Rx FER Lower",	GetRegValue(hKey, "Range Rx FER Lower", _T("5")));
	m_mapRegistry.SetAt("Range Rx FER Upper",	GetRegValue(hKey, "Range Rx FER Upper", _T("5")));

	m_mapRegistry.SetAt("Range Rx Level Lower",	GetRegValue(hKey, "Range Rx Level Lower", _T("3")));
	m_mapRegistry.SetAt("Range Rx Level Upper",	GetRegValue(hKey, "Range Rx Level Upper", _T("3")));

	RegCloseKey(hKey);
}

CString CRegistry::GetRegValue(HKEY hCurrentKey, LPCSTR lpValueName, LPCSTR lpDefaultValue)
{
	DWORD dwType;
	TCHAR szData[100];
	DWORD dwLength = 0;

	dwLength = sizeof(szData);
	ZeroMemory(szData, sizeof(szData));

	if(RegQueryValueEx(hCurrentKey, lpValueName, 0, &dwType, (BYTE *)szData, &dwLength) != ERROR_SUCCESS)
	{
		RegSetValueEx(hCurrentKey, lpValueName, 0, REG_SZ, (BYTE *)(LPSTR)lpDefaultValue, strlen(lpDefaultValue) );
		strcpy(szData, lpDefaultValue);
	}

	return CString(szData);
}

CString CRegistry::GetValue(CString sValueName)
{
	return m_mapRegistry[sValueName];
}

void CRegistry::SetValue(CString sValueName, CString sValue)
{
	m_mapRegistry[sValueName] = sValue;
	CString sKeyName = m_mapValueToKey[sValueName];
	
	if ( sKeyName.IsEmpty() || sKeyName == "" )
		return;

	HKEY hKey;
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE, (LPCSTR)sKeyName, 0, KEY_SET_VALUE, &hKey) != ERROR_SUCCESS)
		RegCreateKey(HKEY_LOCAL_MACHINE, (LPCSTR)sKeyName, &hKey); 

	RegSetValueEx(hKey, (LPCSTR)sValueName, 0, REG_SZ, (BYTE *)(LPSTR)(LPCSTR)sValue, sValue.GetLength());

	RegCloseKey(hKey);
}
