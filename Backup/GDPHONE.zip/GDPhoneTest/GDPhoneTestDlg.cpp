// GDPhoneTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "GDPhoneTest.h"
#include "GDPhoneTestDlg.h"
#include "GDComDefine.h"
#include "Util.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGDPhoneTestDlg dialog

CGDPhoneTestDlg::CGDPhoneTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGDPhoneTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGDPhoneTestDlg)
	m_nCommMode = -1;
	m_nBaudRate = -1;
	m_nComPort = -1;
	m_sDriverName = _T("");
	m_sParameter = _T("");
	m_sParameter2 = _T("");
	m_bIsCdma = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CGDPhoneTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGDPhoneTestDlg)
	DDX_Control(pDX, IDC_SPY_LIST, m_listSpy);
	DDX_Control(pDX, IDC_RESULT_LIST, m_listResult);
	DDX_CBIndex(pDX, IDC_COMBO_COMM_MODE, m_nCommMode);
	DDX_CBIndex(pDX, IDC_COMBO_BAUDRATE, m_nBaudRate);
	DDX_CBIndex(pDX, IDC_COMBO_COMPORT, m_nComPort);
	DDX_Text(pDX, IDC_EDIT_DRIVER_NAME, m_sDriverName);
	DDX_Text(pDX, IDC_EDIT_PARAMETER, m_sParameter);
	DDX_Text(pDX, IDC_EDIT_PARAMETER2, m_sParameter2);
	DDX_Radio(pDX, IDC_RADIO_4, m_nRadio);
	DDX_Check(pDX, IDC_CHECK_CDMA, m_bIsCdma);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CGDPhoneTestDlg, CDialog)
	//{{AFX_MSG_MAP(CGDPhoneTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_INIT_PHONE, OnButtonInitPhone)
	ON_BN_CLICKED(IDC_BUTTON_EXIT_PHONE, OnButtonExitPhone)
	ON_BN_CLICKED(IDC_BUTTON_OPEN, OnButtonOpen)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE, OnButtonClose)
	ON_BN_CLICKED(IDC_BUTTON_RUN, OnButtonRun)
	ON_BN_CLICKED(IDC_CLEAR, OnClear)
	ON_BN_CLICKED(IDC_BUTTON_SEARCH, OnButtonSearch)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGDPhoneTestDlg message handlers

BOOL CGDPhoneTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_sDriverName = "LGE";
	m_nComPort = 1;
	m_nBaudRate = 0;
	m_nCommMode = 0;
	UpdateData(FALSE);

	CString sBinPath = CUtil::GetBinPath();
	sBinPath += CString("\\") + _T("GDPhone.dll");
	sBinPath = CUtil::MakeLastVersionPath(sBinPath);

	HINSTANCE hDLL = NULL;
	hDLL = LoadLibrary(sBinPath);
	if ( hDLL == NULL )
	{
		AfxMessageBox("Phone DLL�� ã�� ���� �����ϴ�.");
		return FALSE;
	}

	typedef LPVOID (*FP_GET_GDPHONE)();
	FP_GET_GDPHONE pGetGDPhone;

	pGetGDPhone = (FP_GET_GDPHONE)GetProcAddress(hDLL,"GetGDPhone");
	m_pGDPhone = (GDPhoneInterface *)pGetGDPhone();

	m_pGDPhone->SetEventHandler(&m_Event);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CGDPhoneTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CGDPhoneTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CGDPhoneTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CGDPhoneTestDlg::OnButtonInitPhone() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_nCommMode<0)
	{
		m_listResult.AddString("��� ��带 ������ �ּ���");
		return;
	}

	BOOL bRet = m_pGDPhone->InitPhone(m_nCommMode+1);
	m_listResult.AddString(CString("InitPhone => ") + (bRet?"OK":"NG") );
}

void CGDPhoneTestDlg::OnButtonExitPhone() 
{
	// TODO: Add your control notification handler code here
	BOOL bRet = m_pGDPhone->ExitPhone();
	m_listResult.AddString(CString("ExitPhone => ") + (bRet?"OK":"NG") );
}

void CGDPhoneTestDlg::OnButtonOpen() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_nComPort<0)
	{
		m_listResult.AddString("COM��Ʈ�� ������ �ּ���");
		return;
	}
	if (m_nBaudRate<0)
	{
		m_listResult.AddString("BaudRate�� ������ �ּ���");
		return;
	}

	int nBaudRate[3] = {CBR_115200, CBR_38400, CBR_19200};

	BOOL bRet = m_pGDPhone->Open(m_nComPort+1, nBaudRate[m_nBaudRate]);
	m_pGDPhone->Init();
	m_listResult.AddString(CString("Open => ") + (bRet?"OK":"NG") );
}

void CGDPhoneTestDlg::OnButtonClose() 
{
	// TODO: Add your control notification handler code here
	BOOL bRet = m_pGDPhone->Close();
	m_listResult.AddString(CString("Close => ") + (bRet?"OK":"NG") );
}

void CGDPhoneTestDlg::OnButtonRun() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_nRadio<0)
	{
		m_listResult.AddString("�Լ��� ������ �ּ���");
		return;
	}

	BOOL bRet = FALSE;
	BOOL bResult=FALSE;
	CString sDisplay(_T(""));
	CString sOutValue(_T(""));
	int nState;
	PHONESTATUS PhoneStatus;

	DWORD dwStartTime = clock();

	switch (m_nRadio)
	{
	case 0 : 
		sDisplay = "IsPhoneConnected";
		bRet = m_pGDPhone->IsPhoneConnected();
		break;
	case 1 : 
		sDisplay = "GetSWVersion";
		bRet = m_pGDPhone->GetSWVersion(sOutValue);
		break;
	case 2 : 
		sDisplay = "GetProductID";
		bRet = m_pGDPhone->GetProductID(sOutValue);
		break;
	case 3 : 
		sDisplay = "SetProductID";
		bRet = m_pGDPhone->SetProductID(m_sParameter);
		break;
	case 4 : 
		sDisplay = "GetESNIMEI";
		bRet = m_pGDPhone->GetESNIMEI(sOutValue);
		break;
	case 5 : 
		sDisplay = "SetKeyPad";
		if ( m_nCommMode >= 2 ) // UMTS
			bRet = m_pGDPhone->SetKeyPad((DWORD)&m_sParameter,atoi(m_sParameter2));
		else					// CDMA
			bRet = m_pGDPhone->SetKeyPad((DWORD)atoi(m_sParameter),atoi(m_sParameter2));
		
		break;
	case 6 : 
		sDisplay = "SetKeyPadLock";
		bRet = m_pGDPhone->SetKeyPadLock(atoi(m_sParameter));
		break;
	case 7 : 
		sDisplay = "CheckRegister";
		bRet = m_pGDPhone->CheckRegister(bResult);
		break;
	case 8 : 
		sDisplay = "SetBand";
		bRet = m_pGDPhone->SetBand(atoi(m_sParameter));
		break;
	case 9 : 
		sDisplay = "SetChannel";
		bRet = m_pGDPhone->SetChannel(atof(m_sParameter));
		break;
	case 10 : 
		sDisplay = "SetMode";
		bRet = m_pGDPhone->SetMode((BYTE)atoi(m_sParameter));
		break;
	case 11 : 
		sDisplay = "SetDipSwitch";
		bRet = m_pGDPhone->SetDipSwitch((WORD)atoi(m_sParameter));
		break;
	case 12 : 
		sDisplay = "SetBluetoothMode";
		bRet = m_pGDPhone->SetBluetoothMode(atoi(m_sParameter), 10);
		break;
	case 13 : 
		sDisplay = "PhoneReset";
		bRet = m_pGDPhone->PhoneReset();
		break;
	case 14 : 
		sDisplay = "GetPhoneState";
		bRet = m_pGDPhone->GetPhoneState(0,&nState,sOutValue);
		break;
	case 15 : 
		sDisplay = "GetPhoneStatus";
		bRet = m_pGDPhone->GetPhoneStatus(&PhoneStatus);
		sOutValue.Format("CH : %d",(int)PhoneStatus.curr_chan);
		break;
	case 16 : 
		sDisplay = "ChangeDiagPath";
		if ( m_sParameter == "6500" )
			bRet = m_pGDPhone->ChangeDiagPath(TO_MSM6500);
		else
			bRet = m_pGDPhone->ChangeDiagPath(TO_MSM6275);
		break;
	case 17 : 
		sDisplay = "SetFTMNV";
		bRet = m_pGDPhone->SetFTMNV(FALSE);
		break;
	case 18 : 
		sDisplay = "SetTestMode";
		bRet = m_pGDPhone->SetTestMode(m_sParameter);
		break;
	case 19 : 
		sDisplay = "SetVirtualSIM";
		bRet = m_pGDPhone->SetVSIM();
		break;
	case 20 : 
		sDisplay = "SetEmergencyCall";
		bRet = m_pGDPhone->SetEmergencyCall(TRUE);
		break;
	case 21 : 
		sDisplay = "ChangeSystem";
		bRet = m_pGDPhone->ChangeSystem(atoi(m_sParameter));
		break;
	}

	DWORD dwElapseTime = clock() - dwStartTime;

	CString sElapseTime(_T(""));
	sElapseTime.Format(" [%d.%03dsec]", dwElapseTime/1000, dwElapseTime%1000);

	if (!sOutValue.IsEmpty())
		sOutValue = CString(" ( ") + sOutValue + " )";
	m_listResult.AddString( sDisplay + " => " + (bRet?"OK":"NG") + sOutValue + sElapseTime);
}

void CGDPhoneTestDlg::OnClear() 
{
	// TODO: Add your control notification handler code here
	m_listResult.ResetContent();	
	m_listSpy.ResetContent();
}

void CGDPhoneTestDlg::OnButtonSearch() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if (m_nComPort<0)
	{
		m_listResult.AddString("COM��Ʈ�� ������ �ּ���");
		return;
	}

	BOOL bRet = FALSE;
	CString sDisplay(_T(""));
	CString sOutValue(_T(""));

	sDisplay = "Search SW Version";
	bRet = m_pGDPhone->SearchSWVersion(m_nComPort+1, m_bIsCdma, sOutValue);

	if (!sOutValue.IsEmpty())
		sOutValue = CString(" ( ") + sOutValue + " )";
	m_listResult.AddString( sDisplay + " => " + (bRet?"OK":"NG") + sOutValue);
}
