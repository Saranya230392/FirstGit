// Registry.h: interface for the CRegistry class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REGISTRY_H__71F0EE05_D45C_4DE6_9122_1949F8CCA236__INCLUDED_)
#define AFX_REGISTRY_H__71F0EE05_D45C_4DE6_9122_1949F8CCA236__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRegistry : public CObject  
{
// Attribute
protected:
	CMapStringToString m_mapRegistry;
	CMapStringToString m_mapValueToKey;

// Operation
protected:
	void SetKeyInfo();
	CString GetRegValue(HKEY hCurrentKey, LPCSTR lpValueName, LPCSTR lpDefaultValue);

public:
	void SetValue(CString sValueName, CString sValue);
	CString GetValue(CString sValueName);
	void OpenRegistry();
	CRegistry();
	virtual ~CRegistry();

};

#endif // !defined(AFX_REGISTRY_H__71F0EE05_D45C_4DE6_9122_1949F8CCA236__INCLUDED_)
