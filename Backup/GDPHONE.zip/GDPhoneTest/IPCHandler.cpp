// IPCHandler.cpp: implementation of the CIPCHandler class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "IPCHandler.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const int MsgLabelCnt = 18;

const enum MsgLabelIndex {  ML_IDENTITY = 0, ML_IDENTITY_RES, ML_SETMODEL, ML_SETMODEL_RES,
							ML_STARTTEST, ML_STARTTEST_RES, ML_PROGRESS, ML_PROGRESS_RES,
							ML_ENDTEST, ML_ENDTEST_RES, ML_SETLOSS, ML_SETLOSS_RES,
							ML_SETSYSTEM, ML_SETSYSTEM_RES, ML_PROGRAMCHECK, ML_PROGRAMCHECK_RES,
							ML_GETMODEL, ML_INSTRUMENTINFO };
const CString MsgLabel[MsgLabelCnt] = { _T("Identity"), _T("Identity Res"), _T("SetModel"), _T("SetModel Res"),
										_T("StartTest"), _T("StartTest Res"), _T("Progress"), _T("Progress Res"),
										_T("EndTest"), _T("EndTest Res"), _T("SetLoss"), _T("SetLoss Res"),
										_T("SetSystem"), _T("SetSystem Res"), _T("ProgramCheck"), _T("ProgramCheck Res") 
										_T("GetModel"), _T("InstrumentInfo") };

CIPCHandler::CIPCHandler()
{
	m_sClientName = _T("");
	m_sSWVersion = _T("");
	m_pEventHandler = NULL;
	m_bUseDefaultEventHandler = FALSE;
}

CIPCHandler::~CIPCHandler()
{
	if ( m_bUseDefaultEventHandler && m_pEventHandler )
	{
		delete m_pEventHandler;
		m_pEventHandler = NULL;
		m_bUseDefaultEventHandler = FALSE;
	}
}

BOOL CIPCHandler::RunServer(CIPCEvent *pEventHandler)
{
	if ( m_SocketManager.IsRun() )
		return TRUE;

	if ( pEventHandler == NULL )
	{
		m_pEventHandler = new CIPCEvent;
		m_bUseDefaultEventHandler = TRUE;
	}
	else
	{
		m_pEventHandler = pEventHandler;		
	}
	m_pEventHandler->SetParent(this);

	m_SocketManager.Run(this, TRUE);

	return TRUE;
}

BOOL CIPCHandler::RunClient(CString sName, CString sSWVersion, CIPCEvent *pEventHandler)
{
	if ( m_SocketManager.IsRun() )
		return TRUE;

	if ( sName.IsEmpty() )
		return FALSE;

	if ( pEventHandler == NULL )
	{
		m_pEventHandler = new CIPCEvent;
		m_bUseDefaultEventHandler = TRUE;
	}
	else
	{
		m_pEventHandler = pEventHandler;		
	}
	m_pEventHandler->SetParent(this);

	m_sClientName = sName;
	m_sSWVersion = sSWVersion;

	m_SocketManager.Run(this, FALSE);

	return TRUE;
}

//=================================
// Methods For Manufacturing SW
//=================================

void CIPCHandler::SendIdentity(CString sName, CString sSWVersion)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	pArgMap->SetAt("SW Name", sName);
	pArgMap->SetAt("SW Version", sSWVersion);

	m_SocketManager.SendMessageToServer(MsgLabel[ML_IDENTITY], pArgMap);
}

void CIPCHandler::SendSetModel_Res(BOOL bResult, CString sMsg)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	pArgMap->SetAt("Result", (bResult? _T("OK"):_T("NG")));
	pArgMap->SetAt("Error Msg", sMsg);

	m_SocketManager.SendMessageToServer(MsgLabel[ML_SETMODEL_RES], pArgMap);
}

void CIPCHandler::SendStartTest_Res(int nJigNo, BOOL bResult, CString sErrorMsg)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sJigNo(_T(""));
	sJigNo.Format("%d", nJigNo);

	pArgMap->SetAt("Jig No", sJigNo);
	pArgMap->SetAt("Result", (bResult? _T("OK"):_T("NG")));
	pArgMap->SetAt("Error Msg", sErrorMsg);

	m_SocketManager.SendMessageToServer(MsgLabel[ML_STARTTEST_RES], pArgMap);
}

void CIPCHandler::SendProgress(int nJigNo, int nPercent, CString sMsg)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sJigNo(_T("")), sPercent(_T(""));
	sJigNo.Format("%d", nJigNo);
	sPercent.Format("%d", nPercent);

	pArgMap->SetAt("Jig No", sJigNo);
	pArgMap->SetAt("Percent", sPercent);
	pArgMap->SetAt("Msg", sMsg);

	m_SocketManager.SendMessageToServer(MsgLabel[ML_PROGRESS], pArgMap);
}

void CIPCHandler::SendEndTest(int nJigNo, BOOL bResult, CString sMsg)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sJigNo(_T(""));
	sJigNo.Format("%d", nJigNo);

	pArgMap->SetAt("Jig No", sJigNo);
	pArgMap->SetAt("Result", (bResult? _T("PASS"):_T("FAIL")));
	pArgMap->SetAt("Msg", sMsg);

	m_SocketManager.SendMessageToServer(MsgLabel[ML_ENDTEST], pArgMap);
}

void CIPCHandler::SendSetLoss_Res(int nJigNo, BOOL bResult)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sJigNo(_T(""));
	sJigNo.Format("%d", nJigNo);

	pArgMap->SetAt("Jig No", sJigNo);
	pArgMap->SetAt("Result", (bResult? _T("OK"):_T("CANCEL")));

	m_SocketManager.SendMessageToServer(MsgLabel[ML_SETLOSS_RES], pArgMap);
}

void CIPCHandler::SendSetSystem_Res(BOOL bResult)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	pArgMap->SetAt("Result", (bResult? _T("OK"):_T("CANCEL")));

	m_SocketManager.SendMessageToServer(MsgLabel[ML_SETSYSTEM_RES], pArgMap);
}

void CIPCHandler::SendProgramCheck_Res()
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	m_SocketManager.SendMessageToServer(MsgLabel[ML_PROGRAMCHECK_RES], pArgMap);
}

void CIPCHandler::SendGetModel()
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	m_SocketManager.SendMessageToServer(MsgLabel[ML_GETMODEL], pArgMap);
}

void CIPCHandler::SendInstrumentInfo(CString sName1, CString sAddr1, CString sName2, CString sAddr2, CString sName3, CString sAddr3, CString sName4, CString sAddr4, CString sName5, CString sAddr5, CString sName6, CString sAddr6, CString sName7, CString sAddr7)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	pArgMap->SetAt("Name1", sName1.IsEmpty()?_T("NULL"):sName1);
	pArgMap->SetAt("Addr1", sAddr1.IsEmpty()?_T("NULL"):sAddr1);
	pArgMap->SetAt("Name2", sName2.IsEmpty()?_T("NULL"):sName2);
	pArgMap->SetAt("Addr2", sAddr2.IsEmpty()?_T("NULL"):sAddr2);
	pArgMap->SetAt("Name3", sName3.IsEmpty()?_T("NULL"):sName3);
	pArgMap->SetAt("Addr3", sAddr3.IsEmpty()?_T("NULL"):sAddr3);
	pArgMap->SetAt("Name4", sName4.IsEmpty()?_T("NULL"):sName4);
	pArgMap->SetAt("Addr4", sAddr4.IsEmpty()?_T("NULL"):sAddr4);
	pArgMap->SetAt("Name5", sName5.IsEmpty()?_T("NULL"):sName5);
	pArgMap->SetAt("Addr5", sAddr5.IsEmpty()?_T("NULL"):sAddr5);
	pArgMap->SetAt("Name6", sName6.IsEmpty()?_T("NULL"):sName6);
	pArgMap->SetAt("Addr6", sAddr6.IsEmpty()?_T("NULL"):sAddr6);
	pArgMap->SetAt("Name7", sName7.IsEmpty()?_T("NULL"):sName7);
	pArgMap->SetAt("Addr7", sAddr7.IsEmpty()?_T("NULL"):sAddr7);

	m_SocketManager.SendMessageToServer(MsgLabel[ML_INSTRUMENTINFO], pArgMap);
}

//=================================
// Methods For Celmelt
//=================================

void CIPCHandler::SendIdentity_Res(CString sReceiver, BOOL bResult)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	pArgMap->SetAt("Result", (bResult? _T("OK"):_T("UNKNOWN")));

	m_SocketManager.SendMessage(sReceiver, MsgLabel[ML_IDENTITY_RES], pArgMap);
}

void CIPCHandler::SendSetModel(CString sReceiver, CString sModel, CString sBuyer, CString sWorkOrder, CString sColor, CString sCommType, int nBaudrate)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sBaudrate(_T(""));
	sBaudrate.Format("%d", nBaudrate);

	pArgMap->SetAt("Model", sModel);
	pArgMap->SetAt("Buyer", sBuyer);
	pArgMap->SetAt("WorkOrder", sWorkOrder);
	pArgMap->SetAt("Color", sColor);
	pArgMap->SetAt("CommType", sCommType);
	pArgMap->SetAt("Baudrate", sBaudrate);

	m_SocketManager.SendMessage(sReceiver, MsgLabel[ML_SETMODEL], pArgMap);
}

void CIPCHandler::SendStartTest(CString sReceiver, int nJigNo, CString sBarcode)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sJigNo(_T(""));
	sJigNo.Format("%d", nJigNo);

	pArgMap->SetAt("Jig No", sJigNo);
	pArgMap->SetAt("Barcode", sBarcode);

	m_SocketManager.SendMessage(sReceiver, MsgLabel[ML_STARTTEST], pArgMap);
}

void CIPCHandler::SendProgress_Res(CString sReceiver, int nJigNo)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sJigNo(_T(""));
	sJigNo.Format("%d", nJigNo);

	pArgMap->SetAt("Jig No", sJigNo);

	m_SocketManager.SendMessage(sReceiver, MsgLabel[ML_PROGRESS_RES], pArgMap);
}

void CIPCHandler::SendEndTest_Res(CString sReceiver, int nJigNo)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sJigNo(_T(""));
	sJigNo.Format("%d", nJigNo);

	pArgMap->SetAt("Jig No", sJigNo);

	m_SocketManager.SendMessage(sReceiver, MsgLabel[ML_ENDTEST_RES], pArgMap);
}

void CIPCHandler::SendSetLoss(CString sReceiver, int nJigNo)
{
	CMapStringToString *pArgMap = new CMapStringToString;
	
	CString sJigNo(_T(""));
	sJigNo.Format("%d", nJigNo);

	pArgMap->SetAt("Jig No", sJigNo);

	m_SocketManager.SendMessage(sReceiver, MsgLabel[ML_SETLOSS], pArgMap);
}

void CIPCHandler::SendSetSystem(CString sReceiver)
{
	CMapStringToString *pArgMap = new CMapStringToString;

	m_SocketManager.SendMessage(sReceiver, MsgLabel[ML_SETSYSTEM], pArgMap);
}

void CIPCHandler::SendProgramCheck(CString sReceiver)
{
	CMapStringToString *pArgMap = new CMapStringToString;

	m_SocketManager.SendMessage(sReceiver, MsgLabel[ML_PROGRAMCHECK], pArgMap);
}

void CIPCHandler::ProcessMessage(CString sSender, CString sLabel, CMapStringToString &ArgMap)
{
	if ( m_pEventHandler == NULL )
		return;

	for ( int nIndex = 0; nIndex < MsgLabelCnt ; nIndex++ )
	{
		if ( MsgLabel[nIndex] == sLabel )
			break;

		if ( nIndex == ( MsgLabelCnt - 1 ) )
			return;
	}

	CString sArgValue[20] = { _T(""), };

	switch ( nIndex )
	{
		case ML_IDENTITY :
			if ( !ArgMap.Lookup("SW Name", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("SW Version", sArgValue[1]) )
				return;
			m_pEventHandler->OnIdentity(sArgValue[0], sArgValue[1]);
			break;

		case ML_IDENTITY_RES :
			if ( !ArgMap.Lookup("Result", sArgValue[0]) )
				return;
			m_pEventHandler->OnIdentity_Res( (sArgValue[0]=="OK")? TRUE : FALSE );
			break;

		case ML_SETMODEL :
			if ( !ArgMap.Lookup("Model", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("Buyer", sArgValue[1]) )
				return;
			if ( !ArgMap.Lookup("WorkOrder", sArgValue[2]) )
				return;
			if ( !ArgMap.Lookup("Color", sArgValue[3]) )
				return;
			if ( !ArgMap.Lookup("CommType", sArgValue[4]) )
				return;
			if ( !ArgMap.Lookup("Baudrate", sArgValue[5]) )
				return;
			m_pEventHandler->OnSetModel(sArgValue[0], sArgValue[1], sArgValue[2], sArgValue[3], sArgValue[4], atoi(sArgValue[5]));
			break;

		case ML_SETMODEL_RES :
			if ( !ArgMap.Lookup("Result", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("Error Msg", sArgValue[1]) )
				return;
			m_pEventHandler->OnSetModel_Res(sSender, ((sArgValue[0]=="OK")? TRUE : FALSE) , sArgValue[1]);
			break;

		case ML_STARTTEST :
			if ( !ArgMap.Lookup("Jig No", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("Barcode", sArgValue[1]) )
				return;
			m_pEventHandler->OnStartTest( atoi(sArgValue[0]) , sArgValue[1]);
			break;

		case ML_STARTTEST_RES :
			if ( !ArgMap.Lookup("Jig No", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("Result", sArgValue[1]) )
				return;
			if ( !ArgMap.Lookup("Error Msg", sArgValue[2]) )
				return;
			m_pEventHandler->OnStartTest_Res(sSender, atoi(sArgValue[0]) , ((sArgValue[1]=="OK")? TRUE : FALSE), sArgValue[2]);
			break;

		case ML_PROGRESS :
			if ( !ArgMap.Lookup("Jig No", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("Percent", sArgValue[1]) )
				return;
			if ( !ArgMap.Lookup("Msg", sArgValue[2]) )
				return;
			m_pEventHandler->OnProgress(sSender, atoi(sArgValue[0]) , atoi(sArgValue[1]), sArgValue[2]);
			break;

		case ML_PROGRESS_RES :
			if ( !ArgMap.Lookup("Jig No", sArgValue[0]) )
				return;
			m_pEventHandler->OnProgress_Res( atoi(sArgValue[0]) );
			break;

		case ML_ENDTEST :
			if ( !ArgMap.Lookup("Jig No", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("Result", sArgValue[1]) )
				return;
			if ( !ArgMap.Lookup("Msg", sArgValue[2]) )
				return;
			m_pEventHandler->OnEndTest(sSender, atoi(sArgValue[0]) , ((sArgValue[1]=="PASS")? TRUE : FALSE), sArgValue[2]);
			break;

		case ML_ENDTEST_RES :
			if ( !ArgMap.Lookup("Jig No", sArgValue[0]) )
				return;
			m_pEventHandler->OnEndTest_Res( atoi(sArgValue[0]) );
			break;

		case ML_SETLOSS :
			if ( !ArgMap.Lookup("Jig No", sArgValue[0]) )
				return;
			m_pEventHandler->OnSetLoss( atoi(sArgValue[0]) );
			break;

		case ML_SETLOSS_RES :
			if ( !ArgMap.Lookup("Jig No", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("Result", sArgValue[1]) )
				return;
			m_pEventHandler->OnSetLoss_Res(sSender, atoi(sArgValue[0]), ((sArgValue[1]=="OK")? TRUE : FALSE) );
			break;

		case ML_SETSYSTEM :
			m_pEventHandler->OnSetSystem();
			break;

		case ML_SETSYSTEM_RES :
			if ( !ArgMap.Lookup("Result", sArgValue[0]) )
				return;
			m_pEventHandler->OnSetSystem_Res(sSender, ((sArgValue[0]=="OK")? TRUE : FALSE) );
			break;

		case ML_PROGRAMCHECK :
			m_pEventHandler->OnProgramCheck();
			break;

		case ML_PROGRAMCHECK_RES :
			m_pEventHandler->OnProgramCheck_Res(sSender);
			break;

		case ML_GETMODEL :
			m_pEventHandler->OnGetModel(sSender);
			break;

		case ML_INSTRUMENTINFO :
			if ( !ArgMap.Lookup("Name1", sArgValue[0]) )
				return;
			if ( !ArgMap.Lookup("Addr1", sArgValue[1]) )
				return;
			if ( !ArgMap.Lookup("Name2", sArgValue[2]) )
				return;
			if ( !ArgMap.Lookup("Addr2", sArgValue[3]) )
				return;
			if ( !ArgMap.Lookup("Name3", sArgValue[4]) )
				return;
			if ( !ArgMap.Lookup("Addr3", sArgValue[5]) )
				return;
			if ( !ArgMap.Lookup("Name4", sArgValue[6]) )
				return;
			if ( !ArgMap.Lookup("Addr4", sArgValue[7]) )
				return;
			if ( !ArgMap.Lookup("Name5", sArgValue[8]) )
				return;
			if ( !ArgMap.Lookup("Addr5", sArgValue[9]) )
				return;
			if ( !ArgMap.Lookup("Name6", sArgValue[10]) )
				return;
			if ( !ArgMap.Lookup("Addr6", sArgValue[11]) )
				return;
			if ( !ArgMap.Lookup("Name7", sArgValue[12]) )
				return;
			if ( !ArgMap.Lookup("Addr7", sArgValue[13]) )
				return;
			for ( int i = 0; i < 14; i++ )
			{
				if ( sArgValue[i] == "NULL" ) sArgValue[i] = "";
			}

			m_pEventHandler->OnInstrumentInfo(sSender, sArgValue[0], sArgValue[1], sArgValue[2], sArgValue[3], sArgValue[4], sArgValue[5], sArgValue[6], sArgValue[7], sArgValue[8], sArgValue[9], sArgValue[10], sArgValue[11], sArgValue[12], sArgValue[13]);
			break;
	}

	ArgMap.RemoveAll();
}

void CIPCHandler::OnIPCConnect(BOOL bIsServer)
{
	if ( !bIsServer )
	{
		SendIdentity(m_sClientName, m_sSWVersion);
	}

	m_pEventHandler->OnIPCConnect(bIsServer);
}

void CIPCHandler::OnIPCDisconnect(BOOL bIsServer, CString sClientName)
{
	m_pEventHandler->OnIPCDisconnect(bIsServer, sClientName);
}
