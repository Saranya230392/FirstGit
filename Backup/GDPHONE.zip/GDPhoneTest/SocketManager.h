// SocketManager.h: interface for the CSocketManager class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SOCKETMANAGER_H__D64E162F_E107_4C73_8E5A_BFCD6508480D__INCLUDED_)
#define AFX_SOCKETMANAGER_H__D64E162F_E107_4C73_8E5A_BFCD6508480D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxmt.h>
#include <afxsock.h>		// MFC socket extensions

#define SERVER_PORT 2500
#define CLIENT_LOW_PORT 2001
#define CLIENT_HI_PORT 2020
#define LOOPBACK_IP "127.0.0.1"

#define THREAD_SHUTDOWN_WAITTIME 10000

class CIPCHandler;
class CIPCSocket;

class CSocketManager  
{
// Attribute
protected :
	BOOL m_bIsServer;
	static CEvent m_eventThrEnd;
	static CEvent m_eventWakeThrEnd;

public:
	static CPtrList m_UnknownClientList;
	static CMapStringToPtr m_mapClient;
	static CIPCSocket *m_pServer;
	static CWnd *m_pEventSinker;
	static CIPCHandler *m_pParent;
	static CSocket m_ListenSock;

	CString m_sClientName;
	BOOL m_bRun;
	BOOL m_bIsConnectedToServer;
	int m_nClientPort;

public:
	BOOL SendMessageToServer(CString sLabel, CMapStringToString *pArgMap);
	void OnMessage(CSocket *pSocket);
	BOOL SendMessage(CString sReceiver, CString sLabel, CMapStringToString *pArgMap);
	BOOL IsServer();
	BOOL IsRun();
	void OnConnect(CSocket *pSock, CString sIdentity = _T(""));
	void OnDisconnect(CIPCSocket *pSocket);
	static UINT ClientThread(LPVOID pParam);
	static UINT ServerThread(LPVOID pParam);
	BOOL Run(CIPCHandler *pParent, BOOL bIsServer);
	CSocketManager();
	virtual ~CSocketManager();

};

#endif // !defined(AFX_SOCKETMANAGER_H__D64E162F_E107_4C73_8E5A_BFCD6508480D__INCLUDED_)
