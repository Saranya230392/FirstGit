// Event.cpp: implementation of the CEvent class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Event.h"
#include "resource.h"
#include "GDPhoneTestDlg.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEvent::CEvent()
{

}

CEvent::~CEvent()
{

}

void CEvent::SendSpyMessage(CString sMsg, BOOL bShow)
{
}

void CEvent::SendLogMessage(CString sMsg)
{
	CString sDisplay(_T(""));
	SYSTEMTIME sysTime;
	GetLocalTime(&sysTime);
	sDisplay.Format("[%02d:%02d:%02d:%03d] %s", sysTime.wHour, sysTime.wMinute, sysTime.wSecond, sysTime.wMilliseconds, sMsg);
	((CGDPhoneTestDlg *)AfxGetMainWnd())->m_listSpy.AddString(sDisplay);

}
