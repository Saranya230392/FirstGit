//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GDPhoneTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GDPHONETEST_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_COMBO_COMM_MODE             1000
#define IDC_BUTTON_INIT_PHONE           1001
#define IDC_BUTTON_EXIT_PHONE           1002
#define IDC_COMBO_COMPORT               1003
#define IDC_BUTTON_OPEN                 1004
#define IDC_COMBO_BAUDRATE              1005
#define IDC_BUTTON_CLOSE                1006
#define IDC_EDIT_DRIVER_NAME            1007
#define IDC_BUTTON_USB_OPEN             1008
#define IDC_EDIT_PARAMETER              1009
#define IDC_RADIO_4                     1010
#define IDC_RADIO_5                     1011
#define IDC_RADIO_6                     1012
#define IDC_RADIO_7                     1013
#define IDC_RADIO_8                     1014
#define IDC_RADIO_9                     1015
#define IDC_RADIO_10                    1016
#define IDC_RADIO_11                    1017
#define IDC_RADIO_12                    1018
#define IDC_RADIO_13                    1019
#define IDC_RADIO_14                    1020
#define IDC_RADIO_15                    1021
#define IDC_RADIO_16                    1022
#define IDC_RADIO_17                    1023
#define IDC_RADIO_18                    1024
#define IDC_RADIO_19                    1025
#define IDC_BUTTON_RUN                  1026
#define IDC_RESULT_LIST                 1027
#define IDC_CLEAR                       1028
#define IDC_CHECK_CDMA                  1029
#define IDC_EDIT_PARAMETER2             1030
#define IDC_BUTTON_SEARCH               1031
#define IDC_RADIO_20                    1032
#define IDC_RADIO_21                    1033
#define IDC_RADIO_22                    1034
#define IDC_RADIO_23                    1035
#define IDC_RADIO_24                    1036
#define IDC_RADIO_25                    1037
#define IDC_SPY_LIST                    1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
