// SocketManager.cpp: implementation of the CSocketManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "SocketManager.h"
#include "IPCSocket.h"
#include "SocketThread.h"
#include "IPCHandler.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CPtrList CSocketManager::m_UnknownClientList;
CMapStringToPtr CSocketManager::m_mapClient;
CWnd * CSocketManager::m_pEventSinker = NULL;
CIPCHandler *CSocketManager::m_pParent = NULL;
CIPCSocket *CSocketManager::m_pServer = NULL;
CSocket CSocketManager::m_ListenSock;


CEvent CSocketManager::m_eventThrEnd;
CEvent CSocketManager::m_eventWakeThrEnd;

CSocketManager::CSocketManager()
{
	m_bIsServer = FALSE;
	m_sClientName = _T("");
	m_bRun = FALSE;
	m_bIsConnectedToServer = FALSE;
	m_pServer = NULL;
	m_nClientPort = CLIENT_LOW_PORT;
}

CSocketManager::~CSocketManager()
{
	m_bRun = FALSE;
	if ( m_bIsServer ) 
		m_ListenSock.CancelBlockingCall();

	Sleep(1000);

	DWORD dwRet = WaitForSingleObject(m_eventThrEnd.m_hObject, THREAD_SHUTDOWN_WAITTIME);

	CString sKey;
	CIPCSocket *pSocket = NULL;
	POSITION pos = NULL;

	if ( m_bIsServer )
	{
		for ( pos = m_mapClient.GetStartPosition(); pos != NULL; )
		{
			m_mapClient.GetNextAssoc(pos, sKey, (LPVOID &)pSocket);
			pSocket->m_pSockThread->PostThreadMessage(WM_QUIT,0,0);
		}
		Sleep(500);

		m_mapClient.RemoveAll();
	}
	else
	{
		if ( m_pServer )
		{
			m_pServer->m_pSockThread->PostThreadMessage(WM_QUIT,0,0);
			m_pServer = NULL;
			Sleep(500);
		}
	}
}

BOOL CSocketManager::Run(CIPCHandler *pParent, BOOL bIsServer)
{
	if (!AfxSocketInit())
	{
		AfxMessageBox("Windows ���� �ʱ�ȭ�� �����Ͽ����ϴ�.");
		return FALSE;
	}

	m_pParent = pParent;
	m_bIsServer = bIsServer;
	
	m_bRun = TRUE;

	if ( bIsServer )
	{
		AfxBeginThread((AFX_THREADPROC)ServerThread, this);
	}
	else
	{
		AfxBeginThread((AFX_THREADPROC)ClientThread, this);
	}

	return TRUE;
}

UINT CSocketManager::ServerThread(LPVOID pParam)
{
	CSocketManager *pSockMan = (CSocketManager *)pParam;

	CSocket TempSock;
	m_ListenSock.Create(SERVER_PORT);
	m_ListenSock.Bind(SERVER_PORT);

	while ( pSockMan->m_bRun )
	{
		if ( m_ListenSock.Listen() )
		{
			if ( !m_ListenSock.Accept(TempSock) )
				continue;

			CSocketThread *pThread = (CSocketThread *)AfxBeginThread(RUNTIME_CLASS(CSocketThread),
																	   THREAD_PRIORITY_NORMAL,
																	   0,
																	   CREATE_SUSPENDED);
			if ( pThread == NULL )
			{
				AfxMessageBox("Socket Thread Creation Fail. Can't accept client connection!");
				TempSock.Close();
			}

			SOCKET hSocket = TempSock.Detach();
			pThread->m_hSocket = hSocket;
			pThread->m_pSockMan = pSockMan;
			pThread->m_bIsServer = pSockMan->m_bIsServer;
			pThread->ResumeThread();

			m_pParent->OnIPCConnect(TRUE);
		}	
		Sleep(100);
	}

	m_ListenSock.Close();

	m_eventThrEnd.SetEvent();

	AfxEndThread(0, TRUE);

	return 0;
}

UINT CSocketManager::ClientThread(LPVOID pParam)
{
	CSocketManager *pSockMan = (CSocketManager *)pParam;

	CIPCSocket *pClientSock = NULL;

	pSockMan->m_bIsConnectedToServer = FALSE;

	while ( pSockMan->m_bRun )
	{
		if ( !pSockMan->m_bIsConnectedToServer )
		{
			pClientSock = new CIPCSocket;

			if ( ! pClientSock->Create(pSockMan->m_nClientPort) )
			{
				delete pClientSock;
				++pSockMan->m_nClientPort;	

				if ( pSockMan->m_nClientPort > CLIENT_HI_PORT )
					pSockMan->m_nClientPort = CLIENT_LOW_PORT;

				continue;
			}
			if ( ! pClientSock->Connect(LOOPBACK_IP, SERVER_PORT) )
			{
				delete pClientSock;
				++pSockMan->m_nClientPort;

				if ( pSockMan->m_nClientPort > CLIENT_HI_PORT )
					pSockMan->m_nClientPort = CLIENT_LOW_PORT;

				continue;
			}

			pSockMan->m_bIsConnectedToServer = TRUE;

			CSocketThread *pThread = (CSocketThread *)AfxBeginThread(RUNTIME_CLASS(CSocketThread),
																	   THREAD_PRIORITY_NORMAL,
																	   0,
																	   CREATE_SUSPENDED);
			if ( pThread == NULL )
			{
				AfxMessageBox("Socket Thread Creation Fail. Can't accept client connection!");
				pClientSock->Close();
				delete pClientSock;
			}

			SOCKET hSocket = pClientSock->Detach();
			delete pClientSock;

			pThread->m_hSocket = hSocket;
			pThread->m_pSockMan = pSockMan;
			pThread->m_bIsServer = pSockMan->m_bIsServer;
			pThread->ResumeThread();

			Sleep(2000);

			m_pParent->OnIPCConnect(FALSE);
		}

		Sleep(500);
	}

	m_eventThrEnd.SetEvent();

	AfxEndThread(0, TRUE);

	return 0;
}

void CSocketManager::OnConnect(CSocket *pSock, CString sIdentity)
{
	if ( m_bIsServer )
	{
		if ( sIdentity.IsEmpty() )
			return;

		CSocket *pTempSock = NULL;

		POSITION pos = NULL;
		POSITION prevPos = NULL;
		for ( pos = m_UnknownClientList.GetHeadPosition() ; pos != NULL; )
		{
			prevPos = pos;
			pTempSock = (CSocket *)m_UnknownClientList.GetNext(pos);
			if ( pSock != pTempSock )
				continue;
			m_mapClient.SetAt(sIdentity, (LPVOID)pSock);
			m_UnknownClientList.RemoveAt(prevPos);
			break;
		}
	}
	else
	{
	}
}

void CSocketManager::OnDisconnect(CIPCSocket *pSocket)
{
	if ( m_bIsServer )
	{

		CString sKey(_T(""));
		CIPCSocket *pTempSocket;

		POSITION pos = NULL;
		POSITION prevPos = NULL;
		for ( pos = m_mapClient.GetStartPosition() ; pos != NULL; )
		{
			prevPos = pos;
			m_mapClient.GetNextAssoc(pos, sKey, (LPVOID &)pTempSocket);

			if ( pSocket != pTempSocket )
				continue;

			pSocket->Close();
			pSocket->m_pSockThread->PostThreadMessage(WM_QUIT,0,0);
			m_mapClient.RemoveKey(sKey);

			Sleep(500);
			break;
		}
		m_pParent->OnIPCDisconnect(TRUE, sKey);
	}
	else
	{
		if ( m_pServer )
		{
			m_pServer->m_pSockThread->PostThreadMessage(WM_QUIT,0,0);
			m_pServer = NULL;
			Sleep(500);
		}

		m_pParent->OnIPCDisconnect(FALSE);
		m_bIsConnectedToServer = FALSE;
	}

}

BOOL CSocketManager::IsRun()
{
	return m_bRun;
}

BOOL CSocketManager::IsServer()
{
	return m_bIsServer;
}

BOOL CSocketManager::SendMessage(CString sReceiver, CString sLabel, CMapStringToString *pArgMap)
{
	if ( sReceiver.IsEmpty() || sLabel.IsEmpty() || (pArgMap == NULL) )
		return FALSE;

	CIPCSocket *pSocket = NULL;

	if ( !m_mapClient.Lookup(sReceiver, (LPVOID &)pSocket) || pSocket == NULL )
		return FALSE;	

	pSocket->m_pSockThread->PushSendMessage(sLabel, pArgMap);
	pSocket->m_pSockThread->PostThreadMessage(WM_SOCKET_SEND, 0, 0);	// Trigger OnIdle Function

	return TRUE;
}

BOOL CSocketManager::SendMessageToServer(CString sLabel, CMapStringToString *pArgMap)
{
	if ( sLabel.IsEmpty() || (pArgMap == NULL) )
		return FALSE;

	if ( m_pServer == NULL )
		return FALSE;

	m_pServer->m_pSockThread->PushSendMessage(sLabel, pArgMap);
	m_pServer->m_pSockThread->PostThreadMessage(WM_SOCKET_SEND, 0, 0);	// Trigger OnIdle Function

	return TRUE;
}

void CSocketManager::OnMessage(CSocket *pSocket)
{
	CString sDisplay(_T("\n"));

	CString sLabel(_T(""));
	int nArgCount = 0;
	CString sArgName(_T("")), sArgValue(_T(""));

	CSocketFile SockFile(pSocket);
	CArchive ar(&SockFile, CArchive::load);

	ar >> sLabel;
	ar >> nArgCount;

	sDisplay += sLabel + ">";

	CMapStringToString ArgMap;

	for ( int i = 0; i < nArgCount; i++ )
	{
		ar >> sArgName;
		ar >> sArgValue;
		ArgMap.SetAt( sArgName, sArgValue );

		sDisplay += sArgValue + ",";
	}	

	ar.Close();

	sDisplay += "\n";

	TRACE(sDisplay);

	CString sSWName(_T("")), sResult(_T(""));
	if ( sLabel == "Identity" && ArgMap.Lookup("SW Name", sSWName) )
	{
		OnConnect(pSocket, sSWName);
	}
	else if ( sLabel == "Identity Res" && ArgMap.Lookup("Result", sResult) && sResult == "OK" )
	{
		OnConnect(pSocket);
	}

	CString sSender(_T(""));
	CString sKey(_T(""));
	CIPCSocket *pTempSocket = NULL;

	if ( m_bIsServer )
	{
		for ( POSITION pos = m_mapClient.GetStartPosition() ; pos != NULL; )
		{
			m_mapClient.GetNextAssoc(pos, sKey, (LPVOID &)pTempSocket);

			if ( pSocket != pTempSocket )
				continue;

			sSender = sKey;
			break;
		}
	}

	m_pParent->ProcessMessage(sSender, sLabel, ArgMap);
}
