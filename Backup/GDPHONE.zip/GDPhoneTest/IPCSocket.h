#if !defined(AFX_IPCSOCKET_H__1D1B1EA2_514B_4EF0_84E7_FAD081669F4D__INCLUDED_)
#define AFX_IPCSOCKET_H__1D1B1EA2_514B_4EF0_84E7_FAD081669F4D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// IPCSocket.h : header file
//
#include <afxsock.h>		// MFC socket extensions

class CSocketThread;
class CSocketManager;

/////////////////////////////////////////////////////////////////////////////
// CIPCSocket command target

class CIPCSocket : public CSocket
{
// Attributes
public:
	CSocketManager *m_pParent;
	CSocketThread *m_pSockThread;

// Operations
public:
	CIPCSocket();
	virtual ~CIPCSocket();

// Overrides
public:
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CIPCSocket)
	public:
	virtual void OnReceive(int nErrorCode);
	virtual void OnClose(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CIPCSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_IPCSOCKET_H__1D1B1EA2_514B_4EF0_84E7_FAD081669F4D__INCLUDED_)
