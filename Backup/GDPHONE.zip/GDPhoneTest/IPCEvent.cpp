// IPCEvent.cpp: implementation of the CIPCEvent class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#include "IPCEvent.h"
#include "IPCHandler.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CIPCEvent::CIPCEvent()
{
	m_pParent = NULL;
}

CIPCEvent::~CIPCEvent()
{

}

//=============================
//    For Common Event
//=============================

void CIPCEvent::OnIPCConnect(BOOL bIsServer)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent
}

void CIPCEvent::OnIPCDisconnect(BOOL bIsServer, CString sClientName)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent
}


//=============================
//    For Celmelt Side Event
//=============================

void CIPCEvent::OnIdentity(CString sProgramName, CString sSWVersion)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

	m_pParent->SendIdentity_Res(sProgramName, TRUE);
}

void CIPCEvent::OnSetModel_Res(CString sSender, BOOL bResult, CString sMsg)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnStartTest_Res(CString sSender, int nJigNo, BOOL bResult, CString sMsg)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnProgress(CString sSender, int nJigNo, int nPercent, CString sMsg)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnEndTest(CString sSender, int nJigNo, BOOL bResult, CString sMsg)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnSetLoss_Res(CString sSender, int nJigNo, BOOL bResult)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnSetSystem_Res(CString sSender, int nJigNo)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnProgramCheck_Res(CString sSender)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

//=================================
// For Manufacturing SW Side Event
//=================================

void CIPCEvent::OnIdentity_Res(BOOL bResult)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnSetModel(CString sModel, CString sBuyer, CString sWorkOrder, CString sColor, CString sCommType, int nBaudrate)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent
	CString strLog;
	strLog.Format("%s %s %s %s %s",sModel,sBuyer, sWorkOrder,sColor,sCommType);
	AfxMessageBox(strLog);

}

void CIPCEvent::OnStartTest(int nJigNo, CString sBarcode)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent
	CString strLog;
	strLog.Format("%d %s",nJigNo,sBarcode);
	AfxMessageBox(strLog);

}

void CIPCEvent::OnProgress_Res(int nJigNo)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnEndTest_Res(int nJigNo)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnSetLoss(int nJigNo)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnSetSystem()
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::OnProgramCheck()
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent

}

void CIPCEvent::SetParent(CIPCHandler *pParent)
{
	m_pParent = pParent;
}

void CIPCEvent::OnGetModel(CString sSender)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent
}

void CIPCEvent::OnInstrumentInfo(CString sSender, CString sName1, CString sAddr1, CString sName2, CString sAddr2, CString sName3, CString sAddr3, CString sName4, CString sAdder4, CString sName5, CString sAddr5, CString sName6, CString sAddr6, CString sName7, CString sAddr7)
{
	// You can add code here to treat this event or override this virtual function in Your derived class from CIPCEvent
}
