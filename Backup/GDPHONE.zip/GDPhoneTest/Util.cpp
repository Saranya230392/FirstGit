// Util.cpp: implementation of the CUtil class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Util.h"
#include "Registry.h"
#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CUtil::CUtil()
{

}

CUtil::~CUtil()
{

}

CString CUtil::MakeXmlFileName(CString sModelName, CString sBuyerName)
{
	CRegistry Registry;
	CString sRootPath = Registry.GetValue("path");
	CString sModelPath = Registry.GetValue("ModelPath");

	if ( sRootPath.IsEmpty() || sRootPath == "" ||
		 sModelPath.IsEmpty() || sModelPath == "" )
		 return (_T(""));

	CString sXmlFilePath = sRootPath + sModelPath + _T("\\") + sModelName + _T("\\") + sBuyerName + _T("\\");
	CString sXmlFileName = CString("RD_") + sModelName + _T(".xml");

	return ( sXmlFilePath + sXmlFileName );
}

CString CUtil::GetBinPath()
{
	CRegistry Registry;
	CString sRootPath = Registry.GetValue("path");
	CString sBinPath = Registry.GetValue("BinPath");

	if ( sRootPath.IsEmpty() || sRootPath == "" ||
		 sBinPath.IsEmpty() || sBinPath == "" )
		 return (_T(""));

	return ( sRootPath + sBinPath );
}

CString CUtil::GetEnvPath()
{
	CRegistry Registry;
	CString sRootPath = Registry.GetValue("path");
	CString sEnvPath = Registry.GetValue("EnvPath");

	if ( sRootPath.IsEmpty() || sRootPath == "" ||
		 sEnvPath.IsEmpty() || sEnvPath == "" )
		 return (_T(""));

	return ( sRootPath + sEnvPath );
}

CString CUtil::GetLogPath()
{
	CRegistry Registry;
	CString sRootPath = Registry.GetValue("path");
	CString sLogPath = Registry.GetValue("LogPath");

	if ( sRootPath.IsEmpty() || sRootPath == "" ||
		 sLogPath.IsEmpty() || sLogPath == "" )
		 return (_T(""));

	return ( sRootPath + sLogPath );
}

CString CUtil::MakeLastVersionPath(CString sFilePath)
{
	if ( sFilePath.IsEmpty() || sFilePath == "" )
		return sFilePath;

	int nPos = sFilePath.Find(".");
	if ( nPos < 0 )
		return sFilePath;

	CString sExtension = sFilePath.Mid(nPos+1);
	sExtension.MakeUpper();

	CString sFindPath = sFilePath;
#ifdef _DEBUG
	if ( sExtension == "DLL" )	// Dll������ Release Mode�� Debug Mode�� �̸��� �ٸ���.
		sFindPath.Replace(".","_??D.");
	else	// XML, INI....
		sFindPath.Replace(".","_??.");
#else
	sFindPath.Replace(".","_??.");
#endif

	CFileFind FileFind;
	BOOL bRet = FileFind.FindFile(sFindPath);
	if ( !bRet )
		return sFilePath;

	CString sCurrentFileName(_T(""));
	CString sLastFilePath(_T(""));
	int nCurrentVersion = 0;
	int nLastVersion = 0;

	while ( bRet )
	{
		bRet = FileFind.FindNextFile();
		sCurrentFileName = FileFind.GetFileName();

		nPos = sCurrentFileName.Find(".");
		if ( nPos < 0 ) 
			return sFilePath;

#ifdef _DEBUG
		if ( sExtension == "DLL" )	// Dll������ Release Mode�� Debug Mode�� �̸��� �ٸ���.
			nCurrentVersion = atoi( sCurrentFileName.Mid(nPos-3, 2) );
		else	// XML, INI....
			nCurrentVersion = atoi( sCurrentFileName.Mid(nPos-2, 2) );
#else
		nCurrentVersion = atoi( sCurrentFileName.Mid(nPos-2, 2) );
#endif
		if ( nCurrentVersion > nLastVersion )
		{
			nLastVersion = nCurrentVersion;
			sLastFilePath = FileFind.GetFilePath();
		}				
	}

	if ( sCurrentFileName.GetLength() > 0 )
		return sLastFilePath;
	else
		return sFilePath;
}

ULONG CUtil::GetDateFromReportFile(CString sFileName)
{
	if ( sFileName.GetLength() < 10 )
		return 0;

	CString sDate = sFileName.Mid(sFileName.GetLength()-10, 6);
	CString sDateHi = sDate.Left(3);
	CString sDateLo = sDate.Right(3);

	int nDateHi = atoi(sDateHi);
	int nDateLo = atoi(sDateLo);

	ULONG unDate = (ULONG)nDateHi * 1000 + (ULONG)nDateLo;

	return unDate;
}

ULONG CUtil::GetDateFromLogFile(CString sFileName)
{
	if ( sFileName.GetLength() < 14 )
		return 0;

	CString sPureFileName = sFileName.Mid( sFileName.ReverseFind('\\') + 1 );

	CString sYear = sPureFileName.Left(4);
	CString sMonth = sPureFileName.Mid(5,2);
	CString sDay = sPureFileName.Mid(8,2);

	int nYear = atoi(sYear);
	int nMonth = atoi(sMonth);
	int nDay = atoi(sDay);

	ULONG unDate = (ULONG)nDay + (ULONG)nMonth * 100 + (ULONG)(nYear%100) * 10000;

	return unDate;
}

ULONG CUtil::GetDateNWeekAgo(SYSTEMTIME &CurrentTime, int nWeek)
{
	int nDay = 0;
	int nMonth = 0;
	int nYear = 0;

	if ( ( nDay = CurrentTime.wDay - nWeek * 7 ) <= 0 )
	{
		nDay += 30;
		nMonth = CurrentTime.wMonth - 1;
		if ( nMonth <= 0 )
		{
			nMonth += 12;
			nYear = CurrentTime.wYear - 1;
		}
		else
		{
			nYear = CurrentTime.wYear;
		}
	}
	else
	{
		nMonth = CurrentTime.wMonth;
		nYear = CurrentTime.wYear;
	}

	// Calculate the date until one centennial, because of file-name policy.
	ULONG unResultDate = (ULONG)nDay + (ULONG)nMonth * 100 + (ULONG)(nYear%100) * 10000;

	return unResultDate;
}

CString CUtil::GetValidPID(CString sOrigin)
{
	int nNullCharPos = sOrigin.Find('\0');
	if ( nNullCharPos >=0 && nNullCharPos < sOrigin.GetLength() )
		return sOrigin.Left(nNullCharPos);
	else
		return sOrigin;
}

