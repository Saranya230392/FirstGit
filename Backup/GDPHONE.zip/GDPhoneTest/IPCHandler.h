// IPCHandler.h: interface for the CIPCHandler class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_IPCHANDLER_H__3D318011_BCF2_4F87_B3F1_75CD579D060C__INCLUDED_)
#define AFX_IPCHANDLER_H__3D318011_BCF2_4F87_B3F1_75CD579D060C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "SocketManager.h"
#include "IPCEvent.h"

class CIPCHandler  
{
// Attribute
protected:
	CSocketManager m_SocketManager;
	CString m_sClientName;
	CString m_sSWVersion;
	CIPCEvent *m_pEventHandler;
	BOOL m_bUseDefaultEventHandler;
	
public:
	void OnIPCDisconnect(BOOL bIsServer, CString sClientName = _T(""));
	void OnIPCConnect(BOOL bIsServer);
	void ProcessMessage(CString sSender, CString sLabel, CMapStringToString &ArgMap);

	// Methods For Celmelt
	void SendProgramCheck(CString sReceiver);
	void SendSetSystem(CString sReceiver);
	void SendSetLoss(CString sReceiver, int nJigNo);
	void SendEndTest_Res(CString sReceiver, int nJigNo);
	void SendProgress_Res(CString sReceiver, int nJigNo);
	void SendStartTest(CString sReceiver, int nJigNo, CString sBarcode);
	void SendSetModel(CString sReceiver, CString sModel, CString sBuyer, CString sWorkOrder, CString sColor, CString sCommType, int  nBaudrate);
	void SendIdentity_Res(CString sReceiver, BOOL bResult);

	// Methods For Manufacturing SW
	void SendProgramCheck_Res();
	void SendSetSystem_Res(BOOL bResult);
	void SendSetLoss_Res(int nJigNo, BOOL bResult);
	void SendEndTest(int nJigNo, BOOL bResult, CString sMsg);
	void SendProgress(int nJigNo, int nPercent, CString sMsg);
	void SendStartTest_Res(int nJigNo, BOOL  bResult, CString sErrorMsg);
	void SendSetModel_Res(BOOL bResult, CString sMsg);
	void SendIdentity(CString sName, CString sSWVersion);
	void SendGetModel();
	void SendInstrumentInfo(CString sName1="", CString sAddr1="", CString sName2="", CString sAddr2="", CString sName3="", CString sAddr3="", CString sName4="", CString sAddr4="", CString sName5="", CString sAddr5="", CString sName6="", CString sAddr6="", CString sName7="", CString sAddr7="");


	BOOL RunClient(CString sName, CString sSWVersion, CIPCEvent *pEventHandler = NULL);
	BOOL RunServer(CIPCEvent *pEventHandler = NULL);
	CIPCHandler();
	virtual ~CIPCHandler();

};

#endif // !defined(AFX_IPCHANDLER_H__3D318011_BCF2_4F87_B3F1_75CD579D060C__INCLUDED_)
