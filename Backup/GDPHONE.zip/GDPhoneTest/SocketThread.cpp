// SocketThread.cpp : implementation file
//

#include "stdafx.h"

#include "SocketThread.h"
#include "SocketManager.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSocketThread

IMPLEMENT_DYNCREATE(CSocketThread, CWinThread)

CSocketThread::CSocketThread()
{
	m_bIsServer = FALSE;
}

CSocketThread::~CSocketThread()
{
}

BOOL CSocketThread::InitInstance()
{
	// TODO:  perform and per-thread initialization here
	BOOL bAttachResult = FALSE;

	bAttachResult = m_Socket.Attach(m_hSocket);
	m_Socket.m_pParent = m_pSockMan;
	m_Socket.m_pSockThread = this;

	if ( m_bIsServer )
		m_pSockMan->m_UnknownClientList.AddTail((LPVOID)&m_Socket);
	else
		m_pSockMan->m_pServer = &m_Socket;
	
	return TRUE;
}

int CSocketThread::ExitInstance()
{
	// TODO:  perform any per-thread cleanup here
	LPSOCKET_MSG pItem = NULL;

	if ( m_queueMsg.GetCount() > 0 )
	{
		for ( POSITION pos = m_queueMsg.GetHeadPosition(); pos != NULL; )
		{
			pItem = (LPSOCKET_MSG)m_queueMsg.GetNext(pos);
			delete pItem;
		}
		m_queueMsg.RemoveAll();
	}

	return CWinThread::ExitInstance();
}

BEGIN_MESSAGE_MAP(CSocketThread, CWinThread)
	//{{AFX_MSG_MAP(CSocketThread)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSocketThread message handlers


void CSocketThread::PushSendMessage(CString sLabel, CMapStringToString *pArgMap)
{
	LPSOCKET_MSG pItem = new SOCKET_MSG(sLabel, pArgMap);

	m_csMsg.Lock(5000);
	m_queueMsg.AddTail(pItem);
	m_csMsg.Unlock();
}

BOOL CSocketThread::ProcessSendMessage()
{
	LPSOCKET_MSG pItem = NULL;

	if ( m_queueMsg.GetCount() == 0 )
		return FALSE;

	m_csMsg.Lock(5000);
	pItem = (LPSOCKET_MSG)m_queueMsg.RemoveHead();
	m_csMsg.Unlock();

	CSocketFile SockFile(&m_Socket);
	CArchive ar(&SockFile, CArchive::store);
	ar << pItem->m_sLabel;

	ar << ( pItem->m_pArgMap->GetCount() );

	CString sKey(_T("")), sValue(_T(""));
	for ( POSITION pos = pItem->m_pArgMap->GetStartPosition(); pos != NULL; )
	{
		pItem->m_pArgMap->GetNextAssoc(pos, sKey, sValue);
		ar << sKey;
		ar << sValue;
	}

	ar.Close();

	delete pItem;

	return TRUE;
}

int CSocketThread::GetMessageCount()
{
	return m_queueMsg.GetCount();
}

BOOL CSocketThread::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if ( pMsg->message == WM_SOCKET_SEND )
	{
		ProcessSendMessage();
		return TRUE;
	}
	
	return CWinThread::PreTranslateMessage(pMsg);
}
