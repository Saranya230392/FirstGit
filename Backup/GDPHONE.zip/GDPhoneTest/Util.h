// Util.h: interface for the CUtil class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UTIL_H__BD5CFC95_7C13_4AD5_BDD9_E534E9792EC4__INCLUDED_)
#define AFX_UTIL_H__BD5CFC95_7C13_4AD5_BDD9_E534E9792EC4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CUtil : public CObject  
{
public:
	static CString GetValidPID(CString sOrigin);
	static ULONG GetDateFromLogFile(CString sFileName);
	static ULONG GetDateFromReportFile(CString sFileName);
	static ULONG GetDateNWeekAgo(SYSTEMTIME &CurrentTime, int nWeek);
	static CString GetReportPath();
	static CString MakeLastVersionPath(CString sFilePath);
	static CString MakeXmlFileName(CString sModelName, CString sBuyerName);
	static CString GetBinPath();
	static CString GetLogPath();
	static CString GetEnvPath();

	CUtil();
	virtual ~CUtil();

};

#endif // !defined(AFX_UTIL_H__BD5CFC95_7C13_4AD5_BDD9_E534E9792EC4__INCLUDED_)
