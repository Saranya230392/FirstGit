#ifndef _CAI_H
#define _CAI_H
/*===========================================================================

       IS-95   P R O T O C O L   D A T A    D E C L A R A T I O N S 

DESCRIPTION

  This file contains the data structures for messages received and
  transmitted to the base station while the mobile station is operating
  in CDMA mode and other CDMA-related constants and indicators as 
  defined in IS-95.

Copyright (c) 1990,1991,1992 by QUALCOMM, Incorporated.  All Rights Reserved.
Copyright (c) 1993,1994,1995 by QUALCOMM, Incorporated.  All Rights Reserved.
===========================================================================*/

/* <EJECT> */
/*===========================================================================

                      EDIT HISTORY FOR FILE

This section contains comments describing changes made to this file.
Notice that changes are listed in reverse chronological order.

$Header:   Z:/CMtest/CMtest(3.61)/WInclude/CAI.H-arc   1.0   Feb 14 2000 15:35:18   hyun  $
   
when       who     what, where, why
--------   ---     ----------------------------------------------------------
03/01/95   jjw     Added IS-99 and packet Service Option numbers.
01/10/95   dna     Added reject type CAI_WLL_OFF_HOOK
08/09/94   jca     Added new defines for IS-96A/IS-96 voice service options.
05/12/94   gb      Changed N1m to 13 to support high FER testing.
04/25/94   gb      Parameterised all IS95 timeouts in cai_tmo.
04/20/94   jca     Added mux1 enums and constants.  Added define for
                   Loopback service option.
12/22/93   jca     Changed message formats to IS-95 compatible.
10/29/92   jai     Added new System Parameter msg, In-Traffic System Parameter
                   message and renamed signal types for UI task.
07/23/92   jai     Modified file for lint and linking.
07/08/92   jai     Created file

===========================================================================*/

/* <EJECT> */
/*===========================================================================

                     INCLUDE FILES FOR MODULE

===========================================================================*/

//#include "comdef.h"
//#include "qw.h"

/* <EJECT> */
/*===========================================================================

                        DATA DECLARATIONS

===========================================================================*/

/*---------------------------------------------------------------------------
** Multiplex Opion 1 Data Rates
---------------------------------------------------------------------------*/

//typedef enum  
//{                 
#define  CAI_BLANK_RATE		0 //,     /* Indicates data was blanked */
#define  CAI_EIGHTH_RATE	1//,    /* Indicates rate 1/8 data    */
#define  CAI_QUARTER_RATE	2//,   /* Indicates rate 1/4 data    */
#define  CAI_HALF_RATE		3//,      /* Indicates rate 1/2 data    */
#define  CAI_FULL_RATE      4 /* Indicates rate 1   data    */
typedef WORD cai_data_rate_type;

/*---------------------------------------------------------------------------
** Types for CDMA Multiplex Option 1 Frames
---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------
** The following constants specify the number of bits used per frame at the
** various data rates.
---------------------------------------------------------------------------*/

#define  CAI_EIGHTH_RATE_BITS   16  /* Data rate 1/8:  16 bits or  2 BYTEs */
#define  CAI_QUARTER_RATE_BITS  40  /* Data rate 1/4:  40 bits or  5 BYTEs */
#define  CAI_HALF_RATE_BITS     80  /* Data rate 1/2:  80 bits or 10 BYTEs */
#define  CAI_FULL_RATE_BITS    171  /* Data rate 1  : 171 bits or 22 BYTEs */

#define  CAI_MAX_FRAME_SIZE  ((CAI_FULL_RATE_BITS + 5) / 8)
  /* Specifies the number of BYTEs required to hold the frame info bits at
     the highest data rate */

typedef WORD cai_frame_type[CAI_MAX_FRAME_SIZE];

/*-------------------------------------------------------------------------*/
/*  Sync Channel Constants                                                 */
/*-------------------------------------------------------------------------*/

#define CAI_SC_MAX_MSG_BYTES 148
  /* Max Sync Channel message length (see IS-95 Section 7.7.1.2.1) */
#define CAI_SC_MAX_SIZE (CAI_SC_MAX_MSG_BYTES * 8)
  /* Maximum number of bits in a Sync Channel Message */
#define CAI_SC_CRC_SIZE  30
  /* Number of bits in a Sync Channel CRC */
#define CAI_SC_LGTH_SIZE 8
  /* Number of bits in the length field for a Sync Channel message */
#define CAI_SC_BODY_SIZE (CAI_SC_MAX_SIZE - CAI_SC_CRC_SIZE - \
                             CAI_SC_LGTH_SIZE)
  /* Maximum number of bits in the body of a Sync Channel message */

#define CAI_SC_EXT_SIZE  (CAI_SC_MAX_MSG_BYTES - 1)
  /* Number of BYTEs required for a Sync Channel Message body and CRC 
     but not the length BYTE  */

/*-------------------------------------------------------------------------*/
/* Paging Channel constants                                                */
/*-------------------------------------------------------------------------*/

#define CAI_PC_MAX_MSG_BYTES 148
  /* Maximum Paging Channel message length (see IS-95 Section 7.7.2.2.1) */
#define CAI_PC_MAX_SIZE (CAI_PC_MAX_MSG_BYTES * 8)
  /* Maximum number of bits in a Paging Channel message */
#define CAI_PC_CRC_SIZE 30
  /* Number of bits in a Paging Channel CRC */
#define CAI_PC_LGTH_SIZE 8
  /* Number of bits in the length field for a Paging Channel message */
#define CAI_PC_BODY_SIZE  (CAI_PC_MAX_SIZE - CAI_PC_CRC_SIZE -         \
                             CAI_PC_LGTH_SIZE) 
  /* Maximum number of bits in the body of a Paging Channel message */

#define CAI_PC_EXT_SIZE (CAI_PC_MAX_MSG_BYTES - 1) 
  /* Number of BYTEs required for the Paging Channel message body and CRC
     but not the length BYTE */

#define PAGECHN_MAX( x ) \
        (CAI_PC_BODY_SIZE - sizeof( x##_fix_type )) / sizeof( x##_var_type )
  /* Macro to calculate maximum number of variable types that can occur
     in a Paging Channel message */

/*-------------------------------------------------------------------------*/
/* Traffic Channel constants                                               */
/*-------------------------------------------------------------------------*/

#define CAI_FWD_TC_MAX_MSG_BYTES 148
  /* Max Forward Traffic Channel msg length (see IS-95 Section 7.7.3.2.1) */

#define CAI_REV_TC_MAX_MSG_BYTES 255
  /* Max Reverse Traffic Channel msg length (see IS-95 Section 6.7.2.2) */

#define CAI_FWD_TC_MSG_SIZE (CAI_FWD_TC_MAX_MSG_BYTES * 8)
   /* Maximum number of bits in a Forward Traffic Channel Message */

#define CAI_REV_TC_MSG_SIZE (CAI_REV_TC_MAX_MSG_BYTES * 8)
   /* Maximum number of bits in a Reverse Traffic Channel Message */

#define CAI_TC_CRC_SIZE 16
   /* Number of bits in a Forward or Reverse Traffic Channel Message CRC */

#define CAI_TC_LGTH_SIZE 8
   /* Number of bits in a Forward or Reverse Traffic Channel Message
      length field */

#define CAI_FWD_TC_MSG_BODY_SIZE (CAI_FWD_TC_MSG_SIZE -               \
                                    CAI_TC_CRC_SIZE -                 \
                                      CAI_TC_LGTH_SIZE)
  /* Max number of bits in the body of a Foward Traffic Channel message */

#define CAI_REV_TC_MSG_BODY_SIZE (CAI_REV_TC_MSG_SIZE -                \
                                    CAI_TC_CRC_SIZE -                  \
                                      CAI_TC_LGTH_SIZE)
  /* Max number of bits in the body of a Reverse Traffic Channel message */

#define CAI_FWD_TC_EXT_SIZE (CAI_FWD_TC_MAX_MSG_BYTES - 1) 
  /* Number of BYTEs required for the Forward Traffic Channel message body
     and CRC but not the length BYTE */

#define CAI_REV_TC_EXT_SIZE (CAI_REV_TC_MAX_MSG_BYTES - 1) 
  /* Number of BYTEs required for the Reverse Traffic Channel message body
     and CRC but not the length BYTE */

#define TC_FWD_MAX( x )  (CAI_FWD_TC_MSG_BODY_SIZE -   \
                            sizeof( x##_fix_type )) /  \
                              sizeof( x##_var_type )
  /* Macro to caluculate the maximum number of variable types that can
     occur in a Forward Traffic Channel Message */

#define TC_REV_MAX( x )  (CAI_REV_TC_MSG_BODY_SIZE -   \
                            sizeof( x##_fix_type )) /  \
                              sizeof( x##_var_type )
  /* Macro to caluculate the maximum number of variable types that can 
     occur in a Reverse Traffic Channel Message */

/*-------------------------------------------------------------------------*/
/* Access Channel constants                                                */
/*-------------------------------------------------------------------------*/

#define CAI_AC_MAX_MSG_BYTES 110
  /* Maximum Access Channel message length (see IS-95 Section 6.7.1.2.1) */
#define CAI_AC_MAX_SIZE (CAI_AC_MAX_MSG_BYTES * 8)
  /* Maximum number of bits in an Access Channel message */
#define CAI_AC_CRC_SIZE 30
  /* Number of bits in the Access Channel message CRC */
#define CAI_AC_LGTH_SIZE 8
  /* Number of bits in the Access Channel length field */

#define CAI_AC_BODY_SIZE (CAI_AC_MAX_SIZE - CAI_AC_CRC_SIZE -  \
                            CAI_AC_LGTH_SIZE)
  /* Maximum number of bits in the body of an Access Channel message */

#define CAI_AC_EXT_SIZE  (CAI_AC_MAX_MSG_BYTES - 1)
  /* Number of BYTEs required for the Access Channel message body
     and CRC but not the length BYTE */

#define AC_MAX( x )   \
  ((CAI_AC_BODY_SIZE - sizeof( x##_fix_type )) / sizeof( x##_var_type ))
  /* Macro to calculate the maximum number of variable types that can occur
     in an Access Channel message */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                  CAI MESSAGE TYPES                                     */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* Sync Channel message */
#define CAI_SYNC_MSG  0x0001

/* Paging Channel messages */

#define CAI_SYS_PARM_MSG      0x01
  /* System Parameters Message */
#define CAI_ACC_PARM_MSG      0x02
  /* Access Parameters Message */           
#define CAI_NL_MSG            0x03
  /* Neighbor List Message */
#define CAI_CL_MSG            0x04
  /* CDMA Channel List Message */
#define CAI_SLT_PAGE_MSG      0x05
  /* Slotted Page Message */
#define CAI_PAGE_MSG          0x06
  /* Page Message */
#define CAI_PC_ORD_MSG        0x07
  /* Order Message */
#define CAI_CHN_ASN_MSG       0x08
  /* Channel Assigment Message */
#define CAI_PC_BURST_MSG      0x09
  /* Data Burst Message */
#define CAI_PC_AUTH_MSG       0x0A
  /* Authentication Challenge Message */
#define CAI_PC_SSD_UP_MSG     0x0B
  /* SSD Update Message */
#define CAI_FEATURE_MSG       0x0C
  /* Feature Notification Message */

/* Access Channel Messages  */

#define CAI_REG_MSG           0x01
  /* Registration Message */
#define CAI_AC_ORD_MSG        0x02
  /* Order Message */
#define CAI_AC_BURST_MSG      0x03
  /* Data Burst message */
#define CAI_ORIG_MSG          0x04
  /* Origination Message */
#define CAI_PAGE_RESP_MSG     0x05
  /* Page Response Message */
#define CAI_AC_AUTH_RESP_MSG  0x06
  /* Authentication Challenge Response Message */

/* Forward Traffic Channel Messages (see IS-95 Table 7.7.3.3-1) */

#define CAI_TC_FWD_ORD_MSG    0x01
  /* Order Message */
#define CAI_TC_AUTH_MSG       0x02
  /* Authentication Challenge Message */
#define CAI_ALERT_MSG         0x03
  /* Alert with Information Message */
#define CAI_TC_FWD_BURST_MSG  0x04
  /* Data Burst Message */
#define CAI_HO_DIR_MSG        0x05
  /* Handoff Direction Message */
#define CAI_FM_HO_MSG         0x06
  /* Analog Handoff Direction Message */
#define CAI_TC_SYS_PARM_MSG   0x07
  /* In-Traffic System Parameter Message */
#define CAI_TC_NLU_MSG        0x08
  /* Neighbor List Update Message */
#define CAI_SEND_BURST_MSG    0x09
  /* Send Burst DTMF Message */
#define CAI_PWR_CTL_MSG       0x0A
  /* Power Control Parameters Message */
#define CAI_RET_PARMS_MSG     0x0B
  /* Retrieve Parameters Message */
#define CAI_SET_PARMS_MSG     0x0C
  /* Set Parameters Message */
#define CAI_TC_SSD_UP_MSG     0x0D
  /* SSD Update Message */
#define CAI_FWD_FLASH_MSG     0x0E
  /* Flash with Information Message */
#define CAI_MOB_REG_MSG       0x0F
  /* Mobile Station Registered Message */

/* Reverse Traffic Channel Messages (see IS-95 Table 6.7.2.3-1) */
#define CAI_TC_REV_ORD_MSG    0x01
  /* Order Message */
#define CAI_TC_AUTH_RESP_MSG  0x02
  /* Authentication Challenge Response Message */
#define CAI_REV_FLASH_MSG     0x03
  /* Flash with Information Message */
#define CAI_TC_REV_BURST_MSG  0x04
  /* Data Burst Message */
#define CAI_PIL_STR_MSG       0x05
  /* Pilot Strength Measurement Message */
#define CAI_PWR_MSR_MSG       0x06
  /* Power Measurement Report Message */
#define CAI_SEND_DTMF_MSG     0x07
  /* Send Burst DTMF Message */
#define CAI_STATUS_MSG        0x08
  /* Status Message */
#define CAI_ORIG_C_MSG        0x09
  /* Origination Continuation Message */
#define CAI_HO_COMP_MSG       0x0A
  /* Handoff Completion Message */
#define CAI_PARM_RSP_MSG      0x0B
  /* Parameters Response message */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                     ORDER  CODES                                        */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Tables 6.7.3-1 Order and Order Qualification Codes Used on
   the Reverse Traffic Channel and the Access Channel and 7.7.4-1. Order
   and Order Qualification Codes Used on the Paging Channel and the Forward
   Traffic Channel                                                         */

/* Forward Channel Specific Order codes */

#define CAI_ABBR_ALERT_ORD    0x01
  /* Abbreviated Alert Order */
#define CAI_BS_CHAL_CONF_ORD  0x02
  /* Base Station Challenge Confirmation Order */
#define CAI_ENCRYPT_MODE_ORD  0x03
  /* Message Encryption Mode Order */
#define CAI_REORDER_ORD       0x04
  /* Reorder Order */
#define CAI_PARAM_UPDATE_ORD  0x05
  /* Parameter Update Order */
#define CAI_AUDIT_ORD         0x06
  /* Audit Order */
#define CAI_INTERCEPT_ORD     0x09
  /* Intercept Order */       
#define CAI_MAINT_ORD         0x0A
  /* Maintenance Order */
#define CAI_BS_ACK_ORD        0x10
  /* Base Station Acknowledgement Order */
#define CAI_PILOT_MEASURE_ORD 0x11
  /* Pilot Measurement Request Order */
#define CAI_LOCK_OR_MAINT_ORD 0x12
  /* Lock Until Power Cycled, Maintenance Required or Unlock Orders */
#define CAI_STATUS_ORD        0x1A
  /* Status Request Order */
#define CAI_REG_ORD           0x1B
  /* Registration Order */
#define CAI_LOCAL_CTL_ORD     0x1E
  /* Local Control Order */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* Reverse Channel Specific Order Codes */

#define CAI_BS_CHAL_ORD           0x02
  /* Base Station Challenge Order */
#define CAI_SSD_UPDATE_ORD        0x03
  /* SSD Update Confirmation/Rejection Order */
#define CAI_PARAM_UPDATE_CONF_ORD 0x05
  /* Parameter Update Confirmation Order */
#define CAI_FM_REQUEST_ORD        0x0B
  /* Request Analog Service Order */
#define CAI_MS_ACK_ORD            0x10
  /* Mobile Station Acknowledgement Order */
#define CAI_MS_CONNECT_ORD        0x18
  /* Connect Order */
#define CAI_LOCAL_CTL_RESP_ORD    0x1E
  /* Local Control Response order */
#define CAI_MS_REJECT_ORD         0x1F
  /* Mobile Station Reject Order */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* Order Codes that are used on both the Reverse and Forward Traffic
   Channels */

#define CAI_SO_REQ_ORD            0x13
  /* Service Option Request Order */
#define CAI_SO_RESP_ORD           0x14
  /* Service Option Response Order */
#define CAI_RELEASE_ORD           0x15
  /* Release Order */
#define CAI_PLC_ORD               0x17
  /* Long Code Transition Request/Response Order */
#define CAI_DTMF_ORD              0x19
  /* Continuous DTMF Tone Order */
#define CAI_SO_CTL_ORD            0x1D
  /* Service Option Control Order */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                          ORDER QUALIFIERS                               */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Tables 6.7.3-1 Order and Order Qualification Codes Used on
   the Reverse Traffic Channel and the Access Channel and 7.7.4-1. Order
   and Order Qualification Codes Used on the Paging Channel and the Forward
   Traffic Channel                                                         */

#define CAI_LUPC_MASK      0x10
  /* Mask to determine if an order is a Lock Until Power Cycle Order */
#define CAI_UNLOCK_MASK    0xFF
  /* Mask to determine if an order is an Unlock Order */
#define CAI_MAINT_REQ_MASK 0x20
  /* Mask to determine if an order is a Maintenance Required Order */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

#define CAI_REG_ACK 0x00
  /* Value of Order Qualifier if Order is a Registration Accepted Order */
#define CAI_REG_REQ 0x01
  /* Value of Order Qualifier if Order is a Registration Request Order */
#define CAI_REG_REJ 0x02
  /* Value of Order Qualifier if Order is a Registration Rejected Order */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

#define CAI_PLC_REQ_PUB 0x00
  /* Value of Order qualifier which indicates that the order is a 
     Long Code Transition Request Order (request public) */
#define CAI_PLC_REQ_PRI 0x01
  /* Value of Order qualifier which indicates that the order is a 
     Long Code Transition Request Order (request private) */
#define CAI_PLC_RSP_PUB 0x02
  /* Value of Order qualifier which indicates that the order is a 
     Long Code Transition Response Order (use public) */
#define CAI_PLC_RSP_PRI 0x03
  /* Value of Order qualifier which indicates that the order is a 
     Long Code Transition Response Order (use private) */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

#define CAI_REL_NORMAL 0x00
  /* Value of ORDQ to indicate a normal release */
#define CAI_REL_PWDN   0x01
  /* Value of Order qualifier to indicate a release with a powerdown
     indication */
#define CAI_REL_SO     0x02
  /* Value of Order qualification code to indicate that call is released
     because the requested service option is rejected */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

#define CAI_REJ_UNSP   0x01
  /* Value of Order qualifier which indicates that the order was rejected
     for an unspecified reason */

#define CAI_REJ_STATE  0x02
  /* Value of Order qualifer which indicates that the message was rejected
     due to the mobiles current state */

#define CAI_REJ_STRUCT 0x03
  /* Value of Order qualifer which indicates that the message was rejected
     because the message structure was unacceptable */

#define CAI_REJ_FIELD  0x04
  /* Value of Order qualifer which indicates that the message was rejected
     because a message field was not in the valid range */

#define CAI_REJ_CODE   0x05
  /* Value of Order qualifier which indicates that the message was rejected
     because the message type or order code was not understood. */

#define CAI_REJ_CAP    0x06
  /* Value of Order qualifier which indicates that the message was rejected
     because it requires a capability that is not supported by the mobile 
     station */

#define CAI_REJ_CFG    0x07
  /* Value of Order qualifer which indicates that the message was rejected
     because the message cannot be handled by the current mobile station
     configuration. */

#define CAI_WLL_OFF_HOOK 0xFE
  /* Used to reject a page message received while the WLL phone is off hook */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* (See IS-95 Table 7.7.4.4-1. Status Request ORDQ Values)                 */

#define CAI_ID_REQ         0x06
  /* Value of order qualifier for a Status Request order requesting
     identification information */

#define CAI_CALL_MODE_REQ  0x07
  /* Value of order qualifier for a Status Request order requesting
     call mode information */

#define CAI_TERM_INFO_REQ  0x08
  /* Value of order qualifer for a Status Request order requesting
     terminal information */

#define CAI_MIN_INFO_REQ   0x09  
  /* Value of order qualifer for a Status Request order requesting
     MIN information */

#define CAI_SEC_STATUS_REQ 0x0A
  /* Value of order qualifer for a Status Request order requesting
     security status information */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                 PAGING CHANNEL ADDRESS TYPES                            */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 7.7.2.3.1-1 Address Types                               */

#define CAI_MIN_ADDR_TYPE  0x0
  /* MIN (MIN1 and MIN2) address field type */
#define CAI_ESN_ADDR_TYPE  0x1
  /* ESN address field type */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*     PAGING AND FORWARD TRAFFIC CHANNEL INFORMATION RECORDS              */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 7.7.5-1 Information Record Types                        */

#define CAI_DISPLAY_REC     0x01
  /* Display record type */
#define CAI_CALLED_REC      0x02
  /* Called Party Number record type */
#define CAI_CALLING_REC     0x03
  /* Calling Party Number record type */
#define CAI_CONNECT_REC     0x04
  /* Connected Number record type */
#define CAI_SIGNAL_REC      0x05
  /* Signal record type */
#define CAI_MSG_WAITING_REC 0x06
  /* Message Waiting record type */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*            REVERSE TRAFFIC CHANNEL INFORMATION RECORDS                  */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.4-1 Information Record Types                        */

#define CAI_FEAT_REC        0x02
  /* Feature Indicator */
#define CAI_KEYPAD_REC      0x03
  /* Keypad Facility */
#define CAI_REV_CALLED_REC  0x04
  /* Called Party Number */
#define CAI_REV_CALLING_REC 0x05
  /* Calling Party Number */
#define CAI_ID_REC          0x06
  /* Identification */
#define CAI_CALL_MODE_REC   0x07
  /* Call Mode */
#define CAI_TERM_INFO_REC   0x08
  /* Terminal Information */
#define CAI_MIN_INFO_REC    0x09
  /* MIN Information */
#define CAI_SEC_REC         0x0A
  /* Security Status */
#define CAI_REV_CONN_REC    0x0B
  /* Connected Number */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                      REQUEST_MODE CODES                                 */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.1.3.2.4-1. REQUEST_MODE Codes                       */

#define CAI_CDMA_ONLY      0x1
  /* CDMA only */
#define CAI_ANALOG_ONLY    0x2
  /* Analog only */
#define CAI_CDMA_OR_ANALOG 0x3
  /* Either CDMA or analog */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                        NUMBER TYPES                                     */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.1.3.2.4-2. Number Types                             */

#define CAI_UNKNOWN_NUM  0x00
  /* Unknown number type */
#define CAI_INT_NUM      0x01
  /* International number */
#define CAI_NAT_NUM      0x02
  /* National number */
#define CAI_NET_SPEC_NUM 0x03
  /* Network-specific number */
#define CAI_SUB_NUM      0x04
  /* Suscriber number */
#define CAI_ABB_NUM      0x06
  /* Abbreviated number */
  
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                        NUMBER PLANS                                     */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.1.3.2.4-3. Numbering Plan Identification            */

#define CAI_UNKNOWN_PLAN 0x00
  /* Unknown number plan */
#define CAI_ISDN_PLAN    0x01
  /* ISDN/Telephony numbering plan (CCITT E.164 and CCITT E.163) */
#define CAI_DATA_PLAN    0x03
  /* Data numbering plan (CCITT X.121) */
#define CAI_TELEX_PLAN   0x04
  /* Telex numbering plan (CCITT F.69) */
#define CAI_PRIV_PLAN    0x05
  /* Private numbering plan */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                        PRESENTATION INDICATORS                          */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.4.4-1. Presentation Indicators                      */

#define CAI_ALLOW_PI     0x00
  /* Presentation allowed */
#define CAI_RES_PI       0x01
  /* Presentation restricted */
#define CAI_NOT_AVAIL_PI 0x02
  /* Number not available */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                       SCREENING INDICATORS                              */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.4.4-2. Screening Indicators                         */

#define CAI_NOT_SI  0x00
  /* User-provided, not screened */
#define CAI_PASS_SI 0x01
  /* User-provided, verified and passed */
#define CAI_FAIL_SI 0x02
  /* User-provided, verified and failed */
#define CAI_NET_SI  0x03
  /* Network-provided */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                        SIGNAL TYPES                                     */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 7.7.5.5-1. Signal Type                                  */

#define CAI_SIG_TONE  0x00
  /* Tone signal */
#define CAI_SIG_ISDN  0x01
  /* ISDN Alerting */
#define CAI_SIG_IS54B 0x02
  /* IS-54B Alerting */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                      ALERT PITCHES                                      */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 7.7.5.5-2. Alert Pitch                                  */

#define CAI_PITCH_MED  0x00
  /* Medium pitch (standard alert) */
#define CAI_PITCH_HIGH 0x01
  /* High pitch */
#define CAI_PITCH_LOW  0x02
  /* Low pitch */
#define CAI_PITCH_RSV  0x03
  /* Reserved pitch */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                          TONE SIGNALS                                   */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 7.7.5.5-3. Tone Signals (SIGNAL_TYPE = '00')            */

#define CAI_TONE_DIAL           0x00
  /* Dial tone on */
#define CAI_TONE_RING           0x01
  /* Ring back tone on */
#define CAI_TONE_INTERCEPT      0x02
  /* Intercept tone on */
#define CAI_TONE_ABBR_INTERCEPT 0x03
  /* Abbreviated intercept: alternating tones repeated for four seconds */
#define CAI_TONE_REORDER        0x04
  /* Network congestion (reorder) tone on */
#define CAI_TONE_ABBR_REORDER   0x05
  /* Abbreviated network congestion (reorder) */
#define CAI_TONE_BUSY           0x06
  /* Busy tone on */
#define CAI_TONE_CONFIRM        0x07
  /* Confirm tone on */
#define CAI_TONE_ANSWER         0x08
  /* Answer tone on */
#define CAI_TONE_CALLWAIT       0x09
  /* Call waiting tone on */
#define CAI_TONE_OFF            0x3F
  /* Tones off */

/* See IS-95 Table 7.7.5.5-4. ISDN Alerting (SIGNAL_TYPE = '01')           */

#define CAI_ISDN_NORMAL     0x00                                        
  /* Normal Alerting */
#define CAI_ISDN_INTERGROUP 0x01
  /* Intergroup Alerting */
#define CAI_ISDN_SPECIAL    0x02
  /* Special/Priority Alerting */
#define CAI_ISDN_RESERVED3  0x03
  /* Reserved (ISDN Alerting pattern 3) */
#define CAI_ISDN_PING       0x04
  /* "Ping ring": single burst of 500 ms */
#define CAI_ISDN_RESERVED5  0x05
  /* Reserved (ISDN Alerting pattern 5) */
#define CAI_ISDN_RESERVED6  0x06
  /* Reserved (ISDN Alerting pattern 6) */
#define CAI_ISDN_RESERVED7  0x07
  /* Reserved (ISDN Alerting pattern 7) */
#define CAI_ISDN_OFF        0x0F
  /* Alerting off */

/* See IS-95 Table 7.7.5.5-5. IS-54B Alerting (SIGNAL_TYPE = '10')         */

#define CAI_IS54B_OFF      0x00
  /* No Tone: off */
#define CAI_IS54B_L        0x01
  /* Long: (standard alert) */
#define CAI_IS54B_SS       0x02
  /* Short-short */
#define CAI_IS54B_SSL      0x03
  /* Short-short-long */
#define CAI_IS54B_SS2      0x04
  /* Short-short-2 */
#define CAI_IS54B_SLS      0x05
  /* Short-long-short */
#define CAI_IS54B_SSSS     0x06
  /* Short-short-short-short */
#define CAI_IS54B_PBX_L    0x07
  /* PBX Long */
#define CAI_IS54B_PBX_SS   0x08
  /* PBX Short-short */     
#define CAI_IS54B_PBX_SSL  0x09
  /* PBX Short-short-long */
#define CAI_IS54B_PBX_SLS  0x0A
  /* PBX Short-long-short */
#define CAI_IS54B_PBX_SSSS 0x0B
  /* PBX Short-short-short-short */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                    DTMF_ON_LENGTHS                                      */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.2.3.2.7-1. Recommended DTMF Pulse Width             */

#define CAI_DTMF_ON_95  0x00
  /* 95 ms recommended pulse width */
#define CAI_DTMF_ON_150 0x01
  /* 150 ms recommended pulse width */
#define CAI_DTMF_ON_200 0x02
  /* 200 ms recommended pulse width */
#define CAI_DTMF_ON_250 0x03
  /* 250 ms recommended pulse width */
#define CAI_DTMF_ON_300 0x04
  /* 300 ms recommended pulse width */
#define CAI_DTMF_ON_350 0x05
  /* 350 ms recommended pulse width */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                    DTMF_OFF_LENGHS                                      */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.2.3.2.7-2 Recommended Minimum Interdigit Interval   */

#define CAI_DTMF_OFF_60  0x00
  /* 60 ms recommended minimum interdigit interval */
#define CAI_DTMF_OFF_100 0x01
  /* 100 ms recommended minimum interdigit interval */
#define CAI_DTMF_OFF_150 0x02
  /* 150 ms recommended minimum interdigit interval */
#define CAI_DTMF_OFF_200 0x03
  /* 200 ms recommended minimum interdigit interval */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                  PAGING CHANNEL DATA RATES                              */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 7.7.1.3-1. Paging Channel Data Rate                     */

#define CAI_PC_1_RATE 0x0    /* 9600 bps */
#define CAI_PC_2_RATE 0x1    /* 4800 bps */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                  SERVICE OPTIONS                                        */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

#define CAI_SO_REJ          0x0000
  /* Service Option number to indicate service option rejection */

#define CAI_SO_VOICE_IS96A  0x0001 
 /* Basic Variable Rate Voice Service (IS-96A) */

#define CAI_SO_LOOPBACK     0x0002
  /* Mobile Station Loopback (IS-126) */

#define CAI_SO_ASYNC_DATA   0x0004
  /* Asynchronous Data Service (IS-99) */

#define CAI_SO_G3_FAX       0x0005
  /* Group 3 FAX Service (IS-99) */

#define CAI_SO_PPP_PKT_DATA 0x0007
  /* Internet Standard PPP Packet Data Service (PN-3472) */

#define CAI_SO_VOICE_IS96   0x8001 
 /* Speech Service Option (IS-96) */

#define CAI_SO_MARKOV       0x8002
  /* Markov Service Option */

#define CAI_SO_DATA         0x8003
  /* Data Services Service Option, HACK Packet method */

#define CAI_SO_NULL         0xFFFF
  /* NULL value for service option negotiation */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                   AUTHENTICATON MODES                                   */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

#define CAI_NO_AUTH 0x00
#define CAI_AUTH    0x01

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                 MESSAGE ENCRYPTION MODES                                */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 7.7.2.3.2.8-2. Message Encryption Modes                 */

#define CAI_ENCRYPTION_DISABLED   0x00
  /* Encryption disabled */
#define CAI_ENCRYPT_CALL_CTL_MSGS 0x01
  /* Encrypt call control messages */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                    ASSIGNMENT MODES                                     */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 7.7.2.3.2.8-1. Assignment Mode                          */

#define CAI_TRAFFIC_CHAN_ASSIGN 0x00
  /* Traffic Channel Assignment */
#define CAI_PAGING_CHAN_ASSIGN  0x01
  /* Paging Channel Assignment */
#define CAI_ACQ_ANALOG_SYSTEM   0x02
  /* Acquire Analog System */
#define CAI_ANALOG_VCHAN_ASSIGN 0x03
  /* Analog Voice Channel Assignment */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                   REGISTRATION TYPES                                    */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table 6.7.1.3.2.1-1. Registration Type (REG_TYPE) Codes       */

#define CAI_TIMER_REG     0x00
  /* Timer-based registration */
#define CAI_POWERUP_REG   0x01
  /* Power-up registration */
#define CAI_ZONE_REG      0x02
  /* Zone-based registration */
#define CAI_POWERDOWN_REG 0x03
  /* Power-down registration */
#define CAI_PARAMETER_REG 0x04
  /* Parameter-change registration */
#define CAI_ORDERED_REG   0x05
  /* Ordered registration */
#define CAI_DISTANCE_REG  0x06
  /* Distance-based registration */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*          SETTABLE AND RETRIEVABLE PARAMETERS                            */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* The following parameters are from IS-95 Table E-1.                      */

#define CAI_MUX1_REV_1_ID 1  
  /* Number of Reverse Traffic Channel 9600 bps frames with primary traffic
     only */
#define CAI_MUX1_REV_1_LEN 24
  /* Length of CAI_MUX_REV_1 parameter */ 

#define CAI_MUX1_REV_2_ID 2
  /* Number of Reverse Traffic Channel 9600 bps frames, dim-and-burst with
     rate 1/2 primary and signaling traffic */
#define CAI_MUX1_REV_2_LEN 24
  /* Length of CAI_MUX_REV_2 parameter */ 

#define CAI_MUX1_REV_3_ID 3  
  /* Number of Reverse Traffic Channel 9600 bps frames, dim-and_burst with
     rate 1/4 primary and signaling traffic */
#define CAI_MUX1_REV_3_LEN 24
  /* Length of CAI_MUX_REV_3 parameter */ 

#define CAI_MUX1_REV_4_ID 4
  /* Number of Reverse Traffic Channel 9600 bps frames, dim-and_burst with
     rate 1/8 primary and signaling traffic */
#define CAI_MUX1_REV_4_LEN 24
  /* Length of CAI_MUX_REV_4 parameter */ 

#define CAI_MUX1_REV_5_ID 5 
  /* Number of Reverse Traffic Channel 9600 bps frame, blank-and-burst with
     signaling traffic only */
#define CAI_MUX1_REV_5_LEN 24
  /* Length of CAI_MUX_REV_5 parameter */ 

#define CAI_MUX1_REV_6_ID 6
  /* Number of Reverse Traffic Channel 4800 bps frames with primary traffic
     only */
#define CAI_MUX1_REV_6_LEN 24
  /* Length of CAI_MUX_REV_6 parameter */ 

#define CAI_MUX1_REV_7_ID 7  
  /* Number of Reverse Traffic Channel 2400 bps frames with primary traffic
     only */
#define CAI_MUX1_REV_7_LEN 24
  /* Length of CAI_MUX_REV_7 parameter */ 

#define CAI_MUX1_REV_8_ID 8
  /* Number of Reverse Traffic Channel 1200 bps frmaes primary traffic or
     null Traffic Channel data only */
#define CAI_MUX1_REV_8_LEN 24
  /* Length of CAI_MUX_REV_8 parameter */ 

#define CAI_MUX1_REV_9_ID 9
  /* Reserved */
#define CAI_MUX1_REV_10_ID 10
  /* Reserved */
     
#define CAI_MUX1_REV_11_ID 11
  /* Number of Reverse Traffic Channel 9600 bps frames, dim-and-burst with
     rate 1/2 primary and secondary traffic */
#define CAI_MUX1_REV_11_LEN 24
  /* Length of CAI_MUX1_REV_11 parameter */

#define CAI_MUX1_REV_12_ID 12  
  /* Number of Reverse Traffic Channel 9600 bps frames, dim-and_burst with
     rate 1/4 primary and secondary traffic */
#define CAI_MUX1_REV_12_LEN 24
  /* Length of CAI_MUX_REV_12 parameter */ 

#define CAI_MUX1_REV_13_ID 13
  /* Number of Reverse Traffic Channel 9600 bps frames, dim-and_burst with
     rate 1/8 primary and secondary traffic */
#define CAI_MUX1_REV_13_LEN 24
  /* Length of CAI_MUX_REV_13 parameter */ 

#define CAI_MUX1_REV_14_ID 14
  /* Number of Reverse Traffic Channel 9600 bps frames, blank-and-burst with
     secondary traffic only */
#define CAI_MUX1_REV_14_LEN 24
  /* Length of CAI_MUX1_REV_14 parameter */

#define CAI_MUX1_FOR_1_ID 15 
  /* Number of Forward Traffic Channel 9600 bps primary traffic only frames */
#define CAI_MUX1_FOR_1_LEN 24
  /* Length of CAI_MUX1_FOR_1 parameter */

#define CAI_MUX1_FOR_2_ID 16
  /* Number of Forward Traffic Channel 9600 bps frames dim-and-burst with
     rate 1/2 primary and signaling traffic */
#define CAI_MUX1_FOR_2_LEN 24
  /* Length of CAI_MUX1_FOR_2 parameter */

#define CAI_MUX1_FOR_3_ID 17  
  /* Number of Forward Traffic Channel 9600 bps frames dim-and-burst with
     rate 1/4 primary and signaling traffic */
#define CAI_MUX1_FOR_3_LEN 24
  /* Length of CAI_MUX1_FOR_3 parameter */

#define CAI_MUX1_FOR_4_ID 18
  /* Number of Forward Traffic Channel 9600 bps frames, dim-and-burst with
     rate 1/8 primary and signaling traffic */
#define CAI_MUX1_FOR_4_LEN 24
  /* Length of CAI_MUX1_FOR_4 parameter */

#define CAI_MUX1_FOR_5_ID 19 
  /* Number of Forward Traffic Channel 9600 bps frames, blank-and-burst with
     signaling traffic only */
#define CAI_MUX1_FOR_5_LEN 24
  /* Length of CAI_MUX1_FOR_5 parameter */

#define CAI_MUX1_FOR_6_ID 20
  /* Number of Forward Traffic Channel 4800 bps frames, primary traffic only */
#define CAI_MUX1_FOR_6_LEN 24
  /* Length of CAI_MUX1_FOR_6 parameter */

#define CAI_MUX1_FOR_7_ID 21 
  /* Number of Forward Traffic Channel 2400 bps frames, primary traffic only */
#define CAI_MUX1_FOR_7_LEN 24
  /* Length of CAI_MUX1_FOR_7 parameter */

#define CAI_MUX1_FOR_8_ID 22
  /* Number of Forward Traffic Channel 1200 bps frames, primary traffic or
     null Traffic Channel data only */
#define CAI_MUX1_FOR_8_LEN 24
  /* Length of CAI_MUX1_FOR_8 parameter */

#define CAI_MUX1_FOR_9_ID 23 
  /* Number of Forward Traffic Channel 9600 bps frames primary traffic only,
     probable bit errors */
#define CAI_MUX1_FOR_9_LEN 24
  /* Length of CAI_MUX1_FOR_9 parameter */

#define CAI_MUX1_FOR_10_ID 24
  /* Number of Forward Traffic Channel frames with frame quality insufficient
     to decide upon rate */
#define CAI_MUX1_FOR_10_LEN 24
  /* Length of CAI_MUX1_FOR_10 parameter */


#define CAI_MUX1_FOR_11_ID 25
  /* Number of Forward Traffic Channel 9600 bps frames, dim-and-burst with
     rate 1/2 primary and secondary traffic */
#define CAI_MUX1_FOR_11_LEN 24
  /* Length of CAI_MUX1_FOR_11 parameter */
     
#define CAI_MUX1_FOR_12_ID 26
  /* Number of Forward Traffic Channel 9600 bps frames, dim-and-burst with
     rate 1/4 primary and secondary traffic */
#define CAI_MUX1_FOR_12_LEN 24
  /* Length of CAI_MUX1_FOR_12 parameter */

#define CAI_MUX1_FOR_13_ID 27
  /* Number of Forward Traffic Channel 9600 bps frames, dim-and-burst with
     rate 1/8 primary and secondary traffic */
#define CAI_MUX1_FOR_13_LEN 24
  /* Length of CAI_MUX1_FOR_13 parameter */

#define CAI_MUX1_FOR_14_ID 28
  /* Number of Forward Traffic Channel 9600 bps frames, blank-and-burst with
     secondary traffic only */
#define CAI_MUX1_FOR_14_LEN 24
  /* Length of CAI_MUX1_FOR_14 parameter */

#define CAI_PAG_1_ID 29
  /* Number of Paging Channel messages attempted to be received */
#define CAI_PAG_1_LEN 24
  /* Length of CAI_PAG_1_ID parameter */

#define CAI_PAG_2_ID 30
  /* Number of Paging Channel msgs received with a CRC that does not check */
#define CAI_PAG_2_LEN 24
  /* Length of CAI_PAG_2_ID parameter */

#define CAI_PAG_3_ID 31
  /* Number of Paging Channel messages received, addressed to mobile */
#define CAI_PAG_3_LEN 16
  /* Length of CAI_PAG_3 parameter */

#define CAI_PAG_4_ID 32
  /* Number of Paging Channel half frames received by the mobile */
#define CAI_PAG_4_LEN 24
  /* Length of CAI_PAG_4 parameter */

#define CAI_PAG_5_ID 33
  /* Number of Paging Channel half frames that contain any part of a message
     with a CRC that checks */
#define CAI_PAG_5_LEN 24
  /* Length of CAI_PAG_5 parameter */

#define CAI_PAG_6_ID 34
  /* Number of times that the mobile station declared a loss of the Paging
     Channel */
#define CAI_PAG_6_LEN 16
  /* Length of CAI_PAG_6 parameter */

#define CAI_PAG_7_ID 35
  /* Number of mobile station idle handoffs */
#define CAI_PAG_7_LEN 16
  /* Length of CAI_PAG_7 parameter */

#define CAI_ACC_1_ID 36
  /* Number of Access Channel request messages generated by layer 3 */
#define CAI_ACC_1_LEN 16
  /* Length of CAI_ACC_1 parameter */

#define CAI_ACC_2_ID 37
  /* Number of Access Channel response messages generated by layer 3 */
#define CAI_ACC_2_LEN 16
  /* Length of CAI_ACC_2 parameter */

#define CAI_ACC_3_ID 38
  /* Number of times access probe transmitted at least twice */
#define CAI_ACC_3_LEN 16
  /* Length of CAI_ACC_3 parameter */

#define CAI_ACC_4_ID 39
  /* Number of times access probe transmitted at least 3 times */
#define CAI_ACC_4_LEN 16
  /* Length of CAI_ACC_4 parameter */

#define CAI_ACC_5_ID 40
  /* Number of times access probe transmitted at least 4 times */
#define CAI_ACC_5_LEN 16
  /* Length of CAI_ACC_5 parameter */

#define CAI_ACC_6_ID 41
  /* Number of times access probe transmitted at least 5 times */
#define CAI_ACC_6_LEN 16
  /* Length of CAI_ACC_6 parameter */

#define CAI_ACC_7_ID 42
  /* Number of times access probe transmitted at least 6 times */
#define CAI_ACC_7_LEN 16
  /* Length of CAI_ACC_7 parameter */

#define CAI_ACC_8_ID 43
  /* Number of unsuccessful access attempts */
#define CAI_ACC_8_LEN 16
  /* Length of CAI_ACC_8 parameter */

#define CAI_LAYER2_RTC1_ID 44
  /* Number of messages requring acknowledgement which were transmitted at 
     least once on the Reverse Traffic Channel */
#define CAI_LAYER2_RTC1_LEN 16
  /* Length of CAI_LAYER2_RTC1 parameter */

#define CAI_LAYER2_RTC2_ID 45
  /* Number of messages requring acknowledgement which were transmitted at
     least twice on the Reverse Traffic Channel */
#define CAI_LAYER2_RTC2_LEN 16
  /* Length of CAI_LAYER2_RTC2 parameter */

#define CAI_LAYER2_RTC3_ID 46
  /* Number of messages requring acknowledgement which were transmitted at
     least 3 times on the Reverse Traffic Channel */
#define CAI_LAYER2_RTC3_LEN 16
  /* Length of CAI_LAYER2_RTC3 parameter */

#define CAI_LAYER2_RTC4_ID 47
  /* Number of times mobile aborted call because of timeout expiring after
     the N1m transmission of a message requring an acknowledgement.  */
#define CAI_LAYER2_RTC4_LEN 16
  /* Length of CAI_LAYER2_RTC4 parameter */

#define CAI_LAYER2_RTC5_ID 48
  /* Number of times a message not requiring an acknowledgement was sent on
     the Reverse Traffic Channel */
#define CAI_LAYER2_RTC5_LEN 16
  /* Length of CAI_LAYER2_RTC5 parameter */

#define CAI_OTH_SYS_TIME_ID 49
  /* The SYS_TIME field from the most recently received Sync Channel Message */
#define CAI_OTH_SYS_TIME_LEN 36
  /* Length of CAI_OTH_SYS_TIME parameter */

#define CAI_FIRST_PARM_ID 1
  /* This must be set to the lowest valid Parameter ID */
#define CAI_LAST_PARM_ID 49
  /* This must be set to the highest valid Parameter ID */

#define CAI_PARM_MIN_LEN 16  /* Minimum length for parameter */
#define CAI_PARM_MAX_LEN 36  /* Maximum length for a parameter */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                  TIME-OUTS AND TIME LIMITS                              */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table D-1. Time Limits                                        */

#define CAI_T1M 400
  /* Number of ms before mobile station times out its wait for an 
     aknowledgement on the Forward Traffic Channel */
#define CAI_T2M 200
  /* Number of ms allowed for mobile to send an acknowlegement of a 
     signaling message received on the Forward Traffic Channel */
#define CAI_T3M 320
  /* Number of ms during which the mobile will consider a mesage received
     on the Forward Traffic Channel not requiring an acknowledgement having
     the same sequence number as a previously received message to be a 
     duplicate */
#define CAI_T4M 2200
  /* Number of ms during which the mobile will consider a mesage received
     on the Paging Channel from the same base station which has the same
     sequence number as a previously received message to be a duplicate 
     the formula for the calculation is 4 * 2**slot_cycle_index + .2 sec */
#define CAI_T5M 5000
  /* Number of ms for the Forward Traffic Channel Fade timer */
#define CAI_T20M 15000
  /* Number of ms for the Pilot Channel Acquisition substate timer */
#define CAI_T21M 1000
  /* Number of ms for the Receipt of Sync Channel message timeout */
#define CAI_T30M 3000
  /* Number of ms before timeout for a non-slotted mobile station to receive
     a Paging Channel message with a good CRC */
#define CAI_T31M 600000L
  /* Time for a mobile station to consider overhead messages valid */
#define CAI_T32M 5000
  /* Maximum time to enter the Update Overhead Information Substate of the
     System Access State to respond to an SSD Update Message, BS Challenge
     Confirmation Order, and Authentication Challenge Message */
#define CAI_T33M 300
  /* Maximum time to enter the Update Overhead Information Substate of the
     System Access State to respond to messages received while in the
     Mobile Station Idle State (except authentication messages) */
#define CAI_T40M 1000
  /* Maximum time to receive a valid Paging Channel message before aborting
     an access attempt */
#define CAI_T41M 4000
  /* Maximum time to obtain updated overhead messages arriving
     on the Paging Channel */
#define CAI_T42M 12000
  /* System Access State timer while waiting for a delayed response, in ms */
#define CAI_T50M 200
  /* First valid frame timeout, in ms */
#define CAI_T51M 2000
  /* First good message timeout */
#define CAI_T52M 5000
  /* Number of ms to be used for the Waiting For Order Substate timer */
#define CAI_T53M 65000U
  /* Number of ms to be used for the Waiting For Mobile Station Answer
     Substate timer */
#define CAI_T54M 200
  /* Maximum time for the mobile station to send an Origination Continuation
     Message upon entering the Conversation Substate of the Mobile Station
     Control on the Traffic Channel State */
#define CAI_T55M 2000
  /* Number of ms to be used for the Release Substate timer */
#define CAI_T56M 200
  /* Default maximum time to respond to a received message or order on the
     Forward Traffic Channel */
#define CAI_T57M 20000
  /* Limit of powerup registration timer */
#define CAI_T58M 5000
  /* Maximum time for the mobile station to respond to a service option 
     request */
#define CAI_T60M 60
  /* Maximum time to execute a hard handoff involving a new frequency
     assignment using the same base station */
#define CAI_T61M 80
  /* Maximum time to execute a hard handoff involving a new frequency
     assignment using a different base station */
#define CAI_T62M 20
  /* Maximum time to execute a hard handoff involving the same frequency
     assignment */
#define CAI_T63M 100
  /* Maximum time to execute a CDMA to Analog handoff */

#define CAI_T1B 1280
  /* Maximum period between subsequent transmissions of an overhead
     message on the Paging Channel by the base station */
#define CAI_T2B 800
  /* Maximum time for the base station to send a Release Order after
     receiving a Release Order */
#define CAI_T3B 300
  /* Maximum time the base station continues to transmit on a code channel
     after sending or receiving a Release Order */
#define CAI_T4B 5000
  /* Maximum time for the base station to respond to a service option
     request */
  
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* See IS-95 Table D-2. Other Constants                                    */

#define CAI_N1M  13
  /* Maximum number of times that a mobile station transmits a message
   * requiring an acknowledgement on the Reverse Traffic Channel.
   * Changed from 3 to 13 to support high FER data testing.
   */

#define CAI_N2M 12
  /* Number of consecutive Forward Traffic Channel frames placed into
     category 10 before a mobile station must disable its transmitter */
#define CAI_N3M 2
  /* Number of consecutive Forward Traffic Channel frames that must be 
     placed into other than category 10 before a  mobile station is 
     allowed to re-enable its transmitter after disabling its transmitter */
#define CAI_N4M  20
  /* Number of frames delay for a private long code transition
     after the response to the request is transmitted */
#define CAI_N5M 2
  /* Number of received consecutive good Forward Traffic Channel
     frames before a mobile enables its transmitter in TCI */
#define CAI_N6M 6     /* Supported Traffic Channel Active Set size */
#define CAI_N7M 5     /* Supported Traffic Channel Candidate Set size */
#define CAI_N8M 20    /* Minimum supported neighbor set size */
#define CAI_N9M 7     /* Minimum supported zone-list size */
#define CAI_N10M 4    /* Minimum supported sid-nid list size */

typedef struct
{
  WORD t1m;   /* Maximum time the mobile waits for an acknowledgement */
  WORD t3m;   /* Period in which 2 Forward Traffic Channel messages
                 with the same sequence number are considered duplicates */
  WORD t4m;   /* Period in which 2 Paging Channel messages
                 with the same sequence number are considered duplicates */
  WORD t5m;   /* Limit of Forward Traffic Channel fade timer */
  WORD t20m;  /* Maximum time to remain in the Pilot Channel Acquisition
                 substate */
  WORD t21m;  /* Maximum time to receive a valid Sync Channel message */
  WORD t30m;  /* Maximum time to receive a valid Paging Channel message */
  DWORD t31m; /* Maximum time Paging Channel message considred valid */
  WORD t40m;  /* Maximum time to receive a valid Paging Channel message
                 before aborting an access attempt */
  WORD t41m;  /* Maximum time to obtain updated overhead messages arriving
                 on the Paging Channel */
  WORD t42m;  /* Maximum time to receive a delayed layer 3 response
                 following the receipt of an ack for an access probe */
  WORD t50m;  /* Maximum time to obtain N5m consecutive good frames while
                 in the Traffic Channel Initialization state */
  WORD t51m;  /* Maximu time to receive a Base Station ack when in the
                 Traffic Channel Initialization state */
  WORD t52m;  /* Maximum time to receive a message in the Waiting for
                 Order substate which transits the mobile to a new state */
  WORD t53m;  /* Maximum time to receive a message in the Waiting for
                 Answer substate which transits the mobile to a new state */
  WORD t55m;  /* Maximum time to receive a message in the Release substate
                 which transits the mobile to a new state */
  DWORD t57m; /* Limit of powerup registration timer */
  WORD n1m;   /* Maximum number of time a mobile transmits a message
                 requiring an ack on the Reverse Traffic Channel */
  WORD n2m;   /* Number of received consecutive bad Forward Traffic Channel
                 frames before a mobile disables its transmitter */
  WORD n3m;   /* Number of received consecutive good Forward Traffic Channel
                 frames before a mobile re-enables its transmitter */
  WORD n4m;   /* Number of frames delay for a private long code transition
                 after the response to the request is transmitted */
  WORD n5m;   /* Number of received consecutive good Forward Traffic Channel
                 frames before a mobile enables its transmitter in TCI */
  WORD n6m;   /* Minimum supported Active Set size */
  WORD n7m;   /* Minimum supported Candidate Set size */
  WORD n8m;   /* Minimum supported Neighbor Set size */
  WORD n9m;   /* Minimum supported zone list size */
  WORD n10m;  /* Minimum supported SID/NID list size */
} cai_tmo_type;

//extern cai_tmo_type cai_tmo;  /* time-out structure */


/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                      REGISTRATION CONSTANTS                             */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

#define CAI_HOME_NID 65535
  /* Special value of NID used in a SID, NID pair to indicate that the mobile
     station considers all NIDs with a SID to be home (see IS-95 Section
     6.6.5.2 Systems and Networks) */

/* -------------------------------------------------------------------------
** The following data declarations are representations of the CDMA messages
** found in IS-95 (see sections 6.7 and 7.7).  Each bit in the message is
** represented by a BYTE in the data structure.
** ------------------------------------------------------------------------ */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                       GENERIC MESSAGES                                  */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* Type to isolate msg_type */
typedef struct
{
  BYTE msg_type[8];    /* Message type */
} cai_gen_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Generic Paging Channel Message Header */
typedef struct
{
  BYTE msg_type[8];   /* Message type */
  BYTE ack_seq[3];    /* Acknowledgement sequence Number */
  BYTE msg_seq[3];    /* Message sequence number */
  BYTE ack_req[1];    /* Acknowledgement required indicator */
  BYTE valid_ack[1];  /* Valid acknowledgement indicator */
  BYTE addr_type[3];  /* Address type */
  BYTE addr_len[4];   /* Address field length */
} cai_pc_hdr_type;

/* Paging Channel Address Fields */
typedef struct
{
  BYTE min1[24];     /* First part of the mobile identification number */
  BYTE min2[10];     /* Second part of the mobile identification number */
  BYTE reserved[6];  /* Reserved bits */
} cai_min_addr_type;

typedef struct 
{
  BYTE esn[32];      /* Mobile station's electronic serial number */
} cai_esn_addr_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Generic Access Channel Message Header */
typedef struct
{
  BYTE ack_seq[3];    /* Acknowledgement sequence number */
  BYTE msg_seq[3];    /* Message sequence number */
  BYTE ack_req[1];    /* Acknowledgement required indicator */
  BYTE valid_ack[1];  /* Valid acknowledgement indicator */
  BYTE ack_type[3];   /* Acknowledgement address type */
  BYTE msid_type[3];  /* Mobile station identifier field type */
  BYTE msid_len[4];   /* Mobile station identifier field length */
} cai_ac_hdr_type;

/* Access Channel Mobile Station Identifier Fields (MSID_TYPE = '000') */
typedef struct
{
  BYTE min1[24];     /* First part of the mobile identification number */
  BYTE min2[10];     /* Second part of the mobile identification number */
  BYTE esn[32];      /* Mobile station's electronic serial number */
  BYTE reserved[6];  /* Reserved bits */
} cai_msid0_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Traffic Channel Layer 2 Message Header */

typedef struct
{
  BYTE ack_seq[3];          /* Acknowledgement Sequence number */
  BYTE msg_seq[3];          /* Message Sequence number */
  BYTE ack_req[1];          /* Acknowledgement Required indicator */
  BYTE encryption[2];       /* Message encryption indicator */
} cai_tc_hdr_type;

/* Generic Forward and Reverse Traffic Channel message */
typedef struct
{
  BYTE msg_type[8];    /* Message type */
  cai_tc_hdr_type hdr; /* Layer 2 message header */
} cai_gen_tc_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*      PAGING AND FORWARD TRAFFIC CHANNEL INFORMATION RECORD TYPES        */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Note - On the Paging Channel, information records may be included in 
   the Feature Notification Message.  On the Forward Traffic Channel, 
   information records may be included in the Alert With Information
   and the Flash with Information messages.                                */

/* Information Record header */
typedef struct
{
  BYTE record_type[8]; /* Information record type */
  BYTE record_len[8];  /* Information record length */
} cai_rec_hdr_type;

/* Display record (see IS-95 Section 7.7.5.1 Display) */
typedef struct
{
  BYTE chari[8];       /* Character */
} cai_display_rec_var_type;

/* Called Party Number record (see IS-95 Section 7.7.5.2 Called Party
   Number) */

/* Fixed part of Called Party Number fixed record */
typedef struct
{
  BYTE number_type[3];  /* Type of number */
  BYTE number_plan[4];  /* Numbering plan */
} cai_called_fix_type;

/* Variable part of Called Party Number record */
typedef struct
{
  BYTE chari[8];        /* Character */
} cai_called_var_type;

/* Calling Party Number record (see IS-95 Section 7.7.5.3 Calling Party
   Number) */

/* Fixed part of Calling Party Number record */
typedef struct
{
  BYTE number_type[3];   /* Type of number */
  BYTE number_plan[4];   /* Numbering plan */
  BYTE pi[2];            /* Presentation indicator */
  BYTE si[2];            /* Screening indicator */
} cai_calling_fix_type;

/* Variable part of Calling Party Number record */
typedef struct
{
  BYTE chari[8];         /* Character */
} cai_calling_var_type;

/* Use Calling Party Number record types for Connnected Number (see
   IS-95 Section 7.7.5.4 Connected Number) */

/* Signal record (see IS-95 Section 7.7.5.5 Signal) */
typedef struct
{
  BYTE signal_type[2];    /* Signal type */
  BYTE alert_pitch[2];    /* Pitch of the alerting signal */
  BYTE signal[6];         /* Signal code */
  BYTE reserved[6];       /* Reserved bits */
} cai_signal_rec_type;

/* Message Waiting record (see IS-95 Section 7.7.5.6 Message Waiting) */
typedef struct
{
  BYTE msg_count[8];      /* Number of waiting messages */
} cai_msg_waiting_rec_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*            REVERSE TRAFFIC CHANNEL INFORMATION RECORD TYPES             */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Note - these records are used in the Flash With Information and the 
   Status messages (see IS-95 Sections 6.7.2.3.2.3 Flash With Information
   Message and 6.7.2.3.2.8 Status Message)                                 */

/* Note that the Reverse Traffic Channel information records use the
   same record header type as the Forward Traffic Channel information
   records */

/* Feature Indicator record (see IS-95 Section 6.7.4.1 Feature Indicator)  */
typedef struct
{
  BYTE feature[4];   /* Feature indentifier */
  BYTE reserved[4];  /* Reserved bits */
} cai_feat_type;

/* Keypad facility record (see IS-95 Section 6.7.4.2 Keypad Facility)      */
typedef struct
{
  BYTE chari[8];     /* Character */
} cai_keypad_type;

/* Use Called Party Number and Calling Party Number record types from
   Forward Traffic Channel Information records (see IS-95 Sections
   6.7.4.3 Called Party Number and 6.7.4.4 Calling Party Number) */

/* Identification record (see IS-95 Section 6.7.4.5 Identification) */
typedef struct
{
  BYTE min1[24];      /* First part of mobile identification number */
  BYTE min2[10];      /* Second part of mobile identification number */
  BYTE esn[32];       /* Mobile station's electronic serial number */
  BYTE mob_term[1];   /* Mobile terminated calls accepted indicator */
  BYTE reserved[5];   /* Reserved bits */
} cai_id_type;

/* Call Mode record (see IS-95 Section 6.7.4.6 Call Mode) */
typedef struct
{
  BYTE orig_mode[1];     /* Origination mode indicator */
  BYTE pri_service[16];  /* Primary service option */
  BYTE sec_service[16];  /* Secondray service option */
  BYTE reserved[7];      /* Reserved bits */
} cai_call_mode_type;

/* Terminal Information record (see IS-95 Section 6.7.4.7 Terminal
   Information) */

/* Fixed part of Terminal Information record */
typedef struct
{
  BYTE mob_p_rev[8];         /* Protocol revision of the mobile station */
  BYTE mob_mfg_code[8];      /* Manufacturer code */
  BYTE mob_model[8];         /* Model number */
  BYTE mob_firm_rev[16];     /* Firmware revision number */
  BYTE scm[8];               /* Station class mark */
  BYTE local_ctrl[1];        /* Local control indicator */
  BYTE slot_cycle_index[3];  /* Slot cycle index */
} cai_term_info_fix_type;

/* Variable part of Terminal Information record */
typedef struct
{
  BYTE service_option[16];   /* Supported service option */
} cai_term_info_var_type;

/* MIN information record (see IS-95 Section 6.7.4.8 MIN Information) */

/* Fixed part of MIN Information record */
typedef struct
{
  BYTE accolc[4];            /* Overload class */
  BYTE mob_term_home[1];     /* Home registration enable indicator */
  BYTE mob_term_for_sid[1];  /* Foreign SID roaming registration enable
                                indicator */
  BYTE mob_term_for_nid[1];  /* Foreign NID roaming registration enable
                                indicator */
} cai_min_info_fix_type;

/* Variable part of MIN Information record */
typedef struct
{
  BYTE sid[15];              /* System identification */
  BYTE nid[16];              /* Network identification */
} cai_min_info_var_type;
 
/* Security Status record (see IS-95 Section 6.7.4.9 Security Status) */
typedef struct
{
  BYTE auth_mode[2];       /* Authentication mode */
  BYTE encrypt_mode[2];    /* Message encryption mode */
  BYTE private_lcm[1];     /* Private long code mask indicator */
  BYTE reserved[3];        /* Reserved bits */
} cai_sec_stat_type;

/* Use Forward Traffic Channel Connected Number information record type for 
   Connected Number type */

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* SYNC CHANNEL MESSAGE (see IS-95 Section 7.7.1.3)                        */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

typedef struct
{
  BYTE msg_type[8];    /* Message type */
  BYTE p_rev[8];       /* Protocol revision level */
  BYTE min_p_rev[8];   /* Minimum protocol revision level */
  BYTE sid[15];        /* System identification */
  BYTE nid[16];        /* Network identification */
  BYTE pilot_pn[9];    /* Pilot PN sequence offset index */
  BYTE lc_state[42];   /* Long code state */
  BYTE sys_time[36];   /* System time */
  BYTE lp_sec[8];      /* Number of leap seconds that have occurred since
                          the start of System Time */
  BYTE ltm_off[6];     /* Offset of local time from System Time */
  BYTE daylt[1];       /* Daylight savings time indicator */
  BYTE prat[2];        /* Paging Channel data rate */
  BYTE reserved[3];    /* Reserved bits */
} cai_sync_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                    PAGING CHANNEL MESSAGES                              */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* SYSTEM PARAMETERS MESSAGE (see IS-95 Section 7.2.3.2.11)                */

typedef struct
{                               
  BYTE msg_type[8];             /* Message type */  
  BYTE pilot_pn[9];             /* Pilot PN sequence offset index */
  BYTE config_msg_seq[6];       /* Configuration message sequence number */
  BYTE sid[15];                 /* System identification */
  BYTE nid[16];                 /* Network identification */
  BYTE reg_zone[12];            /* Registration zone */
  BYTE total_zones[3];          /* Number of registration zones to be
                                   retained */
  BYTE zone_timer[3];           /* Zone timer length */
  BYTE mult_sids[1];            /* Multiple SID storage indicator */
  BYTE mult_nids[1];            /* Multiple NID storage indicator */
  BYTE base_id[16];             /* Base station identification */
  BYTE base_class[4];           /* Base station class */
  BYTE page_chan[3];            /* Number of Paging Channels */
  BYTE max_slot_cycle_index[3]; /* Maximum slot cycle index */
  BYTE home_reg[1];             /* Home registration indicator */
  BYTE for_sid_reg[1];          /* SID roamer registration indicator */
  BYTE for_nid_reg[1];          /* NID roamer registration indicator */
  BYTE power_up_reg[1];         /* Power-up registration indicator */
  BYTE power_down_reg[1];       /* Power-down registration indicator */
  BYTE parameter_reg[1];        /* Parameter-change registration indicator */
  BYTE reg_prd[7];              /* Registration period */
  BYTE base_lat[22];            /* Base station latitude */
  BYTE base_long[23];           /* Base station longitude */
  BYTE reg_dist[11];            /* Registration distance */
  BYTE srch_win_a[4];           /* Search window size for the Active Set and
                                   Candidate Set */
  BYTE srch_win_n[4];           /* Search window size for the Neighbor Set */
  BYTE srch_win_r[4];           /* Search window size for the Remaining Set */
  BYTE nghbr_max_age[4];        /* Neighbor Set maximum AGE */
  BYTE pwr_rep_thresh[5];       /* Power control reporting threshold */
  BYTE pwr_rep_frames[4];       /* Power control reporting frame count */
  BYTE pwr_thresh_enable[1];    /* Threshold report mode indicator */
  BYTE pwr_period_enable[1];    /* Threshold report mode indicator */
  BYTE pwr_rep_delay[5];        /* Power report delay */
  BYTE rescan[1];               /* Rescan indicator */
  BYTE t_add[6];                /* Pilot detection threshold */
  BYTE t_drop[6];               /* Pilot drop threshold */
  BYTE t_comp[4];               /* Active Set versus Candidate Set 
                                   comparison threshold */
  BYTE t_tdrop[4];              /* Drop timer value */
  BYTE reserved[4];             /* Reserved bits */
} cai_sysparm_msg_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* ACCESS PARAMETERS MESSAGE (see IS-95 Section 7.7.2.3.2.2)               */

typedef struct
{
  BYTE msg_type[8];      /* Message type */
  BYTE pilot_pn[9];      /* Pilot PN sequence offset index */
  BYTE acc_msg_seq[6];   /* Access parameters message sequence number */
  BYTE acc_chan[5];      /* Number of Access Channels */
  BYTE nom_pwr[4];       /* Nominal transmit power offset */
  BYTE init_pwr[5];      /* Initial power offset for access */
  BYTE pwr_step[3];      /* Power increment */
  BYTE num_step[4];      /* Number of access probes */
  BYTE max_cap_sz[3];    /* Maximum Access Channel message capsule size */
  BYTE pam_sz[4];        /* Access Channel preamble length */
  BYTE psist_0_9[6];     /* Persistence value for access overload classes
                            0 through 9 */
  BYTE psist_10[3];      /* Persistence value for Access Overload Class 10 */
  BYTE psist_11[3];      /* Persistence value for Access Overload Class 11 */
  BYTE psist_12[3];      /* Persistence value for Access Overload Class 12 */
  BYTE psist_13[3];      /* Persistence value for Access Overload Class 13 */
  BYTE psist_14[3];      /* Persistence value for Access Overload Class 14 */
  BYTE psist_15[3];      /* Persistence value for Access Overload Class 15 */
  BYTE msg_psist[3];     /* Persistence modifier for Access Channel attempts
                            for message transmissions */
  BYTE reg_psist[3];     /* Persistence modifier for Access Channel attempts
                            for registrations */
  BYTE probe_pn_ran[4];  /* Time randomization for Access Channel probes */
  BYTE acc_tmo[4];       /* Acknowledgement timeout */
  BYTE probe_bkoff[4];   /* Access Channel probe backoff range */
  BYTE bkoff[4];         /* Access Channel probe sequence backoff range */
  BYTE max_req_seq[4];   /* Maximum number of acces probe sequences for an
                            Access Channel request */
  BYTE max_rsp_seq[4];   /* Maximum number of access probe sequences for an
                            Access Channel response */
  BYTE auth[2];          /* Authentication mode */
  BYTE rand[32];         /* Random challenge value - only present if auth
                            field is set to '01' */
  BYTE reserved[7];      /* Reserved bits */
} cai_accparm_msg_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* NEIGHBOR LIST MESSAGE (see IS-95 Section 7.7.2.3.2.3)                   */

/* Fixed Part of message */
typedef struct
{
  BYTE msg_type[8];        /* Message type */  
  BYTE pilot_pn[9];        /* Pilot PN sequence offset index */
  BYTE config_msg_seq[6];  /* Configuration message sequence number */
  BYTE pilot_inc[4];       /* Pilot PN sequence offset index increment */
} cai_nghbr_fix_type;

/* Variable part of message */
typedef struct
{
  BYTE nghbr_config[3];     /* Neighbor configuration */
  BYTE nghbr_pn[9];         /* Neighbor pilot PN sequence offset index */
} cai_nghbr_var_type;

/* Maximum number of variable parts that will fit in message */
#define CAI_NGHBR_MAX  PAGECHN_MAX( cai_nghbr ) 

typedef struct
{
  cai_nghbr_fix_type fix;                   
  cai_nghbr_var_type var[CAI_NGHBR_MAX] ;
} cai_nghbr_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* CDMA CHANNEL LIST MESSAGE (see IS-95 Section 7.7.2.3.2.4)               */

/* Fixed part of message */
typedef struct
{
  BYTE msg_type[8];        /* Message type */
  BYTE pilot_pn[9];        /* Pilot PN sequence offset index */
  BYTE config_msg_seq[6];  /* Configuration message sequence number */
} cai_chnlist_fix_type;

/* Variable part of message */
typedef WORD cai_chnlist_var_type[11]; /* CDMA Channel freq assignment */  

/* Maximum number of variable message parts that will fit into message */
#define CAI_CHNLIST_MAX  PAGECHN_MAX( cai_chnlist )

typedef struct
{
  cai_chnlist_fix_type fix;
  cai_chnlist_var_type var[CAI_CHNLIST_MAX];
} cai_chnlist_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* SLOTTED PAGE MESSAGE (see IS-95 Section 7.7.2.3.2.5)                    */

/* Fixed part of message */
typedef struct
{
  BYTE msg_type[8];        /* Message type */
  BYTE config_msg_seq[6];  /* Configuration message sequence number */
  BYTE acc_msg_seq[6];     /* Access parameters message sequence number */
  BYTE more_pages[1];      /* More slotted pages to follow indicator */
} cai_slt_page_fix_type;

/* Variable part of message */
typedef struct
{
  BYTE msg_seq[3];          /* Message sequence number */
  BYTE ext_addr[1];         /* Extra address indicator */
  BYTE min1[24];            /* First part of mobile identification number */
  BYTE min2[10];            /* Second part of mobile identification number
                               (only present if ext_addr field is set to 1) */
  BYTE special_service[1];  /* Special service option indicator */
  BYTE service_option[16];  /* Service option (only present if 
                               special_service field is set to 1) */
} cai_slt_page_var_type;

/* Minumum size of variable part of message */
#define CAI_SLT_PAGE_MIN \
   (sizeof( cai_slt_page_var_type ) -      \
      FSIZ( cai_slt_page_var_type, min2 ) - \
        FSIZ( cai_slt_page_var_type, service_option ))

/* Maximum number of variable parts of message  */
#define CAI_SLT_PAGE_MAX \
  ((CAI_PC_BODY_SIZE - sizeof( cai_slt_page_fix_type )) / CAI_SLT_PAGE_MIN)

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* PAGE MESSAGE (see IS-95 Section 7.7.2.3.2.6)                            */

/* Fixed part of message */
typedef struct
{
  BYTE msg_type[8];        /* Message type */
  BYTE config_msg_seq[6];  /* Configuration message sequence number */
  BYTE acc_msg_seq[6];     /* Access parameters message sequence number */
} cai_page_fix_type;

/* Variable part of message */
typedef struct
{
  BYTE msg_seq[3];          /* Message Sequence number */
  BYTE ext_addr[1];         /* Extended addressing indicator */
  BYTE min1[24];            /* First part of mobile identification number */
  BYTE min2[10];            /* Second part of mobile identification number
                               (only present if ext_addr field is set to 1) */
  BYTE special_service[1];  /* Special service option indicator */
  BYTE service_option[16];  /* Service option (only present if 
                               special_service field is set to 1) */
} cai_page_var_type;

/* Minimum size of variable length page */
#define CAI_PAGE_MIN  \
   (sizeof( cai_page_var_type ) - \
      FSIZ( cai_page_var_type, min2 ) - \
        FSIZ( cai_page_var_type, service_option ))

/* Maximum number of pages in message */
#define CAI_PAGE_MAX  \
  ((CAI_PC_BODY_SIZE - sizeof( cai_page_fix_type )) / CAI_PAGE_MIN)

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* PAGING CHANNEL ORDER MESSAGE (IS-95 Sections 7.7.2.3.2.7 and 7.7.4)     */

/* NOTE: The following structures define the contents of the Paging
         Channel Order Message following the ADDRESS field. */

/* Orders without an order qualifier */
typedef struct
{
  BYTE order[6];           /* Order field */
  BYTE add_record_len[3];  /* Additional record length */
} cai_pc_gen_ord_type;

/* Orders with an order qualifier */
typedef struct
{
  BYTE order[6];           /* Order field */
  BYTE add_record_len[3];  /* Additional record length */
  BYTE ordq[8];            /* Order qualification code */
} cai_pc_ordq_type;

/* Base Station Challenge Confirmation Order */
typedef struct
{
  BYTE order[6];           /* Order field */
  BYTE add_record_len[3];  /* Additional record length */
  BYTE ordq[8];            /* Order qualification code */
  BYTE authbs[18];         /* Challenge response */
  BYTE reserved[6];        /* Reserved bits */
} cai_pc_bs_chal_type;

/* Minimum size for a Paging Channel Order Message */
#define CAI_PC_ORDER_MIN  (sizeof( cai_pc_hdr_type ) -            \
                             sizeof( cai_gen_type ) +             \
                               sizeof( cai_esn_addr_type ) +      \
                                 sizeof( cai_pc_gen_ord_type ))
  
/* Maximum number of orders in a Paging Channel Order Message */
#define CAI_PC_ORDER_MAX \
  ((CAI_PC_BODY_SIZE - sizeof( cai_gen_type )) / CAI_PC_ORDER_MIN) 

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* CHANNEL ASSIGNMENT MESSAGE (see IS-95 Section 7.7.2.3.2.8)              */

/* NOTE: The following structures define the contents of the
         Channel Assignment Message following the ADDRESS field. */

/* Base of Channel Assignment Message */
typedef struct
{
  BYTE assign_mode[3];     /* Assignment mode */
  BYTE add_record_len[3];  /* Additional record length */
} cai_chnasn_base_type;

/* Types for Channel Assigment Message with Assign mode = 000 */
typedef struct
{
  BYTE assign_mode[3];     /* Assignment mode */
  BYTE add_record_len[3];  /* Additional record length */
  BYTE freq_incl[1];       /* Frequency included indicator */
  BYTE code_chan[8];       /* Code channel */
  BYTE cdma_freq[11];      /* Frequency assignment (only present if
                              freq_incl field is set to 1) */
  BYTE frame_offset[4];    /* Frame offset */
  BYTE encrypt_mode[2];    /* Message encryption mode */
} cai_chnasn_am0_type;

/* Channel Assignment Message with Assign mode = 001 */
typedef struct
{
  BYTE assign_mode[3];     /* Assignment mode */
  BYTE add_record_len[3];  /* Additional record length */
  BYTE respond[1];         /* Respond on new Access Channel indicator */
  BYTE freq_incl[1];       /* Frequency included indicator */
  BYTE cdma_freq[11];      /* Frequency assignment */
} cai_chnasn_am1_fix_type;

typedef struct
{
  BYTE pilot_pn[9];  /* Pilot PN sequence offset index */
} cai_chnasn_am1_var_type;

/* Maximum number of variable message parts that will fit into message:
             56 bits (max add_record_len value is 7 * 8 bits)
         -    2 bits (respond and freq_incl fields --> NO cdma_freq field)
         -----------
             54 bits  (remaining for pilot_pn records)
 divided by   9 bits  (size of pilot_pn field)
         -----------
              6 (max possible pilot_pn records per msg) */

#define CAI_CHNASN_AM1_MAX 6

/* Channel Assignment Message with Assign mode = 010 */
typedef struct
{
  BYTE assign_mode[3];     /* Assignment mode */
  BYTE add_record_len[3];  /* Additional record length */
  BYTE respond[1];         /* Respond on analog control channel indicator */
  BYTE reserved[7];        /* Reserved bits */
} cai_chnasn_am2_type;

/* Channel Assignment Message with Assign mode = 011 */
typedef struct
{
  BYTE assign_mode[3];     /* Assignment mode */
  BYTE add_record_len[3];  /* Additional record length */
  BYTE sid[15];            /* System identification of the analog system */
  BYTE vmac[3];            /* Voice mobile station attenuation code */
  BYTE analog_chan[11];    /* Voice channel number */
  BYTE scc[2];             /* SAT color code */
  BYTE mem[1];             /* Message encryption mode indicator */
} cai_chnasn_am3_type;

/* Minimum record size for a valid Channel Assignment Message */
#define CAI_CHN_ASN_REC_MIN  (sizeof( cai_pc_hdr_type ) -            \
                                sizeof( cai_gen_type ) +             \
                                  sizeof( cai_esn_addr_type ) +      \
                                     sizeof( cai_chnasn_am2_type ))

/* Maximum number of Channel Assignment orders that can fit in a
   Channel Assignment Message */
#define CAI_CHN_ASN_MAX  \
  ((CAI_PC_BODY_SIZE - sizeof( cai_gen_type )) / CAI_CHN_ASN_REC_MIN) 

/* Minimum size for a valid Channel Assignment Message */
#define CAI_CHN_ASN_MIN  (sizeof( cai_pc_hdr_type ) +          \
                               sizeof( cai_esn_addr_type ) +      \
                                  sizeof( cai_chnasn_am2_type ))

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* DATA BURST MESSAGE (see IS-95 Section 7.7.2.3.2.9)                      */

/* NOTE: The following structures define the contents of the 
         Data Burst Message following the ADDRESS field. */

/* Fixed part of message */
typedef struct
{
  BYTE msg_number[8];    /* Message number */
  BYTE burst_type[6];    /* Data burst type */
  BYTE num_msgs[8];      /* Number of messages in the data burst stream */
  BYTE num_fields[8];    /* Number of characters in this message */
} cai_burst_pc_fix_type;

/*  Variable part of message */
typedef struct
{
  BYTE chari[8];         /* Character */
} cai_burst_pc_var_type;

/* Maximum number of variable length message parts:
           1146 bits (maximum paging channel message body size)
         -   23 bits (msg_type + common ack fields + addr_type + addr_len)
         -   32 bits (esn --> addr_type == '001')
         -   30 bits (other Data Burst Message fields)
         -----------
           1061 bits (remaining for data burst characters)
 divided by   8 bits (size of data burst character)
         -----------
            132 (max characters per msg) */

#define CAI_PC_BURST_MAX  132

/* Minimum Data Burst Message size includes 5 for reserved bits */
#define CAI_PC_BURST_MIN  \
   (sizeof( cai_pc_hdr_type ) + sizeof( cai_esn_addr_type ) + \
      sizeof( cai_burst_pc_fix_type ) + 5)

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* AUTHENTICATION CHALLENGE MESSAGE (see IS-95 Section 7.7.2.3.2.10)       */

/* NOTE: The following structure defines the contents of the Authentication
         Challenge Message following the ADDRESS field. */

typedef struct
{
  BYTE randu[24];        /* Random challenge data */
  BYTE reserved[3];      /* Reserved bits */
} cai_pc_auth_ch_type;

/* Minimum size of Authentication Challenge Message */
#define CAI_PC_AUTH_MIN (sizeof( cai_pc_hdr_type ) +      \
                           sizeof( cai_esn_addr_type ) +  \
                             sizeof( cai_pc_auth_ch_type ))

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* SSD UPDATE MESAGE (see IS-95 Section 7.7.2.3.2.11)                      */

/* NOTE: The following structure defines the contents of the SSD Update
         Message following the ADDRESS field. */

typedef struct
{
  BYTE randssd[56];  /* Random data for the computation of SSD */
  BYTE reserved[3];  /* Reserved bits */
} cai_pc_ssd_type;

/* Minimum size of SSD Update Message */
#define CAI_PC_SSD_MIN (sizeof( cai_pc_hdr_type ) +      \
                          sizeof( cai_esn_addr_type ) +  \
                            sizeof( cai_pc_ssd_type ))

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* FEATURE NOTIFICATION MESSAGE (see IS-95 Section 7.7.2.3.2.12)           */

/* NOTE: The following structure defines the contents of the Feature
         Notification Message following the ADDRESS field. */

typedef struct
{
  BYTE release[1];      /* Origination completion indicator */
} cai_pc_feature_type;

/* Minimum length of Feature Notification Message */
#define CAI_FEATURE_MIN (sizeof( cai_pc_hdr_type ) +          \
                           sizeof( cai_esn_addr_type ) +      \
                             sizeof( cai_pc_feature_type ) +  \
                               sizeof( cai_rec_hdr_type ) +   \
                                 sizeof( cai_display_rec_var_type ) + 2)

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                   ACCESS  CHANNEL MESSAGES                              */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* REGISTRATION MESSAGE (see IS-95 Section 6.7.1.3.2.1)                    */

typedef struct
{
  BYTE msg_type[8];         /* Message type */
  cai_ac_hdr_type hdr;      /* Access Channel common header fields */
  cai_msid0_type msid;      /* Mobile station identifier fields */
  BYTE auth_mode[2];        /* Authentication mode */
  BYTE authr[18];           /* Authentication data
                               (only present if auth_mode is set to '01' */
  BYTE randc[8];            /* Random challenge value
                               (only present if auth_mode is set to '01' */
  BYTE count[6];            /* Call history parameter
                               (only present if auth_mode is set to '01' */
  BYTE reg_type[4];         /* Registration type */
  BYTE slot_cycle_index[3]; /* Slot cycle index */
  BYTE mob_p_rev[8];        /* Protocol revision of the mobile station */
  BYTE scm[8];              /* Station class mark */
  BYTE mob_term[1];         /* Mobile terminated calls accepted indicator */
} cai_reg_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* ACCESS CHANNEL ORDER MESSSAGE (see IS-95 Section 6.7.1.3.2.2)           */

/* Generic Order Message */
typedef struct
{
  BYTE msg_type[8];       /* Message type */
  cai_ac_hdr_type hdr;    /* Access Channel common header fields */
  cai_msid0_type msid;    /* Mobile station identifier fields */
  BYTE reserved[2];       /* Reserved bits */
  BYTE order[6];          /* Order code */
  BYTE add_record_len[3]; /* Additional record length */
} cai_ac_gen_ord_type;

/* Order Message with Order Qualifier */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_ac_hdr_type hdr;    /* Access Channel common header fields */
  cai_msid0_type msid;    /* Mobile station identifier fields */
  BYTE reserved[2];       /* Reserved bits */
  BYTE order[6];          /* Order code */
  BYTE add_record_len[3]; /* Additional record length */
  BYTE ordq[8];           /* Order qualification code */
} cai_ac_ordq_type;

/* Base Station Challenge Order */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_ac_hdr_type hdr;    /* Access Channel common header fields */
  cai_msid0_type msid;    /* Mobile station identifier fields */
  BYTE reserved[2];       /* Reserved bits */
  BYTE order[6];          /* Order code */
  BYTE add_record_len[3]; /* Additional record length */
  BYTE ordq[8];           /* Order qualification code */
  BYTE randbs[32];        /* Random challenge data */
} cai_ac_bs_chal_type;

/* Mobile Station Reject Orders */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_ac_hdr_type hdr;    /* Access Channel common header fields */
  cai_msid0_type msid;    /* Mobile station identifier fields */
  BYTE reserved[2];       /* Reserved bits */
  BYTE order[6];          /* Order code */
  BYTE add_record_len[3]; /* Additional record length */
  BYTE ordq[8];           /* Order qualification code */
  BYTE rej_msg_type[8];   /* Mesage type of rejected message */
} cai_ac_rej_type;

typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_ac_hdr_type hdr;    /* Access Channel common header fields */
  cai_msid0_type msid;    /* Mobile station identifier fields */
  BYTE reserved[2];       /* Reserved bits */
  BYTE order[6];          /* Order code */
  BYTE add_record_len[3]; /* Additional record length */
  BYTE ordq[8];           /* Order qualification code */
  BYTE rej_msg_type[8];   /* Mesage type of rejected message */
  BYTE rej_order[8];      /* Order type of rejected message */
  BYTE rej_ordq[8];       /* Order qualification code of rejected message */
} cai_ac_rej_ord_type;

typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_ac_hdr_type hdr;    /* Access Channel common header fields */
  cai_msid0_type msid;    /* Mobile station identifier fields */
  BYTE reserved[2];       /* Reserved bits */
  BYTE order[6];          /* Order code */
  BYTE add_record_len[3]; /* Additional record length */
  BYTE ordq[8];           /* Order qualification code */
  BYTE rej_msg_type[8];   /* Mesage type of rejected message */
  BYTE rej_record[8];     /* Record type of the rejected info record */
} cai_ac_rej_rec_type;

/* Access Channel Order Message */
typedef union
{
  cai_ac_gen_ord_type gen;
  cai_ac_ordq_type    ordq;
  cai_ac_bs_chal_type chal;
  cai_ac_rej_type     rej;
  cai_ac_rej_ord_type rej_ord;
  cai_ac_rej_rec_type rej_rec;
} cai_ac_ord_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* DATA BURST MESSAGE (see IS-95 Section 6.7.1.3.2.3)                      */

/* Fixed part of message */
typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_ac_hdr_type hdr;   /* Access Channel common header fields */
  cai_msid0_type msid;   /* Mobile station identifier fields */
  BYTE reserved[2];      /* Reserved bits */
  BYTE msg_number[8];    /* Message number within the data burst stream */
  BYTE burst_type[6];    /* Data burst type */
  BYTE num_msgs[8];      /* Number of messages in the data burst stream */
  BYTE num_fields[8];    /* Number of characters in this message */
} cai_burst_ac_fix_type;


/*  Variable part of message */
typedef WORD cai_burst_ac_var_type[8];  /* Characters */

/* Maximum number of variable length message parts */
#define CAI_AC_BURST_MAX                                     \
   ((CAI_AC_BODY_SIZE - sizeof( cai_burst_ac_fix_type )) /   \
       sizeof( cai_burst_ac_var_type ))

typedef struct
{
  cai_burst_ac_fix_type fix;
  cai_burst_ac_var_type var[CAI_AC_BURST_MAX];
} cai_burst_ac_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* ORIGINATION MESSAGE (see IS-95 Section 6.7.1.3.2.4)                     */

/* Fixed type for Origination message */
typedef struct
{
  BYTE msg_type[8];         /* Message type */
  cai_ac_hdr_type hdr;      /* Access Channel common header fields */
  cai_msid0_type msid;      /* Mobile station identifier fields */
  BYTE auth_mode[2];        /* Authentication mode */
  BYTE authr[18];           /* Authentication data
                               (only present if auth_mode is set to '01' */
  BYTE randc[8];            /* Random challenge value
                               (only present if auth_mode is set to '01' */
  BYTE count[6];            /* Call history parameter
                               (only present if auth_mode is set to '01' */
  BYTE mob_term[1];         /* Mobile terminated calls accepted indicator */
  BYTE slot_cycle_index[3]; /* Slot cycle index */
  BYTE mob_p_rev[8];        /* Protocol revision of the mobile station */
  BYTE scm[8];              /* Station class mark */
  BYTE request_mode[3];     /* Requested mode code */ 
  BYTE special_service[1];  /* Special service option indicator */
  BYTE service_option[16];  /* Requested service option for this origination
                               (only present if special_service field is
                                set to 1) */
  BYTE pm[1];               /* Privacy mode indicator */
  BYTE digit_mode[1];       /* Digit mode indicator */
  BYTE number_type[3];      /* Type of number (only present if digit_mode
                               field is set to 1) */
  BYTE number_plan[4];      /* Numbering plan (only present if digit_mode
                               field is set to 1) */
  BYTE more_fields[1];      /* More dialed digits indicator */
  BYTE num_fields[8];       /* Number of dialed digits in this message */
} cai_orig_fix_type;

typedef union
{
  BYTE char4[4];  /* 4 bit representation of digits */
  BYTE char8[8];  /* 8 bit representation of digits */
} cai_orig_var_type;

/* Maximum number of variable length message parts */
#define CAI_AC_ORIG_MAX                                \
   ((CAI_AC_BODY_SIZE - sizeof( cai_orig_fix_type ) +  \
     FSIZ( cai_orig_fix_type, authr ) +                \
     FSIZ( cai_orig_fix_type, randc ) +                \
     FSIZ( cai_orig_fix_type, count ) +                \
     FSIZ( cai_orig_fix_type, service_option ) +       \
     FSIZ( cai_orig_fix_type, number_type ) +          \
     FSIZ( cai_orig_fix_type, number_plan )) /         \
       FSIZ( cai_orig_var_type, char4 ))

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* PAGE RESPONSE MESSAGE  (see IS-95 Section 6.7.1.3.2.5)                  */

typedef struct
{
  BYTE msg_type[8];         /* Message type */
  cai_ac_hdr_type hdr;      /* Access Channel common header fields */
  cai_msid0_type msid;      /* Mobile station identifier fields */
  BYTE auth_mode[2];        /* Authentication mode */
  BYTE authr[18];           /* Authentication data
                               (only present if auth_mode is set to '01' */
  BYTE randc[8];            /* Random challenge value
                               (only present if auth_mode is set to '01' */
  BYTE count[6];            /* Call history parameter
                               (only present if auth_mode is set to '01' */
  BYTE mob_term[1];         /* Mobile terminated calls accepted indicator */
  BYTE slot_cycle_index[3]; /* Slot cycle index */
  BYTE mob_p_rev[8];        /* Protocol revision of the mobile station */
  BYTE scm[8];              /* Station class mark */
  BYTE request_mode[3];     /* Requested mode code */ 
  BYTE service_option[16];  /* Service option */
  BYTE pm[1];               /* Privacy mode indicator */
} cai_page_resp_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* AUTHENTICATION CHALLENGE RESPONSE MSG (see IS-95 Section 6.7.1.3.2.6)   */

typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_ac_hdr_type hdr;   /* Access Channel common header fields */
  cai_msid0_type msid;   /* Mobile station identifier fields */
  BYTE reserved[2];      /* Reserved bits */
  BYTE authu[18];        /* Authentication challenge response */
} cai_auth_ch_resp_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                         TRAFFIC CHANNEL MESSAGES                        */
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                FORWARD TRAFFIC CHANNEL ORDER MESSAGE                    */

/* Generic Order Message (see IS-95 Section 7.7.3.3.2.1 Order Message)     */
typedef struct
{
  BYTE msg_type[8];       /* Message type */
  cai_tc_hdr_type hdr;    /* Layer 2 header */
  BYTE use_time[1];       /* Use action time indicator */
  BYTE action_time[6];    /* Action time */
  BYTE order[6];          /* Order field */
  BYTE add_record_len[3]; /* Additional Record Length */
} cai_ftc_gen_ord_type;

/* Order Message with Order Qualifier (see IS-95 Section 7.7.4 Orders)   */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_tc_hdr_type hdr;    /* Layer 2 header */
  BYTE use_time[1];       /* Use action time indicator */
  BYTE action_time[6];    /* Action time */
  BYTE order[6];          /* Order field */
  BYTE add_record_len[3]; /* Additional Record Length */
  BYTE ordq[8];           /* Order qualification code */
} cai_ftc_ordq_type;

/* Base Station Challenge Confirmation Order (see IS-95 Section 7.7.4.1) */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_tc_hdr_type hdr;    /* Layer 2 header */
  BYTE use_time[1];       /* Use action time indicator */
  BYTE action_time[6];    /* Action time */
  BYTE order[6];          /* Order field */
  BYTE add_record_len[3]; /* Additional Record Length */
  BYTE ordq[8];           /* Order qualification code */
  BYTE authbs[18];        /* Challenge response */
  BYTE reserved[6];       /* Reserved bits */
} cai_ftc_chal_type;

/* Service Option Request Order (see IS-95 Section 7.7.4.2) */
typedef struct 
{
  BYTE msg_type[8];         /* Message type */
  cai_tc_hdr_type hdr;      /* Layer 2 header */
  BYTE use_time[1];         /* Use action time indicator */
  BYTE action_time[6];      /* Action time */
  BYTE order[6];            /* Order field */
  BYTE add_record_len[3];   /* Additional Record Length */
  BYTE ordq[8];             /* Order qualification code */
  BYTE service_option[16];  /* Service option */
} cai_ftc_so_req_type;

/* Service Option Response Order (see IS-95 Section 7.7.4.3) */
typedef struct 
{
  BYTE msg_type[8];         /* Message type */
  cai_tc_hdr_type hdr;      /* Layer 2 header */
  BYTE use_time[1];         /* Use action time indicator */
  BYTE action_time[6];      /* Action time */
  BYTE order[6];            /* Order field */
  BYTE add_record_len[3];   /* Additional Record Length */
  BYTE ordq[8];             /* Order qualification code */
  BYTE service_option[16];  /* Service option */
} cai_ftc_so_res_type;

/* Status Request Order (see IS-95 Section 7.7.4.4) */
typedef struct 
{
  BYTE msg_type[8];         /* Message type */
  cai_tc_hdr_type hdr;      /* Layer 2 header */
  BYTE use_time[1];         /* Use action time indicator */
  BYTE action_time[6];      /* Action time */
  BYTE order[6];            /* Order field */
  BYTE add_record_len[3];   /* Additional Record Length */
  BYTE ordq[8];             /* Order qualification code */
  BYTE sid[15];             /* System identification */
  BYTE nid[16];             /* Network identification */
  BYTE reserved[1];         /* Reserved bits */
} cai_ftc_stat_req_type;

/* Forward Traffic Channel Order Message */
typedef union
{
  cai_ftc_gen_ord_type gen;
  cai_ftc_ordq_type ordq;
  cai_ftc_chal_type chal;
  cai_ftc_so_req_type so_req;
  cai_ftc_so_res_type so_res;
  cai_ftc_stat_req_type stat_req;
} cai_ftc_ord_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* AUTHENTICATION CHALLENGE MESSAGE (see IS-95 Section 7.7.3.3.2.2)        */
typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
  BYTE randu[24];        /* Random challenge data */
  BYTE reserved[7];      /* Reserved bits */  
} cai_auth_ch_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* ALERT WITH INFORMATION MESSAGE (see IS-95 Section 7.7.3.3.2.3)          */

/* Fixed part of message */
typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
} cai_alert_fix_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* DATA BURST MESSAGE (see IS-95 Section 7.7.3.3.2.4)                      */

/* Fixed part of message */
typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
  BYTE msg_number[8];    /* Number of message in the data stream burst */
  BYTE burst_type[6];    /* Type of data burst */
  BYTE num_msgs[8];      /* Number of messages in the data stream burst */
  BYTE num_fields[8];    /* Number of characters in field */
} cai_burst_tc_fix_type;

/* Variable part of message */
typedef WORD cai_burst_tc_var_type[8];
  /* Characters for one way data burst */

/* Maximum number of variable parts of message */
#define CAI_FWD_TC_BURST_MAX  TC_FWD_MAX( cai_burst_tc )

typedef struct
{
  cai_burst_tc_fix_type fix;
  cai_burst_tc_var_type var[CAI_FWD_TC_BURST_MAX];
} cai_fwd_tc_burst_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* HANDOFF DIRECTION MESSAGE (see IS-95 Section 7.7.3.3.2.5)               */

typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
  BYTE use_time[1];      /* Indicator of whether to use the ACTION_TIME */
  BYTE action_time[6];   /* Action time */
  BYTE hdm_seq[2];       /* Handoff Direction Message sequence number */
  BYTE srch_win_a[4];    /* Search window size for the Active Set and the
                            Candidate Set */
  BYTE t_add[6];         /* Pilot detection threshold */
  BYTE t_drop[6];        /* Pilot drop threshold */
  BYTE t_comp[4];        /* Active set vs Candidate set comparison 
                            threshold */
  BYTE t_tdrop[4];       /* Drop timer value */
  BYTE frame_offset[4];  /* Frame offset */
  BYTE private_lcm[1];   /* Private long code mask indicator */
  BYTE reset_l2[1];      /* Reset acknowledgement procedures command */
  BYTE encrypt_mode[2];  /* Message encryption mode */
  BYTE freq_incl[1];     /* Indicator of whether the CDMA channel frequency
                            is included in the message */
} cai_ho_dir_fix_type;

typedef struct
{
  BYTE cdma_freq[11];    /* Frequency assignment of CDMA channel */
} cai_ho_dir_freq_type;

typedef struct
{
  BYTE pilot_pn[9];      /* Pilot PN sequence offset index */
  BYTE pwr_comb_ind[1];  /* Power control symbol combining indicator */
  BYTE code_chan[8];     /* Code channel index */
} cai_ho_dir_var_type;

/* Minimum size of variable part of message */
#define CAI_HO_DIR_MIN  sizeof( cai_ho_dir_var_type )

/* Maximum number of variable types in message */
#define CAI_HO_DIR_MAX  \
  ((CAI_FWD_TC_MSG_BODY_SIZE - sizeof( cai_ho_dir_fix_type )) /  \
      CAI_HO_DIR_MIN )

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* ANALOG HANDOFF DIRECTION MESSAGE (see IS-95 Section 7.7.3.3.2.6)        */

typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
  BYTE use_time[1];      /* Indicator of whether to use the ACTION_TIME */
  BYTE action_time[6];   /* Action time */
  BYTE sid[15];          /* System ID of analog system */
  BYTE vmac[3];          /* Voice mobile station attenuation code */
  BYTE analog_chan[11];  /* Analog voice channel number */
  BYTE scc[2];           /* SAT color code */
  BYTE mem[1];           /* Message encryption mode indicator */
} cai_fm_ho_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* IN-TRAFFIC SYSTEM PARAMETER MESSAGE (see IS-95 Section 7.7.3.3.2.7)     */

typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
  BYTE sid[15];          /* System identification */
  BYTE nid[16];          /* Network identification */
  BYTE srch_win_a[4];    /* Characteristic field for Active Pilot Set */
  BYTE srch_win_n[4];    /* Characteristic field for Neighbor Pilot Set */
  BYTE srch_win_r[4];    /* Characteristic field for the Remaining set */
  BYTE t_add[6];         /* Pilot detection threshold */
  BYTE t_drop[6];        /* Pilot drop threshold */
  BYTE t_comp[4];        /* Active Set vs Candidate set comparsion
                            threshold */
  BYTE t_tdrop[4];       /* Drop timer value */
  BYTE nghbr_max_age[4]; /* Neighbor set member maximum age for retention */
  BYTE reserved[4];      /* Reserved bits */
} cai_tc_sysparm_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* NEIGBHOR LIST UPDATE MESSAGE (see IS-95 Section 7.7.3.3.2.8)            */

/* Fixed part of message */
typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
  BYTE pilot_inc[4];     /* Pilot PN sequence offset index increment */
} cai_nlu_fix_type;

/* Variable part of message */
typedef struct
{
  BYTE nghbr_pn[9];      /* Neighbor pilot PN sequence offset index */
} cai_nlu_var_type;

/* Maximum number of neighbors in message */
#define CAI_NLU_MAX  TC_FWD_MAX( cai_nlu )

typedef struct
{
  cai_nlu_fix_type fix;
  cai_nlu_var_type var[CAI_NLU_MAX];
} cai_nlu_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/*                SEND BURST DTMF MESAGE                                   */
/* (See IS-95 Section 7.7.3.3.2.9 Send Burst DTMF Message)                 */

typedef struct
{
  BYTE msg_type[8];        /* Message type */
  cai_tc_hdr_type hdr;     /* Layer 2 header */
  BYTE num_digits[8];      /* Number of DTMF digits in message */
  BYTE dtmf_on_length[3];  /* DTMF pulse width code */
  BYTE dtmf_off_length[3]; /* DTMF interdigit interval code */
} cai_sbdtmf_fix_type;

typedef WORD cai_sbdtmf_var_type[4]; 

#define CAI_SBDTMF_MAX 255 
  /* Max number of digits is constrained by size of the num_digits field */

typedef struct
{
  cai_sbdtmf_fix_type fix;
  cai_sbdtmf_var_type var[CAI_SBDTMF_MAX];
} cai_sbdtmf_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* POWER CONTROL PARAMETERS MESSAGE (see IS-95 Section 7.7.3.3.2.10)       */

typedef struct
{
  BYTE msg_type[8];          /* Message type */
  cai_tc_hdr_type hdr;       /* Layer 2 header */
  BYTE pwr_rep_thresh[5];    /* Power control reporting threshold */
  BYTE pwr_rep_frames[4];    /* Power control reporting frame count */
  BYTE pwr_thresh_enable[1]; /* Threshold report mode indicator */
  BYTE pwr_period_enable[1]; /* Threshold report mode indicator */
  BYTE pwr_rep_delay[5];     /* Power Measurement report delay */
  BYTE reserved[7];          /* Reserved bits */
} cai_pwr_ctl_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* RETRIEVE PARAMETERS MESSAGE (see IS-95 Section 7.7.3.3.2.11)            */

typedef struct
{
  BYTE msg_type[8];     /* Message type */
  cai_tc_hdr_type hdr;  /* Layer 2 header */
} cai_ret_parms_fix_type;

typedef struct
{
  BYTE parameter_id[16];  /* Parameter identification */
} cai_ret_parms_var_type;

#define CAI_RET_PARMS_MAX  TC_FWD_MAX( cai_ret_parms )
  /* Maximum number of variable type that will fit in message */

typedef struct
{
  cai_ret_parms_fix_type fix;
  cai_ret_parms_var_type var[CAI_RET_PARMS_MAX];
} cai_ret_parms_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* SET PARAMETERS MESSAGE (see IS-95 Section 7.7.3.3.2.12)                 */

typedef struct
{
  BYTE msg_type[8];     /* Message type */
  cai_tc_hdr_type hdr;  /* Layer 2 header */
} cai_set_parm_fix_type;
  
typedef struct
{
  BYTE parameter_id[16];   /* Identification for parameter */
  BYTE parameter_len[10];  /* length in bits of returned parameter */
  BYTE parameter[1];       /* First bit of parameter */
} cai_set_parm_var_type;

/* Maximum number of variable types in message */
#define CAI_SET_PARM_MAX (CAI_FWD_TC_MSG_BODY_SIZE -                       \
                          sizeof( cai_set_parm_fix_type )) /               \
                          ( FSIZ( cai_set_parm_var_type, parameter_id ) +  \
                            FSIZ( cai_set_parm_var_type, parameter_len ) + \
                            CAI_PARM_MIN_LEN)

typedef struct
{
  cai_set_parm_fix_type fix;
  cai_set_parm_var_type var;
} cai_set_parm_type;


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* SSD UPDATE MESSAGE (see IS-95 Section 7.7.3.3.2.13)                     */

typedef struct
{
  BYTE msg_type[8];     /* Message type */
  cai_tc_hdr_type hdr;  /* Layer 2 header */
  BYTE randssd[56];     /* Random data */
  BYTE reserved[7];     /* Reserved bits */
} cai_ssd_up_type;

  
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* FLASH WITH INFORMATION MESSAGE (see IS-95 Section 7.7.3.3.2.14)         */

/* Use cai_alert_fix_type from Alert With Information record type
   definition above */

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* MOBILE STATION REGISTERED MESSAGE (see IS-95 Section 7.7.3.3.2.15)      */

typedef struct
{
  BYTE msg_type[8];     /* Message type */
  cai_tc_hdr_type hdr;  /* Layer 2 header */
  BYTE sid[15];         /* System identification */
  BYTE nid[16];         /* Network identification */
  BYTE reg_zone[12];    /* Registration zone */
  BYTE total_zones[3];  /* Number of registration zones to be retained */
  BYTE zone_timer[3];   /* Zone timer length */
  BYTE mult_sids[1];    /* Multiple SID storage indicator */
  BYTE mult_nids[1];    /* Multiple NID storage indicator */
  BYTE base_lat[22];    /* Base station latitude */
  BYTE base_long[23];   /* Base station longitude */
  BYTE reg_dist[11];    /* Registration distance */
  BYTE reserved[4];     /* Reserved bits */
} cai_registered_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* REVERSE TRAFFIC CHANNEL ORDER MESSAGE (see IS-95 Section 6.7.2.3.2.1)   */

/* Generic Order message */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_tc_hdr_type hdr;    /* Layer 2 header */
  BYTE order[6];          /* Order field */
  BYTE add_record_len[3]; /* Additional Record Length */
} cai_rtc_gen_ord_type;

/* Order with order qualifier */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_tc_hdr_type hdr;    /* Layer 2 header */
  BYTE order[6];          /* Order field */
  BYTE add_record_len[3]; /* Additional Record Length */
  BYTE ordq[8];           /* Order qualifier */
} cai_rtc_ordq_type;

/* Base Station Challenge Order (see IS-95 Section 6.7.3.1) */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_tc_hdr_type hdr;    /* Layer 2 header */
  BYTE order[6];          /* Order field */
  BYTE add_record_len[3]; /* Additional Record Length */
  BYTE ordq[8];           /* Order qualifier */
  BYTE randbs[32];        /* Random Challenge data */
} cai_rtc_bs_chal_type;

/* Service Option Request Order and Service Option Response Order
   (see IS-95 Sections 6.7.3.2 and 6.7.3.3) */
typedef struct 
{
  BYTE msg_type[8];         /* Message type */
  cai_tc_hdr_type hdr;      /* Layer 2 header */
  BYTE order[6];            /* Order field */
  BYTE add_record_len[3];   /* Additional Record Length */
  BYTE ordq[8];             /* Order qualifier */
  BYTE service_option[16];  /* Service option */
} cai_rtc_so_type;

/* Mobile Station Reject Order (see IS-95 Section 6.7.3.4) */

/* Fixed part of Mobile Station Reject Order */
typedef struct 
{
  BYTE msg_type[8];       /* Message type */
  cai_tc_hdr_type hdr;    /* Layer 2 header */
  BYTE order[6];          /* Order field */
  BYTE add_record_len[3]; /* Additional Record Length */
  BYTE ordq[8];           /* Order qualifier */
  BYTE rej_msg_type[8];   /* Message type of rejected message */
} cai_rtc_rej_fixed_type;

/* Only present if the rejected message was an Order Message */
typedef struct 
{
  BYTE rej_order[8];  /* Order type of rejected message */
  BYTE rej_ordq[8];   /* Order qualification code of rejected message */
} cai_rtc_rej_order_type;

/* Only present if the rejected message was a Retrieve Parameters Message
   or a Set Parameters Message */
typedef struct 
{
  BYTE rej_param_id[16];  /* Parameter id of the rejected parameter */
} cai_rtc_rej_param_type;

/* Only present if the rejected message was an Alert with Information
   Message or a Flash with Information Message */
typedef struct 
{
  BYTE rej_record[8];  /* Record type of the rejected information record */
} cai_rtc_rej_record_type;

typedef struct
{
  cai_rtc_rej_fixed_type fix;
  union {
    cai_rtc_rej_order_type  order;
    cai_rtc_rej_param_type  param;
    cai_rtc_rej_record_type rec;
  } var;
} cai_rtc_rej_type;

/* Reverse Traffic Channel Order Message */
typedef union
{
  cai_rtc_gen_ord_type  gen;
  cai_rtc_ordq_type     ordq;
  cai_rtc_bs_chal_type  chal;
  cai_rtc_so_type       so;
  cai_rtc_rej_type      rej;
} cai_rtc_ord_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* AUTHENTICATION CHALLENGE RESPONSE MSG (see IS-95 Section 6.7.2.3.2.2)   */

typedef struct
{
  BYTE msg_type[8];     /* Message type */
  cai_tc_hdr_type hdr;  /* Layer 2 header */
  BYTE authu[18];       /* Authentication challenge response */
} cai_auth_type;


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* FLASH WITH INFORMATION MESSAGE (see IS-95 Section 6.7.2.3.2.3)          */

typedef struct
{
  BYTE msg_type[8];     /* Message type */
  cai_tc_hdr_type hdr;  /* Layer 2 header */
} cai_flash_fix_type;


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* DATA BURST MESSAGE (see IS-95 Section 6.7.2.3.2.4)                      */

/* Use cai_tc_burst_fix_type and cai_burst_tc_var_type from Forward
   Traffic Channel Message recordtype definitions above */

/* Maximum number of variable parts of message */
#define CAI_REV_TC_BURST_MAX  TC_REV_MAX( cai_burst_tc )

typedef struct
{
  cai_burst_tc_fix_type fix;
  cai_burst_tc_var_type var[CAI_REV_TC_BURST_MAX];
} cai_rev_tc_burst_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* PILOT STRENGTH MEASUREMENT MESSAGE (see IS-95 Section 6.7.2.3.2.5)      */

typedef struct
{
  BYTE msg_type[8];           /* Message type */
  cai_tc_hdr_type hdr;        /* Layer 2 header */
  BYTE ref_pn[9];             /* Time reference PN sequence offset */
  BYTE pilot_strength[6];     /* Pilot strength */
  BYTE keep[1];               /* Keep pilot indicator */
} cai_pil_str_fix_type;

typedef struct
{
  BYTE pilot_pn_phase[15]; /* Pilot measured phase */
  BYTE pilot_strength[6];  /* Pilot strength */
  BYTE keep[1];            /* Keep pilot indicator */
} cai_pil_str_var_type;

/* Maximum number of variable parts of message */
#define CAI_PIL_STR_MAX TC_REV_MAX( cai_pil_str ) 

typedef struct
{
  cai_pil_str_fix_type fix;
  cai_pil_str_var_type var[CAI_PIL_STR_MAX];
} cai_pil_str_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/*               POWER MEASUREMENT REPORT                                  */
/* (See IS-95 Section 6.7.2.3.2.6 Power Measurement Report Message)        */

typedef struct
{
  BYTE msg_type[8];          /* Message type */
  cai_tc_hdr_type hdr;       /* Layer 2 header */
  BYTE errors_detected[5];   /* Number of frame errors detected */
  BYTE pwr_meas_frames[10];  /* Number of Forward Traffic Channel frames
                                in the measurement period */
  BYTE last_hdm_seq[2];      /* Handoff Direction Message sequence number */
  BYTE num_pilots[4];        /* number of pilots */
} cai_pwr_rpt_fix_type;

typedef struct
{
  BYTE pilot_strength[6];         /* pilot strength */
} cai_pwr_rpt_var_type;

#define CAI_PWR_MAX 15 
  /* Max number of pilot_strength records is constrained by size
     of the num_pilots field */

typedef struct
{
  cai_pwr_rpt_fix_type fix;
  cai_pwr_rpt_var_type var[CAI_PWR_MAX];
} cai_pwr_rpt_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* SEND BURST DTMF MESSAGE (see IS-95 Section 6.7.2.3.2.7)                 */

/* Use cai_sbdtmf_type from Forward Traffic Channel Message record type
   definitions above */

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* STATUS MESSAGE (see IS-95 Section 6.7.2.3.2.8)                          */

typedef struct
{
  BYTE msg_type[8];     /* Message type */
  cai_tc_hdr_type hdr;  /* Layer 2 header */
  BYTE record_type[8];  /* Information record type */
  BYTE record_len[8];   /* Information record length */
} cai_status_fix_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* ORIGINATION CONTINUATION MESSAGE (see IS-95 Section 6.7.2.3.2.9)        */

typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
  BYTE digit_mode[1];    /* Digit mode indicator */
  BYTE num_fields[8];    /* Number of dialed digits in this message */
} cai_orig_c_fix_type;

typedef union
{
  BYTE digit4[4];  /* 4 bit representation of the digit */
  BYTE digit8[8];  /* ASCII representation of the digit */
} cai_orig_c_var_type;

#define CAI_ORIG_C_MAX  255
  /* Maximum number of digits is limited by the length of the num_digits
     field */

typedef struct
{
  cai_orig_c_fix_type fix;
  cai_orig_c_var_type var;
} cai_orig_c_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* HANDOFF COMPLETION MESSAGE (see IS-95 Section 6.7.2.3.2.10)             */

typedef struct
{
  BYTE msg_type[8];      /* Message type */
  cai_tc_hdr_type hdr;   /* Layer 2 header */
  BYTE last_hdm_seq[2];  /* Handoff Direction Message Sequence Number */
} cai_comp_fix_type;

typedef struct
{
  BYTE pilot_pn[9];      /* Pilot PN sequence offset */
} cai_comp_var_type;

#define CAI_MAX_COMP TC_REV_MAX( cai_comp )

typedef struct
{
  cai_comp_fix_type fix;
  cai_comp_var_type var[CAI_MAX_COMP];
} cai_comp_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* PARAMETERS RESPONSE MESSAGE (see IS-95 Section 6.7.2.3.2.11)            */

typedef struct
{
  BYTE msg_type[8];     /* Message type */
  cai_tc_hdr_type hdr;  /* Layer 2 header */
} cai_parm_rsp_fix_type;
  
typedef struct
{
  BYTE parameter_id[16];   /* Identification for parameter */
  BYTE parameter_len[10];  /* length in bits of returned parameter */
  BYTE parameter[1];       /* First bit of parameter */
} cai_parm_rsp_var_type;

/* Maximum number of variable length message parts */
#define CAI_PARM_RSP_MAX (CAI_REV_TC_MSG_BODY_SIZE -            \
                          sizeof( cai_parm_rsp_fix_type )) /    \
                            (FSIZ( cai_parm_rsp_var_type, parameter_id ) +  \
                             FSIZ( cai_parm_rsp_var_type, parameter_len ) + \
                             CAI_PARM_MIN_LEN)

typedef struct
{
  cai_parm_rsp_fix_type fix;
  cai_parm_rsp_var_type var;
} cai_parm_rsp_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* The following data types are used by the Transmit and Receive tasks for
   message storage */

/* Sync Channel Message type */
typedef struct
{
  BYTE sframe_num;             /* Subframe for message */
  BYTE length;                 /* Length BYTE */
  BYTE body[CAI_SC_EXT_SIZE];  /* Message body -- including CRC */
} cai_sc_ext_type;

/* Paging Channel Message type */
typedef struct
{
  QWORD frame_num;            /* Frame number */
  BYTE length;                /* Message length */
  BYTE body[CAI_PC_EXT_SIZE]; /* Message body including CRC */
} cai_pc_ext_type;
 
/* Access Channel Message type */
typedef struct
{
  QWORD frame_num;              /* Frame number */
  BYTE length;                  /* Message Length */
  BYTE body[CAI_AC_EXT_SIZE];   /* Message body including CRC */
} cai_ac_ext_type; 

/* Forward Traffic Channel Message type */
typedef struct
{
  QWORD frame_num;                   /* Frame number */
  BYTE length;                       /* Message length */
  BYTE body[CAI_FWD_TC_EXT_SIZE];    /* Message body including CRC */
} cai_fwd_tc_ext_type;

/* Reverse Traffic Channel Message type */
typedef struct
{
  QWORD frame_num;                   /* Frame number */
  BYTE length;                       /* Message length */
  BYTE body[CAI_REV_TC_EXT_SIZE];    /* Message body including CRC */
} cai_rev_tc_ext_type;

/* Union of Receive types */
typedef union
{
  cai_sc_ext_type     sc;
  cai_pc_ext_type     pc;
  cai_fwd_tc_ext_type tc;
} cai_rx_msg_type;

/* Union of transmit types */

typedef union
{
  cai_ac_ext_type     ac; 
  cai_rev_tc_ext_type tc;
} cai_tx_msg_type;

/*===========================================================================

                      FUNCTION DECLARATIONS

===========================================================================*/

#endif /* CAI_H */


