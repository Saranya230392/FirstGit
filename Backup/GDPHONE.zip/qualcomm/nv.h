#ifndef _NV_H
#define _NV_H

typedef unsigned long  QWORD[ 2 ];

/*==========================================================================

              N V    T A S K    H E A D E R    F I L E

DESCRIPTION

  This header file contains all the definitions necessary for any task
  to interface with the Non Volatile Memory task, in order to access
  the NV EEPROM to read, write, and start.

Copyright (c) 1990,1991,1992 by QUALCOMM Incorporated.  All Rights Reserved.
===========================================================================*/

/*===========================================================================

                           EDIT HISTORY FOR FILE

$Header:   Z:/CMtest/CMtest(3.61)/WInclude/Nv.h-arc   1.2   Apr 25 2000 13:47:10   a111603  $
   
when       who     what, where, why
--------   ---     ----------------------------------------------------------
08/23/95   ras     added DIR_NAME
08/17/95   jmk     Took out the T_SP conditionally excluded stuff.  Kept in
                   the T_SP added at the same place as T_DM.
08/11/95   jmk     Added T_SP conditional compilation (exclude rex, protos, etc)
08/08/95   ras     lint cleanup, IMSI, bad pwr down structures
07/17/95   ras     added support for sms
06/11/95   ras     added support for 20 new rf & ui items
05/22/95   ras     Gemini back to 102 stored numbers
05/12/95   ras     rf item additions + NV_LCD_I - NV_BRIGHT_I
05/09/95   ras     Initial next generation nv checkin
12/17/93   jjw     Added DM address item
11/08/93   jjw     uncommented the External Port mode values
11/04/93   jjw     Fixed a boo-boo (sony_atten_2)
08/22/93   jjw     Added data services items and several other items
05/14/93   jjw     Added compile-time directive for Beta II target
05/10/93   jjw     Changed FM_RSSI to a min_max type
04/06/93   jjw     Major upgrade: Added numerous new items, changed numerous 
                   items, removed ESN from poke, disallowed changing ESN after
                   it becomes non-zero
02/05/93   jjw     Added new items: 1) FM TX power levels (8) and 2) V Battery
                   minimum and maximum values.
10/29/92    ip     Modified items: err_log, sid_acq, auto_answer,
                   auto_redial, page_set, stack_idx.  Added items:
                   unit_id, name_nam, roam_timer, freq_adj.
10/07/92    ip     Removed boot_err item.
07/18/92    ip     Release after code review and initial unit test.
07/03/92    ip     Released per CAI 2.0 plus several items changes.
04/10/92    ip     Changes after code review and per CAI Rev 1.14.
02/24/92    ip     First porting of file from brassboard to DMSS.

===========================================================================*/

/*===========================================================================
 
                           INCLUDE FILES

===========================================================================*/

//#include "targetg.h"
//#include "target.h"
//#include "comdef.h"
//#include "rex.h"
//#include "queue.h"
//#include "qw.h"
//#include "lgic.h"


#pragma pack(1)

/*===========================================================================
 
                           DATA DECLARATIONS

===========================================================================*/
//sya----start
#define     NV_MAX_DDD_DIGITS     4 
//sya----end

/*  Signals declarations.                                                  */

#define  NV_RPT_TIMER_SIG     0x0001      /* Watchdog report signal */
#define  NV_WRITE_TIMER_SIG   0x0002      /* Write timer signal */
#define  NV_CMD_Q_SIG         0x0004      /* Command queue signal */
#define  NV_ERR_LOG_SIG       0x0008      /* error log buffer siganl */

/* Reserved signals.                                                       */

#define  NV_RSVD_0010_SIG     0x0010
#define  NV_RSVD_0020_SIG     0x0020
#define  NV_RSVD_0040_SIG     0x0040
#define  NV_RSVD_0080_SIG     0x0080
#define  NV_RSVD_0100_SIG     0x0100
#define  NV_RSVD_0200_SIG     0x0200
#define  NV_RSVD_0400_SIG     0x0400
#define  NV_RSVD_0800_SIG     0x0800

/* Signals 0x1000 thru 0x8000 are system wide and defined in task.h.       */

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/*  Command codes when command is issued to the NV task.                   */

//typedef enum {
#define  NV_READ_F   0          /* Read item */
#define  NV_WRITE_F  1          /* Write item */
#define  NV_PEEK_F   2          /* Peek at a location */
#define  NV_POKE_F   3          /* Poke into a location */
#define  NV_FREE_F   4          /* Free an nv memory allocation */

//sya----start
#define  NV_CHKPNT_DIS_F  5
#define  NV_CHKPNT_ENA_F  6
#define  NV_OTASP_COMMIT_F  7
//sya----end
typedef WORD nv_func_enum_type;

/*  Returned status codes for requested operation.                         */

//typedef enum {
#define  NV_DONE_S       0     /* Request completed okay */
#define  NV_BUSY_S       1     /* Request is queued */
#define  NV_BADCMD_S     2     /* Unrecognizable command field */
#define  NV_FULL_S       3     /* The NVM is full */
#define  NV_FAIL_S       4     /* Command failed, reason other than NVM was full */
#define  NV_NOTACTIVE_S  5     /* Variable was not active */
#define  NV_BADPARM_S    6     /* Bad parameter in command block */
#define  NV_READONLY_S   7     /* Parameter is write-protected and thus read only */
#define  NV_BADTG_S      8     /* Item not valid for Target */
#define  NV_NOMEM_S      9     /* free memory exhausted */
#define  NV_NOTALLOC_S   10    /* address is not a valid allocation */
typedef WORD nv_stat_enum_type;

/* IO operation type */
//typedef enum {
#define  NV_WRITE_IO     0     /* io write operation */
#define  NV_READ_IO      1     /* io read operation */
typedef WORD nv_io_enum_type;


/*=========================================================================*/

/* Enumerators of items to access.  Each command to the NV task specifies  */
/* the command type with an emumerator from the list below.                */

//typedef enum {

/*-------------------------------------------------------------------------*/

/* Electronic Serial Number.                                               */

#define  NV_ESN_I   0          /* Electronic Serial Number */
#define  NV_ESN_CHKSUM_I        1      /* Electronic Serial Number checksum */

/*-------------------------------------------------------------------------*/

/* NV version numbers.                                                     */

#define  NV_VERNO_MAJ_I        2         /* Major version number */
#define  NV_VERNO_MIN_I        3         /* Minor version number */

/*-------------------------------------------------------------------------*/

/* Permanent physical station configuration parameters.                    */

#define  NV_SCM_I        4               /* SCMp */
#define  NV_SLOT_CYCLE_INDEX_I        5  /* Slot cycle index */
#define  NV_MOB_CAI_REV_I        6       /* Mobile CAI revision number */
#define  NV_MOB_FIRM_REV_I        7      /* Mobile firmware revision number */
#define  NV_MOB_MODEL_I        8         /* Mobile model */
#define  NV_CONFIG_CHKSUM_I        9     /* Checksum of physical configuration parameters */

/*-------------------------------------------------------------------------*/

/* Permanent general NAM items.  Each of these is associated with a        */
/* particular NAM (there are up to four NAMs per unit).  The NAM id is     */
/* specified in the request.  Certain analog parameters are truly          */
/* associated with the MIN        0 but since there is only one MIN per NAM        */
/* in analog mode they are defined as a NAM item.                          */

#define  NV_PREF_MODE_I        10         /* Digital/Analog mode preference */ /* 10 */
#define  NV_CDMA_PREF_SERV_I        11    /* CDMA preferred serving system (A/B) */
#define  NV_ANALOG_PREF_SERV_I        12  /* Analog preferred serving system (A/B) */

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* The NAM parameters in the block below are protected by the NAM          */
/* checksum and can only be programmed via service programming.            */
/* The NAM parameters in the block above are not protected by checksum     */
/* and may be changed by the user 'on the fly'.                            */

#define  NV_CDMA_SID_LOCK_I        13     /* CDMA SID(s) to lockout */
#define  NV_CDMA_SID_ACQ_I        14      /* CDMA SID to acquire */
#define  NV_ANALOG_SID_LOCK_I        15   /* ANALOG SID(s) to lockout */
#define  NV_ANALOG_SID_ACQ_I        16    /* ANALOG SID to acquire */
#define  NV_ANALOG_FIRSTCHP_I        17   /* Analog FIRSTCHPp */
#define NV_ANALOG_HOME_SID_I        18   /* Analog HOME_SIDp */
#define NV_ANALOG_REG_I        19        /* Analog registration setting */ 
#define NV_PCDMACH_I        20           /* Primary CDMA channel */ /* #22 */
#define NV_SCDMACH_I        21           /* Secondary CDMA channel */
#define NV_PPCNCH_I        22            /* Primary PCN channel */
#define NV_SPCNCH_I        23            /* Secondary PCN channel */
#define NV_NAM_CHKSUM_I        24        /* NAM checksum */

/*-------------------------------------------------------------------------*/

/* Authentication NAM items.  Each of these is associated with a NAM       */
/* authentication (there are up to four NAMs per unit).  The NAM id is     */
/* specified in the request.                                               */

#define NV_A_KEY_I        25             /* Authentication A key */
#define NV_A_KEY_CHKSUM_I        26      /* Authentication A key checksum */
#define NV_SSD_A_I        27             /* SSD_Asp */
#define NV_SSD_A_CHKSUM_I        28      /* SSD_Asp checksum */
#define NV_SSD_B_I        29             /* SSD_Bsp */ 
#define NV_SSD_B_CHKSUM_I        30      /* SSD_Bsp checksum */ /* 33 */
#define NV_COUNT_I        31             /* COUNTsp */

/*-------------------------------------------------------------------------*/

/* MIN items.  Each of these is associated with a particular MIN within    */
/* the NAM (there are now up to 2 MINs per NAM).  The MIN id itself is     */
/* specified in the request.  When operating in analog mode the first MIN  */
/* is the one and only meaningfull one.                                    */

#define NV_MIN1_I        32              /* MIN1p */
#define NV_MIN2_I        33              /* MIN2p */
#define NV_MOB_TERM_HOME_I        34     /* CDMA MOB_TERM_HOMEp registration flag */
#define NV_MOB_TERM_FOR_SID_I        35  /* CDMA MOB_TERM_FOR_SIDp registration flag */
#define NV_MOB_TERM_FOR_NID_I        36  /* CDMA MOB_TERM_FOR_NIDp registration flag */
#define NV_ACCOLC_I        37            /* ACCOLCp */
#define NV_SID_NID_I        38           /* CDMA SID/NID pairs */
#define NV_MIN_CHKSUM_I        39        /* MIN checksum */ 

/*-------------------------------------------------------------------------*/

/* Operational NAM settings.                                               */

#define NV_CURR_NAM_I        40          /* Current NAM */ /* 40 */
#define NV_ORIG_MIN_I        41          /* Call origination MIN within NAM */
#define NV_AUTO_NAM_I        42          /* Select NAM automatically on roaming */
#define NV_NAME_NAM_I        43          /* A user selectable name for each NAM */

/*-------------------------------------------------------------------------*/

/* Semi-permanent analog registration parameters.                          */

#define NV_NXTREG_I        44            /* NXTREGsp */
#define NV_LSTSID_I        45            /* SIDsp (last SID registered) */
#define NV_LOCAID_I        46            /* LOCAIDsp */
#define NV_PUREG_I        47             /* PUREGsp */

/*-------------------------------------------------------------------------*/

/* Semi-permanent CDMA registration and channel parameters.                */

#define NV_ZONE_LIST_I        48         /* ZONE_LISTsp */
#define NV_SID_NID_LIST_I        49      /* SID_NID_LISTsp */
#define NV_DIST_REG_I        50          /* Distance registration variables */ /* 55 */
#define NV_LAST_CDMACH_I        51       /* Last CDMA channel acquired */

/*-------------------------------------------------------------------------*/

/* Timers        5 each associated with a specific NAM.                            */

#define NV_CALL_TIMER_I        52     /* Last call time */
#define NV_AIR_TIMER_I        53      /* Air time (resettable cummulative call timer) */
#define NV_ROAM_TIMER_I        54     /* Roam time (resettable cummulative roam timer) */
#define NV_LIFE_TIMER_I        55     /* Life time (non-resettable cumm. call timer) */

/*-------------------------------------------------------------------------*/

/* Run timer        5 independent of NAM.                                          */

#define NV_RUN_TIMER_I        56      /* Run timer (time hardware has been running) */

/*-------------------------------------------------------------------------*/

/* Memory (speed) dial numbers.                                            */

#define NV_DIAL_I        57           /* Speed dial number */
#define NV_STACK_I        58          /* Call stack number */
#define NV_STACK_IDX_I        59      /* Call stack last number index */

/*-------------------------------------------------------------------------*/

/* Telephone pages.                                                        */

#define NV_PAGE_SET_I        60       /* Page setting */ /* 60 */
#define NV_PAGE_MSG_I        61      /* Page message and time */

/*-------------------------------------------------------------------------*/

/* Volumes.                                                                */

#define NV_EAR_LVL_I        62        /* Handset ear piece volume level */
#define NV_SPEAKER_LVL_I        63    /* Handsfree speaker volume level */
#define NV_RINGER_LVL_I        64     /* Ringer volume level */
#define NV_BEEP_LVL_I        65       /* Key beep volume level */

/*-------------------------------------------------------------------------*/

/* Tones.                                                                  */

#define NV_CALL_BEEP_I        66      /* One minute call beeper select */
#define NV_CONT_KEY_DTMF_I        67  /* Continuous keypad DTMF tones select */
#define NV_CONT_STR_DTMF_I        68  /* Continuous string (memory) DTMF tones select */
#define NV_SVC_AREA_ALERT_I        69 /* Service area enter/exit alert select */
#define NV_CALL_FADE_ALERT_I        70/* Call fade alert select */ /* 70 */

/*-------------------------------------------------------------------------*/

/* Various phone settings.                                                 */

#define NV_BANNER_I        71         /* Idle banner to display */
#define NV_LCD_I        72            /* Display brightness setting */
#define NV_AUTO_POWER_I        73     /* Auto power settings (power savings) */
#define NV_AUTO_ANSWER_I        74    /* Auto answer setting */
#define NV_AUTO_REDIAL_I        75    /* Auto redial setting */
#define NV_AUTO_HYPHEN_I        76    /* Auto hyphen setting */
#define NV_BACK_LIGHT_I        77     /* Backlighting manual/auto mode */
#define NV_AUTO_MUTE_I        78      /* Auto radio mute setting */

/*-------------------------------------------------------------------------*/

/* Locks and restrictions values.                                          */

#define NV_MAINTRSN_I        79       /* Base station maintance required reason */
#define NV_LCKRSN_P_I        80       /* Base station lock reason        0 until power cycled */ /* 80 */
#define NV_LOCK_I        81           /* Indicator of whether user locked the phone */
#define NV_LOCK_CODE_I        82      /* Lock code string */
#define NV_AUTO_LOCK_I        83      /* Auto lock setting */
#define NV_CALL_RSTRC_I        84     /* Call restrictions */
#define NV_SEC_CODE_I        85       /* Security code */
#define NV_HORN_ALERT_I        86     /* Horn alert setting */

/*-------------------------------------------------------------------------*/

/* Error log.                                                              */

#define NV_ERR_LOG_I        87        /* Error log */

/*-------------------------------------------------------------------------*/

/* Miscellaneous items.                                                    */

#define NV_UNIT_ID_I        88        /* unit hardware id */
#define NV_FREQ_ADJ_I        89       /* Frequency adjust values */

/*-------------------------------------------------------------------------*/

/* V Battery Min/Max.   (Portable Only Item)                               */

#define NV_VBATT_I        90                    /* V battery regulator array for min/max */ /* 90 */

/*-------------------------------------------------------------------------*/

/* Analog (FM) Transmit power levels                                       */

#define NV_FM_TX_PWR_I        91                          /* Analog TX power level array */

/*-------------------------------------------------------------------------*/

/* Frequency/temperature offset table item                                 */

#define NV_FR_TEMP_OFFSET_I        92  

/*-------------------------------------------------------------------------*/

/* DM Port Mode (Mobiles only) NOTE: Use to be NV_EXT_PORT_MODE_I          */

#define NV_DM_IO_MODE_I        93            /* External port (I/O) mode for DM service   */

/*-------------------------------------------------------------------------*/

/* Portable Turnaround Compensation Tables  (Portable Only)                */

#define NV_CDMA_TX_LIMIT_I        94        /* To limit TX_GAIN_ADJ when output exceeded */
#define NV_FM_RSSI_I        95              /* Analog RSSI adjustment                    */
#define NV_CDMA_RIPPLE_I        96          /* CDMA UHF Ripple Compensation              */
#define NV_CDMA_RX_OFFSET_I        97       /* CDMA RX Offset compensation               */
#define NV_CDMA_RX_POWER_I        98        /* CDMA True RX Power Table                  */
#define NV_CDMA_RX_ERROR_I        99        /* CDMA RX Linear and Non-linear error table */
#define NV_CDMA_TX_SLOPE_1_I        100     /* CDMA TX Gain Comp Slope Compensation table*/
#define NV_CDMA_TX_SLOPE_2_I        101     /* CDMA TX Gain Adjust Slope Compensation tab*/
#define NV_CDMA_TX_ERROR_I        102       /* CDMA TX Non-linear Error Compensation tabl*/
#define NV_PA_CURRENT_CTL_I        103      /* PA Current Control table                  */
/*-------------------------------------------------------------------------*/

/* Audio Adjustment values                                                 */

#define NV_SONY_ATTEN_1_I        104
#define NV_SONY_ATTEN_2_I        105
#define NV_VOC_GAIN_I        106


/*-------------------------------------------------------------------------*/

/* Spare items (2) for developer                                           */

#define NV_SPARE_1_I        107
#define NV_SPARE_2_I        108

/*-------------------------------------------------------------------------*/

/* Data Services items                                                     */

#define NV_DATA_SRVC_STATE_I        109     /* Data Service(Task) Enabled/Disabled       */
#define NV_DATA_IO_MODE_I        110        /* External port (I/O) mode for Data service */
#define NV_IDLE_DATA_TIMEOUT_I        111   /* data service idle time in seconds         */

/*-------------------------------------------------------------------------*/

/* Maximum TX adjustment                                                   */

#define NV_MAX_TX_ADJ_I        112

/*-------------------------------------------------------------------------*/

/* Initial Muting Modes                                                    */

#define NV_INI_MUTE_I        113

/*-------------------------------------------------------------------------*/

/* Factory free format test buffer                                         */

#define NV_FACTORY_INFO_I        114

/*-------------------------------------------------------------------------*/

/* Additional Sony Attenuation values                                      */

#define NV_SONY_ATTEN_3_I        115
#define NV_SONY_ATTEN_4_I        116
#define NV_SONY_ATTEN_5_I        117


/*-------------------------------------------------------------------------*/

/* DM address item (for multi-drop HDLC                                    */

#define NV_DM_ADDR_I        118
#define NV_CDMA_PN_MASK_I        119
#define NV_SEND_TIMEOUT_I        120

/*-------------------------------------------------------------------------*/
/* MSM2P and beyond NV items. */

#define NV_FM_AGC_SET_VS_PWR_I        121            /* FM TX_AGC_ADJ setting vs power */
#define NV_FM_AGC_SET_VS_FREQ_I        122           /* FM TX_AGC_ADJ setting vs frequency */
#define NV_FM_AGC_SET_VS_TEMP_I        123           /* FM TX_AGC_ADJ setting vs temperature */

#define NV_FM_EXP_HDET_VS_PWR_I        124           /* FM expected HDET reading vs power */
#define NV_FM_ERR_SLP_VS_PWR_I        125            /* FM HDET error slope vs power */
#define NV_FM_FREQ_SENSE_GAIN_I        126           /* deviation adj. trim */

#define NV_CDMA_RX_LIN_OFF_0_I        127            /* CDMA Rx linearizer offset */
#define NV_CDMA_RX_LIN_SLP_I        128              /* CDMA Rx linearizer slope */

#define NV_CDMA_RX_COMP_VS_FREQ_I        129         /* CDMA Rx gain comp vs frequency */
#define NV_CDMA_TX_COMP_VS_FREQ_I        130         /* CDMA Tx gain comp vs frequency */
#define NV_CDMA_TX_COMP_VS_VOLT_I        131         /* CDMA Tx gain comp vs voltage */

#define NV_CDMA_TX_LIN_MASTER_OFF_0_I        132     /* CDMA Tx linearizer master offset */
#define NV_CDMA_TX_LIN_MASTER_SLP_I        133       /* CDMA Tx linearizer master slope */
#define NV_CDMA_TX_LIN_VS_TEMP_I        134          /* CDMA Tx linearizer trim vs temp */
#define NV_CDMA_TX_LIN_VS_VOLT_I        135          /* CDMA Tx linearizer trim vs voltage */

#define NV_CDMA_TX_LIM_VS_TEMP_I        136          /* CDMA Tx power limit vs temperature */
#define NV_CDMA_TX_LIM_VS_VOLT_I        137          /* CDMA Tx power limit vs voltage */
#define NV_CDMA_TX_LIM_VS_FREQ_I        138          /* CDMA Tx power limit vs frequency */
#define NV_CDMA_EXP_HDET_VS_AGC_I        139         /* CDMA expected HDET reading vs AGC PDM */
#define NV_CDMA_ERR_SLP_VS_HDET_I        140         /* CDMA HDET error slope vs HDET reading */

#define NV_THERM_I        141                         /* RF & LCD temp. based compensation */
#define NV_VBATT_PA_I        142                      /* RF comp. based on voltage.*/
#define NV_HDET_OFF_I        143                     /* ADC HDET reading offset */
#define NV_HDET_SPN_I        144                     /* ADC HDET reading span */
#define NV_ONETOUCH_DIAL_I        145                /* ena/dis UI one touch dialing */

#define NV_FM_AGC_ADJ_VS_FREQ_I        146
#define NV_FM_AGC_ADJ_VS_TEMP_I        147
#define NV_RF_CONFIG_I        148
#define NV_R1_RISE_I        149
#define NV_R1_FALL_I        150
#define NV_R2_RISE_I        151
#define NV_R2_FALL_I        152
#define NV_R3_RISE_I        153
#define NV_R3_FALL_I        154

#define NV_PA_RANGE_STEP_CAL_I        155
#define NV_LNA_RANGE_POL_I        156
#define NV_LNA_RANGE_RISE_I        157
#define NV_LNA_RANGE_FALL_I        158
#define NV_LNA_RANGE_OFFSET_I        159

#define NV_POWER_CYCLES_I        160
#define NV_ALERTS_LVL_I        161
#define NV_ALERTS_LVL_SHADOW_I        162
#define NV_RINGER_LVL_SHADOW_I        163
#define NV_BEEP_LVL_SHADOW_I        164
#define NV_EAR_LVL_SHADOW_I        165
#define NV_TIME_SHOW_I        166
#define NV_MESSAGE_ALERT_I        167
#define NV_AIR_CNT_I        168
#define NV_ROAM_CNT_I        169
#define NV_LIFE_CNT_I        170
#define NV_SEND_PIN_I        171
#define NV_AUTO_ANSWER_SHADOW_I        172
#define NV_AUTO_REDIAL_SHADOW_I        173
#define NV_SMS_I        174
#define NV_SMS_DM_I        175
#define NV_IMSI_MCC_I        176
#define NV_IMSI_11_12_I        177
#define NV_DIR_NUMBER_I        178
#define NV_VOICE_PRIV_I        179
#define NV_SPARE_B1_I        180
#define NV_SPARE_B2_I        181
#define NV_SPARE_W1_I        182
#define NV_SPARE_W2_I        183

#define  NV_FSC_I                 184
#define  NV_ALARMS_I              185   
#define  NV_STANDING_ALARM_I      186           
#define  NV_ISD_STD_PASSWD_I      187           
#define  NV_ISD_STD_RESTRICT_I    188             
#define  NV_DIALING_PLAN_I        189         
#define  NV_FM_LNA_CTL_I          190       
#define  NV_LIFE_TIMER_G_I        191                                 /*190*/
#define  NV_CALL_TIMER_G_I        192                             
#define  NV_PWR_DWN_CNT_I         193        
#define  NV_FM_AGC_I              194   
#define  NV_FSC2_I                195 
#define  NV_FSC2_CHKSUM_I         196        
#define  NV_WDC_I                 197
#define  NV_HW_CONFIG_I           198      

/*-------------------------------------------------------------------------*/
/* MSM2P and beyond NV items. (continued)  */

#define  NV_CDMA_RX_LIN_VS_TEMP_I      199                       /* CDMA Rx linearizer vs temperature */
#define  NV_CDMA_ADJ_FACTOR_I          200                       /* CDMA adjustment factor */
#define  NV_CDMA_TX_LIM_BOOSTER_OFF_I  201                         /*200*/
#define  NV_CDMA_RX_SLP_VS_TEMP_I      202                    
#define  NV_CDMA_TX_SLP_VS_TEMP_I      203        
#define  NV_PA_RANGE_VS_TEMP_I         204     
#define  NV_LNA_SWITCH_VS_TEMP_I       205       
#define  NV_FM_EXP_HDET_VS_TEMP_I      206        
#define  NV_N1M_I                      207

//#define NV_MAX_I                       209

//sya------start
#define  NV_IMSI_I						208
#define  NV_IMSI_ADDR_NUM_I				209
#define  NV_ASSIGNING_TMSI_ZONE_LEN_I	210
#define  NV_ASSIGNING_TMSI_ZONE_I		211
#define  NV_TMSI_CODE_I					212
#define  NV_TMSI_EXP_I					213
#define  NV_HOME_PCS_FREQ_BLOCK_I		214
#define  NV_DIR_NUMBER_PCS_I			215

#define  NV_ROAMING_LIST_I	216 
#define  NV_MRU_TABLE_I		217

#define  NV_REDIAL_I			218
#define  NV_OTKSL_I				219
#define  NV_TIMED_PREF_MODE_I	220

////////4.05 YJG 2002.5.23 DB535/////////////////////////
#define  NV_GPS1_GPS_RF_DELAY_I 		  443
#define  NV_GPS1_GPS_RF_LOSS_I 			  449
#define  NV_GPS1_LO_CAL_I 				  555
#define  NV_GPS1_PCS_RF_DELAY_I 		  557
#define  NV_GPS_DOPP_SDEV_I               736
#define  NV_PCS_TX_LIM_VS_TEMP_FREQ_I     1075
//////////////////////////////////////////////////////////
#define  NV_CDMA_TX_LIM_VS_TEMP_FREQ_I    996  //by ROMEO for LX1200 //4.09 LBC 2002.12.23 518
/*---------------���Գ� S--- TRI-MODE ------------------------------------------------*/
/* tri mode �����ϱ� ���� digital cal item�߰�    TM210                    */
/* kang 1999/12/7                                                      */
#define  NV_PCS_RX_LIN_OFF_0_I          500//221  /* CDMA Rx linearizer offset              */
#define  NV_PCS_RX_LIN_SLP_I            501//222  /* CDMA Rx linearizer slope               */

#define  NV_PCS_TX_LIN_MASTER_OFF_0_I   502//223  /* CDMA Tx linearizer master offset       */
#define  NV_PCS_TX_LIN_MASTER_SLP_I     503//224  /* CDMA Tx linearizer master slope        */

#define  NV_PCS_RX_COMP_VS_FREQ_I       504//225  /* CDMA Rx gain comp vs frequency         */
#define  NV_PCS_TX_COMP_VS_FREQ_I       505//226  /* CDMA Tx gain comp vs frequency         */

#define  NV_PCS_RX_LIN_VS_TEMP_I        506//227  /* CDMA Rx linearizer vs temperature      */
#define  NV_PCS_TX_LIN_VS_TEMP_I        507//228  /* CDMA Tx linearizer trim vs temp        */

#define  NV_PCS_RX_SLP_VS_TEMP_I        508//229
#define  NV_PCS_TX_SLP_VS_TEMP_I        509//230 

#define  NV_PCS_TX_LIM_VS_TEMP_I        510//231  /* CDMA Tx power limit vs temperature     */
#define  NV_PCS_TX_LIM_VS_FREQ_I        511//232  /* CDMA Tx power limit vs frequency       */

#define  NV_PCS_EXP_HDET_VS_AGC_I       512//233  /* CDMA expected HDET reading vs AGC PDM  */
#define  NV_PCS_HDET_OFF_I              513//234  /* ADC HDET reading offset                */
#define  NV_PCS_HDET_SPN_I              514//235  /* ADC HDET reading span                  */

#define  NV_PCS_R1_RISE_I               515//236
#define  NV_PCS_R1_FALL_I               516//237
#define  NV_PCS_R2_RISE_I               517//238                                 
#define  NV_PCS_R2_FALL_I               518//239
#define  NV_PCS_R3_RISE_I               519//240
#define  NV_PCS_R3_FALL_I               520//241

#define  NV_PCS_PA_RANGE_STEP_CAL_I     521//242
#define  NV_PCS_PA_RANGE_VS_TEMP_I      522//243

#define  NV_PCS_LNA_RANGE_POL_I         523//244
#define  NV_PCS_LNA_RANGE_RISE_I        524//245
#define  NV_PCS_LNA_RANGE_FALL_I        525//246
#define  NV_PCS_LNA_RANGE_OFFSET_I      526//247

#define  NV_PCS_PDM1_VS_TEMP_I          527//248  /* For RF Cal use                           */
#define  NV_PCS_PDM2_VS_TEMP_I          528//249  /* For RF Cal use                           */

#define  NV_PCS_PDM1_VS_FREQ_I          529//250  /* For RF Cal use                           */
#define  NV_PCS_PDM2_VS_FREQ_I          530//251  /* For RF Cal use                           */

#define  NV_PCS_ADJ_FACTOR_I            531//252  /* CDMA adjustment factor */
#define  NV_PCS_RX_AGC_MINMAX_I         532//253  /* Receiver AGC min-max                     */
/* Kang. 1999/12/7                                                      */

#define  NV_LNA_GAIN_POL_TM210_I        533//254
#define  NV_LNA_GAIN_PWR_MIN_TM210_I    534//255
#define  NV_LNA_GAIN_PWR_MAX_TM210_I    535//256
#define  NV_CDMA_LNA_LIN_OFF_0_TM210_I  536//257
#define  NV_CDMA_LNA_LIN_SLP_TM210_I    537//258
#define  NV_LNA_GAIN_VS_TEMP_TM210_I    538//259
//////////////////////////////////////////////////////////////////////
// YJG 2001.9.4 LG-TM520���� �߰� Item
#define NV_SMS_AUTO_DELETE_MENU_I 		539 
#define NV_SMS_AUTO_SAVE_SEL_I			540
#define NV_SMS_MO_MAX_USERDATA_I		541
#define NV_SMS_MO_EDIT_MODE_I			542
#define NV_SMS_MO_L3_ACK_I				543
#define NV_SMS_MO_SO_I					544
#define NV_SMS_VOICE_MAIL_I				545

#define NV_FM_FSG_VS_TEMP_I				559
#define  NV_AUDIO_ADJ_PHONE_I		  561//998 //DB520���� 382������ �ߺ��Ǳ� ������ 998�� �ӽ÷� ��� YJG 2001.6.5
#define  NV_AUDIO_ADJ_EARJACK_I		  562//997 //DB520���� 382������ �ߺ��Ǳ� ������ 997�� �ӽ÷� ���YJG 2001.6.5
#define  NV_HYBRID_PREF_I             562//4.07 LBC 2002.11.20 for KHX2 
#define  NV_AUDIO_ADJ_HFK_I			  563//996 //DB520���� 382������ �ߺ��Ǳ� ������ 996�� �ӽ÷� ���YJG 2001.6.5
//////////////////////////////////////////////////////////////////////
#define NV_FM_PWR_LEVEL56_VS_FREQ_I     565//OJS 01.10.16 DB525�߰�. 
#define NV_FM_PWR_LEVEL012_VS_TEMP_I    566//OJS 01.10.16 DB525�߰�.

#define  NV_FM_RVC_COMP_VS_FREQ_I       576 // TM510���� �߰�..
#define  NV_FM_PWR_LEVEL7_VS_FREQ_I      577 // DB520���� �߰� YJG 2001.6.5

/*---------------���Գ� E------- TRI-MODE ---------------------------------------------*/

#define  NV_SELECTRING_I			221
#define  NV_AUTO_DDD_I				222
#define  NV_INTER_CALL_I			223
#define  NV_RESET_AIR_CNT_I			224
#define  NV_RESET_AIR_TIMER_I		225	
#define  NV_SELECT_CALL_CONNECT_I	226
#define  NV_CALL_CONNECT_LVL_I		227
#define  NV_ALARM_TIME_I			228	
#define  NV_ALARM_FLAG_I			229

#define  NV_SMS_MODE_I			230
//DM110A ���� �߰�.. BY OJS 00.12.19
#define  NV_MRU2_TABLE_I		231	

#define  NV_SMS_ORIG_MSG_ID_I	232	

#define  NV_ROAM_MAIN_I			233
#define  NV_ROAM_SUB_I			234

#define  NV_SMS_TMA_MODE_I		235
#define  NV_DIALING_I			236
#define  NV_BROADCAST_I			237
#define  NV_BROADCAST_CONFIG_I	238


#define  NV_DISPTELNO_I			239
#define  NV_BAUDRATE_I			240
#define  NV_DATA_SO_SET_I		241//YJG 2001.9.4 LG-TM520

#define  NV_SID_NID_LOCK_I		255//YJG 2001.9.4 LG-TM520
#define  NV_PRL_ENABLED_I       256   // DM-110 kang add 

#define  NV_SYSTEM_PREF_I       258  // DM-110Q O.J.S    /* System Preference, per NAM               */
////////////////YJG 2001.9.4 LG-TM520////////////////////////
#define  NV_HOME_SID_NID_I      259
#define  NV_OTAPA_ENABLED_I		260
#define  NV_NAM_LOCK_I			261
/////////////////////////////////////////////////////////////
#define NV_IMSI_T_S1_I          262   /* True IMSI - MIN1                         */
#define NV_IMSI_T_S2_I          263   /* True IMSI - MIN2                         */
#define NV_IMSI_T_MCC_I         264   /* True IMSI - MCC                          */
#define NV_IMSI_T_11_12_I       265   /* True IMSI - 11th & 12th digits           */
#define NV_IMSI_T_ADDR_NUM_I    266   /* True IMSI - Addr num                     */
#define NV_PREF_VOICE_SO_I      285   /* vocoder Rate                             */       
//sp-510 ysi v3.55 1999/12/16
#define  NV_PDM1_VS_FREQ_I            294 // 288 ////////////////////////
#define  NV_PDM2_VS_FREQ_I            295 // 289 ////////////////////////
///////////////YJG 2001.9.4 LG-TM520/////////////////////
#define NV_SPC_CHANGE_ENABLED_I			296
#define NV_DATA_MDR_MODE_I				297
#define NV_DATA_PKT_ORIG_STR_I			298
#define NV_DATA_AUTO_PACKET_DETECTION_I	300
#define NV_AUTO_VOLUME_ENABLED_I		301
/////////////////////////////////////////////////////////
#define NV_CDMA_TX_TX0_LIN_VS_TEMP_I  321 // 315
#define NV_CDMA_TX_TX1_LIN_VS_TEMP_I  322 // 316
#define NV_CDMA_TX_TX2_LIN_VS_TEMP_I  323 // 317
#define NV_CDMA_TX_TX3_LIN_VS_TEMP_I  324 // 318
#define NV_CDMA_TX_TX4_LIN_VS_TEMP_I  325 // 319
#define NV_CDMA_TX_TX5_LIN_VS_TEMP_I  326 // 320
#define NV_CDMA_TX_TX6_LIN_VS_TEMP_I  327 // 321
#define NV_CDMA_TX_TX7_LIN_VS_TEMP_I  328 // 322
#define NV_CDMA_TX_TX8_LIN_VS_TEMP_I  329 // 323
#define NV_CDMA_TX_TX9_LIN_VS_TEMP_I  330 // 324
#define NV_CDMA_TX_TX10_LIN_VS_TEMP_I 331 // 325
#define NV_CDMA_TX_TX11_LIN_VS_TEMP_I 332 // 326
#define NV_CDMA_TX_TX12_LIN_VS_TEMP_I 333 // 327
#define NV_CDMA_TX_TX13_LIN_VS_TEMP_I 334 // 328
#define NV_CDMA_TX_TX14_LIN_VS_TEMP_I 335 // 329
#define NV_CDMA_TX_TX15_LIN_VS_TEMP_I 336 // 330
#define  NV_LNA_GAIN_POL_I            350 // 344  
#define  NV_LNA_GAIN_PWR_MIN_I        351 // 345  
#define  NV_LNA_GAIN_PWR_MAX_I        352 // 346
#define  NV_CDMA_LNA_LIN_OFF_0_I      353 // 347
#define  NV_CDMA_LNA_LIN_SLP_I        354 // 348
#define  NV_LNA_GAIN_VS_TEMP_I        355 // 349
#define  NV_FM_AGC_SET_VS_VOLT_I      356 // 350
#define  NV_CDMA_LNA_COMP_VS_FREQ_I   357 // DM-110A ���� �߰� 00.04.16 OJS
#define  NV_PA_THERM_HIGH_I           358 // �� �� �߰��� 2000/1/27 ysi
#define  NV_PA_THERM_LOW_I            359
/////////////////// kang add 12.22  DM-110 //////////////////
// 1111
#define NV_CDMA_TX_TEMP0_VS_FREQ_I    360 // 354
#define NV_CDMA_TX_TEMP1_VS_FREQ_I    361 // 355
#define NV_CDMA_TX_TEMP2_VS_FREQ_I    362 // 356
#define NV_CDMA_TX_TEMP3_VS_FREQ_I    363 // 357
#define NV_CDMA_TX_TEMP4_VS_FREQ_I    364 // 358
#define NV_CDMA_TX_TEMP5_VS_FREQ_I    365 // 359
#define NV_CDMA_TX_TEMP6_VS_FREQ_I    366 // 360
//#define NV_CDMA_TX_TEMP7_VS_FREQ_I    367 // 361

//#define NV_FM_AGC_TEMP0_VS_FREQ_I     368 // 362
//#define NV_FM_AGC_TEMP1_VS_FREQ_I     369 // 363
//#define NV_FM_AGC_TEMP2_VS_FREQ_I     370 // 364
#define NV_FM_AGC_TEMP3_VS_FREQ_I     371 // 365
#define NV_FM_AGC_TEMP4_VS_FREQ_I     372 // 366
#define NV_FM_AGC_TEMP5_VS_FREQ_I     373 // 367
#define NV_FM_AGC_TEMP6_VS_FREQ_I     374 // 368
#define NV_FM_AGC_TEMP7_VS_FREQ_I     375 // 369

#define NV_FM_AGC_PWR0_VS_FREQ_I      376 // 370
#define NV_FM_AGC_PWR1_VS_FREQ_I      377 // 371
#define NV_FM_AGC_PWR2_VS_FREQ_I      378 // 372
#define NV_FM_AGC_PWR3_VS_FREQ_I      379 // 373
#define NV_FM_AGC_PWR4_VS_FREQ_I      380 // 374
#define NV_FM_AGC_PWR5_VS_FREQ_I      381 // 375
#define NV_FM_AGC_PWR6_VS_FREQ_I      382 // 376
#define NV_FM_AGC_PWR7_VS_FREQ_I      383 // 377

#define NV_CDMA_TX_FINE_COMP_VS_FREQ_I 384 // 378
#define NV_FM_AGC_FINE_ADJ_VS_FREQ_I   385 // 379

#define NV_RX_AGC_MIN_11_I      386//4.03-1 OJS 2002.3.25//SP3100

#define NV_FM_COMP_THERM0_FREQ_LEVEL_I 387
#define NV_FM_COMP_THERM1_FREQ_LEVEL_I 388
#define NV_FM_COMP_THERM2_FREQ_LEVEL_I 389
#define NV_FM_COMP_THERM3_FREQ_LEVEL_I 390
#define NV_FM_COMP_THERM4_FREQ_LEVEL_I 391
#define NV_FM_COMP_THERM5_FREQ_LEVEL_I 392
#define NV_FM_COMP_THERM6_FREQ_LEVEL_I 393
#define NV_FM_COMP_THERM7_FREQ_LEVEL_I 394
//2222
#define  NV_MAX_I				395//sp-510 end 
//sya------end
#define  NV_CDMA_TX_LIN_MASTER0_I         367                
#define  NV_CDMA_TX_LIN_MASTER1_I         368   
#define  NV_CDMA_TX_LIN_MASTER2_I         369   
#define  NV_CDMA_TX_LIN_MASTER3_I         370   

#define  NV_PRL_VERSION_I       402
#define  NV_PA_RANGE_OFFSETS_I  410
#define  NV_TX_COMP0_I	 411	/* Compensation for Tx linz. with internal PA=00 */  
#define  NV_TX_COMP1_I   420	/* Compensation for Tx linz. with internal PA=01 */  
#define  NV_TX_COMP2_I	 421	/* Compensation for Tx linz. with internal PA=10 */  
#define  NV_TX_COMP3_I	 422	/* Compensation for Tx linz. with internal PA=11 */  
////////////YJG 2001.9.4 LG-TM520//////////////////////////////
#define  NV_MM_LVL_I			415
#define  NV_MM_LVL_SHADOW_I		416
#define  NV_MM_SPEAKER_LVL_I	417
#define  NV_PCS_ENC_BTF_I				445
#define  NV_CDMA_ENC_BTF_I				446
#define  NV_SUBPCG_PA_WARMUP_DELAY_I	448
///////////////////////////////////////////////////////////////
#define  NV_FTM_MODE_I					453    /* Determines boot up mode of a factory testmode phone */
///////////////////////////////////////////////////////////////
#define	 NV_LCD_CONTRAST_I 	           458 //LG-D410���� �߰� Item by KBI(01.7.16)
#define  NV_TSTMODE_I	 493    /* P411 for Setting the Channel */ //YJG 2001.6.13
/////////////////////////////4.03-1 OJS 2002.3.25//////////////////////////////////////////
#define  NV_CDMA_TX_LIN_VS_FREQTEMP_I  494  //SP3100/* CDMA Tx linearizer trim vs freq & temp */   /*457*/
#define  NV_CDMA_TX_SLP_VS_FREQTEMP_I  495  //SP3100/* CDMA Tx linearizer trim vs freq & temp */
#define  NV_CDMA_TEMP_LIMLINE_I		497
////////////////////////////////////////////////////////////////////////////////////////////
#define  NV_EXT_LED_I                 720//4.06-2 LBC 2002.10.30 L200 �ܺ� LED�˻縦 ���� �߰� 4.06-2 LBC 2002.10.30 

#define  NV_QDSP_SND_CTRL_I           999 //TM510������ 359�ε� �ߺ��Ǿ �ӽ������� 959�� ����Ѵ�.
///////////////LG-TM520���� �߰� NV Item YJG 2001.9.3//////////////////
#define  NV_DATA_QNC_ENABLED_I		  995
#define	 NV_RING_SOUND_I			  994
#define  NV_VIB_LVL_I				  993
#define  NV_MULTILANG_I				  992
#define  NV_CALL_CONNECT_ALERT_I	  991
#define  NV_THEME_I					  990
#define	 NV_CARRIER_LOGO_I			  989
#define  NV_SMS_ALERT_SEL_I			  988
#define  NV_SMS_2MIN_ALERT_I		  987
#define  NV_SMS_DEFERRED_SEL_I		  986
#define  NV_SMS_VALIDITY_SEL_I		  985
#define  NV_SMS_PRIORITY_SEL_I		  984
#define  NV_SMS_DELIVERY_SEL_I		  983
#define  NV_SMS_DEFAULT_CB_I		  982
#define  NV_GAME_SETTINGS_I			  981
#define  NV_ALERT_SELECT_I			  980
///////////////////////////////////////////////////////////////////////
//#define  NV_SMS_ALERT_I			231	
#define  NV_SMS_ALERT_I			931
/////4.03-1 OJS 2002.3.25 SJKim SP3100 ����.//////
#define  NV_LNA_RANGE_2_RISE_I		  972
#define	 NV_LNA_RANGE_2_FALL_I		  973
#define  NV_LNA_RANGE_12_OFFSET_I	  974
#define  NV_NONBYPASS_TIMER_I		  975
#define  NV_BYPASS_TIMER_I	          976
#define  NV_IM_LEVEL1_I			      977
#define	 NV_IM_LEVEL2_I			      978
#define	 NV_AGC_PHASE_OFFSET_I		  979
/////////////////////////////////////////////////
////////4.05 YJG 2002.5.29 LG-CU6060/////////////
#define  NV_RINGER_SPKR_LVL_I         971/* External speaker ringer volume        229*/
#define  NV_BEEP_SPKR_LVL_I           970/* External speaker key beep volume */ /*230*/
#define  NV_SOUNDS_RINGER_TYPE_I      969//4.05-2 YJG 2002.7.23
/////////////////////////////////////////////////

////////////////4.06 YJG 2002.9.3//////////////////////////
// 2002/2/27 thunder : TMx40 ���� ������ �߰�
#define NV_CDMA_LNA_OFFSET_VS_FREQ_I		968
#define NV_CDMA_LNA_12_OFFSET_VS_FREQ_I		967
#define NV_PCS_LNA_RANGE_2_RISE_I			966
#define NV_PCS_LNA_RANGE_2_FALL_I			965
#define NV_PCS_LNA_RANGE_12_OFFSET_I		964
#define NV_PCS_NONBYPASS_TIMER_I			963
#define NV_PCS_BYPASS_TIMER_I				962
#define NV_PCS_IM_LEVEL1_I					961
#define NV_PCS_IM_LEVEL2_I					960
#define NV_PCS_CDMA_LNA_OFFSET_VS_FREQ_I	959
#define NV_PCS_CDMA_LNA_12_OFFSET_VS_FREQ_I	395///////
#define NV_PCS_AGC_PHASE_OFFSET_I			396///////
#define NV_PCS_RX_AGC_MIN_11_I				397///////

#define NV_PCS_TX_LIN_MASTER0_I				431/////
#define NV_PCS_TX_LIN_MASTER1_I				432/////
#define NV_PCS_TX_LIN_MASTER2_I				433/////
#define NV_PCS_TX_LIN_MASTER3_I				434/////
#define NV_PCS_PA_RANGE_OFFSETS_I			435/////
#define NV_PCS_TX_COMP0_I 					436/////
#define NV_PCS_TX_COMP1_I					437/////
#define NV_PCS_TX_COMP2_I					438/////
#define NV_PCS_TX_COMP3_I					439/////

#define NV_GPS1_CDMA_RF_DELAY_I				444/////

// 2002/4/29 thunder added : GPS ������ �߰�
#define NV_GPS1_ANT_OFF_DB_I				556////
//////////////////////////////////////////////////////////////////////

//////////////////////4.10-1 YJG 2003.1.8/////////////////////////////
#define NV_CDMA_TX_TEMP7_VS_FREQ_I    958//367 // 361
#define NV_FM_AGC_TEMP0_VS_FREQ_I     957//368 // 362
#define NV_FM_AGC_TEMP1_VS_FREQ_I     956//369 // 363
#define NV_FM_AGC_TEMP2_VS_FREQ_I     955//370 // 364
//////////////////////////////////////////////////////////////////////

#define  NV_RF_CAL_VER_I					569		//  [7/16/2007] vivache : rf_cal_ver CDMA Cal check�� ���� NV Define

typedef WORD nv_items_enum_type; 


/*=========================================================================*/

/* Following are all the types to be used in message.  Unless otherwise    */
/* specified all fields are right justified.  All nv.h structures are      */
/* packed(1).  This is done so that external and internal NV storage       */
/* representation is as identical as possible and it minimizes storage     */
/* requirements.                                                           */

/*-------------------------------------------------------------------------*/

#pragma pack(1)

/* Various definitions to be used in subsequent types.                     */

#if ((TG==T_M)||(TG==T_B2))
#define  NV_MAX_SPEED_DIALS 103  /* Maximum 103 speed dials for mobile     */
#define  NV_MAX_LTRS         10        /* With up to 10 letters name */
#define  NV_MAX_STACK_DIALS  10        /* Maximum 10 call stack numbers */
//#define  NV_MAX_NAMS          4        /* Up to 4 NAMs allowed */
#define  NV_MAX_NAMS          5        /* Up to 5 NAMs allowed *///4.04 YJG 2002.4.5 D100
#endif

#if (TG==T_P)
#define  NV_MAX_SPEED_DIALS 100  /* maximum 100 speed dials for portable   */
#define  NV_MAX_LTRS         10        /* With up to 10 letters name */
#define  NV_MAX_STACK_DIALS  10        /* Maximum 10 call stack numbers */
//#define  NV_MAX_NAMS          4        /* Up to 4 NAMs allowed */
#define  NV_MAX_NAMS          5        /* Up to 5 NAMs allowed *///4.04 YJG 2002.4.5 D100
#endif

//sya-----start
#if ((TG==T_G) || (TG==T_DM))
#define  NV_MAX_SPEED_DIALS  102 
#define  NV_MAX_LTRS         25        /* With up to 12 letters name */
#define  NV_MAX_STACK_DIALS  10        /* Maximum 10 call stack numbers */
  #ifdef FEATURE_JSTD008
    #ifdef FEATURE_NV_ONE_NAM_RL_LARGE
    #else
      #if(LGP1000F)
//        #define  NV_MAX_NAMS	      2
      #else
//        #define  NV_MAX_NAMS          2        /* Up to 2 NAMs allowed */
      #endif
    #endif /* FEATURE_NV_ONE_NAM_RL_LARGE */
    #define  NV_MAX_SID_NID       4        /* For 1 SID+NID pair */
  #else
    //#define  NV_MAX_NAMS          4        /* Up to 4 NAMs allowed */
	#define  NV_MAX_NAMS          5        /* Up to 5 NAMs allowed *///4.04 YJG 2002.4.5 D100
    #define  NV_MAX_SID_NID       4        /* Up to 4 SID+NID pairs */
  #endif /* FEATURE_JSTD008 */
#endif
//sya-----end

//#if (TG==T_G)
//HACK until allocations rebalanced #define  NV_MAX_SPEED_DIALS 102  /* maximum 102 speed dials for portable   */
//#define  NV_MAX_SPEED_DIALS  102 
//#define  NV_MAX_LTRS         12        /* With up to 12 letters name */
//#define  NV_MAX_STACK_DIALS  10        /* Maximum 10 call stack numbers */
//#define  NV_MAX_NAMS          4        /* Up to 4 NAMs allowed */
//#endif

#if ((TG==T_I1) || (TG==T_I2) || (TG==T_C1))
#define  NV_MAX_SPEED_DIALS 1  /* maximum 100 speed dials for iss1   */
#define  NV_MAX_LTRS        2  /* With up to 2 letters name */
#define  NV_MAX_STACK_DIALS 2  /* Maximum 2 call stack numbers */
//#define  NV_MAX_NAMS        1  /* Up to 4 NAMs allowed */
#define  NV_MAX_NAMS          5        /* Up to 5 NAMs allowed *///4.04 YJG 2002.4.5 D100
#endif

#if (TG==T_S)
#define  NV_MAX_SPEED_DIALS 100  /* maximum 100 speed dials for stretch    */
#define  NV_MAX_LTRS         10        /* With up to 10 letters name */
#define  NV_MAX_STACK_DIALS  10        /* Maximum 10 call stack numbers */
//#define  NV_MAX_NAMS          4        /* Up to 4 NAMs allowed */
#define  NV_MAX_NAMS          5        /* Up to 5 NAMs allowed *///4.04 YJG 2002.4.5 D100
#endif

#if ((TG==T_PC) || (TG==T_DM) || (TG==T_SP))
#define  NV_MAX_SPEED_DIALS 102  /* maximum 103 speed dials for PC debug   */
#define  NV_MAX_LTRS         12  /* With up to 12 letters name */
#define  NV_MAX_STACK_DIALS  10  /* Maximum 10 call stack numbers */
//#define  NV_MAX_NAMS          4        /* Up to 4 NAMs allowed */
#define  NV_MAX_NAMS          5        /* Up to 5 NAMs allowed *///4.04 YJG 2002.4.5 D100
#endif

#if (TG==T_REX)
#define  NV_MAX_SPEED_DIALS 103  /* maximum 103 speed dials for REX debug  */
#define  NV_MAX_LTRS         12        /* With up to 12 letters name */
#define  NV_MAX_STACK_DIALS  10        /* Maximum 10 call stack numbers */
//#define  NV_MAX_NAMS          4        /* Up to 4 NAMs allowed */
#define  NV_MAX_NAMS          5        /* Up to 5 NAMs allowed *///4.04 YJG 2002.4.5 D100
//sya----start
#define  NV_MAX_SID_NID       4  //sya /* Up to 4 SID+NID pairs */
//sya----end
#endif


#define     NV_DIR_NUMB_SIZ     10        /*number digits in imsi_dir_numb */

//sya-----start
#define     NV_DIR_NUMB_PCS_SIZ 15        /* num digits in dir_number_pcs */
#define     NV_WDC_LTRS          5        /* With up to 5 letters wdc */
#define     NV_FSC_SIZ           6        /*number digits in FSC */
//sya-----end

#define     NV_MAX_PAGE_MSGS    20        /* Maximum 20 page messages */
#define     NV_MAX_DIAL_DIGITS  32        /* Maximum 32 digit number */    
//#define     NV_SMS_DATA_SIZ    325        /* Max BYTEs in SMS data buffer */

//sya-----start
#define     NV_SMS_DATA_SIZ    388        /* Max BYTEs in SMS data buffer */
//sya-----end

#define     NV_SMS_DM_DATA_SIZ 100        /* Max BYTEs in SMS data buffer */

#define     NV_MAX_MINS          2        /* Up to 2 MINs per NAM allowed */
#define     NV_MAX_SID_LOCK      6        /* Up to 6 SIDs to lock out */
#define     NV_MAX_SID_ACQ       6        /* Up to 6 SIDs to acquire */
#define     NV_MAX_SID_NID       4        /* Up to 4 SID+NID pairs */
#define     NV_MAX_ERR_LOG      20        /* Maximum 20 logs in error log */
#define     NV_ERR_FILE_NAME_LEN 8        /* 8 characters file name length */
#define     NV_CDMA_MIN_INDEX    1        /* CDMA MIN index */
#define     NV_ANALOG_MIN_INDEX  0        /* Analog MIN index */

//sya-----start
#define     NV_MAX_ALARMS        6        /* One time alarms for DOT */
#define     NV_ISD_STD_PASSWD_SIZ 4       /* Bytes in passwd */
//sya-----end

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* All items marked by a checksum, except the ESN take a simple checksum.  */
/* If set as defined below it denotes that the item has been programmed    */
/* to NV and is valid.  Any other value denotes that the item is invalid.  */
/* The ESN checksum is hidden from the user, and the flag returned, as     */
/* defined below, indicates if the ESN checksum is valid.                  */

#define     NV_VALID_GEN_CHKSUM     0xFFFF
#define     NV_VALID_ESN_CHKSUM     0xFFFFFFFFL


//  [10/2/2006] lupis : MEID �߰� ��û (LGEAI)
#define		NV_MEID_I				1943  
#define		NV_IMEI_I				550  

typedef  struct
{
  dword		lo;
  dword		hi;
} nv_meid_type;

#define NV_IMEI_SIZE	9	// [01/19/2011] lupis : LTE

typedef struct	// [01/19/2011] lupis : LTE
{
  byte imei[NV_IMEI_SIZE];
} nv_imei_type;
//


/*-------------------------------------------------------------------------*/

/* Type to hold ESN.  The ESN and its checksum are write-once protected    */
/* and the NV task will not write to NV an ESN or its checksum if the      */
/* stored ESN or its checksum are non-zero.                                */

typedef struct {
  DWORD     esn;
} nv_esn_type;

typedef struct {
  DWORD     fsc2;
} nv_fsc2_type;


/*-------------------------------------------------------------------------*/

/* Type to hold ESN checksum.  The checksum is 30 bit CRC with generator   */
/* polynomial as used for CDMA sync channel signaling, per CAI section     */
/* 7.7.1.2.2.  The ESN and its checksum are write-once protected and the   */
/* NV task will not write to NV an ESN or its checksum if the stored ESN,  */
/* or its checksum, or the internal valid flag are not valid.  This item   */
/* can be written only internally, by the NV task.  The status of this     */
/* item can be read externally by other tasks to verify that the ESN has   */
/* been correctly programmed to NV.  An NV_VALID_ESN_CHKSUM value returned */
/* indicates valid ESN checksum.                                           */    

typedef struct {
  DWORD     chksum;
} nv_esn_chksum_type;

typedef struct {
  dword     fsc2_chksum;
} nv_fsc2_chksum_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold configuration checksum.  The checksum is a simple 0xFFFF   */
/* marker which indicates that configuration parameters have been          */
/* programmed and are valid.                                               */

typedef struct {
  WORD      chksum;
} nv_config_chksum_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold SID and associated NAM.  The SID is 15 bits, per CAI       */
/* section 2.3.8.                                                          */

typedef struct {
  BYTE      nam;            /* NAM id 0-3 */
  WORD      sid;            /* SID */
} nv_sid_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold analog/digital preferred mode, and the associated NAM.     */
/* The type is per CAI section 2.3.10.2.                                   */

//typedef enum {
#define  NV_MODE_DIGITAL_PREF  0   /* CDMA then Analog */
#define  NV_MODE_DIGITAL_ONLY  1   /* CDMA only */
#define  NV_MODE_ANALOG_PREF   2   /* Analog then CDMA */
#define  NV_MODE_ANALOG_ONLY   3   /* Analog only */
// TM510 OJS 09.17
#define  NV_MODE_AUTOMATIC     4   /* Determine mode automatically */
#define  NV_MODE_E911          5   /* Emergency mode */
#define  NV_MODE_HOME_ONLY     6   /* Restrict to home only */
#define  NV_MODE_PCS_CDMA_ONLY 7
#define  NV_MODE_CELL_CDMA_ONLY 8
typedef WORD nv_mode_enum_type; 

typedef struct {
  BYTE               nam;        /* NAM id 0-3 */
  nv_mode_enum_type  mode;       /* Preferred mode per enum above */
} nv_pref_mode_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold preferred serving system and the associated NAM.           */
/* Type is per CAI section 2.3.10.1.                                       */

//typedef enum {
#define  NV_SYS_A_ONLY  0             /* A only */
#define  NV_SYS_A_PREF    1        /* A then B */
#define  NV_SYS_B_ONLY    2        /* B only */
#define  NV_SYS_B_PREF    3        /* B then A */
#define  NV_SYS_HOME_ONLY 4        /* Home SID only */

//sya----start
#define  NV_SYS_HOME_PREF  5       /* Acquire SID only */
//sya----end

//#define  NV_SYS_SID_ONLY  5        /* Acquire SID only */
typedef WORD  nv_sys_enum_type;

typedef struct {
  BYTE               nam;   /* NAM id 0-3 */
  nv_sys_enum_type   sys;   /* Preferred system per above enum */
} nv_pref_serv_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold SID(s) for lockout.  The phone will reject acquisition if  */
/* any of these SID(s) is acquired.                                        */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  WORD      sid[NV_MAX_SID_LOCK];   /* SID */
} nv_sid_lock_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold SID(s) for acquisition.  The phone will allow acquisition  */
/* only on these SID(s).                                                   */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  WORD      sid[NV_MAX_SID_ACQ];    /* SID */
} nv_sid_acq_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold FIRSTCHPp and associated NAM.  Value is 11 bits, per       */
/* CAI section 2.3.7.                                                      */

typedef struct {
  BYTE      nam;            /* NAM id 0-3 */
  WORD      channel;        /* FIRSTCHPp channel */
} nv_firstchp_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold analog registration type, along with associated NAM id.    */
/* Type includes enumeration for possible registration values.             */

//typedef enum {
#define  NV_DISABLED          0  /* Autonomous registration disabled */
#define  NV_WHEREABOUTS_KNOWN   1/* Autonomuos registration enabled, tell location */
#define  NV_WHEREABOUTS_UNKNOWN 2/* Autonomous registration enabled, hide location */
typedef WORD nv_analog_reg_enum_type;

typedef struct {
  BYTE                      nam;    /* NAM id 0-3 */
  nv_analog_reg_enum_type   kind;   /* Registration kind per enum above */
} nv_analog_reg_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold CDMA channel and associated NAM.  Value is 11 bits for     */
/* Primary and Secondary channels, per CAI section 6.1.1.                  */

typedef struct {
  BYTE      nam;                 /* NAM id 0-3 */
  WORD      channel_a;           /* A carrier channel number */
  WORD      channel_b;           /* B carrier channel number */
} nv_cdmach_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold NAM data checksum.  The checksum is a simple 0xFFFF marker */
/* which is set to indicate that NAM parameters have been programmed and   */
/* are valid.                                                              */

typedef struct {
  BYTE      nam;                 /* NAM id 0-3 */
  WORD      chksum;              /* The checksum */
} nv_nam_chksum_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold authentication A key and the associated NAM id.  The       */
/* number is 64 bits, per IS-54 appendix A (CAI Appendix X).               */

typedef struct {
  BYTE      nam;                 /* NAM id 0-3 */
  QWORD     key;                 /* A key array */
} nv_a_key_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold authentication A key 16 bit CRC checksum with generator    */
/* polynomial as used for CDMA reverse and forward traffic signaling       */
/* messages, per CAI sections 6.7.2.2.2 and 7.7.3.2.  Exact security       */
/* and protection of the A-Key is for now TBD.                             */

typedef struct {
  BYTE      nam;                 /* NAM id 0-3 */
  WORD      chksum;              /* Checksum */
} nv_a_key_chksum_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold SSD (A or B) variable and the associated NAM id.  Each     */
/* SSD is 64 bits, per CAI sections 2.3.12.1.1. and 6.3.12.1.1.            */

typedef struct {
  BYTE      nam;                 /* NAM id 0-3 */
  QWORD     ssd;                 /* SSD array */
} nv_ssd_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold SSD (A or B) 16 bit CRC checksum with generator polynomial */
/* as used for CDMA reverse and forward traffic signaling messages, per    */
/* CAI sections 6.7.2.2.2 and 7.7.3.2.  Exact security and protection of   */
/* the SSDs is for now TBD.                                                */

typedef struct {
  BYTE      nam;                 /* NAM id 0-3 */
  WORD      chksum;              /* Checksum */
} nv_ssd_chksum_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold the call history COUNT parameter and the associated NAM    */
/* id, per CAI section 2.3.12.1.3.                                         */

typedef struct {
  BYTE      nam;                 /* NAM id 0-3 */
  BYTE      count;               /* COUNTsp */
} nv_count_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold MIN1p for 4 MINs, along with the associated NAM id.        */
/* The number is 24 bits, per CAI section 2.3.1.                           */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  DWORD     min1[NV_MAX_MINS];      /* MIN1 */
} nv_min1_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold MIN2p for 4 MINs, along with the associated NAM id.        */
/* The number is 10 bits, per CAI section 2.3.1.                           */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  WORD      min2[NV_MAX_MINS];      /* MIN2 */
} nv_min2_type;
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold IMSI MCC , along with the associated NAM id.               */
/* The number is 24 bits                                                   */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  WORD     imsi_mcc;                          
} nv_imsi_mcc_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold DIR_NUMBER  with the associated NAM id.                    */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  BYTE      dir_number[NV_DIR_NUMB_SIZ];                          
} nv_dir_number_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold IMSI_11_12 for 4 MINs, along with the associated NAM id.   */
/* The number is 8 bits.                                                   */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  BYTE      imsi_11_12;                          
} nv_imsi_11_12_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold CDMA mobile termination type, along with associated NAM,   */
/* to be used for the MOB_TERM_... variables for registration.             */

typedef struct {
  BYTE               nam;                    /* NAM id 0-3 */
  boolean            enabled[NV_MAX_MINS];   /* Registration enabled */
} nv_mob_term_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold ACCOLCp, along with associated NAM id.  Value is 4 bits,   */
/* per CAI section 2.3.5.                                                  */

//namhowon

typedef struct {
  BYTE      nam;                         /* NAM id 0-3 */
  BYTE      class1[NV_MAX_MINS];          /* ACCOLCp class */
} nv_accolc_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold SID+NID pairs.  The SID is 15 bits, per CAI 2.3.8, and the */
/* NID is 16 bits, per CAI section 2.3.10.3.                               */

typedef struct {
  WORD      sid;
  WORD      nid;
} nv_sid_nid_pair_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold SID+NID pairs for CDMA acquisition, along with NAM id      */
/* NID is 16 bits, per CAI section 2.3.10.3.  There are up to 4 SID+NID    */
/* pairs, in descending preferrence (0=first, 3=last).                     */

typedef struct {
  BYTE                 nam;                               /* NAM id 0-3 */
  nv_sid_nid_pair_type pair[NV_MAX_MINS][NV_MAX_SID_NID]; /* SID+NID Pair */
} nv_sid_nid_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold MIN data checksum.  The checksum is a simple 0xFFFF marker */
/* which specifies that MIN parameters have been programmed and are valid. */

typedef struct {
  BYTE      nam;                             /* NAM id 0-3 */
  WORD      chksum[NV_MAX_MINS];             /* Checksum */
} nv_min_chksum_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold ORIG_MIN id, along with the associated NAM id.             */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  BYTE      id;                     /* MIN id 0-3 */
} nv_orig_min_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold the name of each NAM, along with the associated NAM id.    */

typedef struct {
  BYTE      nam;                    /* NAM id 0-3 */
  BYTE      name[NV_MAX_LTRS];      /* NAM name string */
} nv_name_nam_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

//sya-----start
//typedef enum {
#define  NV_PCS_BLOCK_A		0
#define  NV_PCS_BLOCK_B		1
#define  NV_PCS_BLOCK_C		2
#define  NV_PCS_BLOCK_D		3
#define  NV_PCS_BLOCK_E		4
#define  NV_PCS_BLOCK_F		5
#define  NV_CELLULAR_SYS_A	6
#define  NV_CELLULAR_SYS_B	7
//} nv_block_or_sys_enum_type;
typedef WORD nv_block_or_sys_enum_type;

/* Type to hold SID_NID_LIST, per IS-95A section 6.3.4.                    */

typedef struct {
  word                       sid;
  word                       nid;
  nv_block_or_sys_enum_type  block_or_sys;
  byte                       band_class;
} nv_sid_nid_list_type;
//sya-----end

/* Type to hold ZONE_LIST, per CAI section 6.3.4.                          */

typedef struct {
  WORD      reg_zone;            /* REG_ZONEsp */
  WORD      sid;                 /* SIDsp */
  WORD      nid;                 /* NIDsp */
//SYA--------START
  nv_block_or_sys_enum_type  block_or_sys;
  byte                       band_class;
//SYA--------END
} nv_zone_list_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold distance based registration paremeters, per CAI            */
/* section 6.3.4.                                                          */

typedef struct {
  DWORD     base_lat_reg;        /* BASE_LAT_REGsp */
  DWORD     base_long_reg;       /* BASE_LONG_REGsp */
  WORD      reg_dist_reg;        /* BASE_DIST_REGsp */
} nv_dist_reg_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold call timers and associated NAM id.  Each NAM has its own   */
/* set of these timers, with units as shown.   The range of these timers   */
/* is more then 100 years.                                                 */
/*                                                                         */
/*    Timer             units                                              */
/*    -----             -----                                              */
/*    Call Time         seconds                                            */
/*    Air Time          minutes                                            */
/*    Roam Time         minutes                                            */
/*    Life Time         minutes                                            */

typedef struct {
  BYTE      nam;            /* NAM id 0-3 */
  DWORD     time;           /* Time */
} nv_call_time_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold run timer, with units as shown.  The range is a zillion    */
/* years.                                                                  */
/*                                                                         */
/*    Timer             units                                              */
/*    -----             -----                                              */
/*    Run Time          minutes                                            */

typedef struct
{
  DWORD     time;       /* Time */
} nv_run_time_type;

typedef struct {
  byte      nam;            /* NAM id 0-N */
  dword     cnt;            /* count */
} nv_call_cnt_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold speed dial number.  'num_digits' and 'num_letters'         */
/* indicate the actual number of digits and letters, or zero if none.      */
/* The storage address is in the range 0-99 for speed dial numbers         */

typedef struct {
  BYTE      address;                      /* Storage address 0-99 */
#if ((TG==T_G) || (TG==T_PC) || (TG==T_DM) || (TG==T_SP))
  BYTE      status;                       /* flag bits */
#endif /* TG==T_G || TG==T_PC || TG==T_DM || TG==T_SP */
  BYTE      num_digits;                   /* Number of digits */

//sya---start
  byte      voiced; //SYA                       /* Voice saved ? */
//sya----end

  BYTE      digits[NV_MAX_DIAL_DIGITS];   /* Array of digits */
  BYTE      letters[NV_MAX_LTRS];         /* Name associated with number */
} nv_dial_type;

typedef struct {
  DWORD     record_id;
  BYTE      address;                      /* Storage address 0-99 */
#if ((TG==T_G) || (TG==T_PC) || (TG==T_DM) || (TG==T_SP))
  BYTE      status;                       /* flag bits */
#endif /* TG==T_G || TG==T_PC || TG==T_DM || TG==T_SP */
  BYTE      num_digits;                   /* Number of digits */

  BYTE      digits[NV_MAX_DIAL_DIGITS];   /* Array of digits */
  BYTE      letters[NV_MAX_LTRS];         /* Name associated with number */
  byte      voiced; //SYA                       /* Voice saved ? */
} nv_speed_dial_type;


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold stack dial number.  'num_digits' and 'num_letters'         */
/* indicate the actual number of digits and letters, or zero if none.      */
/* The storage address is in the range 0-9 for a stack number              */

typedef struct {
  BYTE      address;                      /* Storage address 0-9 */
#if ((TG==T_G) || (TG==T_PC) || (TG==T_DM) || (TG==T_SP))
  BYTE      status;                       /* flag bits */
  DWORD     time_stamp;                   /* years to seconds */
#endif /* TG==T_G || TG==T_PC || TG==T_DM || TG==T_SP */
  BYTE      num_digits;                   /* Number of digits */
  BYTE      digits[NV_MAX_DIAL_DIGITS];   /* Array of digits */
  BYTE      letters[NV_MAX_LTRS];         /* Name associated with number */
} nv_stdial_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold call stack index.  The array of BYTEs allows sorting the   */
/* call stack by order of dialing and resorting as it is being used.  The  */
/* secret field indicates if a secret number is in that stack location.    */

typedef struct {
  BYTE      index[NV_MAX_STACK_DIALS];   /* Index array */
  boolean   secret[NV_MAX_STACK_DIALS];  /* TRUE if a secret number */
} nv_stack_idx_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to specify page answer rings and answer mode.                      */

#define NV_PAGE_DISABLE 0
#define NV_PAGE_SILENT  1
#define NV_PAGE_AUDIBLE 2

typedef struct {
  BYTE   enable;            /* paging mode */
  BYTE   rings;             /* Number of rings when to accept page */
} nv_page_set_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold page message.  The page characters are stored as ASCII     */
/* string.                                                                 */

#define  NV_MAX_PAGE_CHARS 20            /* Up to 20 characters in a page */

typedef struct {
  BYTE               address;                      /* Storage address 0-19 */
  DWORD              time_stamp;                   /* Time stamp */
  boolean            new1;                          /* New page status */
  BYTE               num_chars;                    /* Number of characters */
  BYTE               chars[NV_MAX_PAGE_CHARS];     /* Array of characters */
} nv_page_msg_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold display banner.  The banner is fixed length and is stored  */
/* as ASCII string.                                                        */

typedef struct {
  BYTE      letters[NV_MAX_LTRS];            /* Banner */
} nv_banner_type;

typedef struct {//4.05 YJG 2002.5.29
  int       form;
  int       t_color;
  int       b_color;
  byte      letters[NV_MAX_LTRS+1];            /* Banner */
} nv_banner2_type;

//sya-----start
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

typedef struct {
  byte      wdc[NV_WDC_LTRS];            /* Warranty date code */
  byte      extra[3];                    /* in case the wdc def. changes */
} nv_wdc_type;


#define ROAM_NUM_SYS      9
/*--------------------------------------------------------------------------*/
typedef struct {
  byte      nam;                          /* NAM id 0-N       */
  byte  pref_only;
  byte  avail_sys_roam_ind;
  byte  num_records;
  byte  reserved;
} nv_roam_main_type;

/*--------------------------------------------------------------------------*/
typedef struct {
  byte      nam;                          /* NAM id 0-N       */
  byte  roam_sub_id;  // 0 to 9 -> 1,,10
  byte  system_type;
  byte  freq_type;
  byte  block;
  word  channel_num;
  byte  nid_include;
  byte  num_sys;

  struct {
     word  sid;
     word  nid;
     byte  roam_ind;
  } roam_num_sys[ROAM_NUM_SYS];
} nv_roam_sub_type;
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold Field Service Code is fixed length and is stored           */
/* as ASCII string.                                                        */

typedef struct {
  byte      fsc[NV_FSC_SIZ];            /* Field Service Code */
} nv_fsc_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold the standing alarms for India DOT                          */

typedef struct {
  byte       alarm_id;                  /* which standing alarm */
  dword      alarms;                    /* DOT alarms */
} nv_alarms_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold the standing alarms for India DOT                          */

typedef struct {
  byte      isd_std_passwd[NV_ISD_STD_PASSWD_SIZ];
} nv_isd_std_passwd_type;
//sya-----end

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to specify auto answer rings and enable/disable.                   */

typedef struct {
  boolean   enable;            /* TRUE if auto answer enabled */
  BYTE      rings;             /* Number of rings when to answer call */
} nv_auto_answer_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to specify auto redial rings and enable/disable.                   */

typedef struct {
  boolean   enable;      /* TRUE if auto redial enabled */
  BYTE      rings;       /* Number of 10 seconds system busy before redial */
} nv_auto_redial_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold maintenance order and reason code.  Maintenance reason is  */
/* per IS-95 section 7.7.4.                                                */

typedef struct {
  boolean maint_order;   /* Set when maintenance order received            */
  BYTE    maint_reason;  /* Maintenance reason received in the order       */
} nv_maintrsn_type;
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold lock order and reason code.  Lock reason is per CAI        */
/* section 7.7.4.                                                          */

typedef struct {
  boolean lock_order;   /* Set when lock order received and until unlocked */
  BYTE    lock_reason;  /* Lock reason received in the order */
} nv_lckrsn_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold user lock code.  The lock code is fixed length and is      */
/* stored as ASCII string.                                                 */

#define  NV_LOCK_CODE_SIZE 4              /* 4 digit lock code */

typedef struct {
  BYTE      digits[NV_LOCK_CODE_SIZE];    /* Lock code array */
} nv_lock_code_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold security code.  The security code is fixed length and is   */
/* stored as ASCII string.                                                 */

#define  NV_SEC_CODE_SIZE 6               /* 6 digit security code */

typedef struct {
  BYTE      digits[NV_SEC_CODE_SIZE];     /* Security code array */
} nv_sec_code_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold error log.  Up to NV_MAX_ERR_LOG error codes are stored,   */
/* each with number of times detected, file name, and line number.         */

typedef struct {
  BYTE      address;                         /* Storage address 0 to       */
                                             /*  NV_MAX_ERR_LOG-1          */
  BYTE      err_count;                       /* Number of occurances       */
                                             /* (0=empty,FF=full)          */
  BYTE      file_name[NV_ERR_FILE_NAME_LEN]; /* File name string */
  WORD      line_num;                        /* Line number in file */  
  boolean   fatal;                           /* TRUE if fatal error */
} nv_err_log_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type for peek.  Can peek at up to 32 BYTEs in one request.              */

#define  NV_MAX_PEEK_SIZE  32 

typedef struct {
  WORD      address;                   /* Where to start peek from */
  BYTE      length;                    /* How many BYTEs to peek */
  BYTE      mem[NV_MAX_PEEK_SIZE];     /* Returned peek data */
} nv_peek_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type for poke.  Can poke up to 32 BYTEs in one request.                 */

#define  NV_MAX_POKE_SIZE  32 

typedef struct {
  WORD      address;                   /* Where to start poke */
  BYTE      length;                    /* How many BYTEs to poke */
  BYTE      mem[NV_MAX_POKE_SIZE];     /* Poke data */
} nv_poke_type;


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type for real sms item                                                 */

typedef struct {
  BYTE        address;                 /* sms entry [0..23] */
  BYTE        status;                  /* status mask */
  BYTE        user_data_length;
  BYTE        call_back_length; 
  QWORD       param_mask;
  WORD        length;                  /* BYTEs in 'data', [8..325] */
  BYTE        data[NV_SMS_DATA_SIZ];   /* generic sms data, variable size */
} nv_sms_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type for real dm sms item                                               */

typedef struct {
  BYTE        address;                 /* sms entry [0..23] */
  BYTE        status;                  /* status mask */
  BYTE        user_data_length;
  BYTE        call_back_length; 
  QWORD       param_mask;
  WORD        length;                  /* BYTEs in 'data', [8..325] */
  BYTE        data[NV_SMS_DM_DATA_SIZ];   /* generic sms data, variable size */
} nv_sms_dm_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type for generic minimum/maximum type                                   */

typedef struct {
  BYTE        min;                      
  BYTE        max;
} nv_minmax_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type for Analog (FM) TX power levels                                    */

typedef struct {
  BYTE        level_0;                               /* power level 0 (max)*/
  BYTE        level_1;                                    /* power level 1 */
  BYTE        level_2;                                    /* power level 2 */
  BYTE        level_3;                                    /* power level 3 */
  BYTE        level_4;                                    /* power level 4 */
  BYTE        level_5;                                    /* power level 5 */
  BYTE        level_6;                                    /* power level 6 */
  BYTE        level_7;                                    /* power level 7 */
} nv_fm_tx_pwr_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type for Frequency/Temperature Offset Table                             */

#define NV_FR_TEMP_OFFSET_TABLE_SIZ 64

typedef struct {
  BYTE   item[NV_FR_TEMP_OFFSET_TABLE_SIZ];
} nv_fr_temp_offset_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type for Frequency Adjustment Table                                     */

#define NV_FREQ_ADJ_TABLE_SIZ 32

typedef struct {
  BYTE item[ NV_FREQ_ADJ_TABLE_SIZ];
} nv_freq_adj_type;

//sya----start
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold IMSI, along with the associated NAM id.                    */
/* The number is 51 bits, per J-STD-008 section 2.3.1.                     */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  qword     imsi;                   /* International Mobile Station ID */
} nv_imsi_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold IMSI length, along with the associated NAM id.             */
/* The number is 3 bits, per J-STD-008 section 2.3.1.                      */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  byte      num;                    /* Length of the IMSI for this NAM */
} nv_imsi_addr_num_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Type for EVRC preferred voice service options.                          */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  boolean   evrc_capability_enabled;
  word      home_page_voice_so;
  word      home_orig_voice_so;
  word      roam_orig_voice_so;
} nv_pref_voice_so_type;

#define		NV_MAX_HOME_SID_NID 20        /* Up to 20 "home" SID/NID pairs */
typedef struct { // 
	byte					nam;                               /* NAM id 0-N */
	nv_sid_nid_pair_type pair[NV_MAX_HOME_SID_NID];            /* SID+NID Pair */
}nv_home_sid_nid_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold TMSI zone length, along with the associated NAM id.               */
/* The number is 4 bits, per J-STD-008 section 2.3.15.                    */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  byte      length;                 /* The TMSI zone length */
} nv_tmsi_zone_length_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold TMSI zone, along with the associated NAM id.               */
/* The number is 64 bits, per J-STD-008 section 2.3.15.                    */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  qword     zone;                   /* The TMSI zone */
} nv_tmsi_zone_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold TMSI code, along with the associated NAM id.               */
/* The number is 32 bits, per J-STD-008 section 2.3.15.                    */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  dword     code;                   /* The TMSI code */
} nv_tmsi_code_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold TMSI expiration timer, along with the associated NAM id.   */
/* The number is 24 bits, per J-STD-008 section 2.3.15.                    */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  dword     time;                   /* The TMSI expiration timer */
} nv_tmsi_exp_time_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold the subscriber's home block (3 bits), along with the       */
/* associated NAM id.                                                      */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  byte      block;                  /* Home block */
} nv_home_block_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold the roaming list, along with the associated NAM id.        */
/* Roaming list is bit-packed.                                             */

#ifdef FEATURE_NV_ONE_NAM_RL_LARGE
#else
#define  NV_ROAMING_LIST_MAX_SIZE  200
#endif

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  word      size;
  byte      roaming_list[NV_ROAMING_LIST_MAX_SIZE];
} nv_roaming_list_type;

/* Same structure as roaming_list_type but for use in union nv_item_type */
typedef struct {
  byte      nam;
  word      size;
  byte      roaming_list[1];
} nv_roaming_list_union_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold the MRU table, along with the associated NAM id.           */

#define  NV_MRU_TABLE_SIZE 12       /* Table consists of 12 words */

typedef struct {
  byte      nam;                    /* NAM id 0-N */
  word      table[NV_MRU_TABLE_SIZE];
} nv_mru_table_type;
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Type to hold the MRU table (new format), along with the associated NAM. */

#define  NV_MRU2_TABLE_SIZE 12       /* Table consists of 12 words */

/* Specifies the mode: AMPS or CDMA */
#define  NV_MODE_INACTIVE  0
#define  NV_MODE_ANALOG    1
#define  NV_MODE_CDMA      2

#define  NV_SYSTEM_A   0
#define  NV_SYSTEM_B   1

typedef WORD nv_system_type;

/* Specifies either a channel or cellular system */
typedef union {
  word            cdma_channel;     /* The CDMA channel to acquire */
  nv_system_type  cellular_system;  /* The cellular system: A or B */
} nv_cs_union_type;

/* An MRU2 Table entry */
typedef struct {
  byte              mode;           /* The mode: AMPS or CDMA */
  byte              band_class;     /* The band class: cellular or PCS */
  nv_cs_union_type  cs;             /* The CDMA channel or cellular system */
} nv_mru2_table_entry_type;

/* The MRU2 Table */
typedef struct {
  byte                      nam;     /* NAM id 0-N */
  nv_mru2_table_entry_type  entry[NV_MRU2_TABLE_SIZE];
} nv_mru2_table_type;


/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* For OTASP "commit" operation -- type to hold the mobile directory       */
/* number (per IS-683 section 3.5.2.2).                                    */

typedef struct {
  byte      nam;                          /* NAM id 0-N       */
  byte      n_digits;                     /* Number of digits */
  byte      digitn[NV_DIR_NUMB_PCS_SIZ];  /* The digits       */
} nv_mob_dir_data_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* For OTASP "commit" operation -- type to hold the PCS indicator data     */
/* parameter block (per IS-683 section 4.5.2.3).                           */

typedef struct {
  byte     imsi_addr_num;     /* Number of IMSI address digits             */
  word     mcc;               /* Mobile country code                       */
  byte     imsi_11_12;        /* 11th and 12th digits of IMSI              */
  qword    imsi_s;            /* Last 10 digits of IMSI, encoded           */
  dword    imsi_s1;           /* Corresponds to old min1                   */
  word     imsi_s2;           /* Corresponds to old min2                   */
  byte     accolc;            /* Access overload class                     */
  boolean  mob_term_home;     /* Termination indicator for the home system */
  boolean  mob_term_for_sid;  /* Termination indicator for SID roaming     */
  boolean  mob_term_for_nid;  /* Termination indicator for NID roaming     */
  struct {
    word   sid;               /* System identification                     */
    word   nid;               /* Network identification                    */
  } pair[NV_MAX_SID_NID];
} nv_pcs_data_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* For OTASP "commit" operation -- type to hold the consolidated data to   */
/* be committed, along with control flags.                                 */

typedef struct {
  byte nam;                      /* Which NAM the data is for              */
  boolean commit_mob_dir;        /* Commit mobile directory number if set  */
  boolean commit_ftc_pcs;        /* Commit PCS indicator data block if set */
  boolean commit_roam_list;      /* Commit roaming list if set             */
  nv_mob_dir_data_type mob_dir;  /* The data to commit to nv               */
  nv_pcs_data_type ftc_pcs;              /* The data to commit to nv       */
  nv_roaming_list_type *roam_list_ptr;   /* The data to commit to nv       */
} nv_otasp_commit_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* --------------------------------------                                  */
/* PTIORITY :     '00' ->  Normal                                          */
/*                '01' ->  Interactive                                     */
/*                '10' ->  Urgent                                          */
/*                '11' ->  Emergency                                       */
/*                                                                         */
/* SERVICE  :      TBD                                                     */
/*                                                                         */
/* LANGUAGE :     '0'  ->  Unknown or unspecified                          */
/*                '1'  ->  English                                         */
/*                '2'  ->  French                                          */
/*                '3'  ->  Spanish                                         */
/*                'X'  ->  Korean (TBD)                                    */
  typedef struct
  {
    byte priority;          /* Broadcasting message priority */
    //word service;           /* Broadcasting service category */
    byte language;          /* Broadcasting message language indicator */
  } nv_bcast_config_type;
//sya----end

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Values for NV_MAX_TX_ADJ_I                                              */

#define NV_MUTE_NORM 0
#define NV_MUTE_MUTE 1
#define NV_MUTE_SPKR 2


//sya----start
typedef struct {
  byte    alarm_time[4];
} nv_alarm_time_type;
//sya----end

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Array size for NV_FACTORY_INFO_I                                        */

//#define NV_FACTORY_INFO_SIZ  100

//sya----start
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* Array size for NV_FACTORY_INFO_I                                        */

#define NV_FACTORY_INFO_SIZ  86
#define SYS_TIME_SIZ         12
#define CODE_SIZ              2 
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* factory  information */
typedef  struct {
  byte      pc_code[CODE_SIZ];
  byte      sys_time[SYS_TIME_SIZ];
  byte      fac_info[NV_FACTORY_INFO_SIZ];
} nv_factory_info_type;

typedef struct {
  byte      address;                      /* Storage address */
  byte      status;                       /* flag bits */
  word      month;
  word      day;
  byte      letter[NV_MAX_LTRS];
} nv_anniversary_type;

typedef struct {
  byte      status;       
  word      hour;
  word      minute;
  boolean   am_pm;       
  byte      num_digits;
  byte      number[NV_MAX_DIAL_DIGITS];   
} nv_reservation_type;

typedef struct{
  byte      status;
  word      hour;
  word      minute;
  boolean   am_pm;               
} nv_alarm_type;

typedef struct{
  byte      address;
  boolean   status;
  byte      num_digits;
  byte      digits[NV_MAX_DDD_DIGITS];
} nv_ddd_dial_type;

typedef struct{
  boolean   status;
  byte      address;
  byte      num_digits;
  byte      digits[NV_MAX_DDD_DIGITS];
} nv_ddd_sto_type;
//sya----end

// kang add  1999/12/27
typedef struct {
  byte                 nam;                               /* NAM id 0-N */
  boolean              enabled;
} nv_enabled_type;
// end

/*-------------------------------------------------------------------------*/
#define  FEATURE_4PAGE_TX_LINEARIZER                    //

/* CDMA 4PAGE Tx linearizer master offset size */       //
#ifdef FEATURE_4PAGE_TX_LINEARIZER                      //

 #define NV_CDMA_TX_LIN_MASTER_SIZ     36               //     
                                                        //   for 4page tx linearizer for d520   

 typedef struct {                                       // 
   signed short  offset; 
   byte      slope[NV_CDMA_TX_LIN_MASTER_SIZ];          // 
 } nv_tx_linearizer_type;                               // 

#endif
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

#define NV_FREQ_TABLE_SIZ  16  /* size of all tables based on frequency */
#define NV_TEMP_TABLE_SIZ   8  /* size of all tables based on temperature */

/* Values for NV_TX_COMP0_I, NV_TX_COMP1_I, NV_TX_COMP2_I, NV_TX_COMP3_I   */

typedef struct {
  signed char  nv_cdma_tx_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  signed char  nv_cdma_tx_slp_vs_temp[NV_TEMP_TABLE_SIZ];
  signed char  nv_cdma_tx_comp_vs_freq[NV_FREQ_TABLE_SIZ];
} nv_tx_comp_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

// For DM110Q By O.J.S 2000.06.14
#define  NV_SP_A_ONLY 0          /* A only */
#define  NV_SP_B_ONLY 1            /* B only */
#define  NV_SP_HOME_ONLY 2         /* Home only */
#define  NV_SP_STANDARD 3          /* Home preferred */

typedef WORD  nv_sys_pref_enum_type;

typedef struct {
  byte                    nam;   /* NAM id 0-N */
  nv_sys_pref_enum_type   sys;   /* Preferred system per above enum */
} nv_sys_pref_type;
// end

/* definitions for Port mode                                               */

#define NV_PORT_SYNC_MODE     0      /* Sync (HDLC) mode for port */
#define NV_PORT_BAUD_96_MODE  1      /* 9600 Baud mode */
#define NV_PORT_BAUD_192_MODE 2      /* 19200 Baud mode */
#define NV_PORT_BAUD_384_MODE 3      /* 38400 Baud mode */

/////////YJG 2001.9.4 LG-TM520���� �߰�////////////////////
typedef struct {
  byte    gMmlvl;
  byte    gBacklight_lvl;
} nv_game_settings_type;

#define     NV_MAX_PKT_ORIG_DIGITS  16    /* Maximum 16 digit number */    
typedef struct {
  byte      num_digits;                     /* Number of digits */
  byte      digits[NV_MAX_PKT_ORIG_DIGITS]; /* The digit array */
} nv_data_pkt_orig_str_type;

typedef enum {
  NV_LANGUAGE_ENGLISH,         /* Use English language    */
  NV_LANGUAGE_SPANISH,         /* Use Spanish language    */
  NV_LANGUAGE_FRENCH,          /* Use French language     */   
  NV_LANGUAGE_PORTUGUESE,      /* Use Portuguese language */
  NV_LANGUAGE_ENUM_PAD = 0x7FFF  /* Pad to 16 bits on ARM */
} nv_language_enum_type;

#define     NV_MAX_SID_NID_LOCK 10        /* Up to 10 SID/NIDs to lock out */
typedef struct {
  byte                 nam;                               /* NAM id 0-N */
  nv_sid_nid_pair_type pair[NV_MAX_SID_NID_LOCK];         /* SID+NID Pair */
} nv_sid_nid_lock_type;
///////////////////////////////////////////////////////////

#define NV_VOICE_MAIL_SIZ	32
#define FM_FSG_VS_TEMP_SIZ   8

typedef struct {//4.05-2 YJG 2002.7.23
  byte    ringer_vc_withid;
  byte    ringer_vc_restid;
  byte    ringer_vc_noid;
  byte    ringer_vc_roam;
  byte    ringer_msg_vm;
  byte    ringer_msg_pt;
  byte    ringer_msg_mb;
  byte    ringer_alarms;
} nv_ringertype_type;
/*-------------------------------------------------------------------------*/

/* Return to default packing.                                              */

#pragma pack()




/*-------------------------------------------------------------------------*/

/* Portable RF Turnaround Compensation Table Sizes                         */

#define NV_RIPPLE_COMP_TABLE_SIZ      32
#define NV_RX_OFFSET_TABLE_SIZ        32
#define NV_RX_POWER_TABLE_SIZ        128
#define NV_RX_ERROR_TABLE_SIZ        128
#define NV_TX_SLOPE_1_TABLE_SIZ      128
#define NV_TX_SLOPE_2_TABLE_SIZ      128
#define NV_TX_NON_LIN_ERR_TABLE_SIZ  128
#define NV_HDET_TABLE_SIZ             64

#define NV_PWR_TABLE_SIZ   16  /* size of all tables based on power level */
#define NV_FREQ_TABLE_SIZ  16  /* size of all tables based on frequency */
#define NV_TEMP_TABLE_SIZ   8  /* size of all tables based on temperature */
#define NV_VOLT_TABLE_SIZ   8  /* size of all tables based on battery voltage */
#define NV_FM_FREQ_LEVEL_SIZ  128 /* compensation for therm vs frequency vs level */
#define NV_CDMA_RX_LIN_SIZ          16 /* CDMA Rx linearizer offset size */

#define NV_CDMA_TX_LIN_MASTER_SIZ   36 /* CDMA Tx linearizer master offset size */

#define NV_CDMA_EXP_HDET_VS_AGC_SIZ 16 /* CDMA expected HDET reading vs AGC PDM size */
#define NV_CDMA_ERR_SLP_VS_HDET_SIZ  8 /* CDMA HDET error slope vs HDET reading size */
#define NV_ADJ_VS_FREQ_SIZ           16
#define NV_ADJ_VS_TEMP_SIZ            8
//sp-510 ysi v3.55 1999/12/16
#define NV_CDMA_LNA_LIN_SIZ 8
#define NV_QDSP_CAL_DATA_SIZ  16
#define NV_AUDIO_ADJ_ITEM_SIZ 9

//  [7/16/2007] vivache : rf_cal_ver
#define NV_SIZE_OF_VERSION  8         /* Size of a version number in bytes */

/*=========================================================================*/

/* NVM items union type.  The union is ordered according to the            */
/* NV_xxx_I enum items ordering.  Note that when the caller defines        */
/* or allocates a buffer of this union type, the largest member of         */
/* this union defines the size, and caution should be then exercised.      */
/* The largest member is nv_dial_type which requires 44 BYTEs.             */

/*-------------------------------------------------------------------------*/

typedef union {

/*-------------------------------------------------------------------------*/

/* Physical NAM parameters.                                                */

/*-------------------------------------------------------------------------*/

/* Type for NV_ESN_I item.                                                 */
/* -----------------------                                                 */

  nv_esn_type        esn;

/* Type for NV_ESN_CHKSUM_I item.                                          */
/* ------------------------------                                          */

  nv_esn_chksum_type esn_chksum;

/* Type for NV_VERNO_MAJ_I item.                                           */
/* -----------------------------                                           */
/* This is the NV major version number.  Changing the major version        */
/* number forces a NV memory initialization to default values.             */

  BYTE         verno_maj;

/* Type for NV_VERNO_MIN_I item.                                           */
/* -----------------------------                                           */
/* This is the NV minor version number.  This value is stored for          */
/* information purpose only.                                               */

  BYTE         verno_min;

/* Type for NV_SCM_I item.                                                 */
/* -----------------------                                                 */
/* The SCM is 8 bits, per CAI section 6.3.3.                               */

  BYTE         scm;

/* Type for NV_SLOT_CYCLE_INDEX_I item.                                    */
/* ------------------------------------                                    */
/* The slot cycle index is 3 bits, per CAI section 1.1.2.2.                */

  BYTE         slot_cycle_index;

/* Type for NV_MOB_CAI_REV_I item.                                         */
/* -------------------------------                                         */
/* The Mobile CAI revision is 8 bits, per CAI section 1.1.2.2. and as      */
/* specified for each CAI revision in the title section.                   */

  BYTE         mob_cai_rev;

/* Type for NV_MOB_FIRM_REV_I item.                                        */
/* --------------------------------                                        */
/* Software version number.  16 bits per CAI section 1.1.2.2.              */

  WORD         mob_firm_rev;

/* Type for NV_MOB_MODEL_I item.                                           */
/* -----------------------------                                           */
/* Mobile model.  8 bits per CAI section 1.1.2.2.                          */

  BYTE         mob_model;

/* Type for NV_CONFIG_CHKSUM_I item.                                       */
/* ---------------------------------                                       */

  nv_config_chksum_type       config_chksum;

/*-------------------------------------------------------------------------*/

/* NAM items.                                                              */

/* Type for NV_PREF_MODE_I item.                                           */
/* -----------------------------                                           */

  nv_pref_mode_type  pref_mode;

/* Type for NV_CDMA_PREF_SERV_I item.                                      */
/* -----------------------------                                           */

  nv_pref_serv_type   cdma_pref_serv;

/* Type for NV_ANALOG_PREF_SERV_I item.                                    */
/* ------------------------------------                                    */

  nv_pref_serv_type   analog_pref_serv;  

/* Type for NV_CDMA_SID_LOCK_I item.                                       */
/* ---------------------------------                                       */

  nv_sid_lock_type      cdma_sid_lock;

/* Type for NV_CDMA_SID_ACQ_I item.                                        */
/* --------------------------------                                        */

  nv_sid_acq_type       cdma_sid_acq;

/* Type for NV_ANALOG_SID_LOCK_I item.                                     */
/* -----------------------------------                                     */

  nv_sid_lock_type      analog_sid_lock;

/* Type for NV_ANALOG_SID_ACQ_I item.                                      */
/* ----------------------------------                                      */

  nv_sid_acq_type       analog_sid_acq;

/* Type for NV_ANALOG_FIRSTCHP_I item.                                     */
/* -----------------------------------                                     */

  nv_firstchp_type      analog_firstchp;

/* Type for NV_ANALOG_HOME_SID_I item.                                     */
/* -----------------------------------                                     */

  nv_sid_type           analog_home_sid;

/* Type for NV_ANALOG_REG_I item.                                          */
/* ------------------------------                                          */

  nv_analog_reg_type       analog_reg;

/* Type for NV_PCDMACH_I item.                                             */
/* ---------------------------                                             */

  nv_cdmach_type           pcdmach;

/* Type for NV_SCDMACH_I item.                                             */
/* ---------------------------                                             */

  nv_cdmach_type           scdmach;

/* Type for NV_PPCNCH_I item.                                              */
/* --------------------------                                              */

  nv_cdmach_type           ppcnch;

/* Type for NV_SPCNCH_I item.                                              */
/* --------------------------                                              */

  nv_cdmach_type           spcnch;

/* Type for NV_NAM_CHKSUM_I item.                                          */
/* ------------------------------                                          */

  nv_nam_chksum_type       nam_chksum;

/* Type for NV_A_KEY_I item.                                               */
/* -------------------------                                               */

  nv_a_key_type   a_key;

/* Type for NV_A_KEY_CHKSUM_I item.                                        */
/* --------------------------------                                        */

  nv_a_key_chksum_type   a_key_chksum;

/* Type for NV_SSD_A_I item.                                               */
/* -------------------------                                               */

  nv_ssd_type     ssd_a;

/* Type for NV_SSD_A_CHKSUM_I item.                                        */
/* --------------------------------                                        */

  nv_ssd_chksum_type     ssd_a_chksum;

/* Type for NV_SSD_B_I item.                                               */
/* -------------------------                                               */

  nv_ssd_type     ssd_b;

/* Type for NV_SSD_B_CHKSUM_I item.                                        */
/* --------------------------------                                        */

  nv_ssd_chksum_type     ssd_b_chksum;

/* Type for NV_COUNT_I item.                                               */
/* -------------------------                                               */

  nv_count_type   count;

/*-------------------------------------------------------------------------*/

/* MIN items.                                                              */

/*-------------------------------------------------------------------------*/

/* Type for NV_MIN1_I item.                                                */
/* ------------------------                                                */

  nv_min1_type       min1;

/* Type for NV_MIN2_I item.                                                */
/* ------------------------                                                */

  nv_min2_type       min2;

/* Type for NV_IMSI_T_S1_I item.                                           */
/* -----------------------------                                           */

  nv_min1_type       imsi_t_s1;

/* Type for NV_IMSI_T_S2_I item.                                           */
/* -----------------------------                                           */

  nv_min2_type       imsi_t_s2;


/* Type for NV_MOB_TERM_HOME_I item.                                       */
/* ---------------------------------                                       */

  nv_mob_term_type    mob_term_home;

/* Type for NV_MOB_TERM_FOR_SID_I item.                                    */
/* ------------------------------------                                    */

  nv_mob_term_type       mob_term_for_sid;

/* Type for NV_MOB_TERM_FOR_NID_I item.                                    */
/* ------------------------------------                                    */

  nv_mob_term_type       mob_term_for_nid;

/* Type for NV_ACCOLC_I item.                                              */
/* --------------------------                                              */

  nv_accolc_type     accolc;

/* Type for NV_SID_NID_I item.                                             */
/* ---------------------------                                             */

  nv_sid_nid_type    sid_nid;

/* Type for NV_MIN_CHKSUM_I item.                                          */
/* ------------------------------                                          */

  nv_min_chksum_type    min_chksum;

/*-------------------------------------------------------------------------*/

/* Operational NAM settings.                                               */

/*-------------------------------------------------------------------------*/

/* Type for NV_CURR_NAM_I item.                                            */
/* ----------------------------                                            */
/* This type holds the id of the current NAM (0-3) and is then used to     */
/* identify or index into any parameter which is NAM specific.             */

  BYTE          curr_nam;

/* Type for NV_ORIG_MIN_I item.                                            */
/* -----------------------------                                           */
/* This type holds the id of the MIN (0-3) within the current NAM (0-3)    */
/* which specifies the MIN used for call origination.  This id may be      */
/* changed by the user and is retained during powerdown.                   */

  nv_orig_min_type  orig_min;

/* Type for NV_AUTO_NAM_I item.                                            */
/* ----------------------------                                            */
/* If auto nam is set then the phone will automatically switch to the      */
/* the new NAM if it is defined as one of the four NAMs and if the phone   */
/* has matched the SID of this new NAM as it roamed into a new SID.        */

  boolean      auto_nam;

/* Type for NV_NAME_NAM_I item.                                            */
/* -----------------------------                                           */
/* This type holds the name of each NAM.                                   */

  nv_name_nam_type  name_nam;

/*-------------------------------------------------------------------------*/

/* Semi-permanent analog registration parameters.                          */

/*-------------------------------------------------------------------------*/

/* Type for NV_NXTREG_I item.                                              */
/* ----------------------------                                            */
/* Holds the registration count per CAI section 2.3.4.1.                   */

  DWORD        nxtreg;

/* Type for NV_LSTSID_I item.                                              */
/* --------------------------                                              */
/* Holds the last SID registered to, per CAI section 2.3.4.1.              */

  WORD         lstsid;

/* Type for NV_LOCAID_I item.                                              */
/* --------------------------                                              */
/* Holds the location area ID, per CAI section 2.3.4.2.                    */

  WORD         locaid;

/* Type for NV_PUREG_I item.                                               */
/* -------------------------                                               */
/* Holds the powerup registration identifier, per CAI section 2.3.4.2.     */

  boolean      pureg;

/*-------------------------------------------------------------------------*/

/* Semi-permanent CDMA registration parameters.                            */

/*-------------------------------------------------------------------------*/

/* Type for NV_ZONE_LIST_I item.                                           */
/* -----------------------------                                           */

  nv_zone_list_type        zone_list;

/* Type for NV_SID_NID_LIST_I item.                                        */
/* --------------------------------                                        */
/* Holds the SID+NID list, per CAI section 6.3.4.                          */

  nv_sid_nid_pair_type     sid_nid_list;

/* Type for NV_DIST_REG_I item.                                            */
/* ----------------------------                                            */

  nv_dist_reg_type         dist_reg;

/* Type for NV_LAST_CDMACH_I item.                                         */
/* -------------------------------                                         */

  nv_cdmach_type           last_cdmach;

/*-------------------------------------------------------------------------*/

/* Timers.                                                                 */
            
/*-------------------------------------------------------------------------*/

/* Type for NV_CALL_TIMER_I item.                                          */
/* ------------------------------                                          */

  nv_call_time_type   call_timer;

/* Type for NV_AIR_TIMER_I item.                                           */
/* ------------------------------                                          */

  nv_call_time_type   air_timer;

/* Type for NV_ROAM_TIMER_I item.                                          */
/* ------------------------------                                          */

  nv_call_time_type   roam_timer;

/* Type for NV_LIFE_TIMER_I item.                                          */
/* ------------------------------                                          */

  nv_call_time_type   life_timer;

/* Type for NV_RUN_TIMER_I item.                                           */
/* ------------------------------                                          */

  nv_run_time_type    run_timer;

/*-------------------------------------------------------------------------*/

/* Speed dial numbers.                                                     */

/*-------------------------------------------------------------------------*/

/* Type for NV_DIAL_I item.                                                */
/* ------------------------                                                */

  nv_dial_type       dial;

  nv_speed_dial_type   speed_dial;//for SP110C/DM110C
/* Type for NV_STACK_I item.                                               */
/* -------------------------                                               */

  nv_stdial_type       stack;

/* Type for NV_STACK_IDX_I item.                                           */
/* -----------------------------                                           */

  nv_stack_idx_type  stack_idx;

/*-------------------------------------------------------------------------*/

/* Page messages.                                                          */

/*-------------------------------------------------------------------------*/

/* Type for NV_PAGE_SET_I item.                                            */
/* ----------------------------                                            */

  nv_page_set_type   page_set;

/*-------------------------------------------------------------------------*/

/* Type for NV_PAGE_MSG_I item.                                            */
/* ----------------------------                                            */

  nv_page_msg_type   page_msg;

/*-------------------------------------------------------------------------*/

/* Volumes.                                                                */

/*-------------------------------------------------------------------------*/

/* Type for NV_EAR_LEVEL_I item.                                           */
/* -----------------------------                                           */
/* Volume is from 1 (min) to 255 (max) and 0 means OFF (or SILENCE).       */

  BYTE         ear_level;

/* Type for NV_SPEAKER_LEVEL_I item.                                       */
/* ---------------------------------                                       */
/* Volume is from 1 (min) to 255 (max) and 0 means OFF (or SILENCE).       */

  BYTE         speaker_level;

/* Type for NV_RINGER_LEVEL_I item.                                        */
/* --------------------------------                                        */
/* Volume is from 1 (min) to 255 (max) and 0 means OFF (or SILENCE).       */

  BYTE         ringer_level;

/* Type for NV_BEEP_LEVEL_I item.                                          */
/* -----------------------------                                           */
/* Volume is from 1 (min) to 255 (max) and 0 means OFF (or SILENCE).       */

  BYTE         beep_level;

/*-------------------------------------------------------------------------*/

/* Tones.                                                                  */

/*-------------------------------------------------------------------------*/

/* Type for NV_CALL_BEEP_I item.                                           */
/* -----------------------------                                           */
/* When set the user is beeped during a call once a minute on the          */
/* 50 seconds mark.                                                        */

  boolean      call_beep;

/* Type for NV_CONT_KEY_DTMF_I item.                                       */
/* ---------------------------------                                       */
/* When set this means that manual DTMF tones should be sent as continuous */
/* instead of as burst tones.                                              */

  boolean      cont_key_dtmf;

/* Type for NV_CONT_STR_DTMF_I item.                                       */
/* ---------------------------------                                       */
/* When set this means that string DTMF tones should be sent as continuous */
/* instead of as burst tones.                                              */

  boolean      cont_str_dtmf;

/* Type for NV_SVC_AREA_ALERT_I item.                                      */
/* ----------------------------------                                      */
/* When set this means that the phone beeps whenever it leaves a service   */
/* area and whenever it enters a service area.                             */

  boolean      svc_area_alert;

/* Type for NV_CALL_FADE_ALERT_I item.                                     */
/* -----------------------------------                                     */
/* When set this means that the phone beeps whenever a call fades.         */

  boolean      call_fade_alert;

/*-------------------------------------------------------------------------*/

/* Various phone settings.                                                 */

/*-------------------------------------------------------------------------*/

/* Type for NV_BANNER_I item.                                              */
/* --------------------------                                              */

  nv_banner_type  banner;

  nv_banner2_type  banner2;//4.05 YJG 2002.5.29

/* Type for NV_LCD_I item.                                                 */
/* --------------------------                                              */
/* Specifies handset brightness, with 1 lowest, 255 highest, and 0 means   */
/* blank (lights out).                                                     */

  BYTE         lcd;

/* Type for NV_AUTO_POWER_I item.                                          */
/* ------------------------------                                          */
/* This values specifies, in units of ten minutes, how long the phone      */
/* should stay in power on when ignition is turned off:                    */
/*                                                                         */
/* 0        - power off when ignition is turned off                        */
/* 1-254    - stay in power on, range is from 10 minutes to 42 hours       */
/* 255      - do not ever power down (good for testing)                    */

  BYTE         auto_power;

/* Type for NV_AUTO_ANSWER_I item.                                         */
/* -------------------------------                                         */

  nv_auto_answer_type   auto_answer;

/* Type for NV_AUTO_REDIAL_I item.                                         */
/* -------------------------------                                         */

  nv_auto_redial_type   auto_redial;

/* Type for NV_AUTO_HYPHEN_I item.                                         */
/* -------------------------------                                         */
/* When set the phone inserts hyphens automatically after 4, 7, 10, and 11 */
/* digits (i.e. 1-619-587-1121).  When cleared no hyphens are entered.     */

  boolean         auto_hyphen;

/* Type for NV_BACK_LIGHT_I item.                                          */
/* ------------------------------                                          */
/* This values specifies how many seconds should pass before the           */
/* backlighting is turned off, starting from the last moment when any      */
/* key was touched:                                                        */
/*                                                                         */
/* 0        - backlight never on                                           */
/* 1-10     - number of seconds before turning off                         */
/* 11-254   - illegal value                                                */
/* 255      - backlight never off                                          */

  BYTE      back_light;

/* Type for NV_AUTO_MUTE_I item.                                           */
/* -----------------------------                                           */
/* When set this causes the phone to mute the car stereo when a call is    */
/* started and unmute the car stereo when the call is ended.               */

  boolean      auto_mute;

/*-------------------------------------------------------------------------*/

/* Locks and restrictions.                                                 */

/*-------------------------------------------------------------------------*/

/* Type for NV_MAINTRSN_I item.                                            */
/* ---------------------------                                             */

  nv_maintrsn_type     maintrsn;

/* Type for NV_LCKRSN_P_I item.                                            */
/* -----------------------------                                           */

  nv_lckrsn_type     lckrsn_p;

/* Type for NV_LOCK_I item.                                                */
/* ------------------------                                                */
/* Set when the phone is locked (from the keypad), cleared when unlocked   */
/* (from the keypad).                                                      */

  boolean      lock;

/* Type for NV_LOCK_CODE_I item.                                           */
/* -----------------------------                                           */

  nv_lock_code_type lock_code;

/* Type for NV_AUTO_LOCK_I item.                                           */
/* ---------------------------------                                       */
/* When set this means that everytime the phone is powered down it is      */
/* electronically locked and must be unlocked via the lock code.           */

  boolean      auto_lock;

/* Type for NV_CALL_RSTRC_I item.                                          */
/* ------------------------------                                          */
/* WORD holding call restrictions bit map.  If the WORD is cleared         */
/* (all zeros) then no call restrictions are in place.                     */

  WORD         call_rstrc;

/* Type for NV_SEC_CODE_I item.                                            */
/* ----------------------------                                            */

  nv_sec_code_type   sec_code;

/* Type for NV_HORN_ALERT_I item.                                          */
/* ------------------------------                                          */
/* When set the horn sounds if the phone rings while ignition is off.      */

  boolean      horn_alert;

/*-------------------------------------------------------------------------*/

/* Error log.                                                              */

/*-------------------------------------------------------------------------*/

/* Type for NV_ERR_LOG_I item.                                             */
/* ---------------------------                                             */

  nv_err_log_type    err_log;

/*-------------------------------------------------------------------------*/


/* Miscellaneous items.                                                    */

/* Type for NV_UNIT_ID_I item.                                             */
/* ---------------------------                                             */

  DWORD             unit_id;

/* Type for NV_FREQ_ADJ_I item (table).                                    */
/* ------------------------------------                                    */

  nv_freq_adj_type  freq_adj;


/*-------------------------------------------------------------------------*/

/* Type for peek operation.                                                */
/* ------------------------                                                */

  nv_peek_type     peek;


/*-------------------------------------------------------------------------*/

/* Type for poke operation.                                                */
/* ------------------------                                                */

  nv_poke_type     poke;


/*-------------------------------------------------------------------------*/

/* Type for NV_VBATT_I item.                                               */
/* -----------------------------                                           */

   nv_minmax_type     vbatt;


/*-------------------------------------------------------------------------*/

/* Type for NV_FM_TX_PWR_I item.                                           */
/* -------------------------------                                         */

  nv_fm_tx_pwr_type   fm_tx_pwr;


/*-------------------------------------------------------------------------*/

/* Type for NV_FR_TEMP_OFFSET_I item.                                      */
/* -------------------------------                                         */

  nv_fr_temp_offset_type  fr_temp_offset;  

/*-------------------------------------------------------------------------*/

/* Type for NV_CDMA_TX_LIMIT_I item.                                       */
/* ---------------------------------                                       */

  BYTE    cdma_tx_limit;


/*-------------------------------------------------------------------------*/

/* Type for   NV_FM_RSSI_I  item.                                          */
/* ---------------------------------                                       */

  nv_minmax_type    fm_rssi;


/*-------------------------------------------------------------------------*/

/* Type for   NV_CDMA_RIPPLE_I item.                                       */
/* ---------------------------------                                       */

  BYTE    cdma_ripple[ NV_RIPPLE_COMP_TABLE_SIZ];


/*-------------------------------------------------------------------------*/

/* Type for   NV_CDMA_RX_OFFSET_I item.                                    */
/* ---------------------------------                                       */

  BYTE    cdma_rx_offs[ NV_RX_OFFSET_TABLE_SIZ];


/*-------------------------------------------------------------------------*/

/* Type for   NV_CDMA_RX_POWER_I item.                                     */
/* ---------------------------------                                       */

  BYTE    cdma_rx_pwr[ NV_RX_POWER_TABLE_SIZ];


/*-------------------------------------------------------------------------*/

/* Type for   NV_CDMA_RX_ERROR_I item.                                     */
/* ---------------------------------                                       */

  BYTE    cdma_rx_err[ NV_RX_ERROR_TABLE_SIZ];


/*-------------------------------------------------------------------------*/

/* Type for   NV_CDMA_TX_SLOPE_1_I item.                                   */
/* ---------------------------------                                       */

  BYTE    cdma_tx_slp1[ NV_TX_SLOPE_1_TABLE_SIZ];


/*-------------------------------------------------------------------------*/

/* Type for   NV_CDMA_TX_SLOPE_2_I item.                                   */
/* ---------------------------------                                       */

  BYTE    cdma_tx_slp2[ NV_TX_SLOPE_2_TABLE_SIZ];


/*-------------------------------------------------------------------------*/

/* Type for   NV_CDMA_TX_ERROR_I item.                                     */
/* ---------------------------------                                       */

  BYTE    cdma_tx_err[ NV_TX_NON_LIN_ERR_TABLE_SIZ];


/*-------------------------------------------------------------------------*/

/* Type for   NV_PA_CURENT_CTL_I item.                                     */
/* ---------------------------------                                       */

  BYTE    pa_cur_ctl[ NV_HDET_TABLE_SIZ];


/* Type for   NV_SONY_ATTEN_1_I                                            */
/* ---------------------------------                                       */

  BYTE    sony_atten_1;


/* Type for   NV_SONY_ATTEN_2_I                                            */
/* ---------------------------------                                       */

  BYTE    sony_atten_2;

/*-------------------------------------------------------------------------*/

/* Type for   NV_VOC_GAIN_I                                                */
/* ---------------------------------                                       */

  WORD    voc_gain;


/*-------------------------------------------------------------------------*/

/* Type for   NV_SPARE_1_I                                                 */
/* ---------------------------------                                       */

  WORD    spare_1;

/*-------------------------------------------------------------------------*/

/* Type for   NV_SPARE_2_I                                                 */
/* ---------------------------------                                       */

  WORD    spare_2;

/*-------------------------------------------------------------------------*/

/* Type for NV_DATA_IO_MODE_I item.                                        */
/* -------------------------------                                         */

  BYTE    data_io_mode;


/*-------------------------------------------------------------------------*/

/* Type for NV_DATA_MODE_ENABLED_I item.                                   */
/* -------------------------------                                         */

  BYTE    dm_io_mode;


/*-------------------------------------------------------------------------*/

/* Type for NV_DATA_MODE_ENABLED_I item.                                   */
/* -------------------------------                                         */

  boolean    data_srvc_enabled;

/*-------------------------------------------------------------------------*/

/* Type for NV_IDLE_DATA_TIMEOUT_I item.                                   */
/* -------------------------------                                         */

  WORD      idle_data_timeout;

/*-------------------------------------------------------------------------*/

/* Type for NV_MAX_TX_ADJ_I item.                                          */
/* -------------------------------                                         */

  BYTE      max_tx_adj;

/*-------------------------------------------------------------------------*/

/* Type for NV_INI_MUTE_I item.                                            */
/* -------------------------------                                         */

  BYTE      init_mute;

/*-------------------------------------------------------------------------*/

/* Type for NV_FACTORY_INFO_I item.                                        */
/* -------------------------------                                         */
//sya----start
  nv_factory_info_type    factory_info;
//sya----end
//  BYTE      fact_info[100];

/*-------------------------------------------------------------------------*/

/* Type for   NV_SONY_ATTEN_3_I                                            */
/* ---------------------------------                                       */

  BYTE    sony_atten_3;

/*-------------------------------------------------------------------------*/

/* Type for   NV_SONY_ATTEN_4_I                                            */
/* ---------------------------------                                       */

  BYTE    sony_atten_4;

/*-------------------------------------------------------------------------*/

/* Type for   NV_SONY_ATTEN_5_I                                            */
/* ---------------------------------                                       */

  BYTE    sony_atten_5;

/* Type for  NV_DM_ADDR_I                                                  */
/* ---------------------------------                                       */

  BYTE    dm_addr;
/* Type for  NV_CDMA_PN_MASK_I                                             */
/* ---------------------------------                                       */

  BYTE    cdma_pn_mask;

/* Type for  NV_SEND_TIMEOUT_I                                             */
/* ---------------------------------                                       */

  BYTE    send_timeout;
/*-------------------------------------------------------------------------*/

  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  FM mode TX_AGC_ADJ initial setting vs power, frequency, and temperature
   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
  BYTE fm_agc_set_vs_pwr[NV_PWR_TABLE_SIZ];
  BYTE fm_agc_set_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_set_vs_temp[NV_TEMP_TABLE_SIZ];

  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  FM mode TX_AGC_ADJ adjustments vs frequency, temperature, and power
   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
  BYTE fm_exp_hdet_vs_pwr[NV_PWR_TABLE_SIZ];
  BYTE fm_err_slp_vs_pwr[NV_PWR_TABLE_SIZ];

  BYTE fm_freq_sense_gain;
  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  CDMA mode Rx AGC linearization table (to be loaded into MSM2P)
   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
  BYTE cdma_rx_lin_off_0;
  BYTE cdma_rx_lin_slp[NV_CDMA_RX_LIN_SIZ];

  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  CDMA mode RX/TX_GAIN_COMP values vs frequency and battery voltage
   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
  BYTE cdma_rx_comp_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_comp_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_comp_vs_volt[NV_VOLT_TABLE_SIZ];

  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  CDMA mode Tx AGC linearization (MSM2P data is derived from these tables)
   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
  WORD cdma_tx_lin_master_off_0;
  BYTE cdma_tx_lin_master_slp[NV_CDMA_TX_LIN_MASTER_SIZ];
  BYTE cdma_tx_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_lin_vs_volt[NV_VOLT_TABLE_SIZ];

  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  CDMA mode Tx power limit data vs temperature, battery voltage, frequency,
  TX_AGC_ADJ PDM setting, and HDET reading
   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
  BYTE cdma_tx_lim_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_lim_vs_volt[NV_VOLT_TABLE_SIZ];
  BYTE cdma_tx_lim_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_exp_hdet_vs_agc[NV_CDMA_EXP_HDET_VS_AGC_SIZ];
  BYTE cdma_err_slp_vs_hdet[NV_CDMA_ERR_SLP_VS_HDET_SIZ];

  /* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
  ADC offset and gain values for calculating indecies to the above tables
   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */
/* Type for NV_THERM_I item.                                               */
/* -----------------------------                                           */

   nv_minmax_type     therm; /* RF & LCD calibration */
   nv_minmax_type     vbatt_pa; /*  */
//HACK  BYTE temp_off;    /* ADC temperature offset */
//HACK  BYTE temp_spn;    /* ADC temperature span */

//HACK  BYTE volt_off;    /* ADC battery voltage offset */
//HACK  BYTE volt_spn;    /* ADC battery voltage span */
  BYTE hdet_off;    /* ADC HDET reading offset */
  BYTE hdet_spn;    /* ADC HDET reading span */
  boolean onetouch_dial;  /* ena/dis UI one touch dialing */
  BYTE fm_agc_adj_vs_freq[NV_ADJ_VS_FREQ_SIZ];
  BYTE fm_agc_adj_vs_temp[NV_ADJ_VS_TEMP_SIZ];
  BYTE rf_config;
  BYTE r1_rise;
  BYTE r1_fall;
  BYTE r2_rise;
  BYTE r2_fall;
  BYTE r3_rise;
  BYTE r3_fall;

/* Type for  NV_PA_RANGE_STEP_CAL_I                                      */
/* -----------------------------                                         */
  BYTE   pa_range_step_cal;

/* Type for  NV_LNA_RANGE_POL_I                                          */
/* -----------------------------                                         */
  BYTE   lna_range_pol;

/* Type for  NV_LNA_RANGE_RISE_I                                         */
/* -----------------------------                                         */
  BYTE   lna_range_rise;

/* Type for  NV_LNA_RANGE_FALL_I                                         */
/* -----------------------------                                         */
  BYTE   lna_range_fall;

/* Type for  NV_LNA_RANGE_OFFSET_I                                       */
/* -----------------------------                                         */
  WORD   lna_range_offset;
      
/* Type for  NV_POWER_CYCLES__I                                          */
/* -----------------------------                                         */
  DWORD  power_cycles;

/* Type for  NV_ALERTS_LVL_I                                             */
/* -----------------------------                                         */
  BYTE   alerts_lvl;

/* Type for  NV_ALERTS_LVL_SHADOW_I                                      */
/* -----------------------------                                         */
  BYTE   alerts_lvl_shadow;

/* Type for  NV_RINGER_LVL_SHADOW_I                                      */
/* -----------------------------                                         */
  BYTE   ringer_lvl_shadow;

/* Type for  NV_BEEP_LVL_SHADOW_I                                        */
/* -----------------------------                                         */
  BYTE   beep_lvl_shadow;

/* Type for  NV_EAR_LVL_SHADOW_I                                         */
/* -----------------------------                                         */
  BYTE   ear_lvl_shadow;

/* Type for  NV_TIME_SHOW_I                                              */
/* -----------------------------                                         */
  boolean time_show;

/* Type for  NV_MESSAGE_ALERT_I                                          */
/* -----------------------------                                         */
  BYTE    message_alert;

/* Type for  NV_AIR_CNT_I                                                */
/* -----------------------------                                         */
//sya----start
  nv_call_cnt_type   air_cnt;
//sya----end
// DWORD   air_cnt;

/* Type for  NV_ROAM_CNT_I                                               */
/* -----------------------------                                         */
//sya----start
  nv_call_cnt_type   roam_cnt;
//sya----end
//  DWORD   roam_cnt;

/* Type for  NV_LIFE_CNT_I                                               */
/* -----------------------------                                         */
  DWORD   life_cnt;

/* Type for  NV_SEND_PIN_I                                               */
/* -----------------------------                                         */
  boolean   send_pin;

/* Type for  NV_AUTO_ANSWER_SHADOW_I                                     */
/* -----------------------------                                         */
  BYTE      auto_answer_shadow;
 
/* Type for  NV_AUTO_REDIAL_SHADOW_I                                     */
/* -----------------------------                                         */
  BYTE      auto_redial_shadow;

/* Type for  NV_SMS_I                                                    */
/* -----------------------------                                         */
/*  nv_sms_type   sms; */
  nv_sms_dm_type   sms;

/* Type for  NV_IMSI_MCC_I                                               */
/* -----------------------------                                         */
  nv_imsi_11_12_type  imsi_11_12;

/* Type for  NV_IMSI_T_11_12_I                                           */
/* -----------------------------                                         */
  nv_imsi_11_12_type  imsi_t_11_12;

/* Type for  NV_IMSI_11_12_I                                             */
/* -----------------------------                                         */
  nv_imsi_mcc_type    imsi_mcc;

/* Type for  NV_IMSI_T_MCC_I                                             */
/* -----------------------------                                         */
  nv_imsi_mcc_type    imsi_t_mcc;

/* Type for  NV_DIR_NUMBER_I                                             */
/* -----------------------------                                         */
  nv_dir_number_type    dir_number;

/* Type for  NV_VOICE_PRIV_I                                             */
/* -----------------------------                                         */
  BYTE    voice_priv;

//sya----start
// Type for NV_FSC_I item.                                                 
// --------------------------                                                 
  nv_fsc_type  fsc;

//*********The following items are country specific for ISS2 **************   
// Type for NV_ALARMS_I item.                                                 
// --------------------------                                                 
  nv_alarms_type  alarms;

// Type for NV_STANDING_ALARM_I item.                                         
// --------------------------                                                 
  word  standing_alarm;

// Type for NV_ISD_STD_PASSWD_I item.                                         
// --------------------------                                                 
  nv_isd_std_passwd_type  isd_std_passwd;

// Type for NV_ISD_STD_RESTRICT_I item.                                       
// --------------------------                                                 
  byte  isd_std_restrict;

// Type for NV_DIALING_PLAN_I item.                                           
// --------------------------                                                 
  word  dialing_plan;

// Type for NV_FM_LNA_CTL_I item.                                           
// --------------------------                                                 
  nv_minmax_type     fm_lna_ctl; //SYA

// Type for NV_CALL_TIMER_G_I item.                                             
// ------------------------------                                             

  nv_run_time_type   call_timer_g;

// Type for NV_LIFE_TIMER_G_I item.                                             
// ------------------------------                                             

  nv_run_time_type   life_timer_g;

// Type for  NV_DWNR_UP_CNT_I                                             
// -----------------------------                                         
  DWORD   pwr_dwn_cnt;

// Type for NV_FM_AGC_I item.                                                 
// -----------------------                                                    
  nv_minmax_type     fm_agc;

// Type for NV_FSC2_I item.                                                   
// -----------------------                                                    
  nv_fsc2_type        fsc2;

// Type for NV_FSC2_CHKSUM_I item.                                            
// ------------------------------                                             
  nv_fsc2_chksum_type fsc2_chksum;

// Type for NV_WDC_I item.                                                    
// -----------------------                                                    
  nv_wdc_type        wdc;

// Type for NV_HW_CONFIG_I item.                                                    
// -----------------------                                                    
  dword              hw_config;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
//  CDMA RF Calibration items
//   - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -    
  BYTE cdma_rx_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_adj_factor;
  BYTE cdma_tx_lim_booster_off;
  BYTE cdma_rx_slp_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_slp_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE pa_range_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE lna_switch_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE fm_exp_hdet_vs_temp[NV_TEMP_TABLE_SIZ];
//sp-510 ysi v3.55 1999/12/16
  //INT1 pdm1_vs_freq[NV_FREQ_TABLE_SIZ];//hiultra
  //INT1 pdm2_vs_freq[NV_FREQ_TABLE_SIZ];//hiultra
////////////////////////////////////////////////// 
  BYTE pdm1_vs_freq[NV_FREQ_TABLE_SIZ];//hiultra
  BYTE pdm2_vs_freq[NV_FREQ_TABLE_SIZ];//hiultra		
  //////////////////////////////////////////////
  BYTE lna_gain_pol;//hiultra
  BYTE lna_gain_pwr_min;//hiultra
  BYTE lna_gain_pwr_max;//hiultra
  int2 cdma_lna_lin_off_0;//hiultra
  BYTE cdma_lna_lin_slp[NV_CDMA_LNA_LIN_SIZ];//hiultra
  int2 lna_gain_vs_temp[NV_TEMP_TABLE_SIZ];//hiultra
  BYTE fm_agc_set_vs_volt[NV_VOLT_TABLE_SIZ];//hiultra
  BYTE cdma_lna_comp_vs_freq[NV_FREQ_TABLE_SIZ][NV_CDMA_LNA_LIN_SIZ]; //DM-110A���� �߰� OJS
  BYTE cdma_tx_tx0_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx1_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx2_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx3_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx4_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx5_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx6_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx7_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx8_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx9_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx10_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx11_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx12_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx13_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx14_lin_vs_temp[NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_tx15_lin_vs_temp[NV_TEMP_TABLE_SIZ];
//sp-510 end
// DM-110 start  kang add  99.12.22
  /////// ���� ///
  BYTE   pa_therm_high;                // �ΰ� �߰� 2000/1/27 ysi
  BYTE   pa_therm_low;                 //                                             
  int2   qdsp_snd_ctrl[NV_QDSP_CAL_DATA_SIZ];

  nv_enabled_type          prl_enabled;

/* Type for NV_SYSTEM_PREF_I item.                                         */
/* -------------------------------                                         */
  nv_sys_pref_type         system_pref;

  BYTE cdma_tx_temp0_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_temp1_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_temp2_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_temp3_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_temp4_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_temp5_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_temp6_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE cdma_tx_temp7_vs_freq[NV_FREQ_TABLE_SIZ];

  BYTE fm_agc_temp0_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_temp1_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_temp2_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_temp3_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_temp4_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_temp5_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_temp6_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_temp7_vs_freq[NV_FREQ_TABLE_SIZ];

  BYTE fm_agc_pwr0_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_pwr1_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_pwr2_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_pwr3_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_pwr4_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_pwr5_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_pwr6_vs_freq[NV_FREQ_TABLE_SIZ];  
  BYTE fm_agc_pwr7_vs_freq[NV_FREQ_TABLE_SIZ];

  BYTE cdma_tx_fine_comp_vs_freq[NV_FREQ_TABLE_SIZ];
  BYTE fm_agc_fine_adj_vs_freq[NV_ADJ_VS_FREQ_SIZ];

  /////////////// DM-510 �߰� Item. kang add ..../////
  BYTE fm_comp_therm0_freq_level[NV_FM_FREQ_LEVEL_SIZ];  
  BYTE fm_comp_therm1_freq_level[NV_FM_FREQ_LEVEL_SIZ];  
  BYTE fm_comp_therm2_freq_level[NV_FM_FREQ_LEVEL_SIZ];  
  BYTE fm_comp_therm3_freq_level[NV_FM_FREQ_LEVEL_SIZ];  
  BYTE fm_comp_therm4_freq_level[NV_FM_FREQ_LEVEL_SIZ];  
  BYTE fm_comp_therm5_freq_level[NV_FM_FREQ_LEVEL_SIZ];  
  BYTE fm_comp_therm6_freq_level[NV_FM_FREQ_LEVEL_SIZ];  
  BYTE fm_comp_therm7_freq_level[NV_FM_FREQ_LEVEL_SIZ]; 
  BYTE fm_rvc_data[NV_FREQ_TABLE_SIZ];
////////////////////////////////////////////////////////
// Type for  NV_N1M_I                                                       
// -----------------------------                                            
  byte    n1m;

// Type for NV_IMSI_I item.                                                   
// -----------------------                                                    
  nv_imsi_type       imsi;

// Type for NV_IMSI_ADDR_NUM_I item.                                          
// -----------------------                                                    
  nv_imsi_addr_num_type imsi_addr_num;

/* Type for NV_IMSI_T_ADDR_NUM_I item.                                     */
/* -----------------------                                                 */
  nv_imsi_addr_num_type imsi_t_addr_num;

// Type for NV_ASSIGNING_TMSI_ZONE_LEN_I item.                                    
// -----------------------                                                    
  nv_tmsi_zone_length_type  assigning_tmsi_zone_length;
// -----------------------                                                    
  nv_pref_voice_so_type    pref_voice_so;
// Type for NV_ASSIGNING_TMSI_ZONE_I item.                                    
// -----------------------                                                    
  nv_tmsi_zone_type  assigning_tmsi_zone;

// Type for NV_TMSI_CODE_I item.                                              
// -----------------------                                                    
  nv_tmsi_code_type  tmsi_code;

// Type for NV_TMSI_EXP_I item.                                               
// -----------------------                                                    
  nv_tmsi_exp_time_type tmsi_exp_timer;

// Type for NV_HOME_PCS_FREQ_BLOCK_I item.                                    
// -----------------------                                                    
  nv_home_block_type home_block;

// Type for NV_DIR_NUMBER_PCS_I item.                                    
// -----------------------                                                    
///////////////////////////////////////

// Type for NV_ROAMING_LIST_I item.                                           
// -----------------------                                                    
  nv_roaming_list_union_type roaming_list;

// Type for NV_MRU_TABLE_I item.                                              
// -----------------------                                                    
  nv_mru_table_type mru_table;

/* Type for NV_MRU2_TABLE_I item.                                          */
/* -----------------------                                                 */
  nv_mru2_table_type mru2_table;

// Type for OTASP "commit" operation (writes several nv items).               
// -----------------------                                                    
  nv_otasp_commit_type otasp_commit;


// Type for NV_REDIAL_I item.                                                 
// -------------------------                                                  

  nv_dial_type       redial;

// Type for NV_OTKSL_I item.                                                  
// -----------------------                                                    
  nv_sec_code_type   otksl;

// Type for NV_TIMED_PREF_MODE_I item.                                        
// -----------------------                                                    
  boolean      timed_pref_mode;

//////////////////////insert for sd5300 -- start
/* Type for NV_RINGOUND_I item.                                            */
/* -----------------------                                                 */
  boolean      ring_sound;

/* Type for NV_SMS_ALERT_I item.                                           */
/* -----------------------                                                 */
//  byte         sms_alert;

/* Type for NV_CALL_CONNECT_I item.                                        */
/* -----------------------                                                 */
  boolean      call_connect_alert;

/* Type for NV_ALARM_I item.                                               */
/* -----------------------                                                 */
  nv_alarm_type     alarm;

/* Type for NV_ANNIVERSARY_I item.                                         */
/* -----------------------                                                 */
  nv_anniversary_type  anniversary;

/* Type for NV_RESERVATION_I item.                                         */
/* -----------------------                                                 */
  nv_reservation_type  reservation;

/* Type for NV_AUTO_DIAL_I item.                                           */
/* -----------------------                                                 */
  boolean   auto_dial;

/* Type for NV_DDD_STO_I item.                                             */
/* -----------------------                                                 */
  nv_ddd_sto_type    ddd_sto;

/* Type for NV_DDD_DIAL_I item.                                            */
/* -----------------------                                                 */
  nv_ddd_dial_type    ddd_dial;

/* Type for NV_DIALING_I item.                                             */
/* -----------------------                                                 */
//  byte     voice_dialing;

/* Type for NV_SEND_LIFE_CNT_I item.                                       */
/* -----------------------                                                 */
  dword     send_life_cnt;

/* Type for NV_SEND_LIFE_TIMER_G_I item.                                   */
/* -----------------------                                                 */
  nv_run_time_type     send_life_timer_g;

/* Type for NV_VOCODER_I item.                                             */
/* -----------------------                                                 */
  boolean    vocoder_select;

/* Type for NV_ALARM_SETUP_I item.                                         */
/* -----------------------                                                 */
  byte       alarm_setup;
/////////////////////insert for sd5300 -- end


//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -   

// Type for NV_SELECTRING_I item.                                             
// ------------------------------                                             
// Select the ring sound!                                                     
//                                                                            
// 1-10        - Ring sound NO.                                               
// 1           - Default value                                                
// Other value - Not used!                                                    

  byte      selectring;
//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -   

// Type for NV_AUTO_DDD_I item.                                               
// ------------------------------                                             
  word      auto_ddd;

// Type for  NV_INTER_CALL_I                                                
// -----------------------------                                            
  boolean   inter_call;

// Type for  NV_RESET_AIR_CNT_I                                             
// -----------------------------                                            
  nv_call_cnt_type   reset_air_cnt;

// Type for NV_RESET_AIR_TIMER_I item.                                      
// ------------------------------                                           
  nv_call_time_type   reset_air_timer;

// Type for NV_SELECT_CALL_CONNECT_I item.                                    
// ------------------------------										      
// Select the call connect sound!                                             
//																		      
// 1-4         - Ring sound NO.                                               
// 1		   - Default value											      
// Other value - Not used!												      

  byte      select_call_connect;

// Type for NV_CALL_CONNECT_LVL_I item. 									      
// -------------------------------- 									      
// Volume is from 1 (min) to 255 (max) and 0 means OFF (or SILENCE).	      

  byte		   call_connect_level;

// Type for  NV_ALARM_TIME_I                                                
// -----------------------------										    
  nv_alarm_time_type alarm_time;

// Type for  NV_ALARM_FLAG_I                                                
// -----------------------------										    
  boolean alarm_flag;

// Type for  NV_SMS_MODE_I                                                   
// -----------------------------                                              
  boolean   sms_mode;


// Type for  NV_SMS_ALERT_I                                                   
// -----------------------------                                              
  byte      sms_alert;


// Type for  NV_SMS_ORIG_MSG_ID_I                                                   
// -----------------------------                                              
  word      sms_orig_msg_id;

// Type for  NV_ROAM_MAIN_I                                                   
// -----------------------------                                              
  nv_roam_main_type    roam_main;

// Type for  NV_ROAM_SUB_I                                                   
// -----------------------------                                              
  nv_roam_sub_type     roam_sub;


// Type for NV_SMS_TMA_MODE_I item.                                               
// -------------------------------                                            
  boolean   sms_tma_mode;  

// Type for  NV_DIALING_I                                                     
// -----------------------------                                              
  // voice dialing nv value
//     see ->uiint.h
  //   UI_VOICE_NONE      0
    // UI_VOICE_PASSIVE   1
  //   UI_VOICE_AUTO      2       
  byte      voice_dialing;

// Type for NV_BROADCAST_I item.                                       
// --------------------------------------                                     
  boolean   bcast_mode;

// Type for NV_BROADCAST_CONFIG_I item.                                       
// --------------------------------------                                     
  nv_bcast_config_type bcast_config;

// Type for  NV_DISPTELNO_I                                                   
// -----------------------------                                              
  boolean   disptelno;
#define FEATURE_PA_RANGE_TEMP_FREQ_COMP    // kowooseok 2000/9/6
#define NV_NUM_PA_RANGES 4

//#ifdef FEATURE_PA_RANGE_TEMP_FREQ_COMP
/* Type for NV_PA_RANGE_OFFSETS_I item.                                    */
/* -------------------------------                                         */
  signed short pa_range_offsets[NV_NUM_PA_RANGES];

/* Type for NV_TX_COMP0_I item.                                             */
/* -------------------------------                                         */
  nv_tx_comp_type          tx_comp0;
  
/* Type for NV_TX_COMP1_I item.                                            */
/* -------------------------------                                         */
  nv_tx_comp_type          tx_comp1;
  
/* Type for NV_TX_COMP2_I item.                                            */
/* -------------------------------                                         */
  nv_tx_comp_type          tx_comp2;
  
/* Type for NV_TX_COMP3_I item.                                            */
/* -------------------------------                                         */
  nv_tx_comp_type          tx_comp3;
//#endif

//#ifdef FEATURE_4PAGE_TX_LINEARIZER                        
/* Type for  NV_CDMA_TX_LIN_MASTER0_I item.  */
/* ---------------------------------------   */
  nv_tx_linearizer_type    cdma_tx_lin_master0;      

/* Type for  NV_CDMA_TX_LIN_MASTER1_I item.  */
/* ---------------------------------------   */
  nv_tx_linearizer_type    cdma_tx_lin_master1;

/* Type for  NV_CDMA_TX_LIN_MASTER2_I item.  */
/* ---------------------------------------   */
  nv_tx_linearizer_type    cdma_tx_lin_master2;

/* Type for  NV_CDMA_TX_LIN_MASTER3_I item.  */
/* ---------------------------------------   */
  nv_tx_linearizer_type    cdma_tx_lin_master3;
//#endif

// Type for NV_BAUDRATE_I item.                                       
// --------------------------------------                                     
  word baudrate;

  short audio_adj_phone[NV_AUDIO_ADJ_ITEM_SIZ];//YJG 2001.9.4 DB520 TM520
  short audio_adj_earjack[NV_AUDIO_ADJ_ITEM_SIZ];//YJG 2001.9.4 DB520 TM520
  short audio_adj_hfk[NV_AUDIO_ADJ_ITEM_SIZ];//YJG 2001.9.4 DB520 TM520

  BYTE fm_pwr_level7_vs_freq[16];//YJG 2001.6.5 DB520

  BYTE fm_pwr_level56_vs_freq[16];

  BYTE fm_pwr_level012_vs_temp[8];
	
  BYTE fm_rvc_comp_vs_freq[16];//YJG 2001.6.5 DB520

  BYTE tstmode;//YJG 2001.6.13

  BYTE lcd_contrast;

  nv_home_sid_nid_type     home_sid_nid; //YJG 2001.9.4

  signed char fm_fsg_vs_temp[FM_FSG_VS_TEMP_SIZ];

//////////////////////4.03-1 OJS 2002.3.25///////////////////////////
  BYTE cdma_tx_lin_vs_freqtemp[NV_FREQ_TABLE_SIZ][NV_TEMP_TABLE_SIZ];
  BYTE cdma_tx_slp_vs_freqtemp[NV_FREQ_TABLE_SIZ][NV_TEMP_TABLE_SIZ];

  /* Type for NV_LNA_RANGE_2_RISE_I item.                                    */
/* ------------------------------------                                    */
  BYTE                     lna_range_2_rise;

/* Type for NV_LNA_RANGE_2_FALL_I item.                                    */
/* ------------------------------------                                    */
  BYTE                     lna_range_2_fall;

/* Type for NV_LNA_RANGE_12_OFFSET_I item.                                 */
/* ------------------------------------                                    */
  int2                     lna_range_12_offset;

/* Type for NV_NONBYPASS_TIMER_I item.                                     */
/* ------------------------------------                                    */
  __int8                     nonbypass_timer;

/* Type for NV_BYPASS_TIMER_I item.                                        */                                                  
/* ------------------------------------                                    */
  __int8                     bypass_timer;

/* Type for NV_IM_LEVEL1_I item.                                           */
/* ------------------------------------                                    */
  BYTE                     im_level1;

/* Type for NV_IM_LEVEL2_I item.                                           */
/* ------------------------------------                                    */
  BYTE                     im_level2;

/* Type for NV_AGC_PHASE_OFFSET_I item.                                    */
/* ------------------------------------                                    */
  byte                     agc_phase_offset;

/* Type for NV_RX_AGC_MIN_11_I item.                                       */
/* ------------------------------------                                    */
  nv_minmax_type           rx_agc_min_11;
///////////////////////////////////////////////////////////////

  /* Type for NV_THEME_I item.                                               */
  byte         theme;

/* Type for NV_CARRIER_LOGO_I item.                                               */
  byte   carrier_logo; // golions 2000.11.2

/* Type for NV_VIB_LVL_I item.                                               */
  byte         vib_lvl;

/* Type for NV_PCS_ENC_BTF_I item.                                         */
/* -------------------------------                                         */
  dword        pcs_enc_btf;
  
/* Type for NV_CDMA_ENC_BTF_I item.                                        */
/* -------------------------------                                         */
  dword        cdma_enc_btf;

/* Type for NV_SUBPCG_PA_WARMUP_DELAY_I item.                              */
/* -------------------------------                                         */
  word         subpcg_pa_warmup_delay;

// 2002/9/7 thunder : TM250 IM2 cal ojy
  boolean										ftm_mode;

// 2001/6/25 thunder added : NV item�� Ÿ�� ���� �߰�

/* Type for NV_GAME_SETTINGS_I item.  */
  nv_game_settings_type    game_settings;

/* Type for NV_SMS_AUTO_DELETE_MENU_I item.*/
  boolean      sms_auto_delete_menu;

/* Type for NV_SMS_AUTO_SAVE_SEL_I item.*/
  boolean      sms_auto_save_sel;

/* Type for NV_SMS_MO_MAX_USERDATA_I item.*/
  word         sms_mo_max_userdata;

/* Type for NV_SMS_MO_EDIT_MODE_I item.*/
  byte         sms_mo_edit_mode;

/* Type for NV_SMS_MO_L3_ACK_I item.*/
  boolean      sms_mo_l3_ack;

/* Type for NV_SMS_MO_SO_I item.*/
  boolean      sms_mo_so;

/* Type for NV_SMS_VOICE_MAIL_I item.*/
  byte         sms_voice_mail[32];

// 2001/7/20 thunder added : NV item�� Ÿ�� ���� �߰�
/* Type for NV_ALERT_SELECT_I item.*/
  boolean	   alertselect;

  /* Type for NV_MM_LVL_I item.                                              */
/* -------------------------------                                         */
  byte                     mm_lvl;

/* Type for NV_MM_LVL_SHADOW_I item.                                       */
/* -------------------------------                                         */
  byte                     mm_lvl_shadow;
  
/* Type for NV_MM_SPEAKER_LVL_I item.                                      */
/* -------------------------------                                         */
  byte                     mm_speaker_lvl;

  /* Type for NV_SMS_DEFERRED_SEL_I item.*/
  byte         sms_deferred_sel;
  /* Type for NV_SMS_VALIDITY_SEL_I item.*/
  byte         sms_validity_sel;
  /* Type for NV_SMS_PRIORITY_SEL_I item.*/
  byte         sms_priority_sel;
  /* Type for NV_SMS_DELIVERY_SEL_I  item.*/
  boolean      sms_delivery_sel;
  /* Type for NV_SMS_DEFAULT_CB_I  item.*/
  boolean      sms_default_cb;

/* Type for NV_AUTO_VOLUME_ENABLED_I item.                                 */
/* ---------------------------------------                                 */
  boolean                  auto_volume_enabled;

/* Type for NV_LANGUAGE_SELECTION_I item.                                  */
/* --------------------------------------                                  */
  nv_language_enum_type  language_selection;

  /* Type for NV_OTAPA_ENABLED_I item.                                       */
/* ---------------------------------                                       */
  nv_enabled_type          otapa_enabled;

  nv_enabled_type          nam_lock;

  /* Type for NV_SPC_CHANGE_ENABLED_I item.                                  */
/* --------------------------------------                                  */
  boolean                  spc_change_enabled;

  /* Type for NV_SMS_ALERT_SEL_I item.*/
  byte         sms_alert_sel;

/* Type for NV_SMS_2MIN_ALERT_I item.*/
  boolean      sms_2min_alert;

/* Type for NV_DATA_QNC_ENABLED_I item.                                    */
/* ------------------------------------                                    */
  boolean             data_qnc_enabled;

/* Type for NV_DATA_SO_SET_I item.                                         */
/* -------------------------------                                         */
  byte                data_so_set;

/* Type for NV_DATA_MDR_MODE_I item.                                       */
/* ---------------------------------                                       */
  byte                     data_mdr_mode;

/* Type for NV_DATA_PKT_ORIG_STR_I item.                                   */
/* -------------------------------------                                   */
  nv_data_pkt_orig_str_type data_pkt_orig_str;

/* Type for NV_DATA_AUTO_PACKET_DETECTION_I item.                          */
/* -------------------------------------                                   */
  byte                     data_auto_packet_detection;

  nv_sid_nid_lock_type     sid_nid_lock;

//////////////////4.06 YJG 2002.9.3//////////////
// 2002/2/27 thunder : TMx40�� ���� �߰�

/* Type for  NV_PCS_PDM1_VS_TEMP_I item.  */ 
/* ---------------------------------------   */ 
  signed char pdm1_vs_temp[NV_TEMP_TABLE_SIZ];   

/* Type for  NV_PCS_PDM2_VS_TEMP_I item.  */ 
/* ---------------------------------------   */ 
  signed char pdm2_vs_temp[NV_TEMP_TABLE_SIZ];
  
/* Type for NV_LNA_RANGE_2_RISE_I item.                                    */ 
/* Type for NV_PCS_LNA_RANGE_2_RISE_I item.                                    */ 
/* ------------------------------------                                    */ 
//  signed char              lna_range_2_rise;                                  
                                                                              
/* Type for NV_LNA_RANGE_2_FALL_I item.                                    */ 
/* Type for NV_PCS_LNA_RANGE_2_FALL_I item.                                    */ 
/* ------------------------------------                                    */ 
//  signed char              lna_range_2_fall;                                  
                                                                              
/* Type for NV_LNA_RANGE_12_OFFSET_I item.                                 */ 
/* Type for NV_PCS_LNA_RANGE_12_OFFSET_I item.                                    */ 
/* ------------------------------------                                    */ 
//  signed short             lna_range_12_offset;                               
                                                                              
/* Type for NV_NONBYPASS_TIMER_I item.                                     */ 
/* Type for NV_PCS_NONBYPASS_TIMER_I item.                                    */ 
/* ------------------------------------                                    */ 
//  byte                     nonbypass_timer;                                   
                                                                              
/* Type for NV_BYPASS_TIMER_I item.                                        */ 
/* Type for NV_PCS_BYPASS_TIMER_I item.                                    */ 
/* ------------------------------------                                    */ 
//  byte                     bypass_timer;                                      
                                                                              
/* Type for NV_IM_LEVEL1_I item.                                           */ 
/* Type for NV_PCS_IM_LEVEL1_I item.                                    */ 
/* ------------------------------------                                    */ 
//  signed char              im_level1;                                         
                                                                              
/* Type for NV_IM_LEVEL2_I item.                                           */ 
/* Type for NV_PCS_IM_LEVEL2_I item.                                    */ 
/* ------------------------------------                                    */ 
//  signed char              im_level2;                                         
                                                                              
/* Type for NV_CDMA_LNA_OFFSET_VS_FREQ_I item.                             */ 
/* Type for NV_PCS_CDMA_LNA_OFFSET_VS_FREQ_I item.                             */ 
/* ------------------------------------                                    */ 
  signed char              cdma_lna_offset_vs_freq[NV_FREQ_TABLE_SIZ];        
                                                                                
/* Type for NV_CDMA_LNA_12_OFFSET_VS_FREQ_I item.                          */   
/* Type for NV_PCS_CDMA_LNA_12_OFFSET_VS_FREQ_I item.                          */   
/* ------------------------------------                                    */ 
  signed char              cdma_lna_12_offset_vs_freq[NV_FREQ_TABLE_SIZ];     
                                                                                
/* Type for NV_AGC_PHASE_OFFSET_I item.                                    */   
/* Type for NV_PCS_AGC_PHASE_OFFSET_I item.                                    */   
/* ------------------------------------                                    */ 
//  byte                     agc_phase_offset;                                  
                                                                                
/* Type for NV_RX_AGC_MIN_11_I item.                                       */   
/* Type for NV_PCS_RX_AGC_MIN_11_I item.                                       */   
/* ------------------------------------                                    */ 
//  nv_minmax_type           rx_agc_min_11;                                     
  
/* Type for NV_GPS1_GPS_RF_DELAY_I item.                                   */  
/* -------------------------------                                         */  
//  signed short             gps1_gps_rf_delay;                                    
                                                                               
/* Type for NV_GPS1_CDMA_RF_DELAY_I item.                                  */  
/* -------------------------------                                         */  
  signed short             gps1_cdma_rf_delay;                                 


// 2002/4/29 thunder added : GPS ������ �߰� : 5��
/* Type for NV_GPS1_GPS_RF_LOSS_I item.                                    */
/* -------------------------------                                         */
//  byte                     gps1_gps_rf_loss;

/* Type for  NV_GPS1_LO_CAL_I item.                                        */
/* -------------------------------                                         */
//  signed short             gps1_lo_cal;                       

/* Type for  NV_GPS1_PCS_RF_DELAY_I item.                                  */
/* -------------------------------                                         */
//  signed short             gps1_pcs_rf_delay;

/* Type for NV_GPS_DOPP_SDEV_I item.                                       */
/* -------------------------------                                         */
//  byte                                   gps_dopp_sdev;

/* Type for  NV_GPS1_ANT_OFF_DB_I item.                                    */
/* -------------------------------                                         */
  signed short             gps1_ant_off_db;


/////////////////4.06 YJG 2002.9.3 End////////////////////

  word                     prl_version;

  //boolean      ring_sound;
//sya----end

/* Gemini UI additions */
/*
#if (TG == T_PC)
  boolean generic_bool;
  BYTE    generic_BYTE;
  WORD    generic_WORD;
  DWORD   generic_DWORD;
#endif // (TG == T_PC) */
  __int8 nLimLine[NV_FREQ_TABLE_SIZ];//4.03-1 OJS 2002.3.25

  ///////////4.05 YJG 2002.5.23 DB535///////////////////
  int2      gps1_gps_rf_delay;
  byte      gps1_gps_rf_loss;
  int2      gps1_lo_cal; 
  int2      gps1_pcs_rf_delay; 
  byte      gps_dopp_sdev;
  BYTE      cdma_tx_lim_vs_temp_freq[NV_FREQ_TABLE_SIZ];
  //////////////////////////////////////////////////////

  ///////////4.05 YJG 2002.5.29 LG-CU6060///////////////
  byte    ringer_spkr_lvl;
  byte    beep_spkr_lvl;
  //////////4.06-2 LBC 2002.10.30///////////////////////
  boolean                  ext_led;
  //////////4.07 LBC 2002.11.20  thcho  2002.10.18//////
  byte    hybrid_pref;     
  //////////////////////////////////////////////////////
  nv_ringertype_type sounds_ringer_type;

  nv_meid_type		meid_type;	//  [10/2/2006] lupis3 : MEID �߰�
  nv_imei_type		imei_type;	//  [01/19/2011] lupis3 : LTE
 /* Type for  NV_RF_CAL_VER_I item.                                         */
/* -------------------------------                                         */
  byte                                   rf_cal_ver[NV_SIZE_OF_VERSION];	//  [7/16/2007] vivache : rf_cal_ver

} nv_item_type;

/*-------------------------------------------------------------------------*/

/* The command on the NVM queue */

typedef struct {
  q_link_type           link;           /* Queue field */
  nv_items_enum_type    item;           /* Item to access */
  nv_func_enum_type     cmd;            /* READ, WRITE, PEEK or POKE */
  nv_item_type          *data_ptr;      /* Pointer to read or write data */
  rex_tcb_type          *tcb_ptr;       /* Task to signal */
  rex_sigs_type         sigs;           /* Rex signals for task */
  q_type                *done_q_ptr;    /* Where to place done buffer */
  nv_stat_enum_type     status;         /* Status of request */
} nv_cmd_type;

/*-------------------------------------------------------------------------*/


/*===========================================================================

                      FUNCTION DECLARATIONS

===========================================================================*/



/*===========================================================================

FUNCTION NV_TASK

DESCRIPTION
  The main control task calls this function with rex_def_task to start up
  the nv task.  This function then initializes NV timers and command queue.
  If the major revision number has changed then this function rebuilds the
  NV itself.  Once initialization is complete the function sets MC_ACK_SIG
  and it waits for NV_START_SIG.  When the start signal is received the
  function reads and processes any request it finds on its queue until
  there are no more requests.  Once the request queue is empty the task
  then starts normal operation by waiting for and processing any new commands
  when they arrrive on its command queue.  Throughout its operation the
  NV task wakes up periodically to kick the watchdog task.

DEPENDENCIES
  This function must be called with rex_def_task _once_.  It requires the
  NV_START_SIG before proceeding past the initialization stage.

RETURN VALUE
  Never returns.

SIDE EFFECTS
  Modifies NVM.

===========================================================================*/

extern void nv_task
(
  DWORD param      /* parameter from REX, unused */
);


/*===========================================================================

FUNCTION NV_CMD

DESCRIPTION
  This is the outside world's interface to the non volatile memory task.
  This function takes an already filled out nv_cmd_type which it places
  on the nv command queue.  The function then returns to the caller.
  Return to the caller does not mean that the command has been executed
  yet, only that it is queued for execution.  When nv_cmd is done processing
  the request it returns the buffer to the specified queue if a return
  queue adress is provided.  Otherwise it does not move the buffer.

  An example NV READ request for MIN1 is as follows:
                              
  static   nv_cmd_type       cmd_buf;        - Define command buffer
  static   nv_item_type      data_buf;       - Define data buffer

  data_buf.min1.nam  = current_nam;          - Specify which NAM          
  cmd_buf.cmd        = NV_READ_F;            - Specify read operation     
  cmd_buf.tcb_ptr    = rex_self();           - Own TCB                    
  cmd_buf.sigs       = XX_NV_CMD_SIG;        - Signal to set when done    
  cmd_buf.done_q_ptr = NULL;                 - No buffer return required  
  cmd_buf.item       = NV_MIN1_I;            - Specify the item to read   
  cmd_buf.data_ptr   = &data_buf;            - Where to place read data   

  rex_clr_sigs (rex_self(), XX_NV_CMD_SIG);  - Clear the signal        
  nv_cmd (&cmd_buf);                         - And issue the command   

DEPENDENCIES
  The NV task must have been started up already.  All of the items in
  the nv_cmd_type must be already set.

RETURN VALUE
  None directly.  The requested data is returned in the buffer pointed
  to inside the nv_cmd_type.  The status variable of the nv_cmd_type
  will be updated to reflect the current status of this command as it
  is processed.  In the above nv_cmd buffer nv_cmd.status is set to:

    NV_DONE_S        - Request completed okay
    NV_BUSY_S        - Request is queued
    NV_BADCMD_S      - Unrecognizable command field
    NV_FULL_S        - The NVM is full
    NV_FAIL_S        - Command failed, reason other than NVM was full
    NV_NOTACTIVE_S   - Variable was not active
    NV_BADPARM_S     - Bad parameter in command block
    NV_READONLY_S    - Parameter is write-protected and thus read only

SIDE EFFECTS
  The nv_cmd_type is placed on the NV command queue.  It must not be
  modified until the command has been processed!

===========================================================================*/

extern void nv_cmd
(
  nv_cmd_type *cmd_ptr  /* pointer to the NV command block */
);


/*===========================================================================

FUNCTION NV_READ_ERR_LOG

DESCRIPTION
  This function reads an error log from NVM.

DEPENDENCIES
  The function DOES NOT USE ANY TASK SERVICES, so that it can be
  called when the tasking environment does not yet exist or if it
  is not reliable.  This function DOES NOT USE ERROR SERVICES.  It
  returns status to the caller if there is a failure.

RETURN VALUE
  NV_DONE_S         if it worked
  NV_NOT_ACTIVE_S   if item was not active
  NV_FAIL_S         if item could not be read

SIDE EFFECTS
  None.

===========================================================================*/

extern nv_stat_enum_type nv_read_err_log
(
  nv_err_log_type  *nv_err_log_ptr    /* Pointer where to return read data */
);


/*===========================================================================

FUNCTION NV_WRITE_ERR_LOG

DESCRIPTION
  This function writes an error log to NVM.

DEPENDENCIES
  The function DOES NOT USE ANY TASK SERVICES, so that it can be
  called when the tasking environment does not yet exist or if it
  is not reliable.  This function DOES NOT USE ERROR SERVICES.  It
  returns status to the caller if there is a failure.

RETURN VALUE
  NV_DONE_S - if it worked
  NV_FAIL_S - if item could not be written

SIDE EFFECTS
  None.

===========================================================================*/

extern nv_stat_enum_type nv_write_err_log
(
  nv_err_log_type  *nv_err_log_ptr    /* Pointer where to get write data */
);


/*===========================================================================

FUNCTION NV_BUILT

DESCRIPTION
  This function checks the major version number of the the NV task
  as stored at edit time, against the major version number of the
  NV EEPROM as read from NVM.  If the numbers are different then the
  function returns FALSE, which indicates that the NV is not built
  and it may not be accessed from any external task.  If the numbers
  are the same then the function returns TRUE, which indicates that
  NV is built and it may be accessed.  This function lets other units
  issue direct NV read and write commands if the status returned is
  TRUE, thus allowing NV read and write before the NV task has been
  started.

DEPENDENCIES
  This is a special use function, normally called by error services
  to allow early access to NV, and before the NV task has been started.
  If NV_BUILT returns TRUE the NV may be accessed BUT ONLY USING DIRECT
  READ AND WRITES OF THE ERROR LOG (NV_READ_ERR_LOG and NV_WRITE_ERR_LOG).
  The NV task itself can not be counted upon to be started yet and normal
  NV requests must not be used.  As with all direct read and write
  operation, the data item (here it is the major version number) must
  be contained on a signle physical NV page.

RETURN VALUE
  TRUE      - The NV has been built and direct read/write is allowed
  FALSE     - The NV has not been built and access is not allowed

SIDE EFFECTS
  None.

===========================================================================*/

//extern boolean nv_built (void);
/*===========================================================================

FUNCTION NV_MEMAVAIL

DESCRIPTION
  Return the number of BYTEs available in th long pool for allocation

DEPENDENCIES
  nva_memavail must have been called

RETURN VALUE
  the number of BYTEs left in the long pool

SIDE EFFECTS
  None.

===========================================================================*/

WORD nv_memavail (void);

#pragma pack()

#endif /* NV_H */

