#ifndef _DIAGCMD_H
#define _DIAGCMD_H
/*==========================================================================

  D I A G N O S T I C    T A S K    P A C K E T    I D   D E F I N E S

DESCRIPTION
  This file contains packet id definitions for the serial interface to
  the dmss.  

Copyright (c) 1993,1994 by QUALCOMM, Incorporated.  All Rights Reserved.
===========================================================================*/

/* <EJECT> */
/*===========================================================================

                      EDIT HISTORY FOR FILE

This section contains comments describing changes made to this file.
Notice that changes are listed in reverse chronological order.

$Header:   Z:/CMtest/CMtest(3.61)/WInclude/DIAGCMD.H-arc   1.0   Feb 14 2000 15:35:20   hyun  $

when       who     what, where, why
--------   ---     ----------------------------------------------------------
07/23/93   twp     Added DIAG_TMOB_F
01/14/93   twp     First release

===========================================================================*/

/*--------------------------------------------------------------------------

  Command Codes between the Diagnostic Monitor and the mobile. Packets
  travelling in each direction are defined here, while the packet templates
  for requests and responses are distinct.  Note that the same packet id
  value can be used for both a request and a response.  These values
  are used to index a dispatch table in diag.c, so 

  DON'T CHANGE THE NUMBERS ( REPLACE UNUSED IDS WITH FILLERS ). NEW IDs
  MUST BE ASSIGNED AT THE END.
  
----------------------------------------------------------------------------*/

#define DIAG_VERNO_F     0    /* Version Number Request/Response            */
#define DIAG_ESN_F       1    /* Mobile Station ESN Request/Response        */
#define DIAG_PEEKB_F     2    /* Peek byte Request/Response                 */
#define DIAG_PEEKW_F     3    /* Peek word Request/Response                 */
#define DIAG_PEEKD_F     4    /* Peek dword Request/Response                */
#define DIAG_POKEB_F     5    /* Poke byte Request/Response                 */
#define DIAG_POKEW_F     6    /* Poke word Request/Response                 */
#define DIAG_POKED_F     7    /* Poke dword Request/Response                */
#define DIAG_OUTP_F      8    /* Byte output Request/Response               */
#define DIAG_OUTPW_F     9    /* Word output Request/Response               */
#define DIAG_INP_F      10    /* Byte input Request/Response                */
#define DIAG_INPW_F     11    /* Word input Request/Response                */
#define DIAG_STATUS_F   12    /* DMSS status Request/Response               */
#define DIAG_VPEEK_F    13    /* Peek Vocoder Data Memory Request/Response  */
#define DIAG_VPOKE_F    14    /* Poke Vocoder Data Memory Request/Response  */
#define DIAG_LOGMASK_F  15    /* Set logging mask Request/Response          */
#define DIAG_LOG_F      16    /* Log packet Request/Response                */
#define DIAG_NV_PEEK_F  17    /* Peek at NV memory Request/Response         */
#define DIAG_NV_POKE_F  18    /* Poke at NV memory Request/Response         */
#define DIAG_BAD_CMD_F  19    /* Invalid Command Response                   */
#define DIAG_BAD_PARM_F 20    /* Invalid parmaeter Response                 */
#define DIAG_BAD_LEN_F  21    /* Invalid packet length Response             */
#define DIAG_BAD_DEV_F  22    /* Packet not accepted from device Response   */
#define DIAG_VOC_ERR_F  23    /* Error occured during processing of vocoder */
                              /*    request                                 */
#define DIAG_BAD_MODE_F 24    /* Packet not allowed in this mode            */
                              /*    ( online vs offline )                   */
#define DIAG_TAGRAPH_F  25    /* info for TA power and voice graphs         */
#define DIAG_MARKOV_F   26    /* Markov statistics                          */
#define DIAG_MARKOV_RESET_F 27  /* Reset of Markov statistics               */
#define DIAG_DIAG_VER_F 28    /* Return diag version for comparison to      */
                              /*    detect incompatabilities                */
#define DIAG_TS_F       29    /* Return a timestamp                         */
#define DIAG_TA_PARM_F  30    /* Set TA parameters                          */
#define DIAG_MSG_F      31    /* Request for msg report                     */
#define DIAG_HS_KEY_F   32    /* Handset Emulation -- keypress              */
#define DIAG_HS_LOCK_F  33    /* Handset Emulation -- lock or unlock        */
#define DIAG_HS_SCREEN_F  34  /* Handset Emulation -- display request       */
#define DIAG_PARM_GET_F 35    /* Parameter Retreival                        */
#define DIAG_PARM_SET_F 36    /* Parameter Download                         */
#define DIAG_REGIS_F    37    /* External device identification             */
#define DIAG_NV_READ_F  38    /* Read NV item                               */
#define DIAG_NV_WRITE_F 39    /* Write NV item                              */
#define DIAG_CONFIG_F   40    /* Configure table                            */
#define DIAG_CONTROL_F  41    /* Mode change request                        */
#define DIAG_ERR_READ_F 42    /* Error record retreival                     */
#define DIAG_ERR_CLEAR_F  43  /* Error record clear                         */
#define DIAG_SER_RESET_F  44  /* Symbol error rate counter reset            */
#define DIAG_SER_REPORT_F 45  /* Symbol error rate counter report           */
#define DIAG_TEST_F     46    /* Run a specified test                       */
#define DIAG_GET_DIPSW_F  47  /* Retreive the current dip switch setting    */
#define DIAG_SET_DIPSW_F  48  /* Write new dip switch setting               */
#define DIAG_VOC_PCM_LB_F 49  /* Start/Stop Vocoder PCM loopback            */
#define DIAG_VOC_PKT_LB_F 50  /* Start/Stop Vocoder PKT loopback            */

//sya--------start
/* 51-52 Reserved */
#define DIAG_ORIG_F       53  /* Originate a call                           */
#define DIAG_END_F        54  /* End a call                                 */
/* 55-57 Reserved */
//sya--------end

#define DIAG_DLOAD_F      58  /* Switch to downloader                       */
#define DIAG_TMOB_F       59  /* Test Mode Commands                         */
#define DIAG_FTM_CMD_F    59 /* Test Mode Commands and FTM commands ysi 95c ftm 2000/9/24*/  

//sya--------start
#define DIAG_SEQ_NUM_F    60  /* Request to begin sending seq_nums in pkts  */
#define DIAG_SLEEP_F      61  /* Control whether portable may sleep         */
#define DIAG_SYSTIME_F    62  /* Obtain System Time from the mobile         */
//sya--------end

#define DIAG_STATE_F      63  /* Return the current state of the phone      */
#define DIAG_PILOT_SETS_F 64  /* Return all current sets of pilots          */
#define DIAG_SPC_F        65  /* Send the Service Prog. Code to allow SP    */

//sya--------start
#define DIAG_BAD_SPC_MODE_F 66  /* Invalid nv_read/write because SP is locked */
#define DIAG_PARM_GET2_F  67  /* get parms including MUX2: obsoletes PARM_GET */
//sya--------end

#define DIAG_RXCAL_F      68  /* Number of packets defined.                 */
#define DIAG_TXCAL_F      69  /* Number of packets defined.                 */
#define	DIAG_MISC_CAL_F   70  /* Number of packets defined.                 */
//#define DIAG_MAX_F        71  /* Number of packets defined.                 */

//sya--------start
#define DIAG_SERIAL_CHG_F 68  /* Serial mode change Request/Response        */
#define DIAG_GET_RSSI_F   69  /* Current CDMA RSSI Request/Response         */
#define DIAG_PASSWORD_F   70  /* Send password to unlock secure operations  */
#define DIAG_BAD_SECURITY_MODE_F 74  /* An operation was attempted which
                                        required the phone to be in a
                                        security state that is wasn't -
                                        like unlocked */
//#define DIAG_PR_LIST_WR_F 75  /* Write Preferred Roaming list to the phone. */
#define DIAG_PR_LIST_WR_F 72  /* Write Preferred Roaming list to the phone. */
#define DIAG_PR_LIST_RD_F 73  /* Read Preferred Roaming list from the phone. */
#define DIAG_SUBSYS_CMD_F 75	/* Subssytem dispatcher (extended diag cmd)   */
//#define DIAG_PR_LIST_RD_F 76  /* Read Preferred Roaming list from the phone. */
#define DIAG_MAX_F        77  /* Number of packets defined.                 */
//sya--------end
#define DIAG_FS_OP_F      92  /* Performs an Embedded File ---->this item inserted because of Global Phone Group's EFS*/
#define  DIAG_CAL_F                117//4.03-1 OJS 2002.3.25  /* Calibration Request/Response       *///OJS SP3100�� ���.
//OJS 20001122      

//+[WCDMA] vivache : SH100/KH1000, Diagnosis Packet Path ���� ���� command �߰�.
//#ifdef LGE_CALL_CDMA_ON_MSM6275  /* ByungChul, 2005/12/29 */
#define DIAG_LGF_CHANGE_DIAG_PATH_F		206
#define DIAG_LGF_GET_DIAG_PATH_F		207
#define DIAG_LGF_CHANGE_FACTORY_MODE_F	208

#define DIAG_RX_CAL_F             245
#define DIAG_TX_CAL_F             246
#define DIAG_MISC_CAL_INTERCUBE_F           247
//OJS END

#define DIAG_LNA_CTRL_F           249
// edited by JAKE for calibration <2001.02.20>

//2001.02.22 khj for temperature compensation
#define DIAG_TEMP_ADC_F           250

//2001.03.08 khj for tx power limit
#define DIAG_TX_PWR_LIMIT_F        248

// for T-DMB
#define DIAG_TDMB_F        233

//#define DIAG_MAX_F                255  /*KJH ADD 20001122  90  Number of packets defined.
#define DIAG_SUBSYS_FTM     11
#define   FTM_1X_C       0
#define   FTM_LGF_C      10
//2003.12.10 sandman : FTM Mode�� �ƴ� ���¿����� Packet����� ���� �߰�
#define DIAG_LGF_TOOLSDIAG_F	205
#endif  /* DIAGCMD_H */
