#ifndef _SIO_H
#define _SIO_H
/*===========================================================================

                S E R I A L    I / O    S E R V I C E S

                       H E A D E R    F I L E

DESCRIPTION
  This file contains types and declarations associated with the DMSS
  Serial I/O Services.

Copyright (c) 1990, 1991, 1992 by QUALCOMM, Incorporated.  All Rights Reserved.
Copyright (c) 1993 by QUALCOMM, Incorporated.  All Rights Reserved.
===========================================================================*/


/*===========================================================================

                      EDIT HISTORY FOR FILE

  $Header:   Z:/CMtest/CMtest(3.61)/WInclude/Sio.h-arc   1.0   Feb 14 2000 15:35:28   hyun  $

when       who     what, where, why
--------   ---     ----------------------------------------------------------
03/23/95   rdh     Added ISS1 to sio_baud_clock_ctl prototype.
01/22/95   jjw     Added 2nd generation definitions and function prototypes
05/25/94   jjw     Made change to Ring buffer type parameter
05/18/94   jjw     Added changes for DM multi-drop
08/19/93   jjw     Modfied some existing function names, added all Data
                   services functionality
12/07/93   jah     Added prototype for sio_baud_clock_ctl().
06/07/93   jjw     Made code review changes, added some more changes for Beta
                   II initial functionality
05/14/93   jjw     Added T_B2 compile-time directive for Beta II target
05/11/93   jjw     Cleaned up for code review, phase 1
03/12/93   jjw     Added typedef for Async. SIO channel A usage.
01/28/92   jah     Improved comments before passing this module to Jim Willkie.
08/25/92   jah     Improved error logging to differentiate errors more clearly.
07/23/92   jah     Added comments.
06/22/92   jah     Ported from brassboard, removed async.

===========================================================================*/


//#include "comdef.h"     /* Definitions for BYTE, WORD, etc.     */
//#include "queue.h"      /* Queue declaration package            */
//#include "rex.h"        /* REX multitasking package             */
//#include "targetg.h"     /* Target specific definitions          */

/*===========================================================================

                        DATA DECLARATIONS

===========================================================================*/

/*---------------------------------------------------------------------------
 SIO commands return status codes. The following status codes are returned by
 the sio functions.
---------------------------------------------------------------------------*/
//typedef enum {
#define SIO_DONE_S  0          /* Requested command performed successfully.       */
#define SIO_BADP_S  1          /* Bad parameter specified in requested command.   */
#define SIO_FULL_S  2          /* For sync mode, implies previous packet is still
                           being transmitted or received (as appropriate). */
#define SIO_BUSY_S  3          /* Command is still being processed.               */
//} sio_status_type;
typedef WORD sio_status_type;

/*---------------------------------------------------------------------------
 SIO Port Service mode type
---------------------------------------------------------------------------*/
//typedef enum {
#define SIO_DM_ASYNC_MODE        0                    /* DM A-HDLC mode           */
#define SIO_DS_AUTODETECT_MODE   1                    /* Full Autodetect mode     */
#define SIO_DS_RAWDATA_MODE      2                    /* Async Data transfer mode */
#define SIO_DS_CMD_MODE          3                    /* Async Data command mode  */
#define SIO_DS_PKT_MODE          4                    /* Packet service mode      */
//} sio_srvc_mode_enum_type;
typedef WORD sio_srvc_mode_enum_type;

/*---------------------------------------------------------------------------
 SIO Port Mode types.
---------------------------------------------------------------------------*/

/* Diagnostics Monitor (DM) external port modes                            */

#define SIO_HDLC_SYNC_MODE       0        /* Sync HDLC mode                */
#define SIO_HDLC_ASYNC_96_MODE   1        /* Async HDLC pkts @ 9.6 K baud  */
#define SIO_HDLC_ASYNC_192_MODE  2        /* Async HDLC pkts @ 19.2 K baud */
#define SIO_HDLC_ASYNC_384_MODE  3        /* Async HDLC pkts @ 38.4 K baud */
#define SIO_MONO_SYNC_MODE       4        /* Mono-sync packets # 38.4      */

/* Data Services Task external port modes                                  */

#define SIO_RAW_ASYNC_96_MODE    5        /* Async BYTEs @ 9.6 baud        */
#define SIO_RAW_ASYNC_192_MODE   6        /* Async BYTEs @ 19.2K baud      */
#define SIO_RAW_ASYNC_384_MODE   7        /* Async BYTEs @ 38.4K baud      */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/*---------------------------------------------------------------------------
 SIO MSM Dataport Link Packet Header type. The following descriptor is used
 for performing both packet receive and transmit functions.
---------------------------------------------------------------------------*/
#define SIO_MAX_PKT_SIZ  600

/*---------------------------------------------------------------------------
 SIO Dataport Sync BYTE definition
---------------------------------------------------------------------------*/
#define SIO_SYNC_BYTE   0x1D

/*---------------------------------------------------------------------------
 Maximum number of pad BYTEs that can be inserted into an MSM dataport packet.
 Pad BYTEs are used to aid in the synchronization of the link.
---------------------------------------------------------------------------*/

#define SIO_DP_MAX_PAD  10

/*---------------------------------------------------------------------------
  SIO Dataport Protocol BYTE definition (in header structure)
---------------------------------------------------------------------------*/

#define SIO_DLOAD_PROTO 0x01    /* Code Download */
#define SIO_DIAG_PROTO  0x02    /* Diag Task     */
#define SIO_DATA_PROTO  0x03    /* Data Services */

#pragma pack(1)         /* force to packed structure */

/*---------------------------------------------------------------------------
  Packet Header type for the different headers possible (ie. Monosync or HDLC)
  packets using the MSM
---------------------------------------------------------------------------*/

typedef struct
{
  BYTE sync;                       /* Sync BYTE                            */
  BYTE len_msb;                    /* Packet length most-significant BYTE  */
  BYTE len_lsb;                    /* Packet length least-significant BYTE */
  BYTE protocol;                   /* Protocol switch BYTE                 */
  WORD checksum;                   /* Checksum of following packet         */
} sio_mono_hdr_type;

typedef struct
{
  BYTE pad[sizeof( sio_mono_hdr_type )-1];       /* accounts for mono hdr */
  BYTE addr;                                     /* HDLC address field    */
} sio_hdlc_hdr_type;

typedef union
{
  sio_mono_hdr_type mono;
  sio_hdlc_hdr_type hdlc;
} sio_hdr_type;

/*---------------------------------------------------------------------------
  Packet Trailer type for HDLC Sync and HDLC Async packets using the SCC
---------------------------------------------------------------------------*/

typedef struct
{
  WORD crc;
} sio_hdlc_trl_type;

#pragma pack()          /* resume normal packing      */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/*---------------------------------------------------------------------------
  SIO packet descriptor type. The following descriptor is used for performing
  both packet receive and transmit functions.
---------------------------------------------------------------------------*/

typedef struct
{
  q_link_type link;
      /* Used in conjunction with the q_ptr field below for placing this
         descriptor onto a queue following an SIO receive or transmit
         operation. This field must be initialized by the caller prior to
         using the descriptor with the SIO Services. */

  q_type *q_ptr;
      /* Points to the queue on which to place this descriptor following a
         transmit or receive operation. If NULL, then the descriptor is not
         placed on any queue. This field must be initialized by the caller
         prior to using the descriptor with the SIO Services. It is not
         modified by the SIO Services. */

  rex_tcb_type  *tcb_ptr;
      /* This field points to the task control block of the task to be
         signalled when the SIO receive or transmit operation completes. If
         NULL, then no task is signalled. This field must be initialized by
         the caller prior to using the descriptor with the SIO Services. It is
         not modified by the SIO Services. */

  rex_sigs_type sigs;
      /* Specifies the signal mask to use when signalling the task specified
         by the tcb_ptr field. This field must be initialized by the caller
         prior to using the descriptor with the SIO Services. It is not
         modified by the SIO Services. */

  void         *pkt_ptr;
      /* Points to the buffer in which to receive a packet or from which to
         transmit a packet. This field must be initialized by the caller prior
         to using the SIO Services. It is not modified by the SIO services. */

  WORD         max_pkt_len;
      /* Specifies the maximum size, in BYTEs, of the packet buffer pointed
         to by the pkt_ptr field. It is mandatory that the caller initialize
         this field.  This field is not modified by the SIO Services. */

  WORD         pkt_len;
      /* When a packet is received, the SIO Service sets this field to the
         length, in BYTEs, of the received packet. When transmitting a packet,
         this field must be initialized by the caller to the length, in BYTEs,
         of the packet to be transmitted. */

  sio_status_type status;
      /* This field reflects the status of the transmit or receive operation.
         When an operation is initiated, this field is set to SIO_BUSY_S.
         When the operation completes, the field is set to the appropriate
         final status, usually SIO_DONE_S. */

} sio_desc_type;

/*===========================================================================

                      FUNCTION DECLARATIONS

===========================================================================*/


/*===========================================================================

FUNCTION SIO_SETUP_DM_RX

DESCRIPTION
  Setup a Diagnostics Service receive operation for channel A on the SCC. The
  type of RX operation depends upon the current mode of channel A. On completion
  the caller is notified via the receive descriptor.

DEPENDENCIES
  None

RETURN VALUE
  SIO_FULL_S, there is a receive already in progress.
  SIO_DONE_S, operation successful

SIDE EFFECTS
  None

===========================================================================*/

//extern sio_status_type sio_setup_dm_rx
//(
//  sio_desc_type *rx_ptr       /* Pointer to descriptor for receive packet. */
//);

/*===========================================================================

FUNCTION SIO_SETUP_DM_TXRX

DESCRIPTION
  Start a Diagnostics Service transmit operation and prepare for the following
  receive. The transaction is completed by the ISR internal to this service.
  On completion of each operation the caller is notified via the transmit/receive
  descriptor, as appropriate to the operation.

DEPENDENCIES
  None

RETURN VALUE
  SIO_DONE_S, the tx was setup successfully.
  SIO_FULL_S, the previous packet is still being transmitted.

SIDE EFFECTS
  None

===========================================================================*/

//extern sio_status_type sio_setup_dm_txrx
//(
//  sio_desc_type *tx_ptr,     /* Pointer to descriptor for transmit packet. */
//  sio_desc_type *rx_ptr      /* Pointer to descriptor for receive packet.  */
//);


/*===========================================================================

FUNCTION SIO_DM_GET_RX_PKT

DESCRIPTION

  This function retrieves the DM packet for task processing. This function
  performs the Async-HDLC state machine which performs BYTE un-stuffing
  operations and checks the CRC upon reception of the Flag BYTE (which denotes
  end-of-packet). Note that the Async-HDLC protocol is such that the Flag BYTE
  value will only be an end-of-packet indication and will not be at any other
  part of the packet.

DEPENDENCIES
  This function must only be called upon reception of a DM RX signal
  indicating that a DM packet is available.

RETURN VALUE
  TRUE if the packet is error-free, else FALSE.

SIDE EFFECTS
  None
===========================================================================*/

//extern boolean sio_dm_get_rx_pkt
//(
//  sio_desc_type *rx_pkt_ptr             /* pointer to DM RX SIO descriptor */
//);

/*===========================================================================

FUNCTION SIO_SET_DM_MODE

DESCRIPTION
  This function sets the Serial port to SIO_DM_ASYNC_MODE.

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_set_dm_mode( void);

#ifdef DS

/*===========================================================================

FUNCTION SIO_SETUP_DS_RX

DESCRIPTION
  Setup for a Data service RX operation. This function will result in
  RX Data Service BYTEs being continually stuffed into the queue passed in
  the 'rx_watermark_ptr' parameter.

  This function sets the RX serial driver into SIO_AUTODETECT_MODE. Reception
  of certain BYTE values results in the signaling of an event and the
  transition to another mode. Specifically the reception of a valid AT command
  results in the 'AT cmd' signal and the transition to SIO_COMMAND_MODE and
  the reception of a valid PPP starting sequence results in a transition to
  SIO_PACKET_MODE.

DEPENDENCIES
  The calling task must be the task signaled of RX BYTE reception.

RETURN VALUE
  None

SIDE EFFECTS
  A pointer to the TCB for the calling task is saved for use in signaling
  all Data service events.
===========================================================================*/

//extern void sio_setup_ds_rx
//(
//  dsm_watermark_type *rx_watermark_ptr,   /* ptr to RX q and flow ctl item */
//  rex_sigs_type      pkt_sig_mask,        /* Sig mask for packet flag rx'd */
//  rex_sigs_type      atcmd_sig_mask,      /* Sig mask for AT Cmd rx'd      */
//  rex_sigs_type      escape_sig_mask      /* Sig mask for Escape Seq. rx'd */
//);

/*===========================================================================

FUNCTION SIO_SETUP_DS_TX

DESCRIPTION
  Setup for a full Duplex Asynchronous transmit on the External port serial
  channel.

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_setup_ds_tx
//(
//  dsm_item_type *tx_ptr            /* Pointer to item for transmit packet. */
//);

/*===========================================================================

FUNCTION SIO_SET_AUTODETECT_MODE

DESCRIPTION
  This function sets the Serial port driver into SIO_DS_AUTODETECT_MODE.

DEPENDENCIES
  The calling task must be the task signaled for PKT or AT cmd reception.

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_set_autodetect_mode
//(
//  BYTE          termination_char,            /* Autobaud Termination char  */
//  boolean       echo_on                      /* RX character echo on/off   */
//);

/*===========================================================================

FUNCTION SIO_SET_RAWDATA_MODE

DESCRIPTION
  This function sets the Serial port to SIO_DS_RAWDATA_MODE where the SIO
  driver monitors the incoming data stream for the escape sequence using the
  passed parameters.

  Note that the Guard time interval is treated as a minimum and also is
  the maximum time interval between reception of the escape_seq_char.

DEPENDENCIES
  The calling task must be the task signaled for Escape Sequence detection.

RETURN VALUE
  None

SIDE EFFECTS
  The SIO driver software mode is set to SIO_DS_RAWDATA_MODE.
===========================================================================*/

//extern void sio_set_rawdata_mode
//(
//  WORD          guard_time,         /* Guardtime for escape sequence       */
//  BYTE          escape_seq_char     /* Escape sequence character           */
//);

/*===========================================================================

FUNCTION SIO_DCD_ASSERT

DESCRIPTION
  This function will Assert the DCD pin (or for the Portable target enable
  the DCD state to subsequently set the DCD-on field in the port status
  packet) on the External Port.

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_dcd_assert( void);


/*===========================================================================

FUNCTION SIO_DCD_DEASSERT

DESCRIPTION
  This function will De-assert the DCD pin (or for the Portable target enable
  the DCD state to subsequently clear the DCD-on field in the port status
  packet) on the External Port.

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_dcd_deassert( void);

/*===========================================================================

FUNCTION SIO_ENABLE_DTR_EVENT

DESCRIPTION
  This function will enable the SIO software to monitor the DTR pin (or for
  the Portable target monitor the DTR field in the port status packet) and
  signal the calling task.

DEPENDENCIES
  This function can only be called from the task that wants to be signaled.

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_enable_dtr_event
//(
//  rex_sigs_type sig_mask         /* signal mask for signaling calling task */
//);

/*===========================================================================

FUNCTION SIO_DISABLE_RFR_EVENT

DESCRIPTION
  This function will disable the SIO software from monitoring the RFR pin (or
  for the Portable target monitor the RFR field in the port status packet) and
  signal the calling task.

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_disable_dtr_event( void);

/*===========================================================================

FUNCTION SIO_ENABLE_RFR_EVENT

DESCRIPTION
  This function will enable the SIO software to monitor the RFR pin (or for
  the Portable target monitor the RFR field in the port status packet) and
  signal the calling task.

DEPENDENCIES
  This function can only be called from the task that wants to be signaled.

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_enable_rfr_event
//(
//  rex_sigs_type sig_mask         /* signal mask for signaling calling task */
//);

/*===========================================================================

FUNCTION SIO_DISABLE_RFR_EVENT

DESCRIPTION
  This function will disable the SIO software from monitoring the RFR pin (or
  for the Portable target monitor the RFR field in the port status packet) and
  signal the calling task.

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_disable_rfr_event( void);

/*===========================================================================

FUNCTION SIO_RI_ASSERT

DESCRIPTION
  This function will Assert the Ring Indicator pin on the External Port
  connector (or for the portable the RI field in the port status packet will
  be set to indicate that RI is asserted).

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_ri_assert( void);

/*===========================================================================

FUNCTION SIO_RI_DEASSERT

DESCRIPTION
  This function will De-assert the Ring Indicator pin on the External Port
  connector (or for the portable the RI field in the port status packet will
  be cleared to indicate that RI is de-asserted).

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_ri_deassert( void);

/*===========================================================================

FUNCTION SIO_CTS_ASSERT

DESCRIPTION
  This function will assert the Clear-to-send (CTS) pin on the external port
  connector (or for the portable the CTS field in the port status packet will
  be set to indicate the CTS is asserted).

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_cts_assert( void);

/*===========================================================================

FUNCTION SIO_CTS_DEASSERT

DESCRIPTION
  This function will de-assert the Clear-to-send (CTS) pin on the external port
  connector (or for the portable the CTS field in the port status packet will
  be cleared to indicate the CTS is asserted).

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_cts_deassert( void);

/*===========================================================================

FUNCTION SIO_DSR_ASSERT

DESCRIPTION
  This function will assert the Data-Set-Ready (DSR) pin on the external port
  connector (or for the portable the DSR field in the port status packet will
  be set to indicate the DSR is asserted).

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_dsr_assert( void);

/*===========================================================================

FUNCTION SIO_DSR_DEASSERT

DESCRIPTION
  This function will de-assert the Data-Set-Ready (DSR) pin on the external port
  connector (or for the portable the DSR field in the port status packet will
  be cleared to indicate the DSR is asserted).

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_dsr_deassert( void);

/*===========================================================================

FUNCTION SIO_DS_RX_CANCEL

DESCRIPTION
  This function will cancel any pending Data service RX operation and return
  a pointer to the RX descriptor.

DEPENDENCIES
  None

RETURN VALUE
  A pointer to the RX packet descriptor will be returned, or NULL if no RX
  operation was underway.

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_ds_rx_cancel( void);

/*===========================================================================

FUNCTION SIO_DS_TX_CANCEL

DESCRIPTION
  This function will cancel all pending Data Service TX operations and put
  all current TX packet descriptor links on the queue pointed at by the
  done-q-ptr field in the descriptor.

DEPENDENCIES
  All the Data Service TX descriptor packets must contain a valid queue in
  the 'done_q_ptr' field.

RETURN VALUE
  None

SIDE EFFECTS
  None
===========================================================================*/

//extern void sio_ds_tx_cancel( void);

/*===========================================================================

FUNCTION SIO_DTR_ASSERTED

DESCRIPTION
  This function will return the current state of the DTR pin on the external
  connector (or for the portable the DTR field in the most recent port status
  packet will be returned.

DEPENDENCIES
  None

RETURN VALUE
  TRUE is DTR is Asserted, else FALSE.

SIDE EFFECTS
  None
===========================================================================*/

//extern boolean sio_dtr_asserted( void);

/*===========================================================================

FUNCTION SIO_RFR_ASSERTED

DESCRIPTION
  This function will return the current state of the RFR pin on the external
  connector.

DEPENDENCIES
  None

RETURN VALUE
  TRUE is RFR is Asserted, else FALSE.

SIDE EFFECTS
  None
===========================================================================*/

//extern boolean sio_rfr_asserted( void);
#endif

/*===========================================================================

FUNCTION SIO_HW_INIT

DESCRIPTION
  Initialize the serial interface for operation.

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  Aborts any transmit or receive which is currently in progress.

===========================================================================*/

//extern void sio_hw_init( void);


/*===========================================================================

FUNCTION SIO_CONFIG_EXT_PORT_SRVC
  Initialize the Serial Services for the target specified by the compile-time
  directive TG. This could be the SCC channel A and/or the MSM dataport to the
  specified modes.  Note that any pending RX or TX operations remain active
  (ie. has no effect on task operations).

DESCRIPTION

DEPENDENCIES
  1) sio_hw_init must have been previously invoked.
  2) If DS is compiled into the target then the Data Task must be operational

RETURN VALUE
  TRUE if the specified modes are valid, else FALSE.

SIDE EFFECTS
  None
===========================================================================*/

//extern boolean sio_config_ext_port_srvc
//(
//  boolean data_services_mode,                      /* Data Services ON/OFF */
//  BYTE    ext_port_mode,                           /* External Port mode   */
//  BYTE    dm_addr                                  /* HDLC mode address    */
//);


#if ((TG==T_P) || (TG==T_I1))
/*===========================================================================

FUNCTION SIO_BAUD_CLOCK_CTL

DESCRIPTION
  Turn on/off the baud clock

DEPENDENCIES
  The M and N registers must have been previously programmed.

RETURN VALUE
  None

SIDE EFFECTS
  None

===========================================================================*/

//extern void sio_baud_clock_ctl
//(
//  boolean on_off
    /* Turn the baud clock on/off, TRUE=on, FALSE=off */
//);
#endif


#endif /* SIOG2_H */

