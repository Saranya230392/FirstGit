#ifndef _HS_H
#define _HS_H
/*===========================================================================

              H A N D S E T   T A S K   H E A D E R   F I L E

DESCRIPTION
  This file contains the data structures used to interface to the Handset
  Task for the DMSS Portable and Mobile software.

REFERENCES
  ALPS, "A Cellular Bus Operation"
  NEC LCD Controller "uPD7228G" Spec Sheet
  Epson LCD Controller SED1230 Spec Sheet

Copyright (c) 1992, 1993, 1994 by QUALCOMM, Incorporated.  All Rights Reserved.
Copyright (c) 1995 by QUALCOMM, Incorporated.  All Rights Reserved.
===========================================================================*/


/*===========================================================================

                      EDIT HISTORY FOR FILE

  This section contains comments describing changes made to this file.
  Notice that changes are listed in reverse chronological order.

  $Header:   Z:/CMtest/CMtest(3.61)/WInclude/Hs.h-arc   1.0   Feb 14 2000 15:35:24   hyun  $

when       who     what, where, why
--------   ---     ----------------------------------------------------------
05/24/95   jah     Added T_I2 (ISS-2) Support.
05/02/95   jah     Fixed Max RSSI for Beta to be 7 instead of 8.
03/30/95   jah     Added T_G (Gemini) Support.
10/06/94   jah     Changed height/width defines to have a base definition
                   per target, to facilitate the DM.
09/19/94   jah     Added HS_SET_GLYPH command
07/05/94   jah     Added HS_DIAG_SET_SCRN and HS_DIAG_SCRN_LOCK commands and
                   associated packet data types to support diag screen loads
06/28/94   jah     Added ISS1 Annunciators, updated comments
05/11/94   jah     Added HS_ON_HOOK_K and HS_OFF_HOOK_K.
09/22/93   jah     Added HS_EXT_PWR_ON_K and HS_EXT_PWR_OFF_K for Portable
                   external power sensing.
05/14/93   jah     Added more T_B2 (Beta II) conditional compilation
05/11/93   jah     Added T_B2 (Beta II) conditional compilation
03/18/93   jah     Added prototype for hs_set_char(), Portable-only.
03/15/93   jah     Added prototype for hs_poll_gpio.
01/26/93   jah     Added comment to header per code review.
01/15/93   jah     Moved the Portable "Special graphics characters" from 0..7
                   to 8..F (duplicate map).  Added HS_HALF_BOX.
12/07/92   jah     Added HS_BAD_BATT_K for reporting a bad battery in the
                   mobile.
10/23/92   jah     Added commands HS_ALL_ANNUN and HS_ALL_SCRN, and the assoc.
                   data structures.
10/20/92   jah     Added include of target.h.  Added definitons for the
                   Portable annunciators.
10/06/92   jah     Comment updates for portable/mobile differences.  Added
                   portable user-defined characters and screen size.
08/19/92   jah     Changed HS_PWR_K to HS_PWR_ON/OFF_K's for UI convenience.
08/06/92   jah     Converted entirely over to the new ALPS handset
08/02/92   jah     Added keys_free to hs_key_packet_type, for returning the
                   amount of free space in the input buffer.
07/08/92   jah     Initial revision

===========================================================================*/

//#include "comdef.h"     /* Definitions for BYTE, WORD, etc.     */
//#include "queue.h"      /* Definition of Queue services         */
//#include "rex.h"        /* definition of REX data types         */
//#include "targetg.h"     /* Target specific definitions          */
//#include "lgic.h"       /* LGICed definitions                   */


/*===========================================================================

                        DATA DECLARATIONS

===========================================================================*/

/*---------------------------------------------------------------------------
  Commands and Command Header
---------------------------------------------------------------------------*/

/* Handset Operations which can be performed/requested
** (M) = Mobile-only, (P) = Portable-only, (G) = Gemini, all others are "both"
*/
//typedef enum {
#define  HS_ACTIVE         0  /* unused                                            */
#define  HS_SLEEP          1  /* unused                                            */
#define  HS_SCRN_CTL       2  /* Turn on/off the LCD screen                        */
#define  HS_BACKLIGHT      3  /* Turn on/off the screen & keypad backlights        */
#define  HS_SCRN_UPDATE    4  /* Update the screen image                           */
#define  HS_ANNUN          5  /* Turn on/off the annunciators                      */
#define  HS_BLINK_ANNUN    6  /* Set which annunciators blink                      */
#define  HS_SCRN_RSSI      7  /* Set the level of the RSSI bar                     */
#define  HS_AUD_IN         8  /* Set the audio input path                          */
#define  HS_AUD_OUT        9  /* Set the audio output path                         */
#define  HS_SKI            10  /* Simulate keypad input                             */
#define  HS_UPDATE_BLINK   11  /* Update the screen used for blinking               */
#define  HS_BLINK_RATE     12  /* Set the blink rate                                */
#define  HS_DIAG           13  /* Diag state dump                                   */
#define  HS_DIAG_LOCK      14  /* Keypad lock                                       */
#define  HS_DTMF_DET       15  /* (M) Control polling of the DTMF detector          */
#define  HS_ALL_ANNUN      16  /* Set both regular and blinking annunciators        */
#define  HS_ALL_SCRN       17  /* Update both the blink and regular screen          */
#define  HS_DIAG_SET_SCRN  18  /* Set the contents of the screen                    */
#define  HS_DIAG_SCRN_LOCK 19  /* Lock screen updates, restrict diag commands       */
#define  HS_SET_GLYPH      20  /* (P,G) set the bitmap of a glyph                   */
#define  HS_SCRN_BATTERY   21   /* (G) set the battery level display                 */
typedef  BYTE hs_op_type;

/* Command header common to all command packets
*/
typedef struct {
  q_link_type   link;        /* Queue link                            */
  q_type        *done_q_ptr; /* Queue to put 'this' on when done      */
  rex_tcb_type  *task_ptr;   /* Task to signal when done              */
  rex_sigs_type sigs;        /* Signals to signal *task_ptr when done */
  hs_op_type    cmd;         /* Handset Command                       */
} hs_hdr_type;

/*---------------------------------------------------------------------------
  Keypad declarations
---------------------------------------------------------------------------*/

/* These are the keycodes returned by calls to hs_key_get().  Do not depend
** on their numeric value, just use the symbolic values.  Some of these have
** been set to specific values to make decoding the hardware responses
** more convenient.
**
** (M) = Mobile, (P) = Portable, (W) = WLL, (G) = Gemini, all others are "all"
*/
//typedef enum {          /* KEYS                                    */
#define  HS_NONE_K  0        /* No more keycodes available              */
#define  HS_ON_HOOK_K      1   /* (W) phone has gone on-hook              */
#define  HS_OFF_HOOK_K     2   /* (W) phone has gone off-hook             */
#define  HS_RING_VOL_0_K   3   /* (W) ringer volume 0 (Keep 0-2 in order) */
#define  HS_RING_VOL_1_K   4   /* (W) ringer volume 1 ( and sequential!!) */
#define  HS_RING_VOL_2_K   5   /* (W) ringer volume 2                     */
#define  HS_EAR_UP_K       6   /* (G) earpiece up                         */
#define  HS_EAR_UP_END_K   7   /* (G) earpiece up + end pressed           */
#define  HS_EAR_DOWN_K     8   /* (G) earpiece down                       */
#define  HS_PF1_K          9   /* (G) softkey #1 (left-most)              */
#define  HS_PF2_K         10   /* (G) softkey #2 (right-most)             */
#define  HS_MSG_K         11   /* (G) message waiting                     */
#define  HS_POUND_K   0x23    /* '#' key ASCII '#'                      */
#define  HS_STAR_K   0x2A     /* '*' key ASCII '*'                      */
#define  HS_0_K   0x30        /* '0' key ASCII '0'                      */
#define  HS_1_K   0x31        /* '1' key ASCII '1'                      */
#define  HS_2_K   0x32        /* '2' key ASCII '2'                      */
#define  HS_3_K   0x33        /* '3' key ASCII '3'                      */
#define  HS_4_K   0x34        /* '4' key ASCII '4'                      */
#define  HS_5_K   0x35        /* '5' key ASCII '5'                      */
#define  HS_6_K   0x36        /* '6' key ASCII '6'                      */
#define  HS_7_K   0x37        /* '7' key ASCII '7'                      */
#define  HS_8_K   0x38        /* '8' key ASCII '8'                      */
#define  HS_9_K   0x39        /* '9' key ASCII '9'                      */
#define  HS_SEND_K   0x50     /* Send key                                */
#define  HS_END_K   0x51      /* (both) End key (P) Power key           */
#define  HS_CLR_K   0x52      /* Clear key                               */
#define  HS_STO_K   0x53      /* Store key                               */
#define  HS_UP_K   0x54       /* Up-arrow key was pressed                */
#define  HS_DOWN_K   0x55     /* Down-arrow key was pressed              */
#define  HS_MUTE_K   0x56     /* (M) Mute Key                            */
#define  HS_RCL_K   0x57      /* Recall key                              */
#define  HS_SD1_K   0x58      /* (M) speed dial #1                       */
#define  HS_SD2_K   0x59      /* (M) speed dial #2                       */
#define  HS_SD3_K   0x5A      /* (M) speed dial #3                       */
#define  HS_MENU_K   0x5B     /* Menu key                                */
#define  HS_ALPHA_K   0x5C    /* Alpha key                               */
#define  HS_DEC_POUND_K  0x5d     /* (M) Decoded # DTMF                      */
#define  HS_DEC_STAR_K   0x5e     /* (M) Decoded * DTMF                      */
#define  HS_DEC_0_K      0x5f     /* (M) Decoded 0 DTMF                      */
#define  HS_DEC_1_K      0x60     /* (M) Decoded 1 DTMF                      */
#define  HS_DEC_2_K      0x61     /* (M) Decoded 2 DTMF                      */
#define  HS_DEC_3_K      0x62     /* (M) Decoded 3 DTMF                      */
#define  HS_DEC_4_K      0x63     /* (M) Decoded 4 DTMF                      */
#define  HS_DEC_5_K      0x64     /* (M) Decoded 5 DTMF                      */
#define  HS_DEC_6_K      0x65     /* (M) Decoded 6 DTMF                      */
#define  HS_DEC_7_K      0x66     /* (M) Decoded 7 DTMF                      */
#define  HS_DEC_8_K      0x67     /* (M) Decoded 8 DTMF                      */
#define  HS_DEC_9_K      0x68     /* (M) Decoded 9 DTMF                      */
#define  HS_DEC_A_K      0x69     /* (M) Decoded A DTMF                      */
#define  HS_DEC_B_K      0x6a     /* (M) Decoded B DTMF                      */
#define  HS_DEC_C_K      0x6b     /* (M) Decoded C DTMF                      */
#define  HS_DEC_D_K      0x6c     /* (M) Decoded D DTMF                      */
#define  HS_PWR_ON_K     0x6d     /* (M) Power key is switched 'on'          */
#define  HS_PWR_OFF_K    0x6e     /* (M) Power key is switched 'off'         */
#define  HS_PWR_K        0x6f     /* (G) Power key                           */
#define  HS_INFO_K       0x70     /* (G) Info key                            */
#define  HS_FREE_K       0x71     /* Phone was placed in hands-free cradle   */
#define  HS_PHONE_K      0x72     /* Phone was lifted from hands-free cradle */
#define  HS_IGN_OFF_K    0x73     /* Ignition was turned off                 */
#define  HS_IGN_ON_K     0x74     /* Ignition was turned on                  */
#define  HS_TMR_ON_K     0x75     /* (M) Power-up timer 'on' pseudo-key      */
#define  HS_TMR_OFF_K    0x76     /* (M) Power-up timer 'off' pseudo-key     */
#define  HS_BAD_BATT_K   0x77     /* (M) The car battery is failing          */
#define  HS_EXT_PWR_ON_K 0x78     /* (P) External power was turned on        */
#define  HS_EXT_PWR_OFF_K 0x79    /* (P) External power was turned off       */
#define  HS_REDIAL_K      0x7a    /* (W) Redial key                          */
#define  HS_RSSI_K         0x7b   /* (W) RSSI key                            */

#if(KEYPAD == LGIC)
#define  HS_FUNC_K            0x7c/* (LGIG) FUNC key - function key          */
#define  HS_MENU_CLR_K        0x7d/* (LGIG) FUNC key - MENU/CLR key          */
#define  HS_STO_RCL_K         0x7e/* (LGIG) FUNC key - STO/RCL key           */
#endif

#define  HS_RELEASE_K  0xff   /* Key to note that all keys are up        */
typedef WORD hs_key_type;

/* DTMF detector polling on/off command packet for HS_DTMF_DET
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header */
  boolean on_off;       /* on/off control */
} hs_dtmf_packet_type;

/*---------------------------------------------------------------------------
  Screen declarations
---------------------------------------------------------------------------*/

/* Screen dimensions
*/
/* T_M, Mobile */
#define HS_SCRN_HIGH_M  2       /* Screen height in characters */
#define HS_SCRN_WIDE_M  8       /* Screen width in characters  */

/* T_B2, Beta 2 */
#define HS_SCRN_HIGH_B2 2       /* Screen height in characters */
#define HS_SCRN_WIDE_B2 8       /* Screen width in characters  */

/* T_P, Portable */
#define HS_SCRN_HIGH_P  4       /* Screen height in characters */
#define HS_SCRN_WIDE_P  10      /* Screen width in characters  */

/* T_G, Gemini */
#define HS_SCRN_HIGH_G  4       /* Screen height in characters */
#define HS_SCRN_WIDE_G  12      /* Screen width in characters  */

#if (TG==T_M)
#define HS_SCRN_HIGH    HS_SCRN_HIGH_M
#define HS_SCRN_WIDE    HS_SCRN_WIDE_M
#elif (TG==T_B2)
#define HS_SCRN_HIGH    HS_SCRN_HIGH_B2
#define HS_SCRN_WIDE    HS_SCRN_WIDE_B2
#elif (TG==T_P)
#define HS_SCRN_HIGH    HS_SCRN_HIGH_P
#define HS_SCRN_WIDE    HS_SCRN_WIDE_P
#else
#define HS_SCRN_HIGH    HS_SCRN_HIGH_G
#define HS_SCRN_WIDE    HS_SCRN_WIDE_G
#endif

#define HS_SCRN_ROW_0   0                       /* Index of 0th row */
#if HS_SCRN_HIGH > 1
#define HS_SCRN_ROW_1   (1 * HS_SCRN_WIDE)      /* Index of 1st row */
#endif
#if HS_SCRN_HIGH > 2
#define HS_SCRN_ROW_2   (2 * HS_SCRN_WIDE)      /* Index of 2nd row */
#endif
#if HS_SCRN_HIGH > 3
#define HS_SCRN_ROW_3   (3 * HS_SCRN_WIDE)      /* Index of 3rd row */
#endif

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* Screen character image type
*/
typedef WORD hs_scrn_type[ HS_SCRN_HIGH * HS_SCRN_WIDE ];

/* Special graphics characters (or best approximation)
*/
#if ((TG==T_M) || (TG==T_B2))
#define HS_HALF_BOX     ((BYTE) 0xDB)   /* Half-empty box [X ]  */
#define HS_EMPTY_BOX    ((BYTE) 0xDB)   /* Empty box            */
#define HS_EMPTY_LEFT   ((BYTE) 0x3C)   /* Empty left arrow     */
#define HS_EMPTY_RIGHT  ((BYTE) 0x3E)   /* Empty right arrow    */
#define HS_FILL_BOX     ((BYTE) 0x7F)   /* Filled box           */
#define HS_FILL_LEFT    ((BYTE) 0x7F)   /* Filled left arrow    */
#define HS_FILL_RIGHT   ((BYTE) 0x7F)   /* Filled right arrow   */
#define HS_FILL_UP      ((BYTE) 0x5E)   /* Filled up arrow      */
#define HS_FILL_DOWN    ((BYTE) 0x76)   /* Filled down arrow    */
#elif (TG==T_P)
#define HS_EMPTY_BOX    ((BYTE) 0xDB)   /* Empty box            */
#define HS_FILL_BOX     ((BYTE) 0xFF)   /* Filled box           */
#elif (TG==T_G)
#define HS_EMPTY_BOX    ((BYTE) 0xDC)   /* Empty box            */
#define HS_FILL_BOX     ((BYTE) 0x8F)   /* Filled box           */
#endif

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* CD-7000 and Gemini characters are 5 columns packed 1 row per BYTE, 7 rows.
*/
#define HS_GLYPH_WIDTH   5
#define HS_GLYPH_HEIGHT  7
typedef WORD hs_glyph_type[ HS_GLYPH_HEIGHT ];

/* Number of glyphs supported
*/
#if (TG==T_P)
#define HS_GLYPH_CNT     8
#elif (TG==T_G)
#define HS_GLYPH_CNT     4
#else
#define HS_GLYPH_CNT     0
#endif

/* Character definition command packet for HS_SET_GLYPH
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header                         */
  BYTE index;           /* character index of glyph being defined */
  hs_glyph_type bitmap; /* bitmap of glyph being defined          */
} hs_glyph_packet_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* Screen/Backlight on/off command packet for HS_SCRN_CTL and HS_BACKLIGHT
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header */
  boolean on_off;       /* on/off control */
} hs_ctl_packet_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* Screen update command packet for HS_SCRN_UPDATE and HS_UPDATE_BLINK
*/
typedef struct {
  hs_hdr_type hdr;        /* Command header */
  hs_scrn_type *scrn_ptr; /* Screen image   */
} hs_scrn_packet_type;

/* Screen update command packet for HS_ALL_SCRN
*/
typedef struct {
  hs_hdr_type hdr;              /* Command header     */
  hs_scrn_type *scrn_ptr;       /* Screen image       */
  hs_scrn_type *blink_scrn_ptr; /* Blink screen image */
} hs_scrna_packet_type;

/* Blink command packet for HS_BLINK_RATE
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header                           */
  WORD blink_rate;      /* rate for blinking milliseconds per image */
} hs_blink_packet_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* RSSI level command packet for HS_SCRN_RSSI
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header   */
  BYTE rssi;            /* RSSI level       */
  BYTE blink_rssi;      /* Blink RSSI level */
} hs_rssi_packet_type;

/* Define how RSSI level is displayed for targets which have
** an actual RSSI display
*/
#if (TG==T_G)
#define HS_MAX_RSSI     5     /* RSSI range is 0..5 */
#elif (TG==T_I2)
#define HS_MAX_RSSI     0     /* RSSI range is 0    */
#else
#define HS_MAX_RSSI     7     /* RSSI range is 0..7 */
#endif

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

/* Battery level command packet for HS_SCRN_BATTERY
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header      */
  BYTE batt;            /* Battery level       */
  BYTE blink_batt;      /* Blink battery level */
} hs_batt_packet_type;

/* Define how Battery level is displayed for targets which have
** an actual Battery display
*/
#if (TG==T_G)
#define HS_MAX_BATTERY  5     /* Battery range is 0..5 */
#endif

/*---------------------------------------------------------------------------
  Annunciator declarations (Both on-screen and LED)
---------------------------------------------------------------------------*/

/* Annunciator Masks/Values (comment on each is a "rough" meaning of each)
*/
#define HS_AN_ALL       0xffff                  /* Mask of all annunciators */
#define HS_ANNUNCIATORS 12

#if ((TG==T_M) || (TG==T_B2))

/* First set of annunciators
*/
#define HS_AN_MSG       0x0010  /* Message             */

#define HS_AN_CDMA      0x0008  /* CDMA                */
#define HS_AN_PAGE      0x0004  /* Page                */
#define HS_AN_POWER     0x0002  /* Power               */
#define HS_AN_MENU      0x0001  /* Menu                */

/* Second set of annunciators
*/
#define HS_AN_MUTE      0x4000  /* Mute                */
#define HS_AN_PAD       0x2000  /* Pad                 */
#define HS_AN_HORN      0x1000  /* Horn                */

#define HS_AN_ANSR      0x0800  /* Answer              */
#define HS_AN_NOSVC     0x0400  /* No Svc (no service) */
#define HS_AN_ROAM      0x0200  /* Roam                */
#define HS_AN_INUSE     0x0100  /* In Use              */

#elif ((TG==T_P)||(TG==T_S))

#define HS_AN_INUSE     0x0010  /* In Use              */
#define HS_AN_NOSVC     0x0008  /* No Svc (no service) */
#define HS_AN_ROAM      0x0004  /* Roam                */
#define HS_AN_CDMA      0x0002  /* CDMA                */
#define HS_AN_MSG       0x0001  /* Message             */

#elif (TG==T_I1)

#define HS_AN_MUTE      0x4000  /* Mute                */
#define HS_AN_NOSVC     0x0008  /* No Svc (no service) */

#elif (TG==T_G)

#define HS_AN_CDMA      0x0001  /* CDMA                */
#define HS_AN_INUSE     0x0002  /* In Use              */
#define HS_AN_NOSVC     0x0004  /* No Svc (no service) */
#define HS_AN_ROAM      0x0008  /* Roam                */
#define HS_AN_MSG       0x0010  /* Message             */
#define HS_AN_VMAIL     0x0020  /* Voice mail          */
#define HS_AN_SNI       0x0040  /* Silent Notification */

#elif (TG==T_I2)

#define HS_AN_MSG       0x0010  /* Message on network  */
#define HS_AN_RSSI      0x0020  /* RSSI mode active    */
#define HS_AN_DPACTIVE  0x0040  /* Dataport active     */

#endif

/* Annunciator control type
*/
typedef struct {
  WORD mask;            /* Mask of annunciators to modify   */
  WORD value;           /* Values of annunciators to modify */
} hs_ann_type;

/* Annunciator command packet for HS_ANNUN and HS_BLINK_ANNUN
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header     */
  hs_ann_type annun;    /* Annunciator change */
} hs_ann_packet_type;

/* Annunciator command packet for HS_ALL_ANNUN
*/
typedef struct {
  hs_hdr_type hdr;          /* Command header     */
  hs_ann_type annun;        /* Annunciator change */
  hs_ann_type blink_annun;  /* Annunciator change */
} hs_anna_packet_type;

/*---------------------------------------------------------------------------
  Audio control (for the Sound Services)
---------------------------------------------------------------------------*/

/* Handset audio paths
** Not all of the audio paths, just the ones via the handset/cradle.
*/
//typedef enum {
#define  HS_AUD_HS   0 /* Audio path is the handset         */
#define  HS_AUD_HF   1    /* Audio path is the hands-free path */
#define  HS_AUD_MUTE 2   /* Audio path is muted               */
typedef WORD hs_aud_type;

/* Audio path command packet for HS_AUD_IN and HS_AUD_OUT
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header */
  hs_aud_type apath;    /* Audio path     */
} hs_aud_packet_type;

/*---------------------------------------------------------------------------
  Diagnostic input/output/control
---------------------------------------------------------------------------*/

/* Simulate-keypad-input command packet for HS_SKI (for DM HS simulator)
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header                  */
  BYTE keycode;         /* Keycode input                   */
  WORD keys_free;       /* Number of free key buffer slots */
} hs_key_packet_type;

/* Description of the buffer of information describing the
** handset's screen/annunciator state.
*/
typedef struct {
  boolean backlight_on;         /* Backlight state         */
  hs_scrn_type scrn;            /* Screen                  */
  WORD annun;                   /* Annunciators            */
  hs_scrn_type blink_scrn;      /* Screen for blinking     */
  WORD blink_annun;             /* Annunciators for blink  */
  BYTE rssi;                    /* RSSI indicator          */
  WORD blink_rate;              /* Blink rate for blinking */
} hs_diag_type;

/* Handset information dump command packet for HS_DIAG (diag snapshot),
** and screen information command packet for HS_DIAG_SET_SCRN.
*/
typedef struct {
  hs_hdr_type hdr;              /* Command header */
  hs_diag_type *diag_ptr;       /* Handset state snapshot */
} hs_diag_packet_type;

/* Handset keypad lock command packet for HS_DIAG_LOCK and HS_DIAG_SCRN_LOCK
*/
typedef struct {
  hs_hdr_type hdr;      /* Command header */
  boolean lock;         /* Lock/un-lock   */
} hs_lock_packet_type;

/*---------------------------------------------------------------------------
  Command packet definition
---------------------------------------------------------------------------*/

/* Handset command packet which is passed to hs_cmd()
*/
typedef union {
  hs_hdr_type          hdr;     /* Just a command header                   */
  hs_ctl_packet_type   ctl;     /* LCD control, HS_SCRN_CTL, HS_BACKLIGHT  */
  hs_scrn_packet_type  scrn;    /* Screen, HS_SCRN_UPDATE, HS_UPDATE_BLINK */
  hs_scrna_packet_type scrna;   /* All screens, HS_ALL_SCRN                */
  hs_rssi_packet_type  rssi;    /* Set RSSI, HS_SCRN_RSSI                  */
  hs_ann_packet_type   ann;     /* Annunciator change, HS_ANNUN            */
  hs_anna_packet_type  anna;    /* Annunciator change all, HS_ALL_ANNUN    */
  hs_aud_packet_type   aud;     /* Set audio path, HS_AUD_IN, HS_AUD_OUT   */
  hs_key_packet_type   key;     /* Simulate-keypad-input, HS_SKI           */
  hs_blink_packet_type blink;   /* Screen blink, HS_BLINK_RATE             */
  hs_diag_packet_type  diag;    /* Diag state dump, HS_DIAG                */
  hs_lock_packet_type  lock;    /* Keypad lock, HS_DIAG_LOCK               */
  hs_dtmf_packet_type  dtmf;    /* DTMF detector control, HS_DTMF_DET      */
  hs_diag_packet_type  dscrn;   /* Diag screen load, HS_DIAG_SET_SCRN      */
  hs_lock_packet_type  scrlock; /* Screen lock, HS_DIAG_SCRN_LOCK          */
  hs_glyph_packet_type glyph;   /* glyph packet for HS_SET_GLYPH           */
  hs_batt_packet_type  batt;    /* Set Battery level, HS_SCRN_BATTERY      */

} hs_packets_type;

/* Queue of free command buffers.  These can be retrieved by calling
** q_get( &hs_cmd_free_q ).  Note:  *done_q_ptr is set to point to this
** queue so that on completion the commands will be placed back on this
** queue.  Do not alter *done_q_ptr.
*/
//extern q_type hs_cmd_free_q;


/*===========================================================================

                      FUNCTION DECLARATIONS

===========================================================================*/


/*===========================================================================

FUNCTION HS_KEY_INIT

DESCRIPTION
  This procedure performs any keypad initialization, and remembers what task
  to signal when keycodes become available.  This routine stuffs any steady-
  state keys into the key buffer, Ignition on/off and in/out-of hands-free
  cradle.

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  None

===========================================================================*/
//extern void hs_key_init
//(
//  rex_tcb_type  *task_ptr,     /* Task to signal when keycodes arrive      */
//  rex_sigs_type key_signal     /* Signal to send task when keycodes arrive */
//);


/*===========================================================================

FUNCTION HS_KEY_GET

DESCRIPTION
  Read a keycode from the input buffer.

DEPENDENCIES
  None

RETURN VALUE
  This procedure returns the oldest unread keycode.  If no keycode
  is currently available, KEY_NONE is returned.

SIDE EFFECTS
  None

===========================================================================*/
//extern BYTE hs_key_get( void );


/*===========================================================================

FUNCTION HS_CMD

DESCRIPTION
  Queue a command for execution by the Handset Task.

DEPENDENCIES
  The queue will not be processed until the Handset Task has started.

RETURN VALUE
  None

SIDE EFFECTS
  None

===========================================================================*/
//extern void hs_cmd
//(
//  hs_packets_type *cmd_ptr
    /* pointer to a handset command.  When the command has finished, the
    ** command structure is put on the "done queue".  If there is no "done
    ** queue", or this operation is not desirable, set the "done queue"
    ** pointer to NULL.  Also when the command has completed, the specified
    ** task is signaled with the sig parameter.  If no signaling is required,
    ** the task pointer parameter can be set to NULL.
    */
//);


/*===========================================================================

FUNCTION HS_TASK

DESCRIPTION
  The Main Control Task calls this procedure via rex_def_task() to start up
  this function as the Handset Task.  This procedure calls hs_init() which
  initializes the handset and handles startup handshaking with the Main Control
  Task.

DEPENDENCIES
  This procedure must be called by rex_def_task.  The startup handshaking
  must be completed in order for the handset task to begin normal operations.

RETURN VALUE
  This procedure does not return.

SIDE EFFECTS
  The handset display will change as a result of handset task processing.

===========================================================================*/
//extern void hs_task( DWORD ignored /* parameter from REX -- ignored */ );


/*===========================================================================

FUNCTION HS_POLL_GPIO

DESCRIPTION
  This procedure polls the GPIOS which are keys, handling key event
  signals for new keycodes, and key-up.

DEPENDENCIES
  None

RETURN VALUE
  True if anything changed.
  False if no changes occurred.

SIDE EFFECTS
  None

===========================================================================*/
//extern boolean hs_poll_gpio( void );

#if (TG==T_P)


/*===========================================================================

                        OBSOLETE: USE HS_SET_GLYPH

FUNCTION HS_SET_CHAR

DESCRIPTION
  Set the bitmap of a specified character.  The data format of a bitmap
  is a map of each row of the character, 5 bits wide (LSB justified) and
  7 rows tall.  For example:

    0x04, 0x0e, 0x1f, 0x03, 0x03, 0x18, 0x18 is

        ..X..
        .XXX.
        XXXXX
        ...XX
        ...XX
        XX...
        XX...

DEPENDENCIES
  None

RETURN VALUE
  None

SIDE EFFECTS
  By changing the bitmap of the character, any characters of that type
  currently being displayed will change to the new character.

===========================================================================*/
//extern void hs_set_char
//(
//  BYTE character,       /* Character to set the bitmap of         */
//  BYTE *bitmap_ptr      /* Pointer to 7 BYTEs defining the bitmap */
//);
#endif /* TG == T_P */

#endif /* HS_H */
