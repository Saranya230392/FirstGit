#ifndef _DLOAD_H
#define _DLOAD_H

//#include "comdef.h"

/* --------------------------------------------------------------------------
                        DOWNLOAD COMMANDS

  These are the download commands understood by this implementation
-----------------------------------------------------------------------------*/

#define         DLOAD_WRITE_F           1        /* Write a block of memory  */
#define         DLOAD_ERASE_F           4        /* Erase a block of memory  */
#define         DLOAD_GO_F              5        /* Jump to a memory address */
#define         DLOAD_NOOP_F            6        /* No-operation             */
#define         DLOAD_PARAM_F           7        /* Parameter request        */
#define         DLOAD_FLASH_WRITE_F     9        /* Parameter request        */
#define         DLOAD_FLASH_ERASE_F     10   /* Parameter request        */


/* --------------------------------------------------------------------------
                            NAK RESPONSE

 These are the download ack commands
-----------------------------------------------------------------------------*/

#define         DLOAD_NAK_F     3        /* Nak command */


/* --------------------------------------------------------------------------
                        PARAMETER RESPONSE

 These are the download ack commands
-----------------------------------------------------------------------------*/

#define         DLOAD_PARAM_RSP_F            /* Rsponse for parameter req cmd */

/* --------------------------------------------------------------------------
                           NAK REASON

 These are the download nak commands
-----------------------------------------------------------------------------*/

#define         BAD_CHECKSUM    1        /* Bad checksum  */
#define         INVALID_DEST    2        /* Invalid destination address */
#define         INVALID_LEN     3        /* Invalid length */
#define         EARLY_END       4        /* Unexpected end of packet */
#define         DATA_TOO_BIG    5        /* Data length too large for buffer */
#define         INVALID_CMD     6        /* Unknow/invalid command */

/* --------------------------------------------------------------------------
                          ACK RESPONSE

 These are the download nak commands
-----------------------------------------------------------------------------*/

#define         DLOAD_ACK_F     2        /* Ack command */



#define         TX_BUF_LEN       256
#define         RX_BUF_LEN      1024

#define         TARGET_RAM_START_ADDR      (dword)0x10000000
#define         TARGET_FLASH_START_ADDR    (dword)0x80000000
#define         RAM_RESIDENT_FILE          "2MAIN1.BIN"

#endif /* DLOAD_H */

