//  ��  ��  �� : CommToPhoneDefine.h
//  ���� �̷�  
//---------------------------------------------------------------------------------------
//  No / ��¥ / ������ / ���泻�� ������ ����մϴ�.
//---------------------------------------------------------------------------------------
//   1	030825	���ǿ�	 ���Դϴ�.
//   2  040108  sandman  MAX_PACKET_RETRY�� 10 --> 20 ���� ���� 
//---------------------------------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////////////////////
// CommToPhoneDefine.h
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMMTOPHONE_DEFINE_H__06BB9F6E_27A7_11D7_A602_0002B305BE1E__INCLUDED_)
#define AFX_COMMTOPHONE_DEFINE_H__06BB9F6E_27A7_11D7_A602_0002B305BE1E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//////////////////////////////////////////////////////////////////////

// Phone Type
#define	AMPS_ONLY		1
#define	CDMA_ONLY		2
#define	PCS_ONLY		3
#define	AMPS_CDMA		4
#define	AMPS_PCS		5
#define	CDMA_PCS		6
#define	AMPS_CDMA_PCS	7

#define	CRC_END				0xF088
#define	ASYNC_HDLC_FLAG		0x7E
#define ASYNC_HDLC_ESC		0x7D
#define ASYNC_HDLC_ESC_MASK	0x20

// For PA_R1 and PA_R0 control
#define RF_CAGC_PAR_00_V      0x0c // value to set PA R1,R0 = 0,0
#define RF_CAGC_PAR_01_V      0x08 // value to set PA R1,R0 = 0,1
#define RF_CAGC_PAR_10_V      0x04 // value to set PA R1,R0 = 1,0
#define RF_CAGC_PAR_11_V      0x00 // value to set PA R1,R0 = 1,1

#define RF_BAND_CDMA 0
#define RF_BAND_PCS  1
#define MAX_TRY      3

#define  MCC_ENTER_OFFLINE	2 // Enter digital in OFFLINE mode
#define  ACP_ENTER_OFFLINE	6 // Enter analog in OFFLINE mode

// Test���� ���� By PSH
#define ANALOG_MODE		0
#define AMPS_MODE		0
#define DIGITAL_MODE	1
#define CDMA_MODE		1
#define PCN_MODE		2
#define SLEEP_MODE		3
#define NO_RF_MODE		3

#define	DIGITAL_PREF	1
#define	CDMA_PREF		1
#define	DIGITAL_ONLY	2
#define	CDMA_ONLY		2
#define	ANALOG_PREF		3
#define	AMPS_PREF		3
#define	ANALOG_ONLY		4

#define LOG_FING_MASK  ( 1L << LOG_FING_C  )
#define LOG_SRCH2_MASK ( 1L << LOG_SRCH2_C )
#define LOG_AGC_MASK ( 1L << LOG_AGC_PCTL_C )
#define SRCH_PWR_WAIT   -1

// Phone Control Error Code
#define	ERROR_PHONE_PACKET			3001
#define	ERROR_PHONE_RESPONSE_TYPE	3002
#define	ERROR_PHONE_NV_STAT			3003

#define PAR0_OFF	100
#define PAR0_ON		99

// Constants for Min Conversion Routines
#define PREFIX_MASK		0x00FFC000
#define PREFIX_SHIFT	14
#define THOUSANDS_MASK	0x00003C00
#define THOUSANDS_SHIFT	10
#define LAST_3_MASK		0x000003FF
#define LAST_3_SHIFT	0
#define CAL_LNA_TEST        77
#define CAL_HDET            20
#define HDET_HIGH				10
#define HDET_LOW				11
#define VBATT_CAL				12 //sandman

#define CMD_MODE_RESET			0
#define CMD_MODE_OFFLINE		1
#define CMD_MODE_OFFLINE_A		2
#define CMD_BTN_MAXPOWER_ON		3
#define CMD_CDMA_CHAN			4
#define CMD_CDMA_TX_PWR			5	
#define CMD_BTN_BAND_SEL		6
#define CMD_DIP_SWITCH			7
#define CMD_SET_LNA				8
#define CMD_RX_AGC				9
#define CMD_RX_COMP				10
#define CMD_TX_AGC				11
#define CMD_TX_COMP				12
#define CMD_PA_R0				13		
#define CMD_PA_R1				14
#define CMD_AUDIO				15		
#define CMD_IRDA				16

// IM2 Calibration 
typedef enum 
{
   PHONE_MODE_CDMA		= 0,
   PHONE_MODE_FM		= 1,
   PHONE_MODE_GPS_SINAD	= 4,
   PHONE_MODE_CDMA_800	= 5,
   PHONE_MODE_CDMA_1900	= 6,
   PHONE_MODE_CDMA_1800	= 8,
   PHONE_MODE_JCDMA		=14,
   PHONE_MODE_MAX
} mode_id_type;

typedef enum {
   PA_R0,
   PA_R1,
   PA_R2,
   PA_R3,
   PA_RMAX 
} pa_range_type;

typedef enum {
	US_PCS_BAND,
	US_CELLULAR_BAND
} digital_band_type;

typedef struct {
   unsigned short  id;
   signed short val;
} test_id_val_type;

typedef struct {
   byte byte0;
   byte byte1;
   byte byte2;
} test_byte_type;

#define	LG_IM2_SET_READY	0x52
#define	LG_IM2_GET_RXAGC	0x53
#define	LG_GET_IM2_VALUE	0x54
#define DVGA_LNA_R0			0	// LNA_HIGH
#define DVGA_LNA_R1			1	// LNA_MID
#define DVGA_LNA_R2			2	// LNA_LOW
#define DVGA_LNA_R3			3	// LNA_OFF

typedef enum {
	DIAG_SUBSYS_OEM 	 = 0,
	DIAG_SUBSYS_ZREX	 = 1,
	DIAG_SUBSYS_SD		 = 2,
	DIAG_SUBSYS_BT		 = 3,
	DIAG_SUBSYS_WCDMA  = 4,
	DIAG_SUBSYS_HDR 	 = 5,
	DIAG_SUBSYS_DIABLO = 6,
	DIAG_SUBSYS_TREX	 = 7,
	DIAG_SUBSYS_GSM 	 = 8,
	DIAG_SUBSYS_UMTS	 = 9,
	DIAG_SUBSYS_HWTC	 = 10,
	DIAG_SUBSYS_FTM 	 = 11,
	DIAG_SUBSYS_REX 	 = 12,
	DIAG_SUBSYS_GPS 	 = 13,
	DIAG_SUBSYS_WMS 	 = 14,
	DIAG_SUBSYS_CM		 = 15,
	DIAG_SUBSYS_HS		 = 16,
	DIAG_SUBSYS_AUDIO_SETTINGS	 = 17,	 /* replacing DIAG_SUBSYS_APPS */
	DIAG_SUBSYS_DIAG_SERV = 18,
	DIAG_SUBSYS_FS				= 19,
	DIAG_SUBSYS_PORT_MAP_SETTINGS  = 20,
	DIAG_SUBSYS_MEDIAPLAYER 			 = 21,
	DIAG_SUBSYS_QCAMERA 					 = 22,
	DIAG_SUBSYS_MOBIMON 					 = 23,
	DIAG_SUBSYS_GUNIMON 					 = 24,
	DIAG_SUBSYS_LSM 							 = 25,
	DIAG_SUBSYS_QCAMCORDER				 = 26,
	DIAG_SUBSYS_MUX1X 						 = 27,
	DIAG_SUBSYS_DATA1X						 = 28,
	DIAG_SUBSYS_SRCH1X						 = 29,
	DIAG_SUBSYS_CALLP1X 					 = 30,

	DIAG_SUBSYS_LAST
} diagpkt_subsys_cmd_enum_type;


#define CM_STATE_INFO					0
#define HDR_STATE						8

#endif // !defined(AFX_COMMTOPHONE_DEFINE_H__06BB9F6E_27A7_11D7_A602_0002B305BE1E__INCLUDED_)
