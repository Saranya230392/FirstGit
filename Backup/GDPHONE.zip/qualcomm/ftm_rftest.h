/*===========================================================================

                      FTM RF Test Header File

DESCRIPTION
  This header file contains all the definitions necessary in order to
  interface with the FTM RF Unit.  

Copyright (c) 1999--2002 by QUALCOMM, Inc.  All Rights Reserved.
===========================================================================*/


/*===========================================================================

                      EDIT HISTORY FOR FILE

$Header: //depot/asic/msm6100/services/ftm/ftm_rftest.h#1 $


when       who     what, where, why
--------   ---     ----------------------------------------------------------
04/02/03   LeeKH   FTM Pakcet���θ� Cal�� �����Ҽ� �ֵ��� ����
06/10/02   rjr     add fm IQ mismatch
03/21/02   rjr	   cleaned up enum definitions
02/21/02   rjr	   Intial revision.
===========================================================================*/


/*--------------------------------------------------------------------------
                            RF TEST COMMAND ENUM TYPE
--------------------------------------------------------------------------*/

/* these are the command codes that are sent from the diag task to the
   ftm_mcc task as part of the overall command chain for executing RF FTM 
   user commands */
  

typedef enum {

   FTM_SET_PDM=0,              
   FTM_SET_PDM_CLOSE=1,        
   FTM_SET_TX_ON=2,            
   FTM_SET_TX_OFF=3,           
   FTM_SET_MODE=7,             
   FTM_SET_CHAN=8,             
   FTM_GET_RSSI,             
   FTM_GET_SYNTH_STATE=16,      
   FTM_FM_TX_ST=37,            
   FTM_SET_CDMA_CW_WAVEFORM=50,     /*50 */
   FTM_GET_CAGC_RX_AGC=53,
   FTM_SET_PA_RANGE=54,
   FTM_SET_LNA_RANGE=58,
   FTM_GET_ADC_VAL=59,         /* 59 */
   FTM_SET_LNA_OFFSET=81,       /* 81*/
   FTM_SET_DVGA_OFFSET=111,		  
   FTM_GET_CDMA_IM2=114,             /* 114 */
   FTM_SET_FREQUENCY_SENSE_GAIN=115, /* 115 */
   FTM_TX_SWEEP_CAL=116,			  /* 116 */
   FTM_GET_DVGA_OFFSET=117,
   FTM_GET_LNA_OFFSET=118,
   FTM_GET_HDET=119,
   FTM_GET_FM_IQ=120,
   FTM_LNA_RANGE_OVERRIDE=121,
   TEST_MAX                   
} test_id_type;

 

typedef enum {
   PDM_TX_AGC_ADJ = 2,
   PDM_TRK_LO_ADJ = 4,
   PDM_MAX_NUM
} pdm_id_type;


// ȣȯ���� ���Ͽ� Rf.c�� ���� ���ǵǾ� �ִ� ��ũ�ΰ��� �״�� �����
// ��, TEST_LGF_PA_R1O_CONTROL�� TEST_CAL_LGF_FREQ_TRK�� �ߺ��Ǿ� 6���� ����
// ���� FTM �������� ��ü ������ �� ���� �׸��� '//*'�� ���� ǥ����

typedef enum {
	TEST_LGF_CAL_CDMA = 0,						// *
	TEST_LGF_CAL_FM = 1,						// *
	TEST_LGF_CAL_FSG = 2,						// *
	TEST_LGF_TX_GAIN_COMP = 3,
	TEST_LGF_RX_GAIN_COMP = 4,
	TEST_LGF_CAL_FM_FREQ_TRK = 5,
	TEST_LGF_PA_R10_CONTROL = 6,				// *
	TEST_LGF_CHANGE_CURRENT_BAND = 10,			// *
	TEST_LGF_RFT_WRITE = 11,
	TEST_LGF_RFT_READ = 12,
	TEST_LGF_CHANGE_AMPS_BAND = 13,				// *
	TEST_LGF_MEASURE_RSSI = 14,
	TEST_LGF_READ_PWR_CTL_LOG = 19,
	TEST_LGF_READ_PWR_CTL1_LOG = 20,
	TEST_LGF_READ_PWR_CTL2_LOG = 21,
	TEST_LGF_READ_PWR_CTL3_LOG = 22,
	TEST_LGF_CAL_LOAD_CAGC_LINEARIZERS = 66,
	TEST_LGF_HDET_CAL = 79,
	TEST_LGF_MAX_POWER_ON = 80,
	TEST_LGF_MAX_POWER_OFF = 81,
	TEST_LGF_IM2_SET_READY = 82,
	TEST_LGF_IM2_GET_RXAGC = 83,
	TEST_LGF_FM_IQ_SET_READY = 85,
	TEST_LGF_IPC_LIKE_RX_SEARCH = 88,
	TEST_LGF_CAL_GET_CDMA_RX_AGC_VALUE = 91,	// *
	TEST_LGF_CAL_GET_FM_RX_AGC_VALUE = 92,		// *
	TEST_LGF_LOAD_CAL_DATA = 96,
	TEST_LGF_UPDATE_LIM_VS_FREQ = 97,
	TEST_LGF_NVINACTIVE_ENABLE = 99,
	TEST_LGF_NVINACTIVE_DISABLE = 100,

	// 2005.08.26 ssmin For skyworks chip IM2 ����
	TEST_LGF_SKY74100_SET_REG = 101,
	TEST_LGF_SKY74068_SET_REG = 102,
	
	TEST_LGF_RX_CAL = 122,
	TEST_LGF_TX_CAL = 123,
	TEST_LGF_LIM_VS_FREQ_CAL = 120,
	TEST_LGF_LIM_VS_FREQ_READ = 253,
	TEST_LGF_LIM_VS_FREQ_WRITE = 254,
	TEST_LGF_EEPROM_FULL_ERASE = 255,
	TEST_LGF_CAL_GET_FTM_MODE =256,
	TEST_LGF_MAX
} test_lgf_id_type;

//2003.12.09 sandman : toolsdiag_lgf_id_type �߰�
typedef enum {
  TOOLSDIAG_LGF_READ_PWR_CTL0_LOG = 19,
  TOOLSDIAG_LGF_READ_PWR_CTL1_LOG = 20,
  TOOLSDIAG_LGF_READ_PWR_CTL2_LOG = 21,
  TOOLSDIAG_LGF_READ_PWR_CTL3_LOG = 22,
  TOOLSDIAG_LGF_CAL_GET_FTM_MODE = 256
} toolsdiag_lgf_id_type;


//sandman_hdet
typedef enum 
{ 
    ADC_VBATT,      // 0
    ADC_THERM,      // 1
    ADC_HDET_CELL,  // 2
    ADC_HDET_PCS=ADC_HDET_CELL,  //4//2
    ADC_HDET =ADC_HDET_CELL,           //
    ADC_MOD_KEY=3, // 3 T2������ ���
    ADC_SIG_LIST_SIZE=5, //6
} adc_sig_list_type;
