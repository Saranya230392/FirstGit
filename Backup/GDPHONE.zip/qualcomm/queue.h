#ifndef _QUEUES_H
#define _QUEUES_H
/*===========================================================================

            Q U E U E    S E R V I C E S    H E A D E R    F I L E

DESCRIPTION
 This file contains types and declarations associated with the Queue
 Services.

Copyright (c) 1990,1991,1992 by QUALCOMM Incorporated.  All Rights Reserved.
===========================================================================*/


/*===========================================================================

                      EDIT HISTORY FOR FILE

This section contains comments describing changes made to this file.
Notice that changes are listed in reverse chronological order.

$Header:   Z:/CMtest/CMtest(3.61)/WInclude/QUEUE.H-arc   1.0   Feb 14 2000 15:35:28   hyun  $
   
when       who     what, where, why
--------   ---     ----------------------------------------------------------
04/22/92   ip      Initial porting of file from Brassboard to DMSS.
02/20/92   arh     Added new function q_check.

===========================================================================*/


/*===========================================================================

                        DATA DECLARATIONS

===========================================================================*/

/*---------------------------------------------------------------------------
                       QUEUE LINK STRUCTURE

The following link structure is really the heart of the Queue Services. It is
used as a link field with variables which allows them to be moved on and off
queues. It is also used in the definition of queues themselves.

Do NOT directly access the fields of a link! Only the Queue Services should
do this.
---------------------------------------------------------------------------*/

typedef struct q_link_struct
{
  struct q_link_struct  *next_ptr;
    /* Ptr to next link in list. If NULL, there is no next link. */

  struct q_link_struct  *prev_ptr; 
    /* Ptr to prev link in list. If NULL, there is no prev link. */

  void                  *self_ptr;
    /* Ptr to item which contains this link. */

  struct q_struct       *q_ptr;
    /* Ptr to the queue on which this item is enqueued. NULL if the
       item is not on a queue. While not strictly necessary, this field
       is helpful for debugging.*/
}
q_link_type;


/*--------------------------------------------------------------------------
                          QUEUE STRUCTURE

The following structure format is used by the Queue Services to represent
a queue.

Do NOT access the fields of a queue directly. Only the Queue Services should
do this.
--------------------------------------------------------------------------*/

typedef struct q_struct
{
  q_link_type  link;
    /* Used for linking items into queue. */

  WORD         cnt;
    /* Keeps track of number of items enqueued. Though not necessary, having
       this field is tremendously helpful for debugging. */
}
q_type;


/*===========================================================================

                      FUNCTION DECLARATIONS

===========================================================================*/

//extern q_type      *q_init ( q_type *q_ptr );
//extern q_link_type *q_link ( void *item_ptr, q_link_type *link_ptr );

//extern void  q_put  ( q_type *q_ptr, q_link_type *link_ptr );
//extern void  *q_get ( q_type *q_ptr );

//extern WORD  q_cnt  ( q_type *q_ptr );

//extern void  *q_check (q_type  *q_ptr);
//extern void  *q_next  ( q_type *q_ptr, q_link_type *link_ptr );

//extern void q_insert  ( q_link_type *q_insert_ptr, q_link_type *q_item_ptr );
//extern void q_delete  ( q_link_type *q_delete_ptr );

#endif /* QUEUES_H */

