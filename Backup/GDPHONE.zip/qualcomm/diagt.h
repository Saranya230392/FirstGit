#ifndef _DIAGT_H
#define _DIAGT_H
/*===========================================================================

          D I A G N O S T I C   D I R E C T E D   T E S T   
  
                        H E A D E R   F I L E


DESCRIPTION

  This header file defines the constants and structures used by the
  diag unit and the diagnostic monitor to exchange commands and information
  regarding directed tests.  A directed test is one which is commanded by
  the diagnostic monitor.

Copyright (c) 1992,1993,1994 by QUALCOMM, Incorporated. All Rights Reserved.

===========================================================================*/


/*===========================================================================

                        EDIT HISTORY FOR FILE

$Header:   Z:/CMtest/CMtest(3.61)/WInclude/DIAGT.H-arc   1.0   Feb 14 2000 15:35:20   hyun  $

when       who   what, where, why
--------   ---   ------------------------------------------------------------
11/01/94   gb    Sector Lock test functionality added.
05/28/94   jmk   Added field & struct to tmob for running numbered test from DM.
11/03/92   twp   Vocoder PCM & PKT loopback,  analog IS-55 tests
09/04/92   twp   Initial version.

===========================================================================*/


/*===========================================================================

                            INCLUDE FILES

===========================================================================*/
//#include "comdef.h"


/*===========================================================================

                             DECLARATIONS

===========================================================================*/

/* Directed test commands */

//typedef enum {
#define DT_CARRIER_ON_F     0        /* Carrier on command                       */
#define DT_CARRIER_OFF_F    1        /* Carrier off command                      */
#define DT_LOAD_SYNTH_F     2        /* Load Synthesizer command                 */
#define DT_SET_ATTN_F       3        /* Set Attenuation command                  */
#define DT_RXMUTE_F         4        /* Mute the receiver audio signal           */
#define DT_RXUNMUTE_F       5        /* Unmute the receier audio signal          */
#define DT_TXMUTE_F         6        /* Mute the transmit audio signal           */
#define DT_TXUNMUTE_F       7        /* Unmute the transmit audio signal         */
#define DT_ST_ON_F          8        /* Transmit continuous Signalling Tone      */
#define DT_ST_OFF_F         9        /* Stop transmission of Signalling Tone     */
#define DT_SEND_NAM_F       10        /* Send the specified NAM                   */
#define DT_SWITCH_NAM_F     11        /* Change to the specified NAM              */
#define DT_SEND_MIN_F       12        /* Send the specified MIN                   */
#define DT_VERSION_F        13        /* Send software version                    */
#define DT_SEND_ESN_F       14        /* Send the esn                             */
#define DT_RCVS1_F          15        /* Count msgs on Analog Control Channel     */
#define DT_WSTS_F           16        /* Count WORD syncs on Analog Control 
                                 Channel                                  */
#define DT_SAT_ON_F         17        /* Enable transmission of SAT               */
#define DT_SAT_OFF_F        18        /* Disable transmission of SAT              */
#define DT_TERMINATE_F      19        /* Stop RCVS1 or WSTS and report counts     */
#define DT_CDATA_F          20        /* Transmit continuous 5-WORD Reverse 
                                 Control Channel messages                 */
#define DT_DTMF_ON_F        21        /* Activate the DTMF generator with 
                                 specified tones                          */
#define DT_DTMF_OFF_F       22        /* Stop the DTMF                            */
#define DT_COMPANDER_ON_F   23        /* Enable the compander                     */
#define DT_COMPANDER_OFF_F  24        /* Disable the compander                    */
#define DT_RSSI_F           25        /* Return the current RSSI measurement      */
#define DT_MAX_F            26        /* Last and invalid directed test choice    */
//} diag_test_enum_type;
typedef WORD diag_test_enum_type;

//////////4.03-1 OJS 2002.3.25///////////
//OJS SP3100
#define TX_POWER_ON_I       0
#define LNA_ON_I			1
#define CHANNEL_I			2
#define RX_AGC_VALUE_I		3
#define GET_RX_AGC_PDM_I	4
#define SET_RX_AGC_PDM_I	5
#define TX_AGC_VALUE_I		6
#define GET_TX_AGC_PDM_I	7
#define SET_TX_AGC_PDM_I	8
#define GET_TX_HDET_VALUE_I	9      
#define GET_THERM_VALUE_I	10
#define GET_VBATT_VALUE_I	11  

#define SET_PAR_R0_HIGH		12	
#define SET_PAR_R0_LOW		13
//#endif

#define SET_LNA_HIGH		14
#define SET_ABSEL_HIGH		15

// For LNA_RANGE1 Control
#define LNA1_ON_I			16
// For PA R1,R0 Control
#define PA_R10_ON_I			17  
// For AB Sel Control
#define AB_SEL_I			18  
//#ifdef FEATURE_RF_CAL_LIM_VS_FREQ
#define SET_PWR_LIMIT		19
#define GET_THERMISISTOR	20
#define SET_MAX_TX_GAIN_ADJ	21
// LJK 01/05/11 Begin
#define SET_DIPSWITCH		22
#define GET_LIMVSTEMP_NOW	23
#define GET_PWR_LIMIT		24
// LJK 01/05/11 End
//#endif
// LJK 01/05/02 End
typedef WORD diag_cal_test_enum_type;
///////////////////////////////////////


/*-------------------------------------------------------------------------

                    Directed Test parameter types

--------------------------------------------------------------------------*/

/* Parameters for the set_attn directed test */

typedef struct {
  BYTE  attn;
} set_attn_parm_type;

/* Parameters for the switch_nam directed test */

typedef struct {
  BYTE  nam;
} nam_type;

/* Parameters for the send_min directed test */

typedef struct {
  BYTE  nam;
  BYTE  min;
} send_min_parm_type; 

/* Parameters for the sat directed test */

typedef struct {
  BYTE  sat;
} sat_parm_type;

/* Parameters for the CDATA directed test */

typedef struct {
  BYTE  cdata[6];
} cdata_parm_type;

/* Parameters for the dtmf directed test */

typedef struct {
  BYTE  dtmf;
} dtmf_parm_type;

/* Union of the directed test parameter types */
typedef union {
  WORD                    chan;       /* Channel for load-synth cmd  */
  set_attn_parm_type      sa;         /* Attn level for set-attn cmd */
  nam_type                nam;
  send_min_parm_type      sm;
  sat_parm_type           sat;
  cdata_parm_type         cdata;
  dtmf_parm_type          dtmf;
} diag_test_parm_type;


/*--------------------------------------------------------------------------

                     Directed Test Results Types

--------------------------------------------------------------------------*/

/* RCVS1 response (requested with a terminate command) */

typedef struct {
  BYTE  num_uncorr;
  BYTE  num_corr;
} rcvs1_type;

/* WSTS response (requested with a terminate command ) */

typedef struct {
  WORD  num_syncs;
} wsts_type;

/* RSSI response */

/* Union of directed test response types */

typedef union {
  rcvs1_type        rcvs1;              /* Response from RCVS1 command */
  wsts_type         wsts;               /* Response from WSTS command */
  BYTE              rssi;               /* Response from RSSI command */
} diag_test_results_type;

///////////////////////////4.03-1 OJS 2002.3.25////////////////////////////
//OJS SP3100
//-------------------------------------------------------------------------
//
//                    Directed Test parameter types
//
//--------------------------------------------------------------------------

typedef struct {
  BYTE   tx_power_on;
} power_flag_type;

typedef struct {
  BYTE   lna_on;
} lna_flag_type;

typedef struct {
  WORD      cdma_channel;
} channel_data_type;

typedef union {
  WORD    rx_agc_value;
  WORD    rx_agc_pdm_value;
  WORD    rx_imd_pdm_value;
} rx_control_data_type;

typedef union {
  WORD    tx_agc_value;
  WORD    tx_agc_pdm_value;
  // For Data Module
  WORD    open_loop_value;
  WORD    tx_gain_adj_value;
} tx_control_data_type;

typedef struct {
  WORD    adc_value;
} adc_data_type;

typedef struct {
  BYTE tx_pdm2_on;
} tx_pdm2_type; 

// KYLEE 01/02/28 Begin
// For PA_R0,R1 Control
typedef struct {
  BYTE pa_r10_on;
} pa_r10_flag_type;
// KYLEE 01/02/28 End

// KYLEE 01/02/28 Begin
// For LNA_RANGE1 Control
typedef struct {
  BYTE   lna1_on;
} lna1_flag_type; 
// KYLEE 01/02/28 End

// KYLEE 01/02/28 Begin
// For AB Sel Control
typedef struct {
  BYTE   ab_sel_on;
} ab_sel_flag_type; 
// KYLEE 01/02/28 End

typedef struct {
    WORD   lna_gain;       // 0 ~ 511
} lna_gain_type;

typedef struct {
	USHORT pdm_value;
}pdm_data_type;

typedef struct {
	USHORT agc_value;
}agc_data_type;

typedef struct {
	USHORT tx_hdet_value;
}tx_hdet_data_type;

typedef struct {
	BYTE   pa_r10_value;         // 0 ~ 3(0 : R1/R0 off, 1 : R1 off/R0 on), ...
} pa_r10_type;

// Parameters for the dtmf directed test 
// Union of the directed Calibration test parameter types 
typedef union {
  power_flag_type       power_flag;
  lna_flag_type         lna_flag;
  channel_data_type     channel_data;
  rx_control_data_type  rx_control_data;
  tx_control_data_type  tx_control_data;
  adc_data_type         adc_data;
  tx_pdm2_type          tx_pdm2_flag;

  // For LNA_RANGE1 Control
  lna1_flag_type         lna1_flag;
  // For PA_R0,R1 Control
  pa_r10_flag_type	pa_r10_flag;  
  // For AB Sel Control
  ab_sel_flag_type	ab_sel_flag;  
//  #ifdef FEATURE_RF_CAL_LIM_VS_FREQ
  __int16				pwr_limit;
//  #endif
} diag_cal_test_data_type;


typedef union {
  power_flag_type       power_flag;
  lna_flag_type         lna_flag;
  channel_data_type     channel_data;
  rx_control_data_type  rx_control_data;
  tx_control_data_type  tx_control_data;
  adc_data_type         adc_data;
  tx_pdm2_type          tx_pdm2_flag;

  // For LNA_RANGE1 Control
  lna1_flag_type         lna1_flag;
  // For PA_R0,R1 Control
  pa_r10_flag_type	pa_r10_flag;  
  // For AB Sel Control
  ab_sel_flag_type	ab_sel_flag;  
//  #ifdef FEATURE_RF_CAL_LIM_VS_FREQ
  WORD				pwr_limit;
  WORD              thermisistor_now;
  // LJK 01/05/11 Begin
  WORD              limvstemp_now;
  WORD              current_pwr_limit;
} diag_cal_test_results_type;
//SP3100 End
//////////////////////////////////////////////////////////////////////////////
/*===========================================================================

   Test Mobile Commands

===========================================================================*/

#pragma pack(1)  /* Notice: diagnostic monitor packets are BYTE packed. */

//typedef enum {
#define TMOB_TCA_F         0         /* Traffic Channel Assignment */
#define TMOB_TC_MSG_F      1         /* Traffic Channel Message */
#define TMOB_AC_MSG_F      2         /* Access Channel Message */
#define TMOB_SRCH_PARM_F   3 
#define TMOB_PC_ASET_F     4
#define TMOB_PC_NSET_F     5
#define TMOB_TC_ASET_F     6   
#define TMOB_TC_NSET_F     7
#define TMOB_MARKOV_F      8 
#define TMOB_TEST_F        9         /* factory test */
#define TMOB_SECT_LOCK_F   10
#define TMOB_MAX_F         11 
//} tmob_cmd_code_type;
typedef WORD tmob_cmd_code_type;

typedef struct {
   tmob_cmd_code_type   tmob_cmd_id;
   WORD                 test_id;           /* ID of test to run */
} tmob_test_type;

typedef struct {
   tmob_cmd_code_type   tmob_cmd_id;
   BYTE                 tca_code_chan;
   DWORD                tca_long_code;
   WORD                 tca_so;
   WORD                 tca_freq;
   BYTE                 tca_frame_stagger;
   BYTE                 tca_mar_rate;
} tmob_tca_type;


typedef struct {
   tmob_cmd_code_type   tmob_cmd_id;

  BYTE          len;

#define              TEST_R_TC_MSG_CNT  (1184/8)
  BYTE          msg[ TEST_R_TC_MSG_CNT ];
    /* Actual reverse link traffic channel message bits. */
} tmob_tc_msg_type;


typedef struct {
   tmob_cmd_code_type   tmob_cmd_id;

  BYTE          len;              /* Number of BYTEs in message */
  boolean       req;              /* True: access request, False: response */
  BYTE          seq_num;          /* Max number of access probe sequences */

  /* set the next 3 parameters all to zero to get a long code mask
  ** of ZERO which implies no scrambling.
  */
  BYTE          pagech;           /* Current Paging Channel */
  WORD          base_id;          /* Base station identification */
  WORD          pilot_pn;         /* Pilot PN sequence offset index */

  BYTE          pam_sz;           /* Access Channel preamble length */
  BYTE          max_cap_sz;       /* Max Access Channel msg capsule size */
  BYTE          bkoff;            /* Probe sequence backoff range */
  BYTE          probe_bkoff;      /* Probe backoff range */
  BYTE          acc_tmo;          /* Acknowledgement timeout */
  BYTE          init_pwr;         /* Initial power offset for access */
  BYTE          pwr_step;         /* Power increment */
  BYTE          num_step;         /* Number of access probes */
  BYTE          acc_chan;         /* Number of access channels */
  WORD          rn;      /* Random number of chips backoff - ignored now */
  DWORD         p;                /* Persistence probability */

#define              TEST_AC_MSG_CNT  (1184/8)
  BYTE          msg [TEST_AC_MSG_CNT];
                      /* Access Channel message to send */
} tmob_ac_msg_type;


/*--------------------------------------------------------------------------
                   CHANGE PILOT SEARCH PARAMETERS COMMAND

This command provides the Searcher Task with search parameters from
base station messages.
--------------------------------------------------------------------------*/

typedef struct
{
   tmob_cmd_code_type   tmob_cmd_id;
   /* Common command header */

  BYTE               win_a;
   /* Active set search window size index    */
  BYTE               win_n;
   /* Neighbor set search window size index  */
  BYTE               win_r;
   /* Remaining set search window size index */

  BYTE               t_add;
   /* Threshold of energy at which a pilot moves up to the Candidate Set */

  BYTE               t_drop;
   /* Threshold of energy at which a pilot should be dropped from the
      Active Set or Candidate Set */

  BYTE               t_comp;
   /* Margin by which a pilot must exceed an Active Set pilot to trigger a
      new Power Measurement Report */

  BYTE               t_tdrop;
   /* Index of the duration for which a pilot must be below t_drop before
      being dropped or reported */

  BYTE               nghbr_max_age;
   /* Maximum "age" for a pilot to remain in the Neighbor Set */

} tmob_srch_parm_type;


/*--------------------------------------------------------------------------
               PAGING CHANNEL ACTIVE SET UPDATE COMMAND

This command tells the searcher to perform an idle handoff from one
Paging Channel pilot to another.
--------------------------------------------------------------------------*/

typedef struct
{
   tmob_cmd_code_type   tmob_cmd_id;
   /* Common command header */

  WORD               aset_pilot;
    /* The pilot PN index of the new Active Set pilot */

  WORD               aset_walsh;
    /* The walsh channel to be used with the new paging channel */

  QWORD              pn_mask;
    /* PN long code mask to be used on the new paging channel */

  WORD               cdma_freq;
    /* CDMA Channel number of the new paging channel */

} tmob_pc_aset_type;


/*--------------------------------------------------------------------------
                      NEIGHBOR SET UPDATE COMMAND

This command updates the Neighbor Set.

Note: this command format is used for both paging and traffic channel
variants.  
--------------------------------------------------------------------------*/

typedef struct
{
   tmob_cmd_code_type   tmob_cmd_id;
   /* Common command header */

  BYTE               pilot_inc;
   /* Spacing of potential pilot offset in use in this system.  The
      remaining set consists of all pilot offsets which are multiples
      of this value (but are not in another set). */

  WORD               nset_cnt;  
    /* Number of neighbor set members */

  struct
  {
    WORD  pilot;
  }                  nset[ 20 ];
    /* Pilot offset indices for neighbor set members */

} tmob_nset_type;


/*--------------------------------------------------------------------------
              TRAFFIC CHANNEL ACTIVE SET UPDATE COMMAND

This command replaces the Active Set on the traffic channel.
--------------------------------------------------------------------------*/

typedef struct
{
  tmob_cmd_code_type   tmob_cmd_id;
  /* Common command header */

  WORD               cdma_freq;
   /* CDMA Channel number */

  BYTE               t_add;
   /* Threshold of energy at which a pilot moves up to the Candidate Set */

  BYTE               t_drop;
   /* Threshold of energy at which a pilot should be dropped from the
      Active Set or Candidate Set */

  BYTE               t_comp;
   /* Margin by which a pilot must exceed an Active Set pilot to trigger a
      new Power Measurement Report */

  BYTE               t_tdrop;
   /* Index of the duration for which a pilot must be below t_drop before
      being dropped or reported */

  WORD               aset_cnt;
   /* Number of Active Set members */

   /* For each member of the new Active Set: */
  struct
  {
    WORD  pilot;
      /* Pilot PN index of this Active Set member */

    WORD  walsh;
      /* Walsh channel to be used on the traffic channel with the pilot */

    BYTE  pwr_comb_ind;
      /* Flag: nonzero if the power control subchannel on this pilot
               contains the same symbols as that on the previous pilot. */

  }      aset[ 6 ];
    /* Pilot offset indices and walsh channels for active set members */

} tmob_tc_aset_type;


/*===========================================================================

           SET MARKOV TABLE BINARY PROBABILITIES

Probabilities are listed as values which ran# must be less than to be
valid. Probs are listed eighth, eighth+quarter, eighth+quarter+half.
If ran# is greater or equal than last value then transition to full.

Sn = State at frame n.  Rn = Rate at frame n. 
State is table 1st dim index.     Transition is index to table 2nd dim.

Sn+1 = 4 * ( Sn mod 4 ) + ( 3 - Trans ).
Rn+1 = 4 - ( Sn+1 mod 4 ).

===========================================================================*/

typedef struct
{
  tmob_cmd_code_type   tmob_cmd_id;
  /* Common command header */

  WORD Markov_prob [16] [3];          /* Variable Rate Probs */

} tmob_markov_type;

/*===========================================================================

PACKET   tmob_sect_lock_type

ID       TMOB_SECT_LOCK_F

PURPOSE  Sent by DM to lock the Mobile into a specified sector

===========================================================================*/
typedef struct
{
  tmob_cmd_code_type   tmob_cmd_id;               /* Common command header */
  WORD                 pn_offset;
  WORD                 cdma_chan;
  BYTE                 pag_chan;
  BYTE                 acc_chan;
} tmob_sect_lock_type;

typedef union {
   tmob_cmd_code_type   tmob_cmd_id;
   tmob_test_type       test;         /* Run a special test */
   tmob_tca_type        tca;          /* Traffic Channel Assignment */
   tmob_tc_msg_type     tc_msg;       /* Traffic Channel Message */
   tmob_ac_msg_type     ac_msg;       /* Access Channel Message */
   tmob_srch_parm_type  srch_parm;    /* Srch parameters */
   tmob_pc_aset_type    pc_aset;      /* paging active set member */
   tmob_nset_type       nset;         /* page/traffic neighbors */
   tmob_tc_aset_type    tc_aset;      /* traffic active set */
   tmob_markov_type     markov;       /* update Markov table */
   tmob_sect_lock_type  sect_lock;    /* Lock to a specified Sector */
} tmob_cmd_type;


#endif
