/*****************************************************************************
              The LGICed format define for HHP of ver0083

 HISTORY
    When             Who             What
  ------------------------------------------------------------------
    3/3/95           CBK             Change QUALCOMM LCD to HLM8484



******************************************************************************/

//#include"nv.h"
//#include"comdef.h"

#define         T_G                     9
#define         TG                      T_G

//#define         RING_TEST_I             NV_MAX_I


#define         HLM8484                 0x00   /* LGIC used LCD for 1'st HHP (3Lines, 10Char.s) */
#define         QUALCOMM                0x01   /* Qualcomm LCD for 1'st HHP (4Lines, 10Char.s, 1Icon) */
#define         HITACHI                 0x02   /* Normal LCD for test board */
#define         HLM8767                 0x03   /* Graphic type LCD for 2'nd HHP(4Lines, 12Char.s, 2Icons) */

#define         LGIC                    0x04

#define         MSM2P                   0x05   /* 208 pin */
#define         MSM2                    0x06   /* 176 pin */
#define         MSM1                    0x07   /* 144 pin */
#define         INT                     0x08   /* Internal clock source for rex_tick, (cpu_clock_cycle/8)  */
#define         EXT                     0x09   /* External clock source for rex_tick, (timer0 input ) */
#define         SED1230                 0x0A
#define         UMA1018M                0x0B
#define         LMX2332A                0x0C
#define         HLM8767C                0x0D   /* Character type LCD for 2'nd HHP(4Lines, 12Char.s, 2Icons) */

#define         HW_LCD                  HLM8767C
#define         RINGER                  LGIC
#define         IS_MSM                  MSM2P

#define         MSG2LCD                 OFF     /* Display file name and line number on LCD */

#define         REX_CLK                 INT     /* Internal clock */

#define         MSM1_TO_MSM2            TRUE    /* Copy msm1 variable to gemini */

#define         PLL_IC                  LMX2332A /* QUALCOMM = UMA1018M, ALPS = LMX2332A */

#define         KEYPAD                  LGIC     /* LGICed keypad */

/* end of LGIC.H */
