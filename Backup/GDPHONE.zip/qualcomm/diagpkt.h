#ifndef _DIAGPKT_H
#define _DIAGPKT_H

#pragma pack(1)
/*===========================================================================

                     INCLUDE FILES FOR MODULE

===========================================================================*/
#include  "2dload.h"
#include  "CommToPhoneDefine.h"

/* <EJECT> */
/*===========================================================================

                          PACKET DEFINITONS

===========================================================================*/

/* Notice: diagnostic monitor packets are BYTE packed. */

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/*   Communication from the Diagnostic Monitor to the Mobile               */
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/

/* DIAG_DIAGVER
   diag version, used to ensure compatibility of the DM and the DMSS.
   0001   Original
   0002   Changes to status packet and verno packet. Removed verstr packet
   0003   for release to factory. Sends RF mode in status packet
   0004   Adds release directory to verno packet and dipswitch packets
   0005   Many changes in DM.
   0006   Added Vocoder PCM and PKT loopback, and Analog IS-55 tests
   0007   New FER data in tagraph packet
*/

// ��� �߰� //////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////
// BIN Revision Read //

typedef struct {
	BYTE		cmd_code;
	WORD		gen_word;
} gen_byte_and_word_type;
//-[WCDMA]

//SHX2 2003.1.13 By Joe
typedef struct
{
  byte cmd_code;               /* Command code */

} diag_sw_sub_rev_req_type;

/*
 diag_sw_sub_rev_req_type	sw_sub_rev;	//SHX2 2003.1.13 By Joe

PACKET   diag_sw_sub_rev_rsp_type

ID       DIAG_SW_SUB_REV_F

PURPOSE  Sent by the DMSS, contains SW sub revision number

===========================================================================*/
typedef struct
{
  byte cmd_code;
  byte sw_sub_rev;
} diag_sw_sub_rev_rsp_type;

#define DIAG_TEST_MODE_F 250

typedef struct 
{
  byte file_number; 
  byte midi; /* Use test_mode_req_midi_type. */
} test_mode_req_struct_type;


typedef union
{
  byte sw_rev; /* Not used */
  byte lcd; /* Use test_mode_req_lcd_type. */
  byte folder;  /* Use test_mode_req_folder_type. */
  byte motor; /* Use test_mode_req_motor_type. */
  byte acoustic; /* Use test_mode_req_acoustic_type. */  
  test_mode_req_struct_type midi;
  byte vod; /* Use test_mode_req_vod_type. */
  byte cam; /* Use test_mode_req_cam_type. */
  byte buzzer; /* Use test_mode_req_buzzer_type. */
  byte efs_integrity; /* Not used */
  byte factory_init; /* Not used */
  byte IrDA;
  byte Mic2On;	// 250-13-6 : vivache
  byte Iccard;
  byte btmode;	/* used for Bluetooth test mode */

// 2005.7.1 lupis
  byte alcol; //32
  byte tdmb;  //33
  byte tvout;  //34
  byte sdmb;   //35
  byte manual;  //36
  byte uv;  //37
  byte hdd;  //38
  byte Sleep;  //42
  byte VSIM;	//44-0, 1, 2
  byte Camp;	//44-3
  byte CampReq;	//44-4 ~ 20
  byte photo;	//45
  byte MRD;		//47 250-47-0, 1  : vivache - 
  byte UsbFactory;	//47 250-47-3 : vivache - USB Factory Mode ON
  byte SystemChange;	//53
  byte antenna;
  byte calltype;	// 64-0, 64-1

// [08/04/2010] JKPARK : ���� DIAG ��� �߰�
  byte wifimode;	// 33-4, 5,...,13		
  byte PID;			// 70-0, 1(read)
  byte swversion;	// 71-0, 1, 2
  byte imei;		// 72-0, 1(read), 2, 3
  byte calcheck;	// 82-0(calck), 1(caldt)
//-----------------------------------------

} test_mode_req_type;

/*============================================================================
Added by KYH 2003.4.29
PACKET   diag_test_mode_req_type
ID       DIAG_TEST_MODE_F	//250
PURPOSE  Sent from the DM to the DMSS to request the test mode process
RESPONSE The DMSS sends back a diag_test_mode_rsp_type packet.
============================================================================*/
typedef  struct
{
  byte cmd_code;               /* Command code */
  word sub_cmd_code;           /* Use test_mode_sub_cmd_type. */
  test_mode_req_type test_mode_req;
} diag_test_mode_req_type;
//////////////KYH
////////////////////////////////////////////////////////////////////////////
//TST IRDA ���� ���
/*============================================================================
// Added by KYH  2003.4.29 
PACKET   diag_test_mode_req_type

ID       DIAG_TEST_MODE_F

PURPOSE  Sent from the DM to the DMSS to request the test mode process

RESPONSE The DMSS sends back a diag_test_mode_rsp_type packet.

============================================================================*/

typedef enum
{
  TEST_MODE_SW_REV, // 0
  TEST_MODE_LCD,
  TEST_MODE_FOLDER,
  TEST_MODE_MOTOR,
  TEST_MODE_ACOUSTIC,
  TEST_MODE_MIDI,
  TEST_MODE_VOD,
  TEST_MODE_CAM,
  TEST_MODE_BUZZER,
  TEST_MODE_EFS_INTEGRITY,
  TEST_MODE_FACTORY_INIT,
  TEST_MODE_EFS2_INTEGRITY, //11.Mr. seo Test Mode add.
  TEST_MODE_NON_SERACHING,  //12.Mr. seo Test Mode add.
  TEST_MODE_IRDA,           //13.Mr. seo Test Mode add.
  TEST_MODE_ICCARD,         //14.Mr. seo Test Mode add. 
  TEST_MODE_BT_MODE = 24,	/* Added for Bluetooth test mode */
  TEST_MODE_TDMB = 33,      // TDMB, SDMB, MediaFlos, ���� DMB, WiFi(WLAN)
  TEST_MODE_WLAN = 33,		// [08/04/2010] JKPARK : Test mode ��� �� ������ ��Ȯ�� ���ֱ� ���� �߰�.
  TEST_MODE_SDMB = 35,		// S-DMB Sub cmd
  TEST_MODE_MANUAL = 36,	// Manual Test
  TEST_MODE_SLEEP = 42,		// SLEEP MODE
  TEST_MODE_VSIM = 44,		// VIRTUAL SIM
  TEST_MODE_PHOTO = 45,		// Photo Sensor
  TEST_MODE_MRD = 47,		// MRD & USB 
  TEST_MODE_SYSTEM_CHANGE = 53,	// System Change Between CDMA/UMTS
  TEST_MODE_MIMO_ANT_CHECK = 62,	// MIMO Antenna Check
  TEST_MODE_SYSTEM_LTE_RF_CHANGE = 63,	// System Change Between LTE/RF
  TEST_MODE_LTE_CALL = 64,	// System Change Between LTE/RF
  TEST_MODE_PID = 70,			// [08/04/2010] JKPARK : ���� DIAG ��� �߰�
  TEST_MODE_SWVERSION = 71,		// [08/04/2010] JKPARK : ���� DIAG ��� �߰�
  TEST_MODE_IMEI = 72,			// [08/04/2010] JKPARK : ���� DIAG ��� �߰�
  TEST_MODE_CALCHECK = 82		// [08/04/2010] JKPARK : ���� DIAG ��� �߰�
} test_mode_sub_cmd_type;

#define FACTORY_INFO_SIZE 32
#define SWVERSION_SIZE 80
typedef union
{
  byte sw_rev;
  byte lcd; /* Not used */
  byte folder; /* Not used */
  byte motor; /* Not used */
  byte acoustic; /* Not used */
  byte midi; /* Not used */
  byte vod; /* Not used */
  byte cam; /* Not used */
  byte buzzer; /* Not used */
  byte efs_integrity; /* Use test_mode_rsp_efs_integrity_type. */
  byte factory_init; /* Not used */
  byte IrDA;  
  byte Iccard;

  byte tdmb;                         //33
  byte manual;						 //36
  byte VSIM;						 //44
  byte photo;						 //45

  char factory_info[FACTORY_INFO_SIZE];		// [8/5/2010] JKPARK : ���� Diag ����ϸ鼭 PID ó���� ���� �߰���.
  char version_array[SWVERSION_SIZE];		// [8/5/2010] JKPARK : ���� Diag ����ϸ鼭 S/W version ó���� ���� �߰���.

} test_mode_rsp_type;

/*===========================================================================

PACKET   diag_test_mode_rsp_type

ID       DIAG_TEST_MODE_F //250

PURPOSE  Sent by the DMSS, contains test mode process result

===========================================================================*/
typedef struct
{
  byte cmd_code;
  word sub_cmd_code;  /* Use test_mode_sub_cmd_type. */
  byte ret_stat_code; /* Status to return. Use diag_test_mode_ret_stat_type. */
  test_mode_rsp_type test_mode_rsp;
} diag_test_mode_rsp_type;


// ��� �߰� //////////////////////////////////////////////////////////////////

#define DIAG_DIAGVER 0007


/*---------------------------------------------------------------------------

       Declare the packet types for DM to Mobile communication

---------------------------------------------------------------------------*/

/*============================================================================

PACKET   diag_verno_req_type

ID       DIAG_VERNO_F

PURPOSE  Sent from the DM to the DMSS requesting the DMSS send its
         version number

RESPONSE The DMSS sends back a diag_verno_rsp_type packet containing the
         version number

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
} diag_verno_req_type;


/*============================================================================

PACKET   diag_verstr_req_type

ID       DIAG_VERSTR_F

PURPOSE  Sent from the DM to the DMSS to request the version string

RESPONSE The DMSS sends back a diag_verstr_rsp_type packet containing the
         version string.

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
} diag_verstr_req_type;

/*===========================================================================

PACKET   diag_esn_req_type

ID       DIAG_ESN_F

PURPOSE  Sent from the DM to the DMSS to request the Mobile's ESN

RESPONSE The DMSS sends back a diag_esn_rsp_type packet containing ESN

============================================================================*/
typedef struct
{
  BYTE  cmd_code;              /* Command code. */
} diag_esn_req_type;

/*===========================================================================

PACKET   diag_spc_req_type

ID       DIAG_SPC_F

PURPOSE  Sent by external device to enter the Service Programming Code,
         to then allow Service Programming.

RESPONSE The diag_spc_rsp_type will be sent in response.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  nv_sec_code_type sec_code;  /* The security code */
} diag_spc_req_type;


/*==========================================================================

PACKET   diag_peek_req_type

IDs      DIAG_PEEKB_F
         DIAG_PEEKW_F
         DIAG_PEEKD_F

PURPOSE  Sent from the DM to the DMSS to request a read of a block of data.
         The cmd_code specifies BYTE, WORD or DWORD.

RESPONSE The DMSS reads the address and sends the data back in a
         diag_peekb_rsp_type or diag_peekw_rsp_type or diag_peekd_rsp_type

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  BYTE far *ptr;               /* starting address for peek operation */
  WORD length;                 /* number of BYTEs, WORDs, or DWORDs  to be
                                  returned */
} diag_peek_req_type;

/*===========================================================================

PACKET   diag_pokeb_req_type

ID       DIAG_POKEB_F

PURPOSE  Sent by the DM to the DMSS to request that a block of data be
         written starting at a specified address.

RESPONSE If the poke is successful, the DMSS sends exactly the same packet
         back to the DM, otherwise an error packet is sent.

============================================================================*/
#define DIAG_MAX_POKE_B 4
  /* Maximum number of BYTEs allowed for one pokeb request */

typedef struct
{
  BYTE cmd_code;               /* Command code */
  BYTE far *ptr;               /* starting address for poke operation */
  BYTE length;                 /* number of BYTEs to be poked */
  BYTE data[DIAG_MAX_POKE_B];  /* BYTEs to be placed at the addr address */
} diag_pokeb_req_type;

/*===========================================================================

PACKET   diag_pokew_req_type

ID       DIAG_POKEW_F

PURPOSE  Sent by the DM to the DMSS to request that a block of data be
         written starting at a specified address.

RESPONSE If the poke is successful, the DMSS sends exactly the same packet
         back to the DM, otherwise an error packet is sent.

============================================================================*/

#define DIAG_MAX_POKE_W 2
  /* Maximum number of WORDs allowed for one pokew request */

typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD far *ptr;               /* starting address for poke operation */
  BYTE length;                 /* number of WORDs to be poked */
  WORD data[DIAG_MAX_POKE_W];  /* WORDs to be placed at the addr address */
} diag_pokew_req_type;

/*===========================================================================

PACKET   diag_poked_req_type

ID       DIAG_POKED_F

PURPOSE  Sent by the DM to the DMSS to request that a block of data be
         written starting at a specified address.

RESPONSE If the poke is successful, the DMSS sends exactly the same packet
         back to the DM, otherwise an error packet is sent.

============================================================================*/

#define DIAG_MAX_POKE_D 2
  /* Maximum number of DWORDs allowed for one poked request this is 2 to
     allow possible growth to handle qWORDs. */

typedef struct
{
  BYTE cmd_code;               /* Command code */
  DWORD far *ptr;              /* starting address for poke operation */
  BYTE length;                 /* number of DWORDs to be poked */
  DWORD data[DIAG_MAX_POKE_D]; /* DWORD to be placed at the addr address */
} diag_poked_req_type;

/*===========================================================================

PACKET   diag_vpoke_req_type

ID       DIAG_VPOKE_F

PURPOSE  Sent by the DM to the DMSS to request that a block of data be
         written starting at a specified address in the vocoder's memory.

RESPONSE If the poke is successful, the DMSS sends exactly the same packet
         back to the DM, otherwise an error packet is sent.

============================================================================*/

typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD addr;                   /* starting address for poke operation */
  WORD data;                   /* data to be placed at the addr address */
} diag_vpoke_req_type;

/*===========================================================================

PACKET   diag_vpeek_req_type

ID       DIAG_VPEEK_F

PURPOSE  Sent by the DM to the DMSS to request that a block of data be
         read from the vocoder memory at a specified address.

RESPONSE The DMSS reads the vocoder memory and sends what it read back
         in a diag_vpeek_rsp_type packet.

============================================================================*/

typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD addr;                   /* starting address for poke operation */
} diag_vpeek_req_type;


/*===========================================================================

PACKET   diag_outp_req_type

ID       DIAG_OUTP_F

PURPOSE  Sent by the DMSS to the DM to request a BYTE of data be output
         to a specified port.

RESPONSE The DMSS outputs the BYTE to the port and echos the
         diag_outp_req_type packet back to the DM.

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD port;                   /* number of port to output to */
  BYTE data;                   /* data to write to port */
} diag_outp_req_type;


/*===========================================================================

PACKET   diag_outpw_req_type

ID       DIAG_OUTPW_F

PURPOSE  Sent by the DMSS to the DM to request a WORD of data be output
         to a specific port.

RESPONSE The DMSS outputs the WORD, then echos back the diag_outpw_req_type
         packet to the DMSS.

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD port;                   /* number of port to output to */
  WORD data;                   /* data to write to port */
} diag_outpw_req_type;


/*===========================================================================

PACKET   diag_inp_req_type

ID       DIAG_INP_F

PURPOSE  Sent by the DM to request a BYTE to be input from a given port.

RESPONSE The DMSS inputs the BYTE, then returns it in a diag_inp_rsp_type
         packet.

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD port;                   /* port to read from */
} diag_inp_req_type;


/*===========================================================================

PACKET   diag_inpw_req_type

ID       DIAG_INPW_F

PURPOSE  Sent by the DM to request a WORD to be input from a given port.

RESPONSE The DMSS inputs the WORD, then returns it in a diag_inpw_rsp_type
         packet.

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD port;                   /* port to read from */
} diag_inpw_req_type;


/*===========================================================================

PACKET   diag_status_req_type

ID       DIAG_STATUS_F

PURPOSE  Sent by the DM to request a set of status data

RESPONSE The DMSS gathers the status data and sends it in a
         diag_status_rsp_type packet to the DM.

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
} diag_status_req_type;


/*===========================================================================

PACKET   diag_logmask_req_type

ID       DIAG_LOGMASK_F

PURPOSE  Sent by the DM to set the logging mask in the DMSS

RESPONSE The DMSS establishes the logging mask and replies with a
         diag_logmask_rsp_type packet

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  DWORD mask;                  /* mask to use */
} diag_logmask_req_type;


/*===========================================================================

PACKET   diag_log_req_type

ID       DIAG_LOG_F

PURPOSE  Sent by the DM to request accumulated logging information

RESPONSE The DMSS retreives a logging message and sends it in a
         diag_log_rsp_type packet

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
} diag_log_req_type;

/*===========================================================================

PACKET   diag_nv_peek_req_type

ID       DIAG_NV_PEEK_F

PURPOSE  Sent by DM to view an area of DMSS NV memory.  Operates strictly
         by address.

RESPONSE The DMSS reads the specified NV memory and returns its value in
         a diag_nv_peek_rsp_type packet.

===========================================================================*/
typedef struct
{
  BYTE  cmd_code;               /* Command code */
  WORD  address;                /* NV address */
  BYTE  length;                 /* length */
} diag_nv_peek_req_type;


/*===========================================================================

PACKET   diag_nv_poke_req_type

ID       DIAG_NV_POKE_F

PURPOSE  Sent by the DM to request that DMSS NV memory be set to specified
         values. DIAG_MAX_NV_POKE is the max size of the memory block that
         can be written.

RESPONSE DMSS writes specified block of NV data and echos the
         diag_nv_poke_req_type packet back to the DM.

============================================================================*/
/* Maximum number of BYTEs that can be poked in NVM with one request */
#define DIAG_MAX_NV_POKE 4

typedef struct
{
  BYTE cmd_code;               /* Command code */
  nv_poke_type  nvpoke;        /* nv item type */
} diag_nv_poke_req_type;


/*===========================================================================

PACKET   diag_tagraph_req_type

ID       DIAG_TAGRAPH_F

PURPOSE  Sent by the DM to request info for lower-right corner of TA

RESPONSE The DMSS prepares and sends a diag_tagraph_rsp_type packet.

============================================================================*/
typedef struct
{
  BYTE cmd_code;                /* Command code */
} diag_tagraph_req_type;


/*===========================================================================

PACKET   diag_markov_req_type

ID       DIAG_MARKOV_F

PURPOSE  Sent by the DM to reqest Markov Statistics

RESPONSE The DMSS prepares and sends a diag_markov_rsp_type packet.

============================================================================*/
typedef struct
{
  BYTE cmd_code;                /* Command code */
} diag_markov_req_type;


/*===========================================================================

PACKET   diag_diag_ver_req_type

ID       DIAG_DIAG_VER_F

PURPOSE  Sent by DM to request the version of the diag

RESPONSE DMSS returns DIAG_DIAGVER in a diag_diag_ver_rsp_type packet

===========================================================================*/
typedef struct
{
  BYTE cmd_code;                /* Command code */
} diag_diag_ver_req_type;


/*==========================================================================

PACKET   diag_ts_req_type

ID       DIAG_TS_F

PURPOSE  Sent by the DM to request a timestamp from the DMSS

RESPONSE The DMSS returns a timestamp in a diag_ts_rsp_type packet.

============================================================================*/
typedef struct
{
  BYTE cmd_code;                /* Command code */
} diag_ts_req_type;


/*===========================================================================

PACKET   diag_ta_parm_req_type

ID       DIAG_TA_PARM_F

PURPOSE  Sent by the DM to set TA parameters in the DMSS

RESPONSE The DMSS sets the TA parameters and sends a diag_ta_parm_rsp_type
         packet.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;                /* Command code */
  WORD set_mask;
    /* Bit 15 = enable reporting of active set members
       Bit 14 = enable reporting of candidate set members
       Bit 13 = enable reporting of neighbor set members
       Bit 12 = enable reporting of remaining set members
       Bit 11 = enable reporting of pre-candidate set members */
  WORD win_siz;                 /* specifies maximum window size in half chip units */

} diag_ta_parm_req_type;


/*===========================================================================

PACKET   diag_markov_reset_req_type

ID       DIAG_MARKOV_RESET_F
PURPOSE  Sent by the DM to reset the DMSS's Markov Statistics

RESPONSE DMSS resets the accumulated Markov Statistics and replies with
         a diag_m_reset_rsp_type packet.

============================================================================*/
typedef struct
{
  BYTE cmd_code;                /* Command code */
} diag_markov_reset_req_type;



/*===========================================================================

PACKET   diag_msg_req_type

ID       DIAG_MSG_F

PURPOSE  Sent by the DM to request a buffered msg

RESPONSE The DMSS selects an appropriate message and sends it in a
         diag_msg_rsp_type packet.

============================================================================*/
typedef struct
{
 BYTE cmd_code;                    /* Command code */
 WORD msg_level;                   /* highest type desired */
} diag_msg_req_type;

/*===========================================================================

PACKET   diag_err_clr_type

ID       DIAG_ERR_CLEAR_F

PURPOSE  Sent by the DM to clear the requested buffered error records

RESPONSE The DMSS clears the specified error records.

===========================================================================*/
typedef struct {
  BYTE                  cmd_code;   /* Command code --  DIAG_ERR_CLEAR_F */
  BYTE                  rec;        /* record id, or -1 (0xFF) for all */
} diag_err_clr_req_type;

/*===========================================================================

PACKET   diag_err_req_type

ID       DIAG_ERR_READ_F

PURPOSE  Sent by the DM to request the buffered error records

RESPONSE The DMSS retreives error records

===========================================================================*/
typedef struct {
  BYTE                   cmd_code;   /* Command code --  DIAG_ERR_READ_F */
} diag_err_req_type;


/*===========================================================================

PACKET   diag_hs_key_req_type

ID       DIAG_HS_KEY_F

PURPOSE  Sent by DM to cause a keypress input to the handset interface.

RESPONSE Diag queues a keypress to hsi and echos the request packet.

===========================================================================*/
typedef struct
{
 BYTE    cmd_code;                 /* Command code */
 boolean hold;                     /* If true, diag witholds key release */
 BYTE    key;                      /* enumerated key, e.g. HS_DOWN_K */
} diag_hs_key_req_type;

/*===========================================================================

PACKET   diag_hs_lock_req_type

ID       DIAG_HS_LOCK_F

PURPOSE  Sent by DM to lock or unlock the real handset.

RESPONSE Diag queues a command to hsi with new hs lock state, then
         echos the packet to the DM.

===========================================================================*/
//typedef enum {
#define  HS_LOCK_F 0                       /* command to lock real handset */
#define  HS_REL_F  1                       /* command to release real handset */
//} diag_hs_lock_type;
typedef WORD diag_hs_lock_type;

typedef struct
{
 BYTE    cmd_code;                 /* Command code */
 diag_hs_lock_type lock;           /* diag locks or unlocks real hs */
} diag_hs_lock_req_type;


/*===========================================================================

PACKET   diag_screen_req_type

ID       DIAG_HS_SCREEN_F

PURPOSE  Sent by DM to request an image of the handset screen and annun-
         ciators.

RESPONSE DMSS returns diag_screen_rsp_type packet that contains handset
         screen and annunciators.

===========================================================================*/
typedef struct
{
 BYTE    cmd_code;                 /* Command code */
} diag_screen_req_type;


/*===========================================================================

PACKET   diag_parm_get_req_type

ID       DIAG_PARM_GET_F

PURPOSE  Sent by DM to request the set of retreivable parameters.
         Parameters referred to here are the CAI's settable and
         retreival parameters listed in section 6.4.5 and Appendix E.

RESPONSE DMSS places current value of all parameters in a diag_parm_
         get_rsp_type packet and sends it back.


============================================================================*/
typedef struct {
  BYTE                cmd_code;               /* Command code */
} diag_parm_get_req_type;

/*===========================================================================

PACKET   diag_parm_set_req_type

ID       DIAG_PARM_SET_F

PURPOSE  Sent by DM to set one of the retreivable parameters.
         Parameters referred to here are the CAI's settable and
         retreival parameters listed in section 6.4.5 and Appendix E.

RESPONSE DMSS replaces current value of the given parameter with the one
         supplied, and sends a diag_parm_set_rsp_type packet back.


============================================================================*/
typedef struct {
  BYTE                cmd_code;               /* Command code               */
  WORD                 parm_id;                /* Parameter value, from
                                                 cai.h.  A parm_id of 0 will
                                                 cause ALL parmameters to
                                                 be cleared.                */
  DWORD               parm_value;             /* New value for parameter    */
} diag_parm_set_req_type;


/*==========================================================================

PACKET   diag_nv_read_req_type

ID       DIAG_NV_READ_F

PURPOSE  Sent by DM to request the value of some NV item.

RESPONSE DMSS reads the NV item and returns it in a diag_nv_read_rsp
         (which uses the same packet id, DIAG_NV_READ)

============================================================================*/
typedef struct
{
 BYTE                cmd_code;                 /* Command code */
 nv_items_enum_type  item;                     /* Which item   */
 nv_item_type        item_data;                /* Item itself  */
 nv_stat_enum_type   nv_stat;                  /* Status of operation */
} diag_nv_read_req_type;

/*==========================================================================

PACKET   diag_nv_write_req_type

ID       DIAG_NV_WRITE_F

PURPOSE  Sent by DM to cause DMSS to write the value of some NV item.

RESPONSE DMSS reads the NV item and returns it in a diag_nv_write_rsp
         (which uses the same packet id, DIAG_NV_WRITE_F)

============================================================================*/
typedef struct
{
 BYTE                cmd_code;                 /* Command code */
 nv_items_enum_type  item;                     /* Which item   */
 nv_item_type        item_data;                /* Parameters   */
 nv_stat_enum_type   nv_stat;                  /* Status of operation */
} diag_nv_write_req_type;


/*==========================================================================

PACKET   diag_reg_req_type

ID       DIAG_REGIS_F

PURPOSE  Sent by external device to identify itself to the DMSS.  This packet
         is optional, and a default device is assumed if no registration
         is received.

RESPONSE DMSS sets the device, replies.

===========================================================================*/
typedef struct
{
  BYTE               cmd_code;
  WORD                    dev;
} diag_reg_req_type;

/*===========================================================================

PACKET   diag_config_req_type

ID       DIAG_CONFIG_F

PURPOSE  Sent by DM to configure Power Adjustment tables

RESPONSE DMSS configures table according to command

===========================================================================*/
typedef struct
{
  BYTE               cmd_code;
  conf_hdr_type           hdr;            /* Configuration header block */
  conf_data_type         data;            /* Configuration data block */
} diag_conf_req_type;


/*===========================================================================

PACKET   diag_control_req_type

ID       DIAG_CONTROL_F

PURPOSE  Sent by DM to direct the DMSS to go offline or reset

RESPONSE DMSS changes mode or resets

===========================================================================*/
//typedef enum {
#define  MODE_OFFLINE_A_F  0         /* Go to offline analog */
#define  MODE_OFFLINE_D_F  1         /* Go to offline digital */
#define  MODE_RESET_F      2         /* Reset. Only exit from offline */
//ysi ftm 95c 2000/9/29
#define  MODE_ONLINE_FT_F  3
//#define  MODE_MAX_F        4          /* Last (and invalid) mode enum value */ //  [6/26/2006] �ߺ����� ������.
//} mode_enum_type;
typedef WORD mode_enum_type;

typedef struct {
  BYTE               cmd_code;
  mode_enum_type     mode;
} diag_control_req_type;


/*===========================================================================

PACKET   diag_ser_reset_req_type

ID       DIAG_SER_RESET_F

PURPOSE  Sent by DM to direct the DMSS reset the SER counts

RESPONSE DMSS resets counts and sends reply packet acknowledging the action

===========================================================================*/

typedef struct
{
  BYTE cmd_code;
    /* Command code */
} diag_ser_reset_req_type;


/*===========================================================================

PACKET   diag_ser_report_req_type

ID       DIAG_SER_REPORT_F

PURPOSE  Sent by DM to direct the DMSS to report the SER counts.  They
         are not reset.

RESPONSE DMSS send reply packet containing the counts.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;
    /* Command code */
} diag_ser_report_req_type;

/*===========================================================================

PACKET   diag_test_req_type

ID       DIAG_TEST_F

PURPOSE  Sent by DM to direct the DMSS to perform a specified test.

RESPONSE DMSS performs the test, then responds.

===========================================================================*/
typedef struct {
  BYTE                  cmd_code;
  diag_test_enum_type   test_code;
  diag_test_parm_type   parm;
} diag_test_req_type;

/*===========================================================================

PACKET   diag_dipsw_req_type

ID       DIAG_DIPSW_F

PURPOSE  Sent by DM to retreive the current dip switch settings

RESPONSE DMSS performs the test, then responds.

===========================================================================*/
typedef struct {
  BYTE                  cmd_code;
  WORD                  switches;
} diag_dipsw_req_type;


/*===========================================================================

PACKET   diag_voc_pcm_lb_type

ID       DIAG_VOC_PCM_LB_F

PURPOSE  Sent by DM to start/stop vocoder PCM loopback.

RESPONSE DMSS sends command to vocoder, then replies.

===========================================================================*/
typedef struct {
  BYTE                  cmd_code;
  boolean               pcm_lb;           /* TRUE => start, FALSE => stop */
} diag_voc_pcm_lb_type;

/*===========================================================================

PACKET   diag_voc_pkt_lb_type

ID       DIAG_VOC_PKT_LB_F

PURPOSE  Sent by DM to start/stop vocoder PKT loopback.

RESPONSE DMSS sends command to vocoder, then replies.

===========================================================================*/
typedef struct {
  BYTE                  cmd_code;
  boolean               pkt_lb;           /* TRUE => start, FALSE => stop */
} diag_voc_pkt_lb_type;
//choi
/*===========================================================================

PACKET   diag_rxcal_req_type

ID       DIAG_RXCAL_F

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  BYTE set_val;               /* Test Mobile command */
  BYTE cal_start_val;			/* by Choi DH */
  BYTE cal_stop_val;				/* by Choi DH */
} diag_rxcal_req_type;

/*===========================================================================

  1999. 3. 4 CKK for MSM3000

PACKET   diag_rxcal3000_req_type

ID       DIAG_RXCAL_F

===========================================================================*/
typedef struct
{
  BYTE	cmd_code;			/* Command code */
  BYTE	set_val;			/* Test Mobile command */
  WORD	cal_start_val;		/* by Choi DH  - change type (BYTE to WORD) for MSM3000 */
  BYTE	cal_stop_val;		/* by Choi DH */
} diag_rxcal3000_req_type;

/*===========================================================================

PACKET   diag_txcal_req_type

ID       DIAG_TXCAL_F

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  WORD set_val;                /* tx agc value to be set */
  BYTE txcal_or_hdet;         /* 0 : read hdet value from adc 
                                 1 : set txagc value 
                              */
  BYTE cdma_or_fm;            /* 0 : cdma
                                 1 : fm
                              */
} diag_txcal_req_type;
/*===========================================================================

PACKET   diag_misc_cal_what_to_do_type

ID       DIAG_MISC_CAL_F

PURPOSE  Sent by HHP to control the phone as your own.

RESPONSE The diag_misc_cal_rsp_type will be sent in response.

PACKET DEFINITION
  value of what_to_do meaning of what_to_do   meaning of what_1
       0					 MISC_NULL               not used
 	    1	             CHANGE_CDMA_CHAN        cdma channel number
 	    2              HANGE_TX_GAIN_COMP      pdm2 value
 	    3              CHANGE_RX_GAIN_COMP     pdm1 value
 	    4              PA_R10_CONTROL          T.B.D
       5              CAL_MISC_CONTROL
       6              FM_HDET_READ //96/08/14
       7              CAL_FLAG_CONTROL //96/08/16
		11					 CHANGE_CDMA_CHAN_ERR  	 error
		22					 CHANGE_TX_GAIN_COMP_ERR error
		33					 CHANGE_RX_GAIN_COMP_ERR error
		44					 PA_R10_CONTROL_ERR 		 error
===========================================================================*/
//typedef enum {
#define    MISC_NULL                0
#define    CHANGE_CDMA_CHAN         1
#define    CHANGE_TX_GAIN_COMP      2
#define    CHANGE_RX_GAIN_COMP      3
#define    PA_R10_CONTROL           4
#define    CAL_MISC_CONTROL         5
#define    FM_HDET_READ             6
#define    CAL_FLAG_CONTROL         7
#define    CHANGE_CDMA_CHAN_ERR     11
#define    CHANGE_TX_GAIN_COMP_ERR  22
#define    CHANGE_RX_GAIN_COMP_ERR  33
#define    PA_R10_CONTROL_ERR       44
// insert sya=====start
#define	   READ_PWR_CTL_LOG			50	
#define	   READ_PWR_CTL1_LOG		51	
#define	   READ_PWR_CTL2_LOG		52	
#define	   READ_PWR_CTL3_LOG		53	
// insert sya=====end
//} diag_misc_cal_what_to_do_type;

// MSM3000 start CKK
#define   MISC_NULL_3000                0x01       
#define   CHANGE_CDMA_CHAN_3000         0x02
#define   CHANGE_TX_GAIN_COMP_3000      0x03
#define   CHANGE_RX_GAIN_COMP_3000      0x04
#define   PA_R10_CONTROL_3000           0x05
#define   CAL_MISC_CONTROL_3000         0x06
#define   FM_HDET_READ_3000             0x07
#define   CAL_FLAG_CONTROL_3000         0x08
#define   CHANGE_CDMA_CHAN_ERR_3000     0x09
//TM210
#define   CHANGE_CURRENT_BAND           0x0a
#define   MAX_POWER_ON                  0x50 // Offine Max Power On�� �����ϱ� ���� �߰� ysi 2000/03/06 
#define	  LGF_MAX_POWER_OFF				0x51 // ���� TxLim���� ���
#define	  LGF_LIM_VS_FREQ_WRITE			0xFE // ���� TxLim���� ���

//..
//0x0a ~ 0x0f���� ��� �־ ���⿡ �߰� ��.
//..
//TM210
#define   CHANGE_TX_GAIN_COMP_ERR_3000  0x10
#define   CHANGE_RX_GAIN_COMP_ERR_3000  0x11 
#define   PA_R10_CONTROL_ERR_3000       0x12
#define   READ_PWR_CTL_LOG_3000         0x13
#define   READ_PWR_CTL1_LOG_3000        0x14 
#define   READ_PWR_CTL2_LOG_3000        0x15 
#define   READ_PWR_CTL3_LOG_3000        0x16
#define   FM_RX_AGC_TEST                0x17
#define   CAL_TEST_CONTROL              0x18
#define   CAL_RF_CAGC_OUTM              0x19 //qunam �߰� what_1 - register (���ο��� 0x3000000�� ������ address�� ������)
                                             //           what_3 = mask 
                                             //           what_4 = data 
                                             //lgp-7400f���� ������ ���ġ �ʰ� ����.
// ysi for D430 �߰� nv�� ���� �Ǿ� �ֵ� cal����  linearizer�� load�ϱ� ���� 2002/04/20
#define   LOAD_CAL_DATA                 0x60 // 
#define   UPDATE_LIM_VS_FREQ            0x61 
#define   CHANNEL_BAND_FIX_ENABLE       0x65
#define   CHANNEL_BAND_FIX_DISABLE      0x66

// MSM3000 end CKK

typedef WORD diag_misc_cal_what_to_do_type;
/*===========================================================================

PACKET   diag_misc_cal_req_type

ID       DIAG_MISC_CAL_F

PURPOSE  Sent by HHP to control the phone as your own.

RESPONSE The diag_misc_cal_rsp_type will be sent in response.

PACKET DEFINITION
  value of what_to_do meaning of what_to_do meaning of what_1
 	    1		 CHANGE_CDMA_CHAN      cdma channel number
 	    2            CHANGE_TX_GAIN_COMP   pdm2 value
 	    3            CHANGE_RX_GAIN_COMP   pdm1 value
 	    4            PA_R10_DISABLE        T.B.D
===========================================================================*/

typedef struct {
	BYTE cmd_code;        /* Command code */
	diag_misc_cal_what_to_do_type what_to_do;      
	WORD what_1;	    
	WORD what_2;
	BYTE what_3;
} diag_misc_cal_req_type;

/*===========================================================================
// OJS InterCube������ �ϴ¼� ����...  ������

PACKET   diag_misc_cal_req_type

ID       DIAG_MISC_CAL_F

PURPOSE  set channel, check pll lock status

RESPONSE

============================================================================*/
typedef  struct {
  BYTE cmd_code;                /* Command code */
  WORD channel;                 /* Input channel value */
  BYTE lock_status;             /* PLL lock or unlock? */
} diag_misc_calInreCube_req_type;



/*===========================================================================

  1999. 4. 13 CKK for MSM3000

PACKET   diag_misc_cal3000_req_type

===========================================================================*/
typedef struct {
	BYTE cmd_code;        /* Command code */
	BYTE what_to_do;
	WORD what_1;	    
	WORD what_2;
	BYTE what_3;
// cal_log
	BYTE what_4;
	BYTE what_5;
} diag_misc_cal3000_req_type;


//+ for T-DMB
typedef enum {
	TDMB_START = 0,
	TDMB_STOP = 1,
	TDMB_GET_STATUS = 2,
	TDMB_SET_CH = 3,
	TDMB_SET_LNA_OFF = 4,
	TDMB_SET_LNA_ON = 5
} tdmb_sub_cmd_type;

typedef union {
	byte chan;
	byte lna;
} tdmb_req_type;

typedef struct {
    byte cmd_code;
    word sub_cmd_code;
	tdmb_req_type tdmb_req;
} diag_tdmb_req_type;
//-

typedef struct {
   byte cmd_code;              /* Command code */
   diag_misc_cal_what_to_do_type what_to_do;               
   WORD what_1;
   WORD what_2;
   byte what_3;
} diag_misc_cal_rsp_type;

/*===========================================================================

  1999. 4. 13 CKK for MSM3000

PACKET   diag_misc_cal3000_rsp_type

===========================================================================*/
typedef struct {
   BYTE cmd_code;              /* Command code */
   BYTE what_to_do;
   WORD what_1;
   WORD what_2;
   BYTE what_3;
/* cal_log */
   BYTE what_4;
   BYTE what_5;
} diag_misc_cal3000_rsp_type;


// for T-DMB
// LD1200 ����� �䱸�� ���� �̼�ȣS �ʵ� �߰� =========
typedef struct {
    unsigned int dab_ok;
    unsigned int msc_ber;
    unsigned int sync_lock;
    unsigned int afc_ok;
    unsigned int cir;
    unsigned int fic_ber;
    unsigned int tp_lock;
    unsigned int sch_ber;
    unsigned int tp_err_cnt;
	byte srv_state_flag;
} tdmb_status_rsp_type_old;

typedef struct {
    unsigned int dab_ok;
    unsigned int msc_ber;
    unsigned int sync_lock;
    unsigned int afc_ok;
    unsigned int cir;
    unsigned int fic_ber;
    unsigned int tp_lock;
    unsigned int sch_ber;
    unsigned int tp_err_cnt;
	unsigned int va_ber;	// ������ �ʵ�
	byte srv_state_flag;
} tdmb_status_rsp_type;
// =============================================

typedef enum {
	TDMB_TEST_OK_S = 0,
	TDMB_TEST_FAIL_S = 1,
	TDMB_TEST_NOT_SUPPORTED = 2,
	TDMB_TEST_NOT_READY = 0xf		// DMB Task Not Ready : 2005. 8. 26
} diag_tdmb_ret_stat_type;

typedef union {
	tdmb_status_rsp_type_old status_old;	// LD1200
	tdmb_status_rsp_type status;
} tdmb_rsp_type;

typedef struct {
	byte cmd_code;
	word sub_cmd_code;
	byte ret_stat_code;
	tdmb_rsp_type tdmb_rsp;
} diag_tdmb_rsp_type;

/*===========================================================================
//OJS
PACKET   diag_misc_cal3000_rsp_type

===========================================================================*/
typedef  struct {
  BYTE cmd_code;                /* Command code */
  WORD channel;                 /* Input channel value */
  byte lock_status;             /* PLL lock or unlock? */
} diag_misc_calInreCube_rsp_type;

//choi
/*===========================================================================

PACKET   diag_state_rsp_type

ID       DIAG_STATE_F

PURPOSE  Sent by external device to obtain the current state of operation
         the phone is in.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  BYTE phone_state;           /* Current phone state */
  WORD event_count;           /* Count of possible state-changing events */
} diag_state_rsp_type;

typedef struct {
  byte                cmd_code;               /* Command code */
} diag_parm_get2_req_type;

typedef struct {
  byte                cmd_code;               /* Command code */
} diag_ser_mode_chng_req_type;


/*===========================================================================

PACKET   diag_get_rssi_req_type

ID       DIAG_GET_RSSI_F

PURPOSE  Sent by DM to request current CDMA RSSI value.

RESPONSE DMSS places current value a diag_get_rssi_rsp_type
         packet and sends it back.

============================================================================*/
typedef struct {
  byte                cmd_code;               /* Command code */
} diag_get_rssi_req_type;


/*===========================================================================

PACKET   diag_password_req_type

ID       DIAG_PASSWORD_F

PURPOSE  Sent by external device to enter the Security Password.

RESPONSE The diag_password_rsp_type will be sent in response.

===========================================================================*/
#define DIAG_PASSWORD_SIZE 8
typedef struct
{
  byte cmd_code;                      /* Command code */
  byte password[DIAG_PASSWORD_SIZE];  /* The security password */
} diag_password_req_type;


/*===========================================================================

PACKET   diag_pr_list_wr_req_type

ID       DIAG_PR_LIST_WR_F

PURPOSE  Sent by external device to write a Preferred Roaming List to
         the phone.

RESPONSE The diag_pr_list_wr_rsp_type will be sent in response.

===========================================================================*/
#define DIAG_PR_LIST_BLOCK_SIZE 40   /* Size in bytes of the PR_LIST block */
typedef struct
{
  byte cmd_code;                      /* Command code */
  byte seq_num;                       /* Sequence number */
  byte more;                          /* More to come? */
  byte nam;                           /* which NAM this is associated with */
  word num_bits;                      /* length in bits of valid data */
  byte pr_list_data[DIAG_PR_LIST_BLOCK_SIZE];  /* The block of PR_LIST */
} diag_pr_list_wr_req_type;

#define DIAG_PR_LIST_BLOCK_SIZE_3000 120   /* Size in bytes of the PR_LIST block */
typedef struct
{
  BYTE cmd_code;                      /* Command code */
  BYTE seq_num;                       /* Sequence number */
  BYTE more;                          /* More to come? */
  BYTE nam;                           /* which NAM this is associated with */
  WORD num_bits;                      /* length in bits of valid data */
  BYTE pr_list_data[DIAG_PR_LIST_BLOCK_SIZE_3000];  /* The block of PR_LIST */
} diag_pr_list_wr3000_req_type;


/*===========================================================================

PACKET   diag_pr_list_rd_req_type

ID       DIAG_PR_LIST_RD_F

PURPOSE  Sent by external device to read a Preferred Roaming List from
         the phone.

RESPONSE The diag_pr_list_rd_rsp_type will be sent in response.

===========================================================================*/
typedef struct
{
  byte cmd_code;                      /* Command code */
  byte seq_num;                       /* Sequence number */
  byte nam;                           /* PR_LIST for this NAM */
} diag_pr_list_rd_req_type;

/*===========================================================================

PACKET   diag_pilot_sets_req_type

ID       DIAG_PILOT_SETS_F

PURPOSE  Sent by external device to obtain the current contents of the
         various pilot sets.

RESPONSE The diag_pilot_sets_rsp_type will be sent in response.

===========================================================================*/
typedef struct
{
  byte cmd_code;              /* Command code */
} diag_pilot_sets_req_type;

/*===========================================================================

PACKET   diag_spc_rsp_type

ID       DIAG_SPC_F

PURPOSE  Sent by external device to enter the Service Programming Code,
         to then allow Service Programming.  This response indicates
         whether the correct SPC was given or not.

NOTE     If the incorrect SPC is entered, DIAG will time out for 10 seconds.

===========================================================================*/
typedef struct
{
  byte cmd_code;              /* Command code */
  boolean sec_code_ok;        /* The SPC was entered correctly or not */
} diag_spc_rsp_type;

/*===========================================================================

PACKET   diag_state_req_type

ID       DIAG_STATE_F

PURPOSE  Sent by external device to obtain the current state of operation
         the phone is in.

RESPONSE The diag_state_rsp_type will be sent in response.

===========================================================================*/
typedef struct
{
  byte cmd_code;              /* Command code */
} diag_state_req_type;
//choi
/*===========================================================================

PACKET   diag_orig_req_type

ID       DIAG_ORIG_F

PURPOSE  Sent by DM to originate a call.

RESPONSE DMSS originates a call using the specified number.

===========================================================================*/

typedef struct
{
  BYTE cmd_code;       /* Command code */
  BYTE cnt;            /* number of digits in dialed_digits array */
  char dialed_digits[ NV_MAX_DIAL_DIGITS ];
  WORD so;
    /* desired service option - 0 = Reserved,  1 = Voice (IS96A), 2 = Loopback,
                  8001 = Voice (IS96), 8002 = Markov, 8003 = Data (see cai.h) */
} diag_orig_req_type;

/*===========================================================================

PACKET   diag_end_req_type

ID       DIAG_END_F

PURPOSE  Sent by DM to end a call.

RESPONSE DMSS ends the current call.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;    /* Command code */
} diag_end_req_type;

/*===========================================================================

PACKET   diag_dload_req_type

ID       DIAG_DLOAD_F

PURPOSE  Sent by external device to initiate a code download.

RESPONSE DMSS prepares to receive download. Packet acknowledged,  but
         normal processing ceases.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;            /* Command code */
} diag_dload_req_type;

/*===========================================================================

PACKET   diag_dload_write_req_type

ID       DLOAD_WRITE_F

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Sent by Dload program to write codes

RESPONSE Dload program order to DMSS for its action.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;
  BYTE addr_1st;
  BYTE addr_2nd;
  BYTE addr_3th;
  BYTE len_msb;
  BYTE len_lsb;
  BYTE tx_buf[TX_BUF_LEN];
} diag_dload_write_req_type;

/*===========================================================================

PACKET   diag_dload_erase_req_type

ID       DLOAD_ERASE_F

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Sent by Dload program to erase datas

RESPONSE Dload program order to DMSS for action.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;
  BYTE addr_1st;
  BYTE addr_2nd;
  BYTE addr_3th;
  BYTE len_msb;
  BYTE len_lsb;
} diag_dload_erase_req_type;

/*===========================================================================

PACKET   diag_dload_go_req_type

ID       DLOAD_GO_F

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Sent by Dload program to going to code address

RESPONSE Dload program order to DMSS for its action.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;
  BYTE seg_msb;
  BYTE seg_lsb;
  BYTE off_msb;
  BYTE off_lsb;
} diag_dload_go_req_type;

/*===========================================================================

PACKET   diag_dload_noop_req_type

ID       DLOAD_NOOP_F

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Sent by Dload program to test for com line.

RESPONSE Dload program order to DMSS for its action.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;
} diag_dload_noop_req_type;

/*===========================================================================

PACKET   diag_dload_ferase_req_type

ID       DLOAD_FLASH_ERASE_F

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Sent by Dload program to test for com line.

RESPONSE Dload program order to DMSS for its action.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;
} diag_dload_ferase_req_type;

/*===========================================================================

PACKET   diag_dload_param_req_type

ID       DLOAD_PARAM_F

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Sent by Dload program to check parameter of DMSS

RESPONSE Dload program order to DMSS for its action.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;
} diag_dload_param_req_type;



/*===========================================================================

PACKET   diag_dload_param_rsp_type

ID

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Received by Dload program to check parameter of DMSS

RESPONSE Parameter

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  BYTE version;
  BYTE min_version;
  BYTE max_write_msb;
  BYTE max_write_lsb;
} diag_dload_param_rsp_type;

/*===========================================================================

PACKET   diag_dload_ack_rsp_type

ID

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Received by Dload program to check ack of DMSS

RESPONSE Ack.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
} diag_dload_ack_rsp_type;

/*===========================================================================

PACKET   diag_dload_nak_rsp_type

ID

REF.     dloadm2i.typ, dloadm2.asm

PURPOSE  Received by Dload program to check ack of DMSS

RESPONSE Nak.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  BYTE reason_msb;
  BYTE reason_lsb;
} diag_dload_nak_rsp_type;

/*===========================================================================

PACKET   diag_tmob_req_type

ID       DIAG_TMOB_F

PURPOSE  Sent by external device to give a command to a test mobile.

RESPONSE Test Mobile takes appropriate action, send results or ack.

NOTE     Only sent by Tester DM and only processed by Tester Mobile.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  tmob_cmd_type   tmob_cmd;   /* Test Mobile command */
} diag_tmob_req_type;

//*===
//PACKET   diag_rxcal_req_type
//
//ID       DIAG_RXCAL_F
//
//=/==========================================================================*/
//typedef struct
//{
//  BYTE cmd_code;              /* Command code */
//  BYTE set_val;               /* Test Mobile command */
//} diag_rxcal_req_type;

/*===========================================================================

PACKET   diag_seq_num_req_type

ID       DIAG_SEQ_NUM_F

PURPOSE  Sent by external device to request that sequence numbers be included
         in packets.

RESPONSE The identical packet will be sent in response.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
} diag_seq_num_req_type;


/*===========================================================================

PACKET   diag_sleep_req_type

ID       DIAG_SLEEP_F

PURPOSE  Sent by external device to request that the portable stop sleeping,
         or resume sleeping

RESPONSE The diag_sleep_rsp_type will be sent in response

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  boolean sleep_mode;         /* 0 = turn sleeping off, 1 = turn it on */
} diag_sleep_req_type;


/*===========================================================================

PACKET   diag_systime_req_type

ID       DIAG_SYSTIME_F

PURPOSE  Sent by external device to obtain System Time from the mobile.

RESPONSE The diag_systime_rsp_type will be sent in response.  If the
         ping_cts field of the request was nonzero, the CTS pin on the
         serial port will be momentarily asserted at the specified
         System Time.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  boolean ping_cts;           /* 1 = ping the CTS line, 0 = don't */
} diag_systime_req_type;

// ysi 95c ftm 2000/9/24
typedef enum 
{
  FTM_ACQ_MODE_FULL,
  FTM_ACQ_MODE_MINI,
  FTM_ACQ_MODE_MICRO,
  ftm_acq_mode_sizer = 0x7FFFFFFF
} ftm_acq_mode_type;


/*--------------------------------------------------------------------------
                       FTM COMMAND STATUS ENUM TYPE
--------------------------------------------------------------------------*/
typedef enum 
{
  FTM_SUCCESS,
  FTM_INVALID_CMD,
  FTM_INVALID_STATE,
  FTM_NO_SUCCESS,
  ftm_cmd_status_sizer = 0x7FFFFFFF
  /* enforces the enums to be 32 bits */
} ftm_cmd_status_type;


/*--------------------------------------------------------------------------
                        BAND CLASS ENUM TYPE
--------------------------------------------------------------------------*/
typedef enum 
{
  FTM_BAND_CLASS_CELLULAR,
  FTM_BAND_CLASS_PCS,
  ftm_band_class_sizer = 0x7FFFFFFF
} ftm_band_class_type;

/*--------------------------------------------------------------------------
                        RADIO CONFIGURATION ENUM TYPES
--------------------------------------------------------------------------*/
typedef enum 
{
  FTM_FWD_RC_1=0x01,
  FTM_FWD_RC_2,
  FTM_FWD_RC_3,
  FTM_FWD_RC_4,
  FTM_FWD_RC_5,
  FTM_FWD_RC_1X_MAX,
  ftm_fwd_rc_sizer = 0x7FFFFFFF
} ftm_fwd_rc_type;

typedef enum 
{
  FTM_REV_RC_1=0x01,
  FTM_REV_RC_2,
  FTM_REV_RC_3,
  FTM_REV_RC_4,
  FTM_REV_RC_1X_MAX,
  ftm_rev_rc_sizer = 0x7FFFFFFF
} ftm_rev_rc_type;

typedef enum 
{
  FTM_REV_FCH_FULL_RATE=0x00,
  FTM_REV_FCH_HALF_RATE=0x01,
  FTM_REV_FCH_QTR_RATE=0x02,
  FTM_REV_FCH_8TH_RATE=0x03,
  ftm_rev_fch_rate_sizer = 0x7FFFFFFF
} ftm_rev_fch_rate_type;

typedef enum 
{
  FTM_REV_SCH_1_5_RATE=0x00,
  FTM_REV_SCH_2_7_RATE=0x01,
  FTM_REV_SCH_4_8_RATE=0x02,
  FTM_REV_SCH_9_6_RATE=0x03,
  FTM_REV_SCH_19_2_RATE=0x04,
  FTM_REV_SCH_38_4_RATE=0x05,
  FTM_REV_SCH_76_8_RATE=0x06,
  FTM_REV_SCH_153_6_RATE=0x07,
  ftm_rev_sch_rate_sizer = 0x7FFFFFFF
} ftm_rev_sch_rate_type;


/*--------------------------------------------------------------------------
                        CHANNEL SPREAD RATE ENUM TYPE
--------------------------------------------------------------------------*/
typedef enum
{
  FTM_RATE_1X,
  FTM_RATE_2X,
  FTM_RATE_4X,
  FTM_RATE_8X,
  FTM_RATE_16X,
  ftm_spread_rate_sizer = 0x7FFFFFFF
} ftm_spread_rate_type;


/*--------------------------------------------------------------------------
                        CODING TYPE ENUM TYPE
--------------------------------------------------------------------------*/

typedef enum
{
   FTM_DECODE_CONVOLUTIONAL,
   FTM_DECODE_TURBO,
   ftm_decoding_sizer = 0x7FFFFFFF
} ftm_coding_type;


/*--------------------------------------------------------------------------
                        WALSH CODE/QOF  SPECIFIER TYPE
--------------------------------------------------------------------------*/
typedef struct 
{
  byte walsh;    /* walsh channel number (0-63 for 95A/B, 0-127 for cdma2000) */

  byte qof_mask_id;  /* quasi orthoganal function mask (0-3) where 0 is 
                        true walsh codes */
} ftm_walsh_type;

/*--------------------------------------------------------------------------
             Structure for the FTM Fast Forward Power Control Parameters
--------------------------------------------------------------------------*/
typedef struct
{
  byte  target_fer;
  byte  min_setpt;
  byte  max_setpt;
} ftm_fpc_olc_param_type;


typedef struct
{
   ftm_band_class_type band_class;
     /* the band class, Cellular or PCS */

   word cdma_freq;
     /* the cdma frequency channel */

   ftm_acq_mode_type acq_mode;
     /* the acquisition mode, Full, Mini, Micro */
} ftm_cmd_acq_pilot_param_type;

typedef struct
{
   ftm_fwd_rc_type radio_cfg;
   /* the radio configuration of this FCH */

   ftm_walsh_type walsh;
     /* walsh index */

   boolean bypass_lc;
     /* bypass long code (long code set to all zero) */

   byte frame_offset;
     /* frame offset */

   byte subchan_gain;
     /* Power control subchannel gain */

   boolean ffpc_enable;
     /* fast forward power control enable */

   dword fpc_mode;
     /* forward power control mode */

   byte init_setpt;
     /* initial set point for inner loop FPC on FCH */

   ftm_fpc_olc_param_type  olc_params;
   /* outer loop power control parameters */

} ftm_cmd_demod_fch_param_type;

typedef struct
{
   ftm_fwd_rc_type radio_cfg;
   /* the radio configuration of this SCH */

   ftm_walsh_type walsh;
   /* walsh index */

   ftm_spread_rate_type sch_rate;
   /* from 1X - 16X */

   ftm_coding_type coding_type;
   /* Convolutional or Turbo */

   boolean ffpc_enable;
     /* fast forward power control enable */

   dword fpc_mode;
     /* forward power control mode */

   byte init_setpt;
     /* initial set point for inner loop FPC on FCH */

   ftm_fpc_olc_param_type  olc_params;
   /* outer loop power control parameters */

} ftm_cmd_demod_sch_param_type;

typedef struct
{
   ftm_rev_rc_type radio_cfg;
     /* Reverse FCH radio config */

   byte frame_offset;
     /* frame offset */

   ftm_rev_fch_rate_type fch_rate;

   boolean enable_rpc;
     /* Enable/disable reverse power control */

   word num_preambles;
     /* Preamble count for traffic channel initialization */

   dword tx_pattern;
     /* 32 bit pattern of bytes to use in the traffic frames */
} ftm_cmd_mod_fch_param_type;


typedef struct
{
   ftm_rev_rc_type radio_cfg;
     /* Reverse FCH radio config */

   ftm_rev_sch_rate_type sch_rate;
     /* Rate of reverse SCH from */

   ftm_coding_type coding_type;
     /* turbo or convolutional */

   dword tx_pattern;
     /* 32 bit pattern of bytes to use in the traffic frames */
} ftm_cmd_mod_sch_param_type;


typedef struct
{
   boolean rev_power_control;
     /* Reverse power control enable/disable */

   byte adjust_value;
     /* closed loop power control accumulator value */
} ftm_cmd_mod_pc_param_type;
/* ftm_packed_param_type is a union of all the above command 
 * parameters.  All ftm commands take this type as the argument */

typedef struct
{
   word rf_test_cmd;
 
  union 
  {
    word                    gen_w;      /* Generic word                      */
    byte                    gen_b;      /* Generic byte                      */
    dword                   gen_d;      /* Generic dword                     */
    word                    chan;       /* For tuning to a specific channel  */
    boolean                 on_off;     /* For anything with an on_off state */
    mode_id_type            mode;       /* For Setting Phone operation mode  */
    pa_range_type           range;      /* Set the LNA/PA range              */
    test_id_val_type        id_val;     /* For all indexed values            */
    test_byte_type          byte_struct;
  }  ftm_rf_factory_data;
  /* union of RF commands data types */
} ftm_rf_factory_parms;
typedef union {
  ftm_cmd_acq_pilot_param_type  acq;   /* acquisition */
  ftm_cmd_demod_fch_param_type  f_fch; /* forward FCH */
  ftm_cmd_demod_sch_param_type  f_sch; /* forward SCH */
  ftm_cmd_mod_fch_param_type r_fch;    /* reverse FCH */
  ftm_cmd_mod_sch_param_type r_sch;    /* reverse SCH */
  ftm_rf_factory_parms rf_params;
//  hwtc_sbi_factory_parms sbi_params;
} ftm_packed_param_type;

typedef enum {
  FTM_FIRST_CMD = 100,
  FTM_ACQUIRE_SC = 100,
  FTM_SYNC_SC =    101,
  FTM_FWD_FCH_SC = 102,
  FTM_FWD_SCH_SC = 103,
  FTM_REV_FCH_SC = 104,
  FTM_REV_SCH_SC = 105,
  FTM_FCH_LOOP_SC = 106,
  FTM_SCH_LOOP_SC = 107,
  FTM_RELEASE_SC = 108,
  FTM_POWER_CONTROL_SC = 109,
  FTM_MAX_CMD = 110 //ysi 2001/2/20
} ftm_subcmd_type;

/*===========================================================================

PACKET   diag_ftm_req_type

ID       DIAG_FTM_CMD_F

PURPOSE  Sent by DM to request Factory Test Mode commands.

RESPONSE DMSS sends back status of the requested command.

===========================================================================*/
typedef struct
{
  byte cmd_code;
  word sub_cmd;
  word length;      /* Length of the request[] */
  ftm_packed_param_type ftm_data;
//  byte request[1];  /* Actual data content varies with request */
} diag_ftm_req_type;

//----> ftm ysi end
/*--------------------------------------------------------------------------
   Device types that may talk to the diag task.  These masks are used to
   define permissions for packet processing in the dispatch table.

   Until a registration packet is received, DEV_UNKNOWN is assumed.

--------------------------------------------------------------------------*/
#define DEV_UNKNOWN   0x0001  /* Unknown device type. */
#define DEV_DM        0x0002  /* Only a Diagnostic Monitor may request
                                 this packet. */
#define DEV_ANY       0xFFFF  /* Any device may request this packet */
#define DEV_NONE      0x0000  /* No device may request this packet --
                                 this disables processing of the packet
                                 type */

/*---------------------------------------------------------------------------
   Operating modes for packet processing.  These masks are used to define
   permissions for packet processing in the dispatch table.
---------------------------------------------------------------------------*/
#define MODE_OFF_DIG  0x0001  /* Packet accepted in offline-digital        */
#define MODE_OFF_ANA  0x0002  /* Packet accepted in offline-analog         */
#define MODE_ONLINE   0x0004  /* Packet accepted in online                 */
#define MODE_ANY      0xFFFF  /* Packet may be processed in any mode.      */

#define MODE_OFFLINE  ( MODE_OFF_DIG | MODE_OFF_ANA )
                              /* Packet accepted in either offline mode    */
/*===========================================================================

PACKET   diag_fs_op_req_type

ID       DIAG_FS_OP_F

PURPOSE  This message requests a filesystem operation.  This message contains
         sub-commands to specify which file system operation to perform.
         It is a variable length request message - depending on the file
         system operation.

RESPONSE The diag_fs_op_rsp_type will be sent in response.

===========================================================================*/
typedef enum
{
  DIAG_FS_MK_DIR,                    /* Create directory                */
  DIAG_FS_RM_DIR,                    /* Remove Directory                */
  DIAG_FS_DISP_DIRS,                 /* Display directories list        */
  DIAG_FS_DISP_FILES,                /* Display file list               */
                                     /* NOTE: Display ops are temporary 
                                        implementations                 */ 
  DIAG_FS_READ_FILE,                 /* Read a file in FS               */
  DIAG_FS_WRITE_FILE,                /* Write a file in FS              */  
  DIAG_FS_REMOVE_FILE,               /* Remove a file from FS           */  
  DIAG_FS_GET_ATTRIB,                /* Get file attributes             */
  DIAG_FS_SET_ATTRIB,                /* Set file attributes             */
  DIAG_FS_REMOTE_LINK,               /* Create a remote file link       */
  DIAG_FS_ITER_DIRS,                 /* Iterative display directories   */
  DIAG_FS_ITER_FILES,                /* Iterative display files         */
  DIAG_FS_LAST_OP                    /* Last OP.  Range checking.       */
} diag_fs_op_enum_type;

/*--------------------------------------------------------------
   Generic structure definitions used in multiple operations.
--------------------------------------------------------------*/

#define DIAG_FS_MAX_FILENAME_LEN      60 /* Specified by FS              */
#define DIAG_FS_MAX_FILE_BLOCK_SIZE   256 /* Limited by req buffer of 256 */

typedef struct
{
  BYTE len;                            /* Length of filename string 
                                          including NULL terminating char   */
  char name[DIAG_FS_MAX_FILENAME_LEN]; /* Filename string.  NULL terminated.
                                          Valid data len == filename_len+1  */
} diag_fs_filename_type;

typedef struct
{
  WORD len;                               /* Length of data block */
  BYTE data[2500];//[DIAG_FS_MAX_FILE_BLOCK_SIZE]; /* Data block           */
} diag_fs_data_block_type;

/* File attribute mask */
//Need to restrict to these values only.  -LD
typedef enum {
  DIAG_FS_FA_UNRESTRICTED =0x00FF,  /* No file access restrictions           */
  DIAG_FS_FA_PERMANENT    =0x007F,  /* File can't be removed nor truncated   */
  DIAG_FS_FA_READONLY     =0x00BF,  /* File can't be opened for update       */
  DIAG_FS_FA_SYS_PERMANENT=0x0037,  /* File persists across system reformats */
  DIAG_FS_FA_REMOTE       =0x001F   /* Remote file (resides outside file     */
                                    /* system address space)                 */
} diag_fs_attribute_mask_type;     

/* File OPEN operation buffering options */
typedef enum {
  DIAG_FS_OB_PROHIBIT,             /* Prohibit file buffering                */
  DIAG_FS_OB_ALLOW                 /* Allow file buffering                   */
} diag_fs_buffering_option_type;

/* File OPEN operation clean-up options */
typedef enum {
  DIAG_FS_OC_CLOSE     = 0x00, /* Close file as-is                           */
  DIAG_FS_OC_DISCARD   = 0x01, /* Delete file and remove it from directory   */
  DIAG_FS_OC_TRUNCATE  = 0x02, /* Truncate file from specified position      */
  DIAG_FS_OC_REVERT    = 0x03  /* Revert to last checkpointed version        */
} diag_fs_cleanup_option_type;

typedef struct
{
  WORD      attribute_mask;  /* Use diag_fs_attribute_mask_type   */
  BYTE    buffering_option;  /* Use diag_fs_buffering_option_type */
  BYTE      cleanup_option;  /* Use diag_fs_cleanup_option_type   */
} diag_fs_attributes_type;

/*-------------------------------------------------------
  Definitions of data for specific operations.
-------------------------------------------------------*/
/* "Create Directory" operation */
typedef diag_fs_filename_type diag_fs_mkdir_req_type;

/* "Remove Directory" operation */
typedef diag_fs_mkdir_req_type diag_fs_rmdir_req_type;

/* "Display Directory List" operation */
typedef diag_fs_filename_type diag_fs_disp_dirs_req_type;

/* "Display File List" operation */
typedef diag_fs_disp_dirs_req_type diag_fs_disp_files_req_type;

/* "Read File" operation */
typedef struct
{
  BYTE seq_num;                        /* Sequence number for mult blocks */
  
  diag_fs_filename_type filename_info; /* File name info                  */
                                       /* Used only if seq_num == 0       */
} diag_fs_read_req_type;

/* "Write File" operation */
typedef enum
{
  DIAG_FS_NO_OVERWRITE = 0,
  DIAG_FS_OVERWRITE    = 1
} diag_fs_write_mode_enum_type;

typedef struct
{ 
  BYTE                          mode; /* Use diag_fs_write_mode_enum_type  */
  DWORD                 total_length; /* Total length of this file         */
  diag_fs_attributes_type     attrib; /* Attributes for this file          */
  
   union
  {
    diag_fs_filename_type  name_info;    /* File name info                 */
    BYTE raw_data[sizeof(diag_fs_filename_type) +
                  sizeof(diag_fs_data_block_type)];
                                         /* Full possible size of variable
                                            length buffer                  */
  } var_len_buf;
} diag_fs_write_begin_req_type;

typedef union
{
  diag_fs_write_begin_req_type  begin; /* First block of a write           */
  diag_fs_data_block_type      subseq; /* Subsequent blocks for write      */
} diag_fs_write_block_type;

typedef struct
{
  BYTE    seq_num;                        /* Sequence number for mult blocks    */
  BYTE    more;                        /* Flag if more packets are needed to
                                          complete write                     */
  diag_fs_write_block_type     block;  /* Block for this portion of the file */
} diag_fs_write_req_type;

/* "Get File Attributes" operation */
typedef diag_fs_filename_type diag_fs_get_attrib_req_type;

/* "Set File Attributes" operation */
typedef struct
{
  diag_fs_attributes_type       attribs;
  DWORD                   creation_date;
  diag_fs_filename_type   filename_info;
} diag_fs_set_attrib_req_type;

/* "Remove File" operation */
typedef diag_fs_filename_type diag_fs_rmfile_req_type;

/* "Remote File Link" operation */
typedef struct
{
  DWORD               base_address;
  DWORD                     length;
  diag_fs_filename_type  name_info;
} diag_fs_remote_link_req_type;

/* "Iterate Directories" operation */
typedef struct
{
  DWORD seq_num;
  diag_fs_filename_type dir_name;
} diag_fs_iter_dirs_req_type;

/* "Iterate Files" operation */
typedef struct
{
  DWORD seq_num;
  diag_fs_filename_type dir_name;
} diag_fs_iter_files_req_type;

/* Union of all possible operations.  Determined by cmd_code */
typedef union
{                               
  BYTE                             seq_num; /* Seq number in same place for
                                               all packets that use them */
  diag_fs_mkdir_req_type             mkdir;
  diag_fs_rmdir_req_type             rmdir;
  diag_fs_read_req_type               read;
  diag_fs_write_req_type             write;
  diag_fs_disp_dirs_req_type     disp_dirs;
  diag_fs_disp_files_req_type   disp_files;
  diag_fs_get_attrib_req_type   get_attrib;
  diag_fs_set_attrib_req_type   set_attrib;
  diag_fs_rmfile_req_type           rmfile;
  diag_fs_remote_link_req_type remote_link;
  diag_fs_iter_dirs_req_type     iter_dirs;
  diag_fs_iter_files_req_type   iter_files;
} diag_fs_req_type;

typedef struct
{
  BYTE cmd_code;                /* Command code                  */
  BYTE file_op;                 /* From diag_fs_op_enum_type     */
  diag_fs_req_type fs_req;      /* Filesystem request data union */
} diag_fs_op_req_type;

/*===========================================================================

PACKET   diag_cal_req_type

ID       DIAG_RX_CAL_F / DIAG_TX_CAL_F

PURPOSE  read / write calibration data

RESPONSE

============================================================================*/
typedef struct
{
  BYTE cmd_code;                /* Command code */
  WORD agc_value;               /* agc value */
} diag_cal_req_type;

/*===========================================================================

PACKET   diag_cal_test_req_type

ID       DIAG_CAL_F

PURPOSE  Sent by DM to direct the DMSS to perform a calibration test.

RESPONSE DMSS performs the test, then responds.

//4.03-1 OJS 2002.3.25
===========================================================================*/
typedef struct {
  byte                   cmd_code;
  diag_cal_test_enum_type  test_code;
  diag_cal_test_data_type  data;
} diag_cal_test_req_type;



// 2004/2/27 thunder - VX8000
typedef struct
{
  BYTE cmd_code;
  BYTE subsys_id ;
  WORD subsys_cmd;
//  diagpkt_subsys_header_type xx_hdr;

  int  call_state;                 // ENUM for EVENT_ID 416
  int  oprt_mode;                  // ENUM for EVENT_ID 417
  int  system_mode;                // ENUM for EVENT_ID 418
  int  mode_pref;                  // ENUM for EVENT_ID 520
  int  band_pref;                  // ENUM for EVENT_ID 521
  int  roam_pref;                  // ENUM for EVENT_ID 522
  int  srv_domain_pref;            // ENUM for EVENT_ID 523
  int  acq_order_pref;             // ENUM for EVENT_ID 524
  int  hybr_pref;                  // ENUM for EVENT_ID 525
  int  network_sel_mode_pref;      // ENUM for EVENT_ID 526

} diag_cm_state_type;

// 2004/4/1 thunder - VX8000
typedef enum
{
  DIAG_RS232_CONFIG_INFO = 0,	/* Request for baud rate capabilities */
  DIAG_RS232_CONFIG,		/* Set baud rate                      */
  DIAG_USB_CONFIG_INFO,		/* UNIMPLEMENTED!!!                   */
  DIAG_USB_CONFIG		/* UNIMPLEMENTED!!!                   */
}
diag_config_comm_enum_type;

typedef struct
{
  byte cmd_code;		/* Command code                         */
  byte sub_cmd;			/* Use diag_config_comm_enum_type       */
  dword baudrate;		/* Baud rate to be set - use only in a  */
  /* config command, not an info request  */
}
diag_config_comm_req_type;

typedef struct
{
  byte cmd_code;		/* Command code                   */
  byte sub_cmd;			/* Use diag_config_comm_enum_type */

  union
  {
    boolean success;		/* TRUE if baud rate change ACK   */
    byte num_options;		/* Number of options following    */
  }
  cmd_specific;

  /* The following only exist if responding to an info request.    */

  dword baudrate[4];		/* Baud rates available           */
  /* Only used if num_options is nonzero */
}
diag_config_comm_rsp_type;
//sandman -----------------------------------------------------------------------------
typedef struct{
  BYTE cmd_code;
  BYTE subsys_id;
  WORD subsys_cmd;
  ftm_packed_param_type	cmd_ptr;
}  diag_ftm_rsp_pkt_type;

typedef struct{
  BYTE cmd_code;
  BYTE subsys_id ;
  WORD subsys_cmd;
  ftm_packed_param_type	cmd_ptr;
}  diag_ftm_req_pkt_type;
typedef struct
{
	byte			cmd_code;
	word			what_to_do;
	word			what_1;
	signed short	what_2;
	byte			what_3;
	byte			what_4;
	signed char		what_5;
} toolsdiag_lgf_req_type;

// 2004/4/29 thunder - EVDO
typedef struct
{
  BYTE cmd_code;
  BYTE subsys_id ;
  WORD subsys_cmd;

//	diagpkt_subsys_header_type xx_hdr;

  BYTE	at_state;
  BYTE	session_state;
  BYTE	almp_state;
  BYTE	init_state;
  BYTE	idle_state;
  BYTE	conn_state;
  BYTE	rup_state;
  BYTE	ovhd_state;
  BOOL	hybrid_mode;   /* hybrid mode flag TRUE=ON, FALSE=OFF */

} hdrdiag_state_type;
/*===========================================================================


Union of packet types which convey requests from the Diagnostic Monitor to
   the Mobile

===========================================================================*/

typedef union
{
  gen_byte_and_word_type   byte_and_word;	//+[WCMDA] vivache : SH100
  BYTE                       cmd_code;
  diag_verno_req_type           verno;
  diag_verstr_req_type         verstr;
  diag_esn_req_type               esn;
  diag_peek_req_type             peek;
  diag_pokeb_req_type           pokeb;
  diag_pokew_req_type           pokew;
  diag_poked_req_type           poked;
  diag_vpoke_req_type           vpoke;
  diag_vpeek_req_type           vpeek;
  diag_outp_req_type             outp;
  diag_outpw_req_type           outpw;
  diag_inp_req_type               inp;
  diag_inpw_req_type             inpw;
  diag_status_req_type           stat;
  diag_logmask_req_type       logmask;
  diag_log_req_type               log;
  diag_nv_peek_req_type       nv_peek;
  diag_nv_poke_req_type       nv_poke;
  diag_tagraph_req_type       tagraph;
  diag_markov_req_type         markov;
  diag_markov_reset_req_type  m_reset;
  diag_diag_ver_req_type     diag_ver;
  diag_ts_req_type                 ts;
  diag_ta_parm_req_type       ta_parm;
  diag_msg_req_type           msg_req;
  diag_hs_key_req_type         hs_key;
  diag_hs_lock_req_type       hs_lock;
  diag_screen_req_type     screen_req;
  diag_parm_get_req_type     parm_get;
  diag_parm_set_req_type     parm_set;
  diag_nv_read_req_type       nv_read;
  diag_nv_write_req_type     nv_write;
  diag_reg_req_type               reg;
  diag_conf_req_type             conf;
  diag_control_req_type          cont;
  diag_err_req_type           err_req;
  diag_err_clr_req_type       err_clr;
  diag_ser_reset_req_type   ser_reset;
  diag_ser_report_req_type ser_report;
  diag_test_req_type             test;
  diag_dipsw_req_type       dipsw_req;
  diag_voc_pcm_lb_type     vocpcm_req;
  diag_voc_pkt_lb_type     vocpkt_req;
  diag_orig_req_type             orig;
  diag_end_req_type               end;
  diag_dload_req_type           dload;
  diag_dload_write_req_type     write;      /* CBK - Insert for dloading code */
  diag_dload_erase_req_type     erase;      /* CBK - Insert for dloading code */
  diag_dload_go_req_type           go;      /* CBK - Insert for dloading code */
  diag_dload_noop_req_type       noop;      /* CBK - Insert for dloading code */
  diag_dload_ferase_req_type   ferase;      /* CBK - Insert for dloading code */
  diag_dload_param_req_type     param;      /* CBK - Insert for dloading code */
  diag_tmob_req_type             tmob;
  diag_seq_num_req_type   seq_num_req;
  diag_sleep_req_type       sleep_req;
  diag_systime_req_type   systime_req;
  diag_state_req_type       state_req;
  diag_rxcal_req_type           rxcal;
  diag_rxcal3000_req_type   rxcal3000;	// 1999. 3. 4 CKK for MSM3000
  diag_txcal_req_type           txcal;
  diag_misc_cal_req_type     misc_cal;
  diag_misc_cal3000_req_type     misc_cal3000;	// 1999. 4. 13 CKK for MSM3000
  diag_tdmb_req_type tdmb;
  diag_misc_calInreCube_req_type misc_cal_Inter; //OJS InterCube������...
  diag_spc_req_type           spc_req;

//sya-----start
  diag_pilot_sets_req_type pilot_sets;
  diag_parm_get2_req_type   parm_get2;
  diag_ser_mode_chng_req_type  ser_mode_chng;
  diag_get_rssi_req_type    get_rssi;
  diag_password_req_type    password_req;
  diag_pr_list_wr_req_type  pr_list_wr_req;
  diag_pr_list_wr3000_req_type  pr_list_wr3000_req;
  diag_pr_list_rd_req_type  pr_list_rd_req;
//sya-----end
  diag_fs_op_req_type              fs_op;
  diag_ftm_req_type                 ftm;     // ysi 95c ftm 2000/9/24
  diag_cal_req_type        cal;
  diag_cal_test_req_type            cal_test_req;//4.03-1 OJS 2002.3.25//OJS SP3100
  // Revision Read //
  diag_sw_sub_rev_req_type		sw_sub_rev;
  diag_test_mode_req_type		test_mode;	
  diag_ftm_req_pkt_type         ftm_req; 
  toolsdiag_lgf_req_type		tools_req;
// 2004/2/27 thunder - VX8000  
  diag_cm_state_type         cm_state;
// 2004/4/1 thunder - VX8000
  diag_config_comm_req_type	config_comm;
// 2004/4/29 thunder - VX8000  
  hdrdiag_state_type        hdr_state;
} diag_req_type;

/*--------------------------------------------------------------------------
  Define the structure for the incoming packet.  The sio services place the
  crc BYTE into the packet for us, so a buffer will have a packet plus the
  crc.
--------------------------------------------------------------------------*/


typedef struct
{
//sio_hdr_type         hdr;             /* Remove it for async_hdlc_format by CBK */
  diag_req_type        req;
  sio_hdlc_trl_type    trl;
} diag_req_pkt_type;

/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/*     Communication from the Mobile to the Diagnostic Monitor             */
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/


/*============================================================================

PACKET   diag_verno_rsp_type

ID       DIAG_VERNO_F

PURPOSE  Sent by the DMSS, contains version and date information

============================================================================*/
#define VERNO_DATE_STRLEN 11
#define VERNO_TIME_STRLEN  8
#define VERNO_DIR_STRLEN   8

typedef struct
{
  BYTE cmd_code;                              /* Command code               */
  char comp_date[ VERNO_DATE_STRLEN ];        /* Compile date Jun 11 1991   */
  char comp_time[ VERNO_TIME_STRLEN ];        /* Compile time hh:mm:ss      */
  char rel_date [ VERNO_DATE_STRLEN ];        /* Release date               */
  char rel_time [ VERNO_TIME_STRLEN ];        /* Release time               */
  char ver_dir  [ VERNO_DIR_STRLEN ];         /* Version directory          */
  BYTE scm;                                   /* Station Class Mark         */
  BYTE mob_cai_rev;                           /* CAI rev                    */
  BYTE mob_model;                             /* Mobile Model               */
  WORD mob_firm_rev;                          /* Firmware Rev               */
  BYTE slot_cycle_index;                      /* Slot Cycle Index           */
  BYTE voc_maj;                                  /* Vocoder major version                */
  BYTE voc_min;                /* Vocoder minor version                */
} diag_verno_rsp_type;


/*===========================================================================

PACKET   diag_verstr_rsp_type

ID       DIAG_VERSTR_F

PURPOSE  Sent by the DMSS, contains string version number

===========================================================================*/
#define VERSTR_STRLEN 33
typedef struct
{
  BYTE cmd_code;
  char version[ VERSTR_STRLEN ];
} diag_verstr_rsp_type;


/*===========================================================================

PACKET   diag_esn_rsp_type

ID       DIAG_ESN_F

PURPOSE  Sent by DMSS, contains ESN in DWORD format

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  DWORD  esn;                  /* Electronic Serial Number */
} diag_esn_rsp_type;


/*===========================================================================

PACKET   diag_peekb_rsp_type

ID       DIAG_PEEKB_F

PURPOSE  Sent by DMSS, contains values requested in diag_peekb_req_type

============================================================================*/

/* No special response type is required for Poke, OUTP or OUTPW.  In
   these cases the received request types are returned to the Diagnostic
   Monitor because the Diagnostic Monitor does not require further
   information */

#define DIAG_MAX_PEEK_B 16
  /* Maximum number of BYTEs that can be requested in one Peekb request */

/* Peekb Response type */
typedef struct
{
  BYTE cmd_code;               /* Command code */
  BYTE far *ptr;               /* starting address for peek operation */
  WORD length;                 /* number of BYTEs to be returned */
  BYTE data[DIAG_MAX_PEEK_B];  /* BYTEs from memory */
} diag_peekb_rsp_type;


/*===========================================================================

PACKET   diag_peekw_rsp_type

ID       DIAG_PEEKW_F

PURPOSE  Sent by DMSS, contains values requested in diag_peekw_req_type

============================================================================*/
#define DIAG_MAX_PEEK_W  8
  /* Maximum number of WORDs that can be requested in one Peekw request */

/* Peekw Response type */
typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD far *ptr;               /* starting address for peek operation */
  WORD length;                 /* number of WORDs to be returned */
  WORD data[DIAG_MAX_PEEK_W];  /* WORDs from memory */
} diag_peekw_rsp_type;


/*==========================================================================

PACKET   diag_peekd_rsp_type

ID       DIAG_PEEKD_F

PURPOSE  Sent by DMSS, contains DWORDs requested in diag_peekd_req_type

===========================================================================*/
#define DIAG_MAX_PEEK_D  4
  /* Maximum number of DWORDs that can be requested in one Peekd request */

/* Peekd Response type */
typedef struct
{
  BYTE cmd_code;               /* Command code */
  DWORD far *ptr;              /* starting address for peek operation */
  WORD length;                 /* number of DWORDs to be returned */
  DWORD data[DIAG_MAX_PEEK_D]; /* DWORDs from memory */
} diag_peekd_rsp_type;

/*===========================================================================

PACKET   diag_vpeek_rsp_type

ID       DIAG_VPEEK_F

PURPOSE  Sent by DMSS, contains the vocoder peek data requested

============================================================================*/
#define DIAG_VPEEK_SIZE 8
  /* Number of WORDs returned from one Vocoder Peek request */

typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD addr;                   /* starting address for peek operation */
  WORD data[DIAG_VPEEK_SIZE];  /* WORDs from memory */
} diag_vpeek_rsp_type;


/*===========================================================================

PACKET   diag_inp_rsp_type

ID       DIAG_INP_F

PURPOSE  Sent by DMSS, contains the BYTE input from io port

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD port;                   /* port read from */
  BYTE data;                   /* value read from port */
} diag_inp_rsp_type;


/*==========================================================================

PACKET   diag_inpw_rsp_type

ID       DIAG_INPW_F

PURPOSE  Sent by DMSS, contains the WORD input from io port

==========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD port;                   /* port that was read from */
  WORD data;                   /* value read from port */
} diag_inpw_rsp_type;
//choi
/*===========================================================================

PACKET   diag_rxcal_rsp_type

ID       DIAG_RXCAL_F

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  BYTE ok_nok;               /* Test Mobile command */
  BYTE rlt_val;               /* Test Mobile command */
  BYTE srched_val;               /* Test Mobile command */
} diag_rxcal_rsp_type;

/*===========================================================================

  1999. 3. 4 CKK for MSM3000

PACKET   diag_rxcal3000_rsp_type

ID       DIAG_RXCAL_F

===========================================================================*/
typedef struct
{
  BYTE	cmd_code;		/* Command code */
  BYTE	ok_nok;			/* Test Mobile command */
  WORD	rlt_val;		/* Test Mobile command - pdm */
  WORD	srched_val;		/* Test Mobile command - agc_value */
  BYTE	cal_rsp_msb;
  BYTE	cal_rsp_lsb;
} diag_rxcal3000_rsp_type;

/*===========================================================================

PACKET   diag_txcal_rsp_type

ID       DIAG_TXCAL_F

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
  WORD  link;                  /* returned value from phone
                                 to verify the link between phone adn hhp
									   */
  BYTE hdet_ok;               /* 0 : hdet value has been read good. 
  										   1 : hdet value has not been read.
										*/
  WORD hdet_val;              /* hdet value read from ADC meaning 
  										  only when hdet_ok is 0.
									  */
} diag_txcal_rsp_type;
//choi
/*==========================================================================

PACKET   diag_status_rsp_type

ID       DIAG_STATUS_F

PURPOSE  Sent by DMSS, contains status information

===========================================================================*/
typedef struct {
  BYTE    cmd_code;               /* Command code                      0  */
  BYTE    demod;                  /* Demod id BYTE                     1  */
  BYTE    decode;                 /* Decoder id BYTE                   2  */
  BYTE    inter;                  /* Interleaver id BYTE               3  */
  DWORD   esn;                    /* Mobile Electronic Serial Number 4-7  */
  
  WORD    rf_mode;                /* 0->analog,  1->cdma,  2->pcn    8-9  */
  DWORD   min1[NV_MAX_MINS];      /* all MIN1s      8               10-17  */
  WORD    min2[NV_MAX_MINS];      /* all MIN2s      4               18-21  */
  BYTE    orig_min;               /* index (0-3) of the orig MIN       22 */

  WORD    cdma_rx_state;          /* current state for cdma only    23-24 */
  BYTE    cdma_good_frames;       /* whether or not frames we are      25
                                     receiving are good -- cdma only      */
  WORD    analog_corrected_frames;/* good frame count - analog only 25-27 */
  WORD    analog_bad_frames;      /* bad frame count - analog only  28-29 */
  WORD    analog_word_syncs;      /*  -- analog only                30-31 */

  WORD    entry_reason;           /* entry reason                   32-33 */
  WORD    curr_chan;              /* center frequency channel       34-35 */
  BYTE    cdma_code_chan;         /* code for current channel-cdma only36 */
  WORD    pilot_base;             /* pilot pn of current cell-cdma o37-38 */

  WORD    sid;                    /* Current System ID              39-40 */
  WORD    nid;                    /* Current Network ID             41-42 */
  WORD    locaid;                 /* Current Location ID            43-44 */
  WORD    rssi;                   /* Current RSSI level             45-46 */
  BYTE    power;                  /* Current mobile output power level 47 */
} diag_status_rsp_type;


/*===========================================================================

PACKET   diag_logmask_rsp_type

ID       DIAG_LOGMASK_F

PURPOSE  Sent by DMSS, acknowledges that logmask was set.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
} diag_logmask_rsp_type;


/*===========================================================================

PACKET   diag_log_rsp_type

ID       DIAG_LOG_F

PURPOSE  Sent by DMSS, contains log data saved according to the log mask
         Note that this is a variable size packet.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  BYTE more;                   /* Indicates how many log entries, not
                                   including the one returned with this
                                   packet, are queued up in the Mobile
                                   Station */
  WORD len;                    /* Indicates the length, in BYTEs, of the
                                   following log entry */
  log_type log;                /* Contains the log entry data. */
} diag_log_rsp_type;


/*===========================================================================

PACKET   diag_err_type

IDs      DIAG_BAD_CMD_F
         DIAG_BAD_PARM_F
         DIAG_BAD_LEN_F
         DIAG_BAD_VOC_F
         DIAG_BAD_MODE_F

PURPOSE  Sent by DMSS when it detects an erroneous packet from DM. Errors
         include command code out of bounds, bad length...  Includes the
         first DIAG_MAX_ERR BYTEs of the offending input packet.

============================================================================*/
#define DIAG_MAX_ERR 16
  /* maximum number of BYTEs (starting with the first BYTE of the packet )
     from the received packet which will be echoed back to the
     Diagnostic Monitor if an error is detected in the packet */

/* Type to communicate an error in a received packet */
typedef struct
{
  BYTE cmd_code;               /* Command code */
  BYTE pkt[DIAG_MAX_ERR];      /* first 16 BYTEs of received packet */
} diag_err_type;


/*===========================================================================

PACKET   diag_nv_peek_rsp_type

ID       DIAG_NV_PEEK_F

PURPOSE  Sent by DMSS, contains NV memory data requested in a
         diag_nv_peek_rsp_type packet.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  nv_peek_type  peeknv;        /* The nv definition of a peek item */
} diag_nv_peek_rsp_type;


/*===========================================================================

PACKET   diag_tagraph_rsp_type

ID       DIAG_TAGRAPH_F

PURPOSE  Sent by DMSS, contains Temporal Analyzer data for the small
         window.

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  BYTE  rx_rssi;               /* Current value of rx agc register */
// ysi 95c ftm
  DWORD  adj_rssi;              /* Current value of tx gain adjust register */
  DWORD  tx_voc;                /* Current tx vocoder data rate */
  DWORD  rx_voc;                /* Current rx vocoder data rate */
  DWORD bad_frames;            /* Number of bad frames */
  DWORD total_frames;          /* Number of all the frames */
} diag_tagraph_rsp_type;


/*===========================================================================

PACKET   diag_markov_rsp_type

ID       DIAG_MARKOV_F

PURPOSE  Sent by DMSS, contains Markov processing statistics.  Sent when
         requested with a diag_markov_req_type packet.

============================================================================*/
/* Definitions of values for the mode field - service option */
#define DIAG_SO_NONE       0x00
#define DIAG_SO_VOICE      0x01
#define DIAG_SO_LOOPBACK   0x02
#define DIAG_SO_MARKOV     0x03
#define DIAG_SO_DATA       0x04
#define DIAG_SO_VOICE_96A  0x05
#define DIAG_SO_VOICE13      0x06    /* 13K (MSM2 only) Voice call */
#define DIAG_SO_RS2_MARKOV   0x07    /* 13K (MSM2 only) Markov call (new) */
#define DIAG_SO_RS1_MARKOV   0x08
#define DIAG_SO_LOOPBACK_13K 0x09
#define DIAG_SO_MARKOV_13K   0x0A    /* 13K (MSM2 only) Markov call (old) */

typedef struct
{
  BYTE cmd_code;               /* Command code                        */
  BYTE mode;                   /* rxc mode                            */
  WORD markov_rate;            /* rate for markov processing          */
  WORD rx_state;               /* receive task state                  */
  DWORD total_frames;          /* total number of Markov frames       */
  DWORD bad_frames;            /* total number of bad frames          */
  WORD data[ 4 ][ 10 ];        /* mar_test array items for expected
                                     full, half,  quarter and eighth
                                     rate packets                     */
  DWORD bit_errs;              /* Markov bit errors                   */
  WORD good_errs[4];           /* Rate decision good,  but bits bad   */
} diag_markov_rsp_type;

/*==========================================================================

PACKET   diag_markov_reset_rsp_type

ID       DIAG_MARKOV_RESET_F

PURPOSE  Sent by DMSS, contains acknowledgement of the reset of the
         Markov statistics in the mobile.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
} diag_markov_reset_rsp_type;


/*===========================================================================

PACKET   diag_diag_ver_rsp_type

ID       DIAG_DIAG_VER_F

PURPOSE  Sent by DMSS, contains the requested version in WORD format

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  WORD ver;                    /* diag version */
} diag_diag_ver_rsp_type;


/*===========================================================================

PACKET   diag_ts_rsp_type

ID       DIAG_TS_F

PURPOSE  Sent by DMSS, contains a mobile time-stamp in QWORD format

============================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
  QWORD ts;                    /* Time stamp */
} diag_ts_rsp_type;


/*===========================================================================

PACKET   diag_ta_parm_rsp_type

ID       DIAG_TA_PARM_F

PURPOSE  Sent by DMSS, contains acknowledgement that ta parameters were
         set in the mobile.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;               /* Command code */
} diag_ta_parm_rsp_type;

/*===========================================================================

PACKET   diag_msg_rsp_type

ID       DIAG_MSG_F

PURPOSE  Sent by DMSS, contains 0 or 1 of the buffered messages the mobile
         is holding.

===========================================================================*/
typedef struct
{
//  BYTE cmd_code;               /* command code */
//  WORD qty;                    /* number of msg packets in the msg buffer
//                                 including the msg packet returned in this
//                                  response  -- if this field is 0, no msg
//                                  packet is included in this response */
//  DWORD drop_cnt;              /* number of msgs dropped by error services */
//  DWORD total_msgs;            /* total number of msgs that have occured */
//  msg_buf_type buf;            /* msg buffer */

//sya----start
	byte cmd_code;               /* command code */
  word qty;                    /* number of msg packets in the msg buffer
                                  including the msg packet returned in this
                                  response  -- if this field is 0, no msg
                                  packet is included in this response */
  dword drop_cnt;              /* number of msgs dropped by error services */
  dword total_msgs;            /* total number of msgs that have occured */
  byte  level;                  /* Severity level / Priority of this message */
  char  file[ 13 ];             /* Holds source file name                    */
  word  line;                   /* Line number in source file                */
  char  fmt[ 40 ];              /* printf style format string                */
  dword code1;                  /* parameters to go with the format string   */
  dword code2;
  dword code3;
  qword time;                   /* Time at which error occurred              */
//sya----end
} diag_msg_rsp_type;


/*============================================================================

PACKET   diag_screen_rsp_type

ID       DIAG_HS_SCREEN_F

PURPOSE  Sent by DMSS, contains the screen and annunciator image from the
         handset

============================================================================*/
typedef struct
{
// BYTE       cmd_code;             /* Command code */
// hs_diag_type screen;             /* Screen image buffer */
//sya-----start
  byte       cmd_code;             /* Command code */
  boolean backlight_on;         /* Backlight state         */
  byte scrn[ HS_SCRN_HIGH * HS_SCRN_WIDE ];
  byte reserved1;
  word annun;                   /* Annunciators            */
  byte blink_scrn[ HS_SCRN_HIGH * HS_SCRN_WIDE ];
  word blink_annun;             /* Annunciators for blink  */
  byte rssi;                    /* RSSI indicator          */
  byte reserved2;
  word blink_rate;              /* Blink rate for blinking */
//sya-----end
} diag_screen_rsp_type;

/*===========================================================================

PACKET    diag_parm_get_rsp_type

ID        DIAG_PARM_GET_F

PURPOSE   Sent by DMSS, contains the complete set of retreivable parameters.

==========================================================================*/
typedef struct {
  BYTE      cmd_code;                  /* Command code */
  QWORD     time;                      /* Time stamp */
  DWORD     mux_rev[PARM_NUM_REV_TC];  /* Reverse Traffic Channel params */
  DWORD     mux_for[PARM_NUM_FOR_TC];  /* Forward Traffic Channel params */
  DWORD     pag[PARM_NUM_PAG];         /* Paging Channel params */
  DWORD     acc[PARM_NUM_ACC];         /* Access Channel params */
  DWORD     layer2[PARM_NUM_LAYER2];   /* Layer2 params */
  QWORD     sys_time;                  /* OTH_SYS_TIME parameter */
} diag_parm_get_rsp_type;

/*==========================================================================

PACKET    diag_parm_set_rsp_type

ID        DIAG_PARM_SET_F

PURPOSE   Sent by DMSS in response to a request to reset one (or all) of
          the settable parameters to a new value.

============================================================================*/
typedef struct {
  BYTE      cmd_code;           /* Command code */
  QWORD     time;               /* Time stamp for operation */
} diag_parm_set_rsp_type;



/*==========================================================================

PACKET   diag_reg_rsp_type

ID       DIAG_REGIS_F

PURPOSE  Sent by DMSS to acknowledge receipt of diag_reg_req_type

===========================================================================*/
typedef struct
{
  BYTE               cmd_code;
} diag_reg_rsp_type;

/*==========================================================================

PACKET   diag_err_rsp_type

ID       DIAG_ERR_F

PURPOSE  Sent by DMSS to return the error records. All NV_ERR_LOG_SIZE
         of them.

===========================================================================*/
typedef struct {
  BYTE              cmd_code;           /* DIAG_ERR_READ_F */
  err_logged_type   log_cnt;            /* how many logged */
  err_ignored_type  ignore_cnt;         /* how many ignored */
  nv_err_log_type   err_logs[ NV_MAX_ERR_LOG ];  /* error records */
} diag_err_rsp_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Reset SER statistics response                                           */

typedef struct
{
  BYTE  cmd_code;
    /* Command code */
} diag_ser_reset_rsp_type;

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Report SER statistics response                                          */

typedef struct
{
//  BYTE cmd_code;               /* Command code */
//  rxc_ser_type    ser_data;    /* SER data */
//sya------start
  byte cmd_code;               /* Command code */
  dword frame_cnt;  /* Total frame count */
  dword ser1;   /* Sum of all 192 bit frame symbol error counts */
  dword ser2;   /* Sum of all 96 bit frame symbol error counts */
  dword ser4;   /* Sum of all 48 bit frame symbol error counts */
  dword ser8;   /* Sum of all 24 bit frame symbol error counts */
//sya------end
} diag_ser_report_rsp_type;

/*===========================================================================

PACKET   diag_test_rsp_type

ID       DIAG_TEST_F

PURPOSE  Sent by DMSS to relay test results

===========================================================================*/
typedef struct {
  BYTE                      cmd_code;
  diag_test_enum_type       test_code;
  diag_test_results_type    results;
} diag_test_rsp_type;

/*===========================================================================

PACKET   diag_orig_rsp_type

ID       DIAG_ORIG_F

PURPOSE  Sent by DMSS to acknowledge a command from the Data Services DM
         to originate a call.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;    /* Command code */
} diag_orig_rsp_type;

/*===========================================================================

PACKET   diag_end_rsp_type

ID       DIAG_END_F

PURPOSE  Sent by DMSS to acknowledge a command from the Data Services DM
         to end a call.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;    /* Command code */
} diag_end_rsp_type;

/*===========================================================================

PACKET   diag_tmob_rsp_type

ID       DIAG_TMOB_F

PURPOSE  Sent by Tester DMSS to acknowledge arrival of TMOB command.

NOTE     Only sent by Tester DMSS, only received by Tester DM.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;       /* Command code */
} diag_tmob_rsp_type;


/*===========================================================================

PACKET   diag_sleep_rsp_type

ID       DIAG_SLEEP_F

PURPOSE  Sent by external device to acknowledge the request for portable
         sleep being turned on or off.

===========================================================================*/
typedef struct
{
  BYTE cmd_code;              /* Command code */
} diag_sleep_rsp_type;


/*===========================================================================

PACKET   diag_systime_rsp_type

ID       DIAG_SYSTIME_F

PURPOSE  Sent by external device to obtain System Time from the mobile.

===========================================================================*/
typedef struct
{
  BYTE      cmd_code;              /* Command code */
  QWORD     sys_time;              /* System Time as requested.  80ms units */
} diag_systime_rsp_type;


//sya-----start
typedef struct {
    word pilot_pn;              /* Pilot offset */
    word pilot_strength;        /* Pilot strength */
} diag_pilot_data_type;

typedef struct
{
  byte cmd_code;              /* Command code */
  word pilot_inc;             /* Pilot increment for remaining sets */
  byte active_cnt;            /* Count of pilots in active set (up to 6) */
  byte cand_cnt;              /* Count of pilots in candidate set (up to 6) */
  byte neigh_cnt;             /* Count of pilots in neighbor set (up to 20) */
  diag_pilot_data_type pilot_sets[32];
                              /* Sets of pilots (in the above order) (6+6+20) */
} diag_pilot_sets_rsp_type;

typedef struct {
  byte      cmd_code;                  /* Command code */
  qword     time;                      /* Time stamp */
  dword     mux_rev[ 14 ];             /* Reverse Traffic Channel params */
  dword     mux_for[ 14 ];             /* Forward Traffic Channel params */
  dword     pag[ 7 ];                  /* Paging Channel params */
  dword     acc[ 8 ];                  /* Access Channel params */
  dword     layer2[ 5 ];               /* Layer2 params */
  qword     sys_time;                  /* OTH_SYS_TIME parameter */
  dword     mux2_rev[ 26 ];            /* MUX2 Reverse Traffic Channel params */
  dword     mux2_for[ 26 ];            /* MUX2 Forward Traffic Channel params */
} diag_parm_get2_rsp_type;

typedef struct {
  byte                cmd_code;               /* Command code */
  byte                mode_changed;           /* Boolean whether mode changed */
} diag_ser_mode_chng_rsp_type;

typedef struct {
  byte      cmd_code;                  /* Command code           */
  word      rssi;                      /* CDMA RSSI              */
} diag_get_rssi_rsp_type;

typedef struct
{
  byte cmd_code;              /* Command code */
  boolean password_ok;        /* TRUE if Security Password entered correctly */
} diag_password_rsp_type;

#define DIAG_RL_WR_OK          0    /* No errors */
#define DIAG_RL_WR_OK_DONE     1    /* No errors, PR_LIST is complete */
#define DIAG_RL_WR_OUT_OF_SEQ  2    /* Sequence number out of order */
#define DIAG_RL_WR_OVERFLOW    3    /* PR_LIST overflow */

typedef struct
{
  byte cmd_code;                    /* Command code */
  byte rl_status;                   /* Status of block, as above */
  nv_stat_enum_type nv_stat;        /* NV write status if OK_DONE */
} diag_pr_list_wr_rsp_type;

#define DIAG_RL_RD_OK         0     /* No error */
#define DIAG_RL_RD_NV_ERR     1     /* NV error */

typedef struct
{
  byte cmd_code;                               /* Command code */
  byte rl_status;                              /* Status of block, as above */
  nv_stat_enum_type nv_stat;                   /* Status returned by NV */
  byte seq_num;                                /* Sequence number */
  byte more;                                   /* More to come? */
  word num_bits;                               /* Number of valid data bits */
  byte pr_list_data[DIAG_PR_LIST_BLOCK_SIZE];  /* The block of PR_LIST */
} diag_pr_list_rd_rsp_type;
//sya-----end
/*===========================================================================
//ysi 95c ftm 2000/9/24
/*===========================================================================

PACKET   diag_ftm_rsp_type

ID       DIAG_FTM_CMD_F

PURPOSE  Sent by DM to request Factory Test Mode commands.

RESPONSE DMSS sends back status of the requested command.

===========================================================================*/

typedef struct
{
  byte cmd_code;
  word sub_cmd;
  byte status;
} diag_ftm_rsp_type;
/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Union of Responses from Mobile to Diagnostic Monitor */

/*===========================================================================

PACKET   diag_fs_op_rsp_type

ID       DIAG_FS_OP_F

PURPOSE  This response contains status and results data from an EFS 
         operation.  The contents of the response depends on the file
         system operation (sub-command) requested.

===========================================================================*/
/* Operation status values */
typedef enum {
  DIAG_FS_OKAY_S,                /* Good status                            */
  DIAG_FS_FAIL_S,                /* Low-level operation failed             */
  DIAG_FS_BUSY_S,                /* Operation is queued or in progress     */
  DIAG_FS_FILE_NOT_OPEN_S,       /* File needs to be opened for operation  */
  DIAG_FS_FILE_OPEN_S,           /* File needs to be closed for operation  */
  DIAG_FS_FILE_ALREADY_EXISTS_S, /* File already exists                    */
  DIAG_FS_NONEXISTENT_FILE_S,    /* File doesn't exist                     */
  DIAG_FS_DIR_ALREADY_EXISTS_S,  /* User directory already exists          */
  DIAG_FS_NONEXISTENT_DIR_S,     /* User directory doesn't exist           */
  DIAG_FS_DIR_NOT_EMPTY_S,       /* User directory not empty for remove    */
  DIAG_FS_UNKNOWN_OPERATION_S,   /* Unknown operation                      */
  DIAG_FS_ILLEGAL_OPERATION_S,   /* Invalid operation                      */
  DIAG_FS_PARAMETER_ERROR_S,     /* Bad parameter value                    */
  DIAG_FS_BAD_FILE_NAME_S,       /* Invalid file/directory name            */
  DIAG_FS_BAD_FILE_HANDLE_S,     /* Invalid file handle                    */
  DIAG_FS_BAD_SEEK_POS_S,        /* Invalid SEEK position                  */
  DIAG_FS_BAD_TRUNCATE_POS_S,    /* Invalid truncate position              */
  DIAG_FS_FILE_IS_REMOTE_S,      /* Operation invalid for remote files     */
  DIAG_FS_INVALID_CONF_CODE_S,   /* Invalid confirmation code specified    */
  DIAG_FS_EOF_S,                 /* End of file reached                    */
  DIAG_FS_MORE_S,                /* More records exist to be processed     */
  DIAG_FS_GC_IN_PROGRESS_S,      /* Garbage Collection in progress         */
  DIAG_FS_SPACE_EXHAUSTED_S,     /* Out of file system space               */
  DIAG_FS_BLK_FULL_S,            /* File block is full                     */
  DIAG_FS_DIR_SPACE_EXHAUSTED_S, /* Out of Master Directory space          */
  DIAG_FS_FBL_POOL_EXHAUSTED_S   /* Out of File Block List free pool space */
} diag_fs_status_enum_type;

/*------------------------------------------------
  Definitions of data for specific operations.
------------------------------------------------*/
/* "Display Directory List" operation */
typedef struct
{
  WORD num_dirs;
  diag_fs_data_block_type  dir_list;
} diag_fs_disp_dirs_rsp_type;

/* "Display File List" operation */
typedef struct
{
  WORD num_files;
  diag_fs_data_block_type  file_list;
} diag_fs_disp_files_rsp_type;

/* "Read File" operation */
typedef union
{ 
  struct
  {
    DWORD                    total_length;   /* Total length of this file */
    diag_fs_data_block_type  block;
  } begin;

  diag_fs_data_block_type  block;
 
} diag_fs_read_block_type;

typedef struct
{
  BYTE                  seq_num;  /* Sequence number for mult blocks    */
  BYTE                     more;  /* Flag if more packets are needed to
                                      complete transfer                 */
  diag_fs_read_block_type  data;  /* Current portion of the file        */
} diag_fs_read_rsp_type;

/* "Write File" operation */
typedef struct
{
  BYTE seq_num;
} diag_fs_write_rsp_type;

/* "Get File Attributes" operation */
typedef struct
{
  diag_fs_attributes_type attrib; /* Attributes         */
  DWORD            creation_date; /* File creation date */
  DWORD                     size; /* File size          */
} diag_fs_get_attrib_rsp_type;

/* "Iterate Directories" operation */
typedef struct
{
  DWORD seq_num;
  /* "valid" is zero if the requested directory number is past the  */
  /* end of the number of directories, marking the end of the list. */
  /* "valid" is non-zero if the requested directory number is in    */
  /* the list and the directory name is returned in "dir_name".     */
  
  /* The meaning of this field may change, but it will still be     */
  /* there.                                                         */

  BYTE valid;                      /* non-zero if name is valid */
  
  diag_fs_attributes_type   attrib; /* Attributes                   */
  DWORD               logical_size; /* Size of data                 */
  DWORD              physical_size; /* Physical space on device     */
  DWORD             dirname_length; /* Length of directory portion  */
                                    /* of file name.                */
  diag_fs_filename_type  dir_name;
} diag_fs_iter_dirs_rsp_type;

/* "Iterate Files" operation */
typedef struct
{
  DWORD seq_num;
  /* "valid" is zero if the requested file number is past the end   */
  /* of the number of directories, marking the end of the list.     */
  /* "valid" is non-zero if the requested file number is in the     */
  /* list and the file name is returned in "file_name".             */
  
  /* The meaning of this field may change, but it will still be     */
  /* there.                                                         */

  BYTE valid;                       /* non-zero if name is valid    */

  diag_fs_attributes_type   attrib; /* Attributes                   */
  DWORD               logical_size; /* Size of file data            */
  DWORD              physical_size; /* Physical space on device     */
  DWORD             dirname_length; /* Length of directory portion  */
                                    /* of file name.                */
  diag_fs_filename_type  file_name;
} diag_fs_iter_files_rsp_type;

typedef union
{
  BYTE                           seq_num; /* Seq number in same place for 
                                             all packets that use them */
  diag_fs_disp_dirs_rsp_type   disp_dirs;
  diag_fs_disp_files_rsp_type disp_files;
  diag_fs_read_rsp_type             read;
  diag_fs_write_rsp_type           write;
  diag_fs_get_attrib_rsp_type get_attrib;
  diag_fs_iter_dirs_rsp_type   iter_dirs;
  diag_fs_iter_files_rsp_type iter_files;
} diag_fs_rsp_type;

typedef struct
{
  BYTE cmd_code;                     /* Command code                     */
  BYTE file_op;                      /* Operation requested              */
  BYTE fs_status;                    /* Status of operation - values in  
                                        diag_fs_status_enum_type         */
  diag_fs_rsp_type  fs_rsp;          /* Only used if returning more than 
                                        just status                      */
} diag_fs_op_rsp_type;  

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/
/* Union of Responses from Mobile to Diagnostic Monitor */
typedef struct
{
  BYTE cmd_code;                /* Command code */
  WORD agc_value;               /* agc value */
} diag_cal_rsp_type;


//OJS
/*===========================================================================

PACKET   diag_cal_test_rsp_type

ID       DIAG_CAL_F

PURPOSE  Sent by DMSS to relay test results
//4.03-1 OJS 2002.3.25
===========================================================================*/
typedef struct {
  byte                        cmd_code;
  diag_cal_test_enum_type    test_code;
  diag_cal_test_results_type results;
} diag_cal_test_rsp_type;
typedef struct {
	byte			cmd_code;
	word			what_to_do;
	word			what_1;
	signed short	what_2;
	byte			what_3;
	byte			what_4;
	signed char		what_5;
	byte			ret;
} toolsdiag_lgf_rsp_type;

typedef union
{
  gen_byte_and_word_type    byte_and_word;	//+[WCDMA] vivache : SH100
  BYTE                      cmd_code;
  diag_verno_rsp_type       verno;
  diag_verstr_rsp_type      verstr;
  diag_esn_rsp_type         esn;
  diag_peekb_rsp_type       peekb;
  diag_peekw_rsp_type       peekw;
  diag_peekd_rsp_type       peekd;
  diag_vpeek_rsp_type       vpeek;
  diag_pokeb_req_type       pokeb;     /* note: type is a request pkt */
  diag_pokew_req_type       pokew;     /* note: type is a request pkt */
  diag_poked_req_type       poked;     /* note: type is a request pkt */
  diag_vpoke_req_type       vpoke;     /* note: type is a request pkt */
  diag_outp_req_type        outp;      /* note: type is a request pkt */
  diag_outpw_req_type       outpw;     /* note: type is a request pkt */
  diag_inp_rsp_type         inp;
  diag_inpw_rsp_type        inpw;
  diag_status_rsp_type      stat;
  diag_logmask_rsp_type     logmask;
  diag_log_rsp_type         log;
  diag_err_type             err;
  diag_nv_peek_rsp_type     nv_peek;
  diag_nv_poke_req_type     nv_poke;     /* note: type is a req packet */
  diag_tagraph_rsp_type     tagraph;
  diag_markov_rsp_type      markov;
  diag_markov_reset_rsp_type    m_reset;
  diag_diag_ver_rsp_type    diag_ver;
  diag_ts_rsp_type          ts;
  diag_ta_parm_rsp_type     ta_parm;
  diag_msg_rsp_type         msg_rsp;
  diag_hs_lock_req_type     hs_lock;     /* note: type is a req packet */
  diag_hs_key_req_type      hs_key;      /* note: type is a req packet */
  diag_screen_rsp_type      hs_screen;
  diag_parm_get_rsp_type    parm_get;
  diag_parm_set_rsp_type    parm_set;
  diag_nv_read_req_type     nv_read;     /* note: type is a req packet */
  diag_nv_write_req_type    nv_write;    /* note: type is a req packet */
  diag_reg_rsp_type         reg;
  diag_err_rsp_type         err_rsp;
  diag_err_clr_req_type     err_clr;     /* note: type is a req packet */
  diag_control_req_type     cont;        /* note: type is a req packet */
  diag_conf_req_type        conf;        /* note: type is a req packet */
  diag_ser_reset_rsp_type   ser_res;
  diag_ser_report_rsp_type  ser_rep;
  diag_test_rsp_type        test_rsp;
  diag_dipsw_req_type       dipsw_rsp;   /* note: type is a req packet */
  diag_voc_pcm_lb_type      vocpcm_rsp;  /* note: type is same as req packet */
  diag_voc_pkt_lb_type      vocpkt_rsp;  /* note: type is same as req packet */
  diag_orig_rsp_type        orig;
  diag_end_rsp_type         end;
  diag_dload_req_type       dload;       /* note: type is same as req packet */
  diag_dload_param_rsp_type param;       /* CBK - Insert for dloading code   */
  diag_dload_ack_rsp_type   ack;         /* CBK - Insert for dloading code   */
  diag_dload_nak_rsp_type   nak;         /* CBK - Insert for dloading code   */
  diag_tmob_rsp_type        tmob;
  diag_seq_num_req_type     seq_num_rsp; /* note: type is same as req packet */
  diag_sleep_rsp_type       sleep_rsp;
  diag_systime_rsp_type     systime_rsp;
  diag_state_rsp_type       state_rsp;
  diag_spc_rsp_type         spc_rsp;
  diag_rxcal_rsp_type       rxcal;
  diag_rxcal3000_rsp_type   rxcal3000;	// 1999. 3. 4 CKK for MSM3000
  diag_txcal_rsp_type       txcal;
  diag_misc_cal_rsp_type    misc_cal;
  diag_misc_cal3000_rsp_type    misc_cal3000;	// 1999. 4. 13 CKK for MSM3000
  diag_tdmb_rsp_type tdmb;     // for T-DMB
  diag_misc_calInreCube_rsp_type misc_cal_Inter; //OJS InterCube ����...

//sya----start
  diag_pilot_sets_rsp_type  pilot_sets;
  diag_parm_get2_rsp_type   parm_get2;
  diag_ser_mode_chng_rsp_type  ser_mode_chng;
  diag_get_rssi_rsp_type    get_rssi;
  diag_password_rsp_type    password_rsp;
  diag_pr_list_wr_rsp_type  pr_list_wr_rsp;
  diag_pr_list_wr3000_req_type  pr_list_wr3000_rsp;
  diag_pr_list_rd_rsp_type  pr_list_rd_rsp;
//sya----end
  diag_fs_op_rsp_type       fs_op; // EFS   
  diag_ftm_rsp_type         ftm; // ysi 95c ftm 2000/9/24 
  diag_cal_rsp_type        cal;
  diag_cal_test_rsp_type    cal_test_rsp;//4.03-1 OJS 2002.3.25

  diag_test_mode_rsp_type	test_mode;
  diag_ftm_rsp_pkt_type         ftm_rsp; 
  toolsdiag_lgf_rsp_type		tools_rsp;

// 2004/2/27 thunder - VX8000  
  diag_cm_state_type		cm_state;
// 2004/4/1 thunder - VX8000
  diag_config_comm_rsp_type	config_comm;
// 2004/4/29 thunder - VX8000  
  hdrdiag_state_type        hdr_state;
} diag_rsp_type;

typedef struct
{
//sio_hdr_type         hdr;             /* Remove it for async_hdlc_format by CBK */
  diag_rsp_type        rsp;
  BYTE                 tsync_pad[ SIO_DP_MAX_PAD ];
  sio_hdlc_trl_type    trl;
} diag_rsp_pkt_type;

#pragma pack()

#endif /* DIAGPKT_H  */