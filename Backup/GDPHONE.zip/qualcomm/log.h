#ifndef _LOG_H
#define _LOG_H
/*===========================================================================

            L O G    S E R V I C E S    H E A D E R    F I L E

DESCRIPTION
  This file contains declarations for packets to be logged.

Copyright (c) 1991, 1992 by QUALCOMM, Incorporated.  All Rights Reserved.
===========================================================================*/

/*===========================================================================

                      EDIT HISTORY FOR FILE

This section contains comments describing changes made to this file.
Notice that changes are listed in reverse chronological order.

$Header:   Z:/CMtest/CMtest(3.61)/WInclude/LOG.H-arc   1.0   Feb 14 2000 15:35:24   hyun  $
   
when       who     what, where, why
--------   ---     ----------------------------------------------------------
05/03/95   rdh     Added log_status function.
04/13/95   rdh     Added sparsely-sampled AGC/pwr ctl log code type.
01/05/95   rdh     Added LOG_NOCEN_M for TC state DM TA centering control.
07/30/94   rdh     Increased LOG_TA2_CNT for IS-95 Phase III.
02/04/93   jai     Changed comment for log_ta packet.
10/06/92   jai     Added access channel info item and type.
10/05/92   arh     Added analog item and type
08/31/92   gb      DMSS ver.
03/05/91   rdb     Created first (uncommented) cut of file. Take over, Jen.
===========================================================================*/
//#include "nv.h"
//#include "diagt.h"


/*===========================================================================

                        DATA DECLARATIONS

===========================================================================*/

#pragma pack(1)  /* Notice: log packets are BYTE packed. */

/*---------------------------------------------------------------------------
                       LOG TYPE CODES

These codes identify the kind of information contained in a log entry. 
They are used in conjunction with the 'code' field of the log entry header. 
The data types associated with each code are defined below.
---------------------------------------------------------------------------*/

#define  LOG_MS_EQUIP_ID  1
  /* Mobile Station is assigned equipment ID 1. */

//typedef enum
//{
#define   LOG_BASE_C  (LOG_MS_EQUIP_ID << 12)
    /* The upper 4 bits of the 16 bit log entry code specify which type
       of equipment created the log entry. */

#define   LOG_TA_C  LOG_BASE_C   
                     /* Mobile Station temporal analyzer entry. */

#define   LOG_AGC_PCTL_C          (LOG_BASE_C + 1)    /* AGC values and closed loop power control entry. */

#define   LOG_F_MUX1_C          (LOG_BASE_C + 2)      /* Forward link frame rates and types entry. */
#define   LOG_R_MUX1_C          (LOG_BASE_C + 3)      /* Reverse link frame rates and types entry. */

#define   LOG_AC_MSG_C          (LOG_BASE_C + 4)      /* Access channel message entry. */
#define   LOG_R_TC_MSG_C          (LOG_BASE_C + 5)    /* Reverse link traffic channel message entry. */

#define   LOG_SC_MSG_C          (LOG_BASE_C + 6)      /* Sync channel message entry. */
#define   LOG_PC_MSG_C          (LOG_BASE_C + 7)      /* Paging channel message entry. */
#define   LOG_F_TC_MSG_C          (LOG_BASE_C + 8)    /* Forward link traffic channel message entry. */

#define   LOG_VOC_FOR_C          (LOG_BASE_C + 9)     /* Forward link vocoder packet entry */
#define   LOG_VOC_REV_C          (LOG_BASE_C + 10)     /* Reverse link vocoder packet entry */

#define   LOG_FING_C          (LOG_BASE_C + 11)        /* Temporal analyzer finger info only. */
#define   LOG_SRCH_C          (LOG_BASE_C + 12)        /* Temporal anlayzer searcher info only. Superseded
                        by LOG_SRCH2_C (see below). */

#define   LOG_ETAK_C          (LOG_BASE_C + 13)        /* Position and speed information read from ETAK. */

#define   LOG_MAR_C          (LOG_BASE_C + 14)         /* Markov frame statistics. */

#define   LOG_SRCH2_C          (LOG_BASE_C + 15)       /* New and improved temporal analyzer searcher info. */

#define   LOG_HANDSET_C          (LOG_BASE_C + 16)     /*  The Fujitsu handset information */
                     
#define   LOG_ERRMASK_C          (LOG_BASE_C + 17)     /*  Vocoder bit error rate mask */

#define   LOG_ANALOG_INFO_C          (LOG_BASE_C + 18) /* Analog voice channel information */

#define   LOG_ACC_INFO_C          (LOG_BASE_C + 19)    /* Access probe information */

#define   LOG_GPS_C          (LOG_BASE_C + 20)         /* Position and speed information read from GPS receiver */

#define   LOG_TEST_CMD_C          (LOG_BASE_C + 21)    /* Test Command information */

#define   LOG_S_AGC_PCTL_C          (LOG_BASE_C + 22)  /* Sparse (20ms) AGC / closed loop power control entry. */

#define   LOG_MAX_C          (LOG_BASE_C + 23)			/* Provides count of number of log entry codes. MUST
														REMAIN LAST ENUM ITEM. */
typedef   WORD log_code_type;

#define LOG_STATUS_C 0x1FFE
  /* This is the code for the status packet that is requested from the DM
     in a diag request when logging is turned on.  Since it is not a type
     which can be turned on and off with the log mask it is given this
     special code */

/*---------------------------------------------------------------------------
                        LOG HEADER TYPE

The following type defines the structure of the log entry header.
---------------------------------------------------------------------------*/

typedef struct
{
  WORD   len;
    /* Specifies the length, in BYTEs of the entry, including this
       header. */

  log_code_type   code;
    /* Specifies the log code for the entry as enumerated above. */

  QWORD  ts;
    /* The system timestamp for the log entry. The upper 48 bits 
       represent elapsed time since 6 Jan 1980 00:00:00 in 1.25 ms
       units. The low order 16 bits represent elapsed time since the
       last 1.25 ms tick in 1/32 chip units (this 16 bit counter
       wraps at the value 49152). */
}
log_hdr_type;


/*---------------------------------------------------------------------------
                      TEMPORAL ANALYZER ENTRY TYPE                        
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */


  /*- - - - - Finger related information - - - - -*/

  WORD          fing_pilot[ 3 ];
    /* For each finger, indicates which pilot offset is in use. */

  WORD          fing_x[ 3 ];
    /* For each finger, gives low order 16 bits of absolute offset in 
       1/8 chip units. */

  BYTE          fing_y[ 3 ];
    /* For each finger, indicates the current RSSI value. If zero,
       indicates finger is not locked. */


  /*- - - - - Search window related information - - - - -*/

  BYTE          pregain;
    /* Pregain setting used for search:
       0 = 2/32, 1 = 4/32, 2 = 8/32, 3 = 16/32. */

  BYTE          integ;
    /* Integration period used for search in 4 chip units. */

  BYTE          non_coh;
    /* Number of non-coherent integrations accumulated. Value is
       one less than actual value, e.g., 0 implies 1. */

  WORD          pilot_off;
    /* Pilot offset used during search. */

  WORD          win_pos;
    /* Low order 16 bits of absolute window ending position in 1/8 chip
       units. */

  BYTE          num_entries;
    /* Number of entries in energies array. */

#define                   LOG_TA_CNT  48
  WORD          energies[ LOG_TA_CNT ];
    /* Energies versus half chip time offset. */
}
log_ta_type;


/*---------------------------------------------------------------------------
                      AGC AND POWER CONTROL ENTRY TYPE
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

  BYTE          agc_ref;
    /* AGC reference level value. */

#define                   LOG_AGC_PCTL_CNT  100
  BYTE          agc_vals[ LOG_AGC_PCTL_CNT ];                
    /* AGC values sampled at 1.25 ms intevals. */

  BYTE          pctl_vals[ LOG_AGC_PCTL_CNT ];                       
    /* Power control values sampled at 1.25 ms intevals. */
}
log_agc_pctl_type;


/*---------------------------------------------------------------------------
              SPARSELY-SAMPLED AGC AND POWER CONTROL ENTRY TYPE
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

  BYTE          adc_therm;
    /* Calibrated thermistor ADC sample value. */

  BYTE          batt_volt;
    /* Calibrated battery voltage */

  BYTE          tx_pwr_limit;
    /* CDMA TX power limit (hi 8-bits) */

  BYTE          agc_vals[ LOG_AGC_PCTL_CNT ];                
    /* CAGC values sampled at 20 ms intevals. */

  BYTE          pctl_vals[ LOG_AGC_PCTL_CNT ];
    /* Power control values sampled at 20 ms intevals. */

  BYTE          tx_pwr_vals[ LOG_AGC_PCTL_CNT ];                       
    /* CAGC TX power estimate values (hi 8-bits) sampled at 20 ms intervals. */
}
log_s_agc_pctl_type;


/*---------------------------------------------------------------------------
                  FORWARD LINK FRAME STATS ENTRY TYPE                        
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

#define               LOG_F_MUX1_CNT  100
  BYTE          vals[ LOG_F_MUX1_CNT ];
    /* Mixed mode bits for sequential forward link traffic frames. */
}
log_f_mux1_type;


/*---------------------------------------------------------------------------
                  REVERSE LINK FRAME STATS ENTRY TYPE                        
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

#define               LOG_R_MUX1_CNT  100
  BYTE          vals[ LOG_R_MUX1_CNT ];
    /* Mixed mode bits for sequential reverse link traffic frames. */
}
log_r_mux1_type;


/*---------------------------------------------------------------------------
                    ACCESS CHANNEL MESSAGE ENTRY TYPE                        
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

#define              LOG_AC_MSG_CNT  (1184/8)
  BYTE          msg[ LOG_AC_MSG_CNT ];
    /* Actual access channel message bits. */
}
log_ac_msg_type;


/*---------------------------------------------------------------------------
                    REVERSE TRAFFIC CHANNEL ENTRY TYPE                        
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

#define              LOG_R_TC_MSG_CNT  (1184/8)
  BYTE          msg[ LOG_R_TC_MSG_CNT ];
    /* Actual reverse link traffic channel message bits. */
}
log_r_tc_msg_type;


/*---------------------------------------------------------------------------
                     SYNC CHANNEL MESSAGE ENTRY TYPE                        
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */
                     
#define              LOG_SC_MSG_CNT  (1184/8)
  BYTE          msg[ LOG_SC_MSG_CNT ];
    /* Actual sync channel message bits. */
}
log_sc_msg_type;


/*---------------------------------------------------------------------------
                    PAGING CHANNEL MESSAGE ENTRY TYPE                        
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */
                     
#define              LOG_PC_MSG_CNT  (1184/8)
  BYTE          msg[ LOG_PC_MSG_CNT ];
    /* Actual paging channel message bits. */
}
log_pc_msg_type;


/*---------------------------------------------------------------------------
                FORWARD TRAFFIC CHANNEL MESSAGE ENTRY TYPE                        
---------------------------------------------------------------------------*/


typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */
                     
#define              LOG_F_TC_MSG_CNT  (1184/8)
  BYTE          msg[ LOG_F_TC_MSG_CNT ];
    /* Actual forward link traffic channel message bits. */
}
log_f_tc_msg_type;

/*---------------------------------------------------------------------------
                         VOCODER DATA ENTRY TYPE
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

  BYTE  data[24];                 /* vocoder data */
  BYTE  rate;                     /* rate */
  boolean revlink;                /* is reverse link? */
}
log_voc_type;


/*---------------------------------------------------------------------------
                           FINGER ENTRY TYPE                        
 Note: similar info to that contained in the Temporal Analyzer log entry,
       but not including searcher data.
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

  WORD          fing_pilot[ 3 ];
    /* For each finger, indicates which pilot offset is in use. */

  WORD          fing_x[ 3 ];
    /* For each finger, gives low order 16 bits of absolute offset in 
       1/8 chip units. */

  BYTE          fing_y[ 3 ];
    /* For each finger, indicates the current RSSI value. If zero,
       indicates finger is not locked. */
}
log_fing_type;

/*---------------------------------------------------------------------------
                        SEARCHER ENTRY TYPE                        

 --Now obsolete. See new log_srch2_type defined below--

 Note: similar info to that contained in the Temporal Analyzer log entry,
       but not including finger data.
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

  BYTE          pregain;
    /* Pregain setting used for search: 0 = 2, 1 = 4, 2 = 8, 3 = 32. */

  BYTE          integ;
    /* Integration period used for search in 4 chip units. */

  BYTE          non_coh;
    /* Number of non-coherent integrations accumulated. Value is
       one less than actual value, e.g., 0 implies 1. */

  WORD          pilot_off;
    /* Pilot offset used during search. */

  WORD          win_pos;
    /* Low order 16 bits of absolute window ending position in 1/8 chip
       units. */

  BYTE          num_entries;
    /* Number of entries in energies array. */

  WORD          energies[ LOG_TA_CNT ];
    /* Energies versus half chip time offset. */
}
log_srch_type;


/*---------------------------------------------------------------------------
                            ETAK ENTRY TYPE
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. Note: the timestamp for this entry shall
       always be zero. Use preceding and succeeding entry timestamps
       to time bracket this entry. */

  BYTE          lon[ 11 ];
    /* Longitude in ascii format, e.g.: W121.345342 */

  BYTE          lat[ 11 ];
    /* Latitude in ascii format, e.g.: N037.799833 */

  BYTE          speed[ 5 ];
    /* Vehicle speed (meters/second) in ascii format, e.g.: +22.3 */
  
}
log_etak_type;


/*---------------------------------------------------------------------------
                            FUJITSU ENTRY TYPE
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. Note: the timestamp for this entry shall
       always be zero. Use preceding and succeeding entry timestamps
       to time bracket this entry. */

  BYTE          buffer[20];
  
}
log_handset_type;


/*---------------------------------------------------------------------------
                         MARKOV FRAME STATISTICS
This entry effectively replaces the log_f_mux1_type entry.
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */
  
  BYTE          count;
    /* number of entries in entry array */

#define                   LOG_MAR_CNT 100
  struct
  {
    BYTE          mar_inx;
    /* Decision indices for sequential frames. Each index value is computed
       according to the following formula:

         mar_inx = (EXPECTED_MUX1 * 16) + ACTUAL_MUX1

       where EXPECTED_MUX1(i) is the MUX1 index (1 to 14, a la CAI) predicted
       by the Markov process for frame i, and ACTUAL_MUX1 is the MUX1 index
       actually decided upon by the mobile's rate determination algorithm for
       frame i. */

    BYTE          bit_errs;
      /* Bit error counts for sequential frames. */
  }entry[ LOG_MAR_CNT];
  
}
log_mar_type;


/*---------------------------------------------------------------------------
                        SEARCHER 2 ENTRY TYPE                        
 Note: Supersedes previous Temporal Analyzer log entry type. Allows for
       variable window size.
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

  BYTE          pregain;
    /* Pregain setting used for search: 0 = 2, 1 = 4, 2 = 8, 3 = 32. */

  BYTE          integ;
    /* Integration period used for search in 4 chip units. */

  BYTE          non_coh;
    /* Number of non-coherent integrations accumulated. Value is
       one less than actual value, e.g., 0 implies 1. */

  /* Following masks are OR'd into the pilot_off field. */

#define  LOG_ASET_M  0x8000  /* pilot belongs to active set. */
#define  LOG_CSET_M  0x4000  /* pilot belongs to candidate set. */
#define  LOG_NSET_M  0x2000  /* pilot belongs to neighbor set. */
#define  LOG_RSET_M  0x1000  /* pilot belongs to remaining set. */
#define  LOG_PCSET_M 0x0800  /* pilot belongs to the pre-candidate set. */
#define  LOG_NOCEN_M 0x0400  /* Suppress DM TA window recentering */

  WORD          pilot_off;
    /* Pilot offset used during search. */

  WORD          win_pos;
    /* Low order 16 bits of absolute window ending position in 1/8 chip
       units. */

  WORD          win_cen;
    /* Specifies center position of searcher window space. */

  WORD          tcxo_drift;
    /* Specifies tcxo error in 1/(8*256) chip units. Note number is
       signed. */

  WORD          num_entries;
    /* Number of entries in energies array. */

#define                   LOG_TA2_CNT  (228*2)
  WORD          energies[ LOG_TA2_CNT ];
    /* Energies versus half chip time offset. */
}
log_srch2_type;


/*---------------------------------------------------------------------------
                        STATUS ENTRY TYPE                        
---------------------------------------------------------------------------*/
#define LOG_VERNO_DATE_STRLEN 11
#define LOG_VERNO_TIME_STRLEN  8
#define LOG_VERNO_DIR_STRLEN   8


typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

  QWORD end_time;
    /* The time stamp of the last log packet  - not filled by mobile */

  DWORD log_mask;
    /* The log mask - not filled by mobile */

  char comp_date[LOG_VERNO_DATE_STRLEN ];        
    /* Compile date Jun 11 1991   */

  char comp_time[LOG_VERNO_TIME_STRLEN ];        
    /* Compile time hh:mm:ss      */

  char rel_date [LOG_VERNO_DATE_STRLEN ];        
    /* Release date               */

  char rel_time [LOG_VERNO_TIME_STRLEN ];        
    /* Release time               */

  char ver_dir  [LOG_VERNO_DIR_STRLEN ];         
    /* Version directory          */

  BYTE scm;                                   
    /* Station Class Mark         */

  BYTE mob_cai_rev;                           
    /* CAI rev                    */

  BYTE mob_model;                             
    /* Mobile Model               */

  WORD mob_firm_rev;                          
    /* Firmware Rev               */

  BYTE slot_cycle_index;                      
    /* Slot Cycle Index           */

  BYTE  demod;                  
    /* Demod id BYTE                        */

  BYTE  decode;                 
    /* Decoder id BYTE                      */

  BYTE  inter;                  
    /* Interleaver id BYTE                  */

  DWORD esn;                    
    /* Mobile Electronic Serial Number      */

  WORD  rf_mode;                
    /* 0->analog,  1->cdma,  2->pcn         */

  DWORD min1[NV_MAX_MINS];      
    /* all MIN1s                            */

  WORD min2[NV_MAX_MINS];      
    /* all MIN2s                            */

  BYTE orig_min;               
    /* index (0-3) of the orig MIN          */
  
  WORD cdma_rx_state;          
    /* current state for cdma only          */

  BYTE cdma_good_frames;       
    /* whether or not frames we are receiving are good -- cdma only      */

  WORD analog_corrected_frames;
    /* good frame count - analog only       */

  WORD analog_bad_frames;      
    /* bad frame count - analog only        */

  WORD analog_WORD_syncs;      
    /*  -- analog only                      */

  WORD entry_reason;           
    /* entry reason                         */

  WORD curr_chan;              
    /* center frequency channel             */

  BYTE cdma_code_chan;         
    /* code for current channel - cdma only */

  WORD pilot_base;             
    /* pilot pn of current cell - cdma only */

  WORD sid;                    
    /* Current System ID                    */

  WORD nid;                    
    /* Current Network ID                   */

  WORD locaid;                 
    /* Current Location ID                  */

  WORD rssi;                   
    /* Current RSSI level                   */

  BYTE power;                  
    /* Current mobile output power             level    */

} log_status_type;


/*---------------------------------------------------------------------------
                     ANALOG INFORMATION ENTRY TYPE
---------------------------------------------------------------------------*/


typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */

  WORD sid;   
    /* Current System ID */

  WORD channel;
    /* Current channel number */

  BYTE scc;
    /* Current SAT color Code */

  BYTE rssi;
    /* Current RSSI */

  BYTE power; 
    /* Current analog transmit power level */
                     
}
log_analog_info_type;


/*---------------------------------------------------------------------------
                     ACCESS PROBE INFORMATION TYPE
---------------------------------------------------------------------------*/


typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */
  BYTE seq_num;
    /* Access probe sequence number */
  BYTE probe_num;
    /* Access probe number */
  BYTE rx_agc;
    /* Receive AGC */
  BYTE tx_adj;
    /* TX gain adjust */
  BYTE psist;
    /* number of persistence tests performed */
  BYTE ra;
    /* access channel number */
  BYTE rn;
    /* PN randomization delay */
  BYTE rs;
    /* Sequence backoff */
  BYTE rt;
    /* probe backoff */
}log_acc_info_type;


/*---------------------------------------------------------------------------
                            GPS ENTRY TYPE
---------------------------------------------------------------------------*/

typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. Note: the timestamp for this entry shall
       always be zero. Use preceding and succeeding entry timestamps
       to time bracket this entry. */

  BYTE          time[6];
    /* GPS time of day */

  BYTE          lon[ 9 ];
    /* Longitude in ascii format, e.g.: -11721693 */

  BYTE          lat[ 8 ];
    /* Latitude in ascii format, e.g.:  +3290467 */

  BYTE          head[ 3 ];
    /* Heading in ascii format,  e.g.:   176  */

  BYTE          speed[ 3 ];
    /* Vehicle speed (MPH) in ascii format, e.g.: 000 */

  BYTE          source;
   /* Packet information e.g : 0 */
  
  BYTE          data_ind;
   /* Age of data indicator e.g : 2 */
  
}
log_gps_type;



/*---------------------------------------------------------------------------
                     TEST COMMAND LOG TYPE
---------------------------------------------------------------------------*/


typedef struct
{
  log_hdr_type  hdr;
    /* Common entry header. */
  tmob_cmd_type cmd;
    /* Common Test Command type for all test commands. */
}log_test_cmd_type;



/*---------------------------------------------------------------------------
                       UNION OF ALL LOG ENTRY TYPES
---------------------------------------------------------------------------*/

typedef union
{
  log_hdr_type         hdr;       /* Generic. */
  log_ta_type          ta;        /* Temporal Analyzer report. */
  log_agc_pctl_type    agc_pctl;  /* AGC and power control value. */
  log_s_agc_pctl_type  s_agc_pctl;/* Sparsely-sampled AGC and pctl value. */
  log_f_mux1_type      f_mux1;    /* Forward link frame stats. */
  log_r_mux1_type      r_mux1;    /* Reverse link frame stats. */
  log_ac_msg_type      ac_msg;    /* Access channel message. */
  log_r_tc_msg_type    r_tc_msg;  /* Reverse traffic channel message. */
  log_sc_msg_type      sc_msg;    /* Sync channel message. */
  log_pc_msg_type      pc_msg;    /* Paging channel message. */
  log_f_tc_msg_type    f_tc_msg;  /* Forward traffic channel message. */
  log_voc_type         voc;       /* Vocoder package */
  log_fing_type        fing;      /* Temporal Analyzer finger info. */
  log_srch_type        srch;      /* Temporal Analyzer searcher info. */
  log_etak_type        etak;      /* ETAK position and speed info. */
  log_mar_type         mar;       /* Markov frame statistics info. */
  log_srch2_type       srch2;     /* Temporal Analyzer report */
  log_status_type      status;    /* Status info */
  log_analog_info_type analog;    /* Analog information */
  log_acc_info_type    acc_info;  /* Access probe information */
  log_gps_type         gps;       /* GPS data */
  log_test_cmd_type    test_cmd;  /* Test Command information */
}                
log_type;


/*---------------------------------------------------------------------------
                       STATUS CODES FOR LOG SERVICES
---------------------------------------------------------------------------*/

//typedef enum
//{
#define  LOG_DONE_S  0  /* Function performed successfully. */
#define  LOG_NOT_ENA_S 1  /* Logging disabled for specified log code. */
#define  LOG_BUSY_S    2  /* Logging of specified item in progress. */
#define  LOG_BADP_S    3   /* Illegal parameter specified. */
typedef WORD log_ret_status_type;

#pragma pack()  /* Restore default packing. */


/*---------------------------------------------------------------------------
                        LOG DESCRIPTOR TYPE
---------------------------------------------------------------------------*/

typedef struct
{
  q_link_type   link;
    /* Used in conjunction with the q_ptr field below for placing this
       descriptor onto a queue after it is processed. This field must be
       initialized by the caller prior to using the descriptor with the
       Log Services. */
  
  q_type        *q_ptr;
    /* Points to the queue on which to place this descriptor after it is
       processed. If NULL, then the descriptor is not placed on any queue.
       This field must be initialized by the caller prior to using the
       descriptor with the Log Services. It is not modified by the Log
       Services. */

  log_hdr_type  *log_ptr;
    /* Points to the header of the log buffer containing the data BYTEs
       to put in the log. This field must be initialized by the caller
       prior to using the Log Services. It is not modified by the Log
       Services. */

  WORD          status;
    /* This field reflects the status of the logging operation. When an
       operation is initiated, this field is set to LOG_BUSY_S. When the
       operation completes, the field is set to the appropriate final
       status, usually LOG_DONE_S. See Log Services status codes, defined
       above, for a list of all possible codes. */
}
log_desc_type;


/*===========================================================================

                      FUNCTION DECLARATIONS

===========================================================================*/

//extern WORD  log_config ( WORD  code, boolean  flag );

//extern void  log_put ( log_desc_type  *desc_ptr );

//extern boolean  log_status ( WORD  code );

#endif /* LOG_H */

