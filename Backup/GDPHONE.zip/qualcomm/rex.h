#ifndef _REX_H
#define _REX_H
/*===========================================================================

     R E A L - T I M E    E X E C U T I V E    D E C L A R A T I O N S

DESCRIPTION
  This file contains declarations used by REX.

Copyright (c) 1990,1991,1992,1993 by QUALCOMM Incorporated. All Rights Reserved.
===========================================================================*/

/*===========================================================================

                     EDIT HISTORY FOR FILE

This section contains comments describing changes made to this file.
Notice that changes are listed in reverse chronological order.

$Header:   Z:/CMtest/CMtest(3.61)/WInclude/Rex.h-arc   1.0   Feb 14 2000 15:35:34   hyun  $
   
when       who     what, where, why
--------   ---     ----------------------------------------------------------
03/16/93   jah     Added extern of rex_int_level so that tasks could see the
                   current level of interrupt nesting.
02/23/93   jah/gb  Added TIMETEST code for task performance analysis using
                   an 8-bit buffered output.
04/23/92   ip      Changed signals type to rex_sigs_type (still one WORD).
04/22/92   ip      Initial porting of file from Brassboard to DMSS.

===========================================================================*/

//#include "comdef.h"
#define	word	WORD
#define	dword	DWORD
#define	boolean BYTE
#define	qword	QWORD

typedef  signed char    INT1;        /* Signed 8  bit value type. */
typedef  int            INT2;        /* Signed 16 bit value type. */
typedef  long int       INT4;        /* Signed 32 bit value type. */
typedef  __int16        int2;

#define  ARR_SIZE( a )  ( sizeof( (a) ) / sizeof( (a[0]) ) )

#define  MAX( x, y ) ( ((x) > (y)) ? (x) : (y) )
#define  MIN( x, y ) ( ((x) < (y)) ? (x) : (y) )

/*===========================================================================

                       DATA DECLARATIONS

===========================================================================*/

/*---------------------------------------------------------------------------
                           REX SIGNALS TYPE
---------------------------------------------------------------------------*/

typedef  WORD  rex_sigs_type;

/*---------------------------------------------------------------------------
                 REX TASK CONTEXT BLOCK (TCB) TYPE

Use this type for defining TCBs for REX tasks. Do NOT directly access any
of the TCB fields - that's REX's job.

Important Note: In order to optimize performance, REX assumes that all TCB's
are within the DGROUP group. The typedef for rex_tcb_type uses the 'near'
attribute which guarantees the defined TCB will be in DGROUP. Notice that TCB
variables cannot be declared as automatic (i.e., on the stack). If you want
to declare a TCB to be local to a function, you must use the 'static' attri-
bute.
---------------------------------------------------------------------------*/

typedef struct rex_tcb_struct  /* Do NOT access the fields of this */
{                              /* structure directly!              */
  struct
  {
    struct rex_tcb_struct near  *next_ptr;
    struct rex_tcb_struct near  *prev_ptr;
  } link;
        WORD            slices;
        WORD            sp;
        WORD            ss;
        rex_sigs_type   sigs;
        WORD            wait;
        WORD            pri;
#ifdef TIMETEST
        WORD            leds;
#endif
}
near rex_tcb_type;
  /* The 'near' attribute forces inclusion in DGROUP. */


/*---------------------------------------------------------------------------
                     REX TIMER BLOCK TYPE

Use this type for defining REX Timer Blocks. Do NOT directly access any
of the Timer Block fields - that's REX's job.

Important Note: In order to optimize performance, REX assumes that all timers
are within the DGROUP group. The typedef for rex_timer_type uses the 'near'
attribute which guarantees the defined timer will be in DGROUP. Notice that
timer variables cannot be declared as automatic (i.e., on the stack). If you
want to declare a timer to be local to a function, you must use the 'static'
attribute.
---------------------------------------------------------------------------*/

#define REX_MAX_PRIORITY 65535U
  /* used to make the current task the highest priority task, forcing task
     switching to be effectively stopped until the priority is returned
     to normal */

typedef struct rex_timer_struct  /* Do NOT access the fields of this */
{                                /* structure directly!              */
  struct
  {
    struct rex_timer_struct near  *next_ptr;
    struct rex_timer_struct near  *prev_ptr;
  }
                link; 

  WORD            cnt;
  rex_tcb_type    *tcb_ptr;
  rex_sigs_type   sigs;
}
near rex_timer_type;
  /* The 'near' attribute forces inclusion in DGROUP. */


/*===========================================================================

                        FUNCTION DECLARATIONS

===========================================================================*/


/*===========================================================================

FUNCTION NV_CMD

DESCRIPTION

DEPENDENCIES

RETURN VALUE

SIDE EFFECTS

===========================================================================*/

//extern WORD  rex_clr_sigs ( rex_tcb_type *tcb_ptr, rex_sigs_type sigs ); 

//extern WORD  rex_set_sigs ( rex_tcb_type *tcb_ptr, rex_sigs_type sigs );

//extern WORD  rex_get_sigs ( rex_tcb_type *tcb_ptr );

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

//extern void  rex_def_timer ( rex_timer_type *timer_ptr,
//                             rex_tcb_type   *tcb_ptr,
//                             rex_sigs_type  sigs        );

//extern WORD  rex_clr_timer ( rex_timer_type *timer_ptr );

//extern WORD  rex_set_timer ( rex_timer_type *timer_ptr, WORD msecs );

//extern WORD  rex_get_timer ( rex_timer_type *timer_ptr );

//extern void  rex_tick ( WORD msecs );

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

//extern WORD  rex_wait ( rex_sigs_type sigs );

//extern WORD  rex_timed_wait ( rex_sigs_type  sigs,
//                              rex_timer_type *timer_ptr,
//                              WORD           msecs       );

//extern void  rex_def_task ( rex_tcb_type *tcb_ptr,
//                            WORD far     stack[],
//                            WORD         stack_siz,
//                            WORD         pri,
//                            void (far *task_proc_ptr)(dWORD param),
//                            dWORD        param                      );

//extern rex_tcb_type  *rex_self ( void );

//extern WORD  rex_set_pri ( WORD pri );

//extern WORD  rex_get_pri ( void );

/*-   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -   -*/

//extern void  rex_int_prolog ( void );

//extern void  rex_int_epilog ( void );

//extern void  rex_init ( WORD far     istack[ ],
//                        WORD         istack_siz,
//                        rex_tcb_type *tcb_ptr,
//                        WORD far     stack[ ],
//                        WORD         stack_siz,
//                        WORD         pri,
//                        void (far *task_proc_ptr)(dWORD param),
//                        dWORD        param                      );

//#ifdef TIMETEST
//extern WORD rex_led_buf;
//#endif

//extern int2 rex_int_level;

#endif /* REX_H */
