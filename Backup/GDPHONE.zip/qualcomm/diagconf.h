#ifndef _DIAGCONF_H 
#define _DIAGCONF_H

/*==========================================================================

  C O N F I G U R A T I O N   O F   P O W E R   A D J U S T M E N T

                             T A B L E S

                        H E A D E R   F I L E


DESCRIPTION
  Data declarations to support the configuration of the power adjustment
  tables.

  Copyright (c) 1992 by QUALCOMM, Incorporated.  All Rights Reserved.
===========================================================================*/


/*===========================================================================

                      EDIT HISTORY FOR FILE

This section contains comments describing changes made to this file.
Notice that changes are listed in reverse chronological order.

      $Header:   Z:/CMtest/CMtest(3.61)/WInclude/DIAGCONF.H-arc   1.0   Feb 14 2000 15:35:20   hyun  $

when       who     what, where, why
--------   ---     ----------------------------------------------------------
04/10/92   twp     First release

===========================================================================*/


/*===========================================================================

                        DATA DECLARATIONS

===========================================================================*/

#pragma pack(1)        /* DM <--> DMSS packet definitions are BYTE packed */

/*
   The set of parameters that can be downloaded or retreived. 
*/

//typedef enum {
#define  CONF_ID_APC_TAB1_I	0                 /* A power control look-up-table    */
#define  CONF_ID_APC_TAB2_I	1
#define  CONF_ID_APC_TAB3_I	2
#define  CONF_ID_APC_TAB4_I	3
#define  CONF_ID_MAX_I		4                       /* The last enum entry, not used
                                         except to terminate this list    */
//} conf_item_id_type;
typedef WORD conf_item_id_type;

/*
   The set of actions that can be performed on the defined parameters.
*/

//typedef enum {
#define CONF_ACT_WRITEALL_F		0              /* Write the entire item to its permanent
										         storage location  (NV)           */
#define CONF_ACT_WRITESOME_F	1             /* Write some specified part of the item
											     to its permanent location (NV)   */
#define CONF_ACT_READALL_F		2            /* Read and return the entire item  */
#define CONF_ACT_READSOME_F		3              /* Read and return some specified part
										       of the item.                     */
#define CONF_ACT_USEALL_F       4         /* Use the entire item, but do not store
                                      in its permanent location        */
#define CONF_ACT_USESOME_F      5         /* Use some specified part of the item,
                                      but do not store in its permanent
                                      location                         */
#define CONF_ACT_TEST_F         6         /* The first (of how many?) tests to
                                      perform using the loaded data */
#define CONF_ACT_MAX_F          7          /* The last enum entry, not used except
                                      to terminate this list           */
//} conf_item_action_type;
typedef WORD conf_item_action_type;



/*
   The parameter download/retrieval header.
*/

typedef struct
{
 conf_item_action_type  action;    /*  Identifies the operation          */
 conf_item_id_type          id;    /*  Identifies the parameter          */
 WORD                     size;    /*  Size (in BYTEs) of the parameter
                                       data                              */
 WORD                   offset;    /*  For operations involving only some
                                       of the parameter (large lookup
                                       tables), the offset, in BYTEs, from 
                                       the beginning of the parameter 
                                       item.  */
} conf_hdr_type;


/*===========================================================================

   The definitions of all the parameter items

============================================================================*/

/*
   The analog power control look-up-table types are in flux
*/

#define  APC_TAB1_SIZ 256
#define  APC_TAB2_SIZ 256
#define  APC_TAB3_SIZ  32
#define  APC_TAB4_SIZ   1

typedef BYTE  conf_apc_tab1_type[  APC_TAB1_SIZ  ] ;
typedef BYTE  conf_apc_tab2_type[  APC_TAB2_SIZ  ] ;
typedef BYTE  conf_apc_tab3_type[  APC_TAB3_SIZ  ] ;
typedef BYTE  conf_apc_tab4_type[  APC_TAB4_SIZ  ] ;




/*===========================================================================

   The parm_data_type is a union of all the defined parameter types

============================================================================*/

typedef union
{
 conf_apc_tab1_type      apc1;
 conf_apc_tab2_type      apc2;
 conf_apc_tab3_type      apc3;
 conf_apc_tab4_type      apc4;
} conf_data_type;

#pragma pack()             /* restore default packing */

#endif  /* DIAGCONF_H */
