// Util.h: interface for the CUtil class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UTIL_H__4249CBC7_E0E1_44FA_B0F0_C5A7E9D586FB__INCLUDED_)
#define AFX_UTIL_H__4249CBC7_E0E1_44FA_B0F0_C5A7E9D586FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "afxtempl.h"

class CUtil  
{
public:
	CUtil();
	virtual ~CUtil();

	static CString PopTrace();
	static void GDTrace(char *szFormat, ...);
	static CString ExtractBtwLFCR(CString sInputStr);
	static CString ExtractBtwStxEtx(CString sInputStr);
	static CString AttachLF(CString sInputStr);
	static CString AttachCR(CString sInputStr);
	static int GetUSBPortNo(CString sDriverName);
	static int GetCampRequestBandIndex(int nBand);
	static byte GetCampRequestBandSubCommand(int nBand);
	static byte GetValueFromWlanType_Testmode(int nWlanType);
	static CString GetValueFromeWlanType_Atcommand(int nWlanType);
	static CString GetLastError();

// Attribute
protected:
	static CStringList m_TraceQueue;
	static const int m_nTraceQueueSize;
};

#endif // !defined(AFX_UTIL_H__4249CBC7_E0E1_44FA_B0F0_C5A7E9D586FB__INCLUDED_)
