#ifndef _GDPHONEDEFINE
#define _GDPHONEDEFINE

//============================================
// Structure
//============================================

#define		SEARCH_RETRY_CNT	 3
#define     NV_MAX_MINS          2        /* Up to 2 MINs per NAM allowed */

#pragma pack(1)

typedef struct tagPhoneStatus
{
  BYTE    cmd_code;               /* Command code                      0  */
  BYTE    demod;                  /* Demod id BYTE                     1  */
  BYTE    decode;                 /* Decoder id BYTE                   2  */
  BYTE    inter;                  /* Interleaver id BYTE               3  */
  DWORD   esn;                    /* Mobile Electronic Serial Number 4-7  */
  
  WORD    rf_mode;                /* 0->analog,  1->cdma,  2->pcn    8-9  */
  DWORD   min1[NV_MAX_MINS];      /* all MIN1s      8               10-17  */
  WORD    min2[NV_MAX_MINS];      /* all MIN2s      4               18-21  */
  BYTE    orig_min;               /* index (0-3) of the orig MIN       22 */

  WORD    cdma_rx_state;          /* current state for cdma only    23-24 */
  BYTE    cdma_good_frames;       /* whether or not frames we are      25
                                     receiving are good -- cdma only      */
  WORD    analog_corrected_frames;/* good frame count - analog only 25-27 */
  WORD    analog_bad_frames;      /* bad frame count - analog only  28-29 */
  WORD    analog_word_syncs;      /*  -- analog only                30-31 */

  WORD    entry_reason;           /* entry reason                   32-33 */
  WORD    curr_chan;              /* center frequency channel       34-35 */
  BYTE    cdma_code_chan;         /* code for current channel-cdma only36 */
  WORD    pilot_base;             /* pilot pn of current cell-cdma o37-38 */

  WORD    sid;                    /* Current System ID              39-40 */
  WORD    nid;                    /* Current Network ID             41-42 */
  WORD    locaid;                 /* Current Location ID            43-44 */
  WORD    rssi;                   /* Current RSSI level             45-46 */
  BYTE    power;                  /* Current mobile output power level 47 */
} PHONESTATUS, *LPPHONESTATUS;

//  [7/17/2006] vivache Spy Class �߰�
#pragma pack()

//  [3/18/2010] vivache : DIAG CALL ����
const WORD DIAG_VOICE_CALL = 11;
const WORD DIAG_LOOPBACK_CALL = 2;

//============================================
// Interface Abstact Class
//============================================
class CInstrumentEvent;
// GDPhone abstract class should be derived by each vendor-specific phone class.
// Client code must receive a instance pointer by "GetPhone" export-function 
//  in GDPhone.dll and cast it into this abstract class to use.
class GDPhoneInterface
{
public:
	virtual BOOL SearchSWVersion(int nPortNo, BOOL bIsCDMA, CString &sSWVersion) = 0;
	virtual BOOL InitPhone(int nCommMode) = 0;
	virtual BOOL ExitPhone() = 0;
	virtual BOOL Open(int nPortNo, int nBaudRate, BOOL bUSB = FALSE) = 0;
	virtual BOOL OpenUSB(CString &sDriverName) = 0;
	virtual BOOL Close() = 0;
	virtual BOOL Init() = 0;
	virtual BOOL IsPhoneConnected() = 0;
	virtual BOOL GetSWVersion(CString &sSWVersion) = 0;
	virtual BOOL GetProductID(CString &sProductID) = 0;
	virtual BOOL SetProductID(CString sProductID) = 0;
	virtual BOOL GetESNIMEI(CString &sESNIMEI, BOOL bIsIMEI = FALSE) = 0;
	virtual BOOL GetMEID(CString &sMEID) = 0;
	virtual BOOL SetKeyPad(DWORD dwKeyStr, BOOL bLongKey) = 0;
	virtual BOOL SetKeyPadLock(BOOL bLock) = 0;
	virtual BOOL CheckRegister(BOOL& bIsCAMP) = 0;
	virtual BOOL SetBand(int nBandIndex) = 0;
	virtual BOOL SetChannel(double dChannel) = 0;
	virtual BOOL SetMode(BYTE byMode) = 0;
	virtual BOOL SetDipSwitch(WORD wValue) = 0;
	virtual BOOL SetBluetoothMode(int nModeIndex, int nPreDelay, CString sCheckStatus = BTMODE_STATUS_BTTMOK) = 0;
	virtual BOOL PhoneReset() = 0;
	virtual BOOL GetPhoneState(int nSystemType, int *nState, CString &sStateDesc) = 0;
	virtual BOOL GetPhoneStatus(LPPHONESTATUS pPhoneStatus) = 0;
	virtual BOOL ChangeDiagPath(WORD uMSM) = 0;
	virtual BOOL SetFTMNV(BOOL bSet) = 0;
	virtual void SetEventHandler(CInstrumentEvent* pSpy) = 0;	//  [7/17/2006] vivache
	virtual BOOL SetTestMode(CString sItemName) = 0;
	virtual BOOL SetVSIM() = 0;		// [12/8/2006] lupis
	virtual BOOL SetEmergencyCall(BOOL bOnOff) = 0;	//  [4/9/2007] vivache : ECALL Function
	virtual BOOL SetMRDMode(int nModeIndex, int nDelay = DEFAULT_MRD_DELAY) = 0;					//  [7/3/2007] vivache : MRD Mode ��ȯ
	virtual BOOL SetWLANMode(BOOL bState, int nPreDelay, int *pnErrCode, int nWlanType = INDEX_WLAN_802_11G) = 0;														//  [7/3/2007] vivache : WLAN Testmode ��ȯ/����
	virtual BOOL SetWLANRxMode(double& fPer, int nChannel, int nDelay = DEFAULT_WLANRX_DELAY) = 0;	//  [7/3/2007] vivache : WLAN Rx Mode
	virtual BOOL SetWLANTxMode(int nChannel, int nLevel) = 0;										//  [7/3/2007] vivache : WLAN Tx Mode
	virtual BOOL IsCalibration() = 0 ;					//  [7/16/2007] vivache : Calibration�� �Ǿ����� check�ϴ� Item�� ����Ͽ� cal ���� Ȯ��
	virtual BOOL GetRSSI(double& fRssi) = 0 ;			//  [10/23/2007] vivache : CDMA Rssi value �о����
	virtual BOOL ChangeUartPath(int nDirection) = 0 ;	//  [10/24/2008] vivache : Dual CPU Model�� ��� Master/Slave �� UART Path switching�� ���ؼ� �����.
	virtual BOOL BandChange(int bandItem) = 0; // [1/8/2009] By Karl. For ADI quad band chipset. Change main band from EUR to US or US to EUR by command.
	virtual BOOL ChangeSystem(int nDirection) = 0;	//  [01/16/2009] lupis : CDMA/UMTS�� ��� �����ϴ� Model�� ��� CDMA/UMTS �� System switching�� ���ؼ� �����.
	virtual BOOL SetCampRequest(int nBand) = 0;	//  [5/26/2009] vivache : GSM �� ���� ��� command.
	virtual BOOL SetSleepMode() = 0 ; //  [9/16/2009] vivache : Sleep mode
	virtual BOOL SetDetach() = 0; //  [9/18/2009] vivache : detach
	virtual BOOL SetOriginCall(WORD wMode = DIAG_VOICE_CALL) = 0;
	virtual BOOL SetEndCall() = 0;
	virtual BOOL SetMimoAntCheck(int nMode) = 0;
	virtual	BOOL SetLteAttach(BOOL bOn) = 0;
	virtual	BOOL SetPidFlag(int nIndex, char cValue) = 0; //  [7/19/2010] JKPARK : û�ְ��� ����
	virtual	BOOL SetL2000Prepare(BOOL bIsVSIM) = 0;
	virtual BOOL SetFlightMode(BOOL bOnOff) = 0;		// [10/15/2010] JKPARK : 	
	virtual BOOL SetQEMmode(BOOL bMode) = 0;			// [4/14/2011] JKPARK : QEM Enable���� ���� �߰�	
	virtual BOOL SetLoopBackCall(BOOL bOnOff) = 0;	//  [7/23/2011] JKPARK : CDMA ���� AT������ Loopback Call function	
	virtual BOOL SetLcdOnOff(BOOL bOnOff) = 0;			// [11/10/2011] JKPARK : LCD ON/OFF �߰� 	
};

// DLL Export Function Pointer
typedef LPVOID (*FP_GET_GDPHONE)(void);

//==============================================
// Define
//==============================================
#define MRD_NORMAL_MODE	0
#define MRD_SUB_RX_PATH 1
#define MRD_MAIN_RX_PATH 2

#define CHANGE_TO_MASTER_UART 0
#define CHANGE_TO_SLAVE_UART 1
#define CHANGE_TO_EUR	6
#define CHANGE_TO_US	8

#define CHANGE_CDMA_TO_UMTS_SYSTEM 0
#define CHANGE_UMTS_TO_CDMA_SYSTEM 1
#define CHANGE_LTE_ON_RF_ON 2
#define CHANGE_LTE_ON_RF_OFF 3
#define CHANGE_LTE_OFF_RF_ON 4

#define MIMO_MAIN_ON_SUB_ON 0
#define MIMO_MAIN_OFF_SUB_ON 1
#define MIMO_MAIN_ON_SUB_OFF 2

const BYTE QC_MODEM_WCDMA_TO_GSM_HANDOVER_ENABLE(10);
const BYTE QC_MODEM_GSM_AUTO_ANSWERING_ENBABLE(11);
const BYTE QC_MODEM_PROTOCOL_RELEASE6_CHANGE(6);		// [7/19/2010] JKPARK : Protocol Release change
//==============================================
// ERROR CODE
//==============================================


#endif