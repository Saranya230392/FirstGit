// UniteDiag.h: interface for the CUniteDiag class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UNITEDIAG_H__434415F4_799E_4600_BFFA_EDE61386AB42__INCLUDED_)
#define AFX_UNITEDIAG_H__434415F4_799E_4600_BFFA_EDE61386AB42__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Phone.h"

class CUniteDiag : public CPhone  
{
public:
	BOOL SetL2000Prepare(BOOL bIsVSIM);
	CUniteDiag();
	virtual ~CUniteDiag();

	BOOL Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB = FALSE);
	int OpenUSB(CString sDriverName);
	BOOL Close();
	BOOL Init();
	BOOL Exit();
	BOOL IsPhoneConnected();
	BOOL GetSWVersion(CString &sSWVersion);
	BOOL GetProductID(CString &sProductID);
	BOOL SetProductID(CString sProductID);
	BOOL GetESNIMEI(CString &sESNIMEI, BOOL bIsIMEI = FALSE);
	BOOL GetMEID(CString &sMEID);
	BOOL SetKeyPad(DWORD dwKeyStr, BOOL bLongKey = FALSE);
	BOOL SetKeyPadLock(BOOL bLock);
	BOOL CheckRegister(BOOL& bIsCAMP);
	BOOL SetBand(int nBandIndex);
	BOOL SetChannel(double dChannel);
	BOOL SetMode(BYTE byMode);
	BOOL SetDipSwitch(WORD wValue);
	BOOL SetBluetoothMode(int nModeIndex, int nPreDelay, CString sCheckStatus = BTMODE_STATUS_BTTMOK);
	BOOL PhoneReset();
	BOOL GetPhoneState(int nSystemType, int *nState, CString &sStateDesc);
	BOOL GetPhoneStatus(LPPHONESTATUS pPhoneStatus);
	BOOL ChangeDiagPath(WORD uMSM);
	BOOL SetFTMNV(BOOL bSet);
	BOOL SetTestMode(CString sItemName, CString &sResult);
	BOOL SetVSIM();
	BOOL SetEmergencyCall(BOOL bOnOff);	
	BOOL SetMRDMode(int nModeIndex, int nDelay = DEFAULT_MRD_DELAY);					
	BOOL SetWLANMode(BOOL bState, int nPreDelay, int *pnErrCode, int nWlanType = INDEX_WLAN_802_11G);												
	BOOL SetWLANRxMode(double& fPer, int nChannel, int nDelay = DEFAULT_WLANRX_DELAY);
	BOOL SetWLANTxMode(int nChannel, int nLevel);										
	BOOL IsCalibration();	
	BOOL GetRSSI(double& fRssi);	
	BOOL ChangeUartPath(int nDirection);
	BOOL BandChange(int bandItem); 
	BOOL ChangeSystem(int nDirection);	
	BOOL SetCampRequest(int nBand);	
	BOOL SetSleepMode();
	BOOL SetDetach(); 
	BOOL SetOriginCall(WORD wMode = DIAG_VOICE_CALL);
	BOOL SetEndCall();
	BOOL SetMimoAntCheck(int nMode);
	BOOL SetLteAttach(BOOL bOn);
	BOOL SetPidFlag(int nIndex, char cValue); //  [7/19/2010] JKPARK : û�ְ��� ����
	BOOL SetFlightMode(BOOL bOnOff);		// [10/15/2010] JKPARK : Thunder Regi �ҷ� ����	
	BOOL SetQEMmode(BOOL bMode);			// [4/14/2011] JKPARK : QEM Enable���� ���� �߰�
	BOOL SetLoopBackCall(BOOL bOnOff);		//  [7/23/2011] JKPARK : CDMA ���� AT������ Loopback Call function		
	BOOL SetLcdOnOff(BOOL bOnOff);			// [11/10/2011] JKPARK : LCD ON/OFF �߰� 	

protected:
	BOOL NVWrite(nv_items_enum_type Item,nv_item_type *Data);
};

#endif // !defined(AFX_UNITEDIAG_H__434415F4_799E_4600_BFFA_EDE61386AB42__INCLUDED_)
