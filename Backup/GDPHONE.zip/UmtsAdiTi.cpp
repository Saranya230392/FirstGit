// UmtsAdiTi.cpp: implementation of the CUmtsAdiTi class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GDPhone.h"
#include "UmtsAdiTi.h"
#include "Util.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUmtsAdiTi::CUmtsAdiTi() : CPhone()
{

}

CUmtsAdiTi::~CUmtsAdiTi()
{

}

//============================================================================
//  1. Function Name : Open
//	2. Description : Phone�� ����� COM Port�� ����
//  3. Parameter : nPortNo - COM��Ʈ ��ȣ
//                 dwBaudRate - BaudRate
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : CDMA / UMTS ����
//============================================================================
BOOL CUmtsAdiTi::Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB)
{
	return CPhone::Open(nPortNo, dwBaudRate, bUSB);
}

//============================================================================
//  1. Function Name : OpenUSB
//	2. Description : Phone�� ����� USB Port�� ����.
//                   Driver�� Loading�Ǵ� �ð����� �ִ� 7�ʱ��� ��ٸ���.
//  3. Parameter : sDriverName - Phone�� ����ϴ� USB Driver�� �̸� �� �Ϻ��̴�.
//                               ���� CDMA ���� Driver, Qualcomm ���� Driver,
//                               EMP ���� Driver, NTT DOCOMO�� Driver�� 4������ �ִ�.
//  4. Return Value : Detect�� USB Port�� ��ȣ�� �����Ѵ�.
//	5. Remark : CDMA / UMTS ����
//============================================================================
int CUmtsAdiTi::OpenUSB(CString sDriverName)
{
	return CPhone::OpenUSB(sDriverName);
}

//============================================================================
//  1. Function Name : Close
//	2. Description : Phone�� ����� COM Port�� �ݴ´�
//  3. Return Value : ����
//	4. Remark : FTM / DMSS ����
//============================================================================
BOOL CUmtsAdiTi::Close()
{
	return CPhone::Close();
}

//============================================================================
//  1. Function Name : Init
//	2. Description : ��Ÿ��(FTM/DMSS/QUALCOMM/EMP/ADITI) Ưȭ�� �ʱ��۾��� �����Ѵ�.
//  3. Return Value : �����ϸ� TRUE
//	4. Remark : FTM/DMSS/QUALCOMM/EMP/ADITI ���� ����
//============================================================================
BOOL CUmtsAdiTi::Init()
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500, _T("OK"));	//  [4/27/2007] vivache

	return bRet;
}

BOOL CUmtsAdiTi::Exit()
{
	return TRUE;
}

//============================================================================
//  1. Function Name : IsPhoneConnected
//	2. Description : Phone�� ����Ǿ� �ִ��� Ȯ���Ѵ�
//  3. Return Value : �����ϸ� TRUE
//	4. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsAdiTi::IsPhoneConnected()
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500, _T("OK")); //  [4/27/2007] vivache

	return bRet;
}

//============================================================================
//  1. Function Name : GetSWVersion
//	2. Description : Phone�� SW Version�� �о�´�
//  3. Parameter : sSWVersion - SW Version�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsAdiTi::GetSWVersion(CString &sSWVersion)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%SWV");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500);	//  [4/27/2007] vivache

	if (bRet)
	{
		sSWVersion = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
	}

	return bRet;
}

//============================================================================
//  1. Function Name : GetProductID
//	2. Description : Phone�� Product ID�� �о�´�
//  3. Parameter : sProductID - Product ID�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsAdiTi::GetProductID(CString &sProductID)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%INFO");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500);	//  [4/27/2007] vivache

	int nPos = -1;
	if (bRet)
	{
		CString sTempPID = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
		nPos = sTempPID.Find(",");
		if ( nPos < 0 )	// Normal Product
		{
			sProductID = sTempPID;
		}
		else	// Dual PID Product
		{
			sProductID = sTempPID.Left(nPos) + "," + sTempPID.Mid(nPos+1);
		}
	}

	return bRet;
}

BOOL CUmtsAdiTi::SetProductID(CString sProductID)
{
	return TRUE;
}

//============================================================================
//  1. Function Name : GetESNIMEI
//	2. Description : Phone�� IMEI�� �о�´�
//  3. Parameter : sESNIMEI - IMEI�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsAdiTi::GetESNIMEI(CString &sESNIMEI, BOOL bIsIMEI)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%IMEI");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500);	//  [4/27/2007] vivache

	if (bRet)
	{
		sESNIMEI = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
	}

	return bRet;
}

//============================================================================
//  1. Function Name : GetMEID
//	2. Description : Phone�� MEID�� �о�´�
//  3. Parameter : sMEID - MEID�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����	/ UMTS ������� ����
//============================================================================
BOOL CUmtsAdiTi::GetMEID(CString &sMEID)
{
	return FALSE;
}

//============================================================================
//  1. Function Name : SetKeyPad
//	2. Description : Phone�� Ű�е带 ������
//  3. Parameter : sKeyStr - Ű�е� �� (EX. 1, 112...)
//                 bLongKey - TRUE�� Long Key�� ��
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsAdiTi::SetKeyPad(DWORD dwKeyStr, BOOL bLongKey)
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sKeyCmd(_T(""));
	CString sKeyStr = *((CString *)dwKeyStr);
	sKeyCmd.Format("AT%%FKPD=\"%s\"", sKeyStr);
	m_pSerial->m_sRequest = CUtil::AttachCR(sKeyCmd);
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500);

	return bRet;
}

BOOL CUmtsAdiTi::SetKeyPadLock(BOOL bLock)
{
	return TRUE;
}

BOOL CUmtsAdiTi::CheckRegister(BOOL& bIsCAMP)
{
	bIsCAMP = FALSE;

	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%CAMP");

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 10 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(500,10) )	
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if( m_pSerial->m_sResponse.Find("CAMP OK") != -1 )	// CAMP OK�̸� CAMP
		{
			bIsCAMP = TRUE;
			return TRUE;
		}
		else if( m_pSerial->m_sResponse.Find("CAMP OK") == -1 &&  m_pSerial->m_sResponse.Find("OK") != -1 )	// �ܼ� OK �̸� NO CAMP
		{
			bIsCAMP = FALSE;
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CUmtsAdiTi::SetBand(int nBandIndex)
{
	return TRUE;
}

BOOL CUmtsAdiTi::SetChannel(double dChannel)
{
	return TRUE;
}

BOOL CUmtsAdiTi::SetMode(BYTE byMode)
{
	return TRUE;
}

BOOL CUmtsAdiTi::SetDipSwitch(WORD wValue)
{
	return TRUE;
}


BOOL CUmtsAdiTi::SetBluetoothMode(int nModeIndex, int nPreDelay, CString sCheckStatus)
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sBluetoothCmd(_T(""));

	/*
	// Modified by Karl For KE800. Issue : When Enter bluetooth mode, reboots.
	// To avoid it, input at command to the Idle screen.
	sBluetoothCmd.Format("AT%%FKPD=E", nModeIndex);
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;   

	//Sleep(1000);
	sBluetoothCmd=_T("");
	*/
	
	sBluetoothCmd.Format("AT%%BTTM=%d", nModeIndex);
	m_pSerial->m_sRequest = CUtil::AttachCR(sBluetoothCmd);
//	BOOL bRet = m_pSerial->AutoProcessing(NULL, 5000, "BTTM OK");
	
	// Algorithm Modification
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 10 ; i++ )
	{
		if(i == 0)
		{
			if ( !m_pSerial->ReadOnly(500, nPreDelay) )
				continue;
		}
		else
		{
			if ( !m_pSerial->ReadOnly(500, 10))
				continue;
		}
		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sCheckStatus) >= 0 )	//  [7/24/2006] BTTM OK or OK Check
			return TRUE;
	}

	return FALSE;
}

BOOL CUmtsAdiTi::PhoneReset()
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%RESTART");

	if ( !m_pSerial->AutoProcessing(NULL,1500));//,_T("OK")) )
		return FALSE;
	
	return TRUE;
}

BOOL CUmtsAdiTi::GetPhoneState(int nSystemType, int *nState, CString &sStateDesc)
{
	return TRUE;
}

BOOL CUmtsAdiTi::GetPhoneStatus(LPPHONESTATUS pPhoneStatus)
{
	return TRUE;
}

BOOL CUmtsAdiTi::ChangeDiagPath(WORD uMSM)
{
	return TRUE;
}

BOOL CUmtsAdiTi::SetFTMNV(BOOL bSet)
{
	return TRUE;
}

BOOL CUmtsAdiTi::SetTestMode(CString sItemName, CString &sResult)
{
	return TRUE;
}

BOOL CUmtsAdiTi::SetVSIM()
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%SIMOFF=1");

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 30 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(2500,10) )	// 1000 -> 2500
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			return TRUE; 
	}

	return FALSE;
}

//  [4/9/2007] vivache : ECall
BOOL CUmtsAdiTi::SetEmergencyCall(BOOL bOnOff)
{
	if ( m_pSerial == NULL )
		return FALSE;

	int i(0);

	//////////////////////////////////////////////////////////////////////////
	if(bOnOff)	//TRUE. ECALL ON
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%ECALL=1");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		for ( i = 0; i < 10 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("ECALL ON") >= 0 )
				return TRUE;
		}
	}
	else	//FALSE. ECALL OFF
	{		
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%ECALL=0");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		for ( i = 0; i < 5 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			{
				return TRUE;
			}
		}
	}	

	return FALSE;
}

BOOL CUmtsAdiTi::SetMRDMode(int nModeIndex, int nDelay)					//  [7/3/2007] vivache : MRD Mode ��ȯ
{
	CString sCommand(_T(""));
	CString sResult(_T("RXMRD OK"));
	BOOL bNextProc(FALSE);

	if ( m_pSerial == NULL )
		return FALSE;

	if(nModeIndex != MRD_NORMAL_MODE && nModeIndex != MRD_SUB_RX_PATH && nModeIndex != MRD_MAIN_RX_PATH)
		return FALSE;

	//////////////////////////////////////////////////////////////////////////
	// 1. change MRD path
	if(nModeIndex == MRD_NORMAL_MODE)	
	{
		sCommand.Format("AT%%RXMRD=%d", MRD_NORMAL_MODE);
	}
	else if(nModeIndex == MRD_SUB_RX_PATH)
	{
		sCommand.Format("AT%%RXMRD=%d", MRD_SUB_RX_PATH);
		//::Sleep(15000);									// [5/21/2009] JKPARK
	}
	else if(nModeIndex == MRD_MAIN_RX_PATH)	
	{
		sCommand.Format("AT%%RXMRD=%d", MRD_MAIN_RX_PATH);
	}

	m_pSerial->m_sRequest = CUtil::AttachCR(sCommand);
	
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(5000,500) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
		{
			bNextProc = TRUE;
			break;
		}
	}

	if(!bNextProc)	return FALSE;

	if(nDelay <= 0)
		nDelay = 50;	//  Sleep(0)����context switching�Ǵ� ���� ����

	Sleep(nDelay);

	//////////////////////////////////////////////////////////////////////////
	// 2. Reset mode state
	bNextProc = FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%MSRESET");
	
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(3500,500) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("MODEM STATE RESET OK") >= 0 )
		{
			bNextProc = TRUE;
			break;
		}
	}

	if(!bNextProc)	return FALSE;

	bNextProc = FALSE;

	Sleep(500);

	return TRUE;
}

BOOL CUmtsAdiTi::SetWLANMode(BOOL bState, int nPreDelay, int *pnErrCode,  int nWlanType /* = INDEX_WLAN_802_11G*/ )								//  [7/3/2007] vivache : WLAN Testmode ��ȯ/����
{
	CString sCommand(_T("AT%WLAN=0"));
	CString sResult(_T("WLAN OFF"));

	if ( m_pSerial == NULL )
		return FALSE;

	if(bState)	// TRUE �̸� WLAN ON���� ����
	{
		sCommand.Format(_T("AT%%WLAN=%s"), CUtil::GetValueFromeWlanType_Atcommand(nWlanType));
		m_pSerial->m_sRequest = CUtil::AttachCR(sCommand);

		sResult.Format("WLAN ON %s", CUtil::GetValueFromeWlanType_Atcommand(nWlanType));
	}
	else
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%WLAN=0");
		sResult = "WLAN OFF";
	}

	if ( !m_pSerial->WriteOnly(NULL) )
	{
		*pnErrCode = GDERR_PHONE_FATAL;
		return FALSE;
	}

	Sleep(500);	// [6/17/2009] vivache : tunning 1000 -> 500

	for ( int i = 0; i < 5 ; i++ )
	{
		if(i == 0)
		{
			if ( !m_pSerial->ReadOnly(1000, nPreDelay) )
				continue;
		}
		else
		{
			if ( !m_pSerial->ReadOnly(1000, 10))
				continue;
		}	
		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			return TRUE;
	}

	if( m_pSerial->m_sResponse.GetLength()>0 )
	{
		*pnErrCode = GDERR_PHONE_NG;
		return FALSE;
	}

	*pnErrCode = GDERR_PHONE_TIMEOUT;
	return FALSE;
}

BOOL CUmtsAdiTi::SetWLANRxMode(double& fPer, int nChannel, int nDelay )	//  [7/3/2007] vivache : WLAN Rx Mode
{
	CString sCommand(_T(""));
	CString sResult(_T(""));
	BOOL bNextProc(FALSE);
	int i(0);

	fPer = 100;	// �ʱ�ȭ.

	if ( m_pSerial == NULL )
		return FALSE;

	//////////////////////////////////////////////////////////////////////////
	// Parameter �˻�
	if(nChannel < 0 || nChannel > 13)
		return FALSE;

	// WLANR Channel ����
	sCommand.Format("AT%%WLANR=\"%d\"", nChannel);
	sResult.Format("\"%d\"", nChannel);

	m_pSerial->m_sRequest = CUtil::AttachCR(sCommand);

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(2000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
		{
			bNextProc = TRUE;
			break;
		}
	}

	if(!bNextProc)
		return FALSE;
	bNextProc = FALSE;

	// ������ ���� FER ���� ����� �� �� ������ wait
	Sleep(nDelay);

	// ������ �о� ���� : [���� �ʿ�] - return value�� ���� �κ��� ���� �ʿ���.
	sCommand.Format("AT%WLANR=1");
	
	m_pSerial->m_sRequest = CUtil::AttachCR(sCommand);
	sResult ="\"";	//  [7/3/2007] return value�� "��" or 0 ��.  "�� �ִ����� Ȯ���ϴ°����� �ϴ� ������.

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(2000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
		{
			bNextProc = TRUE;
			break;
		}
	}

	if(!bNextProc)
		return FALSE;

	bNextProc = TRUE;

	// �� ��ȯ
	sResult = m_pSerial->m_sResponse;
	sResult.Remove('\"');	//  [7/3/2007] ���� ó�� "�� ������" ����

	fPer = atof((const char*)sResult);

	return TRUE;
}

BOOL CUmtsAdiTi::SetWLANTxMode(int nChannel, int nLevel)					//  [7/3/2007] vivache : WLAN Tx Mode
{
	CString sCommand(_T(""));
	CString sResult(_T(""));
	BOOL bNextProc(FALSE);
	int i(0);

	if ( m_pSerial == NULL )
		return FALSE;

	//////////////////////////////////////////////////////////////////////////
	// Parameter �˻�
/*
	if(nChannel < 0 || nChannel > 13)
		return FALSE;
*/

	// WLANT Channel ����
	sCommand.Format("AT%%WLANT=\"%d\"", nChannel);
	sResult.Format("\"%d\"", nChannel);

	m_pSerial->m_sRequest = CUtil::AttachCR(sCommand);

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(500);

	for ( i = 0; i < 7 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(2000, 200) )	// [6/17/2009] vivache :  7ȸ 2000, 500
			continue;
		
		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("OK") >= 0 )				// [7/6/2011] JKPARK : OK���� üũ �ϵ��� �߰���.
		{
			if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			{
				bNextProc = TRUE;
				break;
			}
		}
	}

	if(!bNextProc)
		return FALSE;
	bNextProc = FALSE;

	return TRUE;
}

BOOL CUmtsAdiTi::IsCalibration()
{
/*	CString sProductID(_T(""));
    int nLength(0);
    int nResponse(0); 
	
	const int MAX_RESPONSE_LENGTH(26);
	const int ASCII_NUM_TWO(50), ASCII_NUM_ONE(49), ASCII_NUM_ZERO(48);
 
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%INFO");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500); 

	if (bRet)
	{
		sProductID = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
	}
    
	nLength = sProductID.GetLength();           

	if (nLength > MAX_RESPONSE_LENGTH)
	{
		nResponse = (int)sProductID.GetAt(MAX_RESPONSE_LENGTH);
        
		//--------------------------------------------------------------------
		// nReponse is 50 ( ASCII, number : 2 --> finished cal stage. Calibrated.	
		//             49                 : 1 --> on Start Cal stage, But not Calibrated.        
		//             48                 : 0 or others. --> not even on cal stage. not calibrated.         
        if( nResponse == ASCII_NUM_TWO ) 
		{
			return TRUE;
		}
		else if( nResponse == ASCII_NUM_ONE )
		{
			return FALSE;
		}
  		else 
		{
			return FALSE;
		}
	}
  
	return FALSE; */
	CString sResult(_T("1"));
	BOOL bRet = FALSE;
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->ReadOnly(500, 0);	// [4/29/2009] JKPARK

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%CALCK");
	// [6/9/2010] JKPARK : ���� �з��� ó���Ǵ� �κ� ����.
//	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500, _T("1"));		
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(100);

	for ( int i = 0; i < 3 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(500,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			bRet = TRUE;
		else ;
	}
	
	if(!bRet) return bRet;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%CALDT");		// [4/29/2009] JKPARK
//	bRet = m_pSerial->AutoProcessing(NULL, 1500, _T("1"));

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(100);

	bRet = FALSE;

	for ( i = 0; i < 3 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(500,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			bRet = TRUE;
		else ;
	}
	
	return bRet;
}

BOOL CUmtsAdiTi::GetRSSI(double& fRssi)	//  [10/23/2007] vivache : CDMA Rssi value �о����
{
	return FALSE;
}

BOOL CUmtsAdiTi::ChangeUartPath(int nDirection)	//  [10/24/2008] vivache : Dual CPU Model�� ��� Master/Slave �� UART Path switching�� ���ؼ� �����.
{
	CString sCommand(_T("AT%UARTPATH=0"));
	CString sResult(_T("OK"));

	if ( m_pSerial == NULL )
		return FALSE;

	if(nDirection == CHANGE_TO_MASTER_UART)	// TRUE �̸� WLAN ON���� ����
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%UARTPATH=0");
		sResult = "OK";
	}
	else if(nDirection == CHANGE_TO_SLAVE_UART)
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%UARTPATH=1");
		sResult = "OK";
	}
	else
		return FALSE;

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(1000);

	for ( int i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(2000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			return TRUE;
	}

	return FALSE;
}

BOOL CUmtsAdiTi::BandChange(int bandItem) 	//  [10/24/2008] vivache : Dual CPU Model�� ��� Master/Slave �� UART Path switching�� ���ؼ� �����.
{
	CString sCommand(_T("AT%BNDI="));
	CString sResult(_T("OK"));

	if ( m_pSerial == NULL )
		return FALSE;
	
	Sleep(50);
	
	if(bandItem == CHANGE_TO_US)	// TRUE �̸� US band(GSM850/PCS)�� ����
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%BNDI=8");
		sResult = "BNDI OK";
	}
	else if(bandItem == CHANGE_TO_EUR)
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%BNDI=6");
		sResult = "BNDI OK";
	}
	else
		return FALSE;

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(1000);

	for ( int i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(3000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			return TRUE;
	}

	return FALSE;
}

BOOL CUmtsAdiTi::ChangeSystem(int nDirection)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_Request.req.test_mode.cmd_code = DIAG_TEST_MODE_F;

	if ( nDirection == CHANGE_LTE_ON_RF_ON )
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%LTERFMODE=0");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		for ( int i = 0; i < 10 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
				return TRUE;
		}
	}
	else if ( nDirection == CHANGE_LTE_ON_RF_OFF )
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%LTERFMODE=1");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		return TRUE;

		for ( int i = 0; i < 20 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);

			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
				return TRUE;
		}
	}
	else if ( nDirection == CHANGE_LTE_OFF_RF_ON )
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%LTERFMODE=2");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		return TRUE;

		for ( int i = 0; i < 20 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);

			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
				return TRUE;
		}
	}

	return FALSE;
}

BOOL CUmtsAdiTi::SetCampRequest(int nBand)	//  [5/26/2009] vivache : GSM �� ���� ��� command.
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sCampReqCmd("");
	int nBandIndex = CUtil::GetCampRequestBandIndex(nBand);
	sCampReqCmd.Format("AT%%CAMPREQ=%d", nBandIndex);

	m_pSerial->m_sRequest = CUtil::AttachCR(sCampReqCmd);

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(500);										// [7/20/2011] JKPARK : �߰� 

	for ( int i = 0; i < 10 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(1000,10) )	
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if(m_pSerial->m_sResponse.Find("OK") != -1)	// CAMP REQ OK�̸� TRUE
			return TRUE;							// [7/20/2011] JKPARK : OK ���丸 üũ�ϵ��� ����
	}

	return FALSE;
}

BOOL CUmtsAdiTi::SetSleepMode()	//  [9/16/2009] vivache : Sleep mode
{
	//Not supported

	return FALSE;
}

BOOL CUmtsAdiTi::SetDetach() //  [9/18/2009] vivache : detatch
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sCampReqCmd("");
	sCampReqCmd.Format("AT%%DETACH");

	m_pSerial->m_sRequest = CUtil::AttachCR(sCampReqCmd);

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(500);						// [7/20/2011] JKPARK : �߰� 		

	for ( int i = 0; i < 10 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(1000,100) )	
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if( m_pSerial->m_sResponse.Find("OK") != -1)
			return TRUE;
	}

	return FALSE;
}

BOOL CUmtsAdiTi::SetOriginCall(WORD wMode /* = DIAG_VOICE_CALL */)
{
	return TRUE;
}

BOOL CUmtsAdiTi::SetEndCall()
{
	SetEmergencyCall(FALSE);
	return TRUE;
}


BOOL CUmtsAdiTi::SetMimoAntCheck(int nMode)
{
	if ( m_pSerial == NULL )
		return FALSE;

	int i(0);

	//////////////////////////////////////////////////////////////////////////
	if( nMode == MIMO_MAIN_ON_SUB_ON )	//TRUE. ECALL ON
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%MIMOANTCHECK=0");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		Sleep(500);							// [7/23/2011] JKPARK 

		for ( i = 0; i < 10 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
				return TRUE;
		}
	}
	else if(  nMode == MIMO_MAIN_OFF_SUB_ON  )	//FALSE. ECALL OFF
	{		
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%MIMOANTCHECK=1");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		Sleep(500);							// [7/23/2011] JKPARK 

		for ( i = 0; i < 5 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			{
				return TRUE;
			}
		}
	}	
	else if(  nMode == MIMO_MAIN_ON_SUB_OFF  )	//FALSE. ECALL OFF
	{		
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%MIMOANTCHECK=2");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		Sleep(500);							// [7/23/2011] JKPARK 

		for ( i = 0; i < 5 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			{
				return TRUE;
			}
		}
	}	

	return FALSE;
}

BOOL CUmtsAdiTi::SetLteAttach(BOOL bOn)
{
	if ( m_pSerial == NULL )
		return FALSE;

	int i(0);

	//////////////////////////////////////////////////////////////////////////
	if(bOn)	//TRUE. ECALL ON
	{
//===========================================================
//		m_pSerial->m_sRequest = CUtil::AttachCR("ate0");
//		if ( !m_pSerial->AutoProcessing(NULL,1500,_T("OK")) )
//			return FALSE;
		
//		m_pSerial->m_sRequest = CUtil::AttachCR("at+cgerep=1,0");
//		if ( !m_pSerial->AutoProcessing(NULL,1500,_T("OK")) )
//			return FALSE;

//		m_pSerial->m_sRequest = CUtil::AttachCR("at+cops=0,0,\"xxx\",2");
//		if ( !m_pSerial->WriteOnly(NULL) )
//			return FALSE;

//		BOOL bCopsResult = FALSE;

//		for ( int i = 0; i < 120 ; i++ )
//		{
//			if ( !m_pSerial->ReadOnly(1000,10) )
//				continue;

//			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
//			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
//			{
//				bCopsResult = TRUE;
//				break;
//			}
//		}

//		if( !bCopsResult )
//			return FALSE;
//		
//		m_pSerial->m_sRequest = CUtil::AttachCR("at+crsm=176,28423,0,0,9");
//		if ( !m_pSerial->AutoProcessing(NULL,1500,_T("OK")) )
//			return FALSE;
//============================================================

		m_pSerial->m_sRequest = CUtil::AttachCR("AT%LTECALL=1");
		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		Sleep(500);							// [7/23/2011] JKPARK 

		for ( i = 0; i < 10 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
				return TRUE;
		}
	}
	else	//FALSE. ECALL OFF
	{		
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%LTECALL=0");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		Sleep(500);							// [7/23/2011] JKPARK 

		for ( i = 0; i < 5 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			{
				return TRUE;
			}
		}
	}	

	return FALSE;
}

// [7/19/2010] JKPARK : û�ְ��� ����
BOOL CUmtsAdiTi::SetPidFlag(int nIndex, char cValue)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%INFO");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 2500);

	CString sProductID(_T(""));

	if (bRet)
		sProductID = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
	else
		return FALSE;

	if ( sProductID.GetLength() > nIndex )
	{
		sProductID.SetAt(nIndex, cValue);
	}
	else
	{
		char *pszCombinedID = new char[ nIndex + 2 ];
		memset(pszCombinedID, '0', nIndex + 1);
		pszCombinedID[nIndex + 1] = 0;

		for ( int i = 0; i < sProductID.GetLength(); i++ ) pszCombinedID[i] = sProductID.GetAt(i);
		pszCombinedID[nIndex] = cValue;

		sProductID = pszCombinedID;
	}

	CString sAtInfo = _T("AT%INFO=");

	for ( int i = 0; i < sProductID.GetLength(); i++ )
	{
		if ( i != 0 ) sAtInfo += ',';
		if ( i < 22 )
		{
			sAtInfo += sProductID.GetAt(i);
		}
		else
		{
			CString sTemp(_T(""));
			sTemp.Format("%d",(int)sProductID.GetAt(i));
			sAtInfo += sTemp;
		}
	}

	m_pSerial->m_sRequest = CUtil::AttachCR(sAtInfo);
	bRet = m_pSerial->AutoProcessing(NULL, 2500, "OK");

	return bRet;
}

BOOL CUmtsAdiTi::SetL2000Prepare(BOOL bIsVSIM)
{
	m_pSerial->m_sRequest = CUtil::AttachCR("ate0");
	if ( !m_pSerial->AutoProcessing(NULL,1500,_T("OK")) )
		return FALSE;
	
	m_pSerial->m_sRequest = CUtil::AttachCR("at+cgerep=1,0");
	if ( !m_pSerial->AutoProcessing(NULL,1500,_T("OK")) )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("at+cops=0,0,\"xxx\",2");
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	BOOL bCopsResult = FALSE;

	for ( int i = 0; i < 180 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(1000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
		{
			bCopsResult = TRUE;
			break;
		}
	}

	if (bIsVSIM)
		return TRUE;

	if( !bCopsResult )
		return FALSE;
	
	m_pSerial->m_sRequest = CUtil::AttachCR("at+crsm=176,28423,0,0,9");
	if ( !m_pSerial->AutoProcessing(NULL,1500,_T("OK")) )
		return FALSE;

	return TRUE;
}

// [10/15/2010] JKPARK : P500/509 Registration �ҷ� ���� ���� �߰���.
BOOL CUmtsAdiTi::SetFlightMode(BOOL bOnOff) 
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sCampReqCmd("");

	if(bOnOff)
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%FLIGHT=1");
	else
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%FLIGHT=0");
	
//	BOOL bRet = m_pSerial->AutoProcessing(NULL, 3000, _T("OK"));

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(100);

	for ( int i = 0; i < 3 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(1000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			return TRUE;
		else ;
	}
	
	return FALSE;
}

BOOL CUmtsAdiTi::SetQEMmode(BOOL bMode)								//  [4/14/2011] JKPARK 
{
	CString sResult(_T("0"));

	if ( m_pSerial == NULL )
		return FALSE;

	if(bMode)	// 
			m_pSerial->m_sRequest = CUtil::AttachCR("AT%QEM=1");
	else 
			m_pSerial->m_sRequest = CUtil::AttachCR("AT%QEM=0");
	
//	sCommand.Format("AT%%QEM=%s", sResult);

	if ( !m_pSerial->AutoProcessing(NULL,1500,_T("OK")) )
		return FALSE;

	return TRUE;
}

// [7/23/2011] JKPARK : AT����ϴ� CDMA���� LB Call Function
BOOL CUmtsAdiTi::SetLoopBackCall(BOOL bOnOff)
{
	if ( m_pSerial == NULL )
		return FALSE;

	int i(0);

	//////////////////////////////////////////////////////////////////////////
	if(bOnOff)	//TRUE. ECALL ON
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%LBCALL=1");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		for ( i = 0; i < 10 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
				return TRUE;
		}
	}
	else	//FALSE. ECALL OFF
	{		
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%LBCALL=0");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		for ( i = 0; i < 5 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			{
				return TRUE;
			}
		}
	}		

	return FALSE;
}

// [11/10/2011] JKPARK : LCD ON�� DCN ���� �޴� ��� ����.
BOOL CUmtsAdiTi::SetLcdOnOff(BOOL bOnOff)
{
	CString sResult(_T("0"));

	if ( m_pSerial == NULL )
		return FALSE;

	if(bOnOff)	// 
			m_pSerial->m_sRequest = CUtil::AttachCR("AT%LCD=14");
	else 
			m_pSerial->m_sRequest = CUtil::AttachCR("AT%LCD=15");
	
//	sCommand.Format("AT%%QEM=%s", sResult);

	if ( !m_pSerial->AutoProcessing(NULL,1500,_T("LCD")) )
		return FALSE;

	return TRUE;
}