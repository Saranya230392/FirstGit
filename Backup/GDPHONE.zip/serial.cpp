// serialport.cpp: implementation of the SerialPort class.

#include "stdafx.h"
#include "serial.h"
#include "PhoneFactory.h"
#include "Util.h"

#ifdef _DEBUG
	#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
	#define new DEBUG_NEW
#endif


static const WORD CRC_Table[] =
{
	0x0000, 0x1189, 0x2312, 0x329b, 0x4624, 0x57ad, 0x6536, 0x74bf,
	0x8c48, 0x9dc1, 0xaf5a, 0xbed3, 0xca6c, 0xdbe5, 0xe97e, 0xf8f7,
	0x1081, 0x0108, 0x3393, 0x221a, 0x56a5, 0x472c, 0x75b7, 0x643e,
	0x9cc9, 0x8d40, 0xbfdb, 0xae52, 0xdaed, 0xcb64, 0xf9ff, 0xe876,
	0x2102, 0x308b, 0x0210, 0x1399, 0x6726, 0x76af, 0x4434, 0x55bd,
	0xad4a, 0xbcc3, 0x8e58, 0x9fd1, 0xeb6e, 0xfae7, 0xc87c, 0xd9f5,
	0x3183, 0x200a, 0x1291, 0x0318, 0x77a7, 0x662e, 0x54b5, 0x453c,
	0xbdcb, 0xac42, 0x9ed9, 0x8f50, 0xfbef, 0xea66, 0xd8fd, 0xc974,
	0x4204, 0x538d, 0x6116, 0x709f, 0x0420, 0x15a9, 0x2732, 0x36bb,
	0xce4c, 0xdfc5, 0xed5e, 0xfcd7, 0x8868, 0x99e1, 0xab7a, 0xbaf3,
	0x5285, 0x430c, 0x7197, 0x601e, 0x14a1, 0x0528, 0x37b3, 0x263a,
	0xdecd, 0xcf44, 0xfddf, 0xec56, 0x98e9, 0x8960, 0xbbfb, 0xaa72,
	0x6306, 0x728f, 0x4014, 0x519d, 0x2522, 0x34ab, 0x0630, 0x17b9,
	0xef4e, 0xfec7, 0xcc5c, 0xddd5, 0xa96a, 0xb8e3, 0x8a78, 0x9bf1,
	0x7387, 0x620e, 0x5095, 0x411c, 0x35a3, 0x242a, 0x16b1, 0x0738,
	0xffcf, 0xee46, 0xdcdd, 0xcd54, 0xb9eb, 0xa862, 0x9af9, 0x8b70,
	0x8408, 0x9581, 0xa71a, 0xb693, 0xc22c, 0xd3a5, 0xe13e, 0xf0b7,
	0x0840, 0x19c9, 0x2b52, 0x3adb, 0x4e64, 0x5fed, 0x6d76, 0x7cff,
	0x9489, 0x8500, 0xb79b, 0xa612, 0xd2ad, 0xc324, 0xf1bf, 0xe036,
	0x18c1, 0x0948, 0x3bd3, 0x2a5a, 0x5ee5, 0x4f6c, 0x7df7, 0x6c7e,
	0xa50a, 0xb483, 0x8618, 0x9791, 0xe32e, 0xf2a7, 0xc03c, 0xd1b5,
	0x2942, 0x38cb, 0x0a50, 0x1bd9, 0x6f66, 0x7eef, 0x4c74, 0x5dfd,
	0xb58b, 0xa402, 0x9699, 0x8710, 0xf3af, 0xe226, 0xd0bd, 0xc134,
	0x39c3, 0x284a, 0x1ad1, 0x0b58, 0x7fe7, 0x6e6e, 0x5cf5, 0x4d7c,
	0xc60c, 0xd785, 0xe51e, 0xf497, 0x8028, 0x91a1, 0xa33a, 0xb2b3,
	0x4a44, 0x5bcd, 0x6956, 0x78df, 0x0c60, 0x1de9, 0x2f72, 0x3efb,
	0xd68d, 0xc704, 0xf59f, 0xe416, 0x90a9, 0x8120, 0xb3bb, 0xa232,
	0x5ac5, 0x4b4c, 0x79d7, 0x685e, 0x1ce1, 0x0d68, 0x3ff3, 0x2e7a,
	0xe70e, 0xf687, 0xc41c, 0xd595, 0xa12a, 0xb0a3, 0x8238, 0x93b1,
	0x6b46, 0x7acf, 0x4854, 0x59dd, 0x2d62, 0x3ceb, 0x0e70, 0x1ff9,
	0xf78f, 0xe606, 0xd49d, 0xc514, 0xb1ab, 0xa022, 0x92b9, 0x8330,
	0x7bc7, 0x6a4e, 0x58d5, 0x495c, 0x3de3, 0x2c6a, 0x1ef1, 0x0f78
};


CSerial::CSerial()
: m_hComPort(NULL)
, m_nPortNo(0)
, m_dwBaudRate(CBR_38400)
{
	m_osRead.hEvent = NULL;	//  [8/10/2006]
	m_osWrite.hEvent = NULL;

	m_bIsUSB = FALSE;
	m_pPhoneFactory = NULL;	//  [4/4/2008] vivache : Multi
}

CSerial::~CSerial()
{
	if(m_hComPort != NULL)
	{
		Close();
	}
}

const CString CSerial::GetPortName(int nPortNo) const
{
	CString s(_T(""));

	if( (nPortNo >= 10 ) ) //COM port 10�� �̻��̸�
	{
		s.Format("\\\\.\\COM%d", nPortNo);
	}
	else
	{
		s.Format("COM%d", nPortNo);
	}

	return s;
}

BOOL CSerial::Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB)
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();	// For Spy
//	if (!pPhoneFactory)
//		return FALSE;
	
	BYTE byDataBit = DATABITS_8;
	BYTE byParityBit = NOPARITY;
	BYTE byStopBit = ONESTOPBIT;
	
	DCB  dcb;
	BOOL bOK = TRUE;
	HANDLE hPort(NULL);

	CString sTemp(_T(""));

	hPort = CreateFile(GetPortName(nPortNo),	// Port Name
							GENERIC_READ | GENERIC_WRITE,		// Attribute
							0,									// Cannot be Shared (�������� ����)
							NULL,								// Handle Cannot be Inherited
							OPEN_EXISTING,						// Device Open
//							FILE_FLAG_OVERLAPPED,
							FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
							NULL);

	if(hPort == INVALID_HANDLE_VALUE || hPort == NULL) 
	{
		sTemp.Format("[COM Port Open] INVALID HANDLE. CreateFile fail. [%d]", nPortNo);
		m_pPhoneFactory->m_pSpy->SendLogMessage(sTemp);
		return FALSE;
	}

//	if(!SetCommMask(hPort, EV_RXCHAR)) bOK = FALSE;

//	if (!SetupComm(hPort,4096,4096)) bOK = FALSE;
//	if (!PurgeComm(hPort,PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR)) bOK = FALSE;

//	memset( &dcb, 0x00, sizeof( dcb ) );	//  [7/7/2006]
//	dcb.DCBlength = sizeof(DCB);

//	if (!GetCommState(hPort,&dcb))	bOK = FALSE;

//	dcb.BaudRate     = dwBaudRate;
//	dcb.ByteSize     = byDataBit;
//	dcb.Parity       = byParityBit;
//	dcb.StopBits     = byStopBit;
//	dcb.fOutxCtsFlow = FALSE;
//	dcb.fOutxDsrFlow = FALSE;
//	dcb.fDtrControl  = DTR_CONTROL_ENABLE;
//	dcb.fRtsControl  = RTS_CONTROL_ENABLE;
//	dcb.fDsrSensitivity   = FALSE;
//	dcb.fTXContinueOnXoff = FALSE;
//	dcb.fOutX = FALSE;
//	dcb.fInX  = FALSE;

//	if (!SetCommState(hPort, &dcb)) bOK = FALSE;

	if(!SetCommMask(hPort, EV_RXCHAR)) 
	{
		m_pPhoneFactory->m_pSpy->SendLogMessage(CString(_T("SetCommMask Fail : ")) + CUtil::GetLastError());
		CloseHandle(hPort);
		return FALSE;
	}

	if (!SetupComm(hPort,8192,8192)) 
	{
		m_pPhoneFactory->m_pSpy->SendLogMessage(CString(_T("SetupComm Fail : ")) + CUtil::GetLastError());
		CloseHandle(hPort);
		return FALSE;
	}

	if (!PurgeComm(hPort,PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR)) 
	{
		m_pPhoneFactory->m_pSpy->SendLogMessage(CString(_T("PurgeComm Fail : ")) + CUtil::GetLastError());
		CloseHandle(hPort);
		return FALSE;
	}

	memset( &dcb, 0x00, sizeof( dcb ) );	//  [7/7/2006]
	dcb.DCBlength = sizeof(DCB);

	if (!bUSB && !GetCommState(hPort,&dcb))	
	{
		m_pPhoneFactory->m_pSpy->SendLogMessage(CString(_T("GetCommState Fail : ")) + CUtil::GetLastError());
		CloseHandle(hPort);
		return FALSE;
	}

	dcb.BaudRate     = dwBaudRate;
	dcb.ByteSize     = byDataBit;
	dcb.Parity       = byParityBit;
	dcb.StopBits     = byStopBit;
	dcb.fOutxCtsFlow = FALSE;
	dcb.fOutxDsrFlow = FALSE;
	dcb.fDtrControl  = DTR_CONTROL_ENABLE;
	dcb.fRtsControl  = RTS_CONTROL_ENABLE;
	dcb.fDsrSensitivity   = FALSE;
	dcb.fTXContinueOnXoff = FALSE;
	dcb.fOutX = FALSE;
	dcb.fInX  = FALSE;

	if (!bUSB && !SetCommState(hPort, &dcb)) 
	{
		m_pPhoneFactory->m_pSpy->SendLogMessage(CString(_T("SetCommState Fail : ")) + CUtil::GetLastError());
		CloseHandle(hPort);
		return FALSE;
	}

	memset(&m_osWrite,0,sizeof(OVERLAPPED));
	memset(&m_osRead,0,sizeof(OVERLAPPED));

	m_osWrite.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	m_osRead.hEvent  = CreateEvent(NULL, TRUE, FALSE, NULL);

	if (m_osWrite.hEvent == NULL || m_osRead.hEvent == NULL)
	{
		bOK = FALSE;
	}

	if (!bOK)
	{
		
	}
	else
	{
		m_hComPort = hPort;
		m_nPortNo = nPortNo;
		m_dwBaudRate = dwBaudRate;
	}
	
	sTemp.Format("%d, %d", dwBaudRate, nPortNo);
	CString sSerialMonitor = CString("[COM Port Open") + ( bOK? _T("] ") : _T(" Fail] ") ) + sTemp;
	m_pPhoneFactory->m_pSpy->SendLogMessage(sSerialMonitor);
	
	return bOK;
}

BOOL CSerial::Close()
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();	// For Spy
//	if (!pPhoneFactory)
//		return FALSE;

	BOOL bRetVal(TRUE);
	try
	{
		if (m_hComPort != INVALID_HANDLE_VALUE && m_hComPort != NULL)
		{
			SetCommMask(m_hComPort,0);
			PurgeComm(m_hComPort,PURGE_TXABORT | PURGE_TXCLEAR | PURGE_RXABORT | PURGE_RXCLEAR);

			if(!CloseHandle(m_hComPort))
			{
				bRetVal = FALSE;
			}

			m_hComPort = NULL;
		}
	}
	catch(...) {}

	try
	{
		if(m_osRead.hEvent != NULL)
		{
			if(!CloseHandle(m_osRead.hEvent))
				bRetVal = FALSE;

			m_osRead.hEvent = NULL;
		}
	}
	catch(...) {}

	try
	{
		if(m_osWrite.hEvent != NULL)
		{
			if(!CloseHandle(m_osWrite.hEvent))
				bRetVal = FALSE;

			m_osWrite.hEvent = NULL;
		}
	}
	catch(...) {}
	
	CString sComPort(_T(""));
	sComPort.Format(" %d", m_nPortNo);
	CString sSerialMonitor = CString("[COM Port Close") + ( bRetVal? _T("]") : _T(" Fail]") ) + sComPort;
	m_pPhoneFactory->m_pSpy->SendLogMessage(sSerialMonitor);

	return bRetVal;	
}

BOOL CSerial::ReadCommPort(LPSTR lpBuffer,DWORD *dwRxLength, int nPreDelay)
{
	DWORD	dwError;	// ������ ����
    COMSTAT	ComStat;	// cbInQue ����� ����
	clock_t dwTimeOut = clock() + 30000;	// [05/03/2010] JKPARK : Pending I/O Error���� ���� �ڵ�.
	memset(&ComStat,0,sizeof(COMSTAT));

	while(1) 
	{
		Sleep(nPreDelay);
		//Delay(2000);
		// ���� Data�� ���̸� �˾ƺ��� ����
		ClearCommError(m_hComPort,&dwError,&ComStat);

		// ���ۿ� ���ŵ� Data�� ����
		if(ComStat.cbInQue==0) break;

		if(!ReadFile(m_hComPort,lpBuffer,ComStat.cbInQue,&ComStat.cbInQue,&m_osRead)) 
		{
			// [05/03/2010] JKPARK : Pending I/O Error���� �񵿱� ����� ���� �ڵ� �߰���.
			if(GetLastError()==ERROR_IO_PENDING)
			{
				while (!GetOverlappedResult(m_hComPort, &m_osRead, &ComStat.cbInQue, TRUE))
				{
					if (GetLastError() != ERROR_IO_INCOMPLETE)
						break;
					if ( clock() > dwTimeOut )	
						break;					
				}
			}
			else
			//-----------------------------------------------------------------------------
				return FALSE;
		}
		
		// ���� Data�� �޾ư� ������ �����͸� ������ŭ ����
		lpBuffer += ComStat.cbInQue;
		
		// ���� ���� Data�� ���̸� ������ŭ ����
		*dwRxLength += ComStat.cbInQue;

		// ���� ���� Data�� ���̰� MAX_PACKET_SIZE=300 �̻��� �Ǹ� error ó��  
//		if(*dwRxLength >= MAX_PACKET_SIZE) return(ERROR_PACKET_OVERFLOW); 
		if(*dwRxLength >= 2000) return(ERROR_PACKET_OVERFLOW);		// [6/9/2010] JKPARK : JS750G VSIM�� ���� ���� ���� data ���� 1308.

		Delay(10);
	}

	return TRUE;

}

DWORD CSerial::WriteCommPort(LPCVOID lpBuffer, DWORD dwBufferLength)
{
	DWORD dwWritten = 0;

	clock_t dwTimeOut = clock() + 60000;	// For VX11K

	if (!WriteFile(m_hComPort, lpBuffer, dwBufferLength, &dwWritten, &m_osWrite))
	{
		if (ERROR_IO_PENDING == GetLastError())
		{
			while (!GetOverlappedResult(m_hComPort, &m_osWrite, &dwWritten, FALSE))
			{
				DWORD dwError = GetLastError();
				if (GetLastError() != ERROR_IO_INCOMPLETE)
					break;
				if ( clock() > dwTimeOut )	// For VX11K
					break;					// For VX11K
			}
		} 
		else
		{
			return dwWritten;
		}
	}
	return dwWritten;
}

BOOL CSerial::IsControlCharacter(BYTE *Result, BYTE CheckCharacter)
{
	switch (CheckCharacter) {
	// Exlusive_or the 7D or 7E with 0x20
	case ASYNC_HDLC_FLAG:
	case ASYNC_HDLC_ESC: 
		*Result = CheckCharacter ^ (BYTE) ASYNC_HDLC_ESC_MASK;
		return TRUE;
	default:
		*Result = CheckCharacter;
		return FALSE;
	}
}

WORD CSerial::ComputeCRC(WORD CRC, BYTE Data)
{
	UINT nTableIndex = (CRC^Data)&0x00FF;
	return((CRC>>8)^CRC_Table[nTableIndex]);
}

BOOL CSerial::DataToDM()
{
//	CPhoneFactory *pPhoneFactory = CPhoneFactory::GetInstance();	// For Spy
//	if (!pPhoneFactory)
//		return FALSE;

	CString szCmd(_T(""));
	szCmd.Format(_T("%s%c%c"), _T("AT$LGDMGO"),0x0d,0x0a);

	if (m_bIsUSB)	// If the port mode is USB, skip the opening & closing of the port : lupis
	{
		Sleep(400);
		return TRUE;
	}

	int nCurrentBaud(CBR_38400);

	nCurrentBaud = m_dwBaudRate;	//  [7/7/2006]

	if(!Close())
		return FALSE;

	Sleep(200);		// For Safety of Program
	// Baud Rate : 115200
	if (!Open(m_nPortNo, CBR_115200))
		return FALSE;

	WriteCommPort(LPCTSTR(szCmd), szCmd.GetLength());
	m_pPhoneFactory->m_pSpy->SendLogMessage("[TX To Phone] AT$LGDMGO");

	if(!Close())
		return FALSE;

	Sleep(200);		// For Safety of Program
	// Baud Rate : ���� �۾� ���̴� BaudRate�� Open
	if (!Open(m_nPortNo, nCurrentBaud))
		return FALSE;	//  [7/2/2006] vivache
	Sleep(200);

	return TRUE;
}

void CSerial::Delay(clock_t Wait)
{
	clock_t	  Goal;

	Goal = Wait + clock();
	while(Goal>clock())
	{
	}

}

void CSerial::SetUSBState(BOOL bOn)
{
	m_bIsUSB = bOn;
}

BOOL CSerial::IsUSB()
{
	return m_bIsUSB;
}
