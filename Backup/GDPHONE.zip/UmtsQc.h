// UmtsQc.h: interface for the CUmtsQc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_UMTSQC_H__7ADE1264_DC41_4525_A9AD_694679EBB36F__INCLUDED_)
#define AFX_UMTSQC_H__7ADE1264_DC41_4525_A9AD_694679EBB36F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Phone.h"

class CUmtsQc : public CPhone  
{
public:
	CUmtsQc();
	virtual ~CUmtsQc();

	BOOL Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB = FALSE);
	int OpenUSB(CString sDriverName);
	BOOL Close();
	BOOL Init();
	BOOL Exit();
	BOOL IsPhoneConnected();
	BOOL GetSWVersion(CString &sSWVersion);
	BOOL GetProductID(CString &sProductID);
	BOOL SetProductID(CString sProductID);
	BOOL GetESNIMEI(CString &sESNIMEI, BOOL bIsIMEI = FALSE);
	BOOL GetMEID(CString &sMEID);
	BOOL SetKeyPad(DWORD dwKeyStr, BOOL bLongKey = FALSE);
	BOOL SetKeyPadLock(BOOL bLock);
	BOOL CheckRegister(BOOL& bIsCAMP);
	BOOL SetBand(int nBandIndex);
	BOOL SetChannel(double dChannel);
	BOOL SetMode(BYTE byMode);
	BOOL SetDipSwitch(WORD wValue);
	BOOL SetBluetoothMode(int nModeIndex, int nPreDelay, CString sCheckStatus = BTMODE_STATUS_BTTMOK);
	BOOL PhoneReset();
	BOOL GetPhoneState(int nSystemType, int *nState, CString &sStateDesc);
	BOOL GetPhoneStatus(LPPHONESTATUS pPhoneStatus);
	BOOL ChangeDiagPath(WORD uMSM);
	BOOL SetFTMNV(BOOL bSet);
	BOOL SetTestMode(CString sItemName, CString &sResult);
	BOOL SetVSIM();
	BOOL SetEmergencyCall(BOOL bOnOff);	//  [4/9/2007] vivache : Emergency Call
	BOOL SetMRDMode(int nModeIndex, int nDelay = DEFAULT_MRD_DELAY);					//  [7/3/2007] vivache : MRD Mode ��ȯ
	BOOL SetWLANMode(BOOL bState, int nPreDelay, int *pnErrCode, int nWlanType = INDEX_WLAN_802_11G);														//  [7/3/2007] vivache : WLAN Testmode ��ȯ/����
	BOOL SetWLANRxMode(double& fPer, int nChannel, int nDelay = DEFAULT_WLANRX_DELAY);	//  [7/3/2007] vivache : WLAN Rx Mode
	BOOL SetWLANTxMode(int nChannel, int nLevel);										//  [7/3/2007] vivache : WLAN Tx Mode
	BOOL IsCalibration();	//  [7/16/2007] vivache : Calibration�� �Ǿ����� check�ϴ� Item�� ����Ͽ� cal ���� Ȯ��
	BOOL GetRSSI(double& fRssi);	//  [10/23/2007] vivache : CDMA Rssi value �о����
	BOOL ChangeUartPath(int nDirection);	//  [10/24/2008] vivache : Dual CPU Model�� ��� Master/Slave �� UART Path switching�� ���ؼ� �����.
	BOOL BandChange(int bandItem); // [1/8/2009] By Karl. For ADI quad band chipset. Change main band from EUR to US or US to EUR by command.
	BOOL ChangeSystem(int nDirection);	//  [01/16/2009] lupis : CDMA/UMTS�� ��� �����ϴ� Model�� ��� CDMA/UMTS �� System switching�� ���ؼ� �����.
	BOOL SetCampRequest(int nBand);	//  [5/26/2009] vivache : GSM �� ���� ��� command.
	BOOL SetSleepMode();	//  [9/16/2009] vivache : Sleep mode
	BOOL SetDetach(); //  [9/18/2009] vivache : detach
	BOOL SetOriginCall(WORD wMode = DIAG_VOICE_CALL);
	BOOL SetEndCall();
	BOOL SetMimoAntCheck(int nMode);
	BOOL SetLteAttach(BOOL bOn);
	BOOL SetPidFlag(int nIndex, char cValue); //  [7/19/2010] JKPARK : û�ְ��� ����
	BOOL SetL2000Prepare(BOOL bIsVSIM);
	BOOL SetFlightMode(BOOL bOnOff);		// [10/15/2010] JKPARK : Thunder Regi �ҷ� ����	
	BOOL SetQEMmode(BOOL bMode);			// [4/14/2011] JKPARK : QEM Enable���� ���� �߰�	
	BOOL SetLoopBackCall(BOOL bOnOff);		//  [7/23/2011] JKPARK : CDMA ���� AT������ Loopback Call function
	BOOL SetLcdOnOff(BOOL bOnOff);			// [11/10/2011] JKPARK : LCD ON/OFF �߰� 	
};

#endif // !defined(AFX_UMTSQC_H__7ADE1264_DC41_4525_A9AD_694679EBB36F__INCLUDED_)
