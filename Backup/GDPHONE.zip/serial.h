// serialport.h: interface for the SerialPort class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SERIALPORT_H__94D4524A_06D5_4CEB_A29D_408647DAE6EE__INCLUDED_)
#define AFX_SERIALPORT_H__94D4524A_06D5_4CEB_A29D_408647DAE6EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "qualcomm/rex.h"
#include "qualcomm/queue.h"
#include "qualcomm/lgic.h"
#include "qualcomm/nv.h"
#include "qualcomm/2dload.h"
#include "qualcomm/diagconf.h"
#include "qualcomm/diagt.h"
#include "qualcomm/sio.h"
#include "qualcomm/log.h"
#include "qualcomm/hs.h"
#include "qualcomm/cai.h"
#include "qualcomm/parm.h"
#include "qualcomm/err.h"
#include "qualcomm/diagpkt.h"
#include "qualcomm/diagcmd.h"
#include "qualcomm/ftm_rftest.h"

#define	MAX_PACKET_RETRY	10
//#define	MAX_PACKET_SIZE		300
#define	MAX_PACKET_SIZE		4396	// 4096 + 300
#define CONNECT_TIMEOUT		30000

#define ERROR_COMM_OPEN		1001
#define ERROR_COMM_CLOSE	1002
#define ERROR_COMM_READ		1003
#define ERROR_COMM_WRITE	1004

#define	ERROR_PACKET_WRITE		2001
#define	ERROR_PACKET_READ		2002
#define	ERROR_PACKET_TIME_OVER	2003
#define	ERROR_PACKET_CRC		2004
#define	ERROR_PACKET_ACK		2005
#define ERROR_PACKET_OVERFLOW   2006

// Packet Constante
#define	CRC_SEED			0xFFFF
#define	CRC_END				0xF088
#define	ASYNC_HDLC_FLAG		0x7E
#define ASYNC_HDLC_ESC		0x7D
#define ASYNC_HDLC_ESC_MASK	0x20


class CPhoneFactory;

class CSerial 
{
// Operation
public:
	CSerial();
	virtual ~CSerial();

    virtual BOOL Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB = FALSE);	// COM Port Open
    virtual BOOL Close();								// COM Port Close : vivache - return Type BOOL�� ����.

	// Following functions are pure virtual functions to be implemented at derived classes
	virtual int Processing(int nReqLength, int nTimeOut) = 0;
	virtual BOOL AutoProcessing(int nReqLength, int nTimeOut, CString sReturn = "") = 0;

	virtual BOOL ReadOnly(int nTimeOut, int nPreDelay) = 0;
	virtual BOOL WriteOnly(int nReqLength) = 0;

	BOOL ReadCommPort(LPSTR lpBuffer,DWORD *dwRxLength, int nPreDelay = 10); // Wrapping function for the ReadFile
    DWORD WriteCommPort(LPCVOID lpBuffer, DWORD dwBufferLength); // Wrapping function for the WriteFile

protected:
	WORD ComputeCRC(WORD CRC, BYTE Data);	// Retrieves the precalcuted CRC Code

	BOOL IsControlCharacter(BYTE *Result, BYTE CheckCharacter);	// Discern Control Character
    const CString GetPortName(int nPortNo) const;	// Retrives formatted COM port name, such as COM1, COM2...
	void Delay(clock_t Wait);
public:
	BOOL DataToDM();	// Send "AT$LGDMGO" to the phone to make DM Mode
// Attribute
public:
	BOOL IsUSB();
	void SetUSBState(BOOL bOn = TRUE);		// For USB Specific Treatment : lupis
   	diag_req_pkt_type m_Request;	// Set this variable to send packet request
    diag_rsp_pkt_type m_Response;	// Read this variable to receive packet request

	CString m_sRequest;		// Set this variable to send AT request
	CString m_sResponse;	// Read this variable to receive AT Response

// Util
public:
	void SetParent(CPhoneFactory* pPhoneFactory){ m_pPhoneFactory = pPhoneFactory; };

protected:
    int m_nPortNo;	// COM Port Number
	DWORD m_dwBaudRate;	// BaudRate

    HANDLE m_hComPort;	// COM Port Handle
    OVERLAPPED m_osRead;	// COM Port Read Event
    OVERLAPPED m_osWrite;	// COM Port Write Event

	BOOL m_bIsUSB;		// For USB Specific Treatment : lupis

protected:
	CPhoneFactory* m_pPhoneFactory;	//  [4/4/2008] vivache : Multi

	friend class CPhoneFactory;
};

#endif // !defined(AFX_SERIALPORT_H__94D4524A_06D5_4CEB_A29D_408647DAE6EE__INCLUDED_)
