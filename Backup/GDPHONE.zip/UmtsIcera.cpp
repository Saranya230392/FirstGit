// UmtsIcera.cpp: implementation of the CUmtsIcera class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Phone.h"
#include "UmtsIcera.h"
#include "Util.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CUmtsIcera::CUmtsIcera()
{

}

CUmtsIcera::~CUmtsIcera()
{

}

//============================================================================
//  1. Function Name : Open
//	2. Description : Phone�� ����� COM Port�� ����
//  3. Parameter : nPortNo - COM��Ʈ ��ȣ
//                 dwBaudRate - BaudRate
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : CDMA / UMTS ����
//============================================================================
BOOL CUmtsIcera::Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB)
{
	return CPhone::Open(nPortNo, dwBaudRate, bUSB);
}

//============================================================================
//  1. Function Name : OpenUSB
//	2. Description : Phone�� ����� USB Port�� ����.
//                   Driver�� Loading�Ǵ� �ð����� �ִ� 7�ʱ��� ��ٸ���.
//  3. Parameter : sDriverName - Phone�� ����ϴ� USB Driver�� �̸� �� �Ϻ��̴�.
//                               ���� CDMA ���� Driver, Qualcomm ���� Driver,
//                               EMP ���� Driver, NTT DOCOMO�� Driver�� 4������ �ִ�.
//  4. Return Value : Detect�� USB Port�� ��ȣ�� �����Ѵ�.
//	5. Remark : CDMA / UMTS ����
//============================================================================
int CUmtsIcera::OpenUSB(CString sDriverName)
{
	return CPhone::OpenUSB(sDriverName);
}

//============================================================================
//  1. Function Name : Close
//	2. Description : Phone�� ����� COM Port�� �ݴ´�
//  3. Return Value : ����
//	4. Remark : FTM / DMSS ����
//============================================================================
BOOL CUmtsIcera::Close()
{
	return CPhone::Close();
}

//============================================================================
//  1. Function Name : Init
//	2. Description : ��Ÿ��(FTM/DMSS/QUALCOMM/EMP/ADITI) Ưȭ�� �ʱ��۾��� �����Ѵ�.
//  3. Return Value : �����ϸ� TRUE
//	4. Remark : FTM/DMSS/QUALCOMM/EMP/ADITI ���� ����
//             mode ��ȯ byte �ʿ� ���� AT�� ���� OK�� üũ�ϸ� ��
//============================================================================
BOOL CUmtsIcera::Init()
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500, _T("OK"));	

	return bRet;
}

BOOL CUmtsIcera::Exit()
{
	return TRUE;
}

//============================================================================
//  1. Function Name : IsPhoneConnected
//	2. Description : Phone�� ����Ǿ� �ִ��� Ȯ���Ѵ�
//  3. Return Value : �����ϸ� TRUE
//	4. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsIcera::IsPhoneConnected()
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500, _T("OK"));

	return bRet;
}

//============================================================================
//  1. Function Name : GetSWVersion
//	2. Description : Phone�� SW Version�� �о�´�
//  3. Parameter : sSWVersion - SW Version�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsIcera::GetSWVersion(CString &sSWVersion)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%SWV");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 2500);

	if (bRet)
	{
		sSWVersion = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
	}

	return bRet;
}

//============================================================================
//  1. Function Name : GetProductID
//	2. Description : Phone�� Product ID�� �о�´�
//  3. Parameter : sProductID - Product ID�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsIcera::GetProductID(CString &sProductID)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%INFO");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 2500);

	int nPos = -1;
	if (bRet)
	{
		nPos = sProductID.Find(",");
		if ( nPos < 0 )	// Normal Product
		{
			sProductID = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
		}
		else	// Dual PID Product
		{
			sProductID = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse.Left(nPos)) + "," 
				+ CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse.Mid(nPos+1));
		}
	}

	return bRet;
}

BOOL CUmtsIcera::SetProductID(CString sProductID)
{
	return TRUE;
}

//============================================================================
//  1. Function Name : GetESNIMEI
//	2. Description : Phone�� IMEI�� �о�´�
//  3. Parameter : sESNIMEI - IMEI�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsIcera::GetESNIMEI(CString &sESNIMEI, BOOL bIsIMEI)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%IMEI");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 2500);

	if (bRet)
	{
		sESNIMEI = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
	}

	return bRet;
}

//============================================================================
//  1. Function Name : GetMEID
//	2. Description : Phone�� MEID�� �о�´�
//  3. Parameter : sMEID - MEID�� ���� ����
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : FTM / DMSS ����	/ UMTS ������� ����
//============================================================================
BOOL CUmtsIcera::GetMEID(CString &sMEID)
{
	return FALSE;
}

//============================================================================
//  1. Function Name : SetKeyPad
//	2. Description : Phone�� Ű�е带 ������
//  3. Parameter : sKeyStr - Ű�е� �� (EX. 1, 112...)
//                 bLongKey - TRUE�� Long Key�� ��
//  4. Return Value : �����ϸ� TRUE
//	5. Remark : QUALCOMM / ADITI ����. EMP ���� ����
//============================================================================
BOOL CUmtsIcera::SetKeyPad(DWORD dwKeyStr, BOOL bLongKey)
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sKeyCmd(_T(""));
	CString sKeyStr = *((CString *)dwKeyStr);
	sKeyCmd.Format("AT%%FKPD=\"%s\"", sKeyStr);
	m_pSerial->m_sRequest = CUtil::AttachCR(sKeyCmd);
//	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500);

// [06/18/2008] JK : UMTS_QC�� KeyPad������ ���� (OK ó��)
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 10 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(500,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			return TRUE;
	}
//	return bRet;
	return FALSE;
}

BOOL CUmtsIcera::SetKeyPadLock(BOOL bLock)
{
	return TRUE;
}

BOOL CUmtsIcera::CheckRegister(BOOL& bIsCAMP)
{
	bIsCAMP = FALSE;

	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%CAMP");

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 10 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(500,100) )	
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if( m_pSerial->m_sResponse.Find("CAMP OK") != -1 )	// CAMP OK�̸� CAMP
		{
			bIsCAMP = TRUE;
			return TRUE;
		}
		else if( m_pSerial->m_sResponse.Find("CAMP OK") == -1 &&  m_pSerial->m_sResponse.Find("OK") != -1 )	// �ܼ� OK �̸� NO CAMP
		{
			bIsCAMP = FALSE;
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CUmtsIcera::SetBand(int nBandIndex)
{
	return TRUE;
}

BOOL CUmtsIcera::SetChannel(double dChannel)
{
	return TRUE;
}

//////////////////////////////////////////////////
// [06/18/2008] JK : Modem Mode ��ȯ�ϴ� Command.
//	1 : Modem Online (AT+CFUN=1)
//  0 : Modem Offline (AT+CFUN=0)
//////////////////////////////////////////////////

BOOL CUmtsIcera::SetMode(BYTE byMode)
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sCmd(_T(""));

	if ( byMode <= 1 )
		sCmd.Format("AT+CFUN=%d", byMode);
	else if (byMode == QC_MODEM_PROTOCOL_RELEASE6_CHANGE)
		sCmd.Format("AT%%IREL=6");			//  JKPARK : Protocol Release 6 change
	else if (byMode == QC_MODEM_WCDMA_TO_GSM_HANDOVER_ENABLE)
		sCmd.Format("AT%%IGCFCALL");		// [10/1/2009] JKPARK. LUU-2100TI(Icera�ű�Ĩ)�� System Handover �����ϱ� ���� command
	else if (byMode == QC_MODEM_GSM_AUTO_ANSWERING_ENBABLE)
		sCmd.Format("ATS0=3");				// [10/1/2009] JKPARK. GSM Auto Answering ��� ����.
	else ;
	
	m_pSerial->m_sRequest = CUtil::AttachCR(sCmd);

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 10 ; i++ )	
	{
		if ( !m_pSerial->ReadOnly(1000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			return TRUE;
	}
	return FALSE;
}

BOOL CUmtsIcera::SetDipSwitch(WORD wValue)
{
	return TRUE;
}

BOOL CUmtsIcera::SetBluetoothMode(int nModeIndex, int nPreDelay, CString sCheckStatus)
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sBluetoothCmd(_T(""));
	sBluetoothCmd.Format("AT%%BTTM=%d", nModeIndex);
	m_pSerial->m_sRequest = CUtil::AttachCR(sBluetoothCmd);
//	BOOL bRet = m_pSerial->AutoProcessing(NULL, 10000, "BTTM OK");

	// Algorithm Modification
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 10 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(500, nPreDelay) )
			continue;
		
		if ( m_pSerial->m_sResponse.Find(sCheckStatus) >= 0 )
			return TRUE;
	}

	return FALSE;
}

BOOL CUmtsIcera::PhoneReset()
{
	return TRUE;
}

BOOL CUmtsIcera::GetPhoneState(int nSystemType, int *nState, CString &sStateDesc)
{
	return TRUE;
}

BOOL CUmtsIcera::GetPhoneStatus(LPPHONESTATUS pPhoneStatus)
{
	return TRUE;
}

BOOL CUmtsIcera::ChangeDiagPath(WORD uMSM)
{
	return TRUE;
}

BOOL CUmtsIcera::SetFTMNV(BOOL bSet)
{
	return TRUE;
}

BOOL CUmtsIcera::SetTestMode(CString sItemName, CString &sResult)
{
	return TRUE;
}

BOOL CUmtsIcera::SetVSIM()
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%SIMOFF=1");

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( int i = 0; i < 10 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(2500,10) )	// 1000 -> 2500
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			return TRUE;
	}

	return FALSE;
}

BOOL CUmtsIcera::SetEmergencyCall(BOOL bOnOff)
{
	if ( m_pSerial == NULL )
		return FALSE;

	int i(0);

	//////////////////////////////////////////////////////////////////////////
	if(bOnOff)	//TRUE. ECALL ON
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%ECALL=1");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		for ( i = 0; i < 10 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("ECALL ON") >= 0 )
				return TRUE;
		}
	}
	else	//FALSE. ECALL OFF
	{		
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%ECALL=0");

		if ( !m_pSerial->WriteOnly(NULL) )
			return FALSE;

		for ( i = 0; i < 5 ; i++ )
		{
			if ( !m_pSerial->ReadOnly(1000,10) )
				continue;

			TRACE( CString("\n")+m_pSerial->m_sResponse);
			
			if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
			{
				return TRUE;
			}
		}
	}	

	return FALSE;
}

BOOL CUmtsIcera::SetMRDMode(int nModeIndex, int nDelay)					//  [7/3/2007] vivache : MRD Mode ��ȯ
{
	CString sCommand(_T(""));
	CString sResult(_T("RXMRD OK"));
	BOOL bNextProc(FALSE);

	if ( m_pSerial == NULL )
		return FALSE;

	if(nModeIndex != MRD_NORMAL_MODE && nModeIndex != MRD_SUB_RX_PATH && nModeIndex != MRD_MAIN_RX_PATH)
		return FALSE;

	//////////////////////////////////////////////////////////////////////////
	// Previous Job : Superviser mode(Engineering)�� ��ȯ 

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%IPWD=\"iceramdmpwd\"");
	
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for (int i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(1500,500) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("OK") >= 0 )
		{
			bNextProc = TRUE;
			break;
		}
	}

	if(!bNextProc)	return FALSE;

	if(nDelay <= 0)
		nDelay = 50;	//  Sleep(0)����context switching�Ǵ� ���� ����

	Sleep(nDelay);
	
	//////////////////////////////////////////////////////////////////////////
	// 1. change MRD path
	if(nModeIndex == MRD_NORMAL_MODE)	
	{
		sCommand.Format("AT%%RXMRD=%d", MRD_NORMAL_MODE);
	}
	else if(nModeIndex == MRD_SUB_RX_PATH)
	{
		sCommand.Format("AT%%RXMRD=%d", MRD_SUB_RX_PATH);
		//::Sleep(15000);									// [5/21/2009] JKPARK
	}
	else if(nModeIndex == MRD_MAIN_RX_PATH)	
	{
		sCommand.Format("AT%%RXMRD=%d", MRD_MAIN_RX_PATH);
	}

	m_pSerial->m_sRequest = CUtil::AttachCR(sCommand);
	
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(5000,500) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
		{
			bNextProc = TRUE;
			break;
		}
	}

	if(!bNextProc)	return FALSE;

	if(nDelay <= 0)
		nDelay = 50;	//  Sleep(0)����context switching�Ǵ� ���� ����

	Sleep(nDelay);

	//////////////////////////////////////////////////////////////////////////
	// 2. Reset mode state ������. (Icera������ �ʿ� ����)
/*	bNextProc = FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%MSRESET");
	
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	for ( i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(3500,500) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find("MODEM STATE RESET OK") >= 0 )
		{
			bNextProc = TRUE;
			break;
		}
	}

	if(!bNextProc)	return FALSE;

	bNextProc = FALSE;

	Sleep(500); */

	return TRUE;
}

BOOL CUmtsIcera::SetWLANMode(BOOL bState, int nPreDelay,  int *pnErrCode, int nWlanType /* = INDEX_WLAN_802_11G*/ )								//  [7/3/2007] vivache : WLAN Testmode ��ȯ/����
{
	//////////////////////////////////////////////////////////////////////////
	// �����ؾ� ��.
	CString sCommand(_T("AT%WLAN=0"));
	CString sResult(_T("WLAN OFF"));

	if ( m_pSerial == NULL )
		return FALSE;

	if(bState)	// TRUE �̸� WLAN ON���� ����
	{
		sCommand.Format(_T("AT%%WLAN=%s"), CUtil::GetValueFromeWlanType_Atcommand(nWlanType));
		m_pSerial->m_sRequest = CUtil::AttachCR(sCommand);

		sResult.Format("WLAN ON %s", CUtil::GetValueFromeWlanType_Atcommand(nWlanType));
	}
	else
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%WLAN=0");
		sResult = "WLAN OFF";
	}

	if ( !m_pSerial->WriteOnly(NULL) )
	{
		*pnErrCode = GDERR_PHONE_FATAL;
		return FALSE;
	}

	Sleep(500);	// [6/17/2009] vivache : tunning 1000 -> 500

	for ( int i = 0; i < 10 ; i++ )
	{
		if(i == 0)
		{
			if ( !m_pSerial->ReadOnly(1000, nPreDelay) )
				continue;
		}
		else
		{
		if ( !m_pSerial->ReadOnly(1500,10) )	// 10ȸ 1500, 10
				continue;
		}	
		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			return TRUE;
	}

	*pnErrCode = GDERR_PHONE_TIMEOUT;
	return FALSE;
}

BOOL CUmtsIcera::SetWLANRxMode(double& fPer, int nChannel, int nDelay )	//  [7/3/2007] vivache : WLAN Rx Mode
{
	//////////////////////////////////////////////////////////////////////////
	// �����ؾ� ��.
	return FALSE;
}

BOOL CUmtsIcera::SetWLANTxMode(int nChannel, int nLevel)					//  [7/3/2007] vivache : WLAN Tx Mode
{
	//////////////////////////////////////////////////////////////////////////
	// �����ؾ� ��.
	CString sCommand(_T(""));
	CString sResult(_T(""));
	BOOL bNextProc(FALSE);
	int i(0);

	if ( m_pSerial == NULL )
		return FALSE;

	//////////////////////////////////////////////////////////////////////////
	// Parameter �˻�
	if(nChannel < 0 || nChannel > 13)
		return FALSE;

	// WLANT Channel ����
	sCommand.Format("AT%%WLANT=\"%d\"", nChannel);
	sResult.Format("\"%d\"", nChannel);

	m_pSerial->m_sRequest = CUtil::AttachCR(sCommand);

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(500);

	for ( i = 0; i < 7 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(2000, 200) )	// [6/17/2009] vivache : 7ȸ 2000, 500 --> 2000, 10  --> 2000, 200
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
		{
			bNextProc = TRUE;
			break;
		}
	}

	if(!bNextProc)
		return FALSE;
	bNextProc = FALSE;

	return TRUE;
}

BOOL CUmtsIcera::IsCalibration()
{
	CString sResult(_T("1"));
	BOOL bRet = FALSE;
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->ReadOnly(500, 0);	// [4/29/2009] JKPARK

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%CALCK");
	// [6/9/2010] JKPARK : ���� �з��� ó���Ǵ� �κ� ����.
//	BOOL bRet = m_pSerial->AutoProcessing(NULL, 1500, _T("1"));		
	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(100);

	for ( int i = 0; i < 3 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(1000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			bRet = TRUE;
		else ;
	}
	
	if(!bRet) return bRet;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%CALDT");		// [4/29/2009] JKPARK
//	bRet = m_pSerial->AutoProcessing(NULL, 1500, _T("1"));

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(100);

	bRet = FALSE;

	for ( i = 0; i < 3 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(1000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			bRet = TRUE;
		else ;
	}
	
	return bRet;
}

BOOL CUmtsIcera::GetRSSI(double& fRssi)	//  [10/23/2007] vivache : CDMA Rssi value �о����
{
	return FALSE;
}

BOOL CUmtsIcera::ChangeUartPath(int nDirection)	//  [10/24/2008] vivache : Dual CPU Model�� ��� Master/Slave �� UART Path switching�� ���ؼ� �����.
{
	CString sCommand(_T("AT%UARTPATH=0"));
	CString sResult(_T("OK"));

	if ( m_pSerial == NULL )
		return FALSE;

	if(nDirection == CHANGE_TO_MASTER_UART)	// TRUE �̸� WLAN ON���� ����
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%UARTPATH=0");
		sResult = "OK";
	}
	else if(nDirection == CHANGE_TO_SLAVE_UART)
	{
		m_pSerial->m_sRequest = CUtil::AttachCR("AT%UARTPATH=1");
		sResult = "OK";
	}
	else
		return FALSE;

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(1000);

	for ( int i = 0; i < 5 ; i++ )
	{
		if ( !m_pSerial->ReadOnly(2000,10) )
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if ( m_pSerial->m_sResponse.Find(sResult) >= 0 )
			return TRUE;
	}

	return FALSE;
}

BOOL CUmtsIcera::BandChange(int bandItem)
{
	return FALSE;
}

BOOL CUmtsIcera::ChangeSystem(int nDirection)
{
	return FALSE;
}

BOOL CUmtsIcera::SetCampRequest(int nBand)	//  [5/26/2009] vivache : GSM �� ���� ��� command.
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sCampReqCmd("");
	int nBandIndex = CUtil::GetCampRequestBandIndex(nBand);
	sCampReqCmd.Format("AT%%CAMPREQ=%d", nBandIndex);

	m_pSerial->m_sRequest = CUtil::AttachCR(sCampReqCmd);

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;

	Sleep(500);										// [7/20/2011] JKPARK : �߰� 

	for ( int i = 0; i < 10 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(500,100) )	
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if(m_pSerial->m_sResponse.Find("OK") != -1)	// CAMP REQ OK�̸� TRUE
			return TRUE;							// [7/20/2011] JKPARK : OK ���丸 üũ�ϵ��� ����
	}

	return FALSE;
}

BOOL CUmtsIcera::SetSleepMode()	//  [9/16/2009] vivache : Sleep mode
{
	//Not supported

	return FALSE;
}

BOOL CUmtsIcera::SetDetach() //  [9/18/2009] vivache : detatch
{
	if ( m_pSerial == NULL )
		return FALSE;

	CString sCampReqCmd("");
	sCampReqCmd.Format("AT%%DETACH");

	m_pSerial->m_sRequest = CUtil::AttachCR(sCampReqCmd);

	if ( !m_pSerial->WriteOnly(NULL) )
		return FALSE;
	
	Sleep(500);						// [7/20/2011] JKPARK : �߰� 

	for ( int i = 0; i < 10 ; i++ )	//  [12/14/2007] vivache : retry 5 --> 10
	{
		if ( !m_pSerial->ReadOnly(1000,100) )	
			continue;

		TRACE( CString("\n")+m_pSerial->m_sResponse);
		
		if( m_pSerial->m_sResponse.Find("OK") != -1)
			return TRUE;
	}

	return FALSE;
}

BOOL CUmtsIcera::SetOriginCall(WORD wMode /* = DIAG_VOICE_CALL */)
{
	return TRUE;
}

BOOL CUmtsIcera::SetEndCall()
{
	SetEmergencyCall(FALSE);
	return TRUE;
}

BOOL CUmtsIcera::SetMimoAntCheck(int nMode)
{
	return TRUE;
}

BOOL CUmtsIcera::SetLteAttach(BOOL bOn)
{
	return TRUE;
}

BOOL CUmtsIcera::SetPidFlag(int nIndex, char cValue)
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->m_sRequest = CUtil::AttachCR("AT%INFO");
	BOOL bRet = m_pSerial->AutoProcessing(NULL, 2500);

	CString sProductID(_T(""));

	if (bRet)
		sProductID = CUtil::ExtractBtwStxEtx(m_pSerial->m_sResponse);
	else
		return FALSE;

	if ( sProductID.GetLength() > nIndex )
	{
		sProductID.SetAt(nIndex, cValue);
	}
	else
	{
		char *pszCombinedID = new char[ nIndex + 2 ];
		memset(pszCombinedID, '0', nIndex + 1);
		pszCombinedID[nIndex + 1] = 0;

		for ( int i = 0; i < sProductID.GetLength(); i++ ) pszCombinedID[i] = sProductID.GetAt(i);
		pszCombinedID[nIndex] = cValue;

		sProductID = pszCombinedID;
	}

	CString sAtInfo = _T("AT%INFO=");

	for ( int i = 0; i < sProductID.GetLength(); i++ )
	{
		if ( i != 0 ) sAtInfo += ',';
		if ( i < 22 )
		{
			sAtInfo += sProductID.GetAt(i);
		}
		else
		{
			CString sTemp(_T(""));
			sTemp.Format("%d",(int)sProductID.GetAt(i));
			sAtInfo += sTemp;
		}
	}

	m_pSerial->m_sRequest = CUtil::AttachCR(sAtInfo);
	bRet = m_pSerial->AutoProcessing(NULL, 2500, "OK");

	return bRet;
}

BOOL CUmtsIcera::SetL2000Prepare(BOOL bIsVSIM)
{
	return TRUE;
}

// [10/15/2010] JKPARK : P500/509 Registration �ҷ� ���� ���� �߰���.
BOOL CUmtsIcera::SetFlightMode(BOOL bOnOff) 
{
	return TRUE;
}

BOOL CUmtsIcera::SetQEMmode(BOOL bMode)								//  [4/14/2011] JKPARK 
{

	return TRUE;
}

// [7/23/2011] JKPARK : AT����ϴ� CDMA���� LB Call Function
BOOL CUmtsIcera::SetLoopBackCall(BOOL bOnOff)
{
	return TRUE;
}

// [11/10/2011] JKPARK : LCD ON�� DCN ���� �޴� ��� ����.
BOOL CUmtsIcera::SetLcdOnOff(BOOL bOnOff)
{
	return TRUE;
}