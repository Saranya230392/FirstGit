// Phone.cpp: implementation of the CPhone class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GDPhone.h"
#include "Phone.h"
#include "Util.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

const char CPhone::phone_acp[][30] = {
					"No Service               ", //0
					"Analog Initialization    ", //1
					"Analog Idle              ", //2
					"Analog Voic channel init ", //3
					"Analog Waiting for Order ", //4
					"Analog Waiting for Answer", //5
					"Analog Conversation      ", //6
					"Analog Release           ", //7
					"Analog System Access     "};//8
const char CPhone::phone_mcc[][30] = {
					"No Service               ", //128
					"CDMA Initialization      ", //129
					"CDMA Idle                ", //130
					"CDMA Voice channel init  ", //131
					"CDMA Waiting for Order   ", //132
					"CDMA Waiting for Answer  ", //133
					"CDMA Conversation        ", //134
					"CDMA Release             ", //135
					"CDMA Update Overhed Info ", //136
					"CDMA Origination Attempt ", //137
					"CDMA Page Response       ", //138
					"CDMA Order/Msg Response  ", //139
					"CDMA Registration Access ", //140
					"CDMA Message Transmission"};//141
const char CPhone::evdo_call_state[][30] = {
					"EVDO Inactive			  ", //0
					"EVDO Acqusition		  ", //1
					"EVDO Sync				  ", //2
					"EVDO Idle				  ", //3
					"EVDO Access			  ", //4
					"EVDO Conversation		  ", //5
					"EVDO Session Close 	  "};//6
const char CPhone::rel_a_call_state[][30] = {
					"CDMA Idle				  ", //0
					"CDMA Origination		  ", //1
					"?????????? 			  ", //2
					"CDMA Alerting			  ", //3
					"CDMA Alerting			  ", //4
					"CDMA Conversation		  ", //5
					"?????????? 			  "};//6


CPhone::CPhone()
{
	m_pSerial = NULL;
	m_pPhoneFactory = NULL;
}

CPhone::~CPhone()
{

}

void CPhone::SetSerial(CSerial *pSerial)
{
	m_pSerial = pSerial;
}


BOOL CPhone::Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB /* = FALSE */)
{
	if ( m_pSerial == NULL )
		return FALSE;

	BOOL bResult = m_pSerial->Open(nPortNo, dwBaudRate, bUSB);
	m_pSerial->SetUSBState(bUSB);	// FALSE���� Parameter ������� ����. �׳� Open���� ���� USB�� ���ʴ� ������ �Ǵ�

	return bResult;
}

int CPhone::OpenUSB(CString sDriverName)
{
	if ( m_pSerial == NULL )
		return FALSE;

	int nPortNo = 0;
	nPortNo = CUtil::GetUSBPortNo(sDriverName);

	if ( nPortNo <= 0 )
		return (-1);

	if( !m_pSerial->Open(nPortNo, CBR_115200, TRUE) )
		nPortNo = -1;
	else
		m_pSerial->SetUSBState(TRUE);	// ������ Port Close���� �ڵ����� �̷����

	return nPortNo;
}

BOOL CPhone::Close()
{
	if ( m_pSerial == NULL )
		return FALSE;

	m_pSerial->SetUSBState(FALSE);	// USB State�� �����Ǿ� �ִٸ� ����

	return m_pSerial->Close();
}
