// PhoneFactory.cpp: implementation of the CPhoneFactory class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GDPhone.h"
#include "PhoneFactory.h"

#include "Util.h"

#include "CdmaFtm.h"
#include "CdmaDmss.h"
#include "UmtsQc.h"
#include "UmtsEmp.h"
#include "UmtsAdiTi.h"
#include "UmtsIcera.h"		// [8/4/2010] JKPARK 
#include "UniteDiag.h"		// [8/4/2010] JKPARK

#include "PacketComm.h"
#include "ATCommand.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// Static Member ========================
CPhoneFactory *CPhoneFactory::m_pInstance = NULL;

CPhoneFactory *CPhoneFactory::GetInstance()
{
	if (m_pInstance==NULL)
		m_pInstance = new CPhoneFactory;

	return m_pInstance;
}

void CPhoneFactory::DeleteInstance()
{
	if (m_pInstance==NULL)
		return;

	delete m_pInstance;
	m_pInstance = NULL;
}
// ======================================

CPhoneFactory::CPhoneFactory()
{
	m_pPhone = NULL;
	m_pSerial = NULL;
	m_pSpy = NULL;	//  [7/17/2006] vivache
}

CPhoneFactory::~CPhoneFactory()
{

}

BOOL CPhoneFactory::InitPhone(int nCommMode)
{
	ExitPhone();

	switch(nCommMode)
	{
	case INDEX_FTM_MODE :
		m_pSerial = new CPacketComm;
		m_pPhone = new CCdmaFtm;
		break;

	case INDEX_DMSS_MODE :
		m_pSerial = new CPacketComm;
		m_pPhone = new CCdmaDmss;
		break;

	case INDEX_QUALCOMM_MODE :
		m_pSerial = new CATCommand;
		m_pPhone = new CUmtsQc;
		break;

	case INDEX_EMP_MODE :
		m_pSerial = new CATCommand;
		m_pPhone = new CUmtsEmp;
		break;

	case INDEX_ADITI_MODE :
		m_pSerial = new CATCommand;
		m_pPhone = new CUmtsAdiTi;
		break;

	case INDEX_ICERA_MODE :
		m_pSerial = new CATCommand;
		m_pPhone = new CUmtsIcera;
		break;

	case INDEX_UDIAG_MODE :
		m_pSerial = new CPacketComm;
		m_pPhone = new CUniteDiag;
		break;
	
	
	}

	if ( ( m_pSerial == NULL ) || ( m_pPhone == NULL ) )
		return FALSE;

	m_pSerial->SetParent(this);	//  [4/4/2008] vivache : Multi
	m_pPhone->SetParent(this);	//  [4/4/2008] vivache : Multi

	m_pPhone->SetSerial(m_pSerial);
	
	return TRUE;
}

BOOL CPhoneFactory::ExitPhone()
{
	if ( m_pPhone )
	{
		delete m_pPhone;
		m_pPhone = NULL;
	}

	if ( m_pSerial )
	{
		delete m_pSerial;
		m_pSerial = NULL;
	}

	return TRUE;
}

BOOL CPhoneFactory::SearchSWVersion(int nPortNo, BOOL bIsCDMA, CString &sSWVersion)
{
	BOOL bRet = FALSE;

	CPhone *pPhone = NULL;
	CSerial *pSerial = NULL;

	for (int i=0 ; i<SEARCH_RETRY_CNT ; i++)
	{
		if ( bIsCDMA )	// CDMA�̸�
		{
			pSerial = new CPacketComm;
			pPhone = new CCdmaFtm;	// SW Version �б�� FTM�� DMSS�� ����
			pPhone->SetSerial(pSerial);
			pPhone->Open(nPortNo, CBR_38400);
			bRet = pPhone->GetSWVersion(sSWVersion);
			pPhone->Close();
			delete pSerial;
			delete pPhone;
		}
		else	// UMTS�̸�
		{
			pSerial = new CATCommand;
			pSerial->Open(nPortNo, CBR_115200);	// QALCOMM�� EMP�� ���� �����Ѵ�
			pSerial->m_sRequest.Format("%c%c%c%c%cAT%c",0x7E,0x44,0x58,0xF4,0x7E,0x0d);
			if ( pSerial->AutoProcessing(NULL, 700) )
			{
				if ( pSerial->m_sResponse.Find("OK") >= 0 )	// QUALCOMM���� Ȯ���Ѵ�
				{	
					pPhone = new CUmtsQc;
					pPhone->SetSerial(pSerial);
					bRet = pPhone->GetSWVersion(sSWVersion);
					delete pPhone;
				}
				else if ( pSerial->m_sResponse.Find("COMMAND") >= 0 ||	// EMP���� Ȯ���Ѵ�
						  pSerial->m_sResponse.Find("Command") >= 0 )	// Qualcomm command�� ���� ���䶧���� �빮�� ó�� �ȵ�
				{
					pPhone = new CUmtsEmp;
					pPhone->SetSerial(pSerial);
					pPhone->Init();
					bRet = pPhone->GetSWVersion(sSWVersion);
					delete pPhone;
				}
			}
			pSerial->Close();
			delete pSerial;

			if (bRet)
				continue;

			pSerial = new CATCommand;
			pSerial->Open(nPortNo, CBR_19200);	// ADI/TI���� Ȯ���Ѵ�
			pSerial->m_sRequest = CUtil::AttachCR("AT");
			if ( pSerial->AutoProcessing(NULL, 700) )
			{
				if ( pSerial->m_sResponse.Find("OK") >= 0 )	// QUALCOMM
				{	
					pPhone = new CUmtsAdiTi;
					pPhone->SetSerial(pSerial);
					bRet = pPhone->GetSWVersion(sSWVersion);
					delete pPhone;
				}
			}
			pSerial->Close();
			delete pSerial;
		}

		if ( bRet )
			break;
	}

	return bRet;
}

CPhone * CPhoneFactory::GetPhone()
{
	return m_pPhone;
}

void CPhoneFactory::SetEventHandler(CInstrumentEvent* pSpy)	//  [7/17/2006] vivache
{
	if(pSpy == NULL)
		return;

	m_pSpy = pSpy;
}

BOOL CPhoneFactory::IsUSB()
{
	if ( m_pSerial == NULL )
		return FALSE;

	return m_pSerial->IsUSB();
}

BOOL CPhoneFactory::EnableUSB(BOOL bOn)
{
	if ( m_pSerial == NULL )
		return FALSE;

	if ( bOn )	// The case that USB Communication must be began
	{
		 // If the USB port was already opened
		if(m_pSerial->m_hComPort != INVALID_HANDLE_VALUE && m_pSerial->m_hComPort != NULL)
			return TRUE;
		
		int nPortNo = m_pSerial->m_nPortNo;
		DWORD nBaudrate = m_pSerial->m_dwBaudRate;

		if ( nPortNo <= 0 || nBaudrate <= 0 )
			return FALSE;

		return m_pSerial->Open(nPortNo, nBaudrate);
	}
	else	// The case that USB Communication must be ended
	{
		return m_pSerial->Close();
	}
}
