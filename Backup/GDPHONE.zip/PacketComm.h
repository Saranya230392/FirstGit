// PacketComm.h: interface for the CPacketComm class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PACKETCOMM_H__3DD0D602_D9E8_4786_9726_20042C693A0A__INCLUDED_)
#define AFX_PACKETCOMM_H__3DD0D602_D9E8_4786_9726_20042C693A0A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "serial.h"

// The instance of CPacketComm class is use for packet communication with phone

class CPacketComm : public CSerial  
{
public:
	BOOL WriteOnly(int nReqLength);
	BOOL ReadOnly(int nTimeOut, int nPreDelay);
	CPacketComm();
	virtual ~CPacketComm();

	BOOL Open(int nPortNo, DWORD dwBaudRate);
	BOOL Close();
	int Processing(int nReqLength, int nTimeOut);
	BOOL AutoProcessing(int nReqLength, int nTimeOut, CString sReturn = "");
};

#endif // !defined(AFX_PACKETCOMM_H__3DD0D602_D9E8_4786_9726_20042C693A0A__INCLUDED_)
