// ATCommand.cpp: implementation of the CATCommand class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GDPhone.h"
#include "ATCommand.h"
#include "PhoneFactory.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CATCommand::CATCommand() : CSerial()
{

}

CATCommand::~CATCommand()
{

}

BOOL CATCommand::Open(int nPortNo, DWORD dwBaudRate, BOOL bUSB)
{
	return CSerial::Open(nPortNo, dwBaudRate);
}

BOOL CATCommand::Close()
{
	return CSerial::Close();
}

int CATCommand::Processing(int nReqLength, int nTimeOut)
{
	BYTE TxBuff[MAX_PACKET_SIZE];
	ZeroMemory(TxBuff, MAX_PACKET_SIZE);

	int  i,j,nReturn;

	int  nTxLength=0;
	nTxLength = m_sRequest.GetLength() + 1;
	CopyMemory(TxBuff, m_sRequest, nTxLength);

	if (!WriteCommPort(TxBuff, nTxLength-1))
		return(ERROR_PACKET_WRITE);

	//=========== For Debugging
	CString sTxMonitor(_T("[TX to Phone] ")); 
	CString sTemp(_T(""));
	int nMaxMonitor = min(nTxLength, 30);
	for( i=0 ; i < nMaxMonitor ; i++ ) 
	{
		sTemp.Format("%02x ", (int)TxBuff[i]);
		sTxMonitor += sTemp;
	}
	sTxMonitor += " <ASCII>";
	for( i=0 ; i < nMaxMonitor ; i++ ) 
	{
		if ( ( TxBuff[i] >= 'a' && TxBuff[i] <= 'z' ) || ( TxBuff[i] >= 'A' && TxBuff[i] <= 'Z' ) || ( TxBuff[i] >= '0' && TxBuff[i] <= '9' ) )
			sTemp.Format("%c", (char)TxBuff[i]);
		else
			sTemp.Format("%02x", (int)TxBuff[i]);
		sTxMonitor += sTemp;
	}
	m_pPhoneFactory->m_pSpy->SendLogMessage(sTxMonitor);
	//

	Sleep(50);	//  [4/27/2007] vivache : �ӽ�

	BYTE RxBuff[MAX_PACKET_SIZE];
	BYTE RxTmp[MAX_PACKET_SIZE];
	ZeroMemory(RxBuff, MAX_PACKET_SIZE);
	ZeroMemory(RxTmp, MAX_PACKET_SIZE);

	int  nRxLength=0; //���� ����Ʈ�� �ʱ�ȭ 

	clock_t Goal;
	Goal = (clock_t)nTimeOut + clock();

	while(1) 
	{
		nReturn=ReadCommPort((LPSTR)&RxTmp[nRxLength],(DWORD*)&nRxLength);

		if(nReturn==FALSE)
			return(ERROR_PACKET_READ);
		else if(nReturn==ERROR_PACKET_OVERFLOW) 
			return(ERROR_PACKET_OVERFLOW);  
		
        if(nRxLength >0)
			break;

        if(Goal <= clock()) 
			return(ERROR_PACKET_TIME_OVER);
	}

	// ���� ���� ó��
	j = 0;
	BOOL bRealMsg = FALSE;
	for (i=0; i<nRxLength; i++) {
		if ( !bRealMsg && ((RxTmp[i]==0x0A)||(RxTmp[i]==0x25)||(RxTmp[i]==0x44)) ) 
			bRealMsg = TRUE;
		else if ( bRealMsg )
			RxBuff[j++] = RxTmp[i];
		if ( bRealMsg && (j>1) && RxTmp[i] == 0x00 )
			break;
	}

	nRxLength = j;

    if (RxBuff[0] == 0x00) 
		return(ERROR_PACKET_ACK);

	m_sResponse.Format("%s",RxBuff);
	m_sResponse.MakeUpper();

	//=========== For Debugging
	CString sRxMonitor(_T("[Rx From Phone] ")); 
	for( i=0 ; i < nMaxMonitor ; i++ ) 
	{
		sTemp.Format("%02x ", (int)RxBuff[i]);
		sRxMonitor += sTemp;
	}
	sRxMonitor += " <ASCII>";
	for( i=0 ; i < nMaxMonitor ; i++ ) 
	{
		if ( ( RxBuff[i] >= 'a' && RxBuff[i] <= 'z' ) || ( RxBuff[i] >= 'A' && RxBuff[i] <= 'Z' ) || ( RxBuff[i] >= '0' && RxBuff[i] <= '9' ) )
			sTemp.Format("%c", (char)RxBuff[i]);
		else
			sTemp.Format("%02x", (int)RxBuff[i]);
		sRxMonitor += sTemp;
	}
	m_pPhoneFactory->m_pSpy->SendLogMessage(sRxMonitor);
	//

	return TRUE;
}

BOOL CATCommand::AutoProcessing(int nReqLength, int nTimeOut, CString sReturn)
{
	int	nResultPacket;
	sReturn.MakeUpper();

	for (int i=0; i < MAX_PACKET_RETRY; i++) {
		nResultPacket = Processing(nReqLength, nTimeOut);

		switch(nResultPacket)
		{ 
			case 1 : case 2 : 
				if ( sReturn.IsEmpty() ||
					 ((!sReturn.IsEmpty())&&(m_sResponse.Find(sReturn)>=0)) )
					return TRUE;
				continue;

			case ERROR_PACKET_OVERFLOW : // ���� ���� Data�� ���̰� MAX_PACKET_SIZE �̻�
				continue;
			
			case ERROR_PACKET_TIME_OVER : // ������ �ð����� ������ ������ ��Ʈ�� �ݾҴ� ��
				Close();
				Open(m_nPortNo, m_dwBaudRate);
				continue; 
			
			default : // ��� noise���� ����
				Close();
				Open(m_nPortNo, m_dwBaudRate);
				continue; 
		}
	}
	return FALSE;
}

BOOL CATCommand::WriteOnly(int nReqLength)
{
	BYTE TxBuff[MAX_PACKET_SIZE];
	ZeroMemory(TxBuff, MAX_PACKET_SIZE);

	int  nTxLength=0;
	nTxLength = m_sRequest.GetLength() + 1;
	CopyMemory(TxBuff, m_sRequest, nTxLength);

	if (!WriteCommPort(TxBuff, nTxLength-1))
		return FALSE;

	//=========== For Debugging
	CString sTxMonitor(_T("[TX to Phone] ")); 
	CString sTemp(_T(""));
	int nMaxMonitor = min(nTxLength, 30);
	for( int i=0 ; i < nMaxMonitor ; i++ ) 
	{
		sTemp.Format("%02x ", (int)TxBuff[i]);
		sTxMonitor += sTemp;
	}
	sTxMonitor += " <ASCII>";
	for( i=0 ; i < nMaxMonitor ; i++ ) 
	{
		if ( ( TxBuff[i] >= 'a' && TxBuff[i] <= 'z' ) || ( TxBuff[i] >= 'A' && TxBuff[i] <= 'Z' ) || ( TxBuff[i] >= '0' && TxBuff[i] <= '9' ) )
			sTemp.Format("%c", (char)TxBuff[i]);
		else
			sTemp.Format("%02x", (int)TxBuff[i]);
		sTxMonitor += sTemp;
	}
	m_pPhoneFactory->m_pSpy->SendLogMessage(sTxMonitor);
	//

	return TRUE;
}

BOOL CATCommand::ReadOnly(int nTimeOut, int nPreDelay)
{
	BYTE RxBuff[MAX_PACKET_SIZE];
	BYTE RxTmp[MAX_PACKET_SIZE];
	ZeroMemory(RxBuff, MAX_PACKET_SIZE);
	ZeroMemory(RxTmp, MAX_PACKET_SIZE);

	int  nRxLength=0; //���� ����Ʈ�� �ʱ�ȭ 

	clock_t Goal;
	Goal = (clock_t)nTimeOut + clock();

	int  i,j,nReturn;

	while(1) 
	{
		if ( nPreDelay > 0 )
			nReturn=ReadCommPort((LPSTR)&RxTmp[nRxLength], (DWORD*)&nRxLength, nPreDelay);
		else	
			nReturn=ReadCommPort((LPSTR)&RxTmp[nRxLength],(DWORD*)&nRxLength);

		if(nReturn==FALSE)
			return FALSE;
		else if(nReturn==ERROR_PACKET_OVERFLOW) 
			return FALSE;  
		
        if(nRxLength >0)
			break;

        if(Goal <= clock()) 
			return FALSE;
	}

	// ���� ���� ó��
	j = 0;
//	BOOL bRealMsg = FALSE;
	BOOL bRealMsg = TRUE;
	for (i=0; i<nRxLength; i++) {
		if ( !bRealMsg && ((RxTmp[i]==0x0A)||(RxTmp[i]==0x25)||(RxTmp[i]==0x44)) ) 
			bRealMsg = TRUE;
		else if ( bRealMsg )
			RxBuff[j++] = RxTmp[i];
		if ( bRealMsg && (j>1) && RxTmp[i] == 0x00 )
			break;
	}

	nRxLength = j;

    if (RxBuff[0] == 0x00) 
		return FALSE;

	m_sResponse.Format("%s",RxBuff);
	m_sResponse.MakeUpper();

	//=========== For Debugging
	CString sRxMonitor(_T("[Rx From Phone] ")); 
	CString sTemp(_T(""));
	int nMaxMonitor = min(nRxLength, 30);
	for( i=0 ; i < nMaxMonitor ; i++ ) 
	{
		sTemp.Format("%02x ", (int)RxBuff[i]);
		sRxMonitor += sTemp;
	}
	sRxMonitor += " <ASCII>";
	for( i=0 ; i < nMaxMonitor ; i++ ) 
	{
		if ( ( RxBuff[i] >= 'a' && RxBuff[i] <= 'z' ) || ( RxBuff[i] >= 'A' && RxBuff[i] <= 'Z' ) || ( RxBuff[i] >= '0' && RxBuff[i] <= '9' ) )
			sTemp.Format("%c", (char)RxBuff[i]);
		else
			sTemp.Format("%02x", (int)RxBuff[i]);
		sRxMonitor += sTemp;
	}
	m_pPhoneFactory->m_pSpy->SendLogMessage(sRxMonitor);
	//

	return TRUE;
}
