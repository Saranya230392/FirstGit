package com.ant.antplus;

import java.text.DecimalFormat;

import com.ant.antplus.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.*;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

public class ANTPlusSettings extends Activity implements View.OnClickListener
{
   public static final String TAG = "ANTApp";   

   // Menu items
   // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]      
   private enum MyMenu
   {
      MENU_NONE,
      MENU_EXIT,      
      MENU_PAIR_HRM,
      MENU_PAIR_SDM,
      MENU_PAIR_CAD,
      MENU_CONFIG,
      MENU_CONFIG_HRM,
      MENU_CONFIG_SDM,
      MENU_CONFIG_WGT,
      MENU_CONFIG_CAD,
      MENU_CONFIG_PROXIMITY
   };

   // ANT Service 
   public static final int EVENT_ANT_ENABLED = 1;
   public static final int EVENT_ANT_DISABLED = 2;
   static final String ANT_INTERRUPTED_KEY = "ant_interrupted";
   static final String ANT_STATE_KEY = "ant_state";
   public static AntInterface sAntReceiver;

   // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]
   //private boolean mServiceConnected = false;
   private boolean mServiceConnected = true;
   // ANT nicolas.choi@lge.com 20101209 - ANT+ [END]
   
   private boolean mStopped = false;
   private boolean mReceiverDisabled = true;
   private int mNumSearchingDevices = 0;
   private boolean mAntProcessingEnabled;
   private IntentFilter intentFilter;
   private boolean mAntInterrupted = false;  // Flag to know if the ANT App was interrupted

   // ANT Channels
   static final byte HRM_CHANNEL = (byte) 0;
   static final byte SDM_CHANNEL = (byte) 1;
   static final byte WEIGHT_CHANNEL = (byte) 2;
   // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]   
   static final byte CAD_CHANNEL = (byte) 3;

   public enum HeartData
   {
      HEART_RATE, 
      SPO2
   };

   public enum FootData
   {
      SPEED,
      DISTANCE,
      STRIDE_COUNT,
      CADENCE
   };

   public enum WeightData
   {
      WEIGHT
   };

   public enum HRMStatePage
   {
      TOGGLE0,
      TOGGLE1,
      INIT,
      EXT
   }

   public enum CadenceData
   {
	   WEIGHT
   };
  
   // Variables to keep track of the status of each sensor
   private SensorPanel mHeartRate;
   private SensorPanel mFootPod;
   private SensorPanel mWeight;
   // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]   
   private SensorPanel mCadence;
   private TextView mDisabledText;

   // Weight scale state
   private boolean mHasSentProfile;
   private boolean mSessionDone;
   
   // HRM state
   private HRMStatePage mStateHRM = HRMStatePage.INIT;
   
   // SDM state
   private boolean mDistanceInit;
   private boolean mStridesInit;
   private float mAccumDistance;
   private long mAccumStrides;
   private float mPrevDistance;
   private int mPrevStrides;

   // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]
   // CAD state
   //private boolean mHasSentProfile;
   //private boolean mSessionDone;

   // Pairing
   private static final short WILDCARD = 0;

   private static final short FIXED = 25;

   private static final byte DEFAULT_BIN = 7;
   public static final String PREFS_NAME = "ANTDemoPrefs";
   public short mDeviceNumberHRM;
   public short mDeviceNumberSDM;
   public short mDeviceNumberWGT;
   // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]   
   public short mDeviceNumberCAD;
   public byte mProximityThreshold;

   /**
    * Class for receiving notifications about ANT service state.
    */

   private AntInterface.ServiceListener mAntServiceListener = new AntInterface.ServiceListener() 
   { 
       public void onServiceConnected() 
       {
           Log.d(TAG, "mAntServiceListener onServiceConnected()");

		   // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]
           mServiceConnected = true;
           
           // Need to enable the ANT radio, now the service is connected
           if(!sAntReceiver.isEnabled())
           {
              // Make sure not to call AntInterface.enable() again, if it has been already called before
              if(mAntInterrupted == false)
              {
                 if(!enableRadio())
                 {
                     Log.i(TAG, "mAntServiceListener onServiceConnected: ANT radio could not be enabled");
                 }
              }
              else
              {
                 Log.i(TAG,"Not attempting to enable radio as application was interrupted (leaving in previous state).");
              }
           }
           else
           {
              Log.i(TAG,"No need to enable radio as already enabled");
           }

           Log.d(TAG, "mAntServiceListener Displaying icons only if radio enabled");
           updateDisplay();
       }

       public void onServiceDisconnected() 
       {
           Log.d(TAG, "mAntServiceListener onServiceDisconnected()");
           
           mServiceConnected = false;
           updateDisplay();
       }
   };

   /** Called when the activity is first created. */
   @Override
   public void onCreate(Bundle savedInstanceState) 
   {
       super.onCreate(savedInstanceState);
       Log.d(TAG, "onCreate enter");              

       /*Retrieve the ANT state and find out whether the ANT App was interrupted*/
       if (savedInstanceState != null) 
       {
          Bundle antState = savedInstanceState.getBundle(ANT_STATE_KEY);

          if (antState != null) 
          {
              mAntInterrupted = antState.getBoolean(ANT_INTERRUPTED_KEY, false);       
          }
      }

       // Register for ANT intent broadcasts.
       intentFilter = new IntentFilter();
       intentFilter.addAction(AntInterfaceIntent.ANT_ENABLED_ACTION);
       intentFilter.addAction(AntInterfaceIntent.ANT_DISABLED_ACTION);
       intentFilter.addAction(AntInterfaceIntent.ANT_RX_MESSAGE_ACTION);
       registerReceiver(mReceiver, intentFilter);

       sAntReceiver = (AntInterface) getLastNonConfigurationInstance();

       if (sAntReceiver == null) 
       {
           sAntReceiver = AntInterface.getInstance(this.getApplicationContext(), mAntServiceListener);
       }

       mServiceConnected = sAntReceiver.isEnabled();
       setContentView(R.layout.landscape_grid);

       initControls();
       Log.d(TAG, "onCreate exit");
   }

   /** Called between onStop and onDetroy **/
   @Override
   public Object onRetainNonConfigurationInstance() 
   {
       return sAntReceiver;
   }

   /** Called before the activity is destroyed (finished or killed) **/
   @Override protected void onDestroy()
   {
      Log.d(TAG, "onDestroy enter");

      try
      {
         if(isFinishing())
         {
            Log.d(TAG, "onDestroy: isFinishing");
             
            if(!mReceiverDisabled)
            {
               unregisterReceiver(mReceiver);
               mReceiverDisabled = true;
            }
          
            if(mServiceConnected)
            {
               sAntReceiver.destroy();
            }
         }
      }
      catch(Exception e)
      {
         Log.w(TAG, "Exception in onDestroy", e);
      }

      super.onDestroy();

      Log.d(TAG, "onDestroy exit");
   }   

   /** Create options menu **/
   @Override
   public boolean onCreateOptionsMenu(Menu menu) 
   {      
       boolean result = super.onCreateOptionsMenu(menu);

       menu.add(MyMenu.MENU_PAIR_HRM.ordinal(), MyMenu.MENU_PAIR_HRM.ordinal(), 0, this.getResources().getString(R.string.Menu_Wildcard_HRM));
       menu.add(MyMenu.MENU_PAIR_SDM.ordinal(), MyMenu.MENU_PAIR_SDM.ordinal(), 1, this.getResources().getString(R.string.Menu_Wildcard_SDM));
       SubMenu configMenu = menu.addSubMenu(MyMenu.MENU_CONFIG.ordinal(), MyMenu.MENU_CONFIG.ordinal(), 2, this.getResources().getString(R.string.Menu_Sensor_Config));
       menu.add(MyMenu.MENU_EXIT.ordinal(), MyMenu.MENU_EXIT.ordinal(), 3, this.getResources().getString(R.string.Menu_Exit));

       configMenu.add(MyMenu.MENU_CONFIG.ordinal(),MyMenu.MENU_CONFIG_HRM.ordinal(), 0, this.getResources().getString(R.string.Menu_HRM));
       configMenu.add(MyMenu.MENU_CONFIG.ordinal(),MyMenu.MENU_CONFIG_SDM.ordinal(), 1, this.getResources().getString(R.string.Menu_SDM));
       configMenu.add(MyMenu.MENU_CONFIG.ordinal(),MyMenu.MENU_CONFIG_WGT.ordinal(), 2, this.getResources().getString(R.string.Menu_WGT));
       configMenu.add(MyMenu.MENU_CONFIG.ordinal(),MyMenu.MENU_CONFIG_CAD.ordinal(), 3, this.getResources().getString(R.string.Menu_CAD));
       configMenu.add(MyMenu.MENU_CONFIG.ordinal(),MyMenu.MENU_CONFIG_PROXIMITY.ordinal(), 4, this.getResources().getString(R.string.Menu_Proximity));
       return result;
   }

   /** Handle context menu item selections **/
   @Override
   public boolean onOptionsItemSelected(MenuItem item) 
   {
      MyMenu selectedItem = MyMenu.values()[item.getItemId()];

      switch (selectedItem) 
      {         
         case MENU_EXIT:            
            exitApplication();
            break;

         case MENU_PAIR_HRM:
            mDeviceNumberHRM = WILDCARD;
            break;

         case MENU_CONFIG_HRM:
            showDialog(PairingDialog.HRM_ID);
            break;

         case MENU_PAIR_SDM:
            mDeviceNumberSDM = WILDCARD;
            break;

         case MENU_CONFIG_SDM:
            showDialog(PairingDialog.SDM_ID);
            break;

         case MENU_CONFIG_WGT:
            showDialog(PairingDialog.WGT_ID);
            break;
			
         // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]
         case MENU_CONFIG_CAD:
            showDialog(PairingDialog.CAD_ID);
            break;

         case MENU_CONFIG_PROXIMITY:
            showDialog(PairingDialog.PROX_ID);
      }

      return super.onOptionsItemSelected(item);
   }
   

   /** Create settings dialog **/
   protected PairingDialog onCreateDialog(int id)
   {
      PairingDialog theDialog = null;

      if(id == PairingDialog.HRM_ID)
         theDialog = new PairingDialog(this, id, mDeviceNumberHRM, new OnPairingListener());
      else if(id == PairingDialog.SDM_ID)
         theDialog = new PairingDialog(this, id, mDeviceNumberSDM, new OnPairingListener());
      else if(id == PairingDialog.WGT_ID)
         theDialog = new PairingDialog(this, id, mDeviceNumberWGT, new OnPairingListener());
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]
      else if(id == PairingDialog.CAD_ID)
         theDialog = new PairingDialog(this, id, mDeviceNumberCAD, new OnPairingListener());
      else if(id == PairingDialog.PROX_ID)
         theDialog = new PairingDialog(this, id, mProximityThreshold, new OnPairingListener());
      return theDialog;
   }

   /** Listener to updates to the device number **/
   private class OnPairingListener implements PairingDialog.PairingListener 
   {
      public void updateID(int id, short deviceNumber)
      {
         if(id == PairingDialog.HRM_ID)
            mDeviceNumberHRM = deviceNumber;
         else if(id == PairingDialog.SDM_ID)
            mDeviceNumberSDM = deviceNumber;
         else if(id == PairingDialog.WGT_ID)
            mDeviceNumberWGT = deviceNumber;
		 // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]		 
         else if(id == PairingDialog.CAD_ID)
            mDeviceNumberCAD = deviceNumber;		 
      }

      public void updateThreshold(int id, byte proxThreshold)
      {
         if(id == PairingDialog.PROX_ID)
            mProximityThreshold = proxThreshold;
      }
   }


   /** Change properties of dialog **/
   @Override
   protected void onPrepareDialog(int id, Dialog theDialog)
   {
      super.onPrepareDialog(id, theDialog);
      PairingDialog dialog = (PairingDialog) theDialog;
      dialog.setId(id);

      if(id == PairingDialog.HRM_ID)
      {
         dialog.setDeviceNumber(mDeviceNumberHRM);
      }
      else if(id == PairingDialog.SDM_ID)
      {
         dialog.setDeviceNumber(mDeviceNumberSDM);
      }
      else if(id == PairingDialog.WGT_ID)
      {
         dialog.setDeviceNumber(mDeviceNumberWGT);
      }
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	  
      else if(id == PairingDialog.CAD_ID)
      {
         dialog.setDeviceNumber(mDeviceNumberCAD);
      }	  
      else if(id == PairingDialog.PROX_ID)
      {
         dialog.setProximityThreshold(mProximityThreshold);
      }
   }

   /** Called after onStart() **/
   @Override
   protected void onRestoreInstanceState(Bundle savedInstanceState)
   {
      Log.d(TAG, "onRestoreInstanceState");

      mNumSearchingDevices = savedInstanceState.getInt("NumSearchingDevices");

      Bundle savedHRM = savedInstanceState.getBundle("HeartRate");
      mHeartRate.restoreState(savedHRM);

      Bundle savedSDM = savedInstanceState.getBundle("FootPod");
      mFootPod.restoreState(savedSDM);

      Bundle savedWGT = savedInstanceState.getBundle("Weight");
      mWeight.restoreState(savedWGT);
	  
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]
      Bundle savedCAD = savedInstanceState.getBundle("Cadence");
      mCadence.restoreState(savedCAD);
	  
      mHasSentProfile = savedInstanceState.getBoolean("HasSentProfile");
      mSessionDone = savedInstanceState.getBoolean("SessionDone");

      // Initialize cumulative values
      mDistanceInit = savedInstanceState.getBoolean("DistanceInit");
      mStridesInit = savedInstanceState.getBoolean("StridesInit");
      mAccumDistance = savedInstanceState.getFloat("AccumDistance");
      mAccumStrides = savedInstanceState.getLong("AccumStrides");
      mPrevDistance = savedInstanceState.getFloat("PrevDistance");
      mPrevStrides = savedInstanceState.getInt("PrevStrides");
      super.onRestoreInstanceState(savedInstanceState);
   }

   /** Called before onPause() 
    * It is important to save persistent data in onPause() instead of onSaveInstanceState(Bundle)  
    * because the later is not part of the lifecycle callbacks, so will not be called in every 
    * situation as described in its documentation.
    **/

   @Override
   protected void onSaveInstanceState(Bundle outState)
   {
      super.onSaveInstanceState(outState);
      Log.d(TAG, "onSaveInstanceState");
	  
      outState.putInt("NumSearchingDevices", mNumSearchingDevices);

      // save the ANT state into bundle for the activity restart
      mAntInterrupted = true ;
      Bundle antState = new Bundle();
      antState.putBoolean(ANT_INTERRUPTED_KEY, mAntInterrupted);
      antState.putBundle(ANT_STATE_KEY, antState);

      // save the state of current sensor connections
      Bundle savedHRM = mHeartRate.bundleState();
      outState.putBundle("HeartRate", savedHRM);

      Bundle savedSDM = mFootPod.bundleState();
      outState.putBundle("FootPod", savedSDM);

      Bundle savedWGT = mWeight.bundleState();
      outState.putBundle("Weight", savedWGT);

	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]
      Bundle savedCAD = mCadence.bundleState();
      outState.putBundle("Cadence", savedCAD);
	  
      outState.putBoolean("HasSentProfile", mHasSentProfile);
      outState.putBoolean("SessionDone", mSessionDone);

      // Save cumulative values
      outState.putBoolean("DistanceInit", mDistanceInit);
      outState.putBoolean("StridesInit", mStridesInit);
      outState.putFloat("AccumDistance", mAccumDistance);
      outState.putLong("AccumStrides", mAccumStrides);
      outState.putFloat("PrevDistance", mPrevDistance);
      outState.putInt("PrevStrides", mPrevStrides);
   }

   /** Called when the activity is no longer visible **/
   @Override
   protected void onStop()
   {
       mStopped = true;
       // disable ANT messages while in background, unless device search underway

       if(0 == mNumSearchingDevices)
       {
           unregisterReceiver(mReceiver);
           mReceiverDisabled = true;
       }
       super.onStop();
   }

   /** Called when the activity becomes visible **/
   @Override
   protected void onStart()
   {
       super.onStart();
       mStopped = false;

       try
       {
          if(mReceiverDisabled)
          {
             registerReceiver(mReceiver, intentFilter);
             mReceiverDisabled = false;
          }
       }

       catch(Throwable tr)
       {
          Log.e(TAG, "Exception on start", tr);
          finish();
       }
   }

   /** Called when another activity is coming infront of the activity**/
   @Override
   protected void onPause()
   {
      Log.d(TAG, "onPause");
      saveState();

      // disable some processing of ANT messages while UI is not available
      mAntProcessingEnabled = false;
      super.onPause();
   }

   /** Called before the activity starts interacting with the user **/
   @Override    
   protected void onResume()
   {
      Log.d(TAG, "onResume");

      super.onResume();
      loadDefaultConfiguration();
      mAntProcessingEnabled = true;
      updateDisplay(); // Invisible until connected to ANT service and chip enabled
   }

   /** Store application persistent data **/
   private void saveState()
   {
      // Save current Channel Id in preferences
      // We need an Editor object to make changes
      SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
      SharedPreferences.Editor editor = settings.edit();
      editor.putInt("DeviceNumberHRM", mDeviceNumberHRM);
      editor.putInt("DeviceNumberSDM", mDeviceNumberSDM);
      editor.putInt("DeviceNumberWGT", mDeviceNumberWGT);
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	  
      editor.putInt("DeviceNumberCAD", mDeviceNumberCAD);
      editor.putInt("ProximityThreshold", mProximityThreshold);
      editor.commit();
   }

   /** Retrieve application persistent data **/
   private void loadDefaultConfiguration()
   {
      // Restore preferences
      SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
      mDeviceNumberHRM = (short) settings.getInt("DeviceNumberHRM", WILDCARD);
      mDeviceNumberSDM = (short) settings.getInt("DeviceNumberSDM", WILDCARD);
      mDeviceNumberWGT = (short) settings.getInt("DeviceNumberWGT", WILDCARD);
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	  
      mDeviceNumberCAD = (short) settings.getInt("DeviceNumberCAD", WILDCARD);
      mProximityThreshold = (byte) settings.getInt("ProximityThreshold", DEFAULT_BIN);
   }

   
   /** Initialize GUI elements **/
   private void initControls()
   {
      // Fetch panels
      mHeartRate = (SensorPanel) findViewById(R.id.hrm_layout);
      mFootPod = (SensorPanel) findViewById(R.id.sdm_layout);
      mWeight = (SensorPanel) findViewById(R.id.weight_layout);
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	  
      mCadence = (SensorPanel) findViewById(R.id.cadence_layout);

      mDisabledText = (TextView)findViewById(R.id.text_status);
      
      // Associate menu buttons with panel
      mHeartRate.setMainButton((MenuButton) findViewById(R.id.button_heart), R.drawable.ant_hrm_gray, R.drawable.ant_hrm);
      mFootPod.setMainButton((MenuButton) findViewById(R.id.button_sdm), R.drawable.ant_spd_gray, R.drawable.ant_spd);
      mWeight.setMainButton((MenuButton) findViewById(R.id.button_weight), R.drawable.ant_wgt_gray, R.drawable.ant_wgt);
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	  
      mCadence.setMainButton((MenuButton) findViewById(R.id.button_cadence), R.drawable.ant_cad_gray, R.drawable.ant_cad);

      // Associate status field with panel
      mHeartRate.setStatus((TextDisplay) findViewById(R.id.text_status_hrm));
      mFootPod.setStatus((TextDisplay) findViewById(R.id.text_status_sdm));
      mWeight.setStatus((TextDisplay) findViewById(R.id.text_status_weight));
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	  
      mCadence.setStatus((TextDisplay) findViewById(R.id.text_status_cadence));

      // Associate data with panel
      mHeartRate.setDataCount(HeartData.values().length);
      mHeartRate.addData((TextDisplay) findViewById(R.id.text_bpm), HeartData.HEART_RATE.ordinal());
      mHeartRate.addData((TextDisplay) findViewById(R.id.text_spo2), HeartData.SPO2.ordinal());
     
      mFootPod.setDataCount(FootData.values().length);
      mFootPod.addData((TextDisplay) findViewById(R.id.text_speed), FootData.SPEED.ordinal());
      mFootPod.addData((TextDisplay) findViewById(R.id.text_distance), FootData.DISTANCE.ordinal());
      mFootPod.addData((TextDisplay) findViewById(R.id.text_strides), FootData.STRIDE_COUNT.ordinal());
      mFootPod.addData((TextDisplay) findViewById(R.id.text_cadence), FootData.CADENCE.ordinal());
      
      mWeight.setDataCount(WeightData.values().length);
      mWeight.addData((TextDisplay) findViewById(R.id.text_weight), WeightData.WEIGHT.ordinal());

      mCadence.setDataCount(CadenceData.values().length);
      mCadence.addData((TextDisplay) findViewById(R.id.text_cadence), CadenceData.WEIGHT.ordinal());
	  
      // Set listener for button presses 
      mHeartRate.getMainButton().setOnClickListener(this); 
      mFootPod.getMainButton().setOnClickListener(this);
      mWeight.getMainButton().setOnClickListener(this);
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	  
      mCadence.getMainButton().setOnClickListener(this);

      // Set listener to use the ANT+ logo if needed 
      ((ImageView) findViewById(R.id.antplus)).setOnClickListener(new OnClickListener()
      {
         public void onClick(View v)
         {
			 // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]
			 mServiceConnected = true;
			 // ANT nicolas.choi@lge.com 20101209 - ANT+ [END]
         
            if(mServiceConnected)
            {
               if(!sAntReceiver.isEnabled())
               {
                  Log.d(TAG, "Logo onClick: Enabling ANT radio");

                  // If enable failed in onConnected, let user try again
                  enableRadio();
                  updateDisplay();
               }
            }
            else
            {
               Log.w(TAG, "log onClick: ANT service not connected");
            }
         }
      });
   }

   private boolean enableRadio()
   {
       boolean result = false;
       if(mServiceConnected)
       {
           if(sAntReceiver.isEnabled())
           {
               result = true;
           }
           else
           {
               result = sAntReceiver.enable();
           }
       }
       else
       {
           Log.w(TAG, "enableRadio: Could not enable, ANT service not connected");
       }
	   
       if(!result)
       {
           showAlert(this, TAG, "Cannot enable ANT interface");
       }

       //return result;
       return true;
   }

   protected void updateDisplay()
   {
       setDisplay(mServiceConnected && sAntReceiver.isEnabled());
   }
   
   /** Set whether buttons etc are visible **/
   protected void setDisplay(boolean mVisible)
   {
	   int visibility = (mVisible ? MenuButton.VISIBLE : MenuButton.INVISIBLE);

       mHeartRate.getMainButton().setVisibility(visibility);
       mFootPod.getMainButton().setVisibility(visibility);
       mWeight.getMainButton().setVisibility(visibility);
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	   
       mCadence.getMainButton().setVisibility(visibility);	   

       mDisabledText.setVisibility(mVisible ? TextView.INVISIBLE : TextView.VISIBLE); // Visible when buttons aren't
       
       populateDisplay();
   }
   
    /** Show available sensor panels on the main interface **/
   private void populateDisplay()
   {
      mHeartRate.refreshUI();
      mFootPod.refreshUI();
      mWeight.refreshUI();
	  // ANT nicolas.choi@lge.com 20101209 - ANT+ [START]	  
      mCadence.refreshUI(); 	  
   }

   /* Display alert dialog */
   public void showAlert(Context context, String title, String msg) 
   {
      new AlertDialog.Builder(context).setTitle(title).setIcon(
            android.R.drawable.ic_dialog_alert).setMessage(msg)
            .setNegativeButton(android.R.string.cancel, null).show();
   }
   
   /** Listener for selections on the MenuButtons **/
   public void onClick(View v)
   {
	   Log.d(TAG, "onClick: START");
   
      // If no channels are open, reset ANT
      if((mHeartRate.getState() == SensorPanel.UIState.INIT | mHeartRate.getState() == SensorPanel.UIState.OFFLINE) &&
         (mFootPod.getState() == SensorPanel.UIState.INIT | mFootPod.getState() == SensorPanel.UIState.OFFLINE) &&
         (mWeight.getState() == SensorPanel.UIState.INIT | mWeight.getState() == SensorPanel.UIState.OFFLINE) &&
         (mCadence.getState() == SensorPanel.UIState.INIT | mCadence.getState() == SensorPanel.UIState.OFFLINE))
      {
         {
            Log.d(TAG, "onClick: Reset ANT");
            if(!sAntReceiver.ANTResetSystem())
            {
               Log.e(TAG, "onClick: Could not reset ANT");
            }
         }
      }

      switch(v.getId())
      {
         case R.id.button_heart:
            switch(mHeartRate.getState())
            {
               case INIT:
               case OFFLINE:
                  // Configure and open channel
                  Log.d(TAG, "onClick (HRM): Open channel");
                  mHeartRate.switchState(SensorPanel.UIState.SEARCH);
                  searchStart();
                  if(!antChannelSetup((byte) 0x01,        // Network:              1 (ANT+)
                                  HRM_CHANNEL,
                                  mDeviceNumberHRM,
                                  (byte) 0x78,        // Device Type:          120 (HRM)
                                  (byte) 0x00,        // Transmission Type:    wild card
                                  (short) 0x1F86,     // Channel period:       8070 (~4Hz)
                                  (byte) 0x39,        // RF Frequency:         57 (ANT+)
                                  mProximityThreshold))
                  {
                      Log.w(TAG, "onClick Open channel: Channel Setup failed");
                  }
                  break;
               case SEARCH:
               case TRACKING_DATA:
                  // Close channel
                  Log.d(TAG, "onClick (HRM): Close channel");
                  mHeartRate.switchState(SensorPanel.UIState.INIT);
                  sAntReceiver.ANTCloseChannel(HRM_CHANNEL);
                  sAntReceiver.ANTUnassignChannel(HRM_CHANNEL);
                  searchStop();
                  break;              
            }
            break;
         case R.id.button_sdm:
            switch(mFootPod.getState())
            {
               case INIT:
               case OFFLINE:
                  Log.d(TAG, "onClick (SDM): Open channel");
                  mFootPod.switchState(SensorPanel.UIState.SEARCH);
                  searchStart();

                  // Initialize cumulative values
                  mDistanceInit = false;
                  mStridesInit = false;
                  mAccumDistance = 0;
                  mAccumStrides = 0;
                  mPrevDistance = 0;
                  mPrevStrides = 0;

                  // Configure and open channel
                  if(!antChannelSetup((byte) 0x01,           // Network:              1 (ANT+)
                                  SDM_CHANNEL,
                                  mDeviceNumberSDM,
                                  (byte) 0x7C,           // Device Type:          124 (SDM)
                                  (byte) 0x00,           // Transmission Type:    wild card
                                  (short) 0x1FC6,        // Channel period:       8134 (~4Hz)
                                  (byte) 0x39,           // RF Frequency:         57 (ANT+)
                                  mProximityThreshold))
                  {
                      Log.w(TAG, "onClick Open channel: Channel Setup failed");
                  }
                  break;
               case SEARCH:
               case TRACKING_DATA:
                  // Close channel
                  Log.d(TAG, "onClick (SDM): Close channel");
                  mFootPod.switchState(SensorPanel.UIState.INIT);
                  sAntReceiver.ANTCloseChannel(SDM_CHANNEL);
                  sAntReceiver.ANTUnassignChannel(SDM_CHANNEL);
                  searchStop();
                  break;               
            }
            break;
         case R.id.button_weight:
            switch(mWeight.getState())
            {
               case INIT:
               case OFFLINE:
                  Log.d(TAG, "onClick (WGT): Open channel");
                  mWeight.switchState(SensorPanel.UIState.SEARCH);
                  searchStart();

                  // Reset session
                  mHasSentProfile = false;
                  mSessionDone = false;
                  
                  // Configure and open channel
                  if(!antChannelSetup((byte) 0x01,        // Network:              1 (ANT+)
                                  WEIGHT_CHANNEL,
                                  mDeviceNumberWGT,
                                  (byte) 0x77,        // Device Type:          119 (weight scale, use 0x7D/125 for Beurer's) 
                                  (byte) 0x00,        // Transmission Type:    wild card
                                  (short) 0x2000,     // Channel period:       8192 (4Hz)
                                  (byte) 0x39,        // RF Frequency:         57 (ANT+)
                                  mProximityThreshold))
                  {
                      Log.w(TAG, "onClick Open channel: Channel Setup failed");
                  }
                  break;
               case SEARCH:
               case TRACKING_DATA:
               case TRACKING_STATUS:
                  // Close channel
                  Log.d(TAG, "onClick (WGT): Close channel");
                  mWeight.switchState(SensorPanel.UIState.INIT);
                  sAntReceiver.ANTCloseChannel(WEIGHT_CHANNEL);
                  sAntReceiver.ANTUnassignChannel(WEIGHT_CHANNEL);
                  searchStop();
                  break;          
            }
            break;
         case R.id.button_cadence:
            switch(mCadence.getState())
            {
               case INIT:
               case OFFLINE:
                  Log.d(TAG, "onClick (CAD): Open channel");
                  mCadence.switchState(SensorPanel.UIState.SEARCH);
                  searchStart();

                  // Reset session
                  mHasSentProfile = false;
                  mSessionDone = false;
                  
                  // Configure and open channel
                  if(!antChannelSetup((byte) 0x01,        // Network:              1 (ANT+)
                                  CAD_CHANNEL,
                                  mDeviceNumberCAD,
                                  (byte) 0x77,        // Device Type:          119 (weight scale, use 0x7D/125 for Beurer's) 
                                  (byte) 0x00,        // Transmission Type:    wild card
                                  (short) 0x2000,     // Channel period:       8192 (4Hz)
                                  (byte) 0x39,        // RF Frequency:         57 (ANT+)
                                  mProximityThreshold))
                  {
                      Log.w(TAG, "onClick Open channel: Channel Setup failed");
                  }
                  break;
               case SEARCH:
               case TRACKING_DATA:
               case TRACKING_STATUS:
                  // Close channel
                  Log.d(TAG, "onClick (CAD): Close channel");
                  mCadence.switchState(SensorPanel.UIState.INIT);
                  sAntReceiver.ANTCloseChannel(CAD_CHANNEL);
                  sAntReceiver.ANTUnassignChannel(CAD_CHANNEL);
                  searchStop();
                  break;          
            }
            break;  			
      }
   }


   /** Receives all of the ANT intents and dispatches to the proper handler **/
   private final BroadcastReceiver mReceiver = new BroadcastReceiver() 
   {      
      Context mContext;

      public void onReceive(Context context, Intent intent) 
      {
         mContext = context;
         String ANTAction = intent.getAction();

         Log.d(TAG, "enter onReceive " + ANTAction);
         if (ANTAction.equals(AntInterfaceIntent.ANT_ENABLED_ACTION)) 
         {
            Log.i(TAG, "onReceive ANT_ENABLED_ACTION " + ANTAction);
            mHandler.sendMessage(mHandler.obtainMessage(EVENT_ANT_ENABLED, 0));
            
            updateDisplay();
         }
         if (ANTAction.equals(AntInterfaceIntent.ANT_DISABLED_ACTION)) 
         {
            Log.i(TAG, "onReceive ANT_DISABLED_ACTION " + ANTAction);
            mHandler.sendMessage(mHandler.obtainMessage(EVENT_ANT_DISABLED, 0));
            
            mHeartRate.switchState(SensorPanel.UIState.INIT);
            mFootPod.switchState(SensorPanel.UIState.INIT);
            mWeight.switchState(SensorPanel.UIState.INIT);
            
            updateDisplay();
         }         

         if (ANTAction.equals(AntInterfaceIntent.ANT_RX_MESSAGE_ACTION)) 
         {
            Log.d(TAG, "onReceive ANT_RX_MESSAGE_ACTION " + ANTAction);       

            byte[] ANTRxMessage = intent.getByteArrayExtra(AntInterfaceIntent.ANT_MESSAGE);
            String text = "Rx:";
         
            for(int i = 0;i < ANTRxMessage.length; i++)
               text += "[" + Integer.toHexString((int) ANTRxMessage[i] & 0xFF) + "]";
         
            Log.d(TAG, text);
            
            byte rxChannelNumber = (byte)(ANTRxMessage[AntMesg.MESG_DATA_OFFSET] & AntDefine.CHANNEL_NUMBER_MASK);
            switch(rxChannelNumber)   // Parse channel number
            {
               case HRM_CHANNEL:
                  antDecodeHRM(ANTRxMessage);
                  break;
               case SDM_CHANNEL:
                  antDecodeSDM(ANTRxMessage);
                  break;
               case WEIGHT_CHANNEL:
                  antDecodeWeight(ANTRxMessage); 
                  break;
			   case CAD_CHANNEL:
				  antDecodeWeight(ANTRxMessage); 
				  break;				  
              default:
                  Log.i(TAG, "Message for different channel ("+ rxChannelNumber +")");
                  break;
            }
         }
      }

      /** Decode ANT+ Weight messages **/
      private void antDecodeWeight(byte[] ANTRxMessage)
      {
         Log.d(TAG, "antDecodeWeight start");

         if(mAntProcessingEnabled && ANTRxMessage[AntMesg.MESG_ID_OFFSET] == AntMesg.MESG_BROADCAST_DATA_ID && mWeight.getState() != SensorPanel.UIState.INIT)   // message ID == broadcast
         {
            Log.d(TAG, "antDecodeWeight: Received broadcast");

            if(mDeviceNumberWGT == WILDCARD)
            {
               Log.i(TAG, "antDecodeWeight: Requesting device number");
               sAntReceiver.ANTRequestMessage(WEIGHT_CHANNEL, AntMesg.MESG_CHANNEL_ID_ID);
            }

            if(!mHasSentProfile)
            {
               byte[] Profile = {0x3A, 0x10, 0x00, 0x02, 
                                 (byte)0xFF, (byte)0x99, (byte)0xAD, 0x04};   // Sample user profile (male, 25)

               sAntReceiver.ANTSendBroadcastData(WEIGHT_CHANNEL, Profile);
               mHasSentProfile = true;
               Log.i(TAG, "Weight user profile sent");
            }
            else
            {               
               if(ANTRxMessage[3] == 0x01)   // check for data page 1
               {
                  int weight = ((int)ANTRxMessage[9]&0xFF  | ((int)(ANTRxMessage[10]&0xFF) << 8)) & 0xFFFF;
                  if(weight == (int) 0xFFFF)
                  {
                     mWeight.switchState(SensorPanel.UIState.TRACKING_STATUS);
                     mWeight.printStatus(mContext.getResources().getString(R.string.Invalid));
                  }
                  else if(weight == (int) 0xFFFE)
                  {
                     mWeight.switchState(SensorPanel.UIState.TRACKING_STATUS);
                     if(!mSessionDone)
                        mWeight.printStatus(mContext.getResources().getString(R.string.Computing));
                     else
                        mWeight.printStatus(mContext.getResources().getString(R.string.NewSession));
                  }
                  else
                  {
                     mWeight.switchState(SensorPanel.UIState.TRACKING_DATA);
                     DecimalFormat weightformat = new DecimalFormat("0.00");
                     mWeight.printValue(WeightData.WEIGHT, weightformat.format((float)weight/100.0) + " Kg");
                     mSessionDone = true;
                  }
               }
            }
         }         

         else if(ANTRxMessage[AntMesg.MESG_ID_OFFSET]==AntMesg.MESG_RESPONSE_EVENT_ID && ANTRxMessage[3]==AntMesg.MESG_EVENT_ID && ANTRxMessage[4]==AntDefine.EVENT_RX_SEARCH_TIMEOUT)   // Search timeout        	 
         {
            Log.i(TAG, "antDecodeWeight: Received search timeout");

            mWeight.switchState(SensorPanel.UIState.OFFLINE);
            sAntReceiver.ANTUnassignChannel((byte)2);
            searchStop();
         }    

         else if(ANTRxMessage[AntMesg.MESG_ID_OFFSET]==AntMesg.MESG_CHANNEL_ID_ID)   // Store requested Channel Id
         {
            Log.i(TAG, "antDecodeWeight: Received device number");
            mDeviceNumberWGT = (short) (((int)ANTRxMessage[3]&0xFF  | ((int)(ANTRxMessage[4]&0xFF) << 8)) & 0xFFFF);
            searchStop();
         }
         Log.d(TAG, "antDecodeWeight end");
      }

      /** Decode ANT+ SDM messages **/
      private void antDecodeSDM(byte[] ANTRxMessage)
      {
         Log.d(TAG, "antDecodeSDM start");
         if (mAntProcessingEnabled && ANTRxMessage[AntMesg.MESG_ID_OFFSET] == AntMesg.MESG_BROADCAST_DATA_ID)  //message ID == broadcast
         {
            Log.d(TAG, "antDecodeSDM: Received broadcast");

            if(mFootPod.getState() != SensorPanel.UIState.INIT)
            {
               Log.d(TAG, "antDecodeSDM: Tracking data");
               mFootPod.switchState(SensorPanel.UIState.TRACKING_DATA);
            }

            // If using a wild card search, request the channel ID
            if(mDeviceNumberSDM == WILDCARD)
            {
               Log.i(TAG, "antDecodeSDM: Requesting device number");
               sAntReceiver.ANTRequestMessage(SDM_CHANNEL, AntMesg.MESG_CHANNEL_ID_ID);
            }

            if ((ANTRxMessage[3]) == 0x01)  //check for data page 1
            {
               DecimalFormat speedformat = new DecimalFormat("0.00");
               float speed = ((float)((int)ANTRxMessage[7]&0x0F) + ((float)((int)ANTRxMessage[8]&0xFF))/256.0f );                                   
               float distance = ((float)((int)ANTRxMessage[6]&0xFF)) + ((float)((int)((ANTRxMessage[7] >>> 4)&0x0F)/16.0f));
               int strides = (int)ANTRxMessage[9]&0x00FF;

               if(!mDistanceInit)   // Calculate cumulative distance
               {
                  mPrevDistance = distance;
                  mDistanceInit = true;
               }
               if(!mStridesInit)    // Calculate cumulative stride count
               {
                  mPrevStrides = strides;
                  mStridesInit = true;
               }          

               mAccumDistance += (distance - mPrevDistance);

               if(mPrevDistance > distance)
                  mAccumDistance += 256.0;
               mPrevDistance = distance;

               mAccumStrides += (strides - mPrevStrides);

               if(mPrevStrides > strides)
                  mAccumStrides += 256;
               mPrevStrides = strides;

               mFootPod.printValue(FootData.SPEED, speedformat.format(speed) + " m/s");
               mFootPod.printValue(FootData.DISTANCE, speedformat.format(mAccumDistance) + " m");
               mFootPod.printValue(FootData.STRIDE_COUNT, mAccumStrides + " strides");
            }

            if(ANTRxMessage[3] == 0x02) // check for data page 2
            {
               DecimalFormat cadenceformat = new DecimalFormat("0.00");
               float cadence = ((float)((int)ANTRxMessage[6]&0xFF)) + ((float)((int)((ANTRxMessage[7] >>> 4)&0x0F)/16.0f));               
               float speed = ((float)((int)ANTRxMessage[7]&0x0F) + ((float)((int)ANTRxMessage[8]&0xFF))/256.0f );

               mFootPod.printValue(FootData.CADENCE, cadenceformat.format(cadence) + " str/min");
               mFootPod.printValue(FootData.SPEED, cadenceformat.format(speed) + " m/s");
            }
         }

         else if(ANTRxMessage[AntMesg.MESG_ID_OFFSET]==AntMesg.MESG_RESPONSE_EVENT_ID && ANTRxMessage[3]==AntMesg.MESG_EVENT_ID && ANTRxMessage[4]==AntDefine.EVENT_RX_SEARCH_TIMEOUT)   // Search timeout         
         {
            Log.i(TAG, "antDecodeSDM: Received search timeout");

            mFootPod.switchState(SensorPanel.UIState.OFFLINE);
            sAntReceiver.ANTUnassignChannel((byte) 1);
            searchStop();
         }

         else if(ANTRxMessage[AntMesg.MESG_ID_OFFSET]==AntMesg.MESG_CHANNEL_ID_ID)   // Store requested Channel Id
         {
            Log.i(TAG, "antDecodeSDM: Received device number");
            mDeviceNumberSDM = (short) (((int)ANTRxMessage[3]&0xFF  | ((int)(ANTRxMessage[4]&0xFF) << 8)) & 0xFFFF);
            searchStop();
         }
         Log.d(TAG, "antDecodeSDM end");
      }

      /** Decode HRM messages **/
      private void antDecodeHRM(byte[] ANTRxMessage)
      {
         Log.d(TAG, "antDecodeHRM start");

         if (mAntProcessingEnabled && ANTRxMessage[AntMesg.MESG_ID_OFFSET] == AntMesg.MESG_BROADCAST_DATA_ID)  //message ID == broadcast
         {
            Log.d(TAG, "antDecodeHRM: Received broadcast");
            if(mHeartRate.getState() != SensorPanel.UIState.INIT)
            {
               Log.d(TAG, "antDecodeHRMM: Tracking data");
               mHeartRate.switchState(SensorPanel.UIState.TRACKING_DATA);
            }
            if(mDeviceNumberHRM == WILDCARD)
            {
               Log.i(TAG, "antDecodeHRM: Requesting device number");
               sAntReceiver.ANTRequestMessage(HRM_CHANNEL, AntMesg.MESG_CHANNEL_ID_ID);            
            }

            // Monitor page toggle bit
            if(mStateHRM != HRMStatePage.EXT)
            {
               if(mStateHRM == HRMStatePage.INIT)
               {
                  if((ANTRxMessage[3] & (byte) 0x80) == 0)
                     mStateHRM = HRMStatePage.TOGGLE0;
                  else
                     mStateHRM = HRMStatePage.TOGGLE1;
               }
               else if(mStateHRM == HRMStatePage.TOGGLE0)
               {
                  if((ANTRxMessage[3] & (byte) 0x80) != 0)
                     mStateHRM = HRMStatePage.EXT;
               }
               else if(mStateHRM == HRMStatePage.TOGGLE1)
               {
                  if((ANTRxMessage[3] & (byte) 0x80) == 0)
                     mStateHRM = HRMStatePage.EXT;
               }
            }
            
            // Heart rate available in all pages and regardless of toggle bit            
            int bpm = (int) ANTRxMessage[10] & 0xFF;
            mHeartRate.printValue(HeartData.HEART_RATE, bpm + " BPM"); 
            
            if(mStateHRM == HRMStatePage.EXT)
            {
               byte pageNumber = (byte) (ANTRxMessage[3] & (byte) 0x7F);         
               
               if(pageNumber == 7) // Pulse oximeter
               {
                  int spo2 = (int) (ANTRxMessage[4] & 0x3F);  // Lower 6 bits
                  if((spo2 == 0) || (ANTRxMessage[4] & (byte) 0xC0) != 0)  // Disconnected or error status code
                  {
                     mHeartRate.printValue(HeartData.SPO2, "---");
                  }
                  else
                  {
                     spo2 += 37; // apply offset 
                     mHeartRate.printValue(HeartData.SPO2, "SPO2 " + spo2 + "%");
                  }
               }
            }

         }

         else if(ANTRxMessage[AntMesg.MESG_ID_OFFSET]==AntMesg.MESG_RESPONSE_EVENT_ID && ANTRxMessage[3]==AntMesg.MESG_EVENT_ID && ANTRxMessage[4]==AntDefine.EVENT_RX_SEARCH_TIMEOUT)   // Search timeout         
         {
            Log.i(TAG, "antDecodeHRM: Received search timeout");
            mHeartRate.switchState(SensorPanel.UIState.OFFLINE);
            sAntReceiver.ANTUnassignChannel((byte) 0);
            searchStop();
         }
         else if(ANTRxMessage[AntMesg.MESG_ID_OFFSET]==AntMesg.MESG_CHANNEL_ID_ID)   // Store requested Channel Id
         {
            Log.i(TAG, "antDecodeHRM: Received device number");
            mDeviceNumberHRM = (short) (((int)ANTRxMessage[3]&0xFF  | ((int)(ANTRxMessage[4]&0xFF) << 8)) & 0xFFFF);
            searchStop();
         }
         Log.d(TAG, "antDecodeHRM end");
      }
   };

   private void searchStart()
   {
       Log.i(TAG, "searchStart (was "+ mNumSearchingDevices +" searches)");
       mNumSearchingDevices++;
   }

   private void searchStop()
   {
       Log.i(TAG, "searchStop (was "+ mNumSearchingDevices +" searches)");
       mNumSearchingDevices--;

       if(mStopped)
       {
           // disable ANT messages while in background unless device search underway
           if(0 == mNumSearchingDevices)
           {
               Log.i(TAG, "searchStop: No more device searches, stopping receive");
               unregisterReceiver(mReceiver);
               mReceiverDisabled = true;
           }
           else
           {
               Log.d(TAG, "searchStop: Search still underway");
           }
       }
   }


   /** Handler for all the ANT related events. 

    ** The events will be handled only when we are in the ANT application main menu **/
   private Handler mHandler = new Handler() 
   {      
      public void handleMessage(Message msg) 
      {
         switch (msg.what) 
         {
            case EVENT_ANT_ENABLED:
               // After ANT is enabled dismiss the progress dialog and display the main screen
               Log.i(TAG, "enter handleMessage ----EVENT_ANT_ENABLED");
               
               break;
            case EVENT_ANT_DISABLED:
               Log.i(TAG, "enter handleMessage ----EVENT_ANT_DISABLED");
               
               break;
         }
      }
   };

   

   /** ANT Channel Configuration **/   
   private boolean antChannelSetup(byte networkNumber, byte channelNumber, short deviceNumber, byte deviceType, byte txType, short channelPeriod, byte radioFreq, byte proxSearch)
   {
      boolean chanStatus = true;

      if(!sAntReceiver.ANTAssignChannel(channelNumber, AntDefine.PARAMETER_RX_NOT_TX, networkNumber))  // Assign as slave channel on selected network (0 = public, 1 = ANT+, 2 = ANTFS)
         chanStatus = false;

      if(!sAntReceiver.ANTSetChannelId(channelNumber, deviceNumber, deviceType, txType))
         chanStatus = false; 

      if(!sAntReceiver.ANTSetChannelPeriod(channelNumber, channelPeriod))
         chanStatus = false;

      if(!sAntReceiver.ANTSetChannelRFFreq(channelNumber, radioFreq))
         chanStatus = false;

      if(!sAntReceiver.ANTSetChannelSearchTimeout(channelNumber, (byte)0)) // Disable high priority search
         chanStatus = false;

      if(!sAntReceiver.ANTSetLowPriorityChannelSearchTimeout(channelNumber,(byte) 12)) // Set search timeout to 30 seconds (low priority search)
         chanStatus = false;
      {
         if(deviceNumber == WILDCARD)
         {
            if(!sAntReceiver.ANTSetProximitySearch(channelNumber, proxSearch))   // Configure proximity search, if using wild card search
               chanStatus = false;
         }
      }

      if(!sAntReceiver.ANTOpenChannel(channelNumber))
         chanStatus = false;

      return chanStatus;
   }
   
   private void exitApplication()
   {
      Log.d(TAG, "exitApplication enter");
      AlertDialog.Builder builder = new AlertDialog.Builder(this);

      builder.setMessage(this.getResources().getString(R.string.Dialog_Exit_Check));
      builder.setCancelable(false);

      builder.setPositiveButton(this.getResources().getString(R.string.Dialog_Confirm), new DialogInterface.OnClickListener() {
                 public void onClick(DialogInterface dialog, int id) {

                     Log.i(TAG, "exitApplication: Exit");
                     finish();
                 }
             });

      builder.setNegativeButton(this.getResources().getString(R.string.Dialog_Cancel), new DialogInterface.OnClickListener() {
                 public void onClick(DialogInterface dialog, int id) {
                     Log.i(TAG, "exitApplication: Cancelled");
                     dialog.cancel();
                 }
             });

      AlertDialog exitDialog = builder.create();
      exitDialog.show();
   }
}

