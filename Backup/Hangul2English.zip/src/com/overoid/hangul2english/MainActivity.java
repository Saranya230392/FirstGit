/*
 * Copyright (C) 2010 jinook.lee All Rights Reserved.
 * 
 * http://overoid.tistory.com
 *
 */

package com.overoid.hangul2english;



import java.util.ArrayList;
import java.util.List;



import com.overoid.hangul2english.data.DataDao;
import com.overoid.hangul2english.data.DataDao.DataTo;
import com.overoid.hangul2english.util.Hangul;


import android.app.AlertDialog;
import android.app.ListActivity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ListActivity {
    public static String CLASSNAME = MainActivity.class.getSimpleName();
    private static final int NOTIFY_ID = 3333;
    
    private DataDao dao;
    private DataListAdapter mListAdapter;
    private ArrayList<DataTo> mDatas;
    
    //UI관련 변수
    private EditText mKorText;
    private EditText mEngText;
    private Button mSaveButton;
    private ImageButton mRemoveButton;
    private ImageButton mCopyButton;
    private ImageView mInfoButton;
    private ListView mListView;
    private TextView mEmpty;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Dao Instance
        dao = new DataDao(getApplicationContext());
        
        // UI Init
        mKorText = (EditText)findViewById(R.id.text_password);
        mEngText = (EditText)findViewById(R.id.text_english);
        mSaveButton = (Button)findViewById(R.id.button_save);
        mRemoveButton= (ImageButton)findViewById(R.id.button_remove);
        mCopyButton = (ImageButton)findViewById(R.id.button_copy);
        mInfoButton = (ImageView)findViewById(R.id.button_info);
        
        //ListActivity를 사용하면 Resource에 ListView id를 "@+id/android:list" 로 사용해야 함.
        mListView = getListView();  
        mListView.setItemsCanFocus(true);
        mListView.setEmptyView(mEmpty);
        mListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        mEmpty = (TextView)findViewById(R.id.list_empty);
        
        //Evetn Handler
        
        // Info Button Click
        mInfoButton.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                infoAlertDialogShow(MainActivity.this);
            }

        });
        
        // Hangul Text Change
        mKorText.addTextChangedListener(new TextWatcher() {
            
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count)  {
                Log.v("**", "TextChanged");
                if(!TextUtils.isEmpty(mKorText.getText())) {
                    mEngText.setText(Hangul.convertToEnglishforSingleChar(Hangul.convertToEnglish(mKorText.getText().toString())));
                } else {
                    mEngText.setText("");
                }
                
            }
            
            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                // TODO Auto-generated method stub
                
            }
            
            @Override
            public void afterTextChanged(Editable arg0) {
                // TODO Auto-generated method stub
                
            }
        });
        
        // Remove Button Click
        mRemoveButton.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View arg0) {
                mKorText.setText("");
                mEngText.setText("");
            }
        });
        
        // Copy Button Click
        mCopyButton.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                if(mEngText.getText().length() > 0) {
                    copyClipboard(mEngText.getText().toString());
                }
            }
        });
        
        // Save Button Click
        mSaveButton.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                if(mKorText.getText().length() > 0 && mEngText.getText().length() > 0) {
                    
                    DataTo to = new DataTo(0, mKorText.getText().toString(), mEngText.getText().toString());
                    Log.i(Constants.LOG_TAG,MainActivity.CLASSNAME + "insert:" + to.toString());
                    dao.insert(to);
                    Toast.makeText(MainActivity.this, R.string.msg_insert_success, Toast.LENGTH_SHORT).show();
    
                    //새로 바인딩해야 함.    
                    populateList();
                } else {
                    Toast.makeText(MainActivity.this, R.string.msg_insert_no_data, Toast.LENGTH_SHORT).show();
                }

            }
        });
        
        //로딩시 데이터를 가져와 리스트에 뿌린다.
        populateList();
        
        //Notify
        notifyMessage();
    }
    
    @Override
    protected void onPause() {
        Log.i(Constants.LOG_TAG,MainActivity.CLASSNAME + "- onPause()");
        super.onPause();
    }

    @Override
    protected void onResume() {
        Log.i(Constants.LOG_TAG,MainActivity.CLASSNAME + "- onResume()");
        super.onResume();

    }
    
    
    
    @Override
    protected void onDestroy() {
        dao.close();
        super.onDestroy();
    }
    
    /****
     * Clipboad에 선택한 텍스트 복사.
     */
    private void copyClipboard(String s) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);  
        clipboard.setText(s);
        Toast.makeText(MainActivity.this, R.string.msg_clipboard_copy_success, Toast.LENGTH_SHORT).show();
    }
    
    /****
     * 정보창을 띄운다.
     * @param context
     */
    private void infoAlertDialogShow(Context context) {
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View infoView = inflater.inflate(R.layout.info, null);

        String alertTitle = getResources().getString(R.string.app_name);
        String buttonMessage = getResources().getString(R.string.msg_info_close_button);
        
        new AlertDialog.Builder(context)
        .setTitle(alertTitle)
        .setView(infoView)
        .setNeutralButton(buttonMessage, new DialogInterface.OnClickListener() {
            
            public void onClick(DialogInterface dlg, int sumthin) {
                //기본적으로 창이 닫히며, 추가작업은 없다.
            }
        }).show();
    }
    
    /****
     * populateList     : table data를 새로 가져와 화면에 뿌린다.
     */
    private void populateList() {
        
        Log.v(Constants.LOG_TAG, MainActivity.CLASSNAME + "- populateList");
        
        mDatas = (ArrayList<DataTo>)dao.get();
        
        if(mDatas == null) {
            mEmpty.setText("");
            setListAdapter(null);
        } else {
            mListAdapter = new DataListAdapter(MainActivity.this,R.layout.list_item, mDatas);
            setListAdapter(mListAdapter);
            Log.v(Constants.LOG_TAG, MainActivity.CLASSNAME + "- populateList, mListView Binding End");
            
        }
    }
    
    /**
     * App 실행시시 알림영역에 아이콘 및 실행정보를 표시
     * 알림영역 선택시 어플 실행.
     * 알림영역 삭제는 어플 종료 이전에는 불가능 하도록 처리해야 함.
     */
    private void notifyMessage() {
        String notiTitle = this.getString(R.string.app_name);
        String notiContent = this.getString(R.string.msg_notify_content);
        final NotificationManager notiMgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification noti = new Notification(R.drawable.ic_notify, notiTitle , System.currentTimeMillis());
        noti.flags |= Notification.FLAG_NO_CLEAR;
        
        PendingIntent i = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),0);
        
        noti.setLatestEventInfo(this, notiTitle, notiContent, i);
        
        notiMgr.notify(NOTIFY_ID, noti);
    }
    
    class DataListAdapter extends ArrayAdapter<DataTo> {
        private static final String CLASS = "DataListAdapter";
        private Context mContext;
        private List<DataTo> mDataList;
        
        public DataListAdapter(Context context, int textViewResourceId, List<DataTo> items) {
            super(context, textViewResourceId, items);
            mContext = context;
            mDataList = items;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView;
            
            if(row == null) {
                LayoutInflater inflator = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                row = inflator.inflate(R.layout.list_item, null);
            }
            
            final DataTo to = mDataList.get(position);
            Log.i(Constants.LOG_TAG, CLASS + " getView:pos" + position + "data:" + to.toString());
            Log.i(Constants.LOG_TAG, CLASS + " korText:" + to.getKorText().toString() + ",engText:" + to.getEngText().toString());
            
            if(to != null) {
                TextView korText = (TextView)row.findViewById(R.id.korText);
                korText.setText(to.getKorText());
                
                TextView engText = (TextView)row.findViewById(R.id.engText);
                engText.setText(to.getEngText());
                
                ImageView copyClipboadButton = (ImageView)row.findViewById(R.id.copyClipboard);
                copyClipboadButton.setOnClickListener(new OnClickListener() {
                    
                    @Override
                    public void onClick(View v) {
                        copyClipboard(to.getEngText().toString());
                    }
                });
                
                ImageView deleteButton = (ImageView)row.findViewById(R.id.deleteImage);
                deleteButton.setOnClickListener(new OnClickListener() {
                    
                    @Override
                    public void onClick(View v) {
                        
                        Log.i(Constants.LOG_TAG, CLASS + " delete:" + to.toString());
                        dao.delete(to.getId());
                        Toast.makeText(mContext, R.string.msg_delete_success, Toast.LENGTH_SHORT).show();
                        
                        //새로 바인딩해야 함.    
                        populateList();
                        
                    }
                });
            }
            return (row);
        }

    }
}