/*
 * Copyright (C) 2010 jinook.lee All Rights Reserved.
 * 
 * http://overoid.tistory.com
 *  
 */

package com.overoid.hangul2english.data;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


import com.overoid.hangul2english.Constants;
import com.overoid.hangul2english.data.H2eDatabase.DataTable;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.util.Log;



public class DataDao {
    private static final String CLASSNAME = DataDao.class.getSimpleName();
    private DatabaseHelper db;
    
    public DataDao(Context context) {
        db = DatabaseHelper.getInstance(context);
        
    }
    
    public void close() {
        db.close();
    }
    /***
     * Inner Class - TO Objects
     * @author jinook.lee
     *
     */
    public static class DataTo {
        private int id;
        private String korText;
        private String engText;
        
        public DataTo() {}

        public DataTo(int id, String korText, String engText) {
            this.id = id;
            this.korText = korText;
            this.engText = engText;
        }

        @Override
        public String toString() {
            return "DataTo [id=" + String.valueOf(id) + ", korText=" + korText + ", engText=" + engText + "]";
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getKorText() {
            return korText;
        }

        public void setKorText(String korText) {
            this.korText = korText;
        }

        public String getEngText() {
            return engText;
        }

        public void setEngText(String engText) {
            this.engText = engText;
        }
    }

    /****
     * insert       : table에 추가하기
     * @param to    : DataTo object
     */
    public void insert(final DataTo to) {
        ContentValues values = new ContentValues();

        values.put(DataTable.COLUMN_KOR_TEXT, to.getKorText());
        values.put(DataTable.COLUMN_ENG_TEXT, to.getEngText());

        Log.v(Constants.LOG_TAG, DataDao.CLASSNAME + " insert - korText:" + to.getKorText());
        long rowId = db.insert(DataTable.TABLE_NAME, values);
        if(rowId < 0) {
            throw new SQLException("Fail At Insert");
        }
    }
   
    /****
     * update       : UI상 사용될 일은 없을듯.
     * @param to    : DataTo object
     */
    public void update(final DataTo to) {
       ContentValues values = new ContentValues();

       values.put(DataTable.COLUMN_KOR_TEXT, to.getKorText());
       values.put(DataTable.COLUMN_ENG_TEXT, to.getEngText());
       
       Log.v(Constants.LOG_TAG, DataDao.CLASSNAME + " update - _id:" + String.valueOf(to.getId()));
       db.update(DataTable.TABLE_NAME, values, to.getId());
       
   }
    
    /****
     * delete       : record delete
     * @param id    : record id
     */
    public void delete(final int id) {
        Log.v(Constants.LOG_TAG, DataDao.CLASSNAME + " delete - _id:" + String.valueOf(id));
        db.delete(DataTable.TABLE_NAME, id);
    }
    
    /****
     * get          : select * from table
     * Cursor를 ArrayList에 담아서 리턴한다.
     * 
     * @return      : ArrayList DataTo
     */
    public List<DataTo> get() {
        Cursor c = null;
        ArrayList<DataTo> ret = null;
        
        String sql = "SELECT * FROM " + DataTable.TABLE_NAME + " ORDER BY 1";
        
        try {
            Log.v(Constants.LOG_TAG, DataDao.CLASSNAME + " get - All");
            c = db.get(sql);
            
            //db.logCursorInfo(c);
            
            ret = setBindCursor(c);
        } catch (SQLException e) {
            Log.e(Constants.LOG_TAG, DataDao.CLASSNAME + " getList ", e);
        } finally {
            if (c != null && !c.isClosed()) {
                c.close();
            }
        }
        
        return ret;
    }
    
    
    /****
     * SQLite Result Cursor 데이터를 Array List에 넣고 리턴하는 메서드. 
     * @param c     : cursor
     * @return      : ArrayList<DataTo>
     */
    private ArrayList<DataTo> setBindCursor(final Cursor c) {
        ArrayList<DataTo> ret = new ArrayList<DataTo>();
        
        int numRows = c.getCount();
        
        c.moveToFirst();
        
        // SQL문에서 Join 사용시 테이블명. 을 사용하면 컬럼명이 틀려지므로 getColumnIndex가
        // Exception을 낸다. 반드시 alias를 사용해 컬럼명을 동일하게 맞춰야 한다.
        // 값이 null인 경우 getInt()는 0을 반환할까? - 반환함.
        
        for(int i=0; i < numRows; i++) {
            DataTo to = new DataTo();
            to.setId(c.getInt(c.getColumnIndex(DataTable.COLUMN_ID)));
            to.setKorText(c.getString(c.getColumnIndex(DataTable.COLUMN_KOR_TEXT)));
            to.setEngText(c.getString(c.getColumnIndex(DataTable.COLUMN_ENG_TEXT)));

            ret.add(to);
            c.moveToNext();
        }
        
        return ret;
    }
    
    /****
     * List<DataTo>의 내용을 로깅하는 메소드
     * @param to
     */
    public void logListInfo(List<DataTo> to) {
        Log.i(Constants.LOG_TAG,"*** List Begin *** " + "Results:" + to.size());
        
        Iterator<DataTo> itr = to.iterator(); 
        while (itr.hasNext()) {
            String msg = ((DataTo)itr.next()).toString();
            Log.i(Constants.LOG_TAG, "DATAS: " + msg);
        }
        Log.i(Constants.LOG_TAG,"*** List End ***");
    }
}
