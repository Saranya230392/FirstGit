/*
 * Copyright (C) 2010 jinook.lee All Rights Reserved.
 * 
 * http://overoid.tistory.com
 *  
 */
package com.overoid.hangul2english.data;

import com.overoid.hangul2english.data.H2eDatabase.DataTable;

public class H2eDatabaseCreator implements DatabaseCreator {

    
    /* Table Creation DDL */
    private final String TABLE_CREATE_DATATABLE = "CREATE TABLE "
        + DataTable.TABLE_NAME + " ( "
        + DataTable.COLUMN_ID + " INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, "
        + DataTable.COLUMN_KOR_TEXT + " INTEGER, "
        + DataTable.COLUMN_ENG_TEXT + " TEXT); ";
        
    
    /* Index Create DDL */
    private final String INDEX_CREATE_DATATABLE = "CREATE UNIQUE INDEX "
        + DataTable.TABLE_NAME + "_pk ON " 
        + DataTable.TABLE_NAME + " (" +  DataTable.COLUMN_ID + " );";
    
    @Override
    public String[] getCreateTablesStmt() {
        String[] tableStmt = {TABLE_CREATE_DATATABLE};
        return tableStmt;
    }

    @Override
    public String[] getCreateIndexStmt() {
        String[] indexStmt = {INDEX_CREATE_DATATABLE};
        return indexStmt;
    }

    @Override
    public String[] getCreateViewStmt() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String[] getCreateTriggerStmt() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public String[] getInitDataInsertStmt() {
        String[] initData = new String[2];
        String[][] initValue = {{"사랑","tkfkd"},
                                {"깍쟁이","Rkrwoddl"}};

        for(int i=0; i<2; i++) {
            initData[i] = "INSERT INTO " + DataTable.TABLE_NAME + "(" 
                         + DataTable.COLUMN_KOR_TEXT + ","
                         + DataTable.COLUMN_ENG_TEXT + " ) "
                         + " VALUES( "
                         + "'" + initValue[i][0] + "','" + initValue[i][1] + "');";
        }
        return initData;
    }

}
