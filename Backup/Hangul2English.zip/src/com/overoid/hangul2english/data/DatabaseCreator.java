/*
 * Copyright (C) 2010 jinook.lee All Rights Reserved.
 * 
 * http://overoid.tistory.com
 * SQLite DDL문을 리턴하는 interface를 정의. 
 */

package com.overoid.hangul2english.data;

public interface DatabaseCreator {
    
    public static final String DB_NAME = "han_to_eng_db";
    public static final int DB_VERSION = 1;
    
    /* Table Definition Statement */
    public String[] getCreateTablesStmt();
    
    /* Index Definition Statement */
    public String[] getCreateIndexStmt();
    
    /* View Definition Statement */
    public String[] getCreateViewStmt();
    
    /* Trigger Definition Statement */
    public String[] getCreateTriggerStmt();
    
    /* Initial Data Insert Statement */
    public String[] getInitDataInsertStmt();
}
