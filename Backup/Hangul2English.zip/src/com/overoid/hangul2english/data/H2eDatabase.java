/*
 * Copyright (C) 2010 jinook.lee All Rights Reserved.
 * 
 * http://overoid.tistory.com
 *  
 */
package com.overoid.hangul2english.data;

public final class H2eDatabase {
    
    H2eDatabase() {}
    
    /* Table이나 View마다 중첩 클래스를 만듭니다.
     * 테이블명, 컬럼명 정보를 상수로 정의합니다.
     */
    public static final class DataTable {
        private DataTable() {}
        
        public static final String TABLE_NAME = "TB_DATA";
        
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_KOR_TEXT = "c_kor_text";
        public static final String COLUMN_ENG_TEXT = "c_eng_text";
        
        public String[] getColumnNames() {
            String[] columnNames = {COLUMN_ID,COLUMN_KOR_TEXT,COLUMN_ENG_TEXT}; 
            return columnNames;
        }
    }
}
