/*
 * Copyright (C) 2010 jinook.lee All Rights Reserved.
 * 
 * http://overoid.tistory.com
 *
 */

package com.overoid.hangul2english;

public class Constants {
 // Log Class에 인자로 넘겨줄 Tag 정의 
    public static final String LOG_TAG = "Hangul2English";
}
