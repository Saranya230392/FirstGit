#ifndef __MBT_OBEX_H_
#define __MBT_OBEX_H_

#include "..\..\..\Include\MBTObex.h"

typedef MBT_VOID (*T_pfnMBT_OBEX_ServerEnable) (T_MBT_OBEX_SERVICE_INFO* SvcInfo, MBT_BYTE* target, MBT_BOOL Authc, T_MBT_OBEX_CHARSET realm_charset, MBT_CHAR* realm, MBT_BYTE realm_len);
typedef MBT_VOID (*T_pfnMBT_OBEX_ServerDisable) (MBT_UINT ServerHandle);
typedef MBT_VOID (*T_pfnMBT_OBEX_ServerConnectRes) (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE connect_res);
typedef MBT_VOID (*T_pfnMBT_OBEX_ServerDisconnectRes) (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE disconnect_res);
typedef MBT_VOID (*T_pfnMBT_OBEX_ServerAuthenticateRes) (MBT_UINT ServerHandle, MBT_CHAR* PassWD, MBT_BYTE PassLen, MBT_CHAR* UserID, MBT_BYTE IDLen);
typedef MBT_VOID (*T_pfnMBT_OBEX_ServerSetPathRes) (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE setpath_res);
typedef MBT_VOID (*T_pfnMBT_OBEX_ServerPutRes) (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE put_res);
typedef MBT_VOID (*T_pfnMBT_OBEX_ServerGetRes) (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE get_res);
typedef MBT_VOID (*T_pfnMBT_OBEX_ServerAbortRes) (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE abort_res);

typedef struct
{
	T_pfnMBT_OBEX_ServerEnable			pfnServerEnable;
	T_pfnMBT_OBEX_ServerDisable			pfnServerDisable;
	T_pfnMBT_OBEX_ServerConnectRes		pfnServerConnectRes;
	T_pfnMBT_OBEX_ServerDisconnectRes	pfnServerDisconnectRes;
	T_pfnMBT_OBEX_ServerAuthenticateRes	pfnServerAuthenticateRes;
	T_pfnMBT_OBEX_ServerSetPathRes		pfnServerSetPathRes;
	T_pfnMBT_OBEX_ServerPutRes			pfnServerPutRes;
	T_pfnMBT_OBEX_ServerGetRes			pfnServerGetRes;
	T_pfnMBT_OBEX_ServerAbortRes			pfnServerAbortRes;
}TApiGrp_MBT_OBEX;

#ifndef BNS_MAIN_VERSION
#define	MBT_OBEX_ServerEnable(p1,p2,p3,p4,p5,p6)		__ApiLink6(MBT_OBEX,ServerEnable,p1,p2,p3,p4,p5,p6)
#define	MBT_OBEX_ServerDisable(p1)						__ApiLink1(MBT_OBEX,ServerDisable,p1)
#define	MBT_OBEX_ServerConnectRes(p1,p2)				__ApiLink2(MBT_OBEX,ServerConnectRes,p1,p2)
#define	MBT_OBEX_ServerDisconnectRes(p1,p2)			__ApiLink2(MBT_OBEX,ServerDisconnectRes,p1,p2)
#define	MBT_OBEX_ServerAuthenticateRes(p1,p2,p3,p4,p5)	__ApiLink5(MBT_OBEX,ServerAuthenticateRes,p1,p2,p3,p4,p5)
#define	MBT_OBEX_ServerSetPathRes(p1,p2)				__ApiLink2(MBT_OBEX,ServerSetPathRes,p1,p2)
#define	MBT_OBEX_ServerPutRes(p1,p2)					__ApiLink2(MBT_OBEX,ServerPutRes,p1,p2)
#define	MBT_OBEX_ServerGetRes(p1,p2)					__ApiLink2(MBT_OBEX,ServerGetRes,p1,p2)
#define	MBT_OBEX_ServerAbortRes(p1,p2)				__ApiLink2(MBT_OBEX,ServerAbortRes,p1,p2)
#endif

#endif //__MBT_OBEX_H_
