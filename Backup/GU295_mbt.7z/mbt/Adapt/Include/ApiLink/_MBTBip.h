#ifndef __MBT_BIP_H_
#define __MBT_BIP_H_
/********************************************************************************
*	File Name	: _MBtBip.h
*	Description	: _MBtBip.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.12.12	Su-Hui, Kim		Created
********************************************************************************/

#include "..\..\..\Include\MBTBip.h"


typedef MBT_VOID (*T_pfnMBT_BIP_InitiatorEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_BIP_InitiatorDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_BIP_InitiatorAuthRsp) (T_MBT_OBEX_AUTH *auth_reply);
typedef MBT_VOID (*T_pfnMBT_BIP_InitiatorGetCapabilityReq) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_BIP_InitiatorPushImage) (T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBTObject);
typedef MBT_VOID (*T_pfnMBT_BIP_InitiatorPushThumbnail) (T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBTObject);
typedef MBT_VOID (*T_pfnMBT_BIP_InitiatorDisconnect) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_BIP_ResponderEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_BIP_ResponderDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_BIP_ResponderAuthRsp) (T_MBT_OBEX_AUTH *auth_reply);
typedef MBT_VOID (*T_pfnMBT_BIP_ResponderAccessRsp) (T_MBT_AUTHRES Reply);
typedef MBT_VOID (*T_pfnMBT_BIP_ResponderGetCapabilityResp) (T_MBT_AUTHRES Reply, T_MBT_BIP_IMAGING_CAPABILITY *ImagingCapability);
typedef MBT_VOID (*T_pfnMBT_BIP_ResponderDisconnect) (MBT_VOID);

typedef struct
{
	T_pfnMBT_BIP_InitiatorEnable				pfnInitiatorEnable;
	T_pfnMBT_BIP_InitiatorDisable				pfnInitiatorDisable;
	T_pfnMBT_BIP_InitiatorAuthRsp				pfnInitiatorAuthRsp;
	T_pfnMBT_BIP_InitiatorGetCapabilityReq		pfnInitiatorGetCapabilityReq;
	T_pfnMBT_BIP_InitiatorPushImage			pfnInitiatorPushImage;
	T_pfnMBT_BIP_InitiatorPushThumbnail			pfnInitiatorPushThumbnail;
	T_pfnMBT_BIP_InitiatorDisconnect			pfnInitiatorDisconnect;	
	T_pfnMBT_BIP_ResponderEnable				pfnResponderEnable;
	T_pfnMBT_BIP_ResponderDisable				pfnResponderDisable;
	T_pfnMBT_BIP_ResponderAuthRsp			pfnResponderAuthRsp;
	T_pfnMBT_BIP_ResponderAccessRsp			pfnResponderAccessRsp;
	T_pfnMBT_BIP_ResponderGetCapabilityResp	pfnResponderGetCapabilityResp;
	T_pfnMBT_BIP_ResponderDisconnect			pfnResponderDisconnect;
}TApiGrp_MBT_BIP;


#ifndef BNS_MAIN_VERSION
#define   MBT_BIP_InitiatorEnable()					__ApiLink0(MBT_BIP,InitiatorEnable)
#define   MBT_BIP_InitiatorDisable()					__ApiLink0(MBT_BIP,InitiatorDisable)
#define   MBT_BIP_InitiatorAuthRsp(p1)				__ApiLink1(MBT_BIP,InitiatorAuthRsp,p1)
#define   MBT_BIP_InitiatorGetCapabilityReq(p1)		__ApiLink1(MBT_BIP,InitiatorGetCapabilityReq,p1)
#define   MBT_BIP_InitiatorPushImage(p1,p2)			__ApiLink2(MBT_BIP,InitiatorPushImage,p1,p2)
#define   MBT_BIP_InitiatorPushThumbnail(p1,p2)		__ApiLink2(MBT_BIP,InitiatorPushThumbnail,p1,p2)
#define   MBT_BIP_InitiatorDisconnect()				__ApiLink0(MBT_BIP,InitiatorDisconnect)
#define   MBT_BIP_ResponderEnable()					__ApiLink0(MBT_BIP,ResponderEnable)
#define   MBT_BIP_ResponderDisable()					__ApiLink0(MBT_BIP,ResponderDisable)
#define   MBT_BIP_ResponderAuthRsp(p1)				__ApiLink1(MBT_BIP,ResponderAuthRsp,p1)
#define   MBT_BIP_ResponderAccessRsp(p1)			__ApiLink1(MBT_BIP,ResponderAccessRsp,p1)
#define   MBT_BIP_ResponderGetCapabilityResp(p1,p2)	__ApiLink2(MBT_BIP,ResponderGetCapabilityResp,p1,p2)
#define   MBT_BIP_ResponderDisconnect()				__ApiLink0(MBT_BIP,ResponderDisconnect)
#endif

#endif //__MBT_BIP_H_
