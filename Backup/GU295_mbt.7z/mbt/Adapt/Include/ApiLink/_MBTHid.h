#ifndef __MBT_HID_H_
#define __MBT_HID_H_

#include "..\..\..\Include\MBTHid.h"

typedef MBT_VOID (*T_pfnMBT_HID_HostEnable) (FP_MBT_HID_RX_REPORT_CO fpRxRpt);
typedef MBT_VOID (*T_pfnMBT_HID_HostDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_HID_HostConnect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_HID_HostDisconnect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_HID_HostAddDevice) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_HID_HostRemoveDevice) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_HID_HostGetDescInfo) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_HID_HostSetLED) (T_MBT_BDADDR BdAddr, T_MBT_HID_LED_MASK led);
typedef MBT_VOID (*T_pfnMBT_HID_HostSendLED) (T_MBT_BDADDR BdAddr, T_MBT_HID_LED_MASK led);
typedef MBT_VOID (*T_pfnMBT_HID_HostSendControl) (T_MBT_BDADDR BdAddr, T_MBT_HID_CONTROL control);
typedef MBT_VOID (*T_pfnMBT_HID_HostSendReport) (T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
typedef MBT_VOID (*T_pfnMBT_HID_HostSetReport) (T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
typedef MBT_VOID (*T_pfnMBT_HID_HostGetReport) (T_MBT_BDADDR BdAddr, MBT_BYTE rpt_type, MBT_BYTE rpt_id);
typedef MBT_VOID (*T_pfnMBT_HID_HostGetIdle) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_HID_HostSetIdle) (T_MBT_BDADDR BdAddr, MBT_BYTE idle);
typedef MBT_VOID (*T_pfnMBT_HID_HostGetProtocol) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_HID_HostSetProtocol) (T_MBT_BDADDR BdAddr, MBT_BOOL boot_mode);

typedef MBT_VOID (*T_pfnMBT_HID_DeviceEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceConnect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceDisconnect) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceSendUnplug) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceSendReport) (T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceSendKeyboardRpt) (T_MBT_HID_MODIFIER_MASK modifier, T_MBT_HID_KEY_TYPE *keycodes, MBT_BYTE key_num);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceSendMouseRpt) (T_MBT_HID_MOUSE_BUTTON_MASK button, MBT_BYTE move_x, MBT_BYTE move_y);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceChangeKeyboardRole) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceChangeMouseRole) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_HID_DeviceChangePhoneRole) (MBT_VOID);


typedef struct
{
	T_pfnMBT_HID_HostEnable		pfnHostEnable;
	T_pfnMBT_HID_HostDisable		pfnHostDisable;
	T_pfnMBT_HID_HostConnect		pfnHostConnect;
	T_pfnMBT_HID_HostDisconnect		pfnHostDisconnect;
	T_pfnMBT_HID_HostAddDevice		pfnHostAddDevice;
	T_pfnMBT_HID_HostRemoveDevice		pfnHostRemoveDevice;
	T_pfnMBT_HID_HostGetDescInfo		pfnHostGetDescInfo;
	T_pfnMBT_HID_HostSetLED		pfnHostSetLED;
	T_pfnMBT_HID_HostSendLED		pfnHostSendLED;
	T_pfnMBT_HID_HostSendControl		pfnHostSendControl;
	T_pfnMBT_HID_HostSendReport		pfnHostSendReport;
	T_pfnMBT_HID_HostSetReport		pfnHostSetReport;
	T_pfnMBT_HID_HostGetReport		pfnHostGetReport;
	T_pfnMBT_HID_HostGetIdle		pfnHostGetIdle;
	T_pfnMBT_HID_HostSetIdle		pfnHostSetIdle;
	T_pfnMBT_HID_HostGetProtocol		pfnHostGetProtocol;
	T_pfnMBT_HID_HostSetProtocol		pfnHostSetProtocol;

	T_pfnMBT_HID_DeviceEnable		pfnDeviceEnable;
	T_pfnMBT_HID_DeviceDisable		pfnDeviceDisable;
	T_pfnMBT_HID_DeviceConnect		pfnDeviceConnect;
	T_pfnMBT_HID_DeviceDisconnect		pfnDeviceDisconnect;
	T_pfnMBT_HID_DeviceSendUnplug		pfnDeviceSendUnplug;
	T_pfnMBT_HID_DeviceSendReport		pfnDeviceSendReport;
	T_pfnMBT_HID_DeviceSendKeyboardRpt		pfnDeviceSendKeyboardRpt;
	T_pfnMBT_HID_DeviceSendMouseRpt		pfnDeviceSendMouseRpt;
	T_pfnMBT_HID_DeviceChangeKeyboardRole		pfnDeviceChangeKeyboardRole;
	T_pfnMBT_HID_DeviceChangeMouseRole		pfnDeviceChangeMouseRole;
	T_pfnMBT_HID_DeviceChangePhoneRole		pfnDeviceChangePhoneRole;

}TApiGrp_MBT_HID;

#ifndef BNS_MAIN_VERSION
#define MBT_HID_HostEnable(p1)		__ApiLink1(MBT_HID,HostEnable,p1)
#define MBT_HID_HostDisable()		__ApiLink0(MBT_HID,HostDisable)
#define MBT_HID_HostConnect(p1)		__ApiLink1(MBT_HID,HostConnect,p1)
#define MBT_HID_HostDisconnect(p1)		__ApiLink1(MBT_HID,HostDisconnect,p1)
#define MBT_HID_HostAddDevice(p1)		__ApiLink1(MBT_HID,HostAddDevice,p1)
#define MBT_HID_HostRemoveDevice(p1)		__ApiLink1(MBT_HID,HostRemoveDevice,p1)
#define MBT_HID_HostGetDescInfo(p1)		__ApiLink1(MBT_HID,HostGetDescInfo,p1)
#define MBT_HID_HostSetLED(p1,p2)		__ApiLink2(MBT_HID,HostSetLED,p1,p2)
#define MBT_HID_HostSendLED(p1,p2)		__ApiLink2(MBT_HID,HostSendLED,p1,p2)
#define MBT_HID_HostSendControl(p1,p2)		__ApiLink2(MBT_HID,HostSendControl,p1,p2)
#define MBT_HID_HostSendReport(p1,p2,p3,p4)		__ApiLink4(MBT_HID,HostSendReport,p1,p2,p3,p4)
#define MBT_HID_HostSetReport(p1,p2,p3,p4)		__ApiLink4(MBT_HID,HostSetReport,p1,p2,p3,p4)
#define MBT_HID_HostGetReport(p1,p2,p3)		__ApiLink3(MBT_HID,HostGetReport,p1,p2,p3)
#define MBT_HID_HostGetIdle(p1)		__ApiLink1(MBT_HID,HostGetIdle,p1)
#define MBT_HID_HostSetIdle(p1,p2)		__ApiLink2(MBT_HID,HostSetIdle,p1,p2)
#define MBT_HID_HostGetProtocol(p1)		__ApiLink1(MBT_HID,HostGetProtocol,p1)
#define MBT_HID_HostSetProtocol(p1,p2)		__ApiLink2(MBT_HID,HostSetProtocol,p1,p2)

#define MBT_HID_DeviceEnable()		__ApiLink0(MBT_HID,DeviceEnable)
#define MBT_HID_DeviceDisable()		__ApiLink0(MBT_HID,DeviceDisable)
#define MBT_HID_DeviceConnect(p1)		__ApiLink1(MBT_HID,DeviceConnect,p1)
#define MBT_HID_DeviceDisconnect()		__ApiLink0(MBT_HID,DeviceDisconnect)
#define MBT_HID_DeviceSendUnplug()		__ApiLink0(MBT_HID,DeviceSendUnplug)
#define MBT_HID_DeviceSendReport(p1,p2,p3)		__ApiLink3(MBT_HID,DeviceSendReport,p1,p2,p3)
#define MBT_HID_DeviceSendKeyboardRpt(p1,p2,p3)		__ApiLink3(MBT_HID,DeviceSendKeyboardRpt,p1,p2,p3)
#define MBT_HID_DeviceSendMouseRpt(p1,p2,p3)		__ApiLink3(MBT_HID,DeviceSendMouseRpt,p1,p2,p3)
#define MBT_HID_DeviceChangeKeyboardRole()		__ApiLink0(MBT_HID,DeviceChangeKeyboardRole)
#define MBT_HID_DeviceChangeMouseRole()		__ApiLink0(MBT_HID,DeviceChangeMouseRole)
#define MBT_HID_DeviceChangePhoneRole()		__ApiLink0(MBT_HID,DeviceChangePhoneRole)
#endif

#endif//_MBT_HID_H_
