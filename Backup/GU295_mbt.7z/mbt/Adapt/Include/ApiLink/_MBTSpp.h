#ifndef	__MBT_SPP_H_
#define __MBT_SPP_H_

#include "..\..\..\Include\MBTSpp.h"

typedef MBT_VOID	(*T_pfnMBT_SPP_Enable) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_SPP_Listen) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_SPP_Disable) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_SPP_ListenStop) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_SPP_Connect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID	(*T_pfnMBT_SPP_Disconnect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_SPP_SendData) (T_MBT_SPP_DATA *txData);


typedef struct
{
	T_pfnMBT_SPP_Enable		  pfnEnable;
	T_pfnMBT_SPP_Listen			pfnListen;  
	T_pfnMBT_SPP_Disable		  pfnDisable;
	T_pfnMBT_SPP_ListenStop		pfnListenStop;
	T_pfnMBT_SPP_Connect		  pfnConnect;
	T_pfnMBT_SPP_Disconnect	  pfnDisconnect;
	T_pfnMBT_SPP_SendData	  pfnSendData;
} TApiGrp_MBT_SPP;

#ifndef		BNS_MAIN_VERSION
#define MBT_SPP_Enable()		    __ApiLink0(MBT_SPP,Enable)
#define MBT_SPP_Listen()		        __ApiLink0(MBT_SPP,Listen)
#define MBT_SPP_Disable()		    __ApiLink0(MBT_SPP,Disable)
#define MBT_SPP_ListenStop()		__ApiLink0(MBT_SPP,ListenStop)
#define MBT_SPP_Connect(p1)		__ApiLink1(MBT_SPP,Connect,p1)
#define MBT_SPP_Disconnect(p1)	__ApiLink1(MBT_SPP,Disconnect,p1)
#define MBT_SPP_SendData(p1)	__ApiLink1(MBT_SPP,SendData,p1)
#endif

#endif//__MBT_SPP_H_
