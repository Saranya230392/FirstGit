#ifndef __MBT_JSR82_H_
#define __MBT_JSR82_H_

#include "..\..\..\Include\MBTJsr82.h"

typedef MBT_VOID (*T_pfnMBT_JSR82_LDEnable)(MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_JSR82_LDDisable)(MBT_VOID);
typedef MBT_UINT (*T_pfnMBT_JSR82_LDGetDiscoverable)(MBT_VOID);
typedef MBT_BOOL (*T_pfnMBT_JSR82_LDSetDiscoverable)(MBT_UINT Mode);
typedef MBT_BOOL (*T_pfnMBT_JSR82_LDSetSecurity)(MBT_UINT Handle, T_MBT_JSR82_SET_SECURITY* Security);
typedef MBT_BOOL (*T_pfnMBT_JSR82_LDSetMyCoD)(MBT_SHORT ServiceCalss, MBT_BYTE MajorClass, MBT_BYTE MinorClass);
typedef MBT_BOOL (*T_pfnMBT_JSR82_LDGetMyCoD)(MBT_VOID);

typedef T_MBT_GAP_SECURITY (*T_pfnMBT_JSR82_RDGetEncrypted)(T_MBT_BDADDR RemoteBDAddr);
typedef MBT_BOOL (*T_pfnMBT_JSR82_RDSetEncrypted)(T_MBT_BDADDR RemoteBDAddr,T_MBT_GAP_SECURITY Security);
typedef MBT_BOOL (*T_pfnMBT_JSR82_RDGetAuthenticated)(T_MBT_BDADDR RemoteBDAddr);
typedef MBT_BOOL (*T_pfnMBT_JSR82_RDPairReq)(MBT_UINT Handle, T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq, MBT_BYTE PinLength);
typedef MBT_BOOL (*T_pfnMBT_JSR82_RDPairRes)(MBT_UINT Handle,MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_BYTE PinLength);
typedef MBT_BOOL (*T_pfnMBT_JSR82_RDNameReq)(MBT_UINT Handle, T_MBT_BDADDR RemoteBDAddr);
typedef MBT_BOOL (*T_pfnMBT_JSR82_DevDiscovery)(MBT_UINT Handle,MBT_UINT AccessMode);
typedef MBT_BOOL (*T_pfnMBT_JSR82_DevDiscoveryCancel)(MBT_UINT Handle);

typedef MBT_BOOL (*T_pfnMBT_JSR82_PopulateRecord)(MBT_UINT SvcHandle,T_MBT_BDADDR RemoteBDAddr,MBT_UINT *Attr,MBT_UINT AttrLength);
typedef MBT_BOOL (*T_pfnMBT_JSR82_ReadRecord)(MBT_UINT SvcHandle, MBT_BYTE* Data, MBT_UINT* DataLength);
typedef MBT_BOOL (*T_pfnMBT_JSR82_LDIsConnected)(T_MBT_BDADDR RemoteBDAddr);

typedef MBT_BOOL (*T_pfnMBT_JSR82_SvcDiscovery)(T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_SEARCH_SD* SearchInfo, MBT_UINT TransID);
typedef MBT_BOOL (*T_pfnMBT_JSR82_SvcDiscoveryCancel)(MBT_UINT TransID);
typedef MBT_BOOL (*T_pfnMBT_JSR82_GetServiceResult)(MBT_UINT TransID, MBT_INT ReadNum);

typedef MBT_VOID (*T_pfnMBT_JSR82_CreateRecord)(MBT_UINT SvcHandle, T_MBT_JSR82_SD_RECORD* CreateInfo);
typedef MBT_INT (*T_pfnMBT_JSR82_UpdateRecord)(MBT_UINT SvcHandle, T_MBT_JSR82_SD_RECORD* UpdateInfo);
typedef MBT_VOID (*T_pfnMBT_JSR82_RemoveRecord)(MBT_UINT SvcHandle);
typedef MBT_VOID (*T_pfnMBT_JSR82_DeleteAttribute)(MBT_UINT SvcHandle, MBT_SHORT AttrID);

typedef MBT_INT (*T_pfnMBT_JSR82_L2CAPOpenServer)(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config);
typedef MBT_INT (*T_pfnMBT_JSR82_L2CAPCloseServer)(MBT_BYTE Handle);
typedef MBT_INT  (*T_pfnMBT_JSR82_L2CAPGetServiceHandle)(MBT_VOID);
typedef MBT_INT (*T_pfnMBT_JSR82_L2CAPAccept)(MBT_BYTE Handle, MBT_BYTE PeerHandle);
typedef MBT_BOOL (*T_pfnMBT_JSR82_L2CAPOpenClient)(MBT_BYTE Handle);
typedef MBT_BOOL (*T_pfnMBT_JSR82_L2CAPSetParam)(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config);
typedef MBT_INT (*T_pfnMBT_JSR82_L2CAPConnect)(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, MBT_INT PSM);
typedef MBT_INT (*T_pfnMBT_JSR82_L2CAPDisconnect)(MBT_BYTE Handle);
typedef MBT_INT (*T_pfnMBT_JSR82_L2CAPWrite)(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
typedef MBT_INT (*T_pfnMBT_JSR82_L2CAPRead)(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
typedef MBT_BOOL (*T_pfnMBT_JSR82_L2CAPGetReady)(MBT_BYTE Handle, MBT_UINT* Length);
typedef MBT_VOID (*T_pfnMBT_JSR82_L2CAPRelease)(MBT_VOID);

typedef MBT_INT (*T_pfnMBT_JSR82_RFCOMMOpenServer)(MBT_BYTE Handle, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config);
typedef MBT_INT (*T_pfnMBT_JSR82_RFCOMMCloseServer)(MBT_BYTE Handle);
typedef MBT_INT  (*T_pfnMBT_JSR82_RFCOMMGetServiceHandle)(MBT_VOID);
typedef MBT_INT (*T_pfnMBT_JSR82_RFCOMMAccept)(MBT_BYTE Handle, MBT_BYTE PeerHandle);
typedef MBT_BOOL (*T_pfnMBT_JSR82_RFCOMMOpenClient)(MBT_BYTE Handle);
typedef MBT_INT (*T_pfnMBT_JSR82_RFCOMMConnect)(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config);
typedef MBT_INT (*T_pfnMBT_JSR82_RFCOMMDisconnect)(MBT_BYTE Handle);
typedef MBT_INT (*T_pfnMBT_JSR82_RFCOMMWrite)(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
typedef MBT_INT (*T_pfnMBT_JSR82_RFCOMMRead)(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
typedef MBT_BOOL (*T_pfnMBT_JSR82_RFCOMMGetReady)(MBT_BYTE Handle ,MBT_UINT* Length);
typedef MBT_VOID (*T_pfnMBT_JSR82_RFCOMMRelease)(MBT_VOID);


typedef struct
{
    T_pfnMBT_JSR82_LDEnable                 pfnLDEnable;
    T_pfnMBT_JSR82_LDDisable                pfnLDDisable;
    T_pfnMBT_JSR82_LDGetDiscoverable        pfnLDGetDiscoverable;
    T_pfnMBT_JSR82_LDSetDiscoverable        pfnLDSetDiscoverable;
    T_pfnMBT_JSR82_LDSetSecurity            pfnLDSetSecurity;
    T_pfnMBT_JSR82_LDSetMyCoD               pfnLDSetMyCoD;
	T_pfnMBT_JSR82_LDGetMyCoD				pfnLDGetMyCoD;

    T_pfnMBT_JSR82_RDGetEncrypted           pfnRDGetEncrypted;
    T_pfnMBT_JSR82_RDGetAuthenticated       pfnRDGetAuthenticated;
    T_pfnMBT_JSR82_RDSetEncrypted           pfnRDSetEncrypted;
    T_pfnMBT_JSR82_RDPairReq                pfnRDPairReq;
    T_pfnMBT_JSR82_RDPairRes                pfnRDPairRes;
    T_pfnMBT_JSR82_RDNameReq                pfnRDNameReq;

    T_pfnMBT_JSR82_DevDiscovery             pfnDevDiscovery;
    T_pfnMBT_JSR82_DevDiscoveryCancel       pfnDevDiscoveryCancel;
	T_pfnMBT_JSR82_PopulateRecord			pfnPopulateRecord;
	T_pfnMBT_JSR82_ReadRecord				pfnReadRecord;
	T_pfnMBT_JSR82_LDIsConnected			pfnLDIsConnected;
    T_pfnMBT_JSR82_SvcDiscovery             pfnSvcDiscovery;
    T_pfnMBT_JSR82_SvcDiscoveryCancel       pfnSvcDiscoveryCancel;
    T_pfnMBT_JSR82_GetServiceResult         pfnGetServiceResult;
    T_pfnMBT_JSR82_CreateRecord             pfnCreateRecord;    
    T_pfnMBT_JSR82_UpdateRecord             pfnUpdateRecord;
    T_pfnMBT_JSR82_RemoveRecord             pfnRemoveRecord;
    T_pfnMBT_JSR82_DeleteAttribute          pfnDeleteAttribute;

    T_pfnMBT_JSR82_L2CAPOpenServer          pfnL2CAPOpenServer;
    T_pfnMBT_JSR82_L2CAPCloseServer         pfnL2CAPCloseServer;
    T_pfnMBT_JSR82_L2CAPGetServiceHandle    pfnL2CAPGetServiceHandle;
    T_pfnMBT_JSR82_L2CAPAccept              pfnL2CAPAccept;
    T_pfnMBT_JSR82_L2CAPOpenClient          pfnL2CAPOpenClient;
    T_pfnMBT_JSR82_L2CAPSetParam            pfnL2CAPSetParam;
    T_pfnMBT_JSR82_L2CAPConnect             pfnL2CAPConnect;
    T_pfnMBT_JSR82_L2CAPDisconnect          pfnL2CAPDisconnect;    
    T_pfnMBT_JSR82_L2CAPWrite               pfnL2CAPWrite;
    T_pfnMBT_JSR82_L2CAPRead                pfnL2CAPRead;
    T_pfnMBT_JSR82_L2CAPGetReady            pfnL2CAPGetReady;
    T_pfnMBT_JSR82_L2CAPRelease             pfnL2CAPRelease;

    T_pfnMBT_JSR82_RFCOMMOpenServer         pfnRFCOMMOpenServer;
    T_pfnMBT_JSR82_RFCOMMCloseServer        pfnRFCOMMCloseServer;
    T_pfnMBT_JSR82_RFCOMMGetServiceHandle   pfnRFCOMMGetServiceHandle;    
    T_pfnMBT_JSR82_RFCOMMAccept             pfnRFCOMMAccept;
    T_pfnMBT_JSR82_RFCOMMOpenClient         pfnRFCOMMOpenClient;
    T_pfnMBT_JSR82_RFCOMMConnect            pfnRFCOMMConnect;
    T_pfnMBT_JSR82_RFCOMMDisconnect         pfnRFCOMMDisconnect;    
    T_pfnMBT_JSR82_RFCOMMWrite              pfnRFCOMMWrite;
    T_pfnMBT_JSR82_RFCOMMRead               pfnRFCOMMRead;
    T_pfnMBT_JSR82_RFCOMMGetReady           pfnRFCOMMGetReady;
    T_pfnMBT_JSR82_RFCOMMRelease            pfnRFCOMMRelease;    
} TApiGrp_MBT_JSR82;

#ifndef		BNS_MAIN_VERSION
#define MBT_JSR82_LDEnable()                    __ApiLink0(MBT_JSR82, LDEnable);
#define MBT_JSR82_LDDisable()                   __ApiLink0(MBT_JSR82, LDDisable);
#define MBT_JSR82_LDGetDiscoverable()           __ApiLink0(MBT_JSR82, LDGetDiscoverable);
#define MBT_JSR82_LDSetDiscoverable(p1)         __ApiLink1(MBT_JSR82, LDSetDiscoverable, p1);
#define MBT_JSR82_LDSetSecurity(p1, p2)         __ApiLink2(MBT_JSR82, LDSetSecurity, p1, p2);
#define MBT_JSR82_LDGetMyCoD() 			        __ApiLink0(MBT_JSR82, LDGetMyCoD);
#define MBT_JSR82_LDSetMyCoD(p1, p2, p3)        __ApiLink3(MBT_JSR82, LDSetMyCoD, p1, p2, p3);

#define MBT_JSR82_RDGetEncrypted(p1)            __ApiLink1(MBT_JSR82, RDGetEncrypted, p1);
#define MBT_JSR82_RDGetAuthenticated(p1)        __ApiLink1(MBT_JSR82, RDGetAuthenticated, p1);
#define MBT_JSR82_RDSetEncrypted(p1, p2)        __ApiLink2(MBT_JSR82, RDSetEncrypted, p1, p2);
#define MBT_JSR82_RDPairReq(p1, p2, p3, p4)     __ApiLink4(MBT_JSR82, RDPairReq, p1, p2, p3, p4);
#define MBT_JSR82_RDPairRes(p1, p2, p3, p4)     __ApiLink4(MBT_JSR82, RDPairRes, p1, p2, p3, p4);
#define MBT_JSR82_RDNameReq(p1, p2)             __ApiLink2(MBT_JSR82, RDNameReq, p1, p2);
    
#define MBT_JSR82_DevDiscovery(p1, p2)              __ApiLink2(MBT_JSR82, DevDiscovery, p1, p2);
#define MBT_JSR82_DevDiscoveryCancel(p1)          __ApiLink1(MBT_JSR82, DevDiscoveryCancel, p1);
#define MBT_JSR82_PopulateRecord(p1,p2,p3,p4)   __ApiLink4(MBT_JSR82, PopulateRecord, p1, p2, p3, p4);
#define MBT_JSR82_ReadRecord(p1, p2, p3)        __ApiLink3(MBT_JSR82, ReadRecord, p1, p2, p3);
#define MBT_JSR82_LDIsConnected(p1)        		__ApiLink1(MBT_JSR82, LDIsConnected, p1);
#define MBT_JSR82_SvcDiscovery(p1, p2, p3)      __ApiLink3(MBT_JSR82, SvcDiscovery, p1, p2, p3);
#define MBT_JSR82_SvcDiscoveryCancel(p1)        __ApiLink1(MBT_JSR82, SvcDiscoveryCancel, p1);
#define MBT_JSR82_GetServiceResult(p1, p2)      __ApiLink2(MBT_JSR82, GetServiceResult, p1, p2);
#define MBT_JSR82_CreateRecord(p1, p2)              __ApiLink2(MBT_JSR82, CreateRecord, p1, p2);
#define MBT_JSR82_UpdateRecord(p1, p2)          __ApiLink2(MBT_JSR82, UpdateRecord, p1, p2);
#define MBT_JSR82_RemoveRecord(p1)              __ApiLink1(MBT_JSR82, RemoveRecord, p1);
#define MBT_JSR82_DeleteAttribute(p1, p2)       __ApiLink2(MBT_JSR82, DeleteAttribute, p1, p2);

#define MBT_JSR82_L2CAPOpenServer(p1, p2)       __ApiLink2(MBT_JSR82, L2CAPOpenServer, p1, p2);
#define MBT_JSR82_L2CAPCloseServer(p1)          __ApiLink1(MBT_JSR82, L2CAPCloseServer, p1);
#define MBT_JSR82_L2CAPGetServiceHandle()       __ApiLink0(MBT_JSR82, L2CAPGetServiceHandle);
#define MBT_JSR82_L2CAPAccept(p1, p2)           __ApiLink2(MBT_JSR82, L2CAPAccept, p1, p2);
#define MBT_JSR82_L2CAPOpenClient(p1)           __ApiLink1(MBT_JSR82, L2CAPOpenClient, p1);
#define MBT_JSR82_L2CAPSetParam(p1, p2)         __ApiLink2(MBT_JSR82, L2CAPSetParam, p1, p2);
#define MBT_JSR82_L2CAPConnect(p1, p2, p3)      __ApiLink3(MBT_JSR82, L2CAPConnect, p1, p2, p3);
#define MBT_JSR82_L2CAPDisconnect(p1)           __ApiLink1(MBT_JSR82, L2CAPDisconnect, p1);
#define MBT_JSR82_L2CAPWrite(p1, p2, p3)        __ApiLink3(MBT_JSR82, L2CAPWrite, p1, p2, p3);
#define MBT_JSR82_L2CAPRead(p1, p2, p3)         __ApiLink3(MBT_JSR82, L2CAPRead, p1, p2, p3);
#define MBT_JSR82_L2CAPGetReady(p1, p2)             __ApiLink2(MBT_JSR82, L2CAPGetReady, p1, p2);
#define MBT_JSR82_L2CAPRelease()                __ApiLink0(MBT_JSR82, L2CAPRelease);

#define MBT_JSR82_RFCOMMOpenServer(p1, p2)      __ApiLink2(MBT_JSR82, RFCOMMOpenServer, p1, p2);
#define MBT_JSR82_RFCOMMCloseServer(p1)         __ApiLink1(MBT_JSR82, RFCOMMCloseServer, p1);
#define MBT_JSR82_RFCOMMGetServiceHandle()      __ApiLink0(MBT_JSR82, RFCOMMGetServiceHandle);
#define MBT_JSR82_RFCOMMAccept(p1, p2)          __ApiLink2(MBT_JSR82, RFCOMMAccept, p1, p2);
#define MBT_JSR82_RFCOMMOpenClient(p1)          __ApiLink1(MBT_JSR82, RFCOMMOpenClient, p1);
#define MBT_JSR82_RFCOMMConnect(p1, p2, p3)     __ApiLink3(MBT_JSR82, RFCOMMConnect, p1, p2, p3);
#define MBT_JSR82_RFCOMMDisconnect(p1)          __ApiLink1(MBT_JSR82, RFCOMMDisconnect, p1);
#define MBT_JSR82_RFCOMMWrite(p1, p2, p3)       __ApiLink3(MBT_JSR82, RFCOMMWrite, p1, p2, p3);
#define MBT_JSR82_RFCOMMRead(p1, p2, p3)        __ApiLink3(MBT_JSR82, RFCOMMRead, p1, p2, p3);
#define MBT_JSR82_RFCOMMGetReady(p1, p2)            __ApiLink2(MBT_JSR82, RFCOMMGetReady, p1, p2);
#define MBT_JSR82_RFCOMMRelease()               __ApiLink0(MBT_JSR82, RFCOMMRelease);
#endif

#endif	//__MBT_JSR82_H_
