#ifndef __MBT_FTP_H_
#define __MBT_FTP_H_
/********************************************************************************
*	File Name	: _MBtFtp.h
*	Description	: _MBtFtp.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.11.05	Lee,ChangHoon		Created
********************************************************************************/

#include "..\..\..\Include\MBTFtp.h"

typedef MBT_VOID (*T_pfnMBT_FTP_ServerEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_FTP_ServerDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_FTP_ServerAccessRsp) (T_MBT_AUTHRES Reply);
typedef MBT_VOID (*T_pfnMBT_FTP_ServerAuthRsp) (T_MBT_OBEX_AUTH *auth_reply);
typedef MBT_BOOL (*T_pfnMBT_FTP_ServerSetRootFolder) (MBT_CHAR *Rootfolder);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientConnect) (T_MBT_BDADDR remoteDev);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientDisconnect) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientAuthRsp) (T_MBT_OBEX_AUTH *auth_reply);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientPutFile) (T_MBT_FTP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientGetFile) (T_MBT_FTP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientChDir) (T_MBT_FTP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientMkDir) (T_MBT_FTP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientListDir) (T_MBT_FTP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientDelDir) (T_MBT_FTP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientDelFile) (T_MBT_FTP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_FTP_ClientAbort) (MBT_VOID);

typedef struct
{
	T_pfnMBT_FTP_ServerEnable			pfnServerEnable;
	T_pfnMBT_FTP_ServerDisable			pfnServerDisable;
	T_pfnMBT_FTP_ServerAccessRsp		pfnServerAccessRsp;
	T_pfnMBT_FTP_ServerAuthRsp			pfnServerAuthRsp;
	T_pfnMBT_FTP_ServerSetRootFolder	pfnServerSetRootFolder;
	T_pfnMBT_FTP_ClientEnable			pfnClientEnable;
	T_pfnMBT_FTP_ClientDisable			pfnClientDisable;
	T_pfnMBT_FTP_ClientConnect			pfnClientConnect;
	T_pfnMBT_FTP_ClientDisconnect		pfnClientDisconnect;
	T_pfnMBT_FTP_ClientAuthRsp			pfnClientAuthRsp;
	T_pfnMBT_FTP_ClientPutFile			pfnClientPutFile;
	T_pfnMBT_FTP_ClientGetFile			pfnClientGetFile;
	T_pfnMBT_FTP_ClientChDir			pfnClientChDir;
	T_pfnMBT_FTP_ClientMkDir			pfnClientMkDir;
	T_pfnMBT_FTP_ClientListDir			pfnClientListDir;
	T_pfnMBT_FTP_ClientDelDir			pfnClientDelDir;
	T_pfnMBT_FTP_ClientDelFile			pfnClientDelFile;
	T_pfnMBT_FTP_ClientAbort			pfnClientAbort;
}TApiGrp_MBT_FTP;

#ifndef BNS_MAIN_VERSION
#define	MBT_FTP_ServerEnable()			__ApiLink0(MBT_FTP,ServerEnable)
#define	MBT_FTP_ServerDisable()			__ApiLink0(MBT_FTP,ServerDisable)
#define	MBT_FTP_ServerAccessRsp(p1)		__ApiLink1(MBT_FTP,ServerAccessRsp,p1)
#define	MBT_FTP_ServerAuthRsp(p1)		__ApiLink1(MBT_FTP,ServerAuthRsp,p1)
#define	MBT_FTP_ServerSetRootFolder(p1)	__ApiLink1(MBT_FTP,ServerSetRootFolder,p1)
#define	MBT_FTP_ClientEnable()			__ApiLink0(MBT_FTP,ClientEnable)
#define	MBT_FTP_ClientDisable()			__ApiLink0(MBT_FTP,ClientDisable)
#define	MBT_FTP_ClientConnect(p1)		__ApiLink1(MBT_FTP,ClientConnect,p1)
#define	MBT_FTP_ClientDisconnect()		__ApiLink0(MBT_FTP,ClientDisconnect)
#define	MBT_FTP_ClientAuthRsp(p1)		__ApiLink1(MBT_FTP,ClientAuthRsp,p1)
#define	MBT_FTP_ClientPutFile(p1)		__ApiLink1(MBT_FTP,ClientPutFile,p1)
#define	MBT_FTP_ClientGetFile(p1)		__ApiLink1(MBT_FTP,ClientGetFile,p1)
#define	MBT_FTP_ClientChDir(p1)			__ApiLink1(MBT_FTP,ClientChDir,p1)
#define	MBT_FTP_ClientMkDir(p1)			__ApiLink1(MBT_FTP,ClientMkDir,p1)
#define	MBT_FTP_ClientListDir(p1)		__ApiLink1(MBT_FTP,ClientListDir,p1)
#define	MBT_FTP_ClientDelDir(p1)		__ApiLink1(MBT_FTP,ClientDelDir,p1)
#define	MBT_FTP_ClientDelFile(p1)		__ApiLink1(MBT_FTP,ClientDelFile,p1)
#define	MBT_FTP_ClientAbort()			__ApiLink0(MBT_FTP,ClientAbort)
#endif

#endif //__MBT_FTP_H_

