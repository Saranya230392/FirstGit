#ifndef	__MBT_AG_H_
#define __MBT_AG_H_

#include "..\..\..\Include\MBTAg.h"

typedef MBT_VOID	(*T_pfnMBT_AG_Enable) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_AG_Disable) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_AG_Connect) (T_MBT_BDADDR RemoteBDAddr,MBT_SERVICE_ID MBTSvc);
typedef MBT_VOID	(*T_pfnMBT_AG_Disconnect) (T_MBT_BDADDR RemoteBDAddr,MBT_SERVICE_ID MBTSvc);
typedef MBT_VOID	(*T_pfnMBT_AG_AudioConnect) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_AG_AudioDisconnect) (MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_AG_GetConStatus) (MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_AG_GetAudioStatus) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_AG_SetConnectable) (MBT_BOOL connectable);
typedef MBT_VOID	(*T_pfnMBT_AG_SetAudioPath) (MBT_BOOL audiopath);
typedef MBT_VOID	(*T_pfnMBT_AG_SetSpkVolume) (MBT_BYTE Level);
typedef MBT_VOID	(*T_pfnMBT_AG_SetMicVolume) (MBT_BYTE Level);
typedef MBT_VOID	(*T_pfnMBT_AG_CallStateChange) (T_MBT_AG_PHONE_CALLSTATE NewState);
typedef MBT_VOID	(*T_pfnMBT_AG_SetCallStatus) (T_MBT_AG_CALLSTATUS CurrentStatus);
typedef MBT_VOID	(*T_pfnMBT_AG_SetCallSetup) (T_MBT_AG_CALLSETUP CurrentCallSetup);
typedef MBT_VOID	(*T_pfnMBT_AG_SetNetworkStatus) (T_MBT_AG_NETSTATE State);
typedef MBT_VOID	(*T_pfnMBT_AG_SetCID) (MBT_CHAR* Num,MBT_BYTE len);
typedef MBT_BOOL (*T_pfnMBT_AG_SetSignalStrength) (MBT_BYTE Level);
typedef MBT_BOOL (*T_pfnMBT_AG_SetRoamingStatus) (MBT_BYTE Level);
typedef MBT_BOOL (*T_pfnMBT_AG_SetBatteryLevel) (MBT_BYTE Level);
typedef MBT_BOOL (*T_pfnMBT_AG_SetCallHeldStatus) (T_MBT_AG_CALL_HELD value);
typedef MBT_BOOL (*T_pfnMBT_AG_SetOperatorSelection) (T_MBT_AG_NETMODE Netmode,MBT_BYTE* OpName);
typedef MBT_BOOL (*T_pfnMBT_AG_SetExtendedError) (T_MBT_AG_CME_ERR ErrorCode);
typedef MBT_BOOL (*T_pfnMBT_AG_SetSubscriberNumber) (MBT_CHAR* Num, MBT_BYTE NumType, MBT_BYTE Len, T_MBT_AG_SERVICE Service,MBT_BOOL FinalFlag);
typedef MBT_BOOL (*T_pfnMBT_AG_SetCallWaiting) (MBT_CHAR* Num,MBT_BYTE Len);
typedef MBT_VOID	(*T_pfnMBT_AG_SendResponse) (MBT_BOOL);
typedef MBT_BOOL (*T_pfnMBT_AG_SetCIND) (T_MBT_AG_NETSTATE Net, T_MBT_AG_CALLSTATUS CallState, T_MBT_AG_CALLSETUP SetupState, MBT_BYTE SignalLevel, MBT_BYTE RoamingStatus, MBT_BYTE BatteryLevel,T_MBT_AG_CALL_HELD value);
typedef MBT_BOOL (*T_pfnMBT_AG_SetCurrentCallList) (MBT_BYTE Idx, T_MBT_AG_CL_DIR Dir, T_MBT_AG_CL_STATUS Status,T_MBT_AG_CL_MODE Mode,T_MBT_AG_CL_MPTY Mprty,MBT_CHAR* Num,MBT_BYTE NumType,MBT_BYTE Len,MBT_BOOL FinalFlag);
typedef MBT_VOID	(*T_pfnMBT_AG_StartVR) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_AG_StopVR) (MBT_VOID);

typedef MBT_VOID (*T_pfnMBT_AG_SendSupportedPBList) (T_MBT_AG_PB_CPBS supportedPbList);
typedef MBT_VOID (*T_pfnMBT_AG_SendSelectedPBInfo) (T_MBT_AG_PB_RETURN result, MBT_SHORT usedRecs, MBT_SHORT totalRecs);
typedef MBT_VOID (*T_pfnMBT_AG_SendPBEntriesInfo) (T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt);
typedef MBT_VOID (*T_pfnMBT_AG_SendPBReadResult) (T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec, MBT_BOOL finalEntry);
typedef MBT_VOID (*T_pfnMBT_AG_SendPBFindEntriesInfo) (T_MBT_AG_PB_RETURN result, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt);
typedef MBT_VOID (*T_pfnMBT_AG_SendPBFindResult) (T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec, MBT_BOOL finalEntry);
typedef MBT_VOID (*T_pfnMBT_AG_SendPBWriteInfo) (T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxlenNum, MBT_SHORT typeStart, MBT_SHORT typeEnd, MBT_SHORT maxlenTxt);
typedef MBT_VOID (*T_pfnMBT_AG_SendPBSelectResult)( T_MBT_AG_PB_RETURN result );
typedef MBT_VOID (*T_pfnMBT_AG_SendPBWriteResult)( T_MBT_AG_PB_RETURN result );

typedef MBT_VOID (*T_pfnMBT_AG_RingStart)(MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_AG_RingStop)(MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_AG_SetCGM)(MBT_CHAR* manufacturerid, MBT_CHAR* modelid);
typedef MBT_VOID (*T_pfnMBT_AG_SetCSCS)(T_MBT_AG_CSCS* AgCSList);

typedef struct
{
	T_pfnMBT_AG_Enable                  pfnEnable;
	T_pfnMBT_AG_Disable         	    pfnDisable;
	T_pfnMBT_AG_Connect	                pfnConnect;
	T_pfnMBT_AG_Disconnect			    pfnDisconnect;
	T_pfnMBT_AG_AudioConnect            pfnAudioConnect;
	T_pfnMBT_AG_AudioDisconnect         pfnAudioDisconnect;
	T_pfnMBT_AG_GetConStatus            pfnGetConStatus;
	T_pfnMBT_AG_GetAudioStatus          pfnGetAudioStatus;
	T_pfnMBT_AG_SetConnectable          pfnSetConnectable;
	T_pfnMBT_AG_SetAudioPath            pfnSetAudioPath;
	T_pfnMBT_AG_SetSpkVolume            pfnSetSpkVolume;
	T_pfnMBT_AG_SetMicVolume		    pfnSetMicVolume;
	T_pfnMBT_AG_CallStateChange		    pfnCallStateChange;
	T_pfnMBT_AG_SetCallStatus           pfnSetCallStatus;
	T_pfnMBT_AG_SetCallSetup            pfnSetCallSetup; 
	T_pfnMBT_AG_SetNetworkStatus        pfnSetNetworkStatus;
	T_pfnMBT_AG_SetCID                  pfnSetCID;
	T_pfnMBT_AG_SetSignalStrength       pfnSetSignalStrength;
	T_pfnMBT_AG_SetRoamingStatus        pfnSetRoamingStatus;
	T_pfnMBT_AG_SetBatteryLevel         pfnSetBatteryLevel;
	T_pfnMBT_AG_SetCallHeldStatus       pfnSetCallHeldStatus;
	T_pfnMBT_AG_SetOperatorSelection    pfnSetOperatorSelection;
	T_pfnMBT_AG_SetExtendedError        pfnSetExtendedError;
	T_pfnMBT_AG_SetSubscriberNumber     pfnSetSubscriberNumber;
	T_pfnMBT_AG_SetCallWaiting          pfnSetCallWaiting;
	T_pfnMBT_AG_SendResponse            pfnSendResponse;
	T_pfnMBT_AG_SetCIND                 pfnSetCIND;
	T_pfnMBT_AG_SetCurrentCallList      pfnSetCurrentCallList;
	T_pfnMBT_AG_StartVR                 pfnStartVR;
	T_pfnMBT_AG_StopVR                  pfnStopVR;
	
	T_pfnMBT_AG_SendSupportedPBList		pfnSendSupportedPBList;
	T_pfnMBT_AG_SendSelectedPBInfo		pfnSendSelectedPBInfo;
	T_pfnMBT_AG_SendPBEntriesInfo		pfnSendPBEntriesInfo;
	T_pfnMBT_AG_SendPBReadResult		pfnSendPBReadResult;
	T_pfnMBT_AG_SendPBFindEntriesInfo   pfnSendPBFindEntriesInfo;
	T_pfnMBT_AG_SendPBFindResult		pfnSendPBFindResult;
	T_pfnMBT_AG_SendPBWriteInfo			pfnSendPBWriteInfo;
	T_pfnMBT_AG_SendPBSelectResult		pfnSendPBSelectResult;
	T_pfnMBT_AG_SendPBWriteResult		pfnSendPBWriteResult;	

	T_pfnMBT_AG_RingStart				pfnRingStart;
	T_pfnMBT_AG_RingStop				pfnRingStop;
	T_pfnMBT_AG_SetCGM					pfnSetCGM;
	T_pfnMBT_AG_SetCSCS			pfnSetCSCS;
	
} TApiGrp_MBT_AG;

#ifndef BNS_MAIN_VERSION
	#define MBT_AG_Enable()			   			    __ApiLink0(MBT_AG,Enable)
	#define MBT_AG_Disable()					    __ApiLink0(MBT_AG,Disable)
	#define MBT_AG_Connect(p1,p2)					__ApiLink2(MBT_AG,Connect,p1,p2)
	#define MBT_AG_Disconnect(p1,p2)				__ApiLink2(MBT_AG,Disconnect,p1,p2)
	#define MBT_AG_AudioConnect()				    __ApiLink0(MBT_AG,AudioConnect)
	#define MBT_AG_AudioDisconnect()		        __ApiLink0(MBT_AG,AudioDisconnect)
	#define MBT_AG_GetConStatus()		 		    __ApiLink0(MBT_AG,GetConStatus)
	#define MBT_AG_GetAudioStatus()	    		    __ApiLink0(MBT_AG,GetAudioStatus)
	#define MBT_AG_SetConnectable(p1)				__ApiLink1(MBT_AG,SetConnectable,p1)
	#define MBT_AG_SetAudioPath(p1)					__ApiLink1(MBT_AG,SetAudioPath,p1)
	#define MBT_AG_SetSpkVolume(p1)		        	__ApiLink1(MBT_AG,SetSpkVolume,p1)
	#define MBT_AG_SetMicVolume(p1)					__ApiLink1(MBT_AG,SetMicVolume,p1)
	#define MBT_AG_CallStateChange(p1)		    	__ApiLink1(MBT_AG,CallStateChange,p1)
	#define MBT_AG_SetCallStatus(p1) 				__ApiLink1(MBT_AG,SetCallStatus,p1)
	#define MBT_AG_SetCallSetup(p1) 				__ApiLink1(MBT_AG,SetCallSetup,p1)
	#define MBT_AG_SetNetworkStatus(p1)				__ApiLink1(MBT_AG,SetNetworkStatus,p1)
	#define MBT_AG_SetCID(p1,p2)			    	__ApiLink2(MBT_AG,SetCID,p1,p2)
	#define MBT_AG_SetSignalStrength(p1)			__ApiLink1(MBT_AG,SetSignalStrength,p1)
	#define MBT_AG_SetRoamingStatus(p1)				__ApiLink1(MBT_AG,SetRoamingStatus,p1)
	#define MBT_AG_SetBatteryLevel(p1)				__ApiLink1(MBT_AG,SetBatteryLevel,p1)
	#define MBT_AG_SetCallHeldStatus(p1)			__ApiLink1(MBT_AG,SetCallHeldStatus,p1)
	#define MBT_AG_SetOperatorSelection(p1,p2)		__ApiLink2(MBT_AG,SetOperatorSelection,p1,p2)
	#define MBT_AG_SetExtendedError(p1)				__ApiLink1(MBT_AG,SetExtendedError,p1)
	#define MBT_AG_SetSubscriberNumber(p1,p2,p3,p4,p5) __ApiLink5(MBT_AG,SetSubscriberNumber,p1,p2,p3,p4,p5)
	#define MBT_AG_SetCallWaiting(p1,p2)			__ApiLink2(MBT_AG,SetCallWaiting,p1,p2)
	#define MBT_AG_SendResponse(p1)	                __ApiLink1(MBT_AG,SendResponse,p1)
	#define MBT_AG_SetCIND(p1,p2,p3,p4,p5,p6,p7)	__ApiLink7(MBT_AG,SetCIND,p1,p2,p3,p4,p5,p6,p7)
	#define MBT_AG_SetCurrentCallList(p1,p2,p3,p4,p5,p6,p7,p8,p9)  __ApiLink9(MBT_AG,SetCurrentCallList,p1,p2,p3,p4,p5,p6,p7,p8,p9)
	#define MBT_AG_StartVR()			                __ApiLink0(MBT_AG,StartVR)
	#define MBT_AG_StopVR()		 	        	        __ApiLink0(MBT_AG,StopVR)

	#define MBT_AG_SendSupportedPBList(p1)          	__ApiLink1(MBT_AG,SendSupportedPBList,p1)
	#define MBT_AG_SendSelectedPBInfo(p1,p2,p3)         __ApiLink3(MBT_AG,SendSelectedPBInfo,p1,p2,p3)
	#define MBT_AG_SendPBEntriesInfo(p1,p2,p3,p4,p5)	__ApiLink5(MBT_AG,SendPBEntriesInfo,p1,p2,p3,p4,p5)
	#define MBT_AG_SendPBReadResult(p1,p2,p3)           __ApiLink3(MBT_AG,SendPBReadResult,p1,p2,p3)
	#define MBT_AG_SendPBFindEntriesInfo(p1,p2,p3)      __ApiLink3(MBT_AG,SendPBFindEntriesInfo,p1,p2,p3)
	#define MBT_AG_SendPBFindResult(p1,p2,p3)           __ApiLink3(MBT_AG,SendPBFindResult,p1,p2,p3)
	#define MBT_AG_SendPBWriteInfo(p1,p2,p3,p4,p5,p6,p7)   __ApiLink7(MBT_AG,SendPBWriteInfo,p1,p2,p3,p4,p5,p6,p7)
	#define MBT_AG_SendPBSelectResult(p1)	__ApiLink1(MBT_AG,SendPBSelectResult,p1)
	#define MBT_AG_SendPBWriteResult(p1)	__ApiLink1(MBT_AG,SendPBWriteResult,p1)

	#define MBT_AG_RingStart()							__ApiLink0(MBT_AG,RingStart)
	#define MBT_AG_RingStop()							__ApiLink0(MBT_AG,RingStop)
	#define MBT_AG_SetCGM(p1,p2)						__ApiLink2(MBT_AG,SetCGM,p1,p2)
	#define MBT_AG_SetCSCS(p1)				__ApiLink1(MBT_AG,SetCSCS,p1)
#endif//BNS_MAIN_VERSION

#endif //__MBT_AG_H_
