#ifndef __MBT_SDC_H_
#define __MBT_SDC_H_
/********************************************************************************
*	File Name	: _MBtSdc.h
*	Description	: _MBtSdc.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.11.05	Lee,ChangHoon		Created
********************************************************************************/

#include "..\..\..\Include\MBTSdc.h"

typedef MBT_VOID* (*T_pfnMBT_SDC_GetRecord) (T_MBT_SDC_RECID MBTSDCRecID);
typedef MBT_INT (*T_pfnMBT_SDC_GetValue) (T_MBT_SDC_VALID MBTSDCValID);
typedef MBT_VOID (*T_pfnMBT_SDC_InitData) (MBT_VOID);

typedef struct
{
	T_pfnMBT_SDC_GetRecord		pfnGetRecord;
	T_pfnMBT_SDC_GetValue		pfnGetValue;
	T_pfnMBT_SDC_InitData		pfnInitData;

}TApiGrp_MBT_SDC;

#ifndef BNS_MAIN_VERSION
#define MBT_SDC_GetRecord(p1)		__ApiLink1(MBT_SDC,GetRecord,p1)
#define MBT_SDC_GetValue(p1)		__ApiLink1(MBT_SDC,GetValue,p1)
#define MBT_SDC_InitData()		__ApiLink0(MBT_SDC,InitData)
#endif

#endif//__MBT_SDC_H_