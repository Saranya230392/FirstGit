#ifndef __MBT_PBAP_H_
#define __MBT_PBAP_H_

#include "..\..\..\Include\MBTPbap.h"


typedef MBT_VOID (*T_pfnMBT_PBAP_ServerEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_PBAP_ServerDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_PBAP_ServerAccessResponse) (MBT_BOOL b_allow);
typedef MBT_VOID (*T_pfnMBT_PBAP_ServerAuthenticate) (MBT_CHAR *p_password, MBT_CHAR *p_userid);
typedef MBT_VOID (*T_pfnMBT_PBAP_ServerClose) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_PBAP_ServerWriteData) (T_MBT_PBAP_OP Operation);

typedef struct
{
	T_pfnMBT_PBAP_ServerEnable			pfnServerEnable;
	T_pfnMBT_PBAP_ServerDisable			pfnServerDisable;
	T_pfnMBT_PBAP_ServerAccessResponse		pfnServerAccessResponse;
	T_pfnMBT_PBAP_ServerAuthenticate			pfnServerAuthenticate;
	T_pfnMBT_PBAP_ServerClose	pfnServerClose;
	T_pfnMBT_PBAP_ServerWriteData			pfnServerWriteData;
}TApiGrp_MBT_PBAP;

#ifndef BNS_MAIN_VERSION
#define	MBT_PBAP_ServerEnable()			__ApiLink0(MBT_PBAP,ServerEnable)
#define	MBT_PBAP_ServerDisable()			__ApiLink0(MBT_PBAP,ServerDisable)
#define	MBT_PBAP_ServerAccessResponse(p1)		__ApiLink1(MBT_PBAP,ServerAccessResponse,p1)
#define	MBT_PBAP_ServerAuthenticate(p1,p2)		__ApiLink2(MBT_PBAP,ServerAuthenticate,p1,p2)
#define	MBT_PBAP_ServerClose()	__ApiLink0(MBT_PBAP,ServerClose)
#define	MBT_PBAP_ServerWriteData(p1)			__ApiLink1(MBT_PBAP,ServerWriteData,p1)
#endif

#endif //__MBT_PBAP_H_

