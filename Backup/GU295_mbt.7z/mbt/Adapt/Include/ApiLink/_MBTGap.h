#ifndef	__MBT_GAP_H_
#define __MBT_GAP_H_
/********************************************************************************
*	File Name	: _MBtGap.h
*	Description	: _MBtGap.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.11.05	Lee,ChangHoon		Created
********************************************************************************/

#include "..\..\..\Include\MBTGap.h"

typedef MBT_BOOL	(*T_pfnMBT_GAP_BTInitialize) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_GAP_BluetoothOn) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_GAP_BluetoothOff) (MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_GAP_SetMyName) (MBT_CHAR* MyDevName);
typedef MBT_BOOL	(*T_pfnMBT_GAP_SetNickName) (T_MBT_BDADDR PairedDevAddr, MBT_CHAR* NickName);
typedef MBT_BOOL	(*T_pfnMBT_GAP_SetConnectable) (MBT_BOOL bConnectable);
typedef MBT_BOOL	(*T_pfnMBT_GAP_SetVisible) (MBT_BOOL bVisibile);
typedef MBT_BOOL	(*T_pfnMBT_GAP_SetPairable) (MBT_BOOL bPairabie);
typedef MBT_BOOL	(*T_pfnMBT_GAP_IsCmdAcceptable) (MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_GAP_IsDeviceConnected)	(T_MBT_BDADDR RemoteBDAddr);
typedef MBT_BOOL 	(*T_pfnMBT_GAP_IsSvcConnected) (MBT_SERVICE_ID MBTSvc);
typedef MBT_BOOL	(*T_pfnMBT_GAP_IsAuthorized) (T_MBT_BDADDR RemoteBDAddr);
typedef MBT_VOID	(*T_pfnMBT_GAP_DevDiscovery) (MBT_SERVICE_ID MBTSvc, MBT_INT nMaxCount);
typedef MBT_VOID	(*T_pfnMBT_GAP_DevDiscoveryCancel) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_GAP_NameReq) (T_MBT_BDADDR RemoteBdAddr);
typedef MBT_VOID	(*T_pfnMBT_GAP_NameReqCancel) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_GAP_SvcDiscovery) (T_MBT_BDADDR RemoteBdAddr);
typedef MBT_VOID	(*T_pfnMBT_GAP_SvcDiscoveryCancel) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_GAP_PairReq) (T_MBT_BDADDR RemoteBdAddr, T_MBT_PIN PinReq, MBT_INT PinLength);
typedef MBT_VOID	(*T_pfnMBT_GAP_PairReqCancel) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_GAP_PairRes) (MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_INT PinLength);
typedef MBT_VOID	(*T_pfnMBT_GAP_SspRes)(MBT_BOOL bAccept);
typedef MBT_VOID	(*T_pfnMBT_GAP_SspPasskeyCancel)(MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_GAP_AuthorizationRes) (MBT_BOOL bAccept, MBT_SERVICE_ID AuthSvc);
typedef MBT_BOOL	(*T_pfnMBT_GAP_UnPair) (T_MBT_BDADDR RemoteBdAddr);
typedef MBT_BOOL	(*T_pfnMBT_GAP_UnPairAll) (MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_GAP_SetAuthorize) (T_MBT_BDADDR RemoteBdAddr, MBT_BOOL bAuthorize);
typedef MBT_BOOL	(*T_pfnMBT_GAP_AddBlockDev) (T_MBT_BDADDR BdAddr);
typedef MBT_BOOL	(*T_pfnMBT_GAP_RemoveBlockDev) (T_MBT_BDADDR BdAddr);

typedef struct
{ 
	T_pfnMBT_GAP_BTInitialize			pfnBTInitialize;
	T_pfnMBT_GAP_BluetoothOn			pfnBluetoothOn;
	T_pfnMBT_GAP_BluetoothOff			pfnBluetoothOff;
	T_pfnMBT_GAP_SetMyName			pfnSetMyName;   
	T_pfnMBT_GAP_SetNickName		pfnSetNickName;
	T_pfnMBT_GAP_SetConnectable		pfnSetConnectable;
	T_pfnMBT_GAP_SetVisible			pfnSetVisible;
	T_pfnMBT_GAP_SetPairable			pfnSetPairable;
	T_pfnMBT_GAP_IsCmdAcceptable		pfnIsCmdAcceptable;
	T_pfnMBT_GAP_IsDeviceConnected	pfnIsDeviceConnected;
	T_pfnMBT_GAP_IsSvcConnected		pfnIsSvcConnected;
	T_pfnMBT_GAP_IsAuthorized			pfnIsAuthorized;
	T_pfnMBT_GAP_DevDiscovery		pfnDevDiscovery;
	T_pfnMBT_GAP_DevDiscoveryCancel	pfnDevDiscoveryCancel;
	T_pfnMBT_GAP_NameReq			pfnNameReq; 
	T_pfnMBT_GAP_NameReqCancel		pfnNameReqCancel;   
	T_pfnMBT_GAP_SvcDiscovery		pfnSvcDiscovery;   
	T_pfnMBT_GAP_SvcDiscoveryCancel	pfnSvcDiscoveryCancel;
	T_pfnMBT_GAP_PairReq				pfnPairReq;           
	T_pfnMBT_GAP_PairReqCancel		pfnPairReqCancel;     
	T_pfnMBT_GAP_PairRes				pfnPairRes; 
	T_pfnMBT_GAP_SspRes				pfnSspRes;
	T_pfnMBT_GAP_SspPasskeyCancel	pfnSspPasskeyCancel;
	T_pfnMBT_GAP_AuthorizationRes		pfnAuthorizationRes;  
	T_pfnMBT_GAP_UnPair				pfnUnPair;        
	T_pfnMBT_GAP_UnPairAll			pfnUnPairAll;
	T_pfnMBT_GAP_SetAuthorize			pfnSetAuthorize;
	T_pfnMBT_GAP_AddBlockDev		pfnAddBlockDev;
	T_pfnMBT_GAP_RemoveBlockDev		pfnRemoveBlockDev;
} TApiGrp_MBT_GAP;

#ifndef BNS_MAIN_VERSION
	#define MBT_GAP_BTInitialize()				__ApiLink0(MBT_GAP,BTInitialize)
	#define MBT_GAP_BluetoothOn()				__ApiLink0(MBT_GAP,BluetoothOn)
	#define MBT_GAP_BluetoothOff()				__ApiLink0(MBT_GAP,BluetoothOff)
	#define MBT_GAP_SetMyName(p1)				__ApiLink1(MBT_GAP,SetMyName,p1)
	#define MBT_GAP_SetNickName(p1,p2)			__ApiLink2(MBT_GAP,SetNickName,p1,p2)
	#define MBT_GAP_SetConnectable(p1)			__ApiLink1(MBT_GAP,SetConnectable,p1)
	#define MBT_GAP_SetVisible(p1)				__ApiLink1(MBT_GAP,SetVisible,p1)
	#define MBT_GAP_SetPairable(p1)				__ApiLink1(MBT_GAP,SetPairable,p1)
	#define MBT_GAP_IsCmdAcceptable()			__ApiLink0(MBT_GAP,IsCmdAcceptable)
	#define MBT_GAP_IsDeviceConnected(p1)		__ApiLink1(MBT_GAP,IsDeviceConnected,p1)
	#define MBT_GAP_IsSvcConnected(p1)			__ApiLink1(MBT_GAP,IsSvcConnected,p1)
	#define MBT_GAP_IsAuthorized(p1)			__ApiLink1(MBT_GAP,IsAuthorized,p1)
	#define MBT_GAP_DevDiscovery(p1,p2)		__ApiLink2(MBT_GAP,DevDiscovery,p1,p2)
	#define MBT_GAP_DevDiscoveryCancel()		__ApiLink0(MBT_GAP,DevDiscoveryCancel)
	#define MBT_GAP_NameReq(p1)				__ApiLink1(MBT_GAP,NameReq,p1)
	#define MBT_GAP_NameReqCancel()			__ApiLink0(MBT_GAP,NameReqCancel)
	#define MBT_GAP_SvcDiscovery(p1)			__ApiLink1(MBT_GAP,SvcDiscovery,p1)
	#define MBT_GAP_SvcDiscoveryCancel()		__ApiLink0(MBT_GAP,SvcDiscoveryCancel)
	#define MBT_GAP_PairReq(p1,p2,p3)		        __ApiLink3(MBT_GAP,PairReq,p1,p2,p3)
	#define MBT_GAP_PairReqCancel()				__ApiLink0(MBT_GAP,PairReqCancel)
	#define MBT_GAP_PairRes(p1,p2,p3)			__ApiLink3(MBT_GAP,PairRes,p1,p2,p3)
	#define MBT_GAP_SspRes(p1)					__ApiLink1(MBT_GAP,SspRes,p1)
	#define MBT_GAP_SspPassKeyCancel()			__ApiLink0(MBT_GAP,SspPassKeyCancel)
	#define MBT_GAP_AuthorizationRes(p1,p2)		__ApiLink2(MBT_GAP,AuthorizationRes,p1,p2)
	#define MBT_GAP_UnPair(p1)					__ApiLink1(MBT_GAP,UnPair,p1)
	#define MBT_GAP_UnPairAll()					__ApiLink0(MBT_GAP,UnPairAll)
	#define MBT_GAP_SetAuthorize(p1,p2)			__ApiLink2(MBT_GAP,SetAuthorize,p1,p2)
	#define MBT_GAP_AddBlockDev(p1)			__ApiLink1(MBT_GAP,AddBlockDev,p1)
	#define MBT_GAP_RemoveBlockDev(p1)		__ApiLink1(MBT_GAP,RemoveBlockDev,p1)
#endif//BNS_MAIN_VERSION

#endif//__MBT_GAP_H_

