#ifndef	__MBT_AVRCP_H_
#define __MBT_AVRCP_H_
/********************************************************************************
*	File Name	: _MBTAvrcp.h
*	Description	: _MBTAvrcp.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.04.05	Lee,ChoonSik		Created
********************************************************************************/
#include "..\..\..\Include\MBTAvrcp.h"

typedef MBT_VOID (*T_pfnMBT_AVRCP_Enable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_AVRCP_Disable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_AVRCP_Connect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_AVRCP_Disconnect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_AVRCP_SendCmd) (T_MBT_BDADDR BdAddr, T_MBT_AVRCP_KEY KeyValue);
typedef MBT_VOID (*T_pfnMBT_AVRCP_GetPlayerValueRes)(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_APP_ATTR* AttrValue);
typedef MBT_VOID (*T_pfnMBT_AVRCP_GetMediaAttrRes)(T_MBT_BDADDR BdAddr, MBT_BYTE AttrNum, T_MBT_AVRCP_MEDIA_ATTR* AttrData );
typedef MBT_VOID (*T_pfnMBT_AVRCP_GetPlayStatusRes)(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_GET_PLAYSTATUS PlayStatus);
typedef MBT_VOID (*T_pfnMBT_AVRCP_RegisterNotiInterimRes)(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti);
typedef MBT_VOID (*T_pfnMBT_AVRCP_RegisterNotiRes)(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti);

typedef struct
{
	T_pfnMBT_AVRCP_Enable				pfnEnable;
	T_pfnMBT_AVRCP_Disable				pfnDisable;
	T_pfnMBT_AVRCP_Connect				pfnConnect;
	T_pfnMBT_AVRCP_Disconnect			pfnDisconnect;
	T_pfnMBT_AVRCP_SendCmd				pfnSendCmd;
	T_pfnMBT_AVRCP_GetPlayerValueRes 		pfnGetPlayerValueRes;
	T_pfnMBT_AVRCP_GetMediaAttrRes		pfnGetMediaAttrRes;
	T_pfnMBT_AVRCP_GetPlayStatusRes		pfnGetPlayStatusRes;
	T_pfnMBT_AVRCP_RegisterNotiInterimRes	pfnRegisterNotiInterimRes;	
	T_pfnMBT_AVRCP_RegisterNotiRes		pfnRegisterNotiRes;
}TApiGrp_MBT_AVRCP;

#ifndef BNS_MAIN_VERSION
#define MBT_AVRCP_Enable()          				__ApiLink0(MBT_AVRCP,Enable)
#define MBT_AVRCP_Disable()         				__ApiLink0(MBT_AVRCP,Disable)
#define MBT_AVRCP_Connect(p1)     				__ApiLink1(MBT_AVRCP,Connect,p1)
#define MBT_AVRCP_Disconnect(p1)    				__ApiLink1(MBT_AVRCP,Disconnect,p1)
#define MBT_AVRCP_SendCmd(p1,p2)   				__ApiLink2(MBT_AVRCP,SendCmd,p1, p2)
#define MBT_AVRCP_GetPlayerValueRes(p1,p2)		__ApiLink2(MBT_AVRCP,GetPlayerValueRes,p1, p2)
#define MBT_AVRCP_GetMediaAttrRes(p1,p2,p3)		__ApiLink3(MBT_AVRCP,GetMediaAttrRes,p1, p2, p3)
#define MBT_AVRCP_GetPlayStatusRes(p1,p2)		__ApiLink2(MBT_AVRCP,GetPlayStatusRes,p1, p2)
#define MBT_AVRCP_RegisterNotiInterimRes(p1,p2)	__ApiLink2(MBT_AVRCP,RegisterNotiInterimRes,p1, p2)
#define MBT_AVRCP_RegisterNotiRes(p1,p2)		__ApiLink2(MBT_AVRCP,RegisterNotiRes,p1, p2)
#endif

#endif//__MBT_AVRCP_H_