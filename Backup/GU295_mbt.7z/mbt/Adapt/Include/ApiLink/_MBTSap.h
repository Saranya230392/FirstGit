#ifndef __MBT_SAP_H_
#define __MBT_SAP_H_
/********************************************************************************
*	File Name	: _MBtSap.h
*	Description	: _MBtSap.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.12.10 		Ahn,ChangSuk		Created
********************************************************************************/

#include "..\..\..\Include\MBTSap.h"

typedef MBT_VOID (*T_pfnMBT_SAP_ServerEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerResAtr) ( T_MBT_SAP_RESULT_CODE Result, MBT_SHORT Length, MBT_BYTE * pAtrRes);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerConnRes) ( T_MBT_BDADDR PeerBDAddr, T_MBT_SAP_CONNECT_STATUS ConnStatus, MBT_SHORT MaxMsgSize, T_MBT_SAP_CARD_STATUS CardStatus);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerResApdu) (T_MBT_SAP_RESULT_CODE Result,MBT_SHORT Length, MBT_BYTE * pApdu);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerResSimOff) (T_MBT_SAP_RESULT_CODE   Result);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerResSimOn) (T_MBT_SAP_RESULT_CODE   Result);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerResResetSim) (T_MBT_SAP_RESULT_CODE   Result);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerResCardReaderStat) (T_MBT_SAP_RESULT_CODE Result, T_MBT_SAP_CARD_READER_STATUS   Status);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerResPrtcl) (T_MBT_SAP_RESULT_CODE   Result);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerSendCardStat) (T_MBT_SAP_CARD_STATUS Status);
typedef MBT_VOID (*T_pfnMBT_SAP_ServerDisconnect) (T_MBT_SAP_DISCONNECT DisconnType);


typedef struct
{
	T_pfnMBT_SAP_ServerEnable				pfnServerEnable;
	T_pfnMBT_SAP_ServerDisable				pfnServerDisable;
	T_pfnMBT_SAP_ServerResAtr				pfnServerResAtr;
	T_pfnMBT_SAP_ServerConnRes				pfnServerConnRes;
	T_pfnMBT_SAP_ServerResApdu				pfnServerResApdu;	
	T_pfnMBT_SAP_ServerResSimOff				pfnServerResSimOff;
	T_pfnMBT_SAP_ServerResSimOn				pfnServerResSimOn;
	T_pfnMBT_SAP_ServerResResetSim			pfnServerResResetSim;
	T_pfnMBT_SAP_ServerResCardReaderStat		pfnServerResCardReaderStat	;
	T_pfnMBT_SAP_ServerResPrtcl				pfnServerResPrtcl;
	T_pfnMBT_SAP_ServerSendCardStat			pfnServerSendCardStat;
	T_pfnMBT_SAP_ServerDisconnect				pfnServerDisconnect;
}TApiGrp_MBT_SAP;

#ifndef BNS_MAIN_VERSION
#define	MBT_SAP_ServerEnable()						__ApiLink0(MBT_SAP,ServerEnable)
#define	MBT_SAP_ServerDisable()					__ApiLink0(MBT_SAP,ServerDisable)
#define	MBT_SAP_ServerResAtr(p1,p2,p3)				__ApiLink3(MBT_SAP,ServerResAtr,p1,p2,p3)
#define	MBT_SAP_ServerConnRes(p1,p2,p3,p4)		__ApiLink4(MBT_SAP,ServerConnRes,p1,p2,p3,p4)
#define	MBT_SAP_ServerResApdu(p1,p2,p3)			__ApiLink3(MBT_SAP,ServerResApdu,p1,p2,p3)
#define	MBT_SAP_ServerResSimOff(p1)				__ApiLink1(MBT_SAP,ServerResSimOff,p1)
#define	MBT_SAP_ServerResSimOn(p1)				__ApiLink1(MBT_SAP,ServerResSimOn,p1)
#define	MBT_SAP_ServerResResetSim(p1)				__ApiLink1(MBT_SAP,ServerResResetSim,p1)
#define	MBT_SAP_ServerResCardReaderStat(p1,p2)	__ApiLink2(MBT_SAP,ServerResCardReaderStat,p1,p2)
#define	MBT_SAP_ServerResPrtcl(p1)					__ApiLink1(MBT_SAP,ServerResPrtcl,p1)
#define	MBT_SAP_ServerSendCardStat(p1)			__ApiLink1(MBT_SAP,ServerSendCardStat,p1)
#define	MBT_SAP_ServerDisconnect(p1)				__ApiLink1(MBT_SAP,ServerDisconnect,p1)
#endif

   
#endif //__MBT_SAP_H_

