#ifndef	__MBT_DUN_H_
#define __MBT_DUN_H_
#include "..\..\..\Include\MBTDun.h"

typedef MBT_VOID	(*T_pfnMBT_DUN_Enable) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_DUN_Disable) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_DUN_Disconnect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID	(*T_pfnMBT_DUN_Listen) (MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_DUN_ListenStop) (MBT_VOID);


typedef struct
{
	T_pfnMBT_DUN_Enable				pfnEnable;
	T_pfnMBT_DUN_Disable			pfnDisable;
	T_pfnMBT_DUN_Disconnect			pfnDisconnect;
	T_pfnMBT_DUN_Listen				pfnListen;
	T_pfnMBT_DUN_ListenStop			pfnListenStop;
} TApiGrp_MBT_DUN;

#ifndef		BNS_MAIN_VERSION
#define MBT_DUN_Enable()		__ApiLink0(MBT_DUN,Enable)
#define MBT_DUN_Disable()		__ApiLink0(MBT_DUN,Disable)
#define MBT_DUN_Disconnect(p1)	__ApiLink1(MBT_DUN,Disconnect,p1)
#define MBT_DUN_Listen()		__ApiLink0(MBT_DUN,Listen)
#define MBT_DUN_ListenStop()	__ApiLink0(MBT_DUN,ListenStop)
#endif

#endif//__MBT_DUN_H_
