#ifndef __MBT_BPP_H_
#define __MBT_BPP_H_
/********************************************************************************
*	File Name	: _MBtBpp.h
*	Description	: _MBtBpp.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.11.05	Lee,ChangHoon		Created
********************************************************************************/

#include "..\..\..\Include\MBTBpp.h"

typedef MBT_VOID (*T_pfnMBT_BPP_Enable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_BPP_Disable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_BPP_AuthRes) (T_MBT_OBEX_AUTH *auth_reply);
typedef MBT_VOID (*T_pfnMBT_BPP_GetPrinterAttribute)(T_MBT_BDADDR BdAddr, MBT_INT PrinterAttr);
typedef MBT_VOID (*T_pfnMBT_BPP_Print) (T_MBT_BDADDR BdAddr, T_MBT_BPP_OBJECT *MBTObject);
typedef MBT_VOID (*T_pfnMBT_BPP_Disconnect) (MBT_VOID);

typedef struct
{
	T_pfnMBT_BPP_Enable				pfnEnable;
	T_pfnMBT_BPP_Disable				pfnDisable;
	T_pfnMBT_BPP_AuthRes				pfnAuthRes;	
	T_pfnMBT_BPP_GetPrinterAttribute	pfnGetPrinterAttribute;
	T_pfnMBT_BPP_Print				pfnPrint;
	T_pfnMBT_BPP_Disconnect			pfnDisconnect;
}TApiGrp_MBT_BPP;


#ifndef BNS_MAIN_VERSION
#define  MBT_BPP_Enable()					__ApiLink0(MBT_BPP,Enable)
#define  MBT_BPP_Disable()					__ApiLink0(MBT_BPP,Disable)
#define  MBT_BPP_AuthRes(p1)				__ApiLink1(MBT_BPP,AuthRes,p1)
#define  MBT_BPP_GetPrinterAttribute(p1,p2)	__ApiLink2(MBT_BPP,GetPrinterAttribute,p1,p2)
#define  MBT_BPP_Print(p1,p2)					__ApiLink2(MBT_BPP,Print,p1,p2)
#define  MBT_BPP_Disconnect()				__ApiLink0(MBT_BPP,Disconnect)
#endif

#endif //__MBT_BPP_H_