#ifndef __MBT_OPP_H_
#define __MBT_OPP_H_

#include "..\..\..\Include\MBTOpp.h"

typedef MBT_VOID (*T_pfnMBT_OPP_ServerEnable)(MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_OPP_ServerDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_OPP_ServerDisconnect) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_OPP_ServerAccessRsp) (T_MBT_AUTHRES Reply);
typedef MBT_VOID (*T_pfnMBT_OPP_ClientEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_OPP_ClientDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_OPP_ClientPushObject) (T_MBT_BDADDR remoteDev,T_MBT_OPP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_OPP_ClientPullObject) (T_MBT_BDADDR remoteDev,T_MBT_OPP_OBJECT * MBTObject);
typedef MBT_VOID (*T_pfnMBT_OPP_ClientExchObject)(T_MBT_BDADDR remoteDev,T_MBT_OPP_OBJECT * Sendbject,T_MBT_OPP_OBJECT * Recvbject);
typedef MBT_VOID (*T_pfnMBT_OPP_ClientDisconnect) (MBT_VOID);

typedef struct
{
	T_pfnMBT_OPP_ServerEnable		pfnServerEnable;
	T_pfnMBT_OPP_ServerDisable		pfnServerDisable;
	T_pfnMBT_OPP_ServerDisconnect		pfnServerDisconnect;
	T_pfnMBT_OPP_ServerAccessRsp		pfnServerAccessRsp;
	T_pfnMBT_OPP_ClientEnable			pfnClientEnable;
	T_pfnMBT_OPP_ClientDisable		pfnClientDisable;
	T_pfnMBT_OPP_ClientPushObject		pfnClientPushObject;
	T_pfnMBT_OPP_ClientPullObject		pfnClientPullObject;
	T_pfnMBT_OPP_ClientExchObject		pfnClientExchObject;
	T_pfnMBT_OPP_ClientDisconnect		pfnClientDisconnect;

}TApiGrp_MBT_OPP;


#ifndef BNS_MAIN_VERSION

#define MBT_OPP_ServerEnable()				__ApiLink0(MBT_OPP,ServerEnable)
#define MBT_OPP_ServerDisable()				__ApiLink0(MBT_OPP,ServerDisable)
#define MBT_OPP_ServerDisconnect()			__ApiLink0(MBT_OPP,ServerDisconnect)
#define MBT_OPP_ServerAccessRsp(p1)		__ApiLink1(MBT_OPP,ServerAccessRsp,p1)
#define MBT_OPP_ClientEnable()				__ApiLink0(MBT_OPP,ClientEnable)
#define MBT_OPP_ClientDisable()				__ApiLink0(MBT_OPP,ClientDisable)
#define MBT_OPP_ClientPushObject(p1,p2)		__ApiLink2(MBT_OPP,ClientPushObject,p1,p2)
#define MBT_OPP_ClientPullObject(p1,p2)		__ApiLink2(MBT_OPP,ClientPullObject,p1,p2)
#define MBT_OPP_ClientExchObject(p1,p2,p3)		__ApiLink3(MBT_OPP,ClientExchObject,p1,p2,p3)
#define MBT_OPP_ClientDisconnect()			__ApiLink0(MBT_OPP,ClientDisconnect)

#endif

#endif//__MBT_OPP_H_

