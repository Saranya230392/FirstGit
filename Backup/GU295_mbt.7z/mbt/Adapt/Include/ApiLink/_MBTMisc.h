#ifndef	__MBT_MISC_H_
#define __MBT_MISC_H_
/********************************************************************************
*	File Name	: _MBTMisc.h
*	Description	: _MBTMisc.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.12.12		Lee,ChoonSik		Created
********************************************************************************/
#include "..\..\..\Include\MBTMisc.h"

typedef MBT_VOID	(*T_pfnMBT_MISC_DUTEnable)			(MBT_INT value);
typedef MBT_VOID	(*T_pfnMBT_MISC_DUTDisable)			(MBT_VOID);
typedef MBT_VOID	(*T_pfnMBT_MISC_SetFCCMode)			(T_MBT_BDADDR testMyAddr, T_MBT_TEST_MODE mode);
typedef MBT_SHORT	(*T_pfnMBT_MISC_LangUtf8ToLocal)	(MBT_CHAR *utf8_str, MBT_SHORT utf8_len, MBT_CHAR *local_str, MBT_SHORT buf_len, MBT_SHORT subst_char);
typedef MBT_BOOL	(*T_pfnMBT_MISC_GetVersion)			(MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_MISC_FactoryTestMode)	(T_MBT_BDADDR testMyAddr);
typedef MBT_BOOL	(*T_pfnMBT_MISC_GetLocalInfo)		(MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_MISC_RadioOn)			(MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_MISC_RadioOff)			(MBT_VOID);
typedef MBT_BOOL	(*T_pfnMBT_MISC_SetSspDebebugMode)	(MBT_BOOL);



typedef struct
{
	T_pfnMBT_MISC_DUTEnable			pfnDUTEnable;
	T_pfnMBT_MISC_DUTDisable		pfnDUTDisable;
	T_pfnMBT_MISC_SetFCCMode		pfnSetFCCMode;
	T_pfnMBT_MISC_LangUtf8ToLocal	pfnLangUtf8ToLocal;
	T_pfnMBT_MISC_GetVersion		pfnGetVersion;
	T_pfnMBT_MISC_FactoryTestMode	pfnFactoryTestMode;
	T_pfnMBT_MISC_GetLocalInfo	pfnGetLocalInfo;
	T_pfnMBT_MISC_RadioOn		pfnRadioOn;
	T_pfnMBT_MISC_RadioOff		pfnRadioOff;
	T_pfnMBT_MISC_SetSspDebebugMode	pfnSetSspDebugMode;
} TApiGrp_MBT_MISC;

#ifndef		BNS_MAIN_VERSION
#define MBT_MISC_DUTEnable(p1)							__ApiLink1(MBT_MISC,DUTEnable,p1)
#define MBT_MISC_DUTDisable()							__ApiLink0(MBT_MISC,DUTDisable)
#define MBT_MISC_SetFCCMode(p1, p2)						__ApiLink2(MBT_MISC,SetFCCMode,p1,p2)
#define MBT_MISC_LangUtf8ToLocal(p1, p2, p3, p4, p5)	__ApiLink5(MBT_MISC,LangUtf8ToLocal,p1,p2,p3,p4,p5)
#define MBT_MISC_GetVersion()							__ApiLink0(MBT_MISC,GetVersion)
#define MBT_MISC_FactoryTestMode(p1)					__ApiLink1(MBT_MISC,FactoryTestMode,p1)
#define MBT_MISC_GetLocalInfo()							__ApiLink0(MBT_MISC,GetLocalInfo)
#define MBT_MISC_RadioOn()								__ApiLink0(MBT_MISC,RadioOn)
#define MBT_MISC_RadioOff()								__ApiLink0(MBT_MISC,RadioOff)
#define MBT_MISC_SetSspDebebugMode(p1)					__ApiLink1(MBT_MISC,SetSspDebugMode,p1)
#endif

#endif//__MBT_MISC_H_
