#ifndef __MBT_A2DP_H_
#define __MBT_A2DP_H_
/********************************************************************************
*	File Name	: _MBtA2dp.h
*	Description	: _MBtA2dp.h
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.11.05	Lee,ChangHoon		Created
********************************************************************************/

#include "..\..\..\Include\MBTA2dp.h"

typedef MBT_VOID (*T_pfnMBT_A2DP_SourceEnable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_A2DP_SourceDisable) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_A2DP_SourceConnect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_A2DP_SourceDisconnect) (T_MBT_BDADDR BdAddr);
typedef MBT_VOID (*T_pfnMBT_A2DP_SourceStart) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_A2DP_SourceStop) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_A2DP_SourcePause) (MBT_VOID);
typedef MBT_VOID (*T_pfnMBT_A2DP_SourceResume) (MBT_VOID);

typedef struct
{
	T_pfnMBT_A2DP_SourceEnable			pfnSourceEnable;
	T_pfnMBT_A2DP_SourceDisable			pfnSourceDisable;
	T_pfnMBT_A2DP_SourceConnect			pfnSourceConnect;
	T_pfnMBT_A2DP_SourceDisconnect		pfnSourceDisconnect;
	T_pfnMBT_A2DP_SourceStart			pfnSourceStart;
	T_pfnMBT_A2DP_SourceStop			pfnSourceStop;
	T_pfnMBT_A2DP_SourcePause			pfnSourcePause;
	T_pfnMBT_A2DP_SourceResume			pfnSourceResume;    
}TApiGrp_MBT_A2DP;

#ifndef BNS_MAIN_VERSION
#define MBT_A2DP_SourceEnable()         __ApiLink0(MBT_A2DP,SourceEnable)
#define MBT_A2DP_SourceDisable()        __ApiLink0(MBT_A2DP,SourceDisable)
#define MBT_A2DP_SourceConnect(p1)              __ApiLink1(MBT_A2DP,SourceConnect,p1)
#define MBT_A2DP_SourceDisconnect(p1)           __ApiLink1(MBT_A2DP,SourceDisconnect,p1)
#define MBT_A2DP_SourceStart()          __ApiLink0(MBT_A2DP,SourceStart)
#define MBT_A2DP_SourceStop()           __ApiLink0(MBT_A2DP,SourceStop)
#define MBT_A2DP_SourcePause()          __ApiLink0(MBT_A2DP,SourcePause)
#define MBT_A2DP_SourceResume()         __ApiLink0(MBT_A2DP,SourceResume)
#endif

#endif//_MBT_A2DP_H_
