#include "mbt_evhandler.h"
#include "MBTSdc.h"
#include "mbt_sdc.h"

#ifndef BNS_EMULATOR		//V [WISE �ӽ� ����, Emulator Compile Error! / by heyviolet]
#include "keypad.h"
#endif

/********************************************************************************
*	Description: 
********************************************************************************/
MBT_BOOL mbt_postevent(T_MBTEVT Evt, MBT_SHORT conn_idx)
{
	//System�� Platform�� �°� Event post �� �� �ֵ��� ���� �� ��.
	
#ifdef MBT_EMULATOR
	extern BOOL EvHandler_PostEvent(T_HANDLE hDst, T_EVENT EventType, T_PARAM wParam, T_PARAM lParam);
	unsigned short* T_MBTEVT_tostring(T_MBTEVT v);
	MBT_EVENT("���� POST EVENT NO : %s",T_MBTEVT_tostring(Evt));
	return EvHandler_PostEvent(MBT_NULL,LGOEM_EVT_BT,Evt,(T_PARAM)conn_idx);
#else

	#if MBT_TARGET_PLATFORM == WISE_PLATFORM
		extern boolean pdk_post_event(void *hDst, unsigned long EventType, unsigned long wParam, void* lParam);
		lgoem_cmd_type* 		ui_cmd_ptr;
		MBT_EVENT("MBT Post Event : %d",Evt);
		if(conn_idx != 0x00 )
		{
			if((ui_cmd_ptr = (lgoem_cmd_type*)lgoem_alloc_cmdbuf_die_if_fail(LGOEM_EVT_BT)) == NULL)
			{
				MBT_EVENT("No UI cmd buffers",0);
				return MBT_FALSE;
			}
			ui_cmd_ptr->bt_event.rsp_cnt = conn_idx;
			return pdk_post_event(MBT_NULL, LGOEM_EVT_BT, Evt, ui_cmd_ptr);
		}
		else
		{
#if 0
			return pdk_post_event(MBT_NULL, LGOEM_EVT_BT, Evt, MBT_NULL);
#else			
			//[LGE_UPDATE_S] kook - AVRCP key event 
			switch(Evt)
			{
				case MBTEVT_AG_CALL_DTMF:
					{
						T_MBT_AG_DTMF *sdcAgDtmfType = mbt_sdc_getrecord(MBTSDC_REC_AG_DTMF_TYPE);
						if(sdcAgDtmfType->Digit == 0x23)
							sdcAgDtmfType->Digit = HS_POUND_K;
						// UI�� DTMF key ���� �÷��ش�.
						KEYPAD_PASS_KEY_CODE((hs_key_type)sdcAgDtmfType->Digit, HS_NONE_K);
						KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, (hs_key_type)sdcAgDtmfType->Digit);
					}
					break;
					
				case MBTEVT_AVRCP_OP_PLAY_KEY_PRESSED: 
					KEYPAD_PASS_KEY_CODE(HS_BT_AV_PLAY_K, HS_NONE_K);
					KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_PLAY_K);
					break;
				case MBTEVT_AVRCP_OP_PLAY_KEY_RELEASED:					
					break;
				case MBTEVT_AVRCP_OP_STOP_KEY_PRESSED:
					KEYPAD_PASS_KEY_CODE(HS_BT_AV_STOP_K, HS_NONE_K);
					KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_STOP_K);
					break;
				case MBTEVT_AVRCP_OP_STOP_KEY_RELEASED:					
					break;
				case MBTEVT_AVRCP_OP_PAUSE_KEY_PRESSED:
					KEYPAD_PASS_KEY_CODE(HS_BT_AV_PAUSE_K, HS_NONE_K);
					KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_PAUSE_K);
					break;
				case MBTEVT_AVRCP_OP_PAUSE_KEY_RELEASED:
					break;
				case MBTEVT_AVRCP_OP_FORWARD_KEY_PRESSED: 
					KEYPAD_PASS_KEY_CODE(HS_BT_AV_FORWARD_K, HS_NONE_K);
					break;
				case MBTEVT_AVRCP_OP_FORWARD_KEY_RELEASED:
					KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_FORWARD_K);
					break;
				case MBTEVT_AVRCP_OP_BACKWARD_KEY_PRESSED: 
					KEYPAD_PASS_KEY_CODE(HS_BT_AV_BACKWARD_K, HS_NONE_K);
					break;
				case MBTEVT_AVRCP_OP_BACKWARD_KEY_RELEASED:
					KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_BACKWARD_K);
					break;
				case MBTEVT_AVRCP_OP_FASTFORWARD_KEY_PRESSED: 
					KEYPAD_PASS_KEY_CODE(HS_BT_AV_FF_K, HS_NONE_K);
					break;
				case MBTEVT_AVRCP_OP_FASTFORWARD_KEY_RELEASED: 
					KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_FF_K);
					break;
				case MBTEVT_AVRCP_OP_REWIND_KEY_PRESSED: 
					KEYPAD_PASS_KEY_CODE(HS_BT_AV_RW_K, HS_NONE_K);
					break;
				case MBTEVT_AVRCP_OP_REWIND_KEY_RELEASED: 
					KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_RW_K);
					break;
				case MBTEVT_AVRCP_OP_VOLUME_UP_KEY_PRESSED:
					break;
				case MBTEVT_AVRCP_OP_VOLUME_UP_KEY_RELEASED:
					break;
				case MBTEVT_AVRCP_OP_VOLUME_DOWN_KEY_PRESSED:
					break;
				case MBTEVT_AVRCP_OP_VOLUME_DOWN_KEY_RELEASED:
					break;
				case MBTEVT_AG_HS_BUTTON_PRESSED:
					KEYPAD_PASS_KEY_CODE(HS_BT_HOOK_K, HS_NONE_K);
					KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_HOOK_K);
					break;				
				default:
					return pdk_post_event(MBT_NULL, LGOEM_EVT_BT, Evt, MBT_NULL);
			}
#endif
			//[LGE_UPDATE_E] kook
		}
	#endif
	
	#if MBT_TARGET_PLATFORM == ASDP_PLATFORM
		WmEventType event;

		MBT_EVENT("MBT Post Event : %d",Evt);

		event.eType = BT_MBT_EVENT;
		event.data.btMBTEvent.MBTEvent = Evt;
		event.data.btMBTEvent.ConnIdx = conn_idx;
		
		wmSendExtSWEvent(&event, (dword)formGetCurrentFormId()); 
// wmEnqueueSWEvent(&event);		

	#endif	

	return MBT_FALSE;
#endif
}
