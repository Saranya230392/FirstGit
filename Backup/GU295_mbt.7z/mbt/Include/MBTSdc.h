#ifndef _MBT_SDC_H_
#define	_MBT_SDC_H_

#include "MBTType.h"

extern	MBT_VOID*	MBT_SDC_GetRecord(T_MBT_SDC_RECID MBTSDCRecID);
extern	MBT_INT		MBT_SDC_GetValue(T_MBT_SDC_VALID MBTSDCValID);
extern	MBT_VOID	MBT_SDC_InitData(MBT_VOID);

#endif//_MBT_SDC_H_