#ifndef _MBT_PBAP_H_
#define	_MBT_PBAP_H_

#include "MBTType.h"

extern MBT_VOID MBT_PBAP_ServerEnable(MBT_VOID);
extern MBT_VOID MBT_PBAP_ServerDisable(MBT_VOID);
extern MBT_VOID MBT_PBAP_ServerAccessResponse(MBT_BOOL b_allow);
extern MBT_VOID MBT_PBAP_ServerAuthenticate(MBT_CHAR *p_password, MBT_CHAR *p_userid);
extern MBT_VOID MBT_PBAP_ServerClose(MBT_VOID);
extern MBT_VOID MBT_PBAP_ServerWriteData(T_MBT_PBAP_OP Operation);

#endif//_MBT_PBAP_H_
