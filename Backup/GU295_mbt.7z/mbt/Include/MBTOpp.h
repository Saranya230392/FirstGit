#ifndef _MBT_OPP_H_
#define	_MBT_OPP_H_

#include "MBTType.h"

extern MBT_VOID MBT_OPP_ServerEnable(MBT_VOID);
extern MBT_VOID MBT_OPP_ServerDisable(MBT_VOID);
extern MBT_VOID MBT_OPP_ServerDisconnect(MBT_VOID);
extern MBT_VOID MBT_OPP_ServerAccessRsp(T_MBT_AUTHRES Reply);
extern MBT_VOID MBT_OPP_ClientEnable(MBT_VOID);
extern MBT_VOID MBT_OPP_ClientDisable(MBT_VOID);
extern MBT_VOID MBT_OPP_ClientPushObject(T_MBT_BDADDR remoteDev,T_MBT_OPP_OBJECT * MBTObject);
extern MBT_VOID MBT_OPP_ClientPullObject(T_MBT_BDADDR remoteDev,T_MBT_OPP_OBJECT * MBTObject);
extern MBT_VOID MBT_OPP_ClientExchObject(T_MBT_BDADDR remoteDev,T_MBT_OPP_OBJECT * SendObject, T_MBT_OPP_OBJECT * RecvObject);
extern MBT_VOID MBT_OPP_ClientDisconnect(MBT_VOID);

#endif//_MBT_OPP_H_
