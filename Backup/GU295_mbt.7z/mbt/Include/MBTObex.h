#ifndef _MBT_OBEX_H_
#define	_MBT_OBEX_H_

#include "MBTType.h"

/**********************************************************************
//	MBT_BYTE				scn				: Service handle
//
//	Return		: Service handle
//	Comment	: scn(arg 1) == T_MBT_OBEX_STATUS->scn
**********************************************************************/
//extern MBT_UINT MBT_OBEX_ServiceRegister(MBT_BYTE scn);

/**********************************************************************
//	MBT_UINT 				SvcHandle		: Service handle
//
//	Return		: Deregist Success or not
**********************************************************************/
//extern MBT_BOOL MBT_OBEX_ServiceDeregister(MBT_UINT SvcHandle);

/**********************************************************************
//	MBT_CHAR*				target			: Type of server(Optional)
//	MBT_BOOL				Authc			: Authentication activate or not
//	T_MBT_OBEX_CHARSET		realm_charset		: Character set of realm name
//	MBT_CHAR*				realm			: Realm name
//	MBT_BYTE				realm_len		: Realm name length
//
//	Comment	: T_MBT_OBEX_STATUS->sdc value MUST be updated
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerEnable(T_MBT_OBEX_SERVICE_INFO* SvcInfo, MBT_BYTE* target, MBT_BOOL Authc, T_MBT_OBEX_CHARSET realm_charset, MBT_CHAR* realm, MBT_BYTE realm_len);

/**********************************************************************
//	MBT_UINT 				ServerHandle		: Server handle
//
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerDisable(MBT_UINT ServerHandle);

/**********************************************************************
//	MBT_UINT 				ServerHandle		: Server handle
//	T_MBT_OBEX_RESPONSE	connect_res		: Connect Req response data type
//
//	Return		: n/a
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerConnectRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE connect_res);

/**********************************************************************
//	MBT_UINT 				ServerHandle		: Server handle
//	T_MBT_OBEX_RESPONSE	disconnect_res	: Disconnect Req response data type
//
//	Return		: n/a
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerDisconnectRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE disconnect_res);

/**********************************************************************
//	MBT_UINT 				ServerHandle		: Server handle
//	MBT_CHAR*				PassWD			: Password
//	MBT_BYTE				PassLen			: Password Length
//	MBT_CHAR*				UserID			: User ID
//	MBT_BYTE				IDLen			: User ID Length
//
//	Return		: n/a
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerAuthenticateRes(MBT_UINT ServerHandle, MBT_CHAR* PassWD, MBT_BYTE PassLen, MBT_CHAR* UserID, MBT_BYTE IDLen);

/**********************************************************************
//	MBT_UINT 				ServerHandle		: Server handle
//	T_MBT_OBEX_RESPONSE	setpath_res		: Setpath Req response data type
//
//	Return		: n/a
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerSetPathRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE setpath_res);

/**********************************************************************
//	MBT_UINT 				ServerHandle		: Server handle
//	T_MBT_OBEX_RESPONSE	put_res			: Put Req response data type
//
//	Return		: n/a
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerPutRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE put_res);

/**********************************************************************
//	MBT_UINT 				ServerHandle		: Server handle
//	T_MBT_OBEX_RESPONSE	get_res			: Get Req response data type
//
//	Return		: n/a
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerGetRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE get_res);

/**********************************************************************
//	MBT_UINT 				ServerHandle		: Server handle
//	T_MBT_OBEX_RESPONSE	abort_res			: Abort Req response data type
//
//	Return		: n/a
**********************************************************************/
extern MBT_VOID MBT_OBEX_ServerAbortRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE abort_res);

#endif//_MBT_OBEX_H_
