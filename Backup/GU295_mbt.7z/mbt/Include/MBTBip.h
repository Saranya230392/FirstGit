#ifndef _MBT_BIP_H_
#define	_MBT_BIP_H_

#include "MBTType.h"

extern MBT_VOID MBT_BIP_InitiatorEnable(MBT_VOID);
extern MBT_VOID MBT_BIP_InitiatorDisable(MBT_VOID);
extern MBT_VOID MBT_BIP_InitiatorAuthRsp(T_MBT_OBEX_AUTH *auth_reply);
extern MBT_VOID MBT_BIP_InitiatorGetCapabilityReq(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_BIP_InitiatorPushImage(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBTObject);
extern MBT_VOID MBT_BIP_InitiatorPushThumbnail(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBTObject);
extern MBT_VOID MBT_BIP_InitiatorDisconnect(MBT_VOID);

extern MBT_VOID MBT_BIP_ResponderEnable(MBT_VOID);
extern MBT_VOID MBT_BIP_ResponderDisable(MBT_VOID);
extern MBT_VOID MBT_BIP_ResponderAuthRsp(T_MBT_OBEX_AUTH *auth_reply);
extern MBT_VOID MBT_BIP_ResponderAccessRsp(T_MBT_AUTHRES Reply);
extern MBT_VOID MBT_BIP_ResponderGetCapabilityResp(T_MBT_AUTHRES Reply, T_MBT_BIP_IMAGING_CAPABILITY *ImagingCapability);
extern MBT_VOID MBT_BIP_ResponderDisconnect(MBT_VOID);

#endif//_MBT_BIP_H_
