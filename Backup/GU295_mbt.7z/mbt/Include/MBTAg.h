#ifndef _MBT_AG_H_
#define	_MBT_AG_H_

#include "MBTType.h"

extern MBT_VOID	MBT_AG_Enable(MBT_VOID);
extern MBT_VOID	MBT_AG_Disable(MBT_VOID);
extern MBT_VOID	MBT_AG_Connect(T_MBT_BDADDR RemoteBDAddr,MBT_SERVICE_ID MBTSvc);
extern MBT_VOID	MBT_AG_Disconnect(T_MBT_BDADDR RemoteBDAddr,MBT_SERVICE_ID MBTSvc);
extern MBT_VOID	MBT_AG_AudioConnect(MBT_VOID);
extern MBT_VOID	MBT_AG_AudioDisconnect(MBT_VOID);
extern MBT_BOOL	MBT_AG_GetConStatus(MBT_VOID);
extern MBT_BOOL	MBT_AG_GetAudioStatus(MBT_VOID);
extern MBT_VOID	MBT_AG_SetConnectable(MBT_BOOL connectable);
extern MBT_VOID	MBT_AG_SetAudioPath(MBT_BOOL audiopath);
extern MBT_VOID	MBT_AG_SetSpkVolume(MBT_BYTE Level);
extern MBT_VOID 	MBT_AG_SetMicVolume(MBT_BYTE Level);
extern MBT_VOID     MBT_AG_CallStateChange(T_MBT_AG_PHONE_CALLSTATE NewState);
extern MBT_VOID MBT_AG_SetCallStatus(T_MBT_AG_CALLSTATUS CurrentStatus);
extern MBT_VOID MBT_AG_SetCallSetup(T_MBT_AG_CALLSETUP CurrentCallSetup);
extern MBT_VOID	MBT_AG_SetNetworkStatus(T_MBT_AG_NETSTATE State);
extern MBT_VOID	MBT_AG_SetCID(MBT_CHAR* Num,MBT_BYTE len);
extern MBT_BOOL MBT_AG_SetSignalStrength(MBT_BYTE Level);
extern MBT_BOOL MBT_AG_SetRoamingStatus(MBT_BYTE Level);
extern MBT_BOOL MBT_AG_SetBatteryLevel(MBT_BYTE Level);
extern MBT_BOOL MBT_AG_SetCallHeldStatus(T_MBT_AG_CALL_HELD value);
extern MBT_BOOL MBT_AG_SetOperatorSelection(T_MBT_AG_NETMODE Netmode,MBT_BYTE* OpName);
extern MBT_BOOL MBT_AG_SetExtendedError(T_MBT_AG_CME_ERR ErrorCode);
extern MBT_BOOL MBT_AG_SetSubscriberNumber(MBT_CHAR* Num, MBT_BYTE NumType, MBT_BYTE Len, T_MBT_AG_SERVICE Service,MBT_BOOL FinalFlag);
extern MBT_BOOL MBT_AG_SetCallWaiting(MBT_CHAR* Num,MBT_BYTE Len);
extern MBT_VOID MBT_AG_SendResponse(MBT_BOOL Response);
extern MBT_BOOL MBT_AG_SetCIND(T_MBT_AG_NETSTATE Net, T_MBT_AG_CALLSTATUS CallState, T_MBT_AG_CALLSETUP SetupState, MBT_BYTE SignalLevel, MBT_BYTE RoamingStatus, MBT_BYTE BatteryLevel,T_MBT_AG_CALL_HELD value);
extern MBT_BOOL MBT_AG_SetCurrentCallList(MBT_BYTE Idx, T_MBT_AG_CL_DIR Dir, T_MBT_AG_CL_STATUS Status,T_MBT_AG_CL_MODE Mode,T_MBT_AG_CL_MPTY Mprty,MBT_CHAR* Num,MBT_BYTE NumType,MBT_BYTE Len,MBT_BOOL FinalFlag);
extern MBT_VOID	MBT_AG_StartVR(MBT_VOID);
extern MBT_VOID	MBT_AG_StopVR(MBT_VOID);
extern MBT_VOID MBT_AG_SendSupportedPBList(T_MBT_AG_PB_CPBS supportedPbList);
extern MBT_VOID MBT_AG_SendSelectedPBInfo(T_MBT_AG_PB_RETURN result, MBT_SHORT usedRecs, MBT_SHORT totalRecs);
extern MBT_VOID MBT_AG_SendPBSelectResult( T_MBT_AG_PB_RETURN result );
extern MBT_VOID MBT_AG_SendPBEntriesInfo(T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt);
extern MBT_VOID MBT_AG_SendPBReadResult(T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec, MBT_BOOL finalEntry);
extern MBT_VOID MBT_AG_SendPBFindEntriesInfo(T_MBT_AG_PB_RETURN result, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt);
extern MBT_VOID MBT_AG_SendPBFindResult(T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec, MBT_BOOL finalEntry);
extern MBT_VOID MBT_AG_SendPBWriteInfo(T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxlenNum, MBT_SHORT typeStart, MBT_SHORT typeEnd, MBT_SHORT maxlenTxt);
extern MBT_VOID MBT_AG_SendPBWriteResult( T_MBT_AG_PB_RETURN result );
extern MBT_VOID MBT_AG_SetCGM(MBT_CHAR* manufacturerid, MBT_CHAR* modelid);
extern MBT_VOID MBT_AG_RingStart(MBT_VOID);
extern MBT_VOID MBT_AG_RingStop(MBT_VOID);
extern MBT_VOID MBT_AG_SetCSCS(T_MBT_AG_CSCS* AgCSList);
#endif//_MBT_AG_H_
