#ifndef _MBT_SAP_H_
#define	_MBT_SAP_H_

#include "MBTType.h"

extern MBT_VOID MBT_SAP_ServerEnable (MBT_VOID);
extern MBT_VOID MBT_SAP_ServerDisable (MBT_VOID);
extern MBT_VOID MBT_SAP_ServerResAtr( T_MBT_SAP_RESULT_CODE  Result, MBT_SHORT Length, MBT_BYTE *  pAtr);
extern MBT_VOID MBT_SAP_ServerConnRes( T_MBT_BDADDR PeerBDAddr,  T_MBT_SAP_CONNECT_STATUS ConnStatus,MBT_SHORT MaxMsgSize, T_MBT_SAP_CARD_STATUS CardStatus);
extern MBT_VOID MBT_SAP_ServerResApdu(T_MBT_SAP_RESULT_CODE	Result, MBT_SHORT Length, MBT_BYTE *  pApdu);
extern MBT_VOID MBT_SAP_ServerResSimOff(T_MBT_SAP_RESULT_CODE   Result);
extern MBT_VOID MBT_SAP_ServerResSimOn(T_MBT_SAP_RESULT_CODE   Result);
extern MBT_VOID MBT_SAP_ServerResResetSim(T_MBT_SAP_RESULT_CODE   Result);
extern MBT_VOID MBT_SAP_ServerResCardReaderStat(T_MBT_SAP_RESULT_CODE  Result, T_MBT_SAP_CARD_READER_STATUS  Status);
extern MBT_VOID MBT_SAP_ServerResPrtcl(T_MBT_SAP_RESULT_CODE   Result);
extern MBT_VOID MBT_SAP_ServerSendCardStat (T_MBT_SAP_CARD_STATUS Status);
extern MBT_VOID MBT_SAP_ServerDisconnect (T_MBT_SAP_DISCONNECT DisconnType);

#endif//_MBT_SAP_H_
