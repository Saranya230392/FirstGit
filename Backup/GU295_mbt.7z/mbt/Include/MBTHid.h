#ifndef _MBT_HID_H_
#define	_MBT_HID_H_

#include "MBTType.h"

extern MBT_VOID MBT_HID_HostEnable(FP_MBT_HID_RX_REPORT_CO fpRxRptCO);
extern MBT_VOID MBT_HID_HostDisable(MBT_VOID);
extern MBT_VOID MBT_HID_HostConnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_HID_HostDisconnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_HID_HostAddDevice(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_HID_HostRemoveDevice(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_HID_HostGetDescInfo(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_HID_HostSetLED(T_MBT_BDADDR BdAddr, T_MBT_HID_LED_MASK led);
extern MBT_VOID MBT_HID_HostSendLED(T_MBT_BDADDR BdAddr, T_MBT_HID_LED_MASK led);
extern MBT_VOID MBT_HID_HostSendControl(T_MBT_BDADDR BdAddr, T_MBT_HID_CONTROL control);
extern MBT_VOID MBT_HID_HostSendReport(T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
extern MBT_VOID MBT_HID_HostSetReport(T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
extern MBT_VOID MBT_HID_HostGetReport(T_MBT_BDADDR BdAddr, MBT_BYTE rpt_type, MBT_BYTE rpt_id);
extern MBT_VOID MBT_HID_HostGetIdle(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_HID_HostSetIdle(T_MBT_BDADDR BdAddr, MBT_BYTE idle);
extern MBT_VOID MBT_HID_HostGetProtocol(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_HID_HostSetProtocol(T_MBT_BDADDR BdAddr, MBT_BOOL boot_mode);

extern MBT_VOID MBT_HID_DeviceEnable(MBT_VOID);
extern MBT_VOID MBT_HID_DeviceDisable(MBT_VOID);
extern MBT_VOID MBT_HID_DeviceConnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_HID_DeviceDisconnect(MBT_VOID);
extern MBT_VOID MBT_HID_DeviceSendUnplug(MBT_VOID);
extern MBT_VOID MBT_HID_DeviceSendReport(T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
extern MBT_VOID MBT_HID_DeviceSendKeyboardRpt(T_MBT_HID_MODIFIER_MASK modifier, T_MBT_HID_KEY_TYPE *keycodes, MBT_BYTE key_num);
extern MBT_VOID MBT_HID_DeviceSendMouseRpt(T_MBT_HID_MOUSE_BUTTON_MASK button, MBT_BYTE move_x, MBT_BYTE move_y);
extern MBT_VOID MBT_HID_DeviceChangeKeyboardRole(MBT_VOID);
extern MBT_VOID MBT_HID_DeviceChangeMouseRole(MBT_VOID);
extern MBT_VOID MBT_HID_DeviceChangePhoneRole(MBT_VOID);

#endif//_MBT_HID_H_
