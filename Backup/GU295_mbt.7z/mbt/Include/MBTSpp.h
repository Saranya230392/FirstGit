#ifndef _MBT_SPP_H_
#define	_MBT_SPP_H_

#include "MBTType.h"

extern MBT_VOID MBT_SPP_Enable (MBT_VOID);
extern MBT_VOID MBT_SPP_Listen (MBT_VOID);
extern MBT_VOID MBT_SPP_Disable (MBT_VOID);
extern MBT_VOID MBT_SPP_ListenStop (MBT_VOID);
extern MBT_VOID MBT_SPP_Connect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_SPP_Disconnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_SPP_SendData(T_MBT_SPP_DATA *txData);

#endif//_MBT_SPP_H_
