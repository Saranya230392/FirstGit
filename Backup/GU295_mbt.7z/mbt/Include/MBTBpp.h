#ifndef _MBT_BPP_H_
#define	_MBT_BPP_H_

#include "MBTType.h"

extern MBT_VOID MBT_BPP_Enable(MBT_VOID);
extern MBT_VOID MBT_BPP_Disable(MBT_VOID);
extern MBT_VOID MBT_BPP_AuthRes(T_MBT_OBEX_AUTH *auth_reply);
extern MBT_VOID MBT_BPP_GetPrinterAttribute(T_MBT_BDADDR BdAddr, MBT_INT PrinterAttr);
extern MBT_VOID MBT_BPP_Print(T_MBT_BDADDR BdAddr, T_MBT_BPP_OBJECT *MBTObject);
extern MBT_VOID MBT_BPP_Disconnect(MBT_VOID);

#endif//_MBT_BPP_H_

