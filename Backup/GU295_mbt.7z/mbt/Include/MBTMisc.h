#ifndef _MBT_MISC_H_
#define	_MBT_MISC_H_

#include "MBTType.h"

extern MBT_VOID MBT_MISC_DUTEnable(MBT_INT value);
extern MBT_VOID MBT_MISC_DUTDisable(MBT_VOID);
extern MBT_VOID MBT_MISC_SetFCCMode(T_MBT_BDADDR testMyAddr, T_MBT_TEST_MODE mode);
extern MBT_BOOL MBT_MISC_FactoryTestMode(T_MBT_BDADDR testMyAddr);
extern MBT_SHORT MBT_MISC_LangUtf8ToLocal(MBT_CHAR *utf8_str, MBT_SHORT utf8_len, MBT_CHAR *local_str, MBT_SHORT buf_len, MBT_SHORT subst_char);
extern MBT_BOOL	MBT_MISC_GetVersion(MBT_VOID);
extern MBT_BOOL	MBT_MISC_GetLocalInfo(MBT_VOID);
extern MBT_BOOL	MBT_MISC_RadioOn(MBT_VOID);
extern MBT_BOOL	MBT_MISC_RadioOff(MBT_VOID);
extern MBT_BOOL	MBT_MISC_SetSspDebebugMode(MBT_BOOL bEnable);

#endif//_MBT_MISC_H_
