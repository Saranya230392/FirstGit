#ifndef _MBT_AVRCP_H_
#define	_MBT_AVRCP_H_

#include "MBTType.h"

extern MBT_VOID MBT_AVRCP_Enable(MBT_VOID);
extern MBT_VOID MBT_AVRCP_Disable(MBT_VOID);
extern MBT_VOID MBT_AVRCP_Connect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_AVRCP_Disconnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_AVRCP_SendCmd (T_MBT_BDADDR BdAddr, T_MBT_AVRCP_KEY KeyValue);
extern MBT_VOID MBT_AVRCP_GetPlayerValueRes(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_APP_ATTR* AttrValue);
extern MBT_VOID MBT_AVRCP_GetMediaAttrRes(T_MBT_BDADDR BdAddr, MBT_BYTE AttrNum, T_MBT_AVRCP_MEDIA_ATTR* AttrData );
extern MBT_VOID MBT_AVRCP_GetPlayStatusRes(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_GET_PLAYSTATUS PlayStatus);
extern MBT_VOID MBT_AVRCP_RegisterNotiInterimRes(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti);
extern MBT_VOID MBT_AVRCP_RegisterNotiRes(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti);

#endif//_MBT_AVRCP_H_