#ifndef _MBT_CONFIG_H_
#define	_MBT_CONFIG_H_


/********************************************************************************
*	Description : MBT Version Define
********************************************************************************/
#define MBT_VERSION_STR				"MBT 1.1.1"

/********************************************************************************
*	Description : S/W Platform Define
********************************************************************************/
#define NONE_PLATFORM				0
#define WISE_PLATFORM				1
#define ASDP_PLATFORM  		 		2
#define DOMESTIC_WISE_PLATFORM	3
#define PDK_PLATFORM				4

/********************************************************************************
*	Description : Baseband Chipset Define
********************************************************************************/
#define QUALCOMM			0
#define INFINEON			1
#define ADI			  		2
#define TI 					3
#define MBT_EMULATOR_BB	4

/********************************************************************************
*	Description : Target Configuration.
*                        Choose target platform.
********************************************************************************/
#ifdef MBT_EMULATOR
#define MBT_TARGET_PLATFORM	WISE_PLATFORM
#define MBT_TARGET_BASEBAND	MBT_EMULATOR_BB
#else
#define MBT_TARGET_PLATFORM	WISE_PLATFORM
#define MBT_TARGET_BASEBAND	QUALCOMM
#endif

/********************************************************************************
*	Description : Support profile configuration.
********************************************************************************/
#if defined(MBT_EMULATOR)
	#define MBT_AG			MBT_TRUE
	#define MBT_A2DP		MBT_TRUE
	#define MBT_AVRCP		MBT_TRUE
	#define MBT_OPP			MBT_TRUE
	#define MBT_BPP			MBT_TRUE
	#define MBT_BIP			MBT_TRUE
	#define MBT_FTP			MBT_TRUE
	#define MBT_PBAP		MBT_TRUE
	#define MBT_DUN			MBT_TRUE
	#define MBT_SPP			MBT_TRUE
	#define MBT_HID_HOST	MBT_TRUE
	#define MBT_HID_DEVICE	MBT_TRUE
	#define MBT_JSR82		MBT_TRUE
	#define MBT_SAP			MBT_TRUE
	#define MBT_GAP			MBT_TRUE
	#define MBT_MISC		MBT_TRUE
	#define MBT_VDP			MBT_TRUE
	#define MBT_OBEX		MBT_TRUE
#else
#define MBT_AG					MBT_TRUE
#define MBT_A2DP				MBT_TRUE
#define MBT_AVRCP				MBT_TRUE
#define MBT_OPP					MBT_TRUE
#define MBT_BPP					MBT_TRUE
#define MBT_BIP					MBT_FALSE
#define MBT_FTP					MBT_TRUE
#define MBT_PBAP				MBT_TRUE
#define MBT_DUN					MBT_TRUE
#define MBT_SPP					MBT_TRUE
#define MBT_HID_HOST			MBT_FALSE
#define MBT_HID_DEVICE			MBT_FALSE
#define MBT_JSR82				MBT_TRUE
#define MBT_SAP					MBT_FALSE
	#define MBT_GAP			MBT_TRUE
	#define MBT_MISC		MBT_TRUE
	#define MBT_VDP			MBT_FALSE
	#define MBT_OBEX		MBT_FALSE
#endif

#define JSR82_QBT
/********************************************************************************
*	Description : Bluetooth Environment configure
********************************************************************************/
/*GAP*/
#define	MBT_MAX_NAME_LEN		80	// Bluetooth Device Name Length(Max) 
#define	MBT_MAXNUM_PAIRED_DEV	20	// paired device�� �ִ� ����
#define	MBT_MAXNUM_SEARCH_DEV	20	// searched device�� �ִ� ����
#define	MBT_MAXNUM_SVC_FIELD	12  // service list record�� �ִ� ����
#define	MBT_MAXNUM_BLOCK_DEV	1	// Blocked device �ִ� ����. ������� �������� 1�� ����

/*AG*/
#define	MBT_MAX_DIALNUM_LEN		64   // ��ȭ ��ȣ�� �ִ� ����
#define	MBT_AG_PB_MAXLEN_NUM	32	// AG�� phonebook sync���� number�� �ִ� ����
#define	MBT_AG_PB_MAXLEN_TXT		64	// AG�� phonebook sync���� text�� �ִ� ����
#define	MBT_AG_CGM_LEN			40	// CGMM, CGMI�� �ִ� ����
#define	MBT_AG_CSCS_NUM			1	//CS List�� ����. Length�� 8�� ������

/*OBEX*/
#define	MBT_MAX_FILE_NAME_LEN		768 // File Name �� �ִ� ���� 256 -> 768
#define	MBT_OBEX_AUTH_USERID_LEN	16 // OBEX Auth User ID Length
#define	MBT_OBEX_AUTH_PASSWD_LEN	16 // OBEX Auth Password Length
#define	MBT_OBEX_FILE_BUF_LEN		4096

/*FTP*/
#define	MBT_FTP_VIRTUAL_FOLDER	FALSE
#define	MBT_FTP_MAX_DIR_NUM		10	// FTP diretory�� �ִ� ����

/*BPP/BIP*/
#define	MBT_MAX_DOC_FORMAT_LEN	63
#define	MBT_MAX_MEDIA_SIZE_LEN	31
#define	MBT_MAX_ATTR_VAL_LEN		32
#define	MBT_MAX_NUM_OF_NESTED_ATTR	20
#define	MBT_MAX_MIME_VAL_LEN		64

/*A2DP*/
#define MBT_A2DP_MAX_CONN_NUM   	1   	// Possible conneciton number of A2DP
/*VDP*/
#define MBT_VDP_MAX_CONN_NUM   	1   	// Possible conneciton number of VDP

/*AVRCP*/
#define MBT_AVRCP_MAX_CONN_NUM			1	// possible conneciton number of A2DP
#define MBT_AVRCP_MAX_ATTR_NUM			4	// max number of player application setting attributes
#define MBT_AVRCP_MAX_ATTR_VALUE_NUM	4 	// max number of player application setting attibute value
#define MBT_AVRCP_MAX_LEN_TEXT			255	// max length of text (1~255)
#define MBT_AVRCP_MAX_EVENT_NUM			8	// max number of event supported by TG
#define MBT_AVRCP_MAX_MEDIA_ID			7	// max number of media attibute ID supported by TG

/*PBAP*/
#define	MBT_PBAP_VCARD_HANDLE_LENGTH	64
#define	MBT_PBAP_MAX_NAME_LENGTH	128
#define	MBT_PBAP_MAX_VCARD_NUM		1000
#define	MBT_PBAP_INTERNAL		MBT_TRUE
#define	MBT_PBAP_SIM			MBT_TRUE

/*HID*/
#define	MBT_HID_MAX_DEVICE_NUM	4
#define	MBT_HID_DESC_MAX_SIZE	1024
#define	MBT_HID_REPORT_MAX_SIZE	512
#define	MBT_HID_MAX_DEVICE_NAME_LENGTH	32

/*JSR82*/
#define MBT_JSR82_MAX_EVENT_NUM         10
#define MBT_JSR82_MAX_SEARCH_UUID_NUM   14
#define MBT_JSR82_MAX_ATTR_ID_NUM       12
#define MBT_JSR82_MAX_32_UUID_NUM       1   // 32 uuid�� ����
#define MBT_JSR82_MAX_128_UUID_NUM      1   // 128 uuid�� ����
#define MBT_JSR82_MAX_PROTO_PARAM_NUM   1   // protocol-specific paramters' num
#define MBT_JSR82_MAX_PROTO_DESC_NUM   4   // protocol-specific paramters' num
#define MBT_JSR82_MAX_NUM_OF_ADD_PROTO_LIST_NUM   1
#define MBT_JSR82_MAX_LANG_BASE_REC_NUM 1
#define MBT_JSR82_MAX_PROFILE_NUM       10
#define MBT_JSR82_MAX_STRING_LEN        32
#define MBT_JSR82_MAX_HID_DESC_NUM      3
#define MBT_JSR82_MAX_HID_DESC_STR_LEN  55
#define MBT_JSR82_MAX_UINT					8			//LEECHANGHOON Added 08/04/07

#define AROMA			// JSR82 for AROMA VM

/*SAP*/
#define MBT_SAP_MAX_APDU_LEN		300			// max length of APDU frame
#define MBT_SAP_MAX_ATR_LEN       	300 			// max length of ATR frame
#define MBT_SAP_MAX_MSG_LEN		(MBT_SAP_MAX_APDU_LEN +12) // max length of message
#define MBT_SAP_MIN_MSG_LEN		20			// min length of message

/*SPP*/
#define MBT_SPP_MAX_CONN_NUM        1   // SPP ���� ���� ����

/*OBEX Protocol*/
#define MBT_OBEX_MAX_SERVER_NUM	1	// Possible Server number of OBEX (ex : AAS)

/*MISC*/
#define MBT_MISC_MAX_MBT_VER_STR_LEN	20
#define MBT_MISC_MAX_STACK1_VER_STR_LEN	30
#define MBT_MISC_MAX_STACK2_VER_STR_LEN	50
#define MBT_MISC_FACTORY_DUT_BD_ADDRS	"0005C9000000"

/********************************************************************************
*	Description : Multi connection configure
********************************************************************************/
#define	MBT_MAX_CONNECTION_NUMBER	2	//���� ���� ���� ��ġ ����(���������� �ٸ� ��ġ)

/********************************************************************************
*	Description : Misc. configure
********************************************************************************/
//#define	MBT_TESTMODE_NONV		//�׽�Ʈ �ڵ�. Nv�� �������� ������� �ּ� Ǯ� ���. ���������� �ݵ�� ������ ��.
#define	MBT_DEBUGMSG				//Debug message ��� ����. ������� �������� ������

/********************************************************************************
*	Description : MBT SDK configuration.
********************************************************************************/
//!!���ǻ���!!
//���ķ����� ���� VC���� MBT Project Setting�� Pre-definition��
//MBT_EMULATOR�� ���� �ؾ���. ���� �������� ����.
#ifdef MBT_EMULATOR
	#define LGOEM_EVT_BT	12200
#endif

#define MBT_DUAL_PROFILE

#endif//_MBT_CONFIG_H_
