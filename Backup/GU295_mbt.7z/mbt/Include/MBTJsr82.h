#ifndef _MBT_JSR82_H_
#define _MBT_JSR82_H_

#include "MBTType.h"

extern MBT_VOID MBT_JSR82_LDEnable(MBT_VOID);
extern MBT_VOID MBT_JSR82_LDDisable(MBT_VOID);
extern MBT_UINT MBT_JSR82_LDGetDiscoverable(MBT_VOID);
extern MBT_BOOL MBT_JSR82_LDSetDiscoverable(MBT_UINT Mode);
extern MBT_BOOL MBT_JSR82_LDSetSecurity(MBT_UINT Handle, T_MBT_JSR82_SET_SECURITY* Security);
extern MBT_BOOL MBT_JSR82_LDSetMyCoD(MBT_SHORT ServiceCalss, MBT_BYTE MajorClass, MBT_BYTE MinorClass);
extern MBT_BOOL MBT_JSR82_LDGetMyCoD(MBT_VOID);

extern T_MBT_GAP_SECURITY MBT_JSR82_RDGetEncrypted(T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL MBT_JSR82_RDSetEncrypted(T_MBT_BDADDR RemoteBDAddr,T_MBT_GAP_SECURITY Security);
extern MBT_BOOL MBT_JSR82_RDGetAuthenticated(T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL MBT_JSR82_RDPairReq(MBT_UINT Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq , MBT_BYTE PinLength);
extern MBT_BOOL MBT_JSR82_RDPairRes(MBT_UINT Handle,MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_BYTE PinLength);

extern MBT_BOOL MBT_JSR82_RDNameReq(MBT_UINT Handle, T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL MBT_JSR82_DevDiscovery(MBT_UINT Handle, MBT_UINT AccessMode);
extern MBT_BOOL MBT_JSR82_DevDiscoveryCancel(MBT_UINT Handle);

extern MBT_BOOL MBT_JSR82_PopulateRecord(MBT_UINT SvcHandle,T_MBT_BDADDR RemoteBDAddr,MBT_UINT *Attr,MBT_UINT AttrLength);
extern MBT_BOOL MBT_JSR82_ReadRecord(MBT_UINT SvcHandle, MBT_BYTE* Data, MBT_UINT* DataLength);
extern MBT_BOOL MBT_JSR82_LDIsConnected(T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL MBT_JSR82_SvcDiscovery(T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_SEARCH_SD* SearchInfo, MBT_UINT TransID);
extern MBT_BOOL MBT_JSR82_SvcDiscoveryCancel(MBT_UINT TransID);
extern MBT_BOOL MBT_JSR82_GetServiceResult(MBT_UINT TransID, MBT_INT ReadNum);
extern MBT_VOID MBT_JSR82_CreateRecord(MBT_UINT SvcHandle,T_MBT_JSR82_SD_RECORD* CreateInfo);
extern MBT_INT MBT_JSR82_UpdateRecord(MBT_UINT SvcHandle, T_MBT_JSR82_SD_RECORD* UpdateInfo);
extern MBT_VOID MBT_JSR82_RemoveRecord(MBT_UINT SvcHandle);
extern MBT_VOID MBT_JSR82_DeleteAttribute(MBT_UINT SvcHandle, MBT_SHORT AttrID);

extern MBT_INT MBT_JSR82_L2CAPOpenServer(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config);
extern MBT_INT MBT_JSR82_L2CAPCloseServer(MBT_BYTE Handle);
extern MBT_INT  MBT_JSR82_L2CAPGetServiceHandle(MBT_VOID);
extern MBT_INT MBT_JSR82_L2CAPAccept(MBT_BYTE Handle, MBT_BYTE PeerHandle);
extern MBT_BOOL MBT_JSR82_L2CAPOpenClient(MBT_BYTE Handle);
extern MBT_BOOL MBT_JSR82_L2CAPSetParam(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config);
extern MBT_INT MBT_JSR82_L2CAPConnect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, MBT_INT PSM);
extern MBT_INT MBT_JSR82_L2CAPDisconnect(MBT_BYTE Handle);
extern MBT_INT MBT_JSR82_L2CAPWrite(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
extern MBT_INT MBT_JSR82_L2CAPRead(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
extern MBT_BOOL MBT_JSR82_L2CAPGetReady(MBT_BYTE Handle, MBT_UINT* Length);
extern MBT_VOID MBT_JSR82_L2CAPRelease(MBT_VOID);

extern MBT_INT MBT_JSR82_RFCOMMOpenServer(MBT_BYTE Handle, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config);
extern MBT_INT MBT_JSR82_RFCOMMCloseServer(MBT_BYTE Handle);
extern MBT_INT  MBT_JSR82_RFCOMMGetServiceHandle(MBT_VOID);
extern MBT_INT MBT_JSR82_RFCOMMAccept(MBT_BYTE Handle, MBT_BYTE PeerHandle);
extern MBT_BOOL MBT_JSR82_RFCOMMOpenClient(MBT_BYTE Handle);
extern MBT_INT MBT_JSR82_RFCOMMConnect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config);
extern MBT_INT MBT_JSR82_RFCOMMDisconnect(MBT_BYTE Handle);
extern MBT_INT MBT_JSR82_RFCOMMWrite(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
extern MBT_INT MBT_JSR82_RFCOMMRead(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
extern MBT_BOOL MBT_JSR82_RFCOMMGetReady(MBT_BYTE Handle, MBT_UINT* Length);
extern MBT_VOID MBT_JSR82_RFCOMMRelease(MBT_VOID);

#endif	//_MBT_JSR82_H_
