#ifndef _MBT_EVHANDLER_H_
#define _MBT_EVHANDLER_H_

#include "MBTType.h"
#include "mbt_debugmsg.h"

#ifdef MBT_EMULATOR
	#if MBT_TARGET_PLATFORM == WISE_PLATFORM
		#ifndef		TYPEDEF_T_EVENT
		#define		TYPEDEF_T_EVENT
		typedef		unsigned long				T_EVENT;			//	event
		#endif

		#ifndef		TYPEDEF_T_PARAM
		#define		TYPEDEF_T_PARAM
		typedef		unsigned long				T_PARAM;			//	Parameter
		#endif

		#ifndef		TYPEDEF_T_HANDLE
		#define		TYPEDEF_T_HANDLE
		typedef		void*						T_HANDLE;			//	handle
		#endif

		#ifndef		TYPEDEF_BOOL
		#define		TYPEDEF_BOOL
		typedef		int							BOOL;				//	boolean
		#endif

		#ifndef NULL
		#define		NULL	0
		#endif
	#endif
#else
	#if MBT_TARGET_PLATFORM == WISE_PLATFORM
		#include "..\..\..\..\PAL\PhonePal\Include\PalDef_OemCommon.h"
	#endif
	#if MBT_TARGET_PLATFORM == ASDP_PLATFORM
		#include "wmEvent.h"
	#endif
#endif
extern MBT_BOOL 	mbt_postevent(T_MBTEVT Evt, MBT_SHORT conn_idx);

#endif//_MBT_EVHANDLER_H_