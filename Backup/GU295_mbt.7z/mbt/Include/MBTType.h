#ifndef _MBT_TYPE_H_
#define	_MBT_TYPE_H_

#include "MBTConfig.h"
#include "MBTDataType.h"
#include "mbt_sdc_id.h"
#include "MBTEvent.h"

/********************************************************************************
* 							DEFINITION
********************************************************************************/

/*******************GAP*******************/
#define	MBT_BDADDR_LEN			6	// DO NOT CHANGE(Spec)!! Bluetooth Address Length(Fixed)
#define	MBT_PIN_LEN				16	// DO NOT CHANGE(Spec)!! Bluetooth PIN Code Length(Max)
#define	MBT_LINKKEY_LEN			16	// DO NOT CHANGE(Spec)!! Bluetooth LinkKey Length(Max)
typedef	MBT_BYTE T_MBT_BDADDR[MBT_BDADDR_LEN];	// BD_ADDR
typedef	MBT_BYTE T_MBT_PIN[MBT_PIN_LEN];  			// PIN code
typedef	MBT_BYTE T_MBT_LINKKEY[MBT_LINKKEY_LEN];	// Link Key

/***************************
** major device class field
****************************/
#define MBT_COD_MAJOR_MISCELLANEOUS	0x00
#define MBT_COD_MAJOR_COMPUTER		0x01
#define MBT_COD_MAJOR_PHONE			0x02
#define MBT_COD_MAJOR_LAN_ACCESS_PT	0x03
#define MBT_COD_MAJOR_AUDIO			0x04
#define MBT_COD_MAJOR_PERIPHERAL		0x05
#define MBT_COD_MAJOR_IMAGING		0x06
#define MBT_COD_MAJOR_WEARABLE		0x07
#define MBT_COD_MAJOR_TOY				0x08
#define MBT_COD_MAJOR_MEDICAL			0x09
#define MBT_COD_MAJOR_UNCLASSIFIED	0x1F

/***************************
** minor device class field
****************************/
#define MBT_COD_MINOR_COMPUTER_DESKTOP		0x01
#define MBT_COD_MINOR_COMPUTER_SERVER 		0x02
#define MBT_COD_MINOR_COMPUTER_LAPTOP		0x03
#define MBT_COD_MINOR_COMPUTER_HANDHELD 	0x04
#define MBT_COD_MINOR_COMPUTER_PALM 		0x05
#define MBT_COD_MINOR_COMPUTER_WEARABLE 	0x06

#define MBT_COD_MINOR_PHONE_CELLULAR 		0x01
#define MBT_COD_MINOR_PHONE_CORDLESS		0x02
#define MBT_COD_MINOR_PHONE_SMART_PHONE 	0x03
#define MBT_COD_MINOR_PHONE_MODEM 			0x04
#define MBT_COD_MINOR_PHONE_ISDN				0x05

#define MBT_COD_MINOR_LAN_17 					0x08
#define MBT_COD_MINOR_LAN_33 					0x10
#define MBT_COD_MINOR_LAN_50 					0x18
#define MBT_COD_MINOR_LAN_67 					0x20
#define MBT_COD_MINOR_LAN_83 					0x28
#define MBT_COD_MINOR_LAN_99 					0x30

#define MBT_COD_MINOR_AUDIO_WEARABLE 		0x01
#define MBT_COD_MINOR_AUDIO_HANDS_FREE 		0x02
#define MBT_COD_MINOR_AUDIO_MICROPHONE 		0x04
#define MBT_COD_MINOR_AUDIO_LOUDSPEAKER 	0x05
#define MBT_COD_MINOR_AUDIO_HEADPHONES 		0x06
#define MBT_COD_MINOR_AUDIO_PORTABLE 		0x07
#define MBT_COD_MINOR_AUDIO_CARKIT 			0x08
#define MBT_COD_MINOR_AUDIO_SETTOP_BOX 		0x09
#define MBT_COD_MINOR_AUDIO_HIFI 				0x0A
#define MBT_COD_MINOR_AUDIO_VCR 				0x0B
#define MBT_COD_MINOR_AUDIO_VIDEO_CAMERA 	0x0C
#define MBT_COD_MINOR_AUDIO_CAMCODER 		0x0D
#define MBT_COD_MINOR_AUDIO_VIDEO_MONITOR 	0x0E
#define MBT_COD_MINOR_AUDIO_VIDEO_DISPLAY 	0x0F
#define MBT_COD_MINOR_AUDIO_VIDEO_CONFERENCING	0x10 
#define MBT_COD_MINOR_AUDIO_GAMING 			0x12

#define MBT_COD_MINOR_PERIPHERAL_KEYBOARD		0x10
#define MBT_COD_MINOR_PERIPHERAL_POINTING		0x20
#define MBT_COD_MINOR_PERIPHERAL_JOYSTICK		0x01 
#define MBT_COD_MINOR_PERIPHERAL_GAMEPAD		0x02 
#define MBT_COD_MINOR_PERIPHERAL_REMOCON		0x03 
#define MBT_COD_MINOR_PERIPHERAL_SENSING		0x04 
#define MBT_COD_MINOR_PERIPHERAL_DIGITIZER		0x05 
#define MBT_COD_MINOR_PERIPHERAL_CARD_READER	0x06 

#define MBT_COD_MINOR_IMAGING_DISPLAY			0x04
#define MBT_COD_MINOR_IMAGING_CAMERA			0x08
#define MBT_COD_MINOR_IMAGING_SCANNER			0x10
#define MBT_COD_MINOR_IMAGING_PRINTER			0x20

#define MBT_COD_MINOR_WEARABLE_WRIST_WATCH 	0x01
#define MBT_COD_MINOR_WEARABLE_PAGER 			0x02
#define MBT_COD_MINOR_WEARABLE_JACKET 			0x03
#define MBT_COD_MINOR_WEARABLE_HELMET 			0x04
#define MBT_COD_MINOR_WEARABLE_GLASSES 			0x05

#define MBT_COD_MINOR_TOY_ROBOT 					0x01
#define MBT_COD_MINOR_TOY_VEHICLE 				0x02
#define MBT_COD_MINOR_TOY_DOLL 					0x03
#define MBT_COD_MINOR_TOY_CONTROLLER 			0x04
#define MBT_COD_MINOR_TOY_GAME 					0x05

#define MBT_COD_MINOR_MEDICAL_BLOOD_PRESSURE	0x01
#define MBT_COD_MINOR_MEDICAL_THERMOMETER 		0x02
#define MBT_COD_MINOR_MEDICAL_WEIGHING_SCALE 	0x03
#define MBT_COD_MINOR_MEDICAL_GLUCOSE_METER 	0x04
#define MBT_COD_MINOR_MEDICAL_PULSE_OXIMETER 	0x05
#define MBT_COD_MINOR_MEDICAL_HEART_PULSE_RATE	0x06
#define MBT_COD_MINOR_MEDICAL_DATA_DISPLAY 		0x07

/***************************
** service class fields
****************************/
#define MBT_COD_SERVICE_LMTD_DISCOVER	0x0020
#define MBT_COD_SERVICE_POSITIONING		0x0100
#define MBT_COD_SERVICE_NETWORKING		0x0200
#define MBT_COD_SERVICE_RENDERING		0x0400
#define MBT_COD_SERVICE_CAPTURING		0x0800
#define MBT_COD_SERVICE_OBJ_TRANSFER		0x1000
#define MBT_COD_SERVICE_AUDIO				0x2000
#define MBT_COD_SERVICE_TELEPHONY		0x4000
#define MBT_COD_SERVICE_INFORMATION		0x8000
/***************************
* MBT service ID
****************************/
// Bluetooth assigned UUIDs for Protocols
#define MBT_PROTOCOL_UUID_SDP			0x0001
#define MBT_PROTOCOL_UUID_UDP			0x0002
#define MBT_PROTOCOL_UUID_RFCOMM		0x0003
#define MBT_PROTOCOL_UUID_TCP			0x0004
#define MBT_PROTOCOL_UUID_TCS_BIN	0x0005
#define MBT_PROTOCOL_UUID_TCS_AT		0x0006
#define MBT_PROTOCOL_UUID_OBEX		0x0008
#define MBT_PROTOCOL_UUID_IP			0x0009
#define MBT_PROTOCOL_UUID_FTP			0x000A
#define MBT_PROTOCOL_UUID_HTTP		0x000C
#define MBT_PROTOCOL_UUID_WSP		0x000E
#define MBT_PROTOCOL_UUID_BNEP		0x000F
#define MBT_PROTOCOL_UUID_UPNP		0x0010
#define MBT_PROTOCOL_UUID_HIDP		0x0011
#define MBT_PROTOCOL_UUID_HARDCOPY_CONTROL_CHANNEL	0x0012
#define MBT_PROTOCOL_UUID_HARDCOPY_DATA_CHANNEL		0x0014
#define MBT_PROTOCOL_UUID_HARDCOPY_NOTIFICATION		0x0016
#define MBT_PROTOCOL_UUID_AVCTP		0x0017
#define MBT_PROTOCOL_UUID_AVDTP		0x0019
#define MBT_PROTOCOL_UUID_CMTP		0x001B
#define MBT_PROTOCOL_UUID_UDI_C_PLANE		0x001D
#define MBT_PROTOCOL_UUID_MCAPControlChannel	0x001E
#define MBT_PROTOCOL_UUID_MCAPDataChannel	0x001F
#define MBT_PROTOCOL_UUID_L2CAP				0x0100
	
// Bluetooth assigned UUIDs for Service Classes
//AG,CTP,ICP
#define MBT_SVCUUID_HEADSET						0X1108	// Peer ��ġ-Headset Profile(MBT_SVC_HSP) 
#define MBT_SVCUUID_HEADSET_AUDIO_GATEWAY		0X1112	// Local ��ġ
#define MBT_SVCUUID_HF_HANDSFREE					0X111E	// Peer ��ġ-Hands-Free Profile(MBT_SVC_HFP)
#define MBT_SVCUUID_AG_HANDSFREE					0X111F	// Local ��ġ
#define MBT_SVCUUID_CORDLESS_TELEPHONY			0X1109	// Cordless Telephony Profile(MBT_SVC_CTP)
#define MBT_SVCUUID_INTERCOM						0X1110	// Intercom Profile(MBT_SVC_ICP)
//SPP, DUN
#define MBT_SVCUUID_SERIAL_PORT					0X1101 // Serial Port Profile(MBT_SVC_SPP)
#define MBT_SVCUUID_DIALUP_NETWORKING			0X1103  // Dial-Up Networking Profile(MBT_SVC_DUN)
//OBEX
#define MBT_SVCUUID_OBEX_OBJECT_PUSH				0X1105	// Object Push Profile(MBT_SVC_OPP)
#define MBT_SVCUUID_OBEX_FILE_TRANSFER			0X1106	// File Transfer Profile(MBT_SVC_FTP)
#define MBT_SVCUUID_DIRECT_PRINTING				0X1118	// Basic Printing Profile(MBT_SVC_BPP)
#define MBT_SVCUUID_IMAGING						0X111A	// Basic Imaging Profile(MBT_SVC_BIP)
#define MBT_SVCUUID_IMAGING_RESPONDER			0X111B	// Basic Imaging Profile(MBT_SVC_BIP)
#define MBT_SVCUUID_SAP							0X112D	// SIM Access Profile(MBT_SVC_SAP)
#define MBT_SVCUUID_PBAP_PSE						0X112F	// Phone Book Access Profile - PSE(MBT_SVC_PBAP)
//A2DP, AVRCP
#define MBT_SVCUUID_AUDIO_SOURCE					0X110A	// Advanced Audio Distribution Profile (MBT_SVC_ASRC)
#define MBT_SVCUUID_AUDIO_SINK					0X110B	// Advanced Audio Distribution Profile (MBT_SVC_ASNK)
#define MBT_SVCUUID_AV_REMOTE_CONTROL_TARGET	0X110C  // A/V Remote Control profile target
#define MBT_SVCUUID_AV_REMOTE_CONTROL			0X110E	// A/V Remote Control Profile(MBT_SVC_AVRCP)
//HID
#define MBT_SVCUUID_HUMAN_INTERFACE				0X1124	// Human Interface Device Profile(MBT_SVC_HIDD)
//PAN
#define MBT_SVCUUID_PANU							0X1115	// Personal Area Network Profile (MBT_SVC_PANUS)
#define MBT_SVCUUID_NAP							0X1116	// Personal Area Network Profile (MBT_SVC_PANAP)
#define MBT_SVCUUID_GN								0X1117	// Personal Area Network Profile (MBT_SVC_PANGR)
//ETC
#define MBT_SVCUUID_FAX							0X1111	// Fax Profile(MBT_SVC_FAX)
#define MBT_SVCUUID_IRMC_SYNC						0X1104	// Synchronization Profile(MBT_SVC_SYNC)
#define MBT_SVCUUID_LAN_ACCESS_USING_PPP		0X1102	// LAN Access Profile(MBT_SVC_LAP)
#define MBT_SVCUUID_VIDEO_SOURCE					0X1303	// Video Distribution Profile (MBT_SVC_VSRC)
#define MBT_SVCUUID_VIDEO_SINK					0X1304	// Video Distribution Profile (MBT_SVC_VSNK)
#define MBT_SVCUUID_AAS							0x4C47	// Auto Achieve Service
//Not yet applied
#define MBT_SVCUUID_SERVICE_DISCOVERY_SERVER	0X1000
#define MBT_SVCUUID_BROWSE_GROUP_DESCRIPTOR	0X1001
#define MBT_SVCUUID_PUBLIC_BROWSE_GROUP			0X1002	
#define MBT_SVCUUID_IRMC_SYNC_COMMAND			0X1107
#define MBT_SVCUUID_AV_REM_CTRL_TARGET			0X110C  
#define MBT_SVCUUID_ADV_AUDIO_DISTRIBUTION		0X110D  
#define MBT_SVCUUID_VIDEO_CONFERENCING			0X110F  
#define MBT_SVCUUID_WAP							0X1113
#define MBT_SVCUUID_WAP_CLIENT					0X1114
#define MBT_SVCUUID_REFERENCE_PRINTING			0X1119
#define MBT_SVCUUID_IMAGING_AUTO_ARCHIVE		0X111C
#define MBT_SVCUUID_IMAGING_REF_OBJECTS			0X111D
#define MBT_SVCUUID_DIR_PRT_REF_OBJ_SERVICE		0X1120
#define MBT_SVCUUID_REFLECTED_UI					0X1121
#define MBT_SVCUUID_BASIC_PRINTING				0X1122
#define MBT_SVCUUID_PRINTING_STATUS				0X1123
#define MBT_SVCUUID_CABLE_REPLACEMENT			0X1125
#define MBT_SVCUUID_HCRP_PRINT					0X1126
#define MBT_SVCUUID_HCRP_SCAN						0X1127
#define MBT_SVCUUID_COMMON_ISDN_ACCESS			0X1128
#define MBT_SVCUUID_VIDEO_CONFERENCING_GW		0X1129
#define MBT_SVCUUID_UDI_MT						0X112A
#define MBT_SVCUUID_UDI_TA						0X112B
#define MBT_SVCUUID_VCP							0X112C
#define MBT_SVCUUID_PBAP_PCE						0X112E 
#define MBT_SVCUUID_PHONE_ACCESS					0x1130
#define MBT_SVCUUID_PNP_INFORMATION				0X1200
#define MBT_SVCUUID_GENERIC_NETWORKING			0X1201
#define MBT_SVCUUID_GENERIC_FILETRANSFER			0X1202
#define MBT_SVCUUID_GENERIC_AUDIO				0X1203
#define MBT_SVCUUID_GENERIC_TELEPHONY			0X1204
#define MBT_SVCUUID_UPNP_SERVICE					0X1205
#define MBT_SVCUUID_UPNP_IP_SERVICE				0X1206
#define MBT_SVCUUID_ESDP_UPNP_IP_PAN				0X1300
#define MBT_SVCUUID_ESDP_UPNP_IP_LAP				0X1301
#define MBT_SVCUUID_ESDP_UPNP_IP_L2CAP			0X1302
#define MBT_SVCUUID_VIDEO_DISTRIBUTION			0X1305
typedef	MBT_SHORT	MBT_SERVICE_ID;

/***************************
** Discoverable Mode
****************************/
#define MBT_DISCOVERABLE_MODE_NONE			0x000000
#define MBT_DISCOVERABLE_MODE_GIAC			0x9E8B33  
#define MBT_DISCOVERABLE_MODE_LIAC			0x9E8B00  

/******************AVRCP******************/

/***************************
** Category bit
****************************/
#define MBT_AVRCP_CATEGORY_1_BIT		0x0001	// Player/Recorder 
#define MBT_AVRCP_CATEGORY_2_BIT		0x0002	// Monitor/Amplifier 
#define MBT_AVRCP_CATEGORY_3_BIT		0x0004	// Tuner 
#define MBT_AVRCP_CATEGORY_4_BIT		0x0008	// Menu 

/***************************
** Equalizer On/Off status
****************************/
#define MBT_AVRCP_EQUALIZER_OFF		0x01	// equalizer off
#define MBT_AVRCP_EQUALIZER_ON		0x02	// equalizer on

/***************************
** Repeate mode status
****************************/
#define MBT_AVRCP_REPEATE_OFF			0x01	// repeate mode off
#define MBT_AVRCP_REPEATE_SINGLE		0x02	// single track repeat
#define MBT_AVRCP_REPEATE_ALL			0x03	// all track repeat
#define MBT_AVRCP_REPEATE_GROUP		0x04	// group repeat

/***************************
** Shuffle On/Off status
****************************/
#define MBT_AVRCP_SHUFFLE_OFF			0x01	// shuffle off
#define MBT_AVRCP_SHUFFLE_ALL			0x02	// all tracks shuffle
#define MBT_AVRCP_SHUFFLE_GROUP		0x03	// group shuffle

/***************************
** Scan On/Off status
****************************/
#define MBT_AVRCP_SCAN_OFF			0x01	// scan off	
#define MBT_AVRCP_SCAN_ALL			0x02	// all tracks scan
#define MBT_AVRCP_SCAN_GROUP			0x03	// group scan

/***************************
** IANA character set
****************************/
#define MBT_AVRCP_CHAR_UTF8			0x006A	// MIBenum value for UTF-8

/***************************
** Media Identifier
****************************/
#define MBT_AVRCP_MEDIA_ID_PLAYING	0x0		// current track

/***************************
** Register Notification Error type
****************************/
#define MBT_AVRCP_ERR_TRACK_CHANGED	0xFFFFFFFFFFFFFFFF	// no track currently selected
#define MBT_AVRCP_ERR_PLAY_POSITION	0xFFFFFFFF			// no track currently selected

/*******************BPP*******************/

// orientation
#define MBT_ORIENT_IGNORED				0x0
#define MBT_ORIENT_PORTRAIT				0x1
#define MBT_ORIENT_LANDSCAPE				0x2
#define MBT_ORIENT_REVERSE_LANDSCAPE		0x4
#define MBT_ORIENT_REVERSE_PORTRAIT		0x8

// sides
#define MBT_SIDES_IGNORED					0x0
#define MBT_SIDES_ONE_SIDED				0x1
#define MBT_SIDES_TWO_SIDED_LONG_EDGE	0x2
#define MBT_SIDES_TWO_SIDED_SHORT_EDGE	0x4

// quality
#define MBT_QUALITY_IGNORED				0x0
#define MBT_QUALITY_NORMAL				0x1
#define MBT_QUALITY_DRAFT					0x2
#define MBT_QUALITY_HIGH					0x4

// attribute
#define MBT_PRINTER_NAME_MASK				0x00000001
#define MBT_PRINTER_LOCATION_MASK			0x00000002
#define MBT_PRINTER_STATE_MASK				0x00000004
#define MBT_PRINTER_STATE_REASONS_MASK		0x00000008
#define MBT_DOCUMENT_FORMAT_SUPPORTED_MASK	0x00000010
#define MBT_COLOR_SUPPORTED_MASK				0x00000020
#define MBT_MAX_COPIES_SUPPORTED_MASK		0x00000040
#define MBT_SIDES_SUPPORTED_MASK				0x00000080
#define MBT_NUMBER_UP_SUPPORTED_MASK		0x00000100
#define MBT_ORIENTATIONS_SUPPORTED_MASK		0x00000200
#define MBT_MEDIA_SIZES_SUPPORTED_MASK		0x00000400
#define MBT_MEDIA_TYPES_SUPPORTED_MASK		0x00000800
#define MBT_MEDIA_LOADED_MASK				0x00001000
#define MBT_QUALITY_SUPPORTED_MASK			0x00002000
#define MBT_QUEUED_JOB_COUNT_MASK			0x00004000
#define MBT_IMAGE_FORMATS_SUPPORTED_MASK	0x00008000
#define MBT_BASIC_TEXT_PAGE_WIDTH_MASK		0x00010000
#define MBT_BASIC_TEXT_PAGE_HEIGHT_MASK		0x00020000
#define MBT_PRINTER_GENERAL_CURRENT_OPERATOR_MASK	0x00040000

/*******************HID********************/
typedef MBT_INT  T_MBT_HID_HANDLE;

#define MBT_HID_KEYBOARD		0x40
#define MBT_HID_MOUSE			0x80
#define MBT_HID_JOYSTICK		0x04
typedef MBT_BYTE	T_MBT_HID_DEV_TYPE;

#define MBT_HID_REPORT_OTHER		0
#define MBT_HID_REPORT_INPUT		1
#define MBT_HID_REPORT_OUTPUT		2
#define MBT_HID_REPORT_FEATURE	3
typedef MBT_BYTE	T_MBT_HID_REPORT_TYPE;

#define MBT_HID_BOOT_MODE			0
#define MBT_HID_REPORT_MODE		1
typedef MBT_BYTE	T_MBT_HID_MODE_TYPE;

#define MBT_HID_CONTROL_NOP			0x0
#define MBT_HID_CONTROL_HARD_RESET	0x1
#define MBT_HID_CONTROL_SOFT_RESET	0x2
#define MBT_HID_CONTROL_SUSPEND		0x3
#define MBT_HID_CONTROL_EXIT_SUSPEND	0x4
#define MBT_HID_CONTROL_UNPLUG		0x5
typedef MBT_BYTE	T_MBT_HID_CONTROL;

#define MBT_HID_KBD_KEY_LEFT_CONTROL		0x01
#define MBT_HID_KBD_KEY_LEFT_SHIFT		0x02
#define MBT_HID_KBD_KEY_LEFT_ALT			0x04
#define MBT_HID_KBD_KEY_LEFT_GUI			0x08
#define MBT_HID_KBD_KEY_RIGHT_CONTROL	0x10
#define MBT_HID_KBD_KEY_RIGHT_SHIFT		0x20
#define MBT_HID_KBD_KEY_RIGHT_ALT			0x40
#define MBT_HID_KBD_KEY_RIGHT_GUI			0x80
typedef MBT_BYTE	T_MBT_HID_MODIFIER_MASK;

#define MBT_HID_LED_NUM_LOCK			0x01
#define MBT_HID_LED_CAPS_LOCK			0x02
#define MBT_HID_LED_SCROLL_LOCK		0x04
#define MBT_HID_LED_COMPOSE			0x08
#define MBT_HID_LED_KANA				0x10
typedef MBT_BYTE	T_MBT_HID_LED_MASK;

#define MBT_HID_MOUSE_BUTTON_LEFT	0x01
#define MBT_HID_MOUSE_BUTTON_RIGHT	0x02
#define MBT_HID_MOUSE_BUTTON_MIDDLE	0x04

typedef MBT_BYTE	T_MBT_HID_MOUSE_BUTTON_MASK;

typedef void (FP_MBT_HID_RX_REPORT_CO) (MBT_SHORT dev_idx, MBT_BYTE *rpt_data, MBT_SHORT rpt_size, T_MBT_HID_REPORT_TYPE rpt_type, T_MBT_HID_MODE_TYPE mode);



/*******************JSR82********************/

/* SDP Attribute ID */
#define	MBT_JSR82_ATTR_ID_SERVICE_RECORD_HANDLE				0x0000
#define	MBT_JSR82_ATTR_ID_SERVICE_CLASS_ID_LIST					0x0001
#define	MBT_JSR82_ATTR_ID_SERVICE_RECORD_STATE					0x0002
#define	MBT_JSR82_ATTR_ID_SERVICE_SERVICE_ID					0x0003
#define	MBT_JSR82_ATTR_ID_PROTOCOL_DESCRIPTOR_LIST				0x0004
#define	MBT_JSR82_ATTR_ID_BROWSE_GROUP_LIST					0x0005
#define	MBT_JSR82_ATTR_ID_LANGUAGE_BASE_ATTRIBUTE_ID_LIST	0x0006
#define	MBT_JSR82_ATTR_ID_SERVICE_INFO_TIME_TO_LIVE			0x0007
#define	MBT_JSR82_ATTR_ID_SERVICE_AVAILABILITY					0x0008
#define	MBT_JSR82_ATTR_ID_BLUETOOTH_PROFILE_DESCRIPTOR_LIST	0x0009
#define	MBT_JSR82_ATTR_ID_DOCUMENTATION_URL					0x000A
#define	MBT_JSR82_ATTR_ID_CLIENT_EXECUTABLE_URL				0x000B
#define	MBT_JSR82_ATTR_ID_ICON_URL								0x000C
#define	MBT_JSR82_ATTR_ID_ADDITIONAL_PROTOCOL_DESCRIPTOR_LISTS	0x000D
#define	MBT_JSR82_ATTR_ID_SERVICE_NAME							0x0100
#define	MBT_JSR82_ATTR_ID_SERVICE_DESCRIPTION					0x0101
#define	MBT_JSR82_ATTR_ID_PROVIDER_NAME						0x0102
#define	MBT_JSR82_ATTR_ID_VERSION_NUMBER_LIST					0x0200
#define	MBT_JSR82_ATTR_ID_GROUP_ID								0x0200
#define	MBT_JSR82_ATTR_ID_SERVICE_DATABASE_STATE				0x0201
#define	MBT_JSR82_ATTR_ID_HID_DESCRIPTOR_LIST					0x0206
#define	MBT_JSR82_ATTR_ID_SERVICE_VERSION						0x0300
#define	MBT_JSR82_ATTR_ID_NETWORK								0x0301

/*******************OBEX Protocol********************/

//OBEX OP Code//
#define MBT_OBEX_REQ_CONNECT		0x00	// need to set final bit
#define MBT_OBEX_REQ_DISCONNECT	0x01	//need to set final bit
#define MBT_OBEX_REQ_PUT			0x02
#define MBT_OBEX_REQ_PUT_FINAL	0x82
#define MBT_OBEX_REQ_GET			0x03
#define MBT_OBEX_REQ_GET_FINAL	0x83
#define MBT_OBEX_REQ_SETPATH		0x05	//need to set final bit
#define MBT_OBEX_REQ_ABORT		0x7F	//need to set final bit
typedef	MBT_BYTE T_MBT_OBEX_OPCODE;

//OBEX Response Code//
#define	MBT_OBEX_RES_DEFAULT		0x00
#define	MBT_OBEX_RES_FAILED		0x08	//	OBEX failed - not from spec
#define	MBT_OBEX_RES_CONTINUE	0x10	//	Continue
#define	MBT_OBEX_RES_OK			0x20	//	OK, Success
#define	MBT_OBEX_RES_CREATED		0x21	//	Created
#define	MBT_OBEX_RES_ACCEPTED	0x22	//	Accepted
#define	MBT_OBEX_RES_NON_AUTH_INFO	0x23	//	Non-Authoritative Information
#define	MBT_OBEX_RES_NO_CONTENT		0x24	//	No Content
#define	MBT_OBEX_RES_RESET_CONTENT	0x25	//	Reset Content
#define	MBT_OBEX_RES_PART_CONTENT	0x26	//	Partial Content
#define	MBT_OBEX_RES_MULTI_CHOICES	0x30	//	Multiple Choices
#define	MBT_OBEX_RES_MVD_PERM		0x31	//	Moved Permanently
#define	MBT_OBEX_RES_MVD_TEMP		0x32	//	Moved temporarily
#define	MBT_OBEX_RES_SEE_OTHER		0x33	//	See Other
#define	MBT_OBEX_RES_NOT_MODIFIED	0x34	//	Not modified
#define	MBT_OBEX_RES_USE_PROXY		0x35	//	Use Proxy
#define	MBT_OBEX_RES_BAD_REQUEST	0x40	//	Bad Request - server couldn't	understand request
#define	MBT_OBEX_RES_UNAUTHORIZED	0x41	//	Unauthorized
#define	MBT_OBEX_RES_PAYMENT_REQD	0x42	//	Payment required
#define	MBT_OBEX_RES_FORBIDDEN		0x43	//	Forbidden - operation is understood but refused
#define	MBT_OBEX_RES_NOT_FOUND		0x44	//	Not Found
#define	MBT_OBEX_RES_NOT_ALLOWED	0x45	//	Method not allowed
#define	MBT_OBEX_RES_NOT_ACCEPTABLE	0x46	//	Not Acceptable
#define	MBT_OBEX_RES_PROXY_AUTH_REQD	0x47	//	Proxy Authentication required
#define	MBT_OBEX_RES_REQUEST_TIMEOUT	0x48	//	Request Time Out
#define	MBT_OBEX_RES_CONFLICT			0x49	//	Conflict
#define	MBT_OBEX_RES_GONE				0x4A	//	Gone
#define	MBT_OBEX_RES_LENGTH_REQD		0x4B	//	Length Required
#define	MBT_OBEX_RES_PRECONDTN_FAILED	0x4C	//	Precondition failed
#define	MBT_OBEX_RES_REQ_ENT_2_LARGE	0x4D	//	Requested entity too large
#define	MBT_OBEX_RES_REQ_URL_2_LARGE	0x4E	//	Request URL too large
#define	MBT_OBEX_RES_UNSUPTD_TYPE		0x4F	//	Unsupported media type
#define	MBT_OBEX_RES_INTRNL_SRVR_ERR	0x50	//	Internal Server Error
#define	MBT_OBEX_RES_NOT_IMPLEMENTED	0x51	//	Not Implemented
#define	MBT_OBEX_RES_BAD_GATEWAY		0x52	//	Bad Gateway
#define	MBT_OBEX_RES_SERVICE_UNAVL		0x53	//	Service Unavailable
#define	MBT_OBEX_RES_GATEWAY_TIMEOUT	0x54	//	Gateway Timeout
#define	MBT_OBEX_RES_HTTP_VER_NOT_SUPTD	0x55//	HTTP version not supported
#define	MBT_OBEX_RES_DATABASE_FULL		0x60	//	Database Full
#define	MBT_OBEX_RES_DATABASE_LOCKED	0x61	//	Database Locked
typedef	MBT_BYTE T_MBT_OBEX_RES;

// CHARSET definition for Authentication Challenge Realm//
#define MBT_OBEX_RCS_ASCII		0x00	//ASCII
#define MBT_OBEX_RCS_8859_1	0x01	//ISO-8859-1
#define MBT_OBEX_RCS_8859_2	0x02	//ISO-8859-2
#define MBT_OBEX_RCS_8859_3	0x03	//ISO-8859-3
#define MBT_OBEX_RCS_8859_4	0x04	//ISO-8859-4
#define MBT_OBEX_RCS_8859_5	0x05	//ISO-8859-5
#define MBT_OBEX_RCS_8859_6	0x06	//ISO-8859-6
#define MBT_OBEX_RCS_8859_7	0x07	//ISO-8859-7
#define MBT_OBEX_RCS_8859_8	0x08	//ISO-8859-8
#define MBT_OBEX_RCS_8859_9	0x09	//ISO-8859-9
#define MBT_OBEX_RCS_UNICODE	0xFF	//Unicode
typedef MBT_BYTE T_MBT_OBEX_CHARSET;


/********************************************************************************
* 							ENUM TYPE DEFINE START
********************************************************************************/

/*******************GAP********************/
// GAP security 
typedef enum
{
    MBT_GAP_SECURITY_NONE=0,				// security ���� �ƹ� ������ ���� ���
    MBT_GAP_SECURITY_AUTHENTICATE,		// authentication�� ����
    MBT_GAP_SECURITY_AUTHENTICATE_AND_ENCRYPT,	// authentication�� encryption ���� 
}T_MBT_GAP_SECURITY;

// GAP access mode
typedef enum
{
    MBT_GAP_ACCESS_MODE_UNKNOWN=0,
    MBT_GAP_ACCESS_MODE_GIAC,				// all
    MBT_GAP_ACCESS_MODE_LIAC,				// limited discoverable mode    
}T_MBT_GAP_ACCESS_MODE;

typedef enum
{
	MBT_GAP_SSP_JUST_WORKS=0,			// Jusrt work
	MBT_GAP_SSP_NUMERIC_COMPARISON,	// Numeric comparison
	MBT_GAP_SSP_PASSKEY_ENTRY,			// Passkey entry
	MBT_GAP_SSP_OOB						// Out of band(NFC)
}T_MBT_GAP_SSP_MODEL;
typedef enum
{
	MBT_GAP_STATUS_IDLE,
	MBT_GAP_STATUS_TURNON,
	MBT_GAP_STATUS_TURNOFF,
	MBT_GAP_STATUS_SETMYNAME,
	MBT_GAP_STATUS_SETVISIBILE,
	MBT_GAP_STATUS_SETCONNECTABLE,
	MBT_GAP_STATUS_DEVDISCOVERY,
	MBT_GAP_STATUS_DEVDISCOVERY_CANCEL,
	MBT_GAP_STATUS_SVCDISCOVERY,
	MBT_GAP_STATUS_SVCDISCOVERY_CANCEL,
	MBT_GAP_STATUS_PAIR_REQ,			//include SSP
	MBT_GAP_STATUS_PAIR_REQ_CANCEL,
	MBT_GAP_STATUS_PAIR_RES,			//include SSP
	MBT_GAP_STATUS_PAIR_RES_CANCEL,
	MBT_GAP_STATUS_AUTHORIZE,
	MBT_GAP_STATUS_UNPAIR
}T_MBT_GAP_STATUS;

typedef enum
{
	MBT_GAP_PAIRERR_UNKNOWN,	//Unknown reason
	MBT_GAP_PAIRERR_TIMEOUT,		//Timeout
	MBT_GAP_PAIRERR_KEYERR,		//PIN Code or passkey Missmatch
	MBT_GAP_PAIRERR_REJECT		//Rejected
}T_MBT_PAIR_ERR_REASON;

/*******************AG********************/

// HSP/HFP AG outgoing call
typedef enum 
{
	MBT_AG_CALL_NORMALDIAL,     	//�Ϲ� �߽�
	MBT_AG_CALL_REDIAL,			//�ֽŹ�ȣ�߽�
	MBT_AG_CALL_MEMDIAL			//�޸� ��ȣ �߽�
}T_MBT_AG_DIAL;

// HSP/HFP AG call status indication
typedef enum 
{
	MBT_AG_CALLSTATUS_END,		// no active call [call indicator, 1]
	MBT_AG_CALLSTATUS_ACTIVE	// active call [call indicator, 0]	
}T_MBT_AG_CALLSTATUS;

// HSP/HFP AG call settup status indication
typedef enum 
{
	MBT_AG_CALLSETUP_IDLE,			// call setup none, [callsetup indicator, 0]
	MBT_AG_CALLSETUP_INCOMING,		// incoming call setup [callsetup indicator, 1]
	MBT_AG_CALLSETUP_ORIGINATING,	// outgoing call setup [callsetup indicator, 2]
	MBT_AG_CALLSETUP_ALERTING,		// call alert [callsetup indicator, 3]
}T_MBT_AG_CALLSETUP;

/* KBNAM : phone�� call state�� ���� [2007/10/10 14:50:14] */
// HSP/HFP AG�� call state
typedef enum 
{
	MBT_AG_PHONE_CALL_NONE,
	MBT_AG_PHONE_CALL_INCOMING,		// incoming call �߻�
	MBT_AG_PHONE_CALL_ORIGINATING,	// outgoing call �߻�
	MBT_AG_PHONE_CALL_ALERTING,
	MBT_AG_PHONE_CALL_ACTIVE,		// call active
	MBT_AG_PHONE_CALL_HELD			// held call exist
}T_MBT_AG_PHONE_CALLSTATE;

// HSP/HFP AG�� ���� �� ���� type
typedef enum 
{
	MBT_AG_NET_OFF,	// �� ��Ȱ��ȭ
	MBT_AG_NET_ON		// �� Ȱ��ȭ
}T_MBT_AG_NETSTATE;

// HSP/HFP AG held call stasus
typedef enum 
{
	MBT_AG_NO_CALL_HELD,					// held call ����
	MBT_AG_HELD_RETRIEVE_OTHER_CALL,	// �ٸ� call�� active
	MBT_AG_HELD_NO_ACTIVE_CALL			// active call ����
}T_MBT_AG_CALL_HELD;

// HFP1.5 AG error code type */
typedef enum 
{
	MBT_AG_CME_ERR_AG_FAILURE 						= 0,		// ag general failure
	MBT_AG_CME_ERR_NO_CONNECTION 					= 1,		// no hfp service connection
	MBT_AG_CME_ERR_OPERATION_NOT_ALLOWED 			= 3,		// ���� ���� �Ұ� ����
	MBT_AG_CME_ERR_OPERATION_NOT_SUPPORTED 		= 4,		// �������� �ʴ� ����
	MBT_AG_CME_ERR_PH_SIM_PIN_REQUIRED 			= 5,		// SIM ���� �ʿ�(���� ���� )
	MBT_AG_CME_ERR_SIM_NOT_INSERTED 				= 10	,	// SIM ����
	MBT_AG_CME_ERR_SIM_PIN_REQUIRED 				= 11,	// SIM ���� �ʿ�
	MBT_AG_CME_ERR_SIM_PUK_REQUIRED 				= 12,	// SIM ���� �ʿ�
	MBT_AG_CME_ERR_SIM_FAILURE 						= 13,	// SIM ���� ����
	MBT_AG_CME_ERR_SIM_BUSY							= 14,	// SIM ���� �Ұ� ����
	MBT_AG_CME_ERR_INCORRECT_PASSWORD 			= 16,	// �н����� ����
	MBT_AG_CME_ERR_SIM_PIN2_REQUIRED 				= 17,	// SIM ���� �ʿ�
	MBT_AG_CME_ERR_SIM_PUK2_REQUIRED 				= 18,	// SIM ���� �ʿ�
	MBT_AG_CME_ERR_MEMORY_FULL					 	= 20,	// ���� ���� ����
	MBT_AG_CME_ERR_INVALID_INDEX					= 21,	// �ε��� ����
	MBT_AG_CME_ERR_MEMORY_FAILURE 					= 23,	// ���� ����
	MBT_AG_CME_ERR_TEXT_STRING_TOO_LONG 			= 24,	// �ʹ� �� ���ڿ� ����
	MBT_AG_CME_ERR_INVALID_CHAR_IN_TXT_STR 		= 25,	// �߸��� ���ڿ� ����
	MBT_AG_CME_ERR_DIAL_STRING_TOO_LONG 			= 26,	// �ʹ� �� ��ȭ��ȣ ����
	MBT_AG_CME_ERR_INVALID_CHAR_IN_DIAL_STR 		= 27,	// �߸��� ��ȭ��ȣ Ÿ�� ����
	MBT_AG_CME_ERR_NO_NETWORK_SERVICE 			= 30,	// �� ��Ȱ��ȭ ����
	MBT_AG_CME_ERR_NETWORK_NOT_ALLOWED 			= 32		// �� ���� �Ұ� ����
}T_MBT_AG_CME_ERR;

// HFP1.5 AG Network mode(operator) 
typedef enum 
{
	MBT_AG_NM_AUTOMATIC,						// automatic mode
	MBT_AG_NM_MANUAL,						// manual mode
	MBT_AG_NM_DEREGISTER_FROM_NETWORK,	// deregister mode
	MBT_AG_NM_NO_CHANGE,					// no change mode
	MBT_AG_NM_MANUAL_AUTOMATIC,			// manual & automatic mode
	MBT_AG_NM_NO_OPERATOR_SELECTED,		// no operator selected mode
	MBT_AG_NM_MAX
}T_MBT_AG_NETMODE;

// HFP1.5 AG Network service 
typedef enum 
{
	MBT_AG_SERVICE_NONE = 0,		// no service
	MBT_AG_SERVICE_VOICE = 4,		// voice call service
	MBT_AG_SERVICE_FAX =5			// fax service
}T_MBT_AG_SERVICE;

// HFP1.5 AG call diretion
typedef enum 
{
	MBT_AG_CL_DIR_OUTGOING,		// outgoing call
	MBT_AG_CL_DIR_INCOMING		// incoming call
}T_MBT_AG_CL_DIR;

// HFP1.5 AG call status
typedef enum 
{
	MBT_AG_CL_STATUS_ACTIVE,		// active call status
	MBT_AG_CL_STATUS_HELD,        	// held call status
	MBT_AG_CL_STATUS_DIALING,    	// dialing status
	MBT_AG_CL_STATUS_ALERTING,  	// alerting status
	MBT_AG_CL_STATUS_INCOMING,   	// incoming status
	MBT_AG_CL_STATUS_WAITING,   	// call waiting status
	MBT_AG_CL_STATUS_NONE         	// no call status
}T_MBT_AG_CL_STATUS;

// HFP1.5 AG call service
typedef enum 
{
	MBT_AG_CL_MODE_VOICE,		// voice call
	MBT_AG_CL_MODE_DATA, 		// data call
	MBT_AG_CL_MODE_FAX			// fax
}T_MBT_AG_CL_MODE;

// HFP1.5 AG call multiparty
typedef enum {
	MBT_AG_CL_NO_MPRTY,			// single call
	MBT_AG_CL_MPRTY				// multiparty call
}T_MBT_AG_CL_MPTY;

// Phonebook Sync phonebook
typedef enum {
	MBT_AG_PB_DEV_ME = 0x00,	// ME phonebook list
	MBT_AG_PB_DEV_DC,		// ME Dialed calls list
	MBT_AG_PB_DEV_MC,		// ME missed calls list
	MBT_AG_PB_DEV_RC,		// ME received calls list
	MBT_AG_PB_DEV_SM,		// SIM phonebook list
	MBT_AG_PB_DEV_FD,		// SIM fix-dialing phonebook list
	MBT_AG_PB_DEV_LD,		// SIM last-dialing phonebook list
	MBT_AG_PB_DEV_MT,		// combined ME and SIM phonebook list
	MBT_AG_PB_DEV_MAX
}T_MBT_AG_PB_DEV;


typedef enum {
	MBT_AG_STATE_IDLE,
	MBT_AG_STATE_CONNECTING,
	MBT_AG_STATE_DISCONNECTING,
	MBT_AG_STATE_CONNECTED,
	MBT_AG_STATE_AUDIO_CONNECTING,
	MBT_AG_STATE_AUDIO_DISCONNECTING,
	MBT_AG_STATE_AUDIO_CONNECTED
} T_MBT_AG_STATE;

/*******************DUN*******************/
typedef enum
{
	MBT_DUN_CLOSED = 0,		// DUN ���񽺰� ��Ȱ��ȭ �� ����  (Default)
	MBT_DUN_STATE_IDLE,		// DUN ���񽺰� Ȱ��ȭ �� ����  (DUN�� Enable�� ����)
	MBT_DUN_STATE_LISTEN,	// DUN Listen ����
	MBT_DUN_CONNECTING,		// DUN ���񽺸� remote device�� �������� ����
	MBT_DUN_CONNECTED,		// DUN ���񽺷� remote device�� ����� ����
	MBT_DUN_DISOCNNECTING	// DUN ���� ���� �����ϴ� ����
}T_MBT_DUN_STATE;

/*******************SPP*******************/

/*******************A2DP******************/

typedef enum
{
	MBT_AV_AUDIO=0,	// AUDIO
	MBT_AV_VIDEO,	// VIDEO
	MBT_AV_MULTIMEDIA,	// A2DP + VDP in one channel
}T_MBT_AV_MEDIATYPE;

typedef enum
{
	/* Media codecs */
	MBT_CODEC_SBC = 0,
	MBT_CODEC_MPEG12_AUDIO,
	MBT_CODEC_MPEG24_AAC,
	MBT_CODEC_ATRAC,
	MBT_CODEC_NON_A2DP,
	/* Video codecs */
	MBT_CODEC_H263_BASELINE,
	MBT_CODEC_MPEG_VISUAL_SIMPLE_PROFILE,
	MBT_CODEC_H263_PROFILE3,
	MBT_CODEC_H263_PROFILE8,
	MBT_CODEC_NON_VDP,
}T_MBT_AV_CODECTYPE;

// A2DP audio source channel
typedef enum
{
	MBT_A2DP_CHANNEL_JOINT_STEREO=0,	// joint stereo channel
	MBT_A2DP_CHANNEL_STEREO,			// stereo channel
	MBT_A2DP_CHANNEL_DUAL,				// dual channel
	MBT_A2DP_CHANNEL_MONO				// mono channel
}T_MBT_A2DP_CHANNEL;

// A2DP connection status
typedef enum
{
	MBT_A2DP_CONSTATUS_DISCONNECTED = 0,	// no connection
    	MBT_A2DP_CONSTATUS_DISCONNECTINNG,		// disconnect is called..but not yet
	MBT_A2DP_CONSTATUS_CANCELING,			// connect cancel is called    
	MBT_A2DP_CONSTATUS_CONNECTING,			// connect is called..but not yet connected
	MBT_A2DP_CONSTATUS_CONNECTED,			// connection is existed    
//  MBT_A2DP_CONSTATUS_STOPPED = MBT_A2DP_CONSTATUS_CONNECTED,  // no playing
	MBT_A2DP_CONSTATUS_STARTING,			// play is called..but not yet
	MBT_A2DP_CONSTATUS_PLAY,				// play
	MBT_A2DP_CONSTATUS_PAUSED,				// pause
	MBT_A2DP_CONSTATUS_STOPPING,			// stop is called..but not yet    
}T_MBT_A2DP_CONSTATUS;
// VDP connection status
typedef enum
{
	MBT_VDP_CONSTATUS_DISCONNECTED = 0,	// no connection
    MBT_VDP_CONSTATUS_DISCONNECTINNG,		// disconnect is called..but not yet
	MBT_VDP_CONSTATUS_CANCELING,			// connect cancel is called
	MBT_VDP_CONSTATUS_CONNECTING,			// connect is called..but not yet connected
	MBT_VDP_CONSTATUS_CONNECTED,			// connection is existed
//	MBT_VDP_CONSTATUS_STOPPED = MBT_VDP_CONSTATUS_CONNECTED,  // no playing
	MBT_VDP_CONSTATUS_STARTING,			// play is called..but not yet
	MBT_VDP_CONSTATUS_PLAY,				// play
	MBT_VDP_CONSTATUS_PAUSED,				// pause
	MBT_VDP_CONSTATUS_STOPPING,			// stop is called..but not yet
}T_MBT_VDP_CONSTATUS;

typedef enum
{
	MBT_VDP_ROLE_SRC=0,	// VDP SRC
	MBT_VDP_ROLE_SNK,	// VDP SNK
}T_MBT_VDP_ROLE;

/*******************AVRCP******************/

// AVRCP key
typedef enum
{
	MBT_AVRCP_PLAY_PRESSED_K = 0,		// category1 - play (pressed)
	MBT_AVRCP_STOP_PRESSED_K,			// category1 - stop (pressed)
	MBT_AVRCP_PAUSE_PRESSED_K,			// category1 - pause (pressed)
	MBT_AVRCP_FORWARD_PRESSED_K,		// category1 - forward (pressed)
	MBT_AVRCP_BACKWARD_PRESSED_K,		// category1 - backward (pressed)
	MBT_AVRCP_FASTFORWARD_PRESSED_K,	// category1 - fast forward (pressed)
	MBT_AVRCP_REWIND_PRESSED_K,			// category1 - rewind (pressed)

	MBT_AVRCP_VOLUMEUP_PRESSED_K,		// category2 - volume up (pressed)
	MBT_AVRCP_VOLUMEDOWN_PRESSED_K,	// category2 - volume down (pressed)

	MBT_AVRCP_PLAY_RELEASED_K,			// category1 - play (released)
	MBT_AVRCP_STOP_RELEASED_K,			// category1 - stop (released)
	MBT_AVRCP_PAUSE_RELEASED_K,			// category1 - pause (released)
	MBT_AVRCP_FORWARD_RELEASED_K,		// category1 - forward (released)
	MBT_AVRCP_BACKWARD_RELEASED_K,		// category1 - backward (released)
	MBT_AVRCP_FASTFORWARD_RELEASED_K,	// category1 - fast forward (released)
	MBT_AVRCP_REWIND_RELEASED_K,		// category1 - rewind (released)

	MBT_AVRCP_VOLUMEUP_RELEASED_K,		// category2 - volume up (released)
	MBT_AVRCP_VOLUMEDOWN_RELEASED_K,	// category2 - volume down (released)
}T_MBT_AVRCP_KEY;

// AVRCP key press/release
typedef enum
{
	MBT_AVRCP_PRESSED_K,		// key press
	MBT_AVRCP_RELEASED_K		// key release
}T_MBT_AVRCP_KEYACTION;

// AVRCP connection status
typedef enum
{
	MBT_AVRCP_CONSTATUS_DISCONNECTED=0,	// no connection
	MBT_AVRCP_CONSTATUS_DISCONNECTING,		// disconnect is called..but not yet
	MBT_AVRCP_CONSTATUS_CONNECTED,			// connection is existed
	MBT_AVRCP_CONSTATUS_CONNECTING,		// connect is called..but not yet connected
	MBT_AVRCP_CONSTATUS_CANCELING,			// connect cancel is called
}T_MBT_AVRCP_CONSTATUS;

// AVRCP Events supported by TG
typedef enum
{
	 MBT_AVRCP_EV_PLAY_STATUS	= 0x01, 		// (M) Change in playback status of the current track
	 MBT_AVRCP_EV_TRACK_CHANGED	= 0x02, 		// (M) Change of current track
	 MBT_AVRCP_EV_REACHED_END	= 0x03, 		// (O) Reached end of a track
	 MBT_AVRCP_EV_REACHED_START	= 0x04, 		// (O) Reached start of a track
	 MBT_AVRCP_EV_PLAY_POS		= 0x05, 		// (O) Change in playback postion (specific interval)
	 MBT_AVRCP_EV_BATT_STATUS	= 0x06, 		// (O) Change in battery status
	 MBT_AVRCP_EV_SYSTEM_STATUS	= 0x07, 		// (O) Change in system status
	 MBT_AVRCP_EV_APP_SETTING	= 0x08, 		// (O) Cahnge in player applicatin setting
}T_MBT_AVRCP_EVENT_ID;

// AVRCP Player Application Settings Attribute 
typedef enum
{
	 MBT_AVRCP_ATTR_EQUALIZER_ON_OFF= 0x01,	// equalizer On/Off status
	 MBT_AVRCP_ATTR_REPEATE_MODE	= 0x02,	// Repeate Mode status
	 MBT_AVRCP_ATTR_SHUFFLE_ON_OFF	= 0x03,	// Shuffle On/Off status
	 MBT_AVRCP_ATTR_SCAN_ON_OFF		= 0x04,	// Scan On/Off status
}T_MBT_AVRCP_ATTR_ID;

// AVRCP List of Media Attributes
 typedef enum
{
	 MBT_AVRCP_ID_MEDIA_TITLE		= 0x01, 	// (M) Title of media
	 MBT_AVRCP_ID_ARTIST_NAME		= 0x02,	// (O) Name of the artist
	 MBT_AVRCP_ID_ALBUM_NAME		= 0x03, 	// (O) Name of the album
	 MBT_AVRCP_ID_MEDIA_NUM			= 0x04, 	// (O) Number of the media (Track number of the CD)
	 MBT_AVRCP_ID_MEDIA_TOT_NUM		= 0x05, 	// (O) Total number of the media (total track number of the CD)
	 MBT_AVRCP_ID_GENRE				= 0x06, 	// (O) Genre
	 MBT_AVRCP_ID_PLAYING_TIME		= 0x07, 	// (O) Playing time in millisecond
}T_MBT_AVRCP_MEDIA_ATTR_ID;

// AVRCP play status
 typedef enum
{
	MBT_AVRCP_PLAYSTATUS_STOPPED	= 0x00,	// Stopped 
	MBT_AVRCP_PLAYSTATUS_PLAYING,			// Playing
	MBT_AVCRP_PLAYSTATUS_PAUSED,			// Paused
	MBT_AVRCP_PLAYSTATUS_FWD_SEEK,			// Fast Forward Seek
	MBT_AVRCP_PLAYSTATUS_REV_SEEK,			// Rewind Seek
	MBT_AVRCP_PLAYSTATUS_ERROR,				// Error state
}T_MBT_AVRCP_PLAYSTATUS;

// AVRCP system status
 typedef enum
{
	MBT_AVRCP_SYSTEM_POWER_ON		= 0x00,	// Powered on
	MBT_AVRCP_SYSTEM_POWER_OFF,				// Powered off
	MBT_AVCRP_SYSTEM_UNPLUGGED,				// Unplugged
}T_MBT_AVRCP_SYSTEM;

// AVRCP battery status
typedef enum
{
	MBT_AVRCP_BATT_NORMAL = 0x0,				// Battery operation is in normal state
	MBT_AVRCP_BATT_WARNING,					// Unable to operate soon.
	MBT_AVRCP_BATT_CRITICAL,					// Can not operate any more.
	MBT_AVRCP_BATT_EXTERNAL,					// Connecting to external power supply
	MBT_AVRCP_BATT_FULL,						// When the evice is completely charged
}T_MBT_AVRCP_BATT_STATUS;


/*******************OBEX*******************/

// OBEX Storage type
typedef enum
{
	MBT_MEMORY_BUFFER = 0,	// memory buffer
	MBT_INTERNAL_FS,			// internal file system
	MBT_EXTERNAL_FS			// external file system
}T_MBT_OBJECT_STORAGE;

/*******************OPP*******************/

// OPP format
typedef enum
{
	MBT_OPP_VCARD21 = 0,	// vCard v2.1
	MBT_OPP_VCARD30,		// vCard v3.0
	MBT_OPP_VNOTE,		// vNote
	MBT_OPP_VCALENDAR,	// vCal
	MBT_OPP_ICAL,			// iCal
	MBT_OPP_VMESSAGE,		// vMsg
	MBT_OPP_OTHERS,		// others
	MBT_OPP_FORMAT_MAX	// for check MAX
}T_MBT_OPP_OBJECT_FORMAT;

// OPP Access request operation
typedef enum {
	MBT_OPS_PUSH,	// Remote����  Local�� Object �� ������ ���  
	MBT_OPS_PULL,	// Remote�� ��û���� Local�� Object�� Remote�� ���� ���
	MBT_OPC_PUSH,	// Local���� Remote�� Object ������ ���
	MBT_OPC_PULL,	// Local�� ��û���� Remote�� Object�� Local��  �������� ���
	MBT_OPC_EXCH_PUSH,	// Local�� ��û���� Remote�� Object�� ��ȯ�ϴ� ���(PUSH ó�� ��)
	MBT_OPC_EXCH_PULL		// Local�� ��û���� Remote�� Object�� ��ȯ�ϴ� ���(PULL ó�� ��)
}T_MBT_OPP_OPERATION;

// OPP authorization response
typedef enum
{
	MBT_FORBID_RES=0,				// authorization reject
	MBT_ALLOW_RES,				// authorization allow
	MBT_ERROR_RES,					// error response
	MBT_UNAUTHORIZED_RES,		//read only
	MBT_NOT_FOUND_RES,			//file not found
	MBT_UNSUPPORTED_MEDIA_TYPE_RES,	//unsupport type
	MBT_SERVICE_UNAVAILABLE_RES,			//unsupport function
	MBT_DATABASE_FULL_RES, 				//no space
	MBT_INTERNAL_SERVER_ERROR_RES,		//etc
//   �Ʒ��� �ʿ�� ��밡���� Error Type��. ����7�ǿ� ���� �� ���.
//	MBT_CONTINUE_RES							
//	MBT_SUCCESS_RES								
//	MBT_CREATED_RES								
//	MBT_ACCEPTED_RES							
//	MBT_NONAUTHORITATIVE_RES					
//	MBT_NO_CONTENT_RES							
//	MBT_RESET_CONTENT_RES						
//	MBT_PARTIAL_CONTENT_RES						
//	MBT_MULTI_CHOICES_RES						
//	MBT_MOVED_PERMANENTLY_RES					
//	MBT_MOVED_TEMPORARILY_RES					
//	MBT_SEE_OTHER_RES							
//	MBT_NOT_MODIFIED_RES						
//	MBT_USE_PROXY_RES							
//	MBT_BAD_REQUEST_RES													
//	MBT_PAYMENT_REQUIRED_RES					
//	MBT_FORBIDDEN_RES							
//	MBT_NOT_FOUND_RES							
//	MBT_METHOD_NOT_ALLOWED_RES					
//	MBT_NOT_ACCEPTABLE_RES							
//	MBT_PROXY_AUTHENTICATION_REQUIRED_RES		
//	MBT_REQUEST_TIME_OUT_RES					
//	MBT_CONFLICT_RES							
//	MBT_GONE_RES								
//	MBT_LENGTH_REQUIRED_RES						
//	MBT_PRECONDITION_FAILED_RES					
//	MBT_REQUESTED_ENTITY_TOO_LARGE_RES			
//	MBT_REQUEST_URL_TOO_LARGE_RES				
//	MBT_NOT_IMPLEMENTED_RES						
//	MBT_BAD_GATEWAY_RES							
//	MBT_GATEWAY_TIMEOUT_RES						
//	MBT_HTTP_VERION_NOT_SUPPORTED_RES			
//	MBT_DATABASE_LOCKED_RES						
}T_MBT_AUTHRES;

// OPP service state
typedef enum
{
	MBT_OPP_STATE_CLOSED,		// OPP ���񽺰� ��Ȱ��ȭ �� ����  (Default)
	MBT_OPP_STATE_IDLE,			// OPP ���񽺰� Ȱ��ȭ�� ���� 		(OPP�� Enable�� ����)
	MBT_OPP_STATE_CONNECTED,	// OPP ���񽺷� remote device�� ����� ����
	MBT_OPP_STATE_SENDING,		// ���� �۽� ���� ����
	MBT_OPP_STATE_PULLING,		// ����  PULL ���� ����
	MBT_OPP_STATE_RECEIVING		// ���� ���� ���� ����
}T_MBT_OPP_STATE;

/*******************FTP*******************/

// FTP Server Access Operation
typedef enum
{
	MBT_FTP_OPER_UNKNOWN,
	MBT_FTP_OPER_PUT,
	MBT_FTP_OPER_GET,
	MBT_FTP_OPER_DEL_FILE,
	MBT_FTP_OPER_DEL_DIR,
	MBT_FTP_OPER_CHG_DIR,
	MBT_FTP_OPER_MK_DIR,
	MBT_FTP_OPER_LIST_DIR
} T_MBT_FTP_OPERATION;

// FTP service state
typedef enum
{
	MBT_FTP_STATE_CLOSED,		// FTP ���񽺰� ��Ȱ��ȭ �� ����  (Default)
	MBT_FTP_STATE_IDLE,			// FTP ���񽺰� Ȱ��ȭ�� ���� (FTP�� Enable�� ����)
	MBT_FTP_STATE_CONNECTED,		// FTP ���񽺷� remote device�� ����� ����
	MBT_FTP_STATE_SENDING,		// ���� �۽� ���� ����
	MBT_FTP_STATE_RECEIVING		// ���� ���� ���� ����
}T_MBT_FTP_STATE;

/*******************BPP*******************/

// MIME Media Type
typedef enum
{
	MBT_MIME_TYPE_APPLICATION_XHTML_PRINT = 0,	// XHTML-Print 0.95(application/vnd.pwg-xhtml-print+xml:0.95)
	MBT_MIME_TYPE_APPLICATION_XHTML_PRINT10,	// XHTML-Print 0.95(application/vnd.pwg-xhtml-print+xml:1.0)
	MBT_MIME_TYPE_APPLICATION_MULTIPLEXED,		// Multiplexed (application/vnd.pwg-multiplexed)	
	MBT_MIME_TYPE_TEXT_PLAIN,					// Basic Text
	MBT_MIME_TYPE_TEXT_VCARD,					// vCard 2.1 (text/x-vcard:2.1)
	MBT_MIME_TYPE_TEXT_VCARD30,					// vCard 3.0 (text/x-vcard:3.0)
	MBT_MIME_TYPE_TEXT_VCALENDAR,				// vCal 1.0 (text/x-vcalendar:1.0)
	MBT_MIME_TYPE_TEXT_ICALENDAR20,				// iCal 2.0 (text/calendar:2.0)
	MBT_MIME_TYPE_TEXT_VMESSAGE,				// vMessage 1.1 (text/x-vmessage:1.1)
	MBT_MIME_TYPE_TEXT_VNOTE,					// vNote 1.1 (text/x-vnote:1.1)
	MBT_MIME_TYPE_IMAGE_JPEG,					// (image/jpeg)
	MBT_MIME_TYPE_IMAGE_GIF,						// (image/gif)
	MBT_MIME_TYPE_APPLICATION_POSTSCRIPT,		// (application/postscript)
	MBT_MIME_TYPE_APPLICATION_HP_PCL_5E,
	MBT_MIME_TYPE_APPLICATION_HP_PCL_3C,
	MBT_MIME_TYPE_APPLICATION_PDF,
	MBT_MIME_TYPE_REF_SIMPLE,
	MBT_MIME_TYPE_REF_XML,
	MBT_MIME_TYPE_REF_LIST,
	MBT_MIME_TYPE_SOAP,
	MBT_MIME_TYPE_REFERENCED_OBJ,
	MBT_MIME_TYPE_RUI,
	MBT_MIME_TYPE_IMG_IMG,
	MBT_MIME_TYPE_IMG_HEADER
}T_MBT_MIME_MEDIA;

//BPP Printer State
typedef enum
{
	MBT_PRINTER_ST_UNKNOWN = 0,			// Unknown
	MBT_PRINTER_ST_IDLE,					// Idle
	MBT_PRINTER_ST_PROCESSING,			// Processing
	MBT_PRINTER_ST_STOPPED				// Stopped
}T_MBT_BPP_PRINTER_STATE;

// BPP Printer State Reason
typedef enum
{
	MBT_PRINTER_SR_NONE = 0,				// No reason given
	MBT_PRINTER_SR_ATT_REQ,				// Attention required on the printer
	MBT_PRINTER_SR_MED_JAM,				// Media Jam
	MBT_PRINTER_SR_PAUSED,				// Paused
	MBT_PRINTER_SR_DOOR_OPEN,			// One or more covers on device are open
	MBT_PRINTER_SR_MED_LOW,				// At least one media tray is low
	MBT_PRINTER_SR_MED_EMPTY,			// At least one media tray is empty
	MBT_PRINTER_SR_OUTAREA_ALMOSTFULL,	// Output area almost full 
	MBT_PRINTER_SR_OUTAREA_FULL,		// Output area full
	MBT_PRINTER_SR_MARKER_LOW,			// Device low on ink or toner
	MBT_PRINTER_SR_MARKER_EMPTY,		// Device out of ink or toner
	MBT_PRINTER_SR_MARKER_FAILURE		// Device ink cartridge or toner ribbon error
}T_MBT_BPP_PRINTER_STATE_REASON;

// BPP Print Job State
typedef enum
{
	MBT_PRINT_JOBSTATE_PRINTING = 1,		// When the remote device receives and prints data
	MBT_PRINT_JOBSTATE_WAITING,			// When the sender waits for the printer (remote device)
	MBT_PRINT_JOBSTATE_STOPPED,			// The print-session has stopped for some reason
	MBT_PRINT_JOBSTATE_COMPLETED,		// When the print-session has ended successfully
	MBT_PRINT_JOBSTATE_ABORTED,			// The print-session has been aborted
	MBT_PRINT_JOBSTATE_CANCELLED,		// The print-session has been canceled
	MBT_PRINT_JOBSTATE_UNKNOWN			// An unknown event has happen during a print-session
}T_MBT_BPP_PRINT_JOB_STATE;

// BPP Media Type
typedef enum
{
	MBT_MTYPE_UNDEF = 0,
	MBT_MTYPE_STATIONERY,
	MBT_MTYPE_STATIONERY_COATED,
	MBT_MTYPE_STATIONERY_INKJET,
	MBT_MTYPE_STATIONERY_PREPRINTED,
	MBT_MTYPE_STATIONERY_LETTERHEAD,
	MBT_MTYPE_STATIONERY_PREPUNCHED,
	MBT_MTYPE_STATIONERY_FILE,
	MBT_MTYPE_STATIONERY_HEAVYWEIGHT,
	MBT_MTYPE_STATIONERY_LIGHTWEIGHT,
	MBT_MTYPE_TRANSPARENCY,
	MBT_MTYPE_ENVELOPE,
	MBT_MTYPE_ENVELOPE_PLAIN,
	MBT_MTYPE_ENVELOPE_WINDOW,
	MBT_MTYPE_CONTINUOUS,
	MBT_MTYPE_CONTINUOUS_LONG,
	MBT_MTYPE_CONTINUOUS_SHORT,
	MBT_MTYPE_TAB_STOCK,
	MBT_MTYPE_PRE_CUT_TABS,
	MBT_MTYPE_FULL_CUT_TABS,
	MBT_MTYPE_MULTI_PART_FORM,
	MBT_MTYPE_LABELS,
	MBT_MTYPE_MULTI_LAYER,
	MBT_MTYPE_SCREEN,
	MBT_MTYPE_SCREEN_PAGED,
	MBT_MTYPE_PHOTOGRAPHIC,
	MBT_MTYPE_PHOTOGRAPHIC_GLOSSY,
	MBT_MTYPE_PHOTOGRAPHIC_HIGH_GLOSS,
	MBT_MTYPE_PHOTOGRAPHIC_SEMI_GLOSS,
	MBT_MTYPE_PHOTOGRAPHIC_SATIN,
	MBT_MTYPE_PHOTOGRAPHIC_MATTE,
	MBT_MTYPE_PHOTOGRAPHIC_FILM,
	MBT_MTYPE_BACK_PRINT_FILM,
	MBT_MTYPE_CARDSTOCK,
	MBT_MTYPE_ROLL
}T_MBT_BPP_MEDIA;

// BPP State
typedef enum
{
	MBT_BPP_STATE_DISABLED = 0,		// BPP ���񽺰� ��Ȱ��ȭ�� ����  (Default)
	MBT_BPP_STATE_ENABLED,			// BPP ���񽺰� Ȱ��ȭ �� ����
	MBT_BPP_STATE_CONNECTING,		// BPP ���񽺸� remote device(Printer)�� �������� ����
	MBT_BPP_STATE_CONNECTED,			// BPP ���񽺷� remote device(Printer)�� ����� ����
	MBT_BPP_STATE_DISCONNECTING, 	// BPP ���� ���� �����ϴ� ����
	MBT_BPP_STATE_GETATTRIBUTE,
	MBT_BPP_STATE_PRINTING	 		// BPP�� Print ���� ����
}T_MBT_BPP_STATE;

/*******************BIP*******************/

// BIP State
typedef enum
{
	MBT_BIP_STATE_DISABLED = 0,		// BIP ���񽺰� ��Ȱ��ȭ�� ����  (Default)
	MBT_BIP_STATE_ENABLED,			// BIP ���񽺰� Ȱ��ȭ �� ����
	MBT_BIP_STATE_CONNECTING,		// BIP ���񽺸� remote device�� �������� ����
	MBT_BIP_STATE_CONNECTED,			// BIP ���񽺷� remote device�� ����� ����
	MBT_BIP_STATE_DISCONNECTING, 	// BIP ���� ���� �����ϴ� ����
	MBT_BIP_STATE_SENDING,			// ���� �۽� ���� ����	
	MBT_BIP_STATE_RECEIVING			// ���� ���� ���� ����
}T_MBT_BIP_STATE;

// BIP Operation
typedef enum
{	 
	MBT_BIP_OP_INIT_GETCAPABILITY,
	MBT_BIP_OP_INIT_PUSHIMAGE,
	MBT_BIP_OP_INIT_PUSHTHUMBNAIL,
	MBT_BIP_OP_RESP_GETCAPABILITY,
	MBT_BIP_OP_RESP_PUSHIMAGE,
	MBT_BIP_OP_RESP_PUSHTHUMBNAIL	
 } T_MBT_BIP_OP;

// BIP Transformation
typedef enum
{
	MBT_BIP_TRANS_NONE = 0,
	MBT_BIP_TRANS_STRETCH,
	MBT_BIP_TRANS_FILL,
	MBT_BIP_TRANS_CROP
}T_MBT_BIP_TRANS;

/*******************JSR82*******************/

// JSR82 SDP attribute
typedef enum
{
    MBT_JSR82_SD_ATTR_UNKNOWN=0,
    MBT_JSR82_SD_ATTR_UUID_LIST,
    MBT_JSR82_SD_ATTR_PROTO_DESC_LIST,
    MBT_JSR82_SD_ATTR_LANG_BASE_ATTR_ID_LIST,
    MBT_JSR82_SD_ATTR_UINT_LIST,
    MBT_JSR82_SD_ATTR_STRING,
    MBT_JSR82_SD_ATTR_UINT8,
    MBT_JSR82_SD_ATTR_UINT16,
    MBT_JSR82_SD_ATTR_UINT32,
    MBT_JSR82_SD_ATTR_UINT64,
    MBT_JSR82_SD_ATTR_BOOL,
    MBT_JSR82_SD_ATTR_UUID,
    MBT_JSR82_SD_ATTR_UUID128,
    MBT_JSR82_SD_ATTR_ADDL_PROTO_DESC_LISTS,
    MBT_JSR82_SD_ATTR_UINT128,
    MBT_JSR82_SD_ATTR_HID_DESC_LIST,
}T_MBT_JSR82_SD_ATTR;


/*******************PBAP*******************/

// PBAP VCARD Version
 typedef enum
{
	MBT_PBAP_VCARD_VER21 = 0,
	MBT_PBAP_VCARD_VER30
}T_MBT_PBAP_VCARD_VERSION;

typedef enum
{
	MBT_PBAP_REPOSIT_INTERNAL = 0,
	MBT_PBAP_REPOSIT_SIM
}T_MBT_PBAP_STORAGE;

typedef enum
{
	MBT_PBAP_DIR_PB = 0,	//phonebook
	MBT_PBAP_DIR_ICH,		//incoming call history
	MBT_PBAP_DIR_OCH,		//outgoing call history
	MBT_PBAP_DIR_MCH,		//missed call history
	MBT_PBAP_DIR_CCH		//combined call history
}T_MBT_PBAP_DIR;

typedef enum
{
	MBT_PBAP_SORT_HANDLE = 0,		//sort by vcard handle(Default)
	MBT_PBAP_SORT_NAME,			//sort by name field
	MBT_PBAP_SORT_SOUND			//sort by sound field
}T_MBT_PBAP_SORT;

typedef enum
{
	MBT_PBAP_SEARCH_NAME=0,		//search by name field(Default)
	MBT_PBAP_SEARCH_NUMBER,		//search by vcard number
	MBT_PBAP_SEARCH_SOUND		//search by sound field
}T_MBT_PBAP_SEARCH;

typedef enum
{
	MBT_PBAP_OP_PULL_DIRECTORY_DATA = 0,	//��ü ���� ���
	MBT_PBAP_OP_PULL_DIRECTORY_LIST,		//����Ʈ ���� ���
	MBT_PBAP_OP_PULL_DIRECTORY_NUM,			//��û�� Directory�� ��ü ���� ����
	MBT_PBAP_OP_PULL_ONE_VCARD				//��û�� vCard �ϳ� ������ ���
}T_MBT_PBAP_OP;

typedef enum
{
	MBT_PBAP_STATE_DISABLED=0,	//PBAP ���� ��Ȱ��ȭ ����
	MBT_PBAP_STATE_ENABLED,		//PBAP ���� Ȱ��ȭ ����
	MBT_PBAP_STATE_CONNECTED,	//PBAP ���񽺰� remote device�� ����� ����
	MBT_PBAP_STATE_SENDING		//PBAP �۽����� ����
}T_MBT_PBAP_STATE;

/*******************HID*******************/

typedef enum
{
	MBT_HID_OP_SET_REPORT = 0,	//Set Report ���� ���
	MBT_HID_OP_GET_REPORT,		//Get Report ���� ���
	MBT_HID_OP_SET_IDLE,			//Set Idle ���� ���
	MBT_HID_OP_GET_IDLE,			//Get Idle ���� ���
	MBT_HID_OP_SET_PROTOCOL,		//Set Protocol ���� ���
	MBT_HID_OP_GET_PROTOCOL,		//Get Protocol ���� ���
	MBT_HID_OP_SEND_REPORT,		//Report Data ���� ���
	MBT_HID_OP_SEND_CONTROL,		//Control Command ���� ���
	MBT_HID_OP_MAX
}T_MBT_HID_OP;

typedef enum
{
	MBT_HID_STATE_NO_CONNECTION=0,	// ������� ���� ����
	MBT_HID_STATE_CONNECTING,		// ����õ����� ����
	MBT_HID_STATE_CONNECTED,			// ����� ����
	MBT_HID_STATE_DISCONNECTING		// ���� ���� ���� ����
}T_MBT_HID_STATE;

typedef enum
{
	MBT_HID_ROLE_PHONE=0,	// Phone Role
	MBT_HID_ROLE_KEYBOARD,	// Keyboard ����
	MBT_HID_ROLE_MOUSE		// Mouse ����
}T_MBT_HID_ROLE;

typedef enum
{
	HID_U_LED_UNDEFINED,
	HID_U_LED_NUM_LOCK,
	HID_U_LED_CAPS_LOCK,
	HID_U_LED_SCROLL_LOCK,
	HID_U_LED_COMPOSE,
	HID_U_LED_KANA
} T_HID_MBT_LED_TYPE;


typedef enum
{
	HID_U_KBD_RESERVED = 0x00,
	HID_U_KBD_ERROR_ROLL_OVER,
	HID_U_KBD_POST_FAIL,
	HID_U_KBD_ERROR_UNDEFINED,
	HID_U_KBD_A,
	HID_U_KBD_B,
	HID_U_KBD_C,
	HID_U_KBD_D,
	HID_U_KBD_E,
	HID_U_KBD_F,
	HID_U_KBD_G,
	HID_U_KBD_H,
	HID_U_KBD_I,
	HID_U_KBD_J,
	HID_U_KBD_K,
	HID_U_KBD_L,

	HID_U_KBD_M = 0x10,
	HID_U_KBD_N,
	HID_U_KBD_O,
	HID_U_KBD_P,
	HID_U_KBD_Q,
	HID_U_KBD_R,
	HID_U_KBD_S,
	HID_U_KBD_T,
	HID_U_KBD_U,
	HID_U_KBD_V,
	HID_U_KBD_W,
	HID_U_KBD_X,
	HID_U_KBD_Y,
	HID_U_KBD_Z,
	HID_U_KBD_1,
	HID_U_KBD_2,

	HID_U_KBD_3 = 0x20,
	HID_U_KBD_4,
	HID_U_KBD_5,
	HID_U_KBD_6,
	HID_U_KBD_7,
	HID_U_KBD_8,
	HID_U_KBD_9,
	HID_U_KBD_0,
	HID_U_KBD_RETURN,
	HID_U_KBD_ESCAPE,		// ESC
	HID_U_KBD_BACKSPACE,
	HID_U_KBD_TAB,
	HID_U_KBD_SPACEBAR,
	HID_U_KBD_MINUS,		// -
	HID_U_KBD_EQUAL,		// =
	HID_U_KBD_LEFT_BRACKET,	// [ and {

	HID_U_KBD_RIGHT_BRACKET = 0x30,	// ] and }
	HID_U_KBD_BACK_SLASH,		// \ and |
	HID_U_KBD_POUND_NON_US,		// #
	HID_U_KBD_SEMICOLON,		// ; and :
	HID_U_KBD_QUOTATION,		// ' and "
	HID_U_KBD_GRAVE_ACCENT,	// ` and ~
	HID_U_KBD_COMMA,		// , and <
	HID_U_KBD_POINT,		// . and >
	HID_U_KBD_SLASH,		// / and ?
	HID_U_KBD_CAPS_LOCK,
	HID_U_KBD_F1,
	HID_U_KBD_F2,
	HID_U_KBD_F3,
	HID_U_KBD_F4,
	HID_U_KBD_F5,
	HID_U_KBD_F6,

	HID_U_KBD_F7 = 0x40,
	HID_U_KBD_F8,
	HID_U_KBD_F9,
	HID_U_KBD_F10,
	HID_U_KBD_F11,
	HID_U_KBD_F12,
	HID_U_KBD_PRINT_SCREEN,
	HID_U_KBD_SCROLL_LOCK,
	HID_U_KBD_PAUSE,
	HID_U_KBD_INSERT,
	HID_U_KBD_HOME,
	HID_U_KBD_PAGEUP,
	HID_U_KBD_DELETE,
	HID_U_KBD_END,
	HID_U_KBD_PAGEDOWN,
	HID_U_KBD_RIGHT_ARROW,

	HID_U_KBD_LEFT_ARROW = 0x50,
	HID_U_KBD_DOWN_ARROW,
	HID_U_KBD_UP_ARROW,
	HID_U_KPD_NUM_LOCK,
	HID_U_KPD_DEVIDE,		// /
	HID_U_KPD_MULTIPLY,		// *
	HID_U_KPD_MINUS,		// -
	HID_U_KPD_PLUS,		// +
	HID_U_KPD_ENTER,
	HID_U_KPD_1,		// 1 and End
	HID_U_KPD_2,		// 2 and Down Arro2
	HID_U_KPD_3,		// 3 and PageDn
	HID_U_KPD_4,		// 4 and Left Arrow
	HID_U_KPD_5,		// 5
	HID_U_KPD_6,		// 6 and Right Arrow
	HID_U_KPD_7,		// 7 and Home

	HID_U_KPD_8 = 0x60,		// 8 and Up Arrow
	HID_U_KPD_9,		// 9 and PageUp
	HID_U_KPD_0,		// 0 and Insert
	HID_U_KPD_POINT,	// . and Delete
	HID_U_KBD_BACK_SLASH_NON_US,		// Non-US \ and |
	HID_U_KBD_APPLICATION,		// near Right Control Key, usually Print Key
	HID_U_KBD_POWER,
	HID_U_KPD_EQUAL,	// =

	HID_U_KBD_F18 = 0x6D, //F18, stowaway Left Fn + up
	HID_U_KBD_F20 = 0x6F, //F20, stowaway Left Fn + left
	HID_U_KBD_F21 = 0x70, //F21, Stowaway Left Fn + down
	HID_U_KBD_F22 = 0x71, //F22, Stowaway Left Fn + right
	HID_U_KBD_F23 = 0x72, //F23, stowaway Left Fn
	HID_U_KBD_F24 = 0x73, //F24, Stowaway Right Fn

	HID_U_KBD_LEFT_CONTROL = 0xE0,
	HID_U_KBD_LEFT_SHIFT,
	HID_U_KBD_LEFT_ALT,
	HID_U_KBD_LEFT_GUI,
	HID_U_KBD_RIGHT_CONTROL,
	HID_U_KBD_RIGHT_SHIFT,
	HID_U_KBD_RIGHT_ALT,
	HID_U_KBD_RIGHT_GUI
} T_MBT_HID_KEY_TYPE;

/*******************TEST*******************/
typedef enum
{
	MBT_TEST_FCC_NULL = 0,		// NULL mode
	MBT_TEST_FCC_MODE1 = 1,	// DH5 LOW  2402
	MBT_TEST_FCC_MODE2,		// DH5 MID  2441
	MBT_TEST_FCC_MODE3,		// DH5 HIGH 2480
	MBT_TEST_FCC_MODE4,		// DH1 MID  2441
	MBT_TEST_FCC_MODE5,		// DH3 MID  2441
	MBT_TEST_FCC_MODE6,		// DH5 HOP
	MBT_TEST_FCC_MODE7		// Receive Mode
}T_MBT_TEST_MODE;


/***************JSR82***************/

typedef enum
{
	MBT_JSR82_SD_DATA_ELEMENT_NULL	= 0,			//Nil, the null type
	MBT_JSR82_SD_DATA_ELEMENT_UNSIGNED_INT,	//Unsigned integer
	MBT_JSR82_SD_DATA_ELEMENT_SIGNED_INT,		//Signed 2s-complement integer
	MBT_JSR82_SD_DATA_ELEMENT_UUID,				//UUID
	MBT_JSR82_SD_DATA_ELEMENT_TEXT_STRING,		 //Text string
	MBT_JSR82_SD_DATA_ELEMENT_BOOL,
	MBT_JSR82_SD_DATA_ELEMENT_SEQUENCE,		//Data element sequence
	MBT_JSR82_SD_DATA_ELEMENT_ALTERNATIVE,		//Data element alternative
	MBT_JSR82_SD_DATA_ELEMENT_URL,				//Uniform resource locator
	MBT_JSR82_SD_DATA_ELEMENT_RESERVED			//Reserved
} T_MBT_JSR82_SD_DATA_ELEMENT_TYPE;

/***************OBEX Protocol***************/
typedef enum
{
	MBT_OBEX_SERVER_NO_CONNECTION=0,	// ������� ���� ����
	MBT_OBEX_SERVER_CONNECTING,			// ����õ����� ����
	MBT_OBEX_SERVER_CONNECTED,			// ����� ����
	MBT_OBEX_SERVER_DISCONNECTING		// ���� ���� ���� ����
}T_MBT_OBEX_STATE;
/********************************************************************************
*						ENUM TYPE DEFINE END
********************************************************************************/



/********************************************************************************
*						DATA TYPE DEFINE START
********************************************************************************/

/*******************GAP*******************/

// My device(local) information
typedef struct
{
	T_MBT_BDADDR	BdAddr;						// BD_ADDR
	MBT_CHAR		Name[MBT_MAX_NAME_LEN+1];	// BT NAME
	MBT_BOOL		bOnOff;						// power on/off status
	MBT_BOOL		bVisible;					// visible/hidden status
	MBT_BOOL		bConnectable;				// connectable status
	MBT_BYTE		MajorClass;					// Major class CoD
	MBT_BYTE		MinorClass;					// Minor class CoD
	MBT_SHORT		ServiceClass;				// Service class CoD
} T_MBT_MYINFO;

// SDP feature
typedef struct
{
	MBT_BOOL                    bAvrcpCategorySearched;         // category value is valid?
	MBT_BYTE		AvrcpCategoryBitmapTG;		// category bitmap of peer device (AVRCP Target)
}T_MBT_SDP_FEATURE_LIST;

// service list list
typedef struct
{
	MBT_INT					nServiceCount;					//���� ����
	MBT_SERVICE_ID			Service[MBT_MAXNUM_SVC_FIELD];	//���� 
	T_MBT_SDP_FEATURE_LIST	Feature;						//SDP feautre list
}T_MBT_SERVICE_LIST;

// searched device information
typedef struct
{
	T_MBT_BDADDR		BdAddr; 					// BD_ADDR
	MBT_CHAR			Name[MBT_MAX_NAME_LEN+1];	// BT device name	
	MBT_BOOL			bPaired;						// ã�� ��ġ �� ����
	MBT_BYTE			MajorClass;					// Major class CoD
	MBT_BYTE			MinorClass;					// Minor class CoD
	MBT_SHORT			ServiceClass;				// Service class CoD
	MBT_BOOL			bEirSupport;					// ��� ��ġ�� EIR ���� ����
	T_MBT_SERVICE_LIST	ServiceList;					// EIR ������ ��� : Svc UUID list
} T_MBT_SEARCHED_DEV_INFO;

// searched device list
typedef struct	
{
	MBT_INT						SearchCount;		// ã�� ��ġ ����
	T_MBT_SEARCHED_DEV_INFO	SearchList[MBT_MAXNUM_SEARCH_DEV];	// searched device information
} T_MBT_SEARCHED_DEV_LIST;

// paired device information
typedef struct
{
	T_MBT_BDADDR				BdAddr; 						// BD_ADDR
	MBT_CHAR					Name[MBT_MAX_NAME_LEN+1];		// BT device name
	MBT_CHAR					NickName[MBT_MAX_NAME_LEN+1];	// BT device nickname
	T_MBT_SERVICE_LIST			ServiceList;			// supported Serivces
	MBT_BOOL					bAuthorized;		// Device Trust (not service authorize!)

	//Full CoD
	MBT_BYTE					MajorClass;			// Major class CoD
	MBT_BYTE					MinorClass;			// Minor class CoD
	MBT_SHORT					ServiceClass;		// Servcie class CoD

	MBT_BOOL					bLinkKeyValid;		// linkkey valid status
	T_MBT_LINKKEY				LinkKey;			// linkkey
	T_MBT_GAP_SECURITY			Security;			// security type

} T_MBT_PAIRED_DEV_INFO;

// paired device list
typedef struct	
{
	MBT_INT						PairedCount;						// paired device ����
	T_MBT_PAIRED_DEV_INFO		PairedList[MBT_MAXNUM_PAIRED_DEV];	// paired device information
	MBT_BOOL					bLock;								// paired list write protect. TRUE : Locked, FALSE : Released
} T_MBT_PAIRED_DEV_LIST;

// name response 
typedef struct
{
	T_MBT_BDADDR				BdAddr;						// BD_ADDR
	MBT_CHAR					Name[MBT_MAX_NAME_LEN+1];	//remote name
} T_MBT_NAME_RES;

// service discovery response
typedef struct
{
	T_MBT_BDADDR				BdAddr;			// BD_ADDR
	T_MBT_SERVICE_LIST			ServiceList;		// services of remote
} T_MBT_SVC_RES;

// pin reply
typedef struct
{
	T_MBT_BDADDR				BdAddr;						// BD_ADDR
	MBT_CHAR					Name[MBT_MAX_NAME_LEN+1];	// remote name
	MBT_SHORT					MajorClass;					// major class CoD
	MBT_SHORT					MinorClass;					// minor class CoD
	MBT_SHORT					ServiceClass;				// service class CoD
} T_MBT_PINREPLY;

// authorization reply type 
typedef struct
{
	T_MBT_BDADDR				BdAddr;						// BD_ADDR
	MBT_CHAR					Name[MBT_MAX_NAME_LEN+1];	// remote name
/*DO NOT UES this Variable. will be expire soon.*/MBT_BOOL bAuthorize;/*DO NOT UES this Variable. will be expire soon.*/
} T_MBT_AUTHREPLY;

// Simple pairing
typedef struct
{
	T_MBT_GAP_SSP_MODEL		AssoModel;			//Model of SSP. See T_MBT_GAP_SSP_MODEL 
	T_MBT_BDADDR				BdAddr;				//remote addr
	MBT_BYTE					MajorClass;			//Major class CoD
	MBT_BYTE					MinorClass;			//Minor class CoD
	MBT_SHORT					ServiceClass;		//Service class CoD
	MBT_CHAR					Name[MBT_MAX_NAME_LEN+1];	//remote name	
	MBT_UINT					nKeyValue; 			//JustWorks: not use, Num Comp.:valeu, Passkey entry: passkey, oop: N/A
} T_MBT_SSP;

// Link up/donw information
typedef struct
{
	T_MBT_BDADDR				LastLinkUp;			//Last Link up device
	T_MBT_BDADDR				LastLinkDown;		//Last Link Down device
	MBT_UINT					LinkCounter;			//Exist link counter
} T_MBT_LINK_UPDOWN;
	
// Pair error response
typedef struct
{
    MBT_BOOL					bIsValid;        	//ErrReason value is valid or not
    T_MBT_PAIR_ERR_REASON    	ErrReason;    	//Error reason
}T_MBT_PAIR_ERR_RSP;

//Block device
typedef struct
{
	MBT_INT			BlockedCount;							//Blocked device counter
	T_MBT_BDADDR	BlockDevList[MBT_MAXNUM_BLOCK_DEV];	//Blocked device list
}T_MBT_BLOCKED_DEV_LIST;


/*******************AG********************/

// dial
typedef struct
{
	T_MBT_AG_DIAL	DialType;	// call type
	MBT_INT			DialNum;	// length
	MBT_CHAR		Digit[MBT_MAX_DIALNUM_LEN+1]; // ��ȭ ��ȣ
} T_MBT_AG_DIALINFO;

// 3way call(chld)
typedef struct
{
	MBT_BYTE	CHLDValue;		// chld value
	MBT_BOOL	bIsExtended;	// call index use or not
	MBT_BYTE	CallIndex;		// call index
} T_MBT_AG_3WAY;

// dtmf
typedef struct
{
	MBT_BYTE	Digit;			// dtmf
} T_MBT_AG_DTMF;

// volume control
typedef struct
{
	MBT_BYTE	VolumeLevel;	// volume level
} T_MBT_AG_SPKGAIN;

// HSP/HFP AG status
typedef struct
{
	MBT_BOOL			bEnalbed;
	MBT_BOOL			bNonDefaultMultiFuncKey;
	MBT_BOOL			bConection;				// connection status
	MBT_BOOL			bAudioPath;				// audio path
    MBT_BOOL            bSupportBVRA;           // Remote Device support BVRA or Not
    MBT_BOOL            bSupportRemoteVolCtrl;           // Remote Device support Remote Volume Control or Not
	T_MBT_AG_STATE		AgState;				// state
	T_MBT_BDADDR		BdAddr;					// BD_ADDR
	T_MBT_AG_PHONE_CALLSTATE	PhoneCallState;	// Call state
} T_MBT_AG_STATUS;

// indication
typedef struct
{
	T_MBT_AG_NETSTATE		bNetStatus;			// network status
	T_MBT_AG_CALLSTATUS	bCallStatus;			// call status
	T_MBT_AG_CALLSETUP		bCallSetupStatus;	// call setup status
	MBT_BYTE				bSignalLevel;		// RSSI
	MBT_BYTE				bRoamingStatus;		// roaming status
	MBT_BYTE				bBatteryLevel;		// battery level
	T_MBT_AG_CALL_HELD		bHeldStatus;			// held call indication
} T_MBT_AG_INDICATION;

typedef struct
{
	MBT_BOOL			bResult;
	T_MBT_AG_CME_ERR	bErrorCode;
}T_MBT_AG_PB_RETURN;

// phonebook record
typedef struct
{
	MBT_SHORT	bIndex;
	MBT_CHAR	number[MBT_AG_PB_MAXLEN_NUM+1];
	MBT_BYTE	bType;	// number type(type of address octet in integer format)
	MBT_CHAR	text[MBT_AG_PB_MAXLEN_TXT+1];
} T_MBT_AG_PB_REC;

// phonebook cpbs req
typedef struct
{
	MBT_BYTE			bSupportedNum;
	T_MBT_AG_PB_DEV	pbType[MBT_AG_PB_DEV_MAX];
	T_MBT_AG_PB_DEV	selectedPbType;
} T_MBT_AG_PB_CPBS;

// phonebook cpbr req
typedef struct
{
	MBT_SHORT	bStartIdx;
	MBT_SHORT	bEndIdx;
} T_MBT_AG_PB_CPBR;

// phonebook cpbf req
typedef struct
{
	MBT_CHAR	findText[MBT_AG_PB_MAXLEN_TXT+1];
} T_MBT_AG_PB_CPBF;

// phonebook cpbw req
typedef struct
{
	MBT_BOOL		erase;
	MBT_SHORT		index;
	MBT_CHAR		phoneNum[MBT_AG_PB_MAXLEN_NUM+1];
	MBT_BYTE		bType;	// number type(type of address octet in integer format)
	MBT_CHAR		text[MBT_AG_PB_MAXLEN_TXT+1];
} T_MBT_AG_PB_CPBW;

// manufacturer and model ID req
typedef struct
{
	MBT_CHAR	manufacturerID[MBT_AG_CGM_LEN+1];	// CGMI
	MBT_CHAR	modelID[MBT_AG_CGM_LEN+1];		// CGMM
} T_MBT_AG_CGM_ID;

// Character set request
typedef struct
{
	MBT_CHAR		AGCharSetList[MBT_AG_CSCS_NUM][8];		//AG -> HF send Character set list
	MBT_CHAR		HFCharSet[8];				//HF ->AG send Character set
	MBT_CHAR		CurrentCharSet[8];				//HF ->AG send Character set	
}T_MBT_AG_CSCS;

/*******************DUN*******************/

// DUN status
typedef struct
{
	MBT_BOOL		bEnabled;
	T_MBT_DUN_STATE	State;
	T_MBT_BDADDR	BdAddr;		// remote device BD_ADDR
} T_MBT_DUN_STATUS;

/*******************SPP*******************/

// SPP Tx/Rx data 
typedef struct
{
	T_MBT_BDADDR	BdAddr;	// remote device BD_ADDR
	MBT_SHORT		Length;	// Tx/Rx data ũ��
	MBT_BYTE		*Buf;	// TX/RX data�� address
} T_MBT_SPP_DATA ;

// SPP status
typedef struct
{
	MBT_BOOL	bEnabled;
	MBT_BOOL	bConection; 
	T_MBT_BDADDR	BdAddr; 
	T_MBT_SPP_DATA	sdcSPPTxData[MBT_SPP_MAX_CONN_NUM];
	T_MBT_SPP_DATA	sdcSPPRxData[MBT_SPP_MAX_CONN_NUM];
} T_MBT_SPP_STATUS;

/*******************A2DP********************/

// A2DP
typedef struct
{
	T_MBT_BDADDR			BdAddr;
	T_MBT_A2DP_CONSTATUS	ConStatus;	// connection status
}T_MBT_A2DP_DATA;

// A2DP status
typedef struct
{
	MBT_BOOL				bEnabled;	// a2dp's enable
	MBT_BYTE                		ConNum;	// Number of connections
	T_MBT_A2DP_CHANNEL		Type;		// audio source channel
	T_MBT_A2DP_DATA		A2dpConn[MBT_A2DP_MAX_CONN_NUM];
}T_MBT_A2DP_STATUS;

/*******************VDP********************/

// VDP
typedef struct
{
	T_MBT_AV_CODECTYPE	CodecType;
	MBT_SHORT	CodecLevel1;
	MBT_SHORT	CodecLevel2;
}T_MBT_VDP_CODECINFO;

typedef struct
{
	MBT_SHORT	FrameRate;
	MBT_SHORT	FrameWidth;
	MBT_SHORT	FrameHeight;
}T_MBT_VDP_VIDEO_STREAMINFO;

typedef struct
{
	MBT_BYTE	Channel;
	MBT_BOOL	bVbr;
	MBT_UINT	SamplingRate;
	MBT_SHORT	BitRate;
	MBT_SHORT	FrameRrate;
}T_MBT_VDP_AUDIO_STREAMINFO;

typedef struct
{
	T_MBT_BDADDR			BdAddr;
	T_MBT_AV_MEDIATYPE		MediaType;
	T_MBT_VDP_CODECINFO		CodecInfo;
	T_MBT_VDP_VIDEO_STREAMINFO	vStreamInfo;
	T_MBT_VDP_AUDIO_STREAMINFO	aStreamInfo;
	T_MBT_VDP_CONSTATUS		ConStatus;	// connection status
}T_MBT_VDP_DATA;

// VDP status
typedef struct
{
	MBT_BOOL			bEnabled;	// VDP's enable
	T_MBT_VDP_ROLE		VdpRole;
	MBT_BYTE			ConNum;	// Number of connections
	T_MBT_VDP_DATA		VdpConn[MBT_VDP_MAX_CONN_NUM];
}T_MBT_VDP_STATUS;

/******************OBEX Protocol*******************/
typedef struct
{
	MBT_UINT	ServerHandle;	//Enabled server handle
	MBT_BYTE	scn;				//Enabled server scn
} T_MBT_OBEX_SERVER_ENABLE_SUCCESS;

//ConnectRequest
typedef struct
{
	MBT_UINT	ServerHandle;
	T_MBT_BDADDR RemoteDevAddr;
	T_MBT_OBEX_OPCODE	OpCode;
	MBT_SHORT	EvtLength;
//	MBT_SHORT	RemotePacketMaxSize; -> Move to T_MBT_OBEX_SERVER_CONNECT_SUCCESS. MTU Size control by BT Stack.
	MBT_BYTE *	pObexHeader;
}T_MBT_OBEX_SERVER_CONNECT_REQ;

//Connected
typedef struct
{
	MBT_UINT	ServerHandle;
	T_MBT_BDADDR RemoteDevAddr;
	MBT_SHORT	RemotePacketMaxSize;	//MTU Size
//	T_MBT_OBEX_OPCODE	OpCode;
//	MBT_SHORT	EvtLength;
//	MBT_SHORT	RemotePacketMaxSize;
}T_MBT_OBEX_SERVER_CONNECT_SUCCESS;

//DisConnectRequest
typedef struct
{
	MBT_UINT	ServerHandle;
	T_MBT_BDADDR RemoteDevAddr;
	T_MBT_OBEX_OPCODE	OpCode;
	MBT_SHORT	EvtLength;
	MBT_BYTE *	pObexHeader;
}T_MBT_OBEX_SERVER_DISCONNECT_REQ;

//DisConnected
typedef struct
{
	MBT_UINT	ServerHandle;
	T_MBT_BDADDR RemoteDevAddr;
//	T_MBT_OBEX_OPCODE	OpCode;
//	MBT_SHORT	EvtLength;
}T_MBT_OBEX_SERVER_DISCONNECT_SUCCESS;

//AbortRequest
typedef struct
{
	MBT_UINT	ServerHandle;
	T_MBT_BDADDR RemoteDevAddr;
	T_MBT_OBEX_OPCODE	OpCode;
	MBT_SHORT	EvtLength;
	MBT_BYTE *	pObexHeader;
}T_MBT_OBEX_SERVER_ABORT_REQ;

//SetPath
typedef struct
{
	MBT_UINT	ServerHandle;
	T_MBT_BDADDR RemoteDevAddr;
	T_MBT_OBEX_OPCODE	OpCode;
	MBT_SHORT	EvtLength;
	MBT_BOOL	Backup;
	MBT_BOOL	NoCreate;
	MBT_BYTE *	pObexHeader;
}T_MBT_OBEX_SERVER_SETPATH_REQ;

//Put
typedef struct
{
	MBT_UINT	ServerHandle;
	T_MBT_OBEX_OPCODE OpCode;
	MBT_SHORT	EvtLength;
	MBT_BYTE *	pObexHeader;
}T_MBT_OBEX_SERVER_PUT_REQ;

//Get
typedef struct
{
	MBT_UINT	ServerHandle;
	T_MBT_OBEX_OPCODE OpCode;
	MBT_SHORT	EvtLength;
	MBT_BYTE *	pObexHeader;
}T_MBT_OBEX_SERVER_GET_REQ;

//for response cmd
typedef struct
{
	//T_MBT_OBEX_OPCODE 	OpCode;
	T_MBT_OBEX_RES 		ResCode;
	MBT_SHORT			EvtLength;
	MBT_BYTE *			pObexHeader;
}T_MBT_OBEX_RESPONSE;

typedef struct
{
	MBT_CHAR 		svcName[30];	//Service Name
	MBT_SERVICE_ID	svcUuid;		//Service UUID
}T_MBT_OBEX_SERVICE_INFO;

typedef struct
{
	MBT_BOOL		bEnabled;		//Is server activated?
	MBT_UINT		ServerHandle;	//Server handle
	T_MBT_OBEX_STATE			ServerState;
	T_MBT_OBEX_SERVICE_INFO	ServerService;
}T_MBT_OBEX_SERVER_INFO;

typedef struct
{
	T_MBT_OBEX_SERVER_ENABLE_SUCCESS			enable_success;

	MBT_BYTE					scn[MBT_OBEX_MAX_SERVER_NUM];
	T_MBT_OBEX_SERVER_INFO		server_info[MBT_OBEX_MAX_SERVER_NUM];

	T_MBT_OBEX_SERVER_CONNECT_REQ			conn_req[MBT_OBEX_MAX_SERVER_NUM];
	T_MBT_OBEX_SERVER_CONNECT_SUCCESS		conn_success[MBT_OBEX_MAX_SERVER_NUM];
	T_MBT_OBEX_SERVER_DISCONNECT_REQ			disc_req[MBT_OBEX_MAX_SERVER_NUM];
	T_MBT_OBEX_SERVER_DISCONNECT_SUCCESS	disc_success[MBT_OBEX_MAX_SERVER_NUM];
	T_MBT_OBEX_SERVER_ABORT_REQ				abort_req[MBT_OBEX_MAX_SERVER_NUM];
	T_MBT_OBEX_SERVER_SETPATH_REQ				setpath_req[MBT_OBEX_MAX_SERVER_NUM];
	T_MBT_OBEX_SERVER_PUT_REQ					put_req[MBT_OBEX_MAX_SERVER_NUM];
	T_MBT_OBEX_SERVER_GET_REQ					get_req[MBT_OBEX_MAX_SERVER_NUM];
}T_MBT_OBEX_STATUS;
/******************AVRCP*******************/
// AVRCP Application setting
typedef struct
{
	MBT_BYTE					AttrNum;		// number of application setting attribute

	struct
	{
		T_MBT_AVRCP_ATTR_ID	ID;				// type of application setting attribute
		MBT_BYTE				Value;			// value of application setting attibute
		
	}Attr[MBT_AVRCP_MAX_ATTR_NUM];
	
}T_MBT_AVRCP_APP_ATTR;

// AVRCP Player Application Settings and values
typedef struct
{
	T_MBT_AVRCP_ATTR_ID		AttrID;			// type of application setting attribute
	MBT_BYTE*					AttrIDText;		// text format for application setting attibute
	MBT_BYTE					AttrValueNum;	// number of application setting attribute value

	struct
	{
		MBT_BYTE				ValueID;			// value of application setting attibute
		MBT_BYTE*				ValueIDText;		// text format for value of application setting attibute
		
	}Val[MBT_AVRCP_MAX_ATTR_VALUE_NUM];
}T_MBT_AVRCP_APP_VALUE;

// AVRCP Player Info
typedef struct
{
	MBT_BYTE					EvIDNum;		// number of events supported by TG
	T_MBT_AVRCP_EVENT_ID		EvID[MBT_AVRCP_MAX_EVENT_NUM];// event information bit
	MBT_BYTE					AttrNum;		// number of application setting attibutes
	MBT_SHORT					AttrCharSet;		// character set of application setting attibute ID text (including value ID text)
	T_MBT_AVRCP_APP_VALUE		Attr[MBT_AVRCP_MAX_ATTR_NUM]; 	// applicaton settings and value
}T_MBT_AVRCP_PLAYER_INFO;

// AVRCP Get Play Status response
typedef struct
{
	MBT_UINT 					Len;			// total length of the playing song in milliseconds
	MBT_UINT 					Positioin;		// current position of the playing in milliseconds elapsed
	T_MBT_AVRCP_PLAYSTATUS 	PlayStatus;		// current status of playing
}T_MBT_AVRCP_GET_PLAYSTATUS;

// AVRCP Get Element Attribute
typedef struct
{
	T_MBT_AVRCP_MEDIA_ATTR_ID	AttrID;			// attibute ID to be sent
	MBT_SHORT					CharacterSetID;	// character set ID to be displayed on CT
	MBT_SHORT					AttrValueLen;	// length of the value of the attribute (0~65535)
	MBT_BYTE*					AttrValue;		// attribute name in specified character set
}T_MBT_AVRCP_MEDIA_ATTR;

// AVRCP Register Notification Response
typedef struct
{
	T_MBT_AVRCP_EVENT_ID 		EventID;		// Event ID requeted by CT
 	union
	{
		T_MBT_AVRCP_BATT_STATUS	BatteryStatus;	// Battery status - MBT_AVRCP_EV_BATT_STATUS
		T_MBT_AVRCP_SYSTEM			SystemStatus;	// current System status - MBT_AVRCP_EV_SYSTEM_STATUS
		MBT_UINT					PlayPosition;	// current playback postion in millisecond - MBT_AVRCP_EV_PLAY_POS
		MBT_UINT64					TrackIdx;		// Index of the current track - MBT_AVRCP_EV_TRACK_CHANGED
		T_MBT_AVRCP_PLAYSTATUS	 	PlayStatus;		// current status of playback - MBT_AVRCP_EV_PLAY_STATUS
		T_MBT_AVRCP_APP_ATTR		AppSetting;		// Player application setting is changed -MBT_AVRCP_EV_APP_SETTING
 	}Val;
}T_MBT_AVRCP_REGISTER_NOTI;

// AVRCP data
typedef struct
{
	T_MBT_BDADDR				BdAddr;
	T_MBT_AVRCP_CONSTATUS   	ConStatus;		// connection status

	T_MBT_AVRCP_APP_ATTR		GetValue;		// number and value of application setting to be sent
	T_MBT_AVRCP_APP_ATTR		SetValue;		// number and value of application setting to be set

	T_MBT_AVRCP_EVENT_ID		NotiEventID;		// event for whicht the CT requires notifications
	MBT_UINT					NotiPlayInterval;// time interval at the change in playback position

	MBT_UINT64					MediaIdentifier;	// Unique identifier to identify an element on TG (PLAYING)
	MBT_BYTE					MediaAttrNum;	// number of attibutes provided
	T_MBT_AVRCP_MEDIA_ATTR_ID	MediaAttrID[MBT_AVRCP_MAX_MEDIA_ID]; // attibute ID for the attibutes to be retrieved

	MBT_BYTE					CharSetNum;	// number of CharacterSet supported by CT
	MBT_SHORT*					CharSetID;		// pointer of CharacterSet supported by CT
	T_MBT_AVRCP_BATT_STATUS	BattStatusCT; 	// battery status of CT
}T_MBT_AVRCP_DATA;

// AVRCP status
typedef struct
{
	MBT_BOOL					bEnabled;     		// avrcp's enable
	MBT_BYTE                			ConNum;         		// Number of connections	
	T_MBT_AVRCP_DATA        		AvrcpConn[MBT_AVRCP_MAX_CONN_NUM]; // connection information
	T_MBT_AVRCP_PLAYER_INFO	PlayerInfo;			// player information supported by TG
}T_MBT_AVRCP_STATUS;

/******************* OBEX Common *******************/

// Object information
typedef struct
{
	MBT_BOOL	bAuth;
	MBT_CHAR	UserId[MBT_OBEX_AUTH_USERID_LEN+1];
	MBT_CHAR	Passwd[MBT_OBEX_AUTH_PASSWD_LEN+1];
} T_MBT_OBEX_AUTH;

/*******************OPP*******************/

// OPP status
 typedef struct
{
	MBT_CHAR	FileName[MBT_MAX_FILE_NAME_LEN];	// ���� �̸�
	MBT_CHAR	DirName[MBT_MAX_FILE_NAME_LEN];	// ���� ���
	MBT_BYTE	*PBuffer;		// Rx/TX data buffer pointer. if use file -MBT_NULL set
	MBT_UINT	ObjectSize;		// Rx/Tx data Total Size
	MBT_UINT	AllocBufferSize;	// Total PBuffer size. (UI alloc)
	T_MBT_OBJECT_STORAGE		StorageType;		// Tx data storage type. :: buffer, Internal FS, External FS
	T_MBT_OPP_OBJECT_FORMAT	ObjectType;			// File type
	MBT_UINT	AcceptableFileSize;					// AcceptableFileSize for object receive
} T_MBT_OPP_OBJECT;


typedef struct
{
	T_MBT_BDADDR			BDAddr;				// ����Ʈ ����̽� �ּ�	
	MBT_BOOL				bServerEnabled;
	MBT_BOOL				bClientEnabled;
	MBT_BOOL				bTempAuthorize;	// Authorize	
	MBT_CHAR				RemoteDevName[MBT_MAX_NAME_LEN];	// ���� ����� ����Ʈ ����̽� �̸�
	MBT_UINT				TxProgress;			// ���� �۽������� ���۷�
	MBT_UINT				RxProgress;			// ���� ���������� ���۷�
	T_MBT_OPP_OPERATION	Operation;			// Access �䱸�� Operation
	T_MBT_OPP_OBJECT		SendingFile;			// ���� �۽����� ����
	T_MBT_OPP_OBJECT		ReceivingFile;		// ���� �������� ����
	T_MBT_OPP_STATE		OppState;			// ���� OPP ����
	T_MBT_AUTHRES			FailReason;			// for MBT_DATABASE_FULL_RES return to UI
}T_MBT_OPP_STATUS;


/*******************FTP*******************/

// FTP status
typedef struct
{
	MBT_CHAR	VirtualDir[MBT_MAX_FILE_NAME_LEN];
	MBT_CHAR	RealDir[MBT_MAX_FILE_NAME_LEN];
} T_MBT_FTP_DIRTYPE;


typedef struct
{
	MBT_CHAR	FileName[MBT_MAX_FILE_NAME_LEN];	// ���� �̸�
	MBT_CHAR	DirName[MBT_MAX_FILE_NAME_LEN];	// ���� ���
	MBT_CHAR	NewName[MBT_MAX_FILE_NAME_LEN];	// �ߺ��� �̸��� �ִ� ���, Rename �� �̸�
	MBT_INT		ObjectSize;							// ���� Object Size 
	MBT_UINT	AcceptableFileSize;					// AcceptableFileSize for object receive
} T_MBT_FTP_OBJECT;


typedef struct
{	
	MBT_BOOL	bServerEnabled;		//Server Enable
	MBT_BOOL	bClientEnabled;		//Client Enable
	MBT_BOOL	bTempAuthorize;	// Authorize
	MBT_CHAR	RemoteDevName[MBT_MAX_NAME_LEN];		// ���� ����� ����Ʈ ����̽� �̸�
	MBT_UINT	NumFTPDir;
	MBT_UINT	TxProgress;			// ���� �۽������� ���۷�
	MBT_UINT	RxProgress;			// ���� ���������� ���۷�
	T_MBT_BDADDR			BDAddr;			// ����Ʈ ����̽� �ּ�
	T_MBT_FTP_DIRTYPE		FTPDirName[MBT_FTP_MAX_DIR_NUM];							
	T_MBT_FTP_OPERATION	Operation;		// ���� ��û����, Ȥ�� �������� ����	
	T_MBT_FTP_OBJECT		SendingFile;		// ���� �۽����� ����
	T_MBT_FTP_OBJECT		ReceivingFile;	// ���� �������� ����
	T_MBT_FTP_OBJECT		TargetFile;		// For Del file, Del dir, Chdir, MKdir
	T_MBT_FTP_STATE			FtpState;		// FTP state
	T_MBT_AUTHRES			FailReason;		// FAIL �̺�Ʈ �߻��ÿ��� ���
}T_MBT_FTP_STATUS;


/*******************BPP*******************/

// BPP Attribute
typedef struct
{
	MBT_SHORT	Copies;
	MBT_SHORT	NumberUp;
	MBT_BYTE	Sides;
	MBT_BYTE	Orient;
	MBT_BYTE	Quality;	
	MBT_CHAR	DocFmt[MBT_MAX_DOC_FORMAT_LEN];
	MBT_CHAR	MediaSize[MBT_MAX_MEDIA_SIZE_LEN];
	T_MBT_BPP_MEDIA	MediaType;	
}T_MBT_BPP_ATTRIBUTE;

// BPP Capability
typedef struct
{
	MBT_CHAR				PrinterName[MBT_MAX_ATTR_VAL_LEN];
	MBT_CHAR				PrinterLocation[MBT_MAX_ATTR_VAL_LEN];
	T_MBT_BPP_PRINTER_STATE			PrinterState;
	T_MBT_BPP_PRINTER_STATE_REASON		PrinterStateReasons;
	MBT_BYTE				NumDocFmtSupported;
	MBT_CHAR				DocFmtSupported[MBT_MAX_NUM_OF_NESTED_ATTR][MBT_MAX_MIME_VAL_LEN];
	MBT_BOOL 				bColorSupported;
	MBT_BYTE				SidesSupported;
	MBT_SHORT				MaxCopiesSupported;	
	MBT_SHORT     			MaxNumberUp;
	MBT_BYTE   				OrientationsSupported;	
	MBT_BYTE   				NumMediaSizesSupported;
	MBT_CHAR				MediaSizesSupported[MBT_MAX_NUM_OF_NESTED_ATTR][MBT_MAX_ATTR_VAL_LEN];
	MBT_BYTE				NumMediaTypesSupported;
	T_MBT_BPP_MEDIA		MediaTypesSupported[MBT_MAX_NUM_OF_NESTED_ATTR];		
	T_MBT_BPP_MEDIA   		LoadedMediaType[MBT_MAX_NUM_OF_NESTED_ATTR];
	MBT_BYTE   				NumLoadedMedia;
	MBT_BYTE   				PrintQualitySupported;
	MBT_BYTE   				NumImageFmtSupported;
	MBT_CHAR				ImageFmtSupported[MBT_MAX_NUM_OF_NESTED_ATTR][MBT_MAX_ATTR_VAL_LEN];
	MBT_SHORT     			QueuedJobCount;
	MBT_SHORT     			BasicTextPageWidth;
	MBT_INT					OperationStatus;
	MBT_SHORT     			BasicTextPageHeight;
	MBT_CHAR				PrinterGeneralCurrentOperator[MBT_MAX_ATTR_VAL_LEN];
}T_MBT_BPP_CAPABILITY;

// BPP Job Status
typedef struct
{
	T_MBT_BPP_PRINT_JOB_STATE		PrintJobState;		// Waiting, stopped, cancelled, unknown, etc.
	T_MBT_BPP_PRINTER_STATE		PrinterState;		// State - idle, processing, or stopped
	T_MBT_BPP_PRINTER_STATE_REASON	PrinterStateReasons;	// Reason in current state
} T_MBT_BPP_JOB_STATUS;

// BPP Object
typedef struct
{
	MBT_CHAR				DirName[MBT_MAX_FILE_NAME_LEN];
	MBT_CHAR				FileName[MBT_MAX_FILE_NAME_LEN];
	T_MBT_MIME_MEDIA		MimeType;
	MBT_BOOL				bJobBasedPrinting;
	MBT_UINT				ObjectSize;			//Tx data Total Size
	T_MBT_BPP_ATTRIBUTE		PrintingAttribute;
	T_MBT_BPP_JOB_STATUS	JobStatus;			// JobState, PrinterState, PrinterStateReason	
}T_MBT_BPP_OBJECT;

// BPP Status
typedef struct
{
	MBT_BOOL				bEnabled;
	MBT_BOOL				bIsObexUserID;		// Obex Authentication Req�� User ID ��û ����
	MBT_CHAR				RemoteDevName[MBT_MAX_NAME_LEN];	// ���� ����� ����Ʈ ����̽� �̸�
	T_MBT_BDADDR			BDAddr;				// ����Ʈ ����̽� �ּ�
	MBT_UINT				TxProgress;			// ���� �۽������� ���� ������ ũ�� (����)
	T_MBT_BPP_OBJECT		PrintingFile;			// ���� �۽����� ����
	T_MBT_BPP_CAPABILITY	PrinterCapability;
	T_MBT_BPP_STATE			State;				// BPP ����
	T_MBT_AUTHRES			FailReason;			// FAIL �̺�Ʈ �߻��ÿ��� ���		
}T_MBT_BPP_STATUS;

/*******************BIP*******************/

// BIP Image Descriptor
typedef struct
{
	MBT_CHAR	Version[10];		// Image Descriptor version (exe) "1.0", etc)
	MBT_CHAR	Encoding[30];	// Image Encoding Type String (ex)"JPEG","GIF","BMP","WBMP","PNG", etc)
	MBT_UINT	Width;			// Image Pixel size : Width
	MBT_UINT	Height;			// Image Pixel size : Height	
	MBT_UINT	Width2;			// width - 0 if not range
	MBT_UINT	Height2;			// height - 0 if not range
	MBT_UINT	Size;			// Image file size
	T_MBT_BIP_TRANS	Transform;
} T_MBT_BIP_IMAGE_DESC;

// BIP Image Format
typedef struct                    
{
	MBT_CHAR	Encoding[30];	// Image Encoding Type String (ex)"JPEG","GIF","BMP","WBMP","PNG", etc)
	MBT_UINT	Width;			// Image Pixel size : Width
	MBT_UINT	Height;			// Image Pixel size : Height	
	MBT_UINT	Width2;			// width - 0 if not range
	MBT_UINT	Height2;			// height - 0 if not range
	MBT_UINT	Size;			// Image file size
} T_MBT_BIP_IMAGE_FORMAT;

// BIP Imaging Capability 
typedef struct
{
	T_MBT_BIP_IMAGE_DESC	PreferFormat;	// Image format prefer to receive
	T_MBT_BIP_IMAGE_FORMAT	ImageFormats[MBT_MAX_NUM_OF_NESTED_ATTR];	// Image format can be retrieved by other devices
	MBT_UINT   				NumImageFormats;
} T_MBT_BIP_IMAGING_CAPABILITY;

// BIP Object
typedef struct
{
	MBT_CHAR	DirName[MBT_MAX_FILE_NAME_LEN];		// ���� ���
	MBT_CHAR	FileName[MBT_MAX_FILE_NAME_LEN];		// ���� �̸�
	MBT_CHAR	ThumbnailFullpath[MBT_MAX_FILE_NAME_LEN];	// Thumbnail fullname (QBT : PushImage �� ���� �־���� ��)
	MBT_UINT	ObjectSize;								// ���� Object Total Size 
	T_MBT_BIP_IMAGE_DESC	ImageDesc;					// Image Descriptor
} T_MBT_BIP_OBJECT;

// BIP Status
typedef struct
{
	MBT_BOOL				bInitiatorEnabled;
	MBT_BOOL				bResponderEnabled;
	MBT_BOOL				bTempAuthorize;	// Authorize	
	MBT_BOOL				bIsObexUserID;		// Obex Authentication Req�� User ID ��û ����
	MBT_CHAR				RemoteDevName[MBT_MAX_NAME_LEN];	// ���� ����� ����Ʈ ����̽� �̸�
	T_MBT_BDADDR			BDAddr;				// ����Ʈ ����̽� �ּ�
	MBT_UINT				TxProgress;			// ���� �۽������� ���� ������ ũ��(����)
	MBT_UINT				RxProgress;			// ���� ���������� ���� ������ ũ��(����)
	T_MBT_BIP_OBJECT		SendingFile;			// ���� �۽����� ����
	T_MBT_BIP_OBJECT		ReceivingFile;		// ���� �������� ����
	T_MBT_BIP_IMAGING_CAPABILITY	ImagingCapability;	
	T_MBT_BIP_STATE			State;				// BIP State
	T_MBT_BIP_OP			Operation;
	T_MBT_AUTHRES			FailReason;			// FAIL �̺�Ʈ �߻��ÿ��� ���	
	MBT_BOOL				bThumbReq;			// using Responder Role (Thumbnail request or not)
}T_MBT_BIP_STATUS;

/*******************PBAP*******************/
 
// PBAP Auth
typedef struct
{
	T_MBT_BDADDR			BDAddr;								// ����Ʈ ����̽� �ּ�
	MBT_CHAR				RemoteDevName[MBT_MAX_NAME_LEN];	// ���� ����� ����Ʈ ����̽� �̸�
}T_MBT_PBAP_AUTHENTICATE;

typedef struct
{
	T_MBT_PBAP_STORAGE		    Storage;
	MBT_SHORT				    Index;
	MBT_CHAR				    vCardMask[8];
	T_MBT_PBAP_DIR			    Dir;
	T_MBT_PBAP_VCARD_VERSION    Format;
}T_MBT_PBAP_PULL_VCARD_IN;

typedef struct
{
	T_MBT_PBAP_STORAGE			Storage;
	T_MBT_PBAP_DIR				Dir;
	MBT_CHAR					vCardMask[8];
	T_MBT_PBAP_VCARD_VERSION	Format;
	MBT_UINT					ListStartOffset;
	MBT_UINT					MaxListCount;
}T_MBT_PBAP_PULL_DIRECTORY_DATA_IN;

typedef struct
{
	T_MBT_PBAP_STORAGE			Storage;
	T_MBT_PBAP_DIR				Dir;
	T_MBT_PBAP_SEARCH			SearchMethod;
	MBT_CHAR					SearchVal[MBT_PBAP_MAX_NAME_LENGTH];
	T_MBT_PBAP_SORT				SortMethod;
	MBT_UINT					MaxListCount;
	MBT_UINT					ListStartOffset;
}T_MBT_PBAP_PULL_DIRECTORY_LIST_IN;

typedef struct
{
	MBT_CHAR					ListHandler[MBT_PBAP_VCARD_HANDLE_LENGTH];
	MBT_CHAR					Name[MBT_PBAP_MAX_NAME_LENGTH];
}T_MBT_PBAP_VCARD_LIST;

typedef struct
{
	MBT_BOOL			Result;
	
	T_MBT_OBJECT_STORAGE StorageType;		// Tx data storage type. :: buffer, Internal FS, External FS
	//yucha_pbap
	// File 
	MBT_CHAR			FileName[MBT_MAX_FILE_NAME_LEN];	// ���� �̸�
	MBT_CHAR			DirName[MBT_MAX_FILE_NAME_LEN];	// ���� ���

	// buffer
	MBT_BYTE			*vCard;
	MBT_SHORT			vCardMergedCount;
	MBT_SHORT			vCardTotalCount;
	MBT_SHORT			NewMissedCallCount;

	MBT_BYTE			*vCardList;
	MBT_SHORT			vCardListTotalCount;
	MBT_SHORT			vCardListMergedCount;
}T_MBT_PBAP_PULL_OPERATION_RESULT;

typedef struct
{
	MBT_BOOL			bEnabled;
	MBT_BOOL			bIsObexUserID;
	T_MBT_PBAP_OP		Operation;
	T_MBT_PBAP_STATE	State;
	MBT_CHAR			NameDev[MBT_PBAP_MAX_NAME_LENGTH];	//for authorization
	MBT_CHAR			ReqPath[MBT_MAX_FILE_NAME_LEN]; 
	T_MBT_BDADDR		BDAddr;									//for authorization
	T_MBT_PBAP_PULL_DIRECTORY_LIST_IN		PullDirectoryListIn;	//Directory List
	T_MBT_PBAP_PULL_VCARD_IN				PullvCardIn;			//vCard data
	T_MBT_PBAP_PULL_DIRECTORY_DATA_IN		PullDirectoryDataIn;	//Directory data
	T_MBT_PBAP_PULL_OPERATION_RESULT		vCardOut;
}T_MBT_PBAP_STATUS;

/*******************HID*******************/

typedef struct
{
	T_MBT_BDADDR		BDAddr;		// remote device addr
	T_MBT_HID_HANDLE	handle;		// handle
	T_MBT_HID_STATE		State;		// HID Host State
	MBT_SHORT			Idle;		// HID Device �� ������ Idle ��
	MBT_BOOL			BootMode;	// HID Device �� ������ Mode(Boot/Report)
	MBT_BYTE			DescStr[MBT_HID_DESC_MAX_SIZE];	// descriptor string
	MBT_SHORT			DescLen;	// descriptor string length
	MBT_BYTE			RptStr[MBT_HID_REPORT_MAX_SIZE];	// report string
	MBT_SHORT			RptLen;		// report string length
	T_MBT_HID_DEV_TYPE	DevType;

	T_MBT_HID_OP		Operation;
}
T_MBT_HID_DEVICE;

 typedef struct
{
	MBT_BOOL			bEnabled;
	FP_MBT_HID_RX_REPORT_CO	*fpRxReport; 
	T_MBT_HID_DEVICE	devices[MBT_HID_MAX_DEVICE_NUM];
}T_MBT_HID_HOST_STATUS;

 typedef struct
{
	MBT_BOOL			bEnabled;
	T_MBT_BDADDR		BDAddr;		// HID host device addr
	T_MBT_HID_STATE		State;		// HID Host State
	T_MBT_HID_OP		Operation;	// Current Operation
	T_MBT_HID_ROLE		Role;		// Keyboard/Phone Role

	MBT_SHORT			Idle;		// my idle value
	MBT_BOOL			BootMode;	// my protocol mode
	MBT_BYTE			DescStr[MBT_HID_DESC_MAX_SIZE];	// my descriptor string
	MBT_SHORT			DescLen;	// my descriptor string length
	MBT_CHAR			Name[MBT_HID_MAX_DEVICE_NAME_LENGTH];	// my device name in hid
	MBT_SHORT			ParserVersion;	// my hid parser version
	MBT_BYTE			CountryCode;	// my hid country code
	MBT_SHORT			LangBase;		// my language base
	MBT_SHORT			VendorID;		// my vendor id
	MBT_SHORT			DeviceID;		// my device id
	MBT_SHORT			ProductVersion;	// my product version

	MBT_BYTE			RptStr[MBT_HID_REPORT_MAX_SIZE];		// report string
	MBT_SHORT			RptLen;		// report string length
	T_MBT_HID_LED_MASK	LedMask;	// received LED mask, used in only keyboard mode
	T_MBT_HID_CONTROL	ControlType;	// received control command type
}T_MBT_HID_DEVICE_STATUS;

/******************JSR82*******************/

// JSR82 128 bit UUID
typedef struct
{
    MBT_BYTE                UUIDByte[16];    
}T_MBT_UUID128;

// JSR82 UUID list type */
typedef struct
{
    MBT_SHORT               NumUUIDs;                               // UUID ����
    MBT_SHORT               UUID[MBT_JSR82_MAX_SEARCH_UUID_NUM];    // UUID ��
    MBT_SHORT               NumUUID32s;                             // 32 bit UUID ����
    MBT_UINT                UUID32[MBT_JSR82_MAX_32_UUID_NUM];      // 32 bit UUID ��
    MBT_SHORT               NumUUID128s;                            // 128 bit UUID ����
    T_MBT_UUID128           UUID128[MBT_JSR82_MAX_128_UUID_NUM];    // 128 bit UUID �� 
}T_MBT_JSR82_UUID_LIST;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� SDP search type */
typedef struct
{
    T_MBT_JSR82_UUID_LIST   UUIDList;                               // UUID list (16, 32, 128)
    MBT_SHORT               NumAttrIDs;                             // Attribute ID ����
    MBT_UINT                AttrVal[MBT_JSR82_MAX_ATTR_ID_NUM];     // Attribute ��
}T_MBT_JSR82_SEARCH_SD;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� Protocol Descriptor type */
typedef struct
{
    MBT_SHORT               UUID;           // identifying the protocol
    MBT_SHORT               NumParam;       // how many elements in aParam are valid
    struct
    {
        MBT_BYTE            Size;    
        MBT_UINT            Value;
    }Param[MBT_JSR82_MAX_PROTO_PARAM_NUM];  // Protocol-specific parameters
#ifdef JSR82_QBT
	T_MBT_UUID128	UUID128;
	MBT_BOOL		BUUID128;
#endif
}T_MBT_JSR82_PROTOCOL_DESC;

//Protocol Descriptor List type
typedef struct
{
    MBT_SHORT                   NumProtoDes;
    T_MBT_JSR82_PROTOCOL_DESC   ProtoDesc[MBT_JSR82_MAX_PROTO_DESC_NUM];
}T_MBT_JSR82_PROTOCOL_DESC_LIST;

// QBT
typedef struct
{
    MBT_SHORT                  		 NumProtoListDes;
    T_MBT_JSR82_PROTOCOL_DESC_LIST   ProtoDescList[MBT_JSR82_MAX_NUM_OF_ADD_PROTO_LIST_NUM];
}T_MBT_JSR82_ADD_PROTOCOL_DESC_LIST;
//QBT
typedef struct
{
	MBT_BYTE	NumVal;		// how many elements in uVal are valid
	MBT_UINT	Val[MBT_JSR82_MAX_UINT];
}T_MBT_JSR82_UINT_LIST;

// QBT
typedef struct
{
  T_MBT_JSR82_SD_DATA_ELEMENT_TYPE	   Type;
  MBT_BYTE						Size_index;
  MBT_BYTE						Hdr_len;
  MBT_BYTE						Attr_value_len;
}T_MBT_JSR82_DATA_ELEMENT_HDR_TYPE;

//Language Base AttributeID List type
typedef struct
{
    MBT_SHORT                   NumLangBase;
    struct
    {
        MBT_SHORT               LangId;
        MBT_SHORT               CharEncId;
        MBT_SHORT               BaseAttrId;
	}LangBase[MBT_JSR82_MAX_LANG_BASE_REC_NUM];
}T_MBT_JSR82_LANG_BASE_ATTR_LIST;


//Bluetooth Profile Descriptor List type
typedef struct
{
    MBT_SHORT                   NumProfile;
    struct
    {
        MBT_UINT                UUID;
        MBT_SHORT               Version;
    }ProfileList[MBT_JSR82_MAX_PROFILE_NUM];
}T_MBT_JSR82_PROFILE_LIST;

//HID Class Descriptor type
typedef struct
{
	T_MBT_JSR82_DATA_ELEMENT_HDR_TYPE Header; // LEECHANGHOON 2008-4-7 QBT���� �߰���.
    MBT_BYTE                    Value;
    MBT_BYTE                    Length;
    MBT_CHAR                    Str[MBT_JSR82_MAX_HID_DESC_STR_LEN];
}T_MBT_JSR82_HID_DESC;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� HID Class Descriptor List type */
typedef struct
{
    MBT_SHORT                   NumHidDesc;
    T_MBT_JSR82_HID_DESC        HidDesc[MBT_JSR82_MAX_HID_DESC_NUM];
}T_MBT_JSR82_HID_DESC_LIST;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� Attribute type */
typedef struct
{
    MBT_SHORT                   AttrID;
    T_MBT_JSR82_SD_ATTR         AttrType;
    
    union
    {
        T_MBT_JSR82_UUID_LIST           UUIDList;
        T_MBT_JSR82_PROTOCOL_DESC_LIST  ProtoDescList;
		T_MBT_JSR82_ADD_PROTOCOL_DESC_LIST  AddProtoDescList;	//LEECHANGHOON - Added 08/04/07
        T_MBT_JSR82_LANG_BASE_ATTR_LIST LangBaseAttrList;
		T_MBT_JSR82_UINT_LIST            	UintList;			//LEECHANGHOON - Added 08/04/07
        T_MBT_JSR82_PROFILE_LIST        BTProfileList;
        T_MBT_JSR82_HID_DESC_LIST       HidDescList;
        MBT_CHAR                        ServiceName[MBT_JSR82_MAX_STRING_LEN];
        MBT_CHAR                        DocumentURL[MBT_JSR82_MAX_STRING_LEN];
        MBT_UINT                        PrimitiveValue;		//LEECHANGHOON - Added 08/04/21 ����� �Ǿ�� ��.
#ifdef JSR82_QBT
		MBT_BYTE						Str[MBT_JSR82_MAX_STRING_LEN]; //yucha 2008/01/13 �߰�. 
		MBT_BOOL						BFlag;	//yucha 2008/01/13 �߰�. 
		T_MBT_UUID128					UUID128;//yucha 2008/01/13 �߰�. 
#endif
	}Value;
}T_MBT_JSR82_ATTRIBUTE;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� SDP Update type */
typedef struct
{
#ifdef JSR82_QBT
	MBT_BOOL               	bCustomSvc;		//yucha 2008/01/12 �߰� 
	MBT_UINT				SrvRechandle;	//yucha 2008/01/12 �߰� 
    MBT_UINT                UUID;      		//yucha 2008/01/12 �߰� 
    T_MBT_UUID128           UUID128;    	//yucha 2008/01/12 �߰� 
#endif
    MBT_SHORT               NumAttr;
    T_MBT_JSR82_ATTRIBUTE   Attr[MBT_JSR82_MAX_ATTR_ID_NUM];

#ifdef JSR82_QBT
	MBT_CHAR				SvcName[MBT_JSR82_MAX_STRING_LEN];//yucha 2008/01/12 �߰� 
#endif

}T_MBT_JSR82_SD_RECORD;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� L2CAP configuration type */
typedef struct
{
    MBT_SHORT   PSM;                // PSM value
    MBT_SHORT   CId;                // connection id (Default - 0x0000)
    MBT_SHORT   InFlushTO;          // flush timeout (Default - 0xFFFF)
    MBT_SHORT   InMTU;              // incoming mtu
    MBT_SHORT   OutMTU;             // outgoing mut
    MBT_BYTE    InQoS;              // QoS (Deafult - 1)

    MBT_UINT    TokenRate;          // (Default - 0x00000000)
    MBT_UINT    TokenBucketSize;    // (Default - 0x00000000)
    MBT_UINT    PeakBandwidth;      // (Default - 0x00000000)
    MBT_UINT    Latency;            // (Default - 0xFFFFFFFF)
    MBT_UINT    DelayVariation;     // (Default - 0xFFFFFFFF)      
}T_MBT_JSR82_L2CAP_CONFIG_INFO;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� RFCOMM configuration type */
typedef struct
{
    MBT_BYTE    ChannelNumber;      // server channel number (CID)
    MBT_CHAR*   SvcName;            // name of service (Default - "SYSTEM_BT_SPP_SERVER")
    MBT_SHORT   SvcId;              // UUID of service (Default - 0x1101) 
    MBT_SHORT   SvcVersion;         // version of service (Default - 0x0000)
    MBT_SHORT   MaxFrameSize;       // 0 means BT driver decides (Default - 0x0000)
}T_MBT_JSR82_RFCOMM_CONFIG_INFO;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� set secuirty type */
typedef struct
{
    MBT_BYTE        Handle;         // Server/Client�� PeerHandle
    MBT_BOOL        bEncrypt;       // encrypt
    MBT_BOOL        bAuthenticate;  // authenticate
    MBT_BOOL        bAuthorize;     // authorize
    MBT_BOOL        bMaster;        // master or slave
}T_MBT_JSR82_SET_SECURITY;   

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� l2cap mtu type */
typedef struct
{
    MBT_INT         TxMTU;
    MBT_INT         RxMTU;
}T_MBT_JSR82_MTU;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� Java event type */
typedef struct
{
    MBT_BOOL            Used;           // Used flag
    MBT_BYTE            ServerHandle;   // JSR82's Server Handle
    MBT_BYTE            ClientHandle;   // JSR82's Client Handle
	T_MBT_BDADDR        BDAddr;         // JSR82's blutooth address
	T_MBT_JSR82_SET_SECURITY Security;	// security type

    union
    {
        MBT_UINT        SvcHandle;      // JSR82's service record handle (create record)
        MBT_UINT        ReadLen;        // JSR82's Read length (L2CAP, RFCOMM)
        MBT_UINT        WriteLen;       // JSR82's Write length (L2CAP, RFCOMM)
        MBT_SHORT       PSM;            // JSR82's L2CAP's PSM
        MBT_BYTE        SCN;            // JSR82's RFCOMM's SCN
        T_MBT_JSR82_MTU MTU;            // JSR82's L2CAP's mtu
    }Val;
    union
    {
        MBT_VOID*   Info;           // JSR82's L2CAP or RFCOMM info given by Java layer (except read & write & close)
        MBT_VOID*   ReadInfo;       // JSR82's L2CAP or RFCOMM Read info 
        MBT_VOID*   WriteInfo;      // JSR82's L2CAP or RFCOMM Write info 
        MBT_VOID*   CloseInfo;      // JSR82's L2CAP or RFCOMM Close info
    }Infos;
}T_MBT_JSR82_EVENT_INFO;

//## 
/* <Group JSR82_Structure>
 JSR82�� ���� status type */
typedef struct
{
    MBT_BOOL        bEnabled;           // JSR82's enable
#ifdef JSR82_QBT
	T_MBT_JSR82_SET_SECURITY Security;  // security type
#endif
    T_MBT_JSR82_EVENT_INFO   EvInfo[MBT_JSR82_MAX_EVENT_NUM]; // event information to Java

    MBT_INT         ReadRecNum;         // Ž���Ǿ��� Service Record�� ������ Ƚ�� (Java layer's input)
    MBT_UINT        TransID;            // Service Search�� transaction ID
    MBT_UINT        SvcRecNum;          // Ž���Ǿ��� Service Record�� ����
    MBT_UINT        AttrIdNum;          // service search�� ���� ���� �� service record�� attribute ID ����    
    MBT_UINT        AttrValLen;         // service search�� ���� ���� �� service record�� attibute value���� ����
#ifndef AROMA
		MBT_BYTE*		AttrVals;			// service search�� ���� ���� �� service record�� ��
#else
		MBT_BYTE**		AttrVals;			// service search�� ���� ���� �� service record�� ��  //pure val :no Attr id
		MBT_SHORT*		AttrSet;			//ATTR id �迭 
#endif
}T_MBT_JSR82_STATUS;

/*******************SAP*******************/
// SAP result code
typedef enum 
{
	MBT_SAP_RESULT_OK_REQUEST,			// OK, request processed correctly
	MBT_SAP_RESULT_ERR_NO_REASON,		// Error, no reason defined
	MBT_SAP_RESULT_ERR_CARD_NOT_ACC, 	// Error, card not accessible
	MBT_SAP_RESULT_ERR_CARD_POW_OFF, 	// Error, card (already) powered off
	MBT_SAP_RESULT_ERR_CARD_REMOVED,	// Error, card removed
	MBT_SAP_RESULT_ERR_CARD_POW_ON,  	// Error, card already powered on
	MBT_SAP_RESULT_ERR_DATA_NOT_AVAIL,	// Error, data not available
	MBT_SAP_RESULT_ERR_NOT_SUPPORTED, 	// Error, not supported
	MBT_SAP_RESULT_ERR_INVALID_MSG, 	// Invalid message (not defined SAP spec.)
} T_MBT_SAP_RESULT_CODE;

// SAP connect status
typedef enum
{
	MBT_SAP_OK_CONNECT, 						// OK, Server can fulfill requirements
	MBT_SAP_UNABLE_TO_ESTABLISH_CONNECT,   	// Error, Server unable to establish connection
	MBT_SAP_MAX_MSG_SIZE_NOT_SUPPORTED,  	// Error, Server does not support maximum message size
	MBT_SAP_MSG_SIZE_TO_SMALL				// Error, maximum message size by Client is too small
} T_MBT_SAP_CONNECT_STATUS;

// SAP card status
typedef enum
{
	MBT_SAP_CARD_UNKNOWN_ERROR = 0x0, 	// unknown error
	MBT_SAP_CARD_RESET,					// SIM card reset
	MBT_SAP_CARD_NOT_ACCESSIBLE,		// SIM card not accessible
	MBT_SAP_CARD_REMOVED,				// SIM card removed
	MBT_SAP_CARD_INSERTED,				// SIM card inserted
	MBT_SAP_CARD_RECOVERED,				// SIM card recovered
}T_MBT_SAP_CARD_STATUS;

// SAP state
typedef enum
{
	MBT_SAP_STATE_NO_CONNECTION=0,		// no connection
	MBT_SAP_STATE_CONNECTING,			// try to connect
	MBT_SAP_STATE_CONNECTED,			// connected state
	MBT_SAP_STATE_DISCONNECTING,		// try to disconnect
	MBT_SAP_STATE_SENDING				// be sending data
}T_MBT_SAP_STATE;

// SAP card reader status
typedef enum
{
	MBT_SAP_CARD_READER_STATUS_ATTACHED,	// Card Reader is attached
	MBT_SAP_CARD_READER_STATUS_REMOVED	// Card Readeris removed
} T_MBT_SAP_CARD_READER_STATUS;

// SAP disconnect
typedef enum
{
	MBT_SAP_GRACEFUL_DISCONNECT,  	// Graceful disconnection
	MBT_SAP_IMMEDIATE_DISCONNECT	// Immediate disconnection
} T_MBT_SAP_DISCONNECT;

// SAP transport protocol
typedef enum
{
	MBT_SAP_TRANSPORT_T_0, 	//T=0
	MBT_SAP_TRANSPORT_T_1	// T=1
}T_MBT_SAP_TRANSPORT_PROTOCOL;

// SAP APDU command
typedef struct 
{
	MBT_BYTE 	ApduCmd[MBT_SAP_MAX_APDU_LEN];	// APDU command frame
	MBT_SHORT 	ApduCmdLength;						// APDU command length
}T_MBT_SAP_APDU_CMD;

// SAP APDU response
typedef struct 
{
	T_MBT_SAP_RESULT_CODE	ResultCode; 							// result of APDU command
       MBT_BYTE   				ApduRes[MBT_SAP_MAX_APDU_LEN];	// APDU command frame
	MBT_SHORT 				ApduResLength;						// APDU command length
} T_MBT_SAP_APDU_RES;

// SAP ATR response
typedef struct 
{
	T_MBT_SAP_RESULT_CODE	ResultCode;  					// reult of ATR command
	MBT_BYTE     				AtrRes[MBT_SAP_MAX_ATR_LEN]; 	// ATR command frame
	MBT_SHORT				AtrResLength;  					// ATR command length
}T_MBT_SAP_ATR_RES;

// SAP card reader status
typedef struct 
{
	T_MBT_SAP_RESULT_CODE 			ResultCode; 			// result of requestion to card reader
	T_MBT_SAP_CARD_READER_STATUS	CardReaderStatus; 	// status of card reader
}T_MBT_SAP_CARD_READER_STATUS_RES;

// SAP status
typedef struct
{	
	MBT_BOOL								bServerEnabled;		//Server Enable
	T_MBT_BDADDR							BDAddr;				// Peer device addr	
	T_MBT_SAP_STATE						State;				// SAP state
	MBT_UINT								MaxMsgSize;			// max message size
	T_MBT_SAP_RESULT_CODE					Result;				// result code
	T_MBT_SAP_CONNECT_STATUS				ConnStatus;			// status of connectiion
	T_MBT_SAP_DISCONNECT					DisconnectType;		// disconnect type
	T_MBT_SAP_TRANSPORT_PROTOCOL			Protocol;			// transport protocol type
	T_MBT_SAP_APDU_CMD					ApduCmd;			// APDU command type
	T_MBT_SAP_APDU_RES						ApduRes;			// APDU response type
	T_MBT_SAP_ATR_RES						AtrRes;				// ATR response type
	T_MBT_SAP_CARD_READER_STATUS  		CardReaderStatus;	// status of card reader
	T_MBT_SAP_CARD_READER_STATUS_RES		CardReaderStatusRes;// response for status of card reader
	T_MBT_SAP_CARD_STATUS     				CardStatus;			// status of card
}T_MBT_SAP_STATUS;

/******************MISC*******************/

// Version 
typedef struct
{
	//MBT Version : ex) MBT 1.1
	MBT_CHAR	MbtVersion[MBT_MISC_MAX_MBT_VER_STR_LEN];
	//Stack Version1 : ex) BTE 10.3.10    
	MBT_CHAR	StackVersion1[MBT_MISC_MAX_STACK1_VER_STR_LEN];
	//Stack Version2 : ex) BCM2048A1_001.002.034.0082.0089
	MBT_CHAR	StackVersion2[MBT_MISC_MAX_STACK2_VER_STR_LEN];
}T_MBT_MISC_VERSION;

/********************************************************************************
*						DATA TYPE DEFINE END
********************************************************************************/

#endif//_MBT_TYPE_H_
