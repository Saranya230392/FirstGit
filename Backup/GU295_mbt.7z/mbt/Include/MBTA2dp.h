#ifndef _MBT_A2DP_H_
#define	_MBT_A2DP_H_

#include "MBTType.h"

extern MBT_VOID MBT_A2DP_SourceEnable(MBT_VOID);
extern MBT_VOID MBT_A2DP_SourceDisable(MBT_VOID);
extern MBT_VOID MBT_A2DP_SourceConnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_A2DP_SourceDisconnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_A2DP_SourceStart(MBT_VOID);
extern MBT_VOID MBT_A2DP_SourceStop(MBT_VOID);
extern MBT_VOID MBT_A2DP_SourcePause(MBT_VOID);
extern MBT_VOID MBT_A2DP_SourceResume(MBT_VOID);

#endif//_MBT_A2DP_H_
