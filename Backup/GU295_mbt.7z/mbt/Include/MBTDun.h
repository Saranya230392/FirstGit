#ifndef _MBT_DUN_H_
#define	_MBT_DUN_H_

#include "MBTType.h"

extern MBT_VOID MBT_DUN_Enable (MBT_VOID);
extern MBT_VOID MBT_DUN_Disable (MBT_VOID);
extern MBT_VOID MBT_DUN_Disconnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID MBT_DUN_Listen(MBT_VOID);
extern MBT_VOID MBT_DUN_ListenStop(MBT_VOID);

#endif//_MBT_DUN_H_