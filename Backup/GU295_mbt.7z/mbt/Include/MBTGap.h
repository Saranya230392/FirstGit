#ifndef _MBT_GAP_H_
#define	_MBT_GAP_H_

#include "MBTType.h"

extern MBT_BOOL	MBT_GAP_BTInitialize (MBT_VOID);
extern MBT_VOID	MBT_GAP_BluetoothOn(MBT_VOID);
extern MBT_VOID	MBT_GAP_BluetoothOff(MBT_VOID);
extern MBT_BOOL	MBT_GAP_SetMyName(MBT_CHAR* MyDevName);
extern MBT_BOOL	MBT_GAP_SetNickName(T_MBT_BDADDR PairedDevAddr, MBT_CHAR* NickName);
extern MBT_BOOL	MBT_GAP_SetConnectable(MBT_BOOL bConnectable);
extern MBT_BOOL	MBT_GAP_SetVisible(MBT_BOOL bVisibile);
extern MBT_BOOL	MBT_GAP_SetPairable(MBT_BOOL bPairabie);
extern MBT_BOOL	MBT_GAP_IsCmdAcceptable	(MBT_VOID);
extern MBT_BOOL	MBT_GAP_IsDeviceConnected(T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL	MBT_GAP_IsSvcConnected(MBT_SERVICE_ID MBTSvc);
extern MBT_BOOL	MBT_GAP_IsAuthorized(T_MBT_BDADDR RemoteBDAddr);
extern MBT_VOID	MBT_GAP_DevDiscovery(MBT_SERVICE_ID MBTSvc, MBT_INT nMaxCount);
extern MBT_VOID	MBT_GAP_DevDiscoveryCancel(MBT_VOID);
extern MBT_VOID	MBT_GAP_NameReq(T_MBT_BDADDR RemoteBdAddr);
extern MBT_VOID	MBT_GAP_NameReqCancel(MBT_VOID);
extern MBT_VOID	MBT_GAP_SvcDiscovery(T_MBT_BDADDR RemoteBdAddr);
extern MBT_VOID	MBT_GAP_SvcDiscoveryCancel(MBT_VOID);
extern MBT_VOID	MBT_GAP_PairReq(T_MBT_BDADDR RemoteBdAddr, T_MBT_PIN PinReq, MBT_INT PinLength);
extern MBT_VOID	MBT_GAP_PairReqCancel(MBT_VOID);
extern MBT_VOID	MBT_GAP_PairRes(MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_INT PinLength);
extern MBT_VOID	MBT_GAP_SspRes(MBT_BOOL bAccept);
extern MBT_VOID	MBT_GAP_SspPasskeyCancel(MBT_VOID);
extern MBT_VOID	MBT_GAP_AuthorizationRes(MBT_BOOL bAccept, MBT_SERVICE_ID AuthSvc);
extern MBT_BOOL	MBT_GAP_UnPair(T_MBT_BDADDR RemoteBdAddr);
extern MBT_BOOL	MBT_GAP_UnPairAll(MBT_VOID);
extern MBT_BOOL	MBT_GAP_SetAuthorize(T_MBT_BDADDR RemoteBdAddr, MBT_BOOL bAuthorize);
extern MBT_BOOL	MBT_GAP_AddBlockDev(T_MBT_BDADDR BdAddr);
extern MBT_BOOL	MBT_GAP_RemoveBlockDev(T_MBT_BDADDR BdAddr);

#endif//_MBT_GAP_H_