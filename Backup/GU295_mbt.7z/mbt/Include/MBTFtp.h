#ifndef _MBT_FTP_H_
#define	_MBT_FTP_H_

#include "MBTType.h"

extern MBT_VOID MBT_FTP_ServerEnable (MBT_VOID);
extern MBT_VOID MBT_FTP_ServerDisable (MBT_VOID);
extern MBT_VOID MBT_FTP_ServerAccessRsp(T_MBT_AUTHRES Reply);
extern MBT_VOID MBT_FTP_ServerAuthRsp(T_MBT_OBEX_AUTH *auth_reply);
extern MBT_BOOL MBT_FTP_ServerSetRootFolder(MBT_CHAR *Rootfolder);

extern MBT_VOID MBT_FTP_ClientEnable (MBT_VOID);
extern MBT_VOID MBT_FTP_ClientDisable (MBT_VOID);
extern MBT_VOID MBT_FTP_ClientConnect(T_MBT_BDADDR remoteDev);
extern MBT_VOID MBT_FTP_ClientDisconnect(MBT_VOID);
extern MBT_VOID MBT_FTP_ClientAuthRsp(T_MBT_OBEX_AUTH *auth_reply);
extern MBT_VOID MBT_FTP_ClientPutFile(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID MBT_FTP_ClientGetFile(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID MBT_FTP_ClientChDir(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID MBT_FTP_ClientMkDir(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID MBT_FTP_ClientListDir(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID MBT_FTP_ClientDelDir(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID MBT_FTP_ClientDelFile(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID MBT_FTP_ClientAbort(MBT_VOID);

#endif//_MBT_FTP_H_