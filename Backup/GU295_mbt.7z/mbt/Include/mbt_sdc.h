#ifndef _MBT_SDC_PI_H_
#define _MBT_SDC_PI_H_

#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID* mbt_sdc_getrecord(T_MBT_SDC_RECID MBTSDCRecID);
extern MBT_INT mbt_sdc_getvalue(T_MBT_SDC_VALID MBTSDCValID);
extern MBT_VOID	mbt_sdc_initdata(MBT_VOID);

#endif//_MBT_SDC_PI_H_
