#ifndef _MBT_DEBUGMSG_H_
#define _MBT_DEBUGMSG_H_

#include "MBTConfig.h"

#ifdef MBT_EMULATOR
	#ifdef MBT_DEBUGMSG
		#if MBT_TARGET_PLATFORM == WISE_PLATFORM
			#ifndef __func__
			#define __func__ "N/A"
			#endif
			#define MBT_FATAL(x)			SysUtil_WriteLog("�ۡ�"x)
			#define MBT_ERR(x, p1, p2, p3)	SysUtil_WriteLog("�ۡ�"x, p1, p2, p3)
			#define MBT_WARN(x, p1, p2, p3)	SysUtil_WriteLog("�ۡ�"x, p1, p2, p3)
			#define MBT_API(x)				//osh mbtemul SysUtil_WriteLog("�ۡ�"x)
			#define MBT_EVENT(x,p1)			//osh mbtemul SysUtil_WriteLog("�ۡ�"x, p1)
			#define MBT_SDC(x, p1, p2, p3)	SysUtil_WriteLog("�ۡ�"x, p1, p2, p3)
			#define MBT_PI(x,p1,p2,p3)		SysUtil_WriteLog("�ۡ�"x,p1,p2,p3)
		#endif//WISE_PLATFORM
	#endif
#else
	#ifdef MBT_DEBUGMSG
		#if MBT_TARGET_BASEBAND == QUALCOMM
			#include "Msg.h"

			//winapi 07.10.07
			//Type �� �´°ɷ� ��� ����Ͻÿ�.
			#define MBT_FATAL(x)		MSG_3(MSG_SSID_BT,MSG_LEGACY_FATAL,x,0,0,0)	
			#define MBT_ERR(x, p1, p2, p3) MSG_3(MSG_SSID_BT,MSG_LEGACY_ERROR,x,p1,p2,p3)	
			#define MBT_WARN(x, p1, p2, p3) MSG_3(MSG_SSID_BT,MSG_LEGACY_ERROR,x,p1,p2,p3)
			#define MBT_API(x) MSG_3(MSG_SSID_BT,MSG_LEGACY_MED,x,0,0,0)
			#define MBT_EVENT(x,p1) MSG_3(MSG_SSID_BT,MSG_LEGACY_HIGH,x,p1,0,0)
			#define MBT_SDC(x, p1, p2, p3) MSG_3(MSG_SSID_BT,MSG_LEGACY_MED,x,p1,p2,p3)
			#define MBT_PI(x, p1, p2, p3) MSG_3(MSG_SSID_BT,MSG_LEGACY_MED,x,p1,p2,p3)
		
		#endif//ASDP_PLATFORM
	
		#if MBT_TARGET_BASEBAND == INFINEON

		#endif
		
	#else//MBT_DEBUGMSG
		#define MBT_FATAL(x)	
		#define MBT_ERR(x, p1, p2, p3)
		#define MBT_WARN(x, p1, p2, p3)
		#define MBT_API(x)
		#define MBT_EVENT(x,p1)
		#define MBT_SDC(x, p1, p2, p3)
		#define MBT_PI(x, p1, p2, p3)
	#endif
#endif



#endif//_MBT_EVHANDLER_H_
