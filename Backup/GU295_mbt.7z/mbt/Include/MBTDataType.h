#ifndef _MBT_DATA_TYPE_H_
#define	_MBT_DATA_TYPE_H_


#include 	"MBTConfig.h"

// 1Byte
#define MBT_CHAR char
#define MBT_BYTE unsigned char
#define MBT_BOOL unsigned char

// 2Byte
#define MBT_SHORT unsigned short

// 4Byte
#define MBT_INT int
#define MBT_UINT unsigned int

// 8Byte
#ifdef WIN32
#define MBT_INT64	__int64
#define MBT_UINT64	unsigned __int64
#else
#define MBT_INT64	long long
#define MBT_UINT64	unsigned long long
#endif

// etc
#define MBT_TRUE 1
#define MBT_FALSE 0
#define MBT_WOULDBLOCK -1
#define MBT_VOID void
#define MBT_NULL 0

#endif//_MBT_DATA_TYPE_H_

