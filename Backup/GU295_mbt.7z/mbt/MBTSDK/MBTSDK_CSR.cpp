// MBTSDK.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <afxdllx.h>
#include <windows.h>
#include <stdio.h>
#include <malloc.h>
#include "sched/types.h" 
#include "sched/pmalloc.h" 
#include "sched/sched.h" 
#include "buffer.h"
#include "bsp.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern "C" {


}

#define REFRESH_RATE	1	// frames per second

static HWND windowHandle;

static AFX_EXTENSION_MODULE MBTSDKDLL = { NULL, NULL };

static HANDLE terminateRefreshThreadEvent;
static HANDLE terminatedRefreshThreadEvent;
static HANDLE TerminatedSchedThreadEvent;
DWORD SchedThread(void)
{
	sched();

	SetEvent(TerminatedSchedThreadEvent);

	ExitThread(0x0CBA);

	return 0;	// lint
}

DWORD RefreshThread(void)
{
	DWORD returnValue;

	do
	{
		switch (returnValue = WaitForSingleObject(terminateRefreshThreadEvent, 1000 / REFRESH_RATE))
		{
			case WAIT_TIMEOUT:
				InvalidateRect(windowHandle, NULL, FALSE);
				break;
		}
	} while (returnValue != WAIT_OBJECT_0);

	SetEvent(terminatedRefreshThreadEvent);

	ExitThread(0x0CBA);

	return 0x0CBA;
}
static uint16_t WordLength(char *string)
{
    bool_t verbatim = FALSE;
    uint16_t l;

    for (l = 0; *string != 0; string++)
    {
        if (*string == '"')
        {
            verbatim = !verbatim;
        }
        l++;
        if ((!verbatim) && (*string == 0x20))
        {
            break;
        }
    }

    return l;
}

static uint16_t StringSplit(char *argv_argc, char ***argv)
{
    bool_t verbatim = FALSE;
    char *sptr;
    uint16_t count;
    uint16_t i,j;

    /* Skip leading spaces */
    while (*argv_argc == 0x20)
    {
        argv_argc++;
    }

    /* Destroy trailing spaces */ 
    for (sptr = argv_argc; *sptr != 0; sptr++)
    {
    }
    for (sptr--; *sptr == 0x20; sptr--)
    {
        *sptr = 0;
    }

    /* Count number of items */
    count = 0;
    for (sptr = argv_argc; *sptr != 0; sptr++)
    {
        /* Skip verbatim input */
        if (*sptr == '"')
        {
            while (*sptr != 0)
            {
                sptr++;
                if (*sptr == '"')
                {
                    sptr++;
                    break;
                }
            }
        }
        if (*sptr == 0x20) /* Space */
        {
            count++;
        }
    }
    count++;

    /* Allocate array of string pointers */
    *argv = (char **) pmalloc(sizeof(char *) * count);

    /* Fill the array with strings from the input */
    i = 0;
    for (sptr = argv_argc; i < count; sptr++)
    {
        (*argv)[i] = (char *) pmalloc(WordLength(sptr)+1);
        for (j = 0; *sptr != 0; j++)
        {
            if (*sptr == '"')
            {
                verbatim = !verbatim;
            }
            (*argv)[i][j] = *sptr++;
            if ((!verbatim) && (*sptr == 0x20)) /* Space */
            {
                j++;
                break;
            }
        }
        (*argv)[i][j] = 0;
        i++;
    }
    return count;
}

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	DWORD   thread_address;
	int argc;
    char **argv;
	MSG msg;
	DWORD threadId;
	HANDLE threadHandle;
	DWORD threadExitCode = 0;

	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("MBTEMUL.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(MBTSDKDLL, hInstance))
			return 0;

		
		// Insert this DLL into the resource chain
		// NOTE: If this Extension DLL is being implicitly linked to by
		//  an MFC Regular DLL (such as an ActiveX Control)
		//  instead of an MFC application, then you will want to
		//  remove this line from DllMain and put it in a separate
		//  function exported from this Extension DLL.  The Regular DLL
		//  that uses this Extension DLL should then explicitly call that
		//  function to initialize this Extension DLL.  Otherwise,
		//  the CDynLinkLibrary object will not be attached to the
		//  Regular DLL's resource chain, and serious problems will
		//  result.


	terminateRefreshThreadEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if (terminateRefreshThreadEvent == NULL)
	{
		return FALSE;
	}
	terminatedRefreshThreadEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if (terminatedRefreshThreadEvent == NULL)
	{
		CloseHandle(terminateRefreshThreadEvent);
		return FALSE;
	}

    /* Start refresh thread */
//	threadHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) RefreshThread, NULL, 0, &threadId);
	if (threadHandle == INVALID_HANDLE_VALUE) 
	{
		CloseHandle(terminateRefreshThreadEvent);
		CloseHandle(terminatedRefreshThreadEvent);
		return FALSE;
	}

	TerminatedSchedThreadEvent = CreateEvent(NULL, FALSE, FALSE, NULL);
	if (TerminatedSchedThreadEvent == NULL)
	{
		SetEvent(terminateRefreshThreadEvent);
		WaitForSingleObject(terminatedRefreshThreadEvent, INFINITE);
		do
		{
			if (GetExitCodeThread(threadHandle, &threadExitCode))
			{
				if (threadExitCode == STILL_ACTIVE)
				{
					Sleep(0);
				}
			}
		} while (threadExitCode == STILL_ACTIVE);
		CloseHandle(terminateRefreshThreadEvent);
		CloseHandle(terminatedRefreshThreadEvent);
		return FALSE;
	}

    /* Init scheduler */
    init_pmalloc();
    init_buf();
	init_sched();

    /* Init application */
    
	argc = StringSplit((char *) GetCommandLine(), &argv);
    BspAppPreInit(argc, argv);
    
    /* Free the memory allocated by StringSplit */
    
	for (; argc > 0; argc--)
    {
        pfree(argv[argc-1]);
    }
    pfree(argv);




    /* Start scheduler */
	threadHandle = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE) SchedThread, NULL, 0, &threadId);
    return 1;

	if (threadHandle == INVALID_HANDLE_VALUE) 
	{
		SetEvent(terminateRefreshThreadEvent);
		WaitForSingleObject(terminatedRefreshThreadEvent, INFINITE);
		do
		{
			if (GetExitCodeThread(threadHandle, &threadExitCode))
			{
				if (threadExitCode == STILL_ACTIVE)
				{
					Sleep(0);
				}
			}
		} while (threadExitCode == STILL_ACTIVE);
		CloseHandle(terminateRefreshThreadEvent);
		CloseHandle(terminatedRefreshThreadEvent);
		CloseHandle(TerminatedSchedThreadEvent);
		return FALSE;
	}

	// Main message loop:
	while (GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	sched_stop();

	WaitForSingleObject(TerminatedSchedThreadEvent, INFINITE);
	do
	{
		if (GetExitCodeThread(threadHandle, &threadExitCode))
		{
			if (threadExitCode == STILL_ACTIVE)
			{
				Sleep(0);
			}
		}
	} while (threadExitCode == STILL_ACTIVE);

	CloseHandle(TerminatedSchedThreadEvent);
	
	SetEvent(terminateRefreshThreadEvent);
	WaitForSingleObject(terminatedRefreshThreadEvent, INFINITE);
	do
	{
		if (GetExitCodeThread(threadHandle, &threadExitCode))
		{
			if (threadExitCode == STILL_ACTIVE)
			{
				Sleep(0);
			}
		}
	} while (threadExitCode == STILL_ACTIVE);

	CloseHandle(terminateRefreshThreadEvent);
	CloseHandle(terminatedRefreshThreadEvent);

/*    DisplayDriverDeinitLock();*/

/*    BspAppPreStop();*/

    sched_task_deinit();
    deinit_sched();
    deinit_pmalloc();

	return msg.wParam;


	new CDynLinkLibrary(MBTSDKDLL);
	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("MBTEMUL.DLL Terminating!\n");
		// Terminate the library before destructors are called
		AfxTermExtensionModule(MBTSDKDLL);
	}
	return 1;   // ok
}
