/*******************************************************************************
*	JSR82�� MBT 1.0���� ���Ե��� ������ �׽�Ʈ ���� �ʾҽ��ϴ�.
*	JSR82_QBT�� ����4�� Makalu�� ����� ���� �ۼ��Ǿ�����,����4�� VM �� �Ʒθ� VM �� �°�
*	�ۼ��� �Ǿ����ϴ�. ���� QBT�� ����Ǵ� JSR82�� Optimize�� ���� �ʿ��Ҽ� �ֽ��ϴ�.
********************************************************************************/
/********************************************************************************
*	File Name		:mbt_jsr82_qbt.c
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.05.17		Hanseok Park			Created
*	07.06.22		Hanseok Park			Modified the JSR82 API names
*	08.01.15		ChangHoon Lee			JSR82 porting for QBT
********************************************************************************/
#include "mbt_jsr82.h"
#include "mbt_gap.h"

#if (MBT_AG == MBT_TRUE)
#include "mbt_ag.h"
#endif
#if (MBT_OPP == MBT_TRUE)
#include "mbt_opp.h"
#endif
#if (MBT_FTP == MBT_TRUE)
#include "mbt_ftp.h"
#endif
#if (MBT_DUN == MBT_TRUE)
#include "mbt_dun.h"
#endif
#if (MBT_SPP == MBT_TRUE)
#include "mbt_spp.h"
#endif
#if (MBT_A2DP == MBT_TRUE)
#include "mbt_a2dp.h"
#endif
#if (MBT_AVRCP == MBT_TRUE)
#include "mbt_avrcp.h"
#endif

#include "mbt_sdc.h"
#include "qbt_utils/qbt_utils.h"
#include "mbt_evhandler.h"
#include "include/mbt_internal_func.h"

#include "bt.h"
#include "btsd.h"

// LEECHANGHOON 2008-1-17 �ӽ� �߰� under 1 line
#include "PalDef_OemBt.h"
#include "qbt_utils/qbt_bt_l2.h"	
#include "qbt_utils/qbt_bt_spp.h"


#define SETTING_LOCAL_NAME      	0x01
#define SETTING_LOCAL_COD       	0x02
#define SETTING_LOCAL_SECURITY  	0x04
#define ENABLING_AUTO_SRV_SRCH  	0x08
#define DISABLING_AUTO_SRV_SRCH 	0x10

#define			UUID_16	    	25   // 0x19
#define 		UUID_32         	26   // 0x1a
#define 		UUID_128       	28   // 0x1c
#define			U_INT_1		0x08	//unsigned int 1byte
#define			U_INT_2		0x09
#define			U_INT_4		0x0a

#define			STR_1			0x25	//Text string , string size is in next 1 bute.

#define			DATA_SEQ_1	0x35	//sequence of data element , data size is in next 1byte.
#define			DATA_SEQ_2	0x36	//sequence of data element , data size is in next 1byte.
#define			DATA_SEQ_4	0x37	//sequence of data element , data size is in next 1byte.

#define	L2CAP_REGISTER_VERSION	0x0100
#define	L2CAP_SCN 				BT_RC_SCN_NOT_SPECIFIED


typedef enum
{
	BTSD_IDLE,
	BTSD_SEARCHING,
	BTSD_NAME_REQUEST,
	BTSD_CANCEL
} MBT_SD_STATE_TYPE;

typedef enum
{
  BT_RM_CMD_NONE,
  BT_RM_CMD_SET_DEVICE_SECURITY_FOR_JSR82,
  BT_RM_CMD_SET_SERVICE_SECURITY_FOR_JSR82,
  BT_RM_CMD_END
} MBT_SEC_CMD_STATE;

//yucha 2008/05/07 start: separate service search from attribute search
typedef enum
{
	BTSD_SVC_IDLE,
	BTSD_SVC_SEARCH,
	BTSD_SVC_ATTRI_SEARCH
}MBT_SD_SVC_SEARCH_STATE;

typedef struct _SvcHnadle
{
	uint32 svcHdl[MBT_JSR82_MAX_SEARCH_UUID_NUM];
	int totHdlCnt;
	int curHdlIndex;
}SvcHandle;

typedef struct _AttriInfo
{
	uint32 attriValue[MBT_JSR82_MAX_ATTR_ID_NUM];
	int totAttriCnt;
	int curAttriIndex;
}AttriInfo;

//yucha 2008/05/07 end

//------------- extern vairable  ----------------------//
extern bt_app_id_type  mbt_rm_app_id;
extern bt_app_id_type  mbt_sd_app_id;
//------------- extern function ----------------------//
extern void bt_sd_service_attribute_add_unknown(
								bt_sd_srv_attr_rec_type*  srv_attr_ptr,
								uint8                     val,
								uint8                     len,
								const byte*               str
);
//------------- global vairable  ----------------------//
// LEECHANGHOON 2008-1-18 System BT���� ������.
uint32 gJSR82_Handle = MBT_NULL;	//chosw 2006-12-21 : bt_sd_create_service_record�� ������ sr_ptr->srv_rec_id ���� 
MBT_BOOL JSR82BT_enable;
MBT_BYTE SetSecurity_cmd_state = BT_RM_CMD_NONE; // LEECHANGHOON 2008-1-28 MBT���� Security������ Device�� Service�� ���еǾ��־� �ʿ���.
bt_app_id_type  mbt_jsr82_app_id = BT_APP_ID_NULL; // LEECHANGHOON 2008-2-5 MBT���� Global�� ����. service_security��������..
MBT_BOOL authoReqJSR82 = FALSE;
MBT_BOOL bSearchPending = MBT_FALSE;

//------------- local variable  ----------------------//
static MBT_INT gDeviceRecordsIdx = 0;
//static MBT_INT btNameRespIdx = 0;
static MBT_SD_STATE_TYPE JSR82_sdStatus = BTSD_IDLE;
static MBT_SHORT createdSvcRecUUID;
static MBT_UINT gSvcHandle = 0;
static T_MBT_JSR82_SD_RECORD	searchedSvcRec[MBT_JSR82_MAX_SEARCH_UUID_NUM];
static bt_bd_addr_type jsr82_pairreq_addr;

static MBT_SHORT		localSetting = 0;
//static MBT_UINT discoverable_mode = MBT_DISCOVERABLE_MODE_NONE;

//yucha 2008/05/07 start: separate service search from attribute search
static bt_sd_srch_pat_uuid_list_type	 uuid_list;
static bt_sd_srch_pat_attr_id_list_type attr_id_list;
MBT_SD_SVC_SEARCH_STATE svcSearchState = BTSD_SVC_IDLE;
static SvcHandle svcHandle;
static AttriInfo attriInfo;
static uint8 numRecs;
static int serviceRecCurIndex;

//yucha 2008/05/07 end

//------------- connected device information ---------//
static bt_bd_addr_type 		svcSearchBdAddr;
bt_rm_handle_type 	jsr82Handle = 0xff;
bt_app_id_type		acl_app_id = 0xff;

MBT_INT		securityIdx = -1;

#if (MBT_JSR82 == MBT_TRUE)

//------------- local function  ----------------------//
static MBT_VOID mbt_jsr82_set_serviceSecurity(MBT_VOID);

static MBT_BOOL mbt_jsr82_CheckCmdStatus( bt_cmd_status_type stat )
{
	MBT_PI( __func__"##########################", 0, 0, 0);
	switch (stat)
	{
		case BT_CS_GN_SUCCESS:
		case BT_CS_GN_PENDING:
			return MBT_TRUE; //SUCCESS;

		case BT_CS_GN_CMD_Q_FULL:
			return MBT_FALSE; //ENOMEMORY;

		default:
			return MBT_FALSE; //EFAILED;
	}
}

void encodeShortLen(uint8 * b ,int off,long value) 
{			
	MBT_PI( __func__"##########################", 0, 0, 0);
	b[off] 	 	 =  ((value>> 8) & 0xff);			
	b[off +1 ]	 =   (value & 0xff);									
}

void encodeint(uint8 * b ,int off, long v) 
{			
	b[off++] = (uint8) ((v >> 24) & 0xff);
	b[off++] = (uint8) ((v >> 16) & 0xff);
	b[off++] = (uint8) ((v >> 8) & 0xff);
	b[off++] = (uint8) (v & 0xff);		 					 
}

MBT_INT mbt_jsr82_getEmptyIdx(MBT_VOID)
{
	T_MBT_JSR82_STATUS* jsr82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	int i;
	MBT_PI( __func__"##########################", 0, 0, 0);
	for(i=1; i<MBT_JSR82_MAX_EVENT_NUM; i++)
	{
		if(jsr82Status->EvInfo[i].Used != MBT_TRUE)
		{
			return i;
		}
	}
	return -1;
}

static void mbt_jsr82_fillSearchAttribute(bt_sd_srch_pat_attr_id_list_type* attr_id_list, AttriInfo* attriInfo)
{
	int i;
	attr_id_list->num_attr_id = 0x00;
	for(i=0; i<3; i++)
	{
		if(attriInfo->curAttriIndex < attriInfo->totAttriCnt)
		{
			attr_id_list->attr_id[attr_id_list->num_attr_id].is_range = MBT_FALSE; 
			attr_id_list->attr_id[attr_id_list->num_attr_id].value = attriInfo->attriValue[attriInfo->curAttriIndex]; 
			attr_id_list->num_attr_id++;
			attriInfo->curAttriIndex++;
		}
	}
}

static void mbt_jsr82_initSvcSearchVar(void)
{
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	memset((void*)&svcHandle, 0x00, sizeof(svcHandle));
	memset((void*)searchedSvcRec, 0x00, sizeof(searchedSvcRec));
	numRecs = 0;
	sdcJSR82Status->SvcRecNum = 0;
	serviceRecCurIndex = 0;
}

static void mb_jsr82_copySvcHandle(SvcHandle* svcHandle, bt_sd_srv_rec_type* pRec)
{
	int areadyExistHdl= FALSE;
	int j;
	for(j=0; j<svcHandle->totHdlCnt; j++)
	{
		if(svcHandle->svcHdl[j] == pRec->srv_rec_id)
		{
			areadyExistHdl = TRUE;
			break;
		}
	}
	MBT_PI("svcHandle.totHdlCnt # :%d, j:%d", svcHandle->totHdlCnt, j, pRec->srv_rec_id);
	if(!areadyExistHdl) // �ߺ�����. �̹� �����ϴ� svcHandle�� ��� skip.
	{
		svcHandle->svcHdl[svcHandle->totHdlCnt] = pRec->srv_rec_id;
		svcHandle->totHdlCnt++;
	}
}

static MBT_BOOL checkLastAttribute(AttriInfo* attriInfo)
{
	return (attriInfo->curAttriIndex == attriInfo->totAttriCnt);
}

static MBT_BOOL checkLastSvcHandle(SvcHandle* svcHandle)
{
	return (svcHandle->totHdlCnt == svcHandle->curHdlIndex+1);
}

static MBT_BOOL checkKeepSearch(MBT_SD_SVC_SEARCH_STATE* svcSearchState,  AttriInfo* attriInfo, SvcHandle* svcHandle)
{
	return ((*svcSearchState == BTSD_SVC_SEARCH && 
		attriInfo->totAttriCnt!= 0x00 && svcHandle->totHdlCnt != 0x00) || 
		(*svcSearchState == BTSD_SVC_ATTRI_SEARCH && 
		attriInfo->totAttriCnt!= 0x00 && svcHandle->totHdlCnt != 0x00));
}

/*===========================================================================

FUNCTION
  mbt_jsr82_convert_qbt_service_class

DESCRIPTION
  Convert service class for qbt layer. Incoming service class from Java has fixed type format like below.

  -------------------------------------------------------------------
  23             16 | 15               8 | 7                   0
      Octet3               Octet2              Octet1
  <-------11bit------><--5bit-><--6bit-><-2bit->
      Service Classes        Mjr cls      Min cls    0  0
  -------------------------------------------------------------------
      13 bit: Limited Discoverable Mode
      14 bit: (reserved)
      15 bit:(reserved)
      16 bit:Positioning (Location identification)
      17 bit:Networking (LAN, Ad hoc, ...)
      18 bit:Rendering (Printing, Speaker, ...)
      19 bit:Capturing (Scanner, Microphone, ...)
      20 bit:Object Transfer (v-Inbox, v-Folder, ...)
      21 bit:Audio (Speaker, Microphone, Headset service, ...)
      22 bit:Telephony (Cordless telephony, Modem, Headset service, ...)
      23 bit:Infomation (WEB-server, WAP-server, ...)
===========================================================================*/
MBT_SHORT mbt_jsr82_convert_qbt_service_class(MBT_SHORT service_class)
{
	MBT_SHORT service_class_qbt = 0;

	if (service_class & 0x01)
		service_class_qbt |= BT_SERVICE_CLASS_LIMITED_DISCOVERABLE_MODE;
	
	/* Extract service class */
	if ( (service_class >> 3) & BT_SD_MAJOR_SERVICE_CLASS_INFORMATION )
	{
		service_class_qbt |= BT_SERVICE_CLASS_INFORMATION;
	}
	if ( (service_class >> 3) & BT_SD_MAJOR_SERVICE_CLASS_TELEPHONY )
	{
		service_class_qbt |= BT_SERVICE_CLASS_TELEPHONY;
	}
	if ( (service_class >> 3) & BT_SD_MAJOR_SERVICE_CLASS_AUDIO )
	{
		service_class_qbt |= BT_SERVICE_CLASS_AUDIO;
	}
	if ( (service_class >> 3) & BT_SD_MAJOR_SERVICE_CLASS_OBJECT_TRANSFER )
	{
		service_class_qbt |= BT_SERVICE_CLASS_OBJECT_TRANSFER;
	}
	if ( (service_class >> 3) & BT_SD_MAJOR_SERVICE_CLASS_CAPTURING )
	{
		service_class_qbt |= BT_SERVICE_CLASS_CAPTURING;
	}
	if ( (service_class >> 3) & BT_SD_MAJOR_SERVICE_CLASS_RENDERING )
	{
		service_class_qbt |= BT_SERVICE_CLASS_RENDERING;
	}
	if ( (service_class >> 3) & BT_SD_MAJOR_SERVICE_CLASS_NETWORKING )
	{
		service_class_qbt |= BT_SERVICE_CLASS_NETWORKING;
	}
	if ( (service_class >> 3) & BT_SD_MAJOR_SERVICE_CLASS_POSITIONING )
	{
		service_class_qbt |= BT_SERVICE_CLASS_POSITIONING;
	}

	return service_class_qbt;
}

/*===========================================================================

FUNCTION
  bt_sd_build_class_of_device

DESCRIPTION
  Builds the class of device from 3 components: service class, major
  device class, and minor device class.

===========================================================================*/
MBT_VOID mbt_jsr82_build_class(MBT_SHORT svc_cls, MBT_SHORT mjr_dev_cls, MBT_SHORT mnr_dev_cls, bt_cod_type* cod_ptr)
{
	MBT_SHORT svc_class_qbt = 0;

	MBT_PI( __func__"##########################", 0, 0, 0);

	svc_class_qbt = mbt_jsr82_convert_qbt_service_class(svc_cls);
	MBT_PI( __func__"Service Class for QBT 0x%x", svc_class_qbt, 0, 0);
	if ( svc_class_qbt & BT_SERVICE_CLASS_INFORMATION )
		cod_ptr->cod_bytes[2] |= BT_SD_MAJOR_SERVICE_CLASS_INFORMATION;
	if ( svc_class_qbt & BT_SERVICE_CLASS_TELEPHONY )
		cod_ptr->cod_bytes[2] |= BT_SD_MAJOR_SERVICE_CLASS_TELEPHONY;
	if ( svc_class_qbt & BT_SERVICE_CLASS_AUDIO )
		cod_ptr->cod_bytes[2] |= BT_SD_MAJOR_SERVICE_CLASS_AUDIO;
	if ( svc_class_qbt & BT_SERVICE_CLASS_OBJECT_TRANSFER )
		cod_ptr->cod_bytes[2] |= BT_SD_MAJOR_SERVICE_CLASS_OBJECT_TRANSFER;
	if ( svc_class_qbt & BT_SERVICE_CLASS_CAPTURING )
		cod_ptr->cod_bytes[2] |= BT_SD_MAJOR_SERVICE_CLASS_CAPTURING;
	if ( svc_class_qbt & BT_SERVICE_CLASS_RENDERING )
		cod_ptr->cod_bytes[2] |= BT_SD_MAJOR_SERVICE_CLASS_RENDERING;
	if ( svc_class_qbt & BT_SERVICE_CLASS_NETWORKING )
		cod_ptr->cod_bytes[2] |= BT_SD_MAJOR_SERVICE_CLASS_NETWORKING;
	if ( svc_class_qbt & BT_SERVICE_CLASS_POSITIONING )
		cod_ptr->cod_bytes[2] |= BT_SD_MAJOR_SERVICE_CLASS_POSITIONING;
	if ( svc_class_qbt & BT_SERVICE_CLASS_LIMITED_DISCOVERABLE_MODE )
		cod_ptr->cod_bytes[1] |= 0x20;
	cod_ptr->cod_bytes[1] |= (mjr_dev_cls);
	cod_ptr->cod_bytes[0] |= ((mnr_dev_cls & 0xFF) << 2);
}


MBT_VOID mbt_jsr82_getsearchresult(	//chosw 2006-11-28 ���� 
  //BTServiceRecord* pDestRec,
  T_MBT_JSR82_SD_RECORD* pDestRec,
  bt_sd_srv_rec_type* pSrcRec
)
{
	bt_sd_srv_attr_rec_type*  pAttr;
	uint8 i,j,k,l,m;
	MBT_PI( __func__"##########################", 0, 0, 0);
	MBT_PI( "-------------------------------------------", 0, 0, 0);
	MBT_PI( __func__" pSrcRec->srv_uuid : %x, pSrcRec->num_srv_attr : %x, pSrcRec->is_custom_srv:%d", pSrcRec->srv_uuid, pSrcRec->num_srv_attr, pSrcRec->is_custom_srv);
	MBT_PI( "-------------------------------------------", 0, 0, 0);

	if(serviceRecCurIndex == 0x00)
	{
		if(pSrcRec->is_custom_srv)
		{
			pDestRec->bCustomSvc = MBT_TRUE;
			memcpy( (void*)&pDestRec->UUID128, (void*)&pSrcRec->srv_uuid128 , sizeof(T_MBT_UUID128));
		}
		else
		{
			pDestRec->bCustomSvc = MBT_FALSE;
			pDestRec->UUID = pSrcRec->srv_uuid; 
		}
	}
	//MBT_PI( __func__"#####  BEFORE  pDestRec->NumAttr:%d, pSrcRec->num_srv_attr:%d", pDestRec->NumAttr, pSrcRec->num_srv_attr, 0);
	pDestRec->NumAttr += pSrcRec->num_srv_attr;
	MBT_PI( __func__"#### pDestRec->NumAttr:%d, pSrcRec->num_srv_attr:%d, serviceRecCurIndex:%d", pDestRec->NumAttr, pSrcRec->num_srv_attr, serviceRecCurIndex);
	
	bt_sd_srv_attr_iter.init(pSrcRec, BT_SD_ITER_ALL);
  
  	for(pAttr = (bt_sd_srv_attr_rec_type*) bt_sd_srv_attr_iter.first(), j = serviceRecCurIndex;
        pAttr != 0 && (j < MBT_JSR82_MAX_ATTR_ID_NUM);
        pAttr = (bt_sd_srv_attr_rec_type*) bt_sd_srv_attr_iter.next(), j++ )
  	{
		serviceRecCurIndex++;
   		pDestRec->Attr[j].AttrID  = pAttr->attr_id;
    	pDestRec->Attr[j].AttrType = (T_MBT_JSR82_SD_ATTR)pAttr->attr_type;

		MBT_PI("[mbt_jsr82_getsearchresult] AttrID : %04x  AttrType : 0x%x\n", pAttr->attr_id, pAttr->attr_type,0);	
		switch (pAttr->attr_type)
    	{
		case MBT_JSR82_SD_ATTR_UUID_LIST:
			pDestRec->Attr[j].Value.UUIDList.NumUUID128s = pAttr->attr_value.uuid_list.num_uuid128;

			for ( k=0; k<pAttr->attr_value.uuid_list.num_uuid128 && k<MBT_JSR82_MAX_128_UUID_NUM; k++ )
			{
				memcpy(
				(void*)&pDestRec->Attr[j].Value.UUIDList.UUID128[k],
				(void*)&pAttr->attr_value.uuid_list.uuid128[k],
				sizeof(T_MBT_UUID128));
			}

			pDestRec->Attr[j].Value.UUIDList.NumUUIDs = pAttr->attr_value.uuid_list.num_uuid;
			for ( k=0; k<pAttr->attr_value.uuid_list.num_uuid && k<MBT_JSR82_MAX_SEARCH_UUID_NUM;k++)
			{
				pDestRec->Attr[j].Value.UUIDList.UUID[k] = pAttr->attr_value.uuid_list.uuid[k];
			}
				
			break;
		case MBT_JSR82_SD_ATTR_PROTO_DESC_LIST:
			pDestRec->Attr[j].Value.ProtoDescList.NumProtoDes = 
			pAttr->attr_value.proto_desc_list.num_proto_desc;
			for(k=0; k<pAttr->attr_value.proto_desc_list.num_proto_desc && k<MBT_JSR82_MAX_PROTO_DESC_NUM; k++)
			{					
				uint8 idx;
				T_MBT_JSR82_PROTOCOL_DESC* pProtoDesc = &pDestRec->Attr[j].Value.ProtoDescList.ProtoDesc[k];
				bt_sd_proto_desc_type *pSrcPD = &pAttr->attr_value.proto_desc_list.proto_desc[k];

				if(pSrcPD->is_uuid128 )
				{
					pProtoDesc->BUUID128 = MBT_TRUE;
					memcpy((void*)&pProtoDesc->UUID128, (void*)&pSrcPD->uuid128,  sizeof(T_MBT_UUID128));
				}
				else
				{
					pProtoDesc->BUUID128 = MBT_FALSE;
					pProtoDesc->UUID    = pSrcPD->uuid;
				}
				pProtoDesc->NumParam = pSrcPD->num_param;
				//param ������ Ȯ�� �ǳ� ��
				//memcpy(pProtoDesc->Param, pSrcPD->param, sizeof(pProtoDesc->Param));
				for(idx=0; idx<pProtoDesc->NumParam;idx++)
				{
					pProtoDesc->Param[idx].Size = pSrcPD->param[idx].size;
					pProtoDesc->Param[idx].Value = pSrcPD->param[idx].value;
				}
				MBT_PI( "[mbt_jsr82_getsearchresult]          pProtoDesc->NumParam:%d", pProtoDesc->NumParam, 0, 0);
				MBT_PI( "[mbt_jsr82_getsearchresult] pProtoDesc.Value:%d, pSrcPD.Value:%d", pProtoDesc->Param[0].Value, pSrcPD->param[0].value, 0);

			}
			break;

		// ����ü �����ϰ� ���� �θ��� ���� 
		case MBT_JSR82_SD_ATTR_ADDL_PROTO_DESC_LISTS:
			pDestRec->Attr[j].Value.AddProtoDescList.NumProtoListDes = 0;
			for(k=0; k<MBT_JSR82_MAX_NUM_OF_ADD_PROTO_LIST_NUM; k++)
			{
				T_MBT_JSR82_PROTOCOL_DESC_LIST* pDestPDL = &pDestRec->Attr[j].Value.AddProtoDescList.ProtoDescList[k];
				bt_sd_proto_desc_list_type* pSrcPDL = &pAttr->attr_value.add_proto_desc_lists[k];

				pDestRec->Attr[j].Value.AddProtoDescList.NumProtoListDes++;

				pDestPDL->NumProtoDes = pSrcPDL->num_proto_desc;
				
				for (l = 0; l < pSrcPDL->num_proto_desc && l < MBT_JSR82_MAX_PROTO_DESC_NUM; l++ )
				{
					uint8 idx;
					T_MBT_JSR82_PROTOCOL_DESC* pDestPD = &pDestPDL->ProtoDesc[l];
					bt_sd_proto_desc_type* pSrcPD = &pSrcPDL->proto_desc[l];
					if(pSrcPD->is_uuid128 )
					{
						pDestPD->BUUID128 = MBT_TRUE;
						memcpy((void*)&pDestPD->UUID128, (void*)&pSrcPD->uuid128, sizeof(T_MBT_UUID128));
					}
					else
					{
						pDestPD->BUUID128 = MBT_FALSE;
						pDestPD->UUID    = pSrcPD->uuid;
					}
					pDestPD->NumParam = pSrcPD->num_param;
					
					//memcpy( (void*)pDestPD->Param, (void*)pSrcPD->param, sizeof(pDestPD->Param));
					for(idx = 0; idx<pDestPD->NumParam; idx++)
					{
						pDestPD->Param[idx].Size = pSrcPD->param[idx].size;
						pDestPD->Param[idx].Value = pSrcPD->param[idx].value;
					}

				}
			}
			break;

		// �ܼ� ����ü ������. 
		case MBT_JSR82_SD_ATTR_LANG_BASE_ATTR_ID_LIST:
			pDestRec->Attr[j].Value.LangBaseAttrList =
				*((T_MBT_JSR82_LANG_BASE_ATTR_LIST*)&pAttr->attr_value.lang_base_attr_id_list);
			break;

		case MBT_JSR82_SD_ATTR_UINT_LIST:
			pDestRec->Attr[j].Value.UintList.NumVal = MAX(pAttr->attr_value.uint_list.num_val, MBT_JSR82_MAX_UINT);

			for ( i=0; i<pDestRec->Attr[j].Value.UintList.NumVal; i++)
			{
				pDestRec->Attr[j].Value.UintList.Val[i] = pAttr->attr_value.uint_list.val[i];
			}
			break;


		case MBT_JSR82_SD_ATTR_STRING:
			MBT_PI( __func__"          [BT_SD_ATTR_TYPE_STRING]",0,0,0);
			memset( pDestRec->Attr[j].Value.Str,0,MBT_JSR82_MAX_STRING_LEN);
			memcpy( pDestRec->Attr[j].Value.Str, pAttr->attr_value.str,MBT_JSR82_MAX_STRING_LEN);
			break;
			
		case MBT_JSR82_SD_ATTR_UINT8:
		case MBT_JSR82_SD_ATTR_UINT16:
		case MBT_JSR82_SD_ATTR_UINT32:
		case MBT_JSR82_SD_ATTR_UINT64:
			pDestRec->Attr[j].Value.PrimitiveValue = pAttr->attr_value.primitive_value;
			break;
		case MBT_JSR82_SD_ATTR_BOOL:
			pDestRec->Attr[j].Value.BFlag = pAttr->attr_value.bool_flag;
			break;
			
		case MBT_JSR82_SD_ATTR_UNKNOWN:
			MBT_PI( "[mbt_jsr82_getsearchresult]          MBT_JSR82_SD_ATTR_UNKNOWN",0,0,0);
		case MBT_JSR82_SD_ATTR_HID_DESC_LIST:
			pDestRec->Attr[j].Value.HidDescList.NumHidDesc = pAttr->attr_value.hid_desc_list.num_hid_class_desc;
			MBT_PI( "[mbt_jsr82_getsearchresult]          NumHidDesc : %d ",pDestRec->Attr[j].Value.HidDescList.NumHidDesc,0,0);
			for ( k=0; k<pAttr->attr_value.hid_desc_list.num_hid_class_desc && k<MBT_JSR82_MAX_HID_DESC_NUM; k++)
			{
				T_MBT_JSR82_HID_DESC* pHIDClassDesc = &pDestRec->Attr[j].Value.HidDescList.HidDesc[k];
				bt_sd_hid_class_desc_type* pSrcHIDClassDesc = &pAttr->attr_value.hid_desc_list.hid_class_desc[k];

// attr-value�� header
				pHIDClassDesc->Header.Type = pSrcHIDClassDesc->header.type;
				pHIDClassDesc->Header.Size_index= pSrcHIDClassDesc->header.size_index;
				pHIDClassDesc->Header.Attr_value_len= pSrcHIDClassDesc->header.attr_value_len;
				MBT_PI( "[mbt_jsr82_getsearchresult]          Header.Type: %d ",pHIDClassDesc->Header.Type,0,0);
				MBT_PI( "[mbt_jsr82_getsearchresult]          Header.Size_index : %d ",pHIDClassDesc->Header.Size_index,0,0);
				MBT_PI( "[mbt_jsr82_getsearchresult]          Header.Attr_value_len : %d ",pHIDClassDesc->Header.Attr_value_len,0,0);
				
				pHIDClassDesc->Value = pSrcHIDClassDesc->val;
				pHIDClassDesc->Length = pSrcHIDClassDesc->len;

				
				memcpy( pHIDClassDesc->Str, pSrcHIDClassDesc->str, pSrcHIDClassDesc->len);


				
				for(m=0;m<pDestRec->Attr[j].Value.HidDescList.HidDesc[k].Length;m++)
					MBT_PI( "[mbt_jsr82_getsearchresult]             pHIDClassDesc->Str : %c ",pDestRec->Attr[j].Value.HidDescList.HidDesc[k].Str[m],0,0);
			}
			break;

		case MBT_JSR82_SD_ATTR_UUID128:
			memcpy((void*)&pDestRec->Attr[j].Value.UUID128, (void*)&pAttr->attr_value.uuid128, sizeof(T_MBT_UUID128));
		break;

		default:
		break;
    	}
  	} /* foreach service attribute */
}


MBT_BOOL  mbt_jsr82_attrValCheck(T_MBT_JSR82_ATTRIBUTE* attrvalue)
{
    T_MBT_JSR82_ATTRIBUTE* tempAttrvalue;
    MBT_BYTE   tempUUID128[16];
    MBT_INT  result;
    MBT_BYTE tempStr[MBT_JSR82_MAX_STRING_LEN];
    MBT_BOOL checkResult = MBT_TRUE;
    int i;
    MBT_PI( __func__"##########################", 0, 0, 0);
    tempAttrvalue = (T_MBT_JSR82_ATTRIBUTE*)attrvalue;

    memset(tempUUID128,0,16);
    memset(tempStr,0,MBT_JSR82_MAX_STRING_LEN);

    
    switch(tempAttrvalue->AttrID)
    {
		case   MBT_JSR82_ATTR_ID_SERVICE_RECORD_HANDLE:
			if(tempAttrvalue->Value.PrimitiveValue == 0)
				checkResult = MBT_FALSE;
			break;
			
        	case MBT_JSR82_ATTR_ID_SERVICE_CLASS_ID_LIST :
			MBT_PI("[attrValCheck] UUIDList.NumUUIDs %d \n",tempAttrvalue->Value.UUIDList.NumUUIDs,0,0);
			MBT_PI("[attrValCheck] UUIDList.NumUUID128s %d \n",tempAttrvalue->Value.UUIDList.NumUUID128s,0,0);

			if(tempAttrvalue->Value.UUIDList.NumUUIDs == 0 && tempAttrvalue->Value.UUIDList.NumUUID128s == 0 )
				checkResult = MBT_FALSE;
				
			for(i=0;i<BT_SD_MAX_NUM_OF_UUID;i++)
			{
				MBT_PI("[attrValCheck] UUIDList.UUID[%d] %d \n",i,tempAttrvalue->Value.UUIDList.UUID[i],0);
				if(tempAttrvalue->Value.UUIDList.UUID[i]!=0)
				{
					checkResult = MBT_TRUE;
					break;
				}
			}

			for(i=0;i<16;i++)
			{
				MBT_PI("[attrValCheck] UUIDList.UUID128[%d] %d \n",i,tempAttrvalue->Value.UUIDList.UUID128[0].UUIDByte[i],0);
				if(tempAttrvalue->Value.UUIDList.UUID128[0].UUIDByte[i]!=0)
				{
					checkResult = MBT_TRUE;
					break;
				}
			}
        	break;
		
// 2. ProtoDesc check.
        case MBT_JSR82_ATTR_ID_PROTOCOL_DESCRIPTOR_LIST:
            if(tempAttrvalue->Value.ProtoDescList.NumProtoDes == 0)
                checkResult = MBT_FALSE;
			break;
// 3. LangBase check 
        case MBT_JSR82_ATTR_ID_LANGUAGE_BASE_ATTRIBUTE_ID_LIST:
            if(tempAttrvalue->Value.LangBaseAttrList.NumLangBase == 0)
                checkResult = MBT_FALSE;
        	break;
// 4. ProtoDescList
        case MBT_JSR82_ATTR_ID_BLUETOOTH_PROFILE_DESCRIPTOR_LIST:
            if(tempAttrvalue->Value.BTProfileList.NumProfile == 0)
                checkResult = MBT_FALSE;
        	break;

// 5. SERVICE_NAME (wStr)
        case  MBT_JSR82_ATTR_ID_DOCUMENTATION_URL:
			checkResult = MBT_TRUE;
			break;
		
	 	case MBT_JSR82_ATTR_ID_SERVICE_NAME:
        case MBT_JSR82_ATTR_ID_CLIENT_EXECUTABLE_URL:
        case MBT_JSR82_ATTR_ID_ICON_URL:
        case MBT_JSR82_ATTR_ID_PROVIDER_NAME:
            if((result =  memcmp(tempAttrvalue->Value.Str,tempStr,BT_SD_MAX_TEXT_STRING_LEN))==0)
                checkResult = MBT_FALSE;
       		break;

// 6. HidDescList
        case MBT_JSR82_ATTR_ID_HID_DESCRIPTOR_LIST:
            if(tempAttrvalue->Value.HidDescList.NumHidDesc == 0)
                checkResult = MBT_FALSE;
        	break;
			
// 7. SERVICE_SERVICE_ID
        case MBT_JSR82_ATTR_ID_SERVICE_SERVICE_ID:
            if( tempAttrvalue->Value.UUIDList.NumUUIDs == 0)
            {
                if((result =  memcmp(tempAttrvalue->Value.UUID128.UUIDByte,tempUUID128,16 ))==0)
                       checkResult = MBT_FALSE;
            }
       		break;
			
// 8. etc
        default :
            {
                if(tempAttrvalue->AttrType == MBT_JSR82_SD_ATTR_UNKNOWN)
                {
                    int k;
			uint8 tempHIDStr[ BT_SD_MAX_HID_CLASS_DESC_STRING_LEN ];
			memset(tempHIDStr,0,BT_SD_MAX_TEXT_STRING_LEN);
			MBT_PI("[attrValCheck] NumHidDesc : %d \n",tempAttrvalue->Value.HidDescList.NumHidDesc,0,0);
			if(tempAttrvalue->Value.HidDescList.NumHidDesc==0)//&&tempAttrvalue->Value.HidDescList.NumHidDesc<4)
			{
				checkResult = MBT_FALSE;
				for ( k=0; k<BT_SD_MAX_NUM_OF_HID_CLASS_DESC; k++ )
				{
					MBT_PI("[attrValCheck] HidDesc[%d].Length, : %d \n",k,tempAttrvalue->Value.HidDescList.HidDesc[k].Length,0);
					if(memcmp( tempAttrvalue->Value.HidDescList.HidDesc[k].Str,tempHIDStr,tempAttrvalue->Value.HidDescList.HidDesc[k].Length))
					{
						checkResult = MBT_TRUE;
						tempAttrvalue->Value.HidDescList.NumHidDesc++;
					}
				}		
			}

                }
            }
            break;
	}    
    return checkResult;
}


//int   EncodeServiceRecordInfo(BTServiceRecord *pserRec,unsigned char *sdpdata,int offset,int ilength)
//svc_record_ptr : the pointer of service rec index
// 
MBT_INT mbt_jsr82_encodeServiceRecordInfo(T_MBT_JSR82_SD_RECORD* jsr82_svc_rec_ptr/*MBT_INT iRecordIndex*/, MBT_SHORT* spAttrSet, MBT_BYTE** ppAttrVals,MBT_INT* spAttrIDNum)
{

	int i 		= 0;
	int j  		= 0;
	//int savepos	= 0;
	int len		= 0;
    int totalLen = 0; 
	int result =0 ;
	//uint16 serviceRecordLen=0;
	
	T_MBT_JSR82_ATTRIBUTE   	attrvalue;
	
	uint8   tempUUID128[16];
	MBT_PI( __func__"##########################", 0, 0, 0);
	
	*spAttrIDNum = jsr82_svc_rec_ptr->NumAttr;  
	MBT_PI("[mbt_jsr82_encodeServiceRecordInfo] AttrIDNum %d \n",*spAttrIDNum,0,0);
	for(i = 0; i < jsr82_svc_rec_ptr->NumAttr; i++)
	{
		int tempPos1=0, tempPos2=0;
		int ipos =0;
		attrvalue = jsr82_svc_rec_ptr->Attr[i];
		MBT_PI("=========================================================================",0,0,0);
		spAttrSet[i]=attrvalue.AttrID;

		if(mbt_jsr82_attrValCheck(&attrvalue) == MBT_TRUE)
		{
			switch(attrvalue.AttrID)
			{
				case MBT_JSR82_ATTR_ID_SERVICE_RECORD_HANDLE:
					MBT_PI(" AttrID : %04x (SERVICE_RECORD_HANDLE)    AttrType : 0x%x\n",
					attrvalue.AttrID,attrvalue.AttrType,0);             
				
					ppAttrVals[i][ipos ++]  =U_INT_4;
					encodeint(ppAttrVals[i], ipos, (uint32)attrvalue.Value.PrimitiveValue);
					MBT_PI("ServiceRecord Handle : %x\n", jsr82_svc_rec_ptr->SrvRechandle,0,0);
					ipos += 4;
					break;
					
				case MBT_JSR82_ATTR_ID_SERVICE_CLASS_ID_LIST:                  
					MBT_PI(" AttrID : %04x (SERVICE_CLASS_ID_LIST)    AttrType : 0x%x\n",attrvalue.AttrID,attrvalue.AttrType,0);  
					MBT_PI("  NumUUID128s : %d, NumUUIDs : %d \n",attrvalue.Value.UUIDList.NumUUID128s,attrvalue.Value.UUIDList.NumUUIDs,0);

					ppAttrVals[i][ipos++] = DATA_SEQ_1;
					tempPos1 = ipos;//len
					ipos +=1;       //len
					//Check whether 128 bit UUID Exist ...
					memset(tempUUID128, 0, 16);
					if((result =  memcmp(attrvalue.Value.UUIDList.UUID128, tempUUID128, 16 )) != 0)
					{
						MBT_PI("            128 bit UUID  Found " ,0,0,0 );
						for(j = 0; j < 16; j++)                                                  
						{
							MBT_PI("%02x \n", attrvalue.Value.UUIDList.UUID128[0].UUIDByte[j],0,0);                                                
						}
						ppAttrVals[i][ipos++] = UUID_128;
						memcpy(ppAttrVals[i] + ipos, attrvalue.Value.UUIDList.UUID128, 16);
						ipos +=  16;                            
					}


					for( j = 0; j < BT_SD_MAX_NUM_OF_UUID; j++ )
					{   
						if(attrvalue.Value.UUIDList.UUID[j] != 0)
						{
							MBT_PI("            16 bit UUID Exist ",0,0,0 );

							ppAttrVals[i][ipos++]   = UUID_16;                              
							encodeShortLen(ppAttrVals[i], ipos, attrvalue.Value.UUIDList.UUID[j]);
							MBT_PI("            ServiceClassUUID :%04x \n", attrvalue.Value.UUIDList.UUID[j],0,0);              
							ipos += 2;
						}
					}
					
					ppAttrVals[i][tempPos1] = (uint8)(ipos - tempPos1 - 1) ;
					MBT_PI("[PARSER-A] : ipos : %d,  SERVICE_CLASS_ID_LIST [%d] len : %d\n", ipos,tempPos1,ppAttrVals[i][tempPos1]);

					break;
			  
				case MBT_JSR82_ATTR_ID_PROTOCOL_DESCRIPTOR_LIST:

					MBT_PI(" AttrID : %04x (PROTOCOL_DESCRIPTOR_LIST)    AttrType : 0x%x\n", attrvalue.AttrID, attrvalue.AttrType, 0);             
					ppAttrVals[i][ipos++] = DATA_SEQ_1;
					tempPos1 = ipos;//len
					ipos +=1;       //len
					
					for(j = 0; j < attrvalue.Value.ProtoDescList.NumProtoDes; j++)
					{
						ppAttrVals[i][ipos++] = DATA_SEQ_1;
						tempPos2 = ipos;//len
						ipos +=1;       //len
						ppAttrVals[i][ipos++]   = UUID_16;
						encodeShortLen(ppAttrVals[i], ipos, attrvalue.Value.ProtoDescList.ProtoDesc[j].UUID);

						MBT_PI("            PROTOCOL UUID  %04x \n",attrvalue.Value.ProtoDescList.ProtoDesc[j].UUID,0,0);

						ipos += 2;
						if(attrvalue.Value.ProtoDescList.ProtoDesc[j].UUID == MBT_PROTOCOL_UUID_L2CAP)
						{
							MBT_PI("[sdp_parser ] [protocoldescriptorList]   [ MBT_PROTOCOL_UUID_L2CAP] \n",0,0,0); 
							if(attrvalue.Value.ProtoDescList.ProtoDesc[j].Param[0].Value !=0 )
							{
								//uint32  uPSM = attrvalue.Value.ProtoDescList.ProtoDesc[j].Param[0].Value;
								MBT_PI("            UUID_L2CAP PSM Value %04x \n",attrvalue.Value.ProtoDescList.ProtoDesc[j].Param[0].Value,0,0);
								//set the PSM Value.
								ppAttrVals[i][ipos++] = U_INT_2;       //==U_INT_2;
								encodeShortLen(ppAttrVals[i], ipos, attrvalue.Value.ProtoDescList.ProtoDesc[j].Param[0].Value);
								ipos  += 2;
							}
						}
						else if(attrvalue.Value.ProtoDescList.ProtoDesc[j].UUID == MBT_PROTOCOL_UUID_RFCOMM)
						{
							MBT_PI("     [sdp_parser ] [protocoldescriptorList]   [ MBT_PROTOCOL_UUID_RFCOMM] \n",0,0,0);   
							if(attrvalue.Value.ProtoDescList.ProtoDesc[j].Param[0].Value!=0)
							{
								MBT_PI("            UUID_RFCOMM  Channel Value %d \n",attrvalue.Value.ProtoDescList.ProtoDesc[j].Param[0].Value,0,0);
								MBT_PI("(fnclamp test)  UUID_RFCOMM  Channel Value %d \n",attrvalue.Value.ProtoDescList.ProtoDesc[j].NumParam,0,0);
								//Set the Channel Value.
								ppAttrVals[i][ipos++] = U_INT_1;           //==U_INT_1;                            
								ppAttrVals[i][ipos++] = (uint8)attrvalue.Value.ProtoDescList.ProtoDesc[j].Param[0].Value;                                                              
							}
						}    
						else if(attrvalue.Value.ProtoDescList.ProtoDesc[j].UUID == MBT_PROTOCOL_UUID_OBEX)
						{
							MBT_PI("     [sdp_parser ] [protocoldescriptorList]   [ MBT_PROTOCOL_UUID_OBEX] \n",0,0,0);   
						} 
						ppAttrVals[i][tempPos2] = (uint8)(ipos -tempPos2 - 1) ;
						MBT_PI("     [PARSER-b] : ipos : %d,  PROTO_DESC_REC [%d] len : %d\n",ipos,tempPos2,ppAttrVals[i][tempPos2]);
					}
					ppAttrVals[i][tempPos1] = (uint8)(ipos - tempPos1 - 1) ;
					MBT_PI("     [PARSER-A] : ipos : %d,  PROTO_DESC_REC [%d] len : %d\n",ipos,tempPos1,ppAttrVals[i][tempPos1]);

					break;



				case   MBT_JSR82_ATTR_ID_SERVICE_NAME:
					MBT_PI(" AttrID : %04x (ATTR_ID_SERVICE_NAME)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
					MBT_PI("                 ServiceName Value %s \n",attrvalue.Value.Str,0,0);
					
					ppAttrVals[i][ipos++] = STR_1;
					len = strlen((void*)attrvalue.Value.Str);// + 1;
					ppAttrVals[i][ipos++] = (uint8)len;
					memcpy(ppAttrVals[i]+ipos, attrvalue.Value.Str, len);
					ipos += len;
					break;
			  
				case   MBT_JSR82_ATTR_ID_SERVICE_SERVICE_ID:
					MBT_PI(" AttrID : %04x (SERVICE_ID)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
					memset(tempUUID128, 0, 16);
					if((result =  memcmp(attrvalue.Value.UUID128.UUIDByte, tempUUID128, 16 )) != 0)
					{
						MBT_PI("            128 bit UUID  Found " ,0,0,0 );
						for(j = 0;j < 16; j++)                                                  
						MBT_PI("%d \n",attrvalue.Value.UUID128.UUIDByte[j],0,0);                                                

						ppAttrVals[i][ipos++] = UUID_128;
						memcpy(ppAttrVals[i] + ipos, attrvalue.Value.UUID128.UUIDByte,16);
						ipos +=  16;                            
					}
					MBT_PI("UUID Value %d ",  attrvalue.Value.UUIDList.UUID[0],0,0);
					if( attrvalue.Value.UUIDList.UUID[0] != 0)
					{ 
						ppAttrVals[i][ipos++] = UUID_16;  //11 000(3 0)
						encodeShortLen(ppAttrVals[i], ipos, attrvalue.Value.UUIDList.UUID[0]);
						ipos += 2;
					}
					break;
					
				case MBT_JSR82_ATTR_ID_LANGUAGE_BASE_ATTRIBUTE_ID_LIST:                 
					MBT_PI(" AttrID : %04x (LANGUAGE_BASE_ATTRIBUTE_ID_LIST)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
					ppAttrVals[i][ipos++] = DATA_SEQ_1;
					tempPos1 = ipos;//len
					ipos += 1;       //len

					for(j =  0;j<attrvalue.Value.LangBaseAttrList.NumLangBase;j++)
					{   
						ppAttrVals[i][ipos++] =U_INT_2;
						encodeShortLen(ppAttrVals[i], ipos, (uint16)attrvalue.Value.LangBaseAttrList.LangBase[j].BaseAttrId);
						ipos += 2;

						ppAttrVals[i][ipos++] =U_INT_2;
						encodeShortLen(ppAttrVals[i], ipos, (uint16)attrvalue.Value.LangBaseAttrList.LangBase[j].CharEncId);
						ipos += 2;

						ppAttrVals[i][ipos++] =U_INT_2;
						encodeShortLen(ppAttrVals[i], ipos, (uint16)attrvalue.Value.LangBaseAttrList.LangBase[j].LangId);
						ipos += 2;

					}
					ppAttrVals[i][tempPos1] = (uint8)(ipos -tempPos1 - 1) ;
					break;

				//������
				case MBT_JSR82_ATTR_ID_SERVICE_AVAILABILITY:
					MBT_PI(" AttrID : %04x (SERVICE_AVAILABILITY)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
#if 0//������
					ipos += 2;
					sdpdata[ipos++]   =  attrvalue.Value.serviceavailable;                                      
#endif		    
					ppAttrVals[i][ipos]   =  0;
					ipos +=1;
					break;       

				//������
				case MBT_JSR82_ATTR_ID_SERVICE_INFO_TIME_TO_LIVE:
					MBT_PI(" AttrID : %04x (SERVICE_INFO_TIME_TO_LIVE)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
#if 0//������ 						
					encodeint(sdpdata, ipos, attrvalue.Value.UintValue);
					ipos += 4;                      
#endif				
					ppAttrVals[i][ipos] = 0;
					ipos +=1;
					break;      
				//������
				case MBT_JSR82_ATTR_ID_DOCUMENTATION_URL:                    
					MBT_PI(" AttrID : %04x (DOCUMENTATION_URL)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
					ppAttrVals[i][ipos++]  =  0x45;
					len = strlen((void*)attrvalue.Value.Str);   //+1;
					MBT_PI(" DOCUMENTATION_URL    len : %d\n",len,0,0);             
					ppAttrVals[i][ipos++] = (uint8)len;
					memcpy(ppAttrVals[i] + ipos, attrvalue.Value.Str, len);
					ipos += len;                                                           
					break;

				//������
				case MBT_JSR82_ATTR_ID_CLIENT_EXECUTABLE_URL:                    
					MBT_PI(" AttrID : %04x (CLIENT_EXECUTABLE_URL)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
#if 0 //������ 						
					sdpdata[ipos++]  =  STRING;
					len              = strlen(attrvalue.Value.wStr) + 1;
					sdpdata[ipos++]  =  len;
					memcpy(sdpdata + ipos,attrvalue.Value.wStr,len);
					ipos += len;                                                                                                                                        
#else
					ppAttrVals[i][ipos] = 0;
					ipos += 1;
#endif
					break;

				//������  
				case MBT_JSR82_ATTR_ID_ICON_URL:                                                                   
					// ����ü�� icon url�� �ش��ϴ� ���� �����ϴ� ������ ����. 
					MBT_PI(" AttrID : %04x (ID_ICON_URL)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
#if 0 //������ 						
					sdpdata[ipos++]  =  STRING;
					len              = strlen(attrvalue.Value.wStr) + 1;
					sdpdata[ipos++]  =  len;
					memcpy(sdpdata + ipos,attrvalue.Value.wStr,len);
					ipos += len;                                                                                                                                        
#else
					ppAttrVals[i][ipos] = 0;
					ipos += 1;
#endif
					break;

				//������
				case MBT_JSR82_ATTR_ID_PROVIDER_NAME:                    
					MBT_PI(" AttrID : %04x (PROVIDER_NAME)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
					ppAttrVals[i][ipos] = 0;
					ipos += 1;
					break;

				//������  
				case MBT_JSR82_ATTR_ID_SERVICE_RECORD_STATE:                                     
					MBT_PI(" AttrID : %04x (SERVICE_RECORD_STATE)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
					ppAttrVals[i][ipos]   =  0;
					ipos += 1;
					break;                  
	
				case MBT_JSR82_ATTR_ID_BLUETOOTH_PROFILE_DESCRIPTOR_LIST:
					MBT_PI(" AttrID : %04x (PROFILE_DESCRIPTOR_LIST)    AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             

					ppAttrVals[i][ipos++] = DATA_SEQ_1;
					tempPos1 = ipos;    //len
					ipos +=1;       //len

					for(j = 0; j < attrvalue.Value.BTProfileList.NumProfile; j++)
					{
						ppAttrVals[i][ipos++] = DATA_SEQ_1;
						tempPos2 = ipos;    //len
						ipos += 1; 

						ppAttrVals[i][ipos++] = UUID_16;
						encodeShortLen(ppAttrVals[i], ipos, (uint16)attrvalue.Value.BTProfileList.ProfileList[j].UUID);
						MBT_PI("PROTOCOL UUID  %d \n",attrvalue.Value.BTProfileList.ProfileList[j].UUID,0,0);
						ipos += 2;
						
						ppAttrVals[i][ipos++] = U_INT_2;
						encodeShortLen(ppAttrVals[i], ipos, (uint16)attrvalue.Value.BTProfileList.ProfileList[j].Version);
						ipos +=2;
						ppAttrVals[i][tempPos2] = (uint8)(ipos - tempPos2 - 1) ;
						MBT_PI("[PARSER-A] : ipos : %d,  PROTO_DESC_REC len(%d) : %d\n", ipos, tempPos2, ppAttrVals[i][tempPos2]);                            
					}
					ppAttrVals[i][tempPos1]=(uint8)(ipos -tempPos1 - 1) ;
					MBT_PI("[PARSER-B] : ipos : %d,  PROTO_DESC_REC len(%d) : %d\n", ipos, tempPos1, ppAttrVals[i][tempPos1]);                        
					break;
			      
				default:
				{
					int attrDataType, attrDataSizeIndex;
					MBT_PI(" AttrID : %04x (USER_DEFINE_ATTR_ID)    AttrType : 0x%x\n",attrvalue.AttrID,attrvalue.AttrType,0);  
					MBT_PI(" NumHidDesc : %d",attrvalue.Value.HidDescList.NumHidDesc,0,0);

					if(attrvalue.Value.HidDescList.NumHidDesc>1)
					{
						ppAttrVals[i][ipos++] = DATA_SEQ_1;
						tempPos1 = ipos;//len
						ipos += 1;       //len
					}
					
					for(j = 0; j < attrvalue.Value.HidDescList.NumHidDesc; j++)
					{

						MBT_PI(" HidDesc[%d].Length : %d, Attr_value_len : %d",j,attrvalue.Value.HidDescList.HidDesc[j].Length,attrvalue.Value.HidDescList.HidDesc[j].Header.Attr_value_len);
						if(strlen(attrvalue.Value.HidDescList.HidDesc[j].Str) > 0)
						{
							//HidDesc ������ Type �̿��ϴ� ���� ������� 
							attrDataType = (attrvalue.Value.HidDescList.HidDesc[j].Header.Type<<3);
							attrDataSizeIndex = attrvalue.Value.HidDescList.HidDesc[j].Header.Size_index & 0x07;
							MBT_PI(" USER_DEFINE_ATTR_ID data[%d]  Header.Type:%d(0x%x)\n",j,attrvalue.Value.HidDescList.HidDesc[j].Header.Type,attrDataType);  
							MBT_PI(" USER_DEFINE_ATTR_ID data[%d]  Header.Size_index:%d\n",j,attrDataSizeIndex,0);  
							ppAttrVals[i][ipos++]  = (uint8)(attrDataType | attrDataSizeIndex);
							len             = attrvalue.Value.HidDescList.HidDesc[j].Length ;   // + 1;
							MBT_PI(" USER_DEFINE_ATTR_ID data[%d]  len:%d\n",j,len,0);             
							ppAttrVals[i][ipos++]  = (uint8)len;
							memcpy(ppAttrVals[i] + ipos, attrvalue.Value.HidDescList.HidDesc[j].Str, len);
							ipos += len;                                                    
						}
					}
					if(attrvalue.Value.HidDescList.NumHidDesc>1)
					{
						ppAttrVals[i][tempPos1]=(uint8)(ipos -tempPos1 - 1) ;									  
					}
                                break;
				}
			}
        }
		else 
		{
            MBT_PI("[attrValCheck Fail!!] ",0,0,0);   
            MBT_PI(" AttrID : %04x     AttrType : 0x%x\n", attrvalue.AttrID,attrvalue.AttrType,0);             
            ppAttrVals[i][ipos++] = 0;
        }


		totalLen += ipos;
		MBT_PI(" ",0,0,0);   
		MBT_PI("[ServiceRecord Encoding Resutl[%d] ,  totalLen : %d ",i,totalLen,0);   
		for(j=0;j<ipos;j++)
		{
			MBT_PI("   ppAttrVals[%d][%d] = %02x", i,j,ppAttrVals[i][j]);    
		}          
	}
    MBT_PI("=========================================================================",0,0,0);
	return totalLen;

}


static int mbt_jsr82_coreServiceAttributeUpdate(
  const T_MBT_JSR82_ATTRIBUTE*  pPDKSvcAttr,
  bt_sd_srv_attr_rec_type*      pCoreSvcAttr
)
{
  uint8                        i, j, k;
  const T_MBT_JSR82_PROTOCOL_DESC*   pBrewProtoDesc;
  const T_MBT_JSR82_PROTOCOL_DESC_LIST*  pPDKProtoDescList;
  bt_sd_proto_desc_type*    pCoreProtoDesc;
  bt_sd_proto_desc_list_type*  pCoreProtoDescList;
  char                      str[ MBT_JSR82_MAX_STRING_LEN + 1 ];
  bt_sd_srv_attr_rec_type      temp_attr;
  bt_sd_srv_attr_enum_type  attr_type = BT_SD_ATTR_TYPE_UNKNOWN;
  bt_sd_uuid_type			uuid16;
  bt_sd_uuid128_type           uuid128;
  bt_sd_uuid128_type*          uuid128_ptr;
  MBT_PI( __func__"##########################", 0, 0, 0);
  switch( pPDKSvcAttr->AttrType )
  {
    case MBT_JSR82_SD_ATTR_UUID_LIST:
		for ( j = 0; ( j < pPDKSvcAttr->Value.UUIDList.NumUUID128s && j < MBT_JSR82_MAX_128_UUID_NUM ); j++ )
		{
			memcpy((void*)&uuid128, (void*)&pPDKSvcAttr->Value.UUIDList.UUID128[j], sizeof(bt_sd_uuid128_type));
			bt_sd_service_attribute_set_uuid128( pCoreSvcAttr, &uuid128 );
		}

		for ( j = 0; ( j < pPDKSvcAttr->Value.UUIDList.NumUUIDs && j < MBT_JSR82_MAX_SEARCH_UUID_NUM); j++ )
		{
			bt_sd_service_attribute_add_uuid(pCoreSvcAttr, pPDKSvcAttr->Value.UUIDList.UUID[j] );
		}
      	break;
		
    case MBT_JSR82_SD_ATTR_PROTO_DESC_LIST:
		for (j = 0; ( j < pPDKSvcAttr->Value.ProtoDescList.NumProtoDes && j < MBT_JSR82_MAX_PROTO_DESC_NUM); j++)
		{
			pBrewProtoDesc = &pPDKSvcAttr->Value.ProtoDescList.ProtoDesc[j];
			if(pBrewProtoDesc->BUUID128)
			{
				memcpy( (void*)&uuid128, (void*)&pBrewProtoDesc->UUID128, sizeof(bt_sd_uuid128_type));
				uuid128_ptr = &uuid128;
				uuid16 = 0; //BT_SD_INVALID_UUID;
			}
			else
			{
				uuid128_ptr = MBT_NULL;
				uuid16 = pBrewProtoDesc->UUID;
			}

			if((pCoreProtoDesc = bt_sd_service_attribute_add_proto_desc(pCoreSvcAttr, uuid16, uuid128_ptr))!= 0 )
			{
				for (k = 0; k < pBrewProtoDesc->NumParam; k++)
				{
					bt_sd_service_attribute_proto_desc_add_param(
					pCoreProtoDesc,
					pBrewProtoDesc->Param[k].Value,
					pBrewProtoDesc->Param[k].Size );
				}
			}
      }
      break;
    case MBT_JSR82_SD_ATTR_ADDL_PROTO_DESC_LISTS:
		for ( i = 0; ( i < pPDKSvcAttr->Value.AddProtoDescList.NumProtoListDes && i < MBT_JSR82_MAX_NUM_OF_ADD_PROTO_LIST_NUM ); i++ )
		{
			pPDKProtoDescList = &pPDKSvcAttr->Value.AddProtoDescList.ProtoDescList[i];
			pCoreProtoDescList = &pCoreSvcAttr->attr_value.add_proto_desc_lists[i];

			/* Initialize the temporary service attribute as a proto desc list */
			bt_sd_service_record_init_attribute(&temp_attr,MBT_JSR82_ATTR_ID_PROTOCOL_DESCRIPTOR_LIST,MBT_JSR82_SD_ATTR_PROTO_DESC_LIST );

			for ( j = 0; ( j < pPDKProtoDescList->NumProtoDes && j < MBT_JSR82_MAX_PROTO_DESC_NUM ); j++ )
			{
				pBrewProtoDesc = &pPDKProtoDescList->ProtoDesc[j];
				if ( pBrewProtoDesc->BUUID128 )
				{
					memcpy( (void*)&uuid128, (void*)&pBrewProtoDesc->UUID128, sizeof(bt_sd_uuid128_type));
					uuid128_ptr = &uuid128;
					uuid16 = 0; //BT_SD_INVALID_UUID;
				}
				else
				{
					uuid128_ptr = MBT_NULL;
					uuid16 = pBrewProtoDesc->UUID;
				}

				if ( ( pCoreProtoDesc = bt_sd_service_attribute_add_proto_desc(&temp_attr, uuid16, uuid128_ptr )) != 0)
				{
					for ( k = 0; k < pBrewProtoDesc->NumParam; k++)
					{
						bt_sd_service_attribute_proto_desc_add_param(
						pCoreProtoDesc,
						pBrewProtoDesc->Param[k].Value,
						pBrewProtoDesc->Param[k].Size );
					}
				}
			}

			/* copy temp_attr to the actual attribute */
			memcpy( (void*) pCoreProtoDescList, (void*)(&temp_attr.attr_value.proto_desc_list),sizeof( bt_sd_proto_desc_list_type ));
			pCoreProtoDescList->header.attr_value_len += temp_attr.header.attr_value_len;
			pCoreSvcAttr->header.attr_value_len += 2 + temp_attr.header.attr_value_len;
		}
		break;


    case MBT_JSR82_SD_ATTR_LANG_BASE_ATTR_ID_LIST:
		for(j = 0; ( j < pPDKSvcAttr->Value.LangBaseAttrList.NumLangBase && j < MBT_JSR82_MAX_LANG_BASE_REC_NUM ); j++ )
		{
			bt_sd_service_attribute_add_lang_base_attr_id(
			pCoreSvcAttr,
			pPDKSvcAttr->Value.LangBaseAttrList.LangBase[j].LangId,
			pPDKSvcAttr->Value.LangBaseAttrList.LangBase[j].CharEncId,
			pPDKSvcAttr->Value.LangBaseAttrList.LangBase[j].BaseAttrId );
		}
      break;
	  
    case MBT_JSR82_SD_ATTR_UINT_LIST:
		for ( j = 0; ( j < pPDKSvcAttr->Value.UintList.NumVal && j < MBT_JSR82_MAX_UINT ); j++ )
		{
			bt_sd_service_attribute_uint_list_add_val(pCoreSvcAttr,	sizeof( uint64 ), /* RYUEN: Fixme */ pPDKSvcAttr->Value.UintList.Val[j] );
		}
		break;
		
    case MBT_JSR82_SD_ATTR_STRING:
		// Wstr -> str ��ȯ func �ϴ� ���´�
		memset(str,0x0,sizeof(str)); 
		memcpy(str,pPDKSvcAttr->Value.Str,sizeof(pPDKSvcAttr->Value.Str));
		bt_sd_service_attribute_set_str( pCoreSvcAttr, str );
		break;
	  
    case MBT_JSR82_SD_ATTR_UINT8:
      	attr_type = MBT_JSR82_SD_ATTR_UINT8;
     	bt_sd_service_attribute_set_value( pCoreSvcAttr, pPDKSvcAttr->Value.PrimitiveValue);
		break;
		
    case MBT_JSR82_SD_ATTR_UINT16:
		if ( attr_type == MBT_JSR82_SD_ATTR_UNKNOWN )
		{
			attr_type = MBT_JSR82_SD_ATTR_UINT16;
		}
     	bt_sd_service_attribute_set_value( pCoreSvcAttr, pPDKSvcAttr->Value.PrimitiveValue);
		break;
		
    case MBT_JSR82_SD_ATTR_UINT32:
		if ( attr_type == MBT_JSR82_SD_ATTR_UNKNOWN )
		{
			attr_type = MBT_JSR82_SD_ATTR_UINT32;
		}
     	bt_sd_service_attribute_set_value( pCoreSvcAttr, pPDKSvcAttr->Value.PrimitiveValue);
		break;
		
    case MBT_JSR82_SD_ATTR_UINT64:
		if ( attr_type == MBT_JSR82_SD_ATTR_UNKNOWN )
		{
			attr_type = MBT_JSR82_SD_ATTR_UINT64;
		}
     	bt_sd_service_attribute_set_value( pCoreSvcAttr, pPDKSvcAttr->Value.PrimitiveValue);
      break;
	  
    case MBT_JSR82_SD_ATTR_BOOL:
		bt_sd_service_attribute_set_bool( pCoreSvcAttr,pPDKSvcAttr->Value.BFlag);
      break;
	  
    case MBT_JSR82_SD_ATTR_HID_DESC_LIST:
		MBT_PI( "### LGOEM_BT_SD_ATTR_TYPE_HID_DESC_LIST ###", 0, 0, 0);
		MBT_PI( "###           NumHidDesc :  ###", pPDKSvcAttr->Value.HidDescList.NumHidDesc, 0, 0);
		for ( i = 0; ( i < pPDKSvcAttr->Value.HidDescList.NumHidDesc && i < BT_SD_MAX_NUM_OF_HID_CLASS_DESC ); i++ )
		{
			const T_MBT_JSR82_HID_DESC*  pPDKHIDClassDesc =
			&pPDKSvcAttr->Value.HidDescList.HidDesc[i];

			bt_sd_service_attribute_add_hid_class_desc(
				pCoreSvcAttr,
				pPDKHIDClassDesc->Value,
				pPDKHIDClassDesc->Length,
				(const byte*)pPDKHIDClassDesc->Str );
		}
		break;
    case MBT_JSR82_SD_ATTR_UUID128:
	      	memcpy((void*)&uuid128, (void*)&pPDKSvcAttr->Value.UUID128,sizeof(uuid128));
	      	bt_sd_service_attribute_set_uuid128( pCoreSvcAttr, &uuid128 );
	      	break;
			
	    /* RYUEN: Fixme
	    BT_SD_ATTR_TYPE_UUID,
	    BT_SD_ATTR_TYPE_UINT128 */

    case MBT_JSR82_SD_ATTR_UNKNOWN:
     	 MBT_PI( "### LGOEM_BT_SD_ATTR_TYPE_UNKNOWN ###   NumHidDesc    %d", 
	  				pPDKSvcAttr->Value.HidDescList.NumHidDesc, 0, 0);
		for ( i = 0; (i< pPDKSvcAttr->Value.HidDescList.NumHidDesc &&i<BT_SD_MAX_NUM_OF_HID_CLASS_DESC ); i++ )
		{
			const T_MBT_JSR82_HID_DESC*  pPDKHIDClassDesc = &pPDKSvcAttr->Value.HidDescList.HidDesc[i];
			MBT_PI( "### LGOEM_BT_SD_ATTR_TYPE_UNKNOWN  Val %x Len %x str %x###", 
			pPDKHIDClassDesc->Value, pPDKHIDClassDesc->Length, pPDKHIDClassDesc->Str);

			bt_sd_service_attribute_add_unknown(pCoreSvcAttr,
												pPDKHIDClassDesc->Value,
												pPDKHIDClassDesc->Length,
												(const byte*)pPDKHIDClassDesc->Str);
		}
     	 break;
  }

  return MBT_TRUE; //SUCCESS;
}

int mbt_jsr82_updateServiceAttribute(
  uint32                        uSvcRecHandle,
  const T_MBT_JSR82_ATTRIBUTE*  pSvcAttr
)
{
	int                       status = MBT_TRUE; //SUCCESS;
	bt_sd_srv_rec_type*       pCoreSvcRec;
	bt_sd_srv_attr_rec_type*  pCoreSvcAttr;

	MBT_PI( "-------------------------------------------", 0, 0, 0);
	MBT_PI( __func__"##########################", 0, 0, 0);
	MBT_PI( "-------------------------------------------", 0, 0, 0);

  if ( ( pCoreSvcRec =
           bt_sd_find_service_record_by_handle( uSvcRecHandle ) ) != 0 )
  {
    if ( ( pCoreSvcAttr = bt_sd_find_service_attribute(
                            pCoreSvcRec,
                            pSvcAttr->AttrID ) ) != 0 )
    {
  	  MBT_PI("   ## Normal ## AttrID[%x], AttrType[%x]", pSvcAttr->AttrID, pSvcAttr->AttrType, 0);
		
      if ( bt_sd_service_record_init_attribute(
             pCoreSvcAttr,
             pCoreSvcAttr->attr_id,
             pCoreSvcAttr->attr_type ) != MBT_FALSE )
      {
        status = mbt_jsr82_coreServiceAttributeUpdate(
                   pSvcAttr, pCoreSvcAttr );
      }
      else
      {
        status = MBT_FALSE; //EBADPARM;
      }
    }
// [ LGE_UPDATE_S 2006-01-02 chosw ] BT_SD_ATTR_TYPE_UNKNOWN ó�� 
    else //if((pSvcAttr->AttrType == LGOEM_BT_SD_ATTR_TYPE_UNKNOWN)||(pSvcAttr->AttrType == LGOEM_BT_SD_ATTR_TYPE_UNKNOWN))
    {

		MBT_PI("   ###### Abnormal ##  AttrID[%x]   Attr Type:%d", pSvcAttr->AttrID, pSvcAttr->AttrType, 0);
  
        pCoreSvcAttr = bt_sd_service_record_add_attribute(
                         pCoreSvcRec,
                         pSvcAttr->AttrID,
                         pSvcAttr->AttrType/*BT_SD_ATTR_TYPE_UNKNOWN*/);
	    if ( ( pCoreSvcAttr = bt_sd_find_service_attribute(
	                            pCoreSvcRec,
	                            pSvcAttr->AttrID ) ) != 0 )
	    {
	      if ( bt_sd_service_record_init_attribute(
	             pCoreSvcAttr,
	             pCoreSvcAttr->attr_id,
	             pCoreSvcAttr->attr_type ) != MBT_FALSE )
	      {
	        status = mbt_jsr82_coreServiceAttributeUpdate(
	                   pSvcAttr, pCoreSvcAttr );
	      }
	      else
	      {
	        status = MBT_FALSE; //EBADPARM;
	      }
	    }
    }

  }
  else
  {
	status = MBT_FALSE; //AEEBT_ENOREC;
  }
  
  return status;
}


#if 0 // LEECHANGHOON 2008-2-27 Not used.
int mbt_jsr82_setUUID128( uint32 handle, T_MBT_UUID128* uuid128)
{
	int index = 0;
	bt_sd_srv_rec_type*      	sr_ptr = MBT_NULL;
	bt_sd_srv_attr_rec_type*    srv_attr_ptr;
	uint8					null_uuid_128[16] = BT_SD_NULL_UUID128;
	MBT_PI( __func__"##########################", 0, 0, 0);
	/* uuid128 */
	sr_ptr =  bt_sd_find_service_record_by_handle(handle);
	if (sr_ptr == MBT_NULL)
	{
		MBT_PI("No UUID- get record Failed",0, 0, 0);
		return;
		
	}
	//060225 caravine for 128bit UUID support
	if(memcmp(uuid128->UUIDByte, null_uuid_128, 16))
	{
		//for (index=0; index<16; index++)
			//uuid128.uuid_byte[index]=lgbx_l2ca_tbl->uuid128[index];
		srv_attr_ptr = bt_sd_find_service_attribute(
			sr_ptr, BT_SD_ATTR_ID_SERVICE_CLASS_ID_LIST);
		if ( srv_attr_ptr != 0 )
		{
			MBT_PI("JL2CAP-128bit UUID is added",0,0,0);
			bt_sd_service_attribute_set_uuid128(srv_attr_ptr, (bt_sd_uuid128_type*)uuid128);
		}
		else
		{
			MBT_PI( "This Record doesn't have Service Class Attr",0, 0, 0 );
		}		
	}	
}
#endif

//-----------------------Jsr82 Evt Callback ���� ------------------------------------//
void mbt_jsr82_ev_cmdDone(bt_ev_msg_type* bt_ev_msg_ptr)
{
	// LEECHANGHOON 2007-11-13 bt_cmd ������ EV callback �������� ó���Ұ͵� ���⼭...
	bt_ev_gn_cmd_done_type* pm =    (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;
	MBT_SDC("JSR82_Event BT_EV_GN_CMD_DONE cmd = 0x%x, status= 0x%x",   pm->cmd_type, pm->cmd_status,0);
	switch ( pm->cmd_type )
	{
		case BT_CMD_SD_DISCOVER_DEVICES:	   
		{
			switch(pm->cmd_status)
			{
				case BT_CS_GN_SUCCESS:
					{				
						T_MBT_SEARCHED_DEV_LIST* SearchedList =   (T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);

						gDeviceRecordsIdx = 0;
						
						// Device index�� �����.						
						memset(SearchedList, 0x00, sizeof(T_MBT_SEARCHED_DEV_LIST));
						
					}
					break;
				case BT_CS_SD_DEVICE_DISCOVERY_ALREADY_IN_PROGRESS:
					MBT_WARN("DEVICE_DISCOVERY_ALREADY_IN_PROGRESS",0,0,0);
					mbt_postevent(MBTEVT_JSR82_INQUIRY_FAIL, 0);
					break;
			}
		}
		
		case BT_CMD_RM_SET_DEVICE_SECURITY:
			if(SetSecurity_cmd_state == BT_RM_CMD_SET_DEVICE_SECURITY_FOR_JSR82)
			{
				SetSecurity_cmd_state = BT_RM_CMD_SET_SERVICE_SECURITY_FOR_JSR82;
				mbt_jsr82_set_serviceSecurity();
			}
			break;
			
		case BT_CMD_RM_SET_SM4: 
		case BT_CMD_RM_SET_SERVICE_SECURITY:
			{
				T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
				if(SetSecurity_cmd_state == BT_RM_CMD_SET_SERVICE_SECURITY_FOR_JSR82)
				{
					SetSecurity_cmd_state = BT_RM_CMD_NONE;
					if (pm->cmd_status == BT_CS_GN_SUCCESS)
					{
						mbt_postevent(MBTEVT_JSR82_SECURITY_SET_SUCCESS, securityIdx);
					}
					else
					{
						mbt_postevent(MBTEVT_JSR82_SECURITY_SET_FAIL, 0);
						memset(&sdcJSR82Status->Security, 0x00, sizeof(T_MBT_JSR82_SET_SECURITY));
						memset(&sdcJSR82Status->EvInfo[securityIdx].Security, 0x00, sizeof(T_MBT_JSR82_SET_SECURITY));
						//TRUE�� �����ϴ� �� �ƴѰ� ? 
						localSetting &= ~SETTING_LOCAL_SECURITY;
					}
					securityIdx = -1;
				}

			}
			break;

		case BT_CMD_SD_STOP_DEVICE_DISCOVERY:
			if(pm->cmd_status != BT_CS_GN_SUCCESS)
			{
				JSR82_sdStatus = BTSD_IDLE;
			}
			break;

		case BT_CMD_SD_REGISTER_SERV_EXT:
		case BT_CMD_SD_REGISTER_CUSTOM_SERVICE_EXT:
			{
				switch(pm->cmd_status)
				{
					case BT_CS_GN_SUCCESS:
					case BT_CS_GN_PENDING:
					{
						T_MBT_JSR82_STATUS* jsr82Status = (T_MBT_JSR82_STATUS *) MBT_SDC_GetRecord(MBTSDC_REC_JSR82_STATUS);
						int event_index = -1;
						
						event_index = mbt_jsr82_getEmptyIdx();
						
						if(event_index == -1)
						{
							MBT_FATAL("EVENT INFO NO FREE SPACE...");
							mbt_postevent(MBTEVT_JSR82_SD_RECORD_CREATE_FAIL, 0);
						}
						else
						{
							jsr82Status->EvInfo[event_index].Used = TRUE;
							jsr82Status->EvInfo[event_index].Val.SvcHandle = gJSR82_Handle;
							jsr82Status->EvInfo[event_index].ServerHandle = gSvcHandle;
							mbt_postevent(MBTEVT_JSR82_SD_RECORD_CREATE_SUCCESS, event_index);
						}
						break;
					}

					case BT_CS_SD_LOCAL_SERVICE_DB_FULL:
						MBT_WARN("Registering service is failed: DB FULL", 0, 0, 0);
						mbt_postevent(MBTEVT_JSR82_SD_RECORD_CREATE_FAIL, 0);
						break;

					case BT_CS_SD_SERVICE_RECORD_EXISTS:
						MBT_WARN("Registering service is failed: RECORD EXISTS", 0, 0, 0);
						mbt_postevent(MBTEVT_JSR82_SD_RECORD_CREATE_FAIL, 0);
						break;
						
					default:
						MBT_WARN("Registering service is failed : %x", pm->cmd_status, 0, 0);
						mbt_postevent(MBTEVT_JSR82_SD_RECORD_CREATE_FAIL, 0);
						break;
						
				}
			}
			break;
	}
}

void mbt_jsr82_ev_rm_bonded(bt_ev_msg_type* bt_ev_msg_ptr)
{
	//nick name update �ʿ���. 
	int i;
	T_MBT_PAIRED_DEV_LIST* btPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	mbt_gap_update_pairedList();
	for(i=0; i < btPairedList->PairedCount; i++)
	{
		if(!bdcmp(btPairedList->PairedList[i].BdAddr, bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes))
		{
			mbt_gap_setnickname(bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes, 
									btPairedList->PairedList[i].Name);
			strcpy(btPairedList->PairedList[i].NickName, btPairedList->PairedList[i].Name);
			break;
		}
	}
	mbt_gap_restore_role_switch(bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes);
	bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes);

	mbt_postevent(MBTEVT_JSR82_BOND_SUCCESS, 0);
}

void mbt_jsr82_ev_rm_bondFail(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	mbt_gap_restore_role_switch(bt_ev_msg_ptr->ev_msg.ev_rm_bondf.bd_addr.bd_addr_bytes);
	bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, bt_ev_msg_ptr->ev_msg.ev_rm_bondf.bd_addr.bd_addr_bytes);
	mbt_postevent(MBTEVT_JSR82_BOND_FAIL, 0);
}

void mbt_jsr82_ev_rm_deviceUpdated(bt_ev_msg_type* bt_ev_msg_ptr)
{
	//bt_ev_gn_cmd_done_type* pm =    (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;
	bt_ev_rm_device_updated_type* devUpdate = (bt_ev_rm_device_updated_type*)&bt_ev_msg_ptr->ev_msg;
	
	switch (devUpdate->update_status)
	{
		case BT_RM_DUS_UNBONDED_B: //Unpair , Unpair all �̰� �����.
			mbt_gap_update_pairedList();
			break;

		case BT_RM_DUS_SECURITY_B:
			if(SetSecurity_cmd_state == BT_RM_CMD_SET_DEVICE_SECURITY_FOR_JSR82)
			{
				MBT_WARN("SET_DEVICE_SECURITY OK!!!",0,0,0);
			}
			else if(SetSecurity_cmd_state == BT_RM_CMD_SET_SERVICE_SECURITY_FOR_JSR82)
			{
				MBT_WARN("SET_SERVICE_SECURITY OK!!!",0,0,0);
			}
			break;
	}
}

void mbt_jsr82_ev_rm_authoReq(bt_ev_msg_type* bt_ev_msg_ptr)
{
	MBT_WARN("mbt_jsr82_EventCallback unexpected BT_EV_RM_AUTHORIZE_REQUEST received!!!",0,0,0);
	authoReqJSR82 = MBT_TRUE;
	mbt_gap_ev_rm_authoReq(bt_ev_msg_ptr);
}

void mbt_jsr82_ev_sd_discoveryResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	if(gDeviceRecordsIdx < MBT_MAXNUM_SEARCH_DEV)
	{
		MBT_INT nSearchIdx, nPairedIdx;
		T_MBT_SEARCHED_DEV_LIST* btSearchList = (T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);
		T_MBT_PAIRED_DEV_LIST* btPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);

		//Duplicated device filtering
		for(nSearchIdx=0; nSearchIdx< btSearchList->SearchCount ; nSearchIdx++)
		{
			if(!bdcmp(btSearchList->SearchList[nSearchIdx].BdAddr, bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.bd_addr.bd_addr_bytes))
			{
				MBT_WARN("Duplicated device filtering : BD ADDR (%s)", bdAddrToString(btSearchList->SearchList[nSearchIdx].BdAddr), 0, 0);
				return;
			}
		}

		//Paired device verify
		for(nPairedIdx=0; nPairedIdx <btPairedList->PairedCount ; nPairedIdx++)
		{
			if(!bdcmp(btPairedList->PairedList[nPairedIdx].BdAddr, bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.bd_addr.bd_addr_bytes))
			{
				btSearchList->SearchList[nSearchIdx].bPaired = MBT_TRUE;
				break;
			}
		}
		
		bdcpy(btSearchList->SearchList[btSearchList->SearchCount].BdAddr,bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.bd_addr.bd_addr_bytes);
		strcpy(btSearchList->SearchList[btSearchList->SearchCount].Name, (char *)"");
		btSearchList->SearchList[btSearchList->SearchCount].ServiceClass = (MBT_SHORT)bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.service_class;
		btSearchList->SearchList[btSearchList->SearchCount].MajorClass = (MBT_SHORT)(bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.major_device_class)>>8;
		btSearchList->SearchList[btSearchList->SearchCount].MinorClass = (MBT_SHORT)bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.minor_device_class;
		gDeviceRecordsIdx = btSearchList->SearchCount++;

		MBT_WARN("Search device count = %d", btSearchList->SearchCount, 0, 0);
		mbt_postevent(MBTEVT_JSR82_INQUIRY_RES, 0);

	}
}

void mbt_jsr82_ev_sd_discoveryComplete(bt_ev_msg_type* bt_ev_msg_ptr)
{
	//T_MBT_SEARCHED_DEV_LIST* btSearchList = (T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);

	if(JSR82_sdStatus == BTSD_CANCEL)
	{
		JSR82_sdStatus = BTSD_IDLE;
		mbt_postevent(MBTEVT_JSR82_DEV_DISCOVERY_CANCEL_SUCCESS, 0);
	}
	else
	{
		JSR82_sdStatus = BTSD_IDLE;
		
		if(gDeviceRecordsIdx == 0) // LEECHANGHOON 2008-1-14 ã�� ������ 0�� ���.
		{
			mbt_postevent(MBTEVT_JSR82_INQUIRY_FAIL, 0);
		}
		else
		{
			mbt_postevent(MBTEVT_JSR82_INQUIRY_SUCCESS, 0);
			//memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btSearchList->SearchList[0].BdAddr, MBT_BDADDR_LEN);
			//jsr82������ name respand�� ������ ȣ�����ش�.
			//bt_cmd_sd_get_device_name(mbt_sd_app_id, &addr);
		}
	}
}

void mbt_jsr82_ev_sd_nameResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	//MBT_INT i;
				
	//T_MBT_SEARCHED_DEV_LIST* btSearchList = (T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);

	//jsr82������ searching device�� get name�� ���� �ʴ´�. 
	T_MBT_NAME_RES* sdcNameRes = (T_MBT_NAME_RES*)mbt_sdc_getrecord(MBTSDC_REC_GAP_NAMERES);
	strcpy(sdcNameRes->Name, (char*)bt_ev_msg_ptr->ev_msg.ev_sd_dname.device_name_str);
	bdcpy(sdcNameRes->BdAddr, bt_ev_msg_ptr->ev_msg.ev_sd_dname.bd_addr.bd_addr_bytes);
	mbt_postevent(MBTEVT_JSR82_NAME_DISCOVERY_SUCCESS, 0);
	
	/*
	//searching �� ó�� 
	for(i=0; i< btSearchList->SearchCount ; i++)
	{
		if(!bdcmp(btSearchList->SearchList[i].BdAddr, bt_ev_msg_ptr->ev_msg.ev_sd_dname.bd_addr.bd_addr_bytes))
		{
			strcpy(btSearchList->SearchList[i].Name, (char *)bt_ev_msg_ptr->ev_msg.ev_sd_dname.device_name_str);
			break;
		}
	}
	btNameRespIdx++;

	if(JSR82_sdStatus == BTSD_CANCEL)
	{
		btNameRespIdx = 0;
		JSR82_sdStatus = BTSD_IDLE;
		mbt_postevent(MBTEVT_JSR82_DEV_DISCOVERY_CANCEL_SUCCESS, 0);
	}
	else if(btSearchList->SearchCount == btNameRespIdx)
	{
		btNameRespIdx = 0;
		mbt_postevent(MBTEVT_JSR82_NAME_DISCOVERY_RES, 0);	//yucha 2007/12/16 added
		mbt_postevent(MBTEVT_JSR82_NAME_DISCOVERY_SUCCESS, 0);
	}
	else
	{
		mbt_postevent(MBTEVT_JSR82_NAME_DISCOVERY_RES, 0);
		memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btSearchList->SearchList[btNameRespIdx].BdAddr, MBT_BDADDR_LEN);
		bt_cmd_sd_get_device_name(mbt_sd_app_id, &addr);
	}
	*/
}

void mbt_jsr82_ev_sd_serviceSearchResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	int i,j;
	T_MBT_BDADDR svc_bd_addr;
	bt_sd_srv_rec_type*       pRec;
	T_MBT_PAIRED_DEV_LIST* btPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	//yucha 2008/05/07 start: separate service search from attribute search
	if(svcSearchState == BTSD_SVC_SEARCH)
	{
		mbt_jsr82_initSvcSearchVar();
	}
	bt_sd_srv_rec_iter.init( BT_SD_DB_TYPE_SRV_SRCH_RESULT_DB, BT_SD_ITER_ALL);
	
	for(pRec = (bt_sd_srv_rec_type*)bt_sd_srv_rec_iter.first();
		pRec != 0 && (numRecs < MBT_JSR82_MAX_SEARCH_UUID_NUM);
		pRec = (bt_sd_srv_rec_type*)bt_sd_srv_rec_iter.next())
	{
		MBT_PI("mbt_jsr82_ev_sd_serviceSearchResp new!! record.#numRecs:%d,srv_rec_id:0x%x ,pSrcRec->num_srv_attr:%d", numRecs, pRec->srv_rec_id, pRec->num_srv_attr);
		if(svcSearchState == BTSD_SVC_SEARCH)
		{
//-------------------- svcHandle�� local buffer�� ������.
			mb_jsr82_copySvcHandle(&svcHandle,pRec);
//-------------------- svcHandle�� local buffer�� ���� ��.
			continue;
		}
		MBT_PI("sdcJSR82Status->SvcRecNum:%d",sdcJSR82Status->SvcRecNum,0,0);
		mbt_jsr82_getsearchresult(&searchedSvcRec[sdcJSR82Status->SvcRecNum], pRec );
	}
		
	sdcJSR82Status->SvcRecNum = numRecs;	
	if(checkKeepSearch(&svcSearchState, &attriInfo, &svcHandle))
	{
		//�ѹ��� �˻� ������ max�� 3�� attribute.
		svcSearchState = BTSD_SVC_ATTRI_SEARCH;
		MBT_PI("Attribute search starting... svcHandle total:%d, current:%d, attriInfo.curAttriIndex:%d", svcHandle.totHdlCnt,svcHandle.curHdlIndex,attriInfo.curAttriIndex);
		for(i=0; i<svcHandle.totHdlCnt;i++)
		{
			MBT_PI("svcHandle[%d]:0x%x", i, svcHandle.svcHdl[i], 0);
		}
//------------------------ to minimize l2cap payload size under 30 byte
		mbt_jsr82_fillSearchAttribute(&attr_id_list, &attriInfo);
		MBT_PI("svcHandle.totHdlCnt:%d, svcHandle.curHdlInex:%d ", svcHandle.totHdlCnt, svcHandle.curHdlIndex, 0);
		MBT_PI("attriInfo.totAttriCnt:%d, attriInfo.curAttriIndex:%d ", attriInfo.totAttriCnt, attriInfo.curAttriIndex, 0);
		bt_cmd_sd_send_service_attribute_req(mbt_jsr82_app_id, &svcSearchBdAddr, svcHandle.svcHdl[svcHandle.curHdlIndex], &attr_id_list, BT_SD_DEFAULT_MAX_ATTR_BYTE_COUNT);
		//�ϳ��� svcHandle�� ���ؼ� sttribute searching�� �Ϸ��ߴ��� Ȯ�� 
//		mbt_jsr82_checkLastAttribute(
		if(checkLastAttribute(&attriInfo))
		{
			numRecs++;
			//serviceRecCurIndex = 0;
			//��� svcHandle�� ���ؼ� attribute searching�� �Ϸ��ߴ��� Ȯ�� 
			if(checkLastSvcHandle(&svcHandle))
			{
				svcSearchState = BTSD_SVC_IDLE;
				MBT_PI("Last SvcHandle, Attribute Search started!!! svcSearchState:%d",svcSearchState,0,0);
			}
			else
			{
				//Attrinbute cur index�� �ʱ�ȭ �ϰ�, ���� svcHandle�� ������. ���� svcHandle�� ���� �˻��� �غ� ��. 
				attriInfo.curAttriIndex = 0x00;
				svcHandle.curHdlIndex++;
				MBT_PI("Ready to search attribute for next SvcHandle svcHandle.curHdlIndex:%d",svcHandle.curHdlIndex,0,0);
			}
		}
//------------------------
	}
	else
	{
		MBT_PI("Evt form mbt_jsr82_svc_discovery SvcRecNum: %d", sdcJSR82Status->SvcRecNum,0,0);
		bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, bt_ev_msg_ptr->ev_msg.ev_sd_service_search_resp.bd_addr.bd_addr_bytes);
		mbt_postevent(MBTEVT_JSR82_SVC_DISCOVERY_SUCCESS, (MBT_SHORT)sdcJSR82Status->SvcRecNum);
		bSearchPending = MBT_FALSE;
		svcSearchState = BTSD_SVC_IDLE;
	}
	
//yucha 2008/05/07 end
}

void mbt_jsr82_ev_sd_errorResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, bt_ev_msg_ptr->ev_msg.ev_sd_error_resp.bd_addr.bd_addr_bytes);
	/*	This event is generated in response to error conditions encountered 
		while executing bt_cmd_sd_search_service() or bt_cmd_sd_get_device_ name() command */
	mbt_postevent(MBTEVT_JSR82_SVC_DISCOVERY_FAIL, 0);
	bSearchPending = MBT_FALSE;
	svcSearchState = BTSD_SVC_IDLE;
}

void mbt_jsr82_ev_sd_timeoutResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, bt_ev_msg_ptr->ev_msg.ev_sd_timeout_resp.bd_addr.bd_addr_bytes);
	/* 	This event is generated in response to a timeout in receiving a 
		reply to either bt_cmd_sd_send_service_search_req() or bt_cmd_sd_send_service_attribute_req()
		or bt_cmd_sd_search_service() or bt_cmd_sd_get_server_ channel_number() */
	mbt_postevent(MBTEVT_JSR82_SVC_DISCOVERY_FAIL, 0);
	bSearchPending = MBT_FALSE;
	svcSearchState = BTSD_SVC_IDLE;
}

void mbt_jsr82_ev_sd_discoverableModeRes(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_ev_sd_discoverable_mode_resp_type *pEvt = &bt_ev_msg_ptr->ev_msg.ev_sd_discv_mode_resp;
		
	switch(pEvt->discv_mode)
	{
		case BT_SD_SERVICE_DISCOVERABLE_MODE_NONE:
			//system_bt_var_set(BTVAR_VISIBLE, MBT_TRUE);
			break;
		case BT_SD_SERVICE_DISCOVERABLE_MODE_GENERAL:
			//system_bt_var_set(BTVAR_VISIBLE, MBT_FALSE);
			break;
		case BT_SD_SERVICE_DISCOVERABLE_MODE_LIMITED:
			break;
	}
}
/********************************************************************************
*	Prototype	: MBT_VOID mbt_jsr82_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
*	Description	: EV Callback ó���� ����.
********************************************************************************/
MBT_VOID mbt_jsr82_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
{
	MBT_WARN("JSR82_EventType : 0x%x", (bt_ev_msg_ptr->ev_hdr.ev_type ),0,0);
	MBT_PI( __func__"##########################", 0, 0, 0);
	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
//-------------------------------- RM START   ---------------------------------------//
		case BT_EV_GN_CMD_DONE:
			mbt_jsr82_ev_cmdDone(bt_ev_msg_ptr);
			break;
		
		//jsr82������ ����. 
		case BT_EV_RM_BONDED:
			mbt_jsr82_ev_rm_bonded(bt_ev_msg_ptr);
			break;
			
		//jsr82������ ����. 	
		case BT_EV_RM_BOND_FAILED:
			mbt_jsr82_ev_rm_bondFail(bt_ev_msg_ptr);
			break;
			
		//�߻��� �� ���� evt ���� �߻��ϸ� ������ �����ؾ� ��. 		
		case BT_EV_RM_PIN_REQUEST:
			MBT_WARN("mbt_jsr82_EventCallback unexpected BT_EV_RM_PIN_REQUEST received!!!",0,0,0);
			break;
					
		case BT_EV_RM_DEVICE_UPDATED:
			mbt_jsr82_ev_rm_deviceUpdated(bt_ev_msg_ptr);
			break;
						
		case BT_EV_RM_LINK_STATUS:
			MBT_WARN("mbt_jsr82_EventCallback unexpected BT_EV_RM_LINK_STATUS received!!!",0,0,0);
			break;
							
		case BT_EV_RM_AUTHORIZE_REQUEST:	 		
			mbt_jsr82_ev_rm_authoReq(bt_ev_msg_ptr);
			break;
								
		case BT_EV_RM_RADIO_DISABLED:
			break;
									
		case BT_EV_RM_CONNECTED_ACL:
			// �� �̺�Ʈ�� RM���� ���� �ʰ� JSR�� �ñ� ? 
			// �ȿ� �� ����....
			//jsr82Handle = bt_ev_msg_ptr->ev_msg.ev_rm_conna.handle;
			break;
											
		case BT_EV_RM_DISCONNECTED_ACL:
			break;

//-------------------------------- RM END  ---------------------------------------//

//-------------------------------- SD START  ---------------------------------------//

		case BT_EV_SD_DEVICE_DISCOVERY_RESP: //Inquiry response
			mbt_jsr82_ev_sd_discoveryResp(bt_ev_msg_ptr);
		  	break;
			
		case BT_EV_SD_DEVICE_DISCOVERY_COMPLETE: //Inquary complete.
			mbt_jsr82_ev_sd_discoveryComplete(bt_ev_msg_ptr);
			break;
			
		case BT_EV_SD_DEVICE_NAME_RESP:
			mbt_jsr82_ev_sd_nameResp(bt_ev_msg_ptr);
			break;
		
		case BT_EV_SD_SERVICE_SEARCH_RESP:				
			mbt_jsr82_ev_sd_serviceSearchResp(bt_ev_msg_ptr);
			break;
		
		case BT_EV_SD_ERROR_RESP:
			mbt_jsr82_ev_sd_errorResp(bt_ev_msg_ptr);
			break;
		
		case BT_EV_SD_TIMEOUT_RESP:
			mbt_jsr82_ev_sd_timeoutResp(bt_ev_msg_ptr);
			break;
			
		case BT_EV_SD_DISCOVERABLE_MODE_RESP:
			mbt_jsr82_ev_sd_discoverableModeRes(bt_ev_msg_ptr);
			break;
//-------------------------------- SD END  ---------------------------------------//
		default:
		{
		  	MBT_ERR( "SDEvCb - unexpect event %x", 
					 bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0 );
		  	break;
		}
	}
}


/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_enable(MBT_VOID)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_VOID mbt_jsr82_enable(MBT_VOID)
{
	T_MBT_JSR82_STATUS* jsr82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	bt_service_id_type	id_type3;
	bt_cmd_status_type stat;
	
	memset((void*)jsr82Status, 0x00, sizeof(T_MBT_JSR82_STATUS));

	if(mbt_jsr82_app_id == BT_APP_ID_NULL) 
	{
		mbt_jsr82_app_id = bt_cmd_ec_get_app_id_and_register(mbt_jsr82_EventCallback);
	}
	else
	{
		MBT_FATAL("##JSR82 Initialize Over time Error. app_id ");
	}
	
	id_type3.service_id_method = BT_SIM_SDP_UUID;
	id_type3.sdp_uuid = MBT_SVCUUID_SERIAL_PORT;
	
	//�ٸ� ���� disable ��Ű�� ��ƾ�� dual ������ ���ŵ� ����. 
	stat = bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type3, BT_RM_SL_0_NONE, MBT_FALSE, MBT_FALSE);
	
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_disable();
#endif
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_disable();
#endif
#if (MBT_DUN == MBT_TRUE)
	mbt_dun_disable();
#endif
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_disable();
#endif
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_server_disable();
#endif
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_client_disable();
#endif
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_server_disable();
#endif
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_disable();
#endif
#if (MBT_BPP == MBT_TRUE)
	mbt_bpp_disable();
#endif
#if (MBT_AG == MBT_TRUE)
	//mbt_ag_disable();
#endif
#if (MBT_SAP == MBT_TRUE)
	mbt_sap_server_disable();
#endif
#if (MBT_BIP == MBT_TRUE)
	mbt_bip_initiator_disable();
#endif
#if (MBT_BIP == MBT_TRUE)
	mbt_bip_responder_disable();
#endif
#if (MBT_PBAP == MBT_TRUE)
	mbt_pbap_server_disable();
#endif

	rex_sleep(200);
	if(mbt_jsr82_CheckCmdStatus(stat))// 2006-11-06 -> SPP Connect�� PINCODE �߻� ���� 
	{
		mbt_postevent(MBTEVT_JSR82_ENABLE_SUCCESS, 0);
		jsr82Status->bEnabled = MBT_TRUE;
		JSR82BT_enable = MBT_TRUE;
	}
	else
	{
		mbt_postevent(MBTEVT_JSR82_ENABLE_FAIL, 0);
		jsr82Status->bEnabled = MBT_FALSE;
		JSR82BT_enable = MBT_FALSE;
	}
}

/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_disable(MBT_VOID)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_VOID mbt_jsr82_disable(MBT_VOID)
{
	T_MBT_JSR82_STATUS* jsr82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	T_MBT_MYINFO* sdcMyInfo = (T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);
	bt_service_id_type	id_type3;
	bt_cmd_status_type stat;
  	bt_sd_service_discoverable_mode_type mode;

	SetSecurity_cmd_state = BT_RM_CMD_NONE; // LEECHANGHOON 2008-1-28 MBT����
	bt_cmd_rm_set_device_security(mbt_jsr82_app_id, MBT_NULL, MBT_FALSE);
	rex_sleep(500);
	id_type3.service_id_method = BT_SIM_DEFAULT_L2CAP;	
	id_type3.sdp_uuid = 0x00;
	stat = bt_cmd_rm_set_sm4( mbt_jsr82_app_id, 
										   &id_type3,
										   BT_SEC_NONE,
										   MBT_FALSE, MBT_FALSE );
 
	id_type3.service_id_method = BT_SIM_SDP_UUID;
	id_type3.sdp_uuid = MBT_SVCUUID_SERIAL_PORT;
	stat = bt_cmd_rm_set_sm4(mbt_jsr82_app_id, &id_type3, BT_SEC_NONE, MBT_FALSE, MBT_FALSE);
	rex_sleep(500);
	//bt_cmd_rm_set_device_security(mbt_rm_app_id, MBT_NULL, MBT_FALSE);
	rex_sleep(500);
	stat = bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type3, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_TRUE, MBT_FALSE);

#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_enable();
#endif
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_enable();
#endif
#if (MBT_DUN == MBT_TRUE)
	mbt_dun_enable();
#endif
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_enable();
#endif
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_server_enable();
#endif
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_client_enable();
#endif
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_server_enable();
#endif
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_enable();
#endif
#if (MBT_BPP == MBT_TRUE)
	mbt_bpp_enable();
#endif
#if (MBT_AG == MBT_TRUE)
	//mbt_ag_enable();
#endif
#if (MBT_SAP == MBT_TRUE)
	mbt_sap_server_enable();
#endif
#if (MBT_BIP == MBT_TRUE)
	mbt_bip_initiator_enable();
#endif
#if (MBT_BIP == MBT_TRUE)
	mbt_bip_responder_enable();
#endif
#if (MBT_PBAP == MBT_TRUE)
	mbt_pbap_server_enable();
#endif

	// LEECHANGHOON 2008-3-12 [START]
	// mbt_jsr82_set_discoverable()�� ���� �����  visible ��带 �����Ѵ�.					
	mbt_gap_setvisible(sdcMyInfo->bVisible);
	// LEECHANGHOON 2008-3-12 [END]
	if(mbt_jsr82_CheckCmdStatus(stat))
	{
		mbt_postevent(MBTEVT_JSR82_DISABLE_SUCCESS, 0);
		jsr82Status->bEnabled = MBT_FALSE;
		JSR82BT_enable = MBT_FALSE;
	}
	else
	{
		mbt_postevent(MBTEVT_JSR82_DISABLE_FAIL, 0);
		jsr82Status->bEnabled = MBT_TRUE;
		JSR82BT_enable = MBT_TRUE;
	}
}

/*=========================================================================== 
*	Prototype		: MBT_UINT mbt_jsr82_get_discoverable(MBT_VOID)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_UINT mbt_jsr82_get_discoverable(MBT_VOID)
{
      MBT_UINT mode;
      T_MBT_MYINFO* btMyInfo =(T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);

      //mode = bt_sd_get_service_discoverable_mode();

      if (btMyInfo->bVisible == MBT_FALSE)
      {
        mode = MBT_DISCOVERABLE_MODE_NONE;
      }
      else 
      {
        mode = MBT_DISCOVERABLE_MODE_GIAC;
      }
	return mode;
	
	#if 0	// LEECHANGHOON 2008-3-12
	if(!mbt_sdc_getvalue(MBTSDC_VAL_GAP_VISIBLE))
		return MBT_DISCOVERABLE_MODE_NONE; //BT_SD_SERVICE_DISCOVERABLE_MODE_NONE;
	else
		return MBT_DISCOVERABLE_MODE_GIAC;
	#endif
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_set_discoverable(MBT_UINT Mode)
*	Description		: 
*	Return			:
*	Expected Event	: BT_EV_SD_DISCOVERABLE_MODE_RESP
===========================================================================*/
MBT_BOOL mbt_jsr82_set_discoverable(MBT_UINT Mode)
{
	bt_cmd_status_type                   stat;
  	bt_sd_service_discoverable_mode_type mode;
	MBT_BOOL bVisible;
	T_MBT_MYINFO* btMyInfo =(T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);
	
//	discoverable_mode = Mode;
	
	// LEECHANGHOON 2008-3-12 MBT����
	switch(Mode)
	{
		case MBT_DISCOVERABLE_MODE_NONE:
			mode = BT_SD_SERVICE_DISCOVERABLE_MODE_NONE;
			bVisible = MBT_FALSE;
			break;
		case MBT_DISCOVERABLE_MODE_GIAC:
			mode = BT_SD_SERVICE_DISCOVERABLE_MODE_GENERAL;
			bVisible = MBT_TRUE;
			break;
#if 0
		case MBT_DISCOVERABLE_MODE_LIAC:
			mode = BT_SD_SERVICE_DISCOVERABLE_MODE_LIMITED;
			bVisible = MBT_TRUE;
			break;
		default:
			mode = BT_SD_SERVICE_DISCOVERABLE_MODE_NONE;
			bVisible = MBT_FALSE;
			break;
#else
		default:
			return MBT_FALSE;
#endif
	}
	
	TASKLOCK();
 	bt_cmd_rm_disable_discoverability(mbt_rm_app_id, !bVisible);
  	TASKFREE();
	
	stat = bt_cmd_sd_set_service_discoverable_mode(mbt_sd_app_id, mode);

	btMyInfo->bVisible = bVisible;
	
  	return mbt_jsr82_CheckCmdStatus(stat);
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_set_security(T_MBT_JSR82_SET_SECURITY* Security)
*	Description		: 
*	Return			:
*	Expected Event	: BT_EV_RM_DEVICE_UPDATED
===========================================================================*/
//MBT_BOOL mbt_jsr82_set_security(T_MBT_JSR82_SET_SECURITY* Security)
MBT_BOOL mbt_jsr82_set_security(MBT_UINT Handle,T_MBT_JSR82_SET_SECURITY* Security)
{
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	bt_security_type sec = MBT_GAP_SECURITY_NONE;
	bt_cmd_status_type stat;
	
	if((securityIdx = mbt_jsr82_getEmptyIdx())== -1)
	{
		mbt_postevent(MBTEVT_JSR82_SECURITY_SET_FAIL, securityIdx);
		return MBT_FALSE;
	}
	else
	{
		MBT_PI("set security idx (%d)", securityIdx, 0, 0);
	}
	
	//memcpy((void*)&sdcJSR82Status->Security, (void*)Security, sizeof(T_MBT_JSR82_SET_SECURITY));
	sdcJSR82Status->EvInfo[securityIdx].Used = TRUE;
	memcpy((void*)&sdcJSR82Status->EvInfo[securityIdx].Security, (void*)Security, sizeof(T_MBT_JSR82_SET_SECURITY));

	if(Security->bEncrypt == MBT_TRUE && Security->bAuthenticate == MBT_TRUE)
	{
		sec = MBT_GAP_SECURITY_AUTHENTICATE_AND_ENCRYPT;
	}
	else if(Security->bEncrypt == MBT_FALSE && Security->bAuthenticate == MBT_TRUE)
	{
		sec = MBT_GAP_SECURITY_AUTHENTICATE;
	}
	else if(Security->bEncrypt == MBT_FALSE && Security->bAuthenticate == MBT_FALSE)
	{
		sec = MBT_GAP_SECURITY_NONE;
	}
	else
	{
		MBT_WARN(">>>> ERROR",0,0,0);
	}

  	localSetting |= SETTING_LOCAL_SECURITY;
	SetSecurity_cmd_state = BT_RM_CMD_SET_DEVICE_SECURITY_FOR_JSR82;
  	stat = bt_cmd_rm_set_device_security(mbt_jsr82_app_id, MBT_NULL, sec);

	return mbt_jsr82_CheckCmdStatus(stat);
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_get_myCoD()
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_BOOL mbt_jsr82_get_myCoD(MBT_VOID)
{

	T_MBT_MYINFO *myInfo = (T_MBT_MYINFO *)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);

	MBT_PI("        Service Class : %x", myInfo->ServiceClass, 0, 0);
	MBT_PI("        Major Class : %x", myInfo->MajorClass, 0, 0);
	MBT_PI("        Minor Class : %x", myInfo->MinorClass, 0, 0);
	
	//myInfo->ServiceClass>>=5;
	//myInfo->MinorClass >>=2;

	return MBT_TRUE;
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_set_serviceSecurity(T_MBT_JSR82_SET_SECURITY* Security)
*	Description		: 
*	Return			:
*	Expected Event	: BT_CMD_RM_SET_SERVICE_SECURITY
===========================================================================*/
static MBT_VOID mbt_jsr82_set_serviceSecurity(MBT_VOID)
{
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	T_MBT_JSR82_SET_SECURITY Security;
	bt_security_type sec = MBT_GAP_SECURITY_NONE;
	bt_cmd_status_type stat;
	bt_service_id_type	service_ident;
	
	MBT_PI( " �ߡ� ServiceSecurity_AUTHENTICATE[%d] ENCRYPT[%d]�ߡ�", 
	sdcJSR82Status->Security.bAuthenticate, sdcJSR82Status->Security.bEncrypt, 0);

	memset((void*)&service_ident, 0x00, sizeof(bt_service_id_type));
//	memcpy((void*)&Security, (void*)&sdcJSR82Status->Security, sizeof(T_MBT_JSR82_SET_SECURITY));
	memcpy((void*)&Security, (void*)&sdcJSR82Status->EvInfo[securityIdx].Security, sizeof(T_MBT_JSR82_SET_SECURITY));

	if(Security.bEncrypt == MBT_TRUE && Security.bAuthenticate == MBT_TRUE)
	{
		sec = MBT_GAP_SECURITY_AUTHENTICATE_AND_ENCRYPT;
	}
	else if(Security.bEncrypt == MBT_FALSE && Security.bAuthenticate == MBT_TRUE)
	{
		sec = MBT_GAP_SECURITY_AUTHENTICATE;
	}
	else if(Security.bEncrypt == MBT_FALSE && Security.bAuthenticate == MBT_FALSE)
	{
		sec = MBT_GAP_SECURITY_NONE;
	}
	else
	{
		MBT_WARN(">>>> mbt_jsr82_set_serviceSecurity ERROR",0,0,0);
	}
	
	service_ident.service_id_method = BT_SIM_DEFAULT_L2CAP;	
	stat = bt_cmd_rm_set_sm4( mbt_jsr82_app_id, 
										   &service_ident,
										   sec,
										   Security.bAuthorize, MBT_FALSE );
	
	// SDP�� security������ �ȵǾ�� �Ѵ�.
	service_ident.service_id_method = BT_SIM_L2CAP_PSM;
	service_ident.l2cap_psm = BT_L2_PSM_SDP;	
	stat = bt_cmd_rm_set_sm4( mbt_jsr82_app_id, 
										   &service_ident,
										   MBT_GAP_SECURITY_NONE,
										   MBT_FALSE, MBT_FALSE );
	
	service_ident.service_id_method = BT_SIM_SDP_UUID;
	service_ident.sdp_uuid = MBT_SVCUUID_SERIAL_PORT;	
//	stat = bt_cmd_rm_set_sm4( mbt_jsr82_app_id, 
   stat = bt_cmd_rm_set_sm4( mbt_rm_app_id, 
										   &service_ident,
										   sec,
										   Security.bAuthorize, MBT_FALSE );
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_set_myCoD(MBT_SHORT ServiceCalss, MBT_BYTE MajorClass, MBT_BYTE MinorClass)
*	Description		: 
*	Return			:
*	Expected Event	: BT_CS_GN_SUCCESS
===========================================================================*/
MBT_BOOL mbt_jsr82_set_myCoD(MBT_SHORT ServiceCalss, MBT_BYTE MajorClass, MBT_BYTE MinorClass)
{
	bt_cmd_status_type  stat;
	bt_cod_type         cod;
	T_MBT_MYINFO* btMyInfo = (T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);

	btMyInfo->ServiceClass 	= (ServiceCalss << 5) & 0xFFE0;
	btMyInfo->MajorClass	= (MajorClass) & 0x1F;
	btMyInfo->MinorClass	= (MinorClass << 2) & 0xFC;

	MBT_PI(__func__"ServiceCalss[0x%x],MajorClass[0x%x], MinorClass[0x%x] ", btMyInfo->ServiceClass, btMyInfo->MajorClass, btMyInfo->MinorClass);

	memset((void*)&cod, 0x00, sizeof(cod));
	mbt_jsr82_build_class( ServiceCalss, MajorClass, MinorClass, &cod );
	
	localSetting |= SETTING_LOCAL_COD;
	MBT_PI(__func__"cod_bytes[0] 0x%x, cod_bytes[1] 0x%x, cod_bytes[2] 0x%x", 
	                           cod.cod_bytes[0],cod.cod_bytes[1],cod.cod_bytes[2]);  

	stat = bt_cmd_rm_set_local_info(mbt_jsr82_app_id, &cod, MBT_NULL );
	if(mbt_jsr82_CheckCmdStatus(stat))
	{
		return MBT_TRUE;
	}
	else
	{
		localSetting &= ~SETTING_LOCAL_COD;
		return MBT_FALSE;
	}
}

/*=========================================================================== 
*	Prototype		: T_MBT_GAP_SECURITY mbt_jsr82_get_encrypted(T_MBT_BDADDR RemoteBDAddr)
*	Description		: 
*	Return			: Sync
*	Expected Event	:
===========================================================================*/
T_MBT_GAP_SECURITY mbt_jsr82_get_encrypted(T_MBT_BDADDR RemoteBDAddr)
{
	T_MBT_PAIRED_DEV_LIST* sdcPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
	int i;
	
	MBT_PI(" Remote Device: %s", bdAddrToString(RemoteBDAddr),0,0);

	for(i=0; i<sdcPairedList->PairedCount; i++)
	{
		MBT_PI(" PairedList[%d].BdAddr: %s",i,bdAddrToString(sdcPairedList->PairedList[i].BdAddr),0);

		if(!bdcmp(sdcPairedList->PairedList[i].BdAddr, RemoteBDAddr))
			//return sdcPairedList->PairedList[i].Security;
			return MBT_GAP_SECURITY_AUTHENTICATE_AND_ENCRYPT;
	}
	
	// ��ġ�ϴ� device�� pairedlist�� ���� ���. 
	return MBT_GAP_SECURITY_NONE;
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_set_encrypted(T_MBT_BDADDR RemoteBDAddr,T_MBT_GAP_SECURITY Security)
*	Description		: 
*	Return			: Sync
*	Expected Event	: BT_EV_RM_LINK_STATUS( Do not always )
===========================================================================*/
MBT_BOOL mbt_jsr82_set_encrypted(T_MBT_BDADDR RemoteBDAddr,T_MBT_GAP_SECURITY Security)
{
	T_MBT_PAIRED_DEV_LIST* sdcPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
	int i;

	MBT_PI(" Remote Device: %s", bdAddrToString(RemoteBDAddr),0,0);

	for(i=0; i<sdcPairedList->PairedCount; i++)
	{
		MBT_PI(" PairedList[%d].BdAddr: %s",i,bdAddrToString(sdcPairedList->PairedList[i].BdAddr),0);

		if(!bdcmp(sdcPairedList->PairedList[i].BdAddr, RemoteBDAddr))
		{
			sdcPairedList->PairedList[i].Security = Security;
			//return mbt_jsr82_CheckCmdStatus(bt_cmd_rm_set_connection_security(mbt_jsr82_app_id, (bt_bd_addr_type*)RemoteBDAddr, (bt_security_type)Security));
			return mbt_jsr82_CheckCmdStatus(bt_cmd_rm_set_device_security(mbt_jsr82_app_id, (bt_bd_addr_type*)RemoteBDAddr, (bt_security_type)Security));
		}
	}
	return MBT_FALSE;
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_get_authenticated(T_MBT_BDADDR RemoteBDAddr)
*	Description		: 
*	Return			: Sync
*	Expected Event	:
===========================================================================*/
MBT_BOOL mbt_jsr82_get_authenticated(T_MBT_BDADDR RemoteBDAddr)
{
	T_MBT_PAIRED_DEV_LIST* sdcPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
	char buff[19];
	
	int i;
	MBT_PI(" Remote Device: %s", bdAddrToString(RemoteBDAddr),0,0);

	for(i=0; i<sdcPairedList->PairedCount; i++)
	{
		MBT_PI(" PairedList[%d].BdAddr: %s",i,bdAddrToString(sdcPairedList->PairedList[i].BdAddr),0);

		if(!bdcmp(sdcPairedList->PairedList[i].BdAddr, RemoteBDAddr))
		{
			MBT_PI(__func__":MBTSDC_REC_GAP_PAIREDLIST:PairedList[%d].Security:%d", i, (sdcPairedList->PairedList[i].Security), 0);
			//return !(!(sdcPairedList->PairedList[i].Security));
			return MBT_TRUE;
		}
	}

	MBT_PI(__func__":no matched address", 0, 0, 0);
	return MBT_FALSE;
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_pair_req(T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq, MBT_BYTE PinLength)
*	Description		: 
*	Return			: Async
*	Expected Event	: BT_EV_RM_BONDED
===========================================================================*/
//MBT_BOOL mbt_jsr82_pair_req(T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq, MBT_BYTE PinLength)
MBT_BOOL mbt_jsr82_pair_req(MBT_UINT Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq, MBT_BYTE PinLength)

{
	bt_pin_code_type pin;
	bt_bd_addr_type addr;	
	bt_cmd_status_type  stat;
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	MBT_PI(__func__"pin length:%d, PinReq[0]:%c, PinReq[1]:%c", PinLength,PinReq[0],PinReq[1]);
	// LEECHANGHOON 2007-11-16 QBT�� Role_sw_req�� ���� �׻� not accept �Ѵܴ�.
	// Pair req �̽��� ���� �ʿ��Ҷ��� accept�ϵ��� �ϰ� �ٽ� restore ��Ų��.
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);

	// LEECHANGHOON 2008-1-7 Pair_req ��Ҹ� ���� �ʿ�.
	memset((uint8*)jsr82_pairreq_addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)jsr82_pairreq_addr.bd_addr_bytes, (uint8*)addr.bd_addr_bytes, MBT_BDADDR_LEN);
	
	mbt_gap_allow_role_switch(addr.bd_addr_bytes);

	pin.length = PinLength;
	memcpy((uint8*)pin.pin_code, (uint8*)PinReq, MBT_PIN_LEN);

	//�� cmd�� ���� evt�� ��� ������ Ȯ�� �� �� ��. rm? jsr82? 
	//rm ���� ��ü�� �ؾ� �� �� �ʹ�. 

	stat = bt_cmd_rm_bond_ext(mbt_jsr82_app_id, &addr, &pin, TRUE);
	if(mbt_jsr82_CheckCmdStatus(stat) == MBT_FALSE)
	{
		bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, RemoteBDAddr);
		mbt_postevent(MBTEVT_JSR82_BOND_FAIL, 0);
		return MBT_FALSE;
	}
	else
	{
		return MBT_TRUE;
	}
}

/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_pair_res(MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_BYTE PinLength)
*	Description		: 
*	Return			: Async
*	Expected Event	: BT_EV_RM_BONDED
===========================================================================*/
MBT_BOOL mbt_jsr82_pair_res(MBT_UINT Handle, MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_BYTE PinLength)
{
	bt_pin_code_type	pin;
	bt_bd_addr_type addr;
	bt_cmd_status_type  stat;
	T_MBT_PINREPLY* btPinReply =(T_MBT_PINREPLY*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PINREPLY);
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	MBT_SDC("mbt_gap_pairres> bAcceps : %d,  pin length : %d ", bAccept, PinLength, 0);
			
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btPinReply->BdAddr, MBT_BDADDR_LEN);
	
	pin.length = PinLength;
	
	memcpy((uint8*)pin.pin_code, (uint8*)PinRes, MBT_PIN_LEN);
	
	//�� cmd�� ���� evt�� ��� ������ Ȯ�� �� �� ��. rm? jsr82? 
	//rm ���� ��ü�� �ؾ� �� �� �ʹ�. 
	stat = bt_cmd_rm_pin_reply(mbt_jsr82_app_id, &addr,bAccept, &pin);
	if(mbt_jsr82_CheckCmdStatus(stat) == MBT_FALSE)
	{
		bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, addr.bd_addr_bytes);
		mbt_postevent(MBTEVT_JSR82_BOND_FAIL, 0);
		return MBT_FALSE;
	}
	return MBT_TRUE;
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_name_req(T_MBT_BDADDR RemoteBDAddr)
*	Description		: 
*	Return			: Async
*	Expected Event	: BT_EV_SD_DEVICE_NAME_RESP
===========================================================================*/
MBT_BOOL mbt_jsr82_name_req(MBT_UINT Handle, T_MBT_BDADDR RemoteBDAddr)
{
	bt_bd_addr_type     addr;
	bt_cmd_status_type  stat;
	
	// searching �� ������ ���� Ȯ�� �����. 
	JSR82_sdStatus = BTSD_IDLE;	
	memset((byte*)&addr,0x0, sizeof(bt_bd_addr_type));
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);

	stat = bt_cmd_sd_get_device_name(mbt_jsr82_app_id, &addr);
	if(mbt_jsr82_CheckCmdStatus(stat) == MBT_FALSE)
	{
		mbt_postevent(MBTEVT_JSR82_NAME_DISCOVERY_FAIL, 0);
		return MBT_FALSE;
	}
	else
	{
		return MBT_TRUE;
	}
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_dev_discovery(MBT_UINT AccessMode)
*	Description		: Inquiry start
*	Return			: Async
*	Expected Event	: BT_EV_SD_DEVICE_DISCOVERY_RESP
===========================================================================*/
MBT_BOOL mbt_jsr82_dev_discovery(MBT_UINT Handle, MBT_UINT AccessMode)
{
	bt_cmd_status_type			stat;
	bt_bd_addr_type 			addr;
	uint16 bitmap;

	rex_sleep(1000);
	MBT_PI(__func__"AccessMode:%d", AccessMode, 0,0);

	if(MBT_DISCOVERABLE_MODE_LIAC == AccessMode)
	{
		return MBT_FALSE;
	}
	//QBT ��ġ �Լ� ȣ��
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
		
	switch(AccessMode)
	{
		case MBT_DISCOVERABLE_MODE_LIAC:
		  	bitmap = BT_SERVICE_CLASS_LIMITED_DISCOVERABLE_MODE;
		  break;
		default:
			bitmap = BT_SERVICE_CLASS_ALL;
		  break; ; //EBADPARM;
	}

	rex_sleep(1500);
	stat = bt_cmd_sd_discover_devices( mbt_jsr82_app_id, 
										bitmap,  
										&addr,		// Address field
										MBT_MAXNUM_SEARCH_DEV);
	
	if(mbt_jsr82_CheckCmdStatus(stat) == MBT_FALSE)
	{
		return MBT_FALSE;
	}
	else
	{
		return MBT_TRUE;
	}
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_dev_discovery_cancel(MBT_VOID)
*	Description		: 
*	Return			: Async
*	Expected Event	: BT_EV_SD_DEVICE_DISCOVERY_COMPLETE
===========================================================================*/
MBT_BOOL mbt_jsr82_dev_discovery_cancel(MBT_UINT Handle)
{
	bt_cmd_status_type	stat;
	JSR82_sdStatus = BTSD_CANCEL;

	stat = bt_cmd_sd_stop_device_discovery(mbt_jsr82_app_id);
	if(mbt_jsr82_CheckCmdStatus(stat) == MBT_FALSE)
	{
		mbt_postevent(MBTEVT_JSR82_DEV_DISCOVERY_CANCEL_FAIL, 0);
		return MBT_FALSE;
	}
	else
	{
		return MBT_TRUE;
	}

}

MBT_BOOL mbt_jsr82_is_connected(T_MBT_BDADDR RemoteBDAddr)
{
	return mbt_gap_isdeviceconnected(RemoteBDAddr);
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_svc_discovery(T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_SEARCH_SD* SearchInfo, MBT_UINT TransID)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_BOOL mbt_jsr82_svc_discovery(T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_SEARCH_SD* SearchInfo, MBT_UINT TransID)
{
	bt_cmd_status_type               stat;
	uint8                            i,j;
	//bt_sd_uuid128_type			   uuid128;  

	rex_sleep(1500);
	if(RemoteBDAddr == MBT_NULL || bSearchPending == MBT_TRUE)
	{
		MBT_WARN(" mbt_jsr82_svc_discovery, RemoteBDAddr[0]:%d bSearchPending:%d, ",RemoteBDAddr[0],bSearchPending,0);	
		return MBT_FALSE;
	}

	if((SearchInfo->UUIDList.NumUUID128s > MBT_JSR82_MAX_128_UUID_NUM ) ||
		(SearchInfo->UUIDList.NumUUIDs > MBT_JSR82_MAX_SEARCH_UUID_NUM ))
	{
		MBT_WARN(" exceed max of uuidNum uuidnum:%d, 128:%d", SearchInfo->UUIDList.NumUUIDs,SearchInfo->UUIDList.NumUUID128s,0);
		return MBT_FALSE;
	}
	
	memcpy((uint8*)svcSearchBdAddr.bd_addr_bytes, (uint*)RemoteBDAddr, MBT_BDADDR_LEN);
	bSearchPending = MBT_TRUE;	//��� ������Ű���� Ȯ���� �� ��. 
	
	/*
	memset(&bt_db_sd_svc_search_addr, 0x0, sizeof(BTBDAddr));
	memcpy(&bt_db_sd_svc_search_addr, pBDAddr, sizeof(BTBDAddr));  
	*/
	//128 uuid
	uuid_list.num_uuid128 = SearchInfo->UUIDList.NumUUID128s;
	for ( i=0; i<SearchInfo->UUIDList.NumUUID128s && i<MBT_JSR82_MAX_128_UUID_NUM;i++)
	{
		memcpy((void*)uuid_list.uuid128[i].uuid_byte, (void*)SearchInfo->UUIDList.UUID128[i].UUIDByte, sizeof(uuid_list.uuid128[i].uuid_byte));
	}

	// ����� 16 �̾� ��ü�� ..... 
	uuid_list.num_uuid = SearchInfo->UUIDList.NumUUIDs;
	for ( i=0;i<SearchInfo->UUIDList.NumUUIDs && i<MBT_JSR82_MAX_SEARCH_UUID_NUM; i++)
	{
		uuid_list.uuid[i] = SearchInfo->UUIDList.UUID[i];
	}
	MBT_PI("num of NumUUID128s : %d, num of NumUUIDs:%d", uuid_list.num_uuid128, uuid_list.num_uuid , 0);
//yucha 2008/05/07 start: separate service search from attribute search
	memset((void*)&attriInfo, 0x00, sizeof(attriInfo));
	memset((void*)&svcHandle, 0x00, sizeof(svcHandle));

	//attr_id_list.num_attr_id = SearchInfo->NumAttrIDs;
	for (i=0;i<SearchInfo->NumAttrIDs && i<MBT_JSR82_MAX_ATTR_ID_NUM;i++)
	{
		MBT_PI("SearchInfo->AttrVal[i]:0x%x, i:%d", SearchInfo->AttrVal[i], i,0);
		attriInfo.attriValue[i] = SearchInfo->AttrVal[i];
		attriInfo.totAttriCnt++;
	}
	attriInfo.curAttriIndex = 0;
	MBT_PI("num of attribute : %d, curAttriIndex:%d", attriInfo.totAttriCnt, attriInfo.curAttriIndex, 0);
 	memcpy((void*)&svcSearchBdAddr, (void*)&svcSearchBdAddr, sizeof(svcSearchBdAddr));
	svcSearchState = BTSD_SVC_SEARCH;
	stat = bt_cmd_sd_send_service_search_req(mbt_jsr82_app_id, &svcSearchBdAddr, &uuid_list, BT_SD_DEFAULT_MAX_ATTR_BYTE_COUNT);
//yucha 2008/05/07 end

	if(mbt_jsr82_CheckCmdStatus(stat) == MBT_FALSE)
	{
		T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

		bSearchPending = MBT_FALSE;
		bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, RemoteBDAddr);
		mbt_postevent(MBTEVT_JSR82_SVC_DISCOVERY_FAIL,0);
		return MBT_FALSE;
	}
	else
	{
		return MBT_TRUE;
	}
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_svc_discovery_cancel(MBT_UINT TransID)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_BOOL mbt_jsr82_svc_discovery_cancel(MBT_UINT TransID)
{
	bt_cmd_status_type stat;
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	//yucha 008/04/30 nokia
	bSearchPending = MBT_FALSE;
	svcSearchState = BTSD_SVC_IDLE;
	//BT_EV_RM_CONNECTED_ACL ���� ����� acl�� handle�� �����Ͽ���. 
	MBT_PI("Disconnecting JSR82 ACL Link jsr82Handle:0x%x, acl_app_id:%d,mbt_jsr82_app_id:%d ", jsr82Handle,acl_app_id,mbt_jsr82_app_id);
	if(jsr82Handle != 0xff)
		stat = bt_cmd_rm_disconnect_acl(acl_app_id, jsr82Handle, BT_RMDR_USER_ENDED);
	rex_sleep(200);
	if(mbt_jsr82_CheckCmdStatus(stat))
	{
		bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, svcSearchBdAddr.bd_addr_bytes);
		mbt_postevent(MBTEVT_JSR82_SVC_DISCOVERY_CANCEL_SUCCESS, 0);
		return MBT_TRUE;
	}
	else
	{
		bdcpy(sdcJSR82Status->EvInfo[0].BDAddr, svcSearchBdAddr.bd_addr_bytes);
		mbt_postevent(MBTEVT_JSR82_SVC_DISCOVERY_CANCEL_FAIL, 0);
		return MBT_FALSE;
	}
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_get_service_result(MBT_UINT TransID, MBT_INT ReadNum)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_BOOL mbt_jsr82_get_service_result(MBT_UINT TransID, MBT_INT ReadNum)
{
	//TransID�� ������ �ʴ´�. �� ��������� Ȯ�� �ʿ�. 
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	
	// 2-1. �� ���� record�� encoding �ϱ� .
	sdcJSR82Status->AttrValLen = mbt_jsr82_encodeServiceRecordInfo(&searchedSvcRec[ReadNum], sdcJSR82Status->AttrSet, sdcJSR82Status->AttrVals, (MBT_INT*)&sdcJSR82Status->AttrIdNum);

	MBT_PI("[ServiceRecord] AttrIDNum = %d, AttrValLen = %d  ", sdcJSR82Status->AttrIdNum ,sdcJSR82Status->AttrValLen ,0);	

	return ((sdcJSR82Status->AttrValLen == 0)? MBT_FALSE: MBT_TRUE);
}

/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_create_record(T_MBT_JSR82_SD_RECORD* CreateInfo)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
//MBT_VOID mbt_jsr82_create_record(T_MBT_JSR82_SD_RECORD* CreateInfo)
MBT_VOID mbt_jsr82_create_record(MBT_UINT SvcHandle,T_MBT_JSR82_SD_RECORD* CreateInfo)
{
	bt_cmd_status_type stat = BT_CS_GN_CMD_Q_FULL;
	System_BT_L2obj_t *pL2Me = NULL;
	System_BT_SPPobj_t*pRCMe = NULL;
	extern uint8 pL2_OpenHandle, pRC_OpenHandle;
	uint16 psm = BT_L2_PSM_INVALID;
	uint8 scn = 0;

	pL2Me = System_BT_L2_FindMebyHandle(pL2_OpenHandle);
	if (pL2Me != NULL) 
	{
		psm = pL2Me->sConfigInfo.psm;
		scn = 0;
	}

	pRCMe = System_BT_SPP_FindMebyHandle( pRC_OpenHandle );
	if (pRCMe != NULL)
	{
		psm = BT_L2_PSM_INVALID;
		scn = pRCMe->scn;
	}

	MBT_PI( __func__" psm %d scn %d", psm, scn, 0 );
	
	//unregister�� ���ؼ� ������ѵ�. 
	// �̱���� QBT ���� ������� ����. �� ������ SPP open�ÿ� �����Ǵ� service record�� ����ϱ� ������
	//Ȯ���� ���ؼ��� service handle�� uuid�� mapping ��ų �ʿ�. 
	createdSvcRecUUID = CreateInfo->UUID;
	if (pL2Me != NULL) 
	{
		int i;
		
		pL2Me->uuid = (uint16)CreateInfo->UUID;		
		for ( i = 0; i < 16; i++ )
		{
			pL2Me->uuid128.uuid_byte[i] = CreateInfo->UUID128.UUIDByte[i];
			MBT_PI( __func__"Copy: %2x => uuid128: %2x ", CreateInfo->UUID128.UUIDByte[i], pL2Me->uuid128.uuid_byte[i], 0);
		}		
		
	}

	if (pRCMe != NULL) 
	{
		int i;
		
		pRCMe->uuid = (uint16)CreateInfo->UUID;		
		for ( i = 0; i < 16; i++ )
		{
			pRCMe->uuid128.uuid_byte[i] = CreateInfo->UUID128.UUIDByte[i];
			MBT_PI( __func__"Copy: %2x => uuid128: %2x ", CreateInfo->UUID128.UUIDByte[i], pRCMe->uuid128.uuid_byte[i], 0);
		}		
		
	}
	gSvcHandle = SvcHandle;
	
	if(CreateInfo->SvcName!= MBT_NULL)
		MBT_PI( __func__"SvcName: %s ", CreateInfo->SvcName,0,0 );
	
	if(CreateInfo->bCustomSvc != TRUE && CreateInfo->UUID != MBT_NULL)
	{
		stat = bt_cmd_sd_register_serv_ext(mbt_jsr82_app_id, CreateInfo->UUID, L2CAP_REGISTER_VERSION, scn, psm, TRUE, CreateInfo->SvcName);
	}
	else 
	{
		bt_sd_uuid_list_type uuidList;
		int i;
		
		uuidList.num_uuid = 0;
		if (CreateInfo->UUID != MBT_NULL)
		{
			uuidList.num_uuid = 1;
			uuidList.uuid[0] = CreateInfo->UUID; // For Serial Port Profile
		}
		
		uuidList.num_uuid128 = 1;

	    	for ( i = 0; i < 16; i++ )
		{
	      		uuidList.uuid128[0].uuid_byte[i] = CreateInfo->UUID128.UUIDByte[i];
			MBT_PI( __func__"CreateInfo: %2x => uuid128: %2x ", CreateInfo->UUID128.UUIDByte[i],uuidList.uuid128[0].uuid_byte[i],0 );
	    	}
		stat = bt_cmd_sd_register_custom_service_ext (mbt_jsr82_app_id, &uuidList, L2CAP_REGISTER_VERSION, scn, psm, TRUE, CreateInfo->SvcName);
	}

	/*
	if(mbt_jsr82_CheckCmdStatus(stat))
	{
		mbt_postevent(MBTEVT_JSR82_SD_RECORD_CREATE_SUCCESS, 0);
	}
	else
	{
		mbt_postevent(MBTEVT_JSR82_SD_RECORD_CREATE_FAIL, 0);
	}
	*/
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_update_record(MBT_UINT SvcHandle, T_MBT_JSR82_UPDATE_SD* UpdateInfo)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_update_record(MBT_UINT SvcHandle, T_MBT_JSR82_SD_RECORD* UpdateInfo)
{
	//bt_cmd_status_type stat;

	//bt_sd_srv_rec_type QcmRec;
	//int j;
	int i;
	int index;
	//int int_index;
	//uint8				     null_uuid_128[16] = BT_SD_NULL_UUID128;	//chosw 2006-12-11
	bt_sd_srv_rec_type*       pCoreSvcRec;
	bt_sd_srv_attr_rec_type*  pCoreSvcAttr;
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	
	MBT_PI( __func__"##########################", 0, 0, 0);
	MBT_PI(__func__" >>> uNumAttr[0x%x] SrvRechandle[0x%04x]", UpdateInfo->NumAttr, UpdateInfo->SrvRechandle, 0);
	for(i=0;i<UpdateInfo->NumAttr;i++)
  		MBT_PI(__func__" >>> UpdateInfo->Attr[%d] : 0x%x", i,UpdateInfo->Attr[i].AttrID, 0);

//fnclamp
	if(sdcJSR82Status->bEnabled)
	{
		pCoreSvcRec = bt_sd_find_service_record_by_handle(UpdateInfo->SrvRechandle);

		if(pCoreSvcRec != 0)
		{
			for ( i = 0; i < pCoreSvcRec->num_srv_attr; i++ )
			{

#if 0				
				for(index=0; index< UpdateInfo->NumAttr; index++)
				{
					if ( pCoreSvcRec->srv_attr[i].attr_id == UpdateInfo->Attr[index].AttrID)
					{
						if( pCoreSvcRec->srv_attr[i].attr_id != NULL )
							MBT_PI(" [fnclamp] update attr-it:0x%04x",  pCoreSvcRec->srv_attr[i].attr_id,0, 0);
						break;
					}
				}
				if(index ==UpdateInfo->NumAttr)
				{
					bt_sd_srv_attr_rec_type*  pCoreSvcAttr;

					if( pCoreSvcRec->srv_attr[i].attr_id != NULL )
						MBT_PI(" [fnclamp] delete attr-it:0x%04x",  pCoreSvcRec->srv_attr[i].attr_id,0, 0);
					//memset( &pCoreSvcRec->srv_attr[i], 0x0, sizeof( bt_sd_srv_attr_rec_type ));
					if ( ( pCoreSvcAttr = bt_sd_find_service_attribute(pCoreSvcRec, pCoreSvcRec->srv_attr[i].attr_id ) ) != 0 )			
						bt_sd_service_record_init_attribute(pCoreSvcAttr, pCoreSvcAttr->attr_id,pCoreSvcAttr->attr_type );
				}
#else
				pCoreSvcAttr = bt_sd_find_service_attribute(pCoreSvcRec, pCoreSvcRec->srv_attr[i].attr_id ); 
				bt_sd_service_record_init_attribute(pCoreSvcAttr, pCoreSvcAttr->attr_id,pCoreSvcAttr->attr_type );
#endif				
			}
		}
		else
		{
			mbt_postevent(MBTEVT_JSR82_SD_RECORD_UPDATE_FAIL, 0);
			return MBT_FALSE;
		}
	}
//fnclam end
	
	//for(index=0; index<LgbxRec->attr_num; index++)
	for(index=0; index< UpdateInfo->NumAttr; index++)
	{
		MBT_PI("           >>> AttrID  [0x%04x]", UpdateInfo->Attr[index].AttrID, 0,0);
		mbt_jsr82_updateServiceAttribute(UpdateInfo->SrvRechandle, &(UpdateInfo->Attr[index]));
		//mbt_jsr82_setUUID128(updateInfo->SrvRechandle, &(updateInfo->Attr[index].Value.UUID128)); //���ʿ� Attrib����ü�� UUID 128 �߰��Ǿ.
	}
	
	
	MBT_PI( __func__" LGBX_JSDP_StackUpdateRecord ", 0, 0, 0);
	MBT_PI( __func__" >>>> Record Handle: 0x%x",UpdateInfo->SrvRechandle, 0, 0);

	index = mbt_jsr82_getEmptyIdx();
	if (index != -1) 
	{
		sdcJSR82Status->EvInfo[index].Used = TRUE;
		sdcJSR82Status->EvInfo[index].Val.SvcHandle = UpdateInfo->SrvRechandle;
	}

	mbt_postevent(MBTEVT_JSR82_SD_RECORD_UPDATE_SUCCESS, index);

	return MBT_TRUE;
#if 0
//yucha  ���� 2008/01/24
	if(mbt_jsr82_CheckCmdStatus(stat))
	{
		//mbt_postevent(MBTEVT_JSR82_SD_RECORD_UPDATE_SUCCESS, 0);
		return MBT_TRUE;
	}
	else
	{
		//mbt_postevent(MBTEVT_JSR82_SD_RECORD_UPDATE_FAIL, 0);
		return MBT_FALSE;
	}
#endif
}


/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_remove_record(MBT_UINT SvcHandle)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_VOID mbt_jsr82_remove_record(MBT_UINT SvcHandle)
{
	bt_cmd_status_type stat;
	//create�ÿ� �̸� ������ѵ�. 
	stat = bt_cmd_sd_unregister_service(mbt_jsr82_app_id, createdSvcRecUUID);
	if(mbt_jsr82_CheckCmdStatus(stat))
		mbt_postevent(MBTEVT_JSR82_SD_RECORD_REMOVE_SUCCESS, 0);
	else
		mbt_postevent(MBTEVT_JSR82_SD_RECORD_REMOVE_FAIL, 0);
		
}

/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_delete_attribute(MBT_UINT SvcHandle, MBT_SHORT AttrID)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_VOID mbt_jsr82_delete_attribute(MBT_UINT SvcHandle, MBT_SHORT AttrID)
{
	//no needs
	//mbt_jsr82_update_record�� �����ؼ� �ۼ� ������. 
}

MBT_BOOL mbt_jsr82_populate_record(MBT_UINT svc_rec_Handle, T_MBT_BDADDR RemoteBDAddr, MBT_UINT *Attr,MBT_UINT AttrLength)
{ 
#if 0
	MBT_UINT TransID = svc_rec_Handle;
	UINT8 i;
	BOOLEAN bAddServiceHandle = FALSE;
	
	APPL_TRACE_ERROR1("-- mbt_jsr82_populate_record: attID=0x%x", AttrLength);
	APPL_TRACE_ERROR1("        record handle  : 0x%x", svc_rec_Handle);

	if(p_mbt_jsr82_if_cb == NULL)
	{
		APPL_TRACE_ERROR0("mbt_jsr82_populate_record : Not ready JAVA");
		return MBT_FALSE;
	}

	for(i = 0; i < AttrLength; i++)
	{
		if(*(Attr + i) == 0x00)
			bAddServiceHandle = TRUE;

		p_mbt_jsr82_if_cb->populate.SearchInfo.AttrVal[i] = *(Attr + i);
	}

	if(!bAddServiceHandle)
	{
		p_mbt_jsr82_if_cb->populate.SearchInfo.AttrVal[i] = 0x00;
		AttrLength++;
	}

	p_mbt_jsr82_if_cb->populate.bSvcUpdate = TRUE;	/* start SVC update */
	p_mbt_jsr82_if_cb->populate.SearchInfo.NumAttrIDs = AttrLength;
	bdcpy(p_mbt_jsr82_if_cb->populate.RemoteBDAddr, RemoteBDAddr);
	p_mbt_jsr82_if_cb->populate.svc_rec_Handle = svc_rec_Handle;

	// �˻� ������ �ֱ��� discovery �������� �Ѵ�....
	//p_mbt_jsr82_if_cb->populate.SearchInfo.UUIDList.NumUUIDs = 1;
	//p_mbt_jsr82_if_cb->populate.SearchInfo.UUIDList.UUID[0] = UUID_PROTOCOL_L2CAP;
	
	return mbt_jsr82_svc_discovery(RemoteBDAddr, &p_mbt_jsr82_if_cb->populate.SearchInfo, TransID);
	#endif
	return MBT_FALSE;
}

MBT_VOID mbt_jsr82_copy_service_record_from_sd(
	T_MBT_JSR82_SD_RECORD* pDestRec,
	bt_sd_srv_rec_type* pSrcRec
)
{
	bt_sd_srv_attr_rec_type*  pAttr;
	uint8 i,j,k,l,m;
	MBT_PI( __func__"##########################", 0, 0, 0);
	MBT_PI( "-------------------------------------------", 0, 0, 0);
	MBT_PI( __func__" pSrcRec->srv_uuid : %x, pSrcRec->num_srv_attr : %x, pSrcRec->is_custom_srv:%d", pSrcRec->srv_uuid, pSrcRec->num_srv_attr, pSrcRec->is_custom_srv);
	MBT_PI( "-------------------------------------------", 0, 0, 0);

	if(pSrcRec->is_custom_srv)
	{
		pDestRec->bCustomSvc = MBT_TRUE;
		memcpy( (void*)&pDestRec->UUID128, (void*)&pSrcRec->srv_uuid128 , sizeof(T_MBT_UUID128));
	}
	else
	{
		pDestRec->bCustomSvc = MBT_FALSE;
		pDestRec->UUID = pSrcRec->srv_uuid; 
	}

	pDestRec->SrvRechandle = pSrcRec->srv_rec_id;

	//MBT_PI( __func__"#####  BEFORE  pDestRec->NumAttr:%d, pSrcRec->num_srv_attr:%d", pDestRec->NumAttr, pSrcRec->num_srv_attr, 0);
	pDestRec->NumAttr += pSrcRec->num_srv_attr;
	MBT_PI( __func__"#### pDestRec->NumAttr:%d, pSrcRec->num_srv_attr:%d, serviceRecCurIndex:%d", pDestRec->NumAttr, pSrcRec->num_srv_attr, serviceRecCurIndex);
	
	bt_sd_srv_attr_iter.init(pSrcRec, BT_SD_ITER_ALL);
  
  	for(pAttr = (bt_sd_srv_attr_rec_type*) bt_sd_srv_attr_iter.first(), j = 0;
        pAttr != 0 && (j < MBT_JSR82_MAX_ATTR_ID_NUM);
        pAttr = (bt_sd_srv_attr_rec_type*) bt_sd_srv_attr_iter.next(), j++ )
  	{
		pDestRec->Attr[j].AttrID  = pAttr->attr_id;
		pDestRec->Attr[j].AttrType = (T_MBT_JSR82_SD_ATTR)pAttr->attr_type;

		MBT_PI("[copy_service_record_from_sd] AttrID : %04x  AttrType : 0x%x\n", pAttr->attr_id, pAttr->attr_type,0);	
		switch (pAttr->attr_type)
		{
			case MBT_JSR82_SD_ATTR_UUID_LIST:
				pDestRec->Attr[j].Value.UUIDList.NumUUID128s = pAttr->attr_value.uuid_list.num_uuid128;

				for ( k=0; k<pAttr->attr_value.uuid_list.num_uuid128 && k<MBT_JSR82_MAX_128_UUID_NUM; k++ )
				{
					memcpy(
					(void*)&pDestRec->Attr[j].Value.UUIDList.UUID128[k],
					(void*)&pAttr->attr_value.uuid_list.uuid128[k],
					sizeof(T_MBT_UUID128));
				}

				pDestRec->Attr[j].Value.UUIDList.NumUUIDs = pAttr->attr_value.uuid_list.num_uuid;
				for ( k=0; k<pAttr->attr_value.uuid_list.num_uuid && k<MBT_JSR82_MAX_SEARCH_UUID_NUM;k++)
				{
					pDestRec->Attr[j].Value.UUIDList.UUID[k] = pAttr->attr_value.uuid_list.uuid[k];
				}
				
				break;
			case MBT_JSR82_SD_ATTR_PROTO_DESC_LIST:
				if (pAttr->attr_id == MBT_JSR82_ATTR_ID_BLUETOOTH_PROFILE_DESCRIPTOR_LIST)
				{
					uint8 idx = 0;
					
					for (k=0,idx=0; k<pAttr->attr_value.proto_desc_list.num_proto_desc && k<MBT_JSR82_MAX_PROTO_DESC_NUM; k++) 
					{
						bt_sd_proto_desc_type *pSrcPD = &pAttr->attr_value.proto_desc_list.proto_desc[k];

						if (pSrcPD->is_uuid128 == FALSE)
						{
							pDestRec->Attr[j].Value.BTProfileList.ProfileList[idx].UUID = pSrcPD->uuid;
							pDestRec->Attr[j].Value.BTProfileList.ProfileList[idx].Version = L2CAP_REGISTER_VERSION;
							idx++;
							MBT_PI( "[copy_service_record_from_sd] pDestRec.UUID:0x%x, pDestRec.Version:0x%x", pSrcPD->uuid, L2CAP_REGISTER_VERSION, 0);					
						}
					}
					pDestRec->Attr[j].Value.BTProfileList.NumProfile = idx;
					MBT_PI( "[copy_service_record_from_sd]          pDestRec->NumProfiles:%d", idx, 0, 0);

				} 
				else if (pAttr->attr_id == MBT_JSR82_ATTR_ID_PROTOCOL_DESCRIPTOR_LIST)
				{
					pDestRec->Attr[j].Value.ProtoDescList.NumProtoDes = pAttr->attr_value.proto_desc_list.num_proto_desc;
					for(k=0; k<pAttr->attr_value.proto_desc_list.num_proto_desc && k<MBT_JSR82_MAX_PROTO_DESC_NUM; k++)
					{					
						uint8 idx;
						T_MBT_JSR82_PROTOCOL_DESC* pProtoDesc = &pDestRec->Attr[j].Value.ProtoDescList.ProtoDesc[k];
						bt_sd_proto_desc_type *pSrcPD = &pAttr->attr_value.proto_desc_list.proto_desc[k];

						if(pSrcPD->is_uuid128 )
						{
							pProtoDesc->BUUID128 = MBT_TRUE;
							memcpy((void*)&pProtoDesc->UUID128, (void*)&pSrcPD->uuid128,  sizeof(T_MBT_UUID128));
						}
						else
						{
							pProtoDesc->BUUID128 = MBT_FALSE;
							pProtoDesc->UUID    = pSrcPD->uuid;
						}
						pProtoDesc->NumParam = pSrcPD->num_param;
						//param ������ Ȯ�� �ǳ� ��
						//memcpy(pProtoDesc->Param, pSrcPD->param, sizeof(pProtoDesc->Param));
						for(idx=0; idx<pProtoDesc->NumParam;idx++)
						{
							pProtoDesc->Param[idx].Size = pSrcPD->param[idx].size;
							pProtoDesc->Param[idx].Value = pSrcPD->param[idx].value;
						}
						MBT_PI( "[copy_service_record_from_sd]          pProtoDesc->NumParam:%d", pProtoDesc->NumParam, 0, 0);
						MBT_PI( "[copy_service_record_from_sd] pProtoDesc.Value:%d, pSrcPD.Value:%d", pProtoDesc->Param[0].Value, pSrcPD->param[0].value, 0);

					}
				}
				break;

			// ����ü �����ϰ� ���� �θ��� ���� 
			case MBT_JSR82_SD_ATTR_ADDL_PROTO_DESC_LISTS:
				pDestRec->Attr[j].Value.AddProtoDescList.NumProtoListDes = 0;
				for(k=0; k<MBT_JSR82_MAX_NUM_OF_ADD_PROTO_LIST_NUM; k++)
				{
					T_MBT_JSR82_PROTOCOL_DESC_LIST* pDestPDL = &pDestRec->Attr[j].Value.AddProtoDescList.ProtoDescList[k];
					bt_sd_proto_desc_list_type* pSrcPDL = &pAttr->attr_value.add_proto_desc_lists[k];	

					pDestRec->Attr[j].Value.AddProtoDescList.NumProtoListDes++;

					pDestPDL->NumProtoDes = pSrcPDL->num_proto_desc;
				
					for (l = 0; l < pSrcPDL->num_proto_desc && l < MBT_JSR82_MAX_PROTO_DESC_NUM; l++ )
					{
						uint8 idx;
						T_MBT_JSR82_PROTOCOL_DESC* pDestPD = &pDestPDL->ProtoDesc[l];
						bt_sd_proto_desc_type* pSrcPD = &pSrcPDL->proto_desc[l];
						if(pSrcPD->is_uuid128 )
						{
							pDestPD->BUUID128 = MBT_TRUE;
							memcpy((void*)&pDestPD->UUID128, (void*)&pSrcPD->uuid128, sizeof(T_MBT_UUID128));
						}
						else
						{
							pDestPD->BUUID128 = MBT_FALSE;
							pDestPD->UUID    = pSrcPD->uuid;
						}
						pDestPD->NumParam = pSrcPD->num_param;
					
						//memcpy( (void*)pDestPD->Param, (void*)pSrcPD->param, sizeof(pDestPD->Param));
						for(idx = 0; idx<pDestPD->NumParam; idx++)
						{
							pDestPD->Param[idx].Size = pSrcPD->param[idx].size;
							pDestPD->Param[idx].Value = pSrcPD->param[idx].value;
						}

					}
				}
				break;

			// �ܼ� ����ü ������. 
			case MBT_JSR82_SD_ATTR_LANG_BASE_ATTR_ID_LIST:
				pDestRec->Attr[j].Value.LangBaseAttrList =
					*((T_MBT_JSR82_LANG_BASE_ATTR_LIST*)&pAttr->attr_value.lang_base_attr_id_list);
				break;

			case MBT_JSR82_SD_ATTR_UINT_LIST:
				pDestRec->Attr[j].Value.UintList.NumVal = MAX(pAttr->attr_value.uint_list.num_val, MBT_JSR82_MAX_UINT);

				for ( i=0; i<pDestRec->Attr[j].Value.UintList.NumVal; i++)
				{
					pDestRec->Attr[j].Value.UintList.Val[i] = pAttr->attr_value.uint_list.val[i];
				}
				break;

			case MBT_JSR82_SD_ATTR_STRING:
				MBT_PI( __func__"          [BT_SD_ATTR_TYPE_STRING]",0,0,0);
				memset( pDestRec->Attr[j].Value.Str,0,MBT_JSR82_MAX_STRING_LEN);
				memcpy( pDestRec->Attr[j].Value.Str, pAttr->attr_value.str,MBT_JSR82_MAX_STRING_LEN);
				break;
			
			case MBT_JSR82_SD_ATTR_UINT8:
			case MBT_JSR82_SD_ATTR_UINT16:
			case MBT_JSR82_SD_ATTR_UINT32:
			case MBT_JSR82_SD_ATTR_UINT64:
				pDestRec->Attr[j].Value.PrimitiveValue = pAttr->attr_value.primitive_value;
				break;
			case MBT_JSR82_SD_ATTR_BOOL:
				pDestRec->Attr[j].Value.BFlag = pAttr->attr_value.bool_flag;
				break;
			
			case MBT_JSR82_SD_ATTR_UNKNOWN:
				MBT_PI( "[copy_service_record_from_sd]          MBT_JSR82_SD_ATTR_UNKNOWN",0,0,0);
			case MBT_JSR82_SD_ATTR_HID_DESC_LIST:
				pDestRec->Attr[j].Value.HidDescList.NumHidDesc = pAttr->attr_value.hid_desc_list.num_hid_class_desc;
				MBT_PI( "[copy_service_record_from_sd]          NumHidDesc : %d ",pDestRec->Attr[j].Value.HidDescList.NumHidDesc,0,0);
				for ( k=0; k<pAttr->attr_value.hid_desc_list.num_hid_class_desc && k<MBT_JSR82_MAX_HID_DESC_NUM; k++)
				{
					T_MBT_JSR82_HID_DESC* pHIDClassDesc = &pDestRec->Attr[j].Value.HidDescList.HidDesc[k];
					bt_sd_hid_class_desc_type* pSrcHIDClassDesc = &pAttr->attr_value.hid_desc_list.hid_class_desc[k];

					// attr-value�� header
					pHIDClassDesc->Header.Type = pSrcHIDClassDesc->header.type;
					pHIDClassDesc->Header.Size_index= pSrcHIDClassDesc->header.size_index;
					pHIDClassDesc->Header.Attr_value_len= pSrcHIDClassDesc->header.attr_value_len;
					MBT_PI( "[copy_service_record_from_sd]          Header.Type: %d ",pHIDClassDesc->Header.Type,0,0);
					MBT_PI( "[copy_service_record_from_sd]          Header.Size_index : %d ",pHIDClassDesc->Header.Size_index,0,0);
					MBT_PI( "[copy_service_record_from_sd]          Header.Attr_value_len : %d ",pHIDClassDesc->Header.Attr_value_len,0,0);
				
					pHIDClassDesc->Value = pSrcHIDClassDesc->val;
					pHIDClassDesc->Length = pSrcHIDClassDesc->len;
	
					memcpy( pHIDClassDesc->Str, pSrcHIDClassDesc->str, pSrcHIDClassDesc->len);
				
					for(m=0;m<pDestRec->Attr[j].Value.HidDescList.HidDesc[k].Length;m++)
						MBT_PI( "[copy_service_record_from_sd]             pHIDClassDesc->Str : %c ",pDestRec->Attr[j].Value.HidDescList.HidDesc[k].Str[m],0,0);
				}
				break;

			case MBT_JSR82_SD_ATTR_UUID128:
				memcpy((void*)&pDestRec->Attr[j].Value.UUID128, (void*)&pAttr->attr_value.uuid128, sizeof(T_MBT_UUID128));
				break;

			default:
				break;
    		}
  	} /* foreach service attribute */

	return;
}

MBT_BOOL mbt_jsr82_read_record(MBT_UINT SvcHandle, MBT_BYTE* Data, MBT_UINT* DataLength)
{ 
	bt_sd_srv_rec_type *svc_rec_ptr = NULL;
	T_MBT_JSR82_SD_RECORD jsr82_sd_rec_st; 
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);

	MBT_PI( __func__" Service Handle 0x%x", SvcHandle, 0, 0);
	svc_rec_ptr = bt_sd_find_service_record_by_handle(SvcHandle);
	if (svc_rec_ptr != NULL) 
	{
		memset(&jsr82_sd_rec_st, 0x00, sizeof(T_MBT_JSR82_SD_RECORD));
		mbt_jsr82_copy_service_record_from_sd(&jsr82_sd_rec_st, svc_rec_ptr);
		sdcJSR82Status->AttrValLen = mbt_jsr82_encodeServiceRecordInfo(&jsr82_sd_rec_st, (MBT_SHORT*)sdcJSR82Status->AttrSet, (MBT_BYTE**)sdcJSR82Status->AttrVals, (MBT_INT*)&sdcJSR82Status->AttrIdNum);
	}
	else 
	{
		MBT_PI( __func__" Cannot find the service record from SD DB", 0, 0, 0);
		return MBT_FALSE;
	}
	
	return MBT_TRUE;
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_l2cap_open_server(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_l2cap_open_server(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config)
{
	//MBT_INT event_index;
	BTL2ConfigInfo info;
	extern uint8 pRC_OpenHandle;
	extern uint8 pL2_OpenHandle;
	
	//T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	
	if(System_BT_L2_Init(Handle) == MBT_FALSE)
	{
		MBT_WARN("L2_Init ERROR",0,0,0);
		mbt_postevent(MBTEVT_JSR82_L2CAP_OPEN_FAIL, 0);
		return PDK_L2_ERROR;
	}
	
	mbt_gap_allow_role_switch(MBT_NULL);	

	info.psm = Config->PSM;
	info.cid = Config->CId;
	info.in_flush_to = Config->InFlushTO;
	info.in_mtu = 	Config->InMTU;
	info.out_mtu = 	Config->OutMTU;
	info.in_qos =	Config->InQoS;
	info.token_rate = Config->TokenRate;
	info.token_bucket_size = Config->TokenBucketSize;
	info.peak_bandwidth = Config->PeakBandwidth;
	info.latency = 		Config->Latency;
	info.delay_variation = Config->DelayVariation;

	pRC_OpenHandle = 0xff;
	pL2_OpenHandle = 0xff;
	return System_BT_L2_Enable(Handle, &info );
}

/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_l2cap_close_server(MBT_BYTE Handle)
*	Description		: Server�� ����. ���� LGOEM_L2_DISCONNECT ������ Server/Client�� ����
					  ��� ���� ������ �ϵ��� �Ǿ��־ �и���.
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_l2cap_close_server(MBT_BYTE Handle)
{
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	return System_BT_L2_Disconnect(Handle);
}

/*=========================================================================== 
*	Prototype		: MBT_INT  mbt_jsr82_l2cap_get_svc_handle(MBT_VOID)
*	Description		: QBT�� ������ �ϳ��� API�� L2CAP/RFCOMM ��� get_svc_handle�� �ؿ�.
					 ���� �������� ä���ָ� ��.
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT  mbt_jsr82_l2cap_get_svc_handle(MBT_VOID)
{
	return gJSR82_Handle;
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_l2cap_accept(MBT_BYTE Handle, MBT_BYTE PeerHandle)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_l2cap_accept(MBT_BYTE Handle, MBT_BYTE PeerHandle)
{
	MBT_PI( __func__"##############Handle:%x,PeerHandle:%x ", Handle, PeerHandle, 0);
	return System_BT_L2_Accept(Handle, PeerHandle);
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_l2cap_open_client(MBT_BYTE Handle)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_BOOL mbt_jsr82_l2cap_open_client(MBT_BYTE Handle)
{
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	if(System_BT_L2_Init(Handle) == MBT_FALSE)
	{
		MBT_WARN("L2_Init ERROR",0,0,0);
		return MBT_FALSE;
	}
	
	mbt_gap_allow_role_switch(MBT_NULL);
	return MBT_TRUE;
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_l2cap_set_param(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_BOOL mbt_jsr82_l2cap_set_param(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config)
{
	BTL2ConfigInfo info;
	
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	info.psm = Config->PSM;
	info.cid = Config->CId;
	info.in_flush_to = Config->InFlushTO;
	info.in_mtu = 	Config->InMTU;
	info.out_mtu = 	Config->OutMTU;
	info.in_qos =	Config->InQoS;
	info.token_rate = Config->TokenRate;
	info.token_bucket_size = Config->TokenBucketSize;
	info.peak_bandwidth = Config->PeakBandwidth;
	info.latency = 		Config->Latency;
	info.delay_variation = Config->DelayVariation;

	return System_BT_L2_SetParams(Handle, info.psm, &info);
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_l2cap_connect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, MBT_INT PSM)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_l2cap_connect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, MBT_INT PSM)
{
	BTBDAddr addr;
	MBT_INT iRet;
	MBT_PI( __func__"##############Handle:%x, PSM:0x%x", Handle, PSM, 0);
	memcpy((uint8*)addr.uAddr, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);
	iRet = System_BT_L2_Connect(Handle, PSM, &addr);
	if(iRet == PDK_L2_ERR_NONE)
		iRet = MBT_TRUE;
	else
		iRet = MBT_FALSE;
	
	return iRet;
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_l2cap_disconnect(MBT_BYTE Handle)
*	Description		: Client�� ����. ���� LGOEM_L2_DISCONNECT ������ Server/Client�� ����
					  ��� ���� ������ �ϵ��� �Ǿ��־ �и���.
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_l2cap_disconnect(MBT_BYTE Handle)
{
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	return System_BT_L2_Disconnect(Handle);
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_l2cap_write(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
*	Description		: Handle : Client PeerHandle
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_l2cap_write(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
{
	MBT_INT ret_state;
	MBT_PI( __func__"##############Handle:%x, Length:%x", Handle, Length, 0);
	ret_state = System_BT_L2_Write(Handle, (const byte*)Buffer, Length);

	if(ret_state == PDK_L2_ERROR)
	{
		ret_state = MBT_FALSE;
		mbt_postevent(MBTEVT_JSR82_L2CAP_WRITE_FAIL, 0);
	}
	else if(ret_state == PDK_L2_WOULDBLOCK)
	{
		ret_state = MBT_TRUE;
		mbt_postevent(MBTEVT_JSR82_L2CAP_WRITE_FAIL, 0);
	}
	else
		ret_state = MBT_TRUE;
	
	return ret_state;
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_l2cap_read(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_l2cap_read(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
{	
	MBT_PI( __func__"##############Handle:%x, Length:%x", Handle, Length, 0);
	return System_BT_L2_Read(Handle, Buffer, Length);
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_l2cap_get_ready(MBT_BYTE Handle)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
//MBT_BOOL mbt_jsr82_l2cap_get_ready(MBT_BYTE Handle)
MBT_BOOL mbt_jsr82_l2cap_get_ready(MBT_BYTE Handle,  MBT_UINT* DLENS)

{
	int32 readableLen = 0;

	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);

	readableLen = System_BT_L2_Readable(Handle);
	*DLENS = (MBT_UINT)readableLen;
	
	return (readableLen != 0)? TRUE : FALSE; 
}

/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_l2cap_release(MBT_VOID)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_VOID mbt_jsr82_l2cap_release(MBT_VOID)
{
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	memset((void*)sdcJSR82Status, 0x00, sizeof(T_MBT_JSR82_STATUS));
	
	System_BT_L2_ReleaseAll();
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_rfcomm_open_server(MBT_BYTE Handle, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_rfcomm_open_server(MBT_BYTE Handle, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config)
{
	BTSppOpenConfig sConfig;
	extern uint8 pRC_OpenHandle;
	extern uint8 pL2_OpenHandle;

	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	if(!System_BT_SPP_Init_jsr82(Handle))
	{
		MBT_WARN("SPP_Init ERROR",0,0,0);
		mbt_postevent(MBTEVT_JSR82_RFCOMM_OPEN_FAIL, 0);
		return MBT_FALSE;
	}
	
	mbt_gap_allow_role_switch(MBT_NULL);

	sConfig.bClientApp = MBT_FALSE;
	sConfig.pBDAddr = MBT_NULL;
	sConfig.pSvcName = Config->SvcName;
	sConfig.uSvcId = Config->SvcId;
	sConfig.uSvcVersion = Config->SvcVersion;
	sConfig.uMaxFrameSize = Config->MaxFrameSize;
	sConfig.uChannelNumber = Config->ChannelNumber;

	pRC_OpenHandle = 0xff;
	pL2_OpenHandle = 0xff;
	return System_BT_SPP_Open( Handle, &sConfig);
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_rfcomm_close_server(MBT_BYTE Handle)
*	Description		: Server�� ����. ���� LGOEM_SPP_CLOSE ������ Server/Client ���� ��θ�
					  ���� ������ �ϵ��� �Ǿ��־ �и���.
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_rfcomm_close_server(MBT_BYTE Handle)
{
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	return System_BT_SPP_Close(Handle);
}

/*=========================================================================== 
*	Prototype		: MBT_INT  mbt_jsr82_rfcomm_get_svc_handle(MBT_VOID)
*	Description		: QBT�� ������ �ϳ��� API�� L2CAP/RFCOMM ��� get_svc_handle�� �ؿ�.
					 ���� �������� ä���ָ� ��.
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT  mbt_jsr82_rfcomm_get_svc_handle(MBT_VOID)
{
	return gJSR82_Handle;
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_rfcomm_accept(MBT_BYTE Handle, MBT_BYTE PeerHandle)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_rfcomm_accept(MBT_BYTE Handle, MBT_BYTE PeerHandle)
{
	MBT_PI( __func__"##############Handle:%x, PeerHandle:%x", Handle, PeerHandle, 0);
	return System_BT_SPP_Accept(Handle, PeerHandle);
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_rfcomm_open_client(MBT_BYTE Handle)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_BOOL mbt_jsr82_rfcomm_open_client(MBT_BYTE Handle)
{
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	if(!System_BT_SPP_Init_jsr82(Handle))
	{
		MBT_WARN("RFCOMM_Init ERROR",0,0,0);
		return MBT_FALSE;
	}
	
	mbt_gap_allow_role_switch(MBT_NULL);
	
	return MBT_TRUE;
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_rfcomm_connect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config)
*	Description		: Client ����.
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_rfcomm_connect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config)
{
	BTSppOpenConfig sConfig;
	
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	sConfig.bClientApp = MBT_TRUE; 
	//memcpy((uint8*)sConfig.pBDAddr->uAddr, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);
	sConfig.pBDAddr = ( BTBDAddr* )RemoteBDAddr;	//yucha 2008/01/24
	sConfig.pSvcName = Config->SvcName;
	sConfig.uSvcId = Config->SvcId;
	sConfig.uSvcVersion = Config->SvcVersion;
	sConfig.uMaxFrameSize = Config->MaxFrameSize;
	sConfig.uChannelNumber = Config->ChannelNumber;

	return System_BT_SPP_Open( Handle, &sConfig);
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_rfcomm_disconnect(MBT_BYTE Handle)
*	Description		: Client�� ����. ���� LGOEM_SPP_CLOSE ������ Server/Client ���� ��θ�
					  ���� ������ �ϵ��� �Ǿ��־ �и���.
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_rfcomm_disconnect(MBT_BYTE Handle)
{
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);
	return System_BT_SPP_Close(Handle);
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_rfcomm_write(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_rfcomm_write(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
{
	MBT_INT iRet;
	MBT_PI( __func__"##############Handle:%x, Length:%x", Handle, Length, 0);
	iRet = System_BT_SPP_Write(Handle, Buffer, Length);
	if(iRet == BT_STREAM_ERROR)
		iRet = MBT_FALSE;
	else if(iRet == BT_STREAM_WOULDBLOCK)
		iRet = MBT_WOULDBLOCK;

	return iRet;
}

/*=========================================================================== 
*	Prototype		: MBT_INT mbt_jsr82_rfcomm_read(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_INT mbt_jsr82_rfcomm_read(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
{
	MBT_INT iRet;
	MBT_PI( __func__"##############Handle:%x, Length:%x", Handle, Length, 0);
	iRet = System_BT_SPP_Read(Handle, Buffer, Length);
	if(iRet == BT_STREAM_ERROR)
		iRet = MBT_FALSE;
	else if(iRet == BT_STREAM_WOULDBLOCK)
		iRet = MBT_WOULDBLOCK;

	return iRet;
}

/*=========================================================================== 
*	Prototype		: MBT_BOOL mbt_jsr82_rfcomm_get_ready(MBT_BYTE Handle) 
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
//MBT_BOOL mbt_jsr82_rfcomm_get_ready(MBT_BYTE Handle)
MBT_BOOL mbt_jsr82_rfcomm_get_ready(MBT_BYTE Handle, MBT_UINT* DLENS)

{
	int32 readableLen = 0;
	
	MBT_PI( __func__"##############Handle:%x", Handle, 0, 0);

	readableLen = System_BT_SPP_Readable(Handle);
	*DLENS = (MBT_UINT)readableLen;
	
	return (readableLen != 0)? TRUE : FALSE;
}

/*=========================================================================== 
*	Prototype		: MBT_VOID mbt_jsr82_rfcomm_release(MBT_VOID)
*	Description		: 
*	Return			:
*	Expected Event	:
===========================================================================*/
MBT_VOID mbt_jsr82_rfcomm_release(MBT_VOID)
{
	T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	memset((void*)sdcJSR82Status, 0x00, sizeof(T_MBT_JSR82_STATUS));
	System_BT_SPP_ReleaseAll();
}
#endif //#if (MBT_JSR82 == MBT_TRUE)
