/*-----------------------------------------------------------------------------
File mbt_avrcp_qbt.c

GENERAL DESCRIPTION
This file contains avrcp target hooks to/from QBT stack from/to MBT BT Layer.

Copyright (c) 2009 QUALCOMM Incorporated.
All Rights Reserved.
Qualcomm Confidential and Proprietary
-----------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------

                        EDIT HISTORY FOR MODULE

  This section contains comments describing changes made to the module.
  Notice that changes are listed in reverse chronological order.

  $Header:  $
  $DateTime: 2009/01/30 15:37:13 $
  $Author: ytkim $

  when        who  what, where, why
  ----------  ---  ------------------------------------------------------------
  2009-01-30   BK  Initial Revision

-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
                     INCLUDE FILES FOR MODULE
-----------------------------------------------------------------------------*/
#include "bt.h"
#include "btpf.h"
#include "btmsg.h"
#include "btpfi.h"
#include "btpfcmdi.h"
#include "bti.h"
#include "btcomdef.h"

#include "mbt_avrcp.h"
#include "mbt_sdc.h"
#include "mbt_evhandler.h"
#include "qbt_utils/qbt_utils.h"
#include "keypad.h"

/*-----------------------------------------------------------------------------
                DEFINITIONS AND DECLARATIONS FOR MODULE
This section contains definitions for constants, macros, types, variables
and other items needed by this module.
-----------------------------------------------------------------------------*/
/* necessary for btmsg.h */
#define BT_MSG_LAYER   QBT_MSG_AVRCP

#define QBT_AV_KEY_TICK_TIME    500
/* This is define 1394 Trade association AV/C document. The document says if
 * release notification is not received from remote controller in 2 sec after a
 * press notification, the target should automatically do release notification
 * The value QBT_AV_FF_RW_REL_TIME is defined in milli seconds
 */
#define QBT_AV_RW_REL_TIME      2000
#define QBT_AV_FF_REL_TIME      2000

/* Remote control commands to target */
#define QBT_AV_PAUSE            0x00 /* PAUSE */
#define QBT_AV_PLAY             0x01 /* PLAY */
#define QBT_AV_STOP             0x02 /* STOP */
#define QBT_AV_FORWARD          0x03 /* FORWARD */
#define QBT_AV_BACKWARD         0x04 /* BACKWARD */
#define QBT_AV_FAST_FORWARD     0x05 /* FAST FORWARD PRESS*/
#define QBT_AV_REWIND           0x06 /* REWIND PRESS */
#define QBT_AV_FAST_FORWARD_REL 0x07 /* FAST FORWARD RELEASE */
#define QBT_AV_REWIND_REL       0x08 /* REWIND RELEASE */
typedef uint8 QBTAVRCPRCCmds;

static const bt_bd_addr_type    QBT_AV_NULL_BD_ADDR = {0,0,0,0,0,0};

/* avrcp object maintained by the QBT avrcp glue layer */
typedef struct _QBTAVRCP
{
  bt_app_id_type  appId;
  bt_bd_addr_type bdAddr;
  uint8           supportedCats;
  boolean         enabled;
  boolean         isConnected;
  boolean         qbtKeyCbIsRunning;
  uint32          rwCounter;
  uint32          ffCounter;
} QBTAVRCP;

static  QBTAVRCP        qbtAvrcp = {BT_APP_ID_NULL, };
#define QBTAVOBJ()      (qbtAvrcp)
#define QBTAV(s)        (qbtAvrcp.s)

static boolean isdisable_disconnect = FALSE;

/*=============================================================================
Prototype Declaration
=============================================================================*/

#ifdef FEATURE_BT_EXTPF_AV

/*------------------------------------------------------------------------------
                          STATIC FUNCTION DEFINITIONS
------------------------------------------------------------------------------*/

/*=============================================================================
FUNCTION:  qbt_avrcp_enable
=============================================================================*/
/**
    Internal function to enable avrcp profile

    @see
    @return      boolean
*/
static boolean qbt_avrcp_enable(void)
{
  int rv = bt_cmd_pf_avrcp_enable(QBTAV(appId), QBTAV(supportedCats));

  if(( rv != BT_CS_GN_PENDING )&& (rv != BT_CS_GN_SUCCESS))
  {
    return FALSE;
  }
  (void)bt_cmd_rm_set_connectable(QBTAV(appId), TRUE, BT_RM_AVP_AUTOMATIC);

  QBTAV(enabled) = TRUE;

  return TRUE;
}

/*=============================================================================
FUNCTION:  qbt_avrcp_convert_bt_cmd_status
=============================================================================*/
/**
    Internal function to convert bt driver command status to boolean

    @see
    @return      boolean
*/
static boolean qbt_avrcp_convert_bt_cmd_status (bt_cmd_status_type stat)
{
   switch (stat)
   {
     case BT_CS_GN_SUCCESS:
     case BT_CS_GN_PENDING:
       return TRUE;

     case BT_CS_GN_CMD_Q_FULL:
     default:
       return FALSE;
   }
}

/*=============================================================================
FUNCTION:  qbt_avrcp_handle_cmd_done_events
=============================================================================*/
/**
    Internal function to handle BT driver command done events

    @see
    @return      None
*/
static void qbt_avrcp_handle_cmd_done_events(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_ev_gn_cmd_done_type* pm = (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;

	switch (pm->cmd_type)
	{
		case BT_PF_CMD_AVRCP_ENABLE:
		{
			if ( bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status == BT_CS_GN_SUCCESS )
			{
				MBT_PI("QBT AVR: avrcp enabled", 0, 0, 0);
				QBTAV(enabled) = TRUE;
				mbt_postevent(MBTEVT_AVRCP_ENABLE_SUCCESS, 0);
			}
			else
			{
				MBT_PI("QBT AVR: avrcp enable failed", 0, 0, 0);
				mbt_postevent(MBTEVT_AVRCP_ENABLE_FAIL, 0);
			}
			break;
		}

		case BT_PF_CMD_AVRCP_DISABLE:
		{
			if ( bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status == BT_CS_GN_SUCCESS )
			{
				MBT_PI("QBT AVR: avrcp disabled", 0, 0, 0);
				//bt_cmd_ec_free_application_id(QBTAV(appId));
				//QBTAV(appId) = BT_APP_ID_NULL;        
				QBTAV(enabled) = FALSE;        
				mbt_postevent(MBTEVT_AVRCP_DISABLE_SUCCESS, 0);
			}
			else
			{
				MBT_PI("QBT AVR: avrcp disable failed", 0, 0, 0);
				mbt_postevent(MBTEVT_AVRCP_DISABLE_FAIL, 0);
			}
			break;
		}

		case BT_CMD_RM_SET_CONNECTABLE:
			break;

		default:
			MBT_PI( "QBT AVR: unexpect Cmd Done 0x%x  status(%x)", pm->cmd_type, pm->cmd_status, 0);
			break;
	}

	return;
}

/*=============================================================================
FUNCTION:  qbt_avrcp_handle_remotectl_events
=============================================================================*/
/**
    Internal function to Notify SAP about Remote Controller Commands

    @see
    @return      None
*/
static void qbt_avrcp_handle_remotectl_events(bt_event_type event,
                                              bt_pf_avrcp_op_status_type dir)
{
	MBT_PI("QBT AVR: RC(cmd,dir)=(0x%x,0x%x)", event, dir, 0);

	switch (event)
	{
		/* AVRCP RC cmds that are currently handled */
		case BT_EV_PF_AVRCP_OP_PAUSE:
			if (BT_PF_AVRCP_OP_PRESSED == dir)
			{
				MBT_PI("QBT AVR: avrcp pause", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_BT_AV_PAUSE_K, HS_NONE_K);
				KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_PAUSE_K);

			}
			break;

		case BT_EV_PF_AVRCP_OP_PLAY:
			if (BT_PF_AVRCP_OP_PRESSED == dir)
			{
				MBT_PI("QBT AVR: avrcp play", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_BT_AV_PLAY_K, HS_NONE_K);
				KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_PLAY_K);
			}
			break;

		case BT_EV_PF_AVRCP_OP_STOP:
			if (BT_PF_AVRCP_OP_PRESSED == dir)
			{
				MBT_PI("QBT AVR: avrcp stop", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_BT_AV_STOP_K, HS_NONE_K);
				KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_STOP_K);
			}
			break;

		case BT_EV_PF_AVRCP_OP_FORWARD:
			if (BT_PF_AVRCP_OP_PRESSED == dir)
			{
				MBT_PI("QBT AVR: avrcp forward pressed", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_BT_AV_FORWARD_K, HS_NONE_K);
			}
			else
			{
				QBTAV(ffCounter) = 0;			
				MBT_PI("QBT AVR: avrcp forward released", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_FORWARD_K);
			}
			break;

		case BT_EV_PF_AVRCP_OP_BACKWARD:
			if (BT_PF_AVRCP_OP_PRESSED == dir)
			{
				MBT_PI("QBT AVR: avrcp backward pressed", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_BT_AV_BACKWARD_K, HS_NONE_K);
			}
			else
			{				
				QBTAV(ffCounter) = 0;
				MBT_PI("QBT AVR: avrcp backward released", 0, 0, 0);			
				KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_BACKWARD_K);
			}
			break;

		case BT_EV_PF_AVRCP_OP_FAST_FORWARD:
			if (BT_PF_AVRCP_OP_PRESSED == dir)
			{
				MBT_PI("QBT AVR: avrcp fast forward pressed", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_BT_AV_FF_K, HS_NONE_K);
			}
			else
			{
				QBTAV(ffCounter) = 0;
				MBT_PI("QBT AVR: avrcp fast forward released", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_FF_K);
			}
			break;

		case BT_EV_PF_AVRCP_OP_REWIND:
			if (BT_PF_AVRCP_OP_PRESSED == dir)
			{
				MBT_PI("QBT AVR: avrcp fast rewind pressed", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_BT_AV_RW_K, HS_NONE_K);
			}
			else
			{
				QBTAV(rwCounter) = 0;
				MBT_PI("QBT AVR: avrcp fast rewind released", 0, 0, 0);
				KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_AV_RW_K);
			}
			break;

		default:
			MBT_PI("QBT AVR: RC(cmd,dir)=(0x%x,0x%x) not handled", event, dir, 0);
			break;
	}

	return;
}

/*=============================================================================
FUNCTION:  qbt_avrcp_event_cb
=============================================================================*/
/**
    Internal callback function to notify about avrcp events from BT driver

    @see
    @return      None
*/
static void qbt_avrcp_event_cb(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_event_type event = bt_ev_msg_ptr->ev_hdr.ev_type;
	T_MBT_AVRCP_STATUS* psdc_avrcp_stat = NULL;

	MBT_PI("qbt_avrcp_event_cb  ", 0, 0, 0);

	switch (event)
	{
		case BT_EV_GN_CMD_DONE:
		{
			qbt_avrcp_handle_cmd_done_events(bt_ev_msg_ptr);
			break;
		}

		case BT_EV_PF_AVRCP_CON:
		{
			MBT_PI("QBT AVR: avrcp connected",0, 0, 0);
			
			memcpy( (void*)&(QBTAV(bdAddr)),
					(void*)&(bt_ev_msg_ptr->ev_msg.ev_avrcp_con.bd_addr),
					sizeof( bt_bd_addr_type) );
			bt_cmd_rm_set_connectable( QBTAV(appId), FALSE, BT_RM_AVP_AUTOMATIC);
			QBTAV(isConnected) = TRUE;

			psdc_avrcp_stat = (T_MBT_AVRCP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_AVRCP_STATUS);
			psdc_avrcp_stat->AvrcpConn[0].ConStatus = MBT_TRUE;
			bdcpy(psdc_avrcp_stat->AvrcpConn[0].BdAddr, bt_ev_msg_ptr->ev_msg.ev_avrcp_con.bd_addr.bd_addr_bytes);
			mbt_postevent(MBTEVT_AVRCP_CONNECT_SUCCESS, 0);
			break;
		}

		case BT_EV_PF_AVRCP_DISCON:
		{
			MBT_PI("QBT AVR: avrcp disconnected",0, 0, 0);
			
			QBTAV(bdAddr) = QBT_AV_NULL_BD_ADDR;
			bt_cmd_rm_set_connectable( QBTAV(appId), TRUE, BT_RM_AVP_AUTOMATIC );
			QBTAV(isConnected) = FALSE;

#ifdef FEATURE_BT_EXTPF_AV
			if (isdisable_disconnect)
			{
					boolean   ret;
					bt_cmd_status_type status;
					
					(void)bt_cmd_rm_set_connectable(QBTAV(appId), FALSE, BT_RM_AVP_AUTOMATIC);	
					status = bt_cmd_pf_avrcp_disable(QBTAV(appId));
					ret = qbt_avrcp_convert_bt_cmd_status(status);
					MBT_PI("QBT AVR: disable avrcp, ret = 0x%x", ret, 0, 0);
					isdisable_disconnect= FALSE;
			}
#endif			
			break;

			psdc_avrcp_stat = (T_MBT_AVRCP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_AVRCP_STATUS);
			psdc_avrcp_stat->AvrcpConn[0].ConStatus = MBT_FALSE;
			mbt_postevent(MBTEVT_AVRCP_DISCONNECT_SUCCESS, 0);
		}

		case BT_EV_PF_AVRCP_OP_PAUSE:
		case BT_EV_PF_AVRCP_OP_PLAY:
		case BT_EV_PF_AVRCP_OP_STOP:
		case BT_EV_PF_AVRCP_OP_REWIND:
		case BT_EV_PF_AVRCP_OP_FAST_FORWARD:
		case BT_EV_PF_AVRCP_OP_FORWARD:
		case BT_EV_PF_AVRCP_OP_BACKWARD:
		{
			bt_pf_avrcp_op_status_type dir;

			MBT_PI("QBT AVR: avrcp push button  appid(%d) txn_id(%d), status(%x)",QBTAV(appId), bt_ev_msg_ptr->ev_msg.ev_avrcp_op.txn_id, bt_ev_msg_ptr->ev_msg.ev_avrcp_op.status);
			
			dir = bt_ev_msg_ptr->ev_msg.ev_avrcp_op.status;
			bt_cmd_pf_avrcp_send_reply( QBTAV(appId),
										bt_ev_msg_ptr->ev_msg.ev_avrcp_op.txn_id,
										bt_ev_msg_ptr->ev_msg.ev_avrcp_op.status,
										event,
										BT_PF_AVRCP_RESPONSE_ACCEPTED );
			qbt_avrcp_handle_remotectl_events(event, dir);
			break;
		}

		case BT_EV_PF_AVRCP_OP_SELECT:
		case BT_EV_PF_AVRCP_OP_UP:
		case BT_EV_PF_AVRCP_OP_DOWN:
		case BT_EV_PF_AVRCP_OP_LEFT:
		case BT_EV_PF_AVRCP_OP_RIGHT:
		case BT_EV_PF_AVRCP_OP_RIGHT_UP:
		case BT_EV_PF_AVRCP_OP_RIGHT_DOWN:
		case BT_EV_PF_AVRCP_OP_LEFT_UP:
		case BT_EV_PF_AVRCP_OP_LEFT_DOWN:
		case BT_EV_PF_AVRCP_OP_ROOT_MENU:
		case BT_EV_PF_AVRCP_OP_SETUP_MENU:
		case BT_EV_PF_AVRCP_OP_CONTENTS_MENU:
		case BT_EV_PF_AVRCP_OP_FAVORITE_MENU:
		case BT_EV_PF_AVRCP_OP_EXIT:
		case BT_EV_PF_AVRCP_OP_0:
		case BT_EV_PF_AVRCP_OP_1:
		case BT_EV_PF_AVRCP_OP_2:
		case BT_EV_PF_AVRCP_OP_3:
		case BT_EV_PF_AVRCP_OP_4:
		case BT_EV_PF_AVRCP_OP_5:
		case BT_EV_PF_AVRCP_OP_6:
		case BT_EV_PF_AVRCP_OP_7:
		case BT_EV_PF_AVRCP_OP_8:
		case BT_EV_PF_AVRCP_OP_9:
		case BT_EV_PF_AVRCP_OP_DOT:
		case BT_EV_PF_AVRCP_OP_ENTER:
		case BT_EV_PF_AVRCP_OP_CLEAR:
		case BT_EV_PF_AVRCP_OP_CHANNEL_UP:
		case BT_EV_PF_AVRCP_OP_CHANNEL_DOWN:
		case BT_EV_PF_AVRCP_OP_PREVIOUS_CHANNEL:
		case BT_EV_PF_AVRCP_OP_SOUND_SELECT:
		case BT_EV_PF_AVRCP_OP_INPUT_SELECT:
		case BT_EV_PF_AVRCP_OP_DISPLAY_INFORMATION:
		case BT_EV_PF_AVRCP_OP_HELP:
		case BT_EV_PF_AVRCP_OP_PAGE_UP:
		case BT_EV_PF_AVRCP_OP_PAGE_DOWN:
		case BT_EV_PF_AVRCP_OP_POWER:
		case BT_EV_PF_AVRCP_OP_VOLUME_UP:
		case BT_EV_PF_AVRCP_OP_VOLUME_DOWN:
		case BT_EV_PF_AVRCP_OP_MUTE:
		case BT_EV_PF_AVRCP_OP_RECORD:
		case BT_EV_PF_AVRCP_OP_EJECT:
		case BT_EV_PF_AVRCP_OP_ANGLE:
		case BT_EV_PF_AVRCP_OP_SUBPICTURE:
		case BT_EV_PF_AVRCP_OP_F1:
		case BT_EV_PF_AVRCP_OP_F2:
		case BT_EV_PF_AVRCP_OP_F3:
		case BT_EV_PF_AVRCP_OP_F4:
		case BT_EV_PF_AVRCP_OP_F5:
		{
			MBT_PI("QBT AVR: no destination for passthrough command", 0, 0, 0);
			bt_cmd_pf_avrcp_send_reply( QBTAV(appId),
									  bt_ev_msg_ptr->ev_msg.ev_avrcp_op.txn_id,
									  bt_ev_msg_ptr->ev_msg.ev_avrcp_op.status,
									  bt_ev_msg_ptr->ev_hdr.ev_type,
									  BT_PF_AVRCP_RESPONSE_NOT_IMPLEMENTED );
			break;
		}

		case BT_EV_PF_AVRCP_OP_GENERIC:
		{
			bt_pf_avrcp_generic_op_type *op;

			op = &bt_ev_msg_ptr->ev_msg.ev_avrcp_generic_op;
			op->cmd = BT_PF_AVRCP_RESPONSE_NOT_IMPLEMENTED;
			bt_cmd_pf_avrcp_send_generic_reply( QBTAV(appId), op->txn_id, op );
			break;
		}

		case BT_EV_PF_AVRCP_CON_FAILED:
			MBT_PI( "QBT AVR: avrcp connection failed", 0, 0, 0 );
			break;

		default:
			MBT_PI( "QBT AVR: unexpected ev 0x%x", event, 0, 0 );
			break;
	}

	return;
}

#endif

/*-----------------------------------------------------------------------------
                       EXTERN FUNCTION DEFINITIONS
-----------------------------------------------------------------------------*/

/*=============================================================================
FUNCTION:  mbt_avrcp_init
=============================================================================*/
/**
    Internal function used to initialize globals

    @see
    @return      None
*/
void mbt_avrcp_init(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	QBTAVRCP *pCon = NULL;
	T_MBT_AVRCP_STATUS *psdc_avrcp_stat = NULL;

  	MBT_PI("QBT AVRCP: AVRCP initialize",0,0,0);
  	pCon = &qbtAvrcp;
  	memset((void*)pCon, 0, sizeof(QBTAVRCP));
   QBTAV(appId) = BT_APP_ID_NULL;
   
  	psdc_avrcp_stat = (T_MBT_AVRCP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_AVRCP_STATUS);
  	if (psdc_avrcp_stat != NULL) {
  		memset(psdc_avrcp_stat, 0x00, sizeof(T_MBT_AVRCP_STATUS));
  	}

#endif
#endif
   return;
}

/*=============================================================================
FUNCTION:  qbt_cmd_avrcp_enable
=============================================================================*/
/**
    Enable AVRCP Service

    @see
    @return      None
*/
void mbt_avrcp_enable(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	if (QBTAV(enabled))
	{
		MBT_PI("QBT AVR: enable avrcp failed, already enabled", 0, 0, 0);
		mbt_postevent(MBTEVT_AVRCP_ENABLE_FAIL, 0);
		return;
	}

   if (BT_APP_ID_NULL == QBTAV(appId))
   {
      QBTAV(appId) = bt_cmd_ec_get_app_id_and_register(qbt_avrcp_event_cb);
   }
   
	if (BT_APP_ID_NULL == QBTAV(appId))
	{
		MBT_PI("QBT AVR: enable avrcp failed, get appId failed", 0, 0, 0);
		mbt_postevent(MBTEVT_AVRCP_ENABLE_FAIL, 0);
		return;
	} else {
		boolean ret;

		QBTAV(supportedCats) = BT_PF_AVRCP_CATEGORY1;
		QBTAV(bdAddr)        = QBT_AV_NULL_BD_ADDR;
		QBTAV(qbtKeyCbIsRunning) = FALSE;
		QBTAV(isConnected) = FALSE;
		QBTAV(rwCounter) = QBTAV(ffCounter) = 0;
		ret = qbt_avrcp_enable();

		MBT_PI("QBT AVR: enable avrcp, ret = 0x%x", ret, 0, 0);
	}

	MBT_PI("QBT AVR: avrcp initialized, aid = 0x%x",QBTAV(appId), 0, 0);

#endif
#endif
  return;
}

/*=============================================================================
FUNCTION:  mbt_avrcp_disable
=============================================================================*/
/**
    Disable AVRCP Service

    @see
    @return      None
*/
void mbt_avrcp_disable(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	boolean   ret;
	bt_cmd_status_type status;

	if (!QBTAV(enabled))
	{
		MBT_PI("QBT AVR: disable avrcp failed, not enabled", 0, 0, 0);
		mbt_postevent(MBTEVT_AVRCP_DISABLE_FAIL, 0);
		return;
	}
	if (QBTAV(isConnected))
	{
		status = bt_cmd_pf_avrcp_disconnect(QBTAV(appId));
		ret = qbt_avrcp_convert_bt_cmd_status(status);
		MBT_PI("QBT AVR: disconnect avrcp, ret = 0x%x", ret, 0, 0);
		isdisable_disconnect = TRUE;
		rex_sleep(500);
	}

/*
	(void)bt_cmd_rm_set_connectable(QBTAV(appId), FALSE, BT_RM_AVP_AUTOMATIC);	
	status = bt_cmd_pf_avrcp_disable(QBTAV(appId));
	ret = qbt_avrcp_convert_bt_cmd_status(status);
	MBT_PI("QBT AVR: disable avrcp, ret = 0x%x", ret, 0, 0);
*/	
#endif
#endif
  return;
}

/*=============================================================================
FUNCTION:  mbt_avrcp_connect
=============================================================================*/
/**
    Connect AVRCP Service

    @see
    @return      None
*/
void mbt_avrcp_connect(T_MBT_BDADDR bd_addr)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	if (QBTAV(isConnected) == TRUE)
	{
		MBT_PI("QBT AVR: connect avrcp failed, already connected", 0, 0, 0);
		return;
	}

	(void)bt_cmd_pf_avrcp_connect(QBTAV(appId), (bt_bd_addr_type*)bd_addr);

	MBT_PI("QBT AVR: avrcp connecting, aid = 0x%x",QBTAV(appId), 0, 0);

#endif
#endif
  return;
}

/**
    Disconnect AVRCP Service

    @see
    @return      None
*/
void mbt_avrcp_disconnect(T_MBT_BDADDR bd_addr)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	if (QBTAV(isConnected) == FALSE)
	{
		MBT_PI("QBT AVR: disnnect avrcp failed, already disconnected", 0, 0, 0);
		return;
	}
	isdisable_disconnect = FALSE;
	(void)bt_cmd_pf_avrcp_disconnect(QBTAV(appId));

	MBT_PI("QBT AVR: avrcp disconnecting, aid = 0x%x",QBTAV(appId), 0, 0);

#endif
#endif
  return;
}


/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
void mbt_avrcp_sendcmd(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_KEY KeyValue)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
#endif
#endif
		return;
}


/*=============================================================================
FUNCTION:  mbt_avrcp_get_player_value_res
=============================================================================*/
/**
    Clear AVRCP key notification to SAP

    @see
    @return      None
*/
void mbt_avrcp_get_player_value_res(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_APP_ATTR* AttrValue)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
#endif
#endif
	return;
}

/*=============================================================================
FUNCTION:  mbt_avrcp_get_media_attr_res
=============================================================================*/
/**
    Clear AVRCP key notification to SAP

    @see
    @return      None
*/
void mbt_avrcp_get_media_attr_res(T_MBT_BDADDR BdAddr, MBT_BYTE AttrNum, T_MBT_AVRCP_MEDIA_ATTR* AttrData  )
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
#endif
#endif
	return;
}

/*=============================================================================
FUNCTION:  mbt_avrcp_get_playstatus_res
=============================================================================*/
/**
    Clear AVRCP key notification to SAP

    @see
    @return      None
*/
void mbt_avrcp_get_playstatus_res(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_GET_PLAYSTATUS PlayStatus)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
#endif
#endif
	return;
}

/*=============================================================================
FUNCTION:  mbt_avrcp_register_noti_interim_res
=============================================================================*/
/**
    Clear AVRCP key notification to SAP

    @see
    @return      None
*/
void mbt_avrcp_register_noti_interim_res(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
#endif
#endif
	return;
}

/*=============================================================================
FUNCTION:  mbt_avrcp_register_noti_res
=============================================================================*/
/**
    Clear AVRCP key notification to SAP

    @see
    @return      None
*/
void mbt_avrcp_register_noti_res(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
#endif
#endif
	return;
}
