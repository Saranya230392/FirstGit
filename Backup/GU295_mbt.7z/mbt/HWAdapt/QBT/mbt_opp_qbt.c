/********************************************************************************
*	File Name	: mbt_opp_qbt.c
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.11.23		Lee,DongHyun			Created - QBT OPP Porting
********************************************************************************/
#include <stdio.h>
#include <string.h>
#include "mbt_opp.h"
#include "mbt_sdc.h"
#include "mbt_evhandler.h" 
#include "mbt_gap.h"
#include "qbt_utils/qbt_fs.h"
#include "qbt_utils/qbt_lang.h"
#include "qbt_utils/qbt_utils.h"
#include "include/mbt_internal_func.h"

#include "bt.h"
#include "btsd.h"

#if (MBT_OPP == MBT_TRUE)
#define MBT_OPP_USE_SCN_SEARCH

typedef struct {
	bt_app_id_type		app_id;
	bt_pf_opp_srv_conn_id_type conn_id;
	uint8				scn;
	fs_handle_type		fs_handle;
	uint32				sent_size;
} mbt_qbt_opp_object;

static uint16 name_str[BT_PF_MAX_FILENAME_LEN*3+1];		//========> local �� �δ㽺��  �������� �� local ���·θ�  ����. 
static char filename[BT_PF_MAX_FILENAME_LEN*3+1];
	
static mbt_qbt_opp_object qbt_opp_client  = { BT_APP_ID_NULL, 0, 0, 0, 0 };
static mbt_qbt_opp_object qbt_opp_server = { BT_APP_ID_NULL, 0, 0, 0, 0 };
static MBT_BYTE mbt_qbt_opp_buf[MBT_OBEX_FILE_BUF_LEN];
static MBT_BYTE need_disconnect = FALSE;
static MBT_BYTE isOnAborting = FALSE;
static MBT_BOOL mbt_opp_CheckCmdStatus( bt_cmd_status_type stat );
static MBT_VOID mbt_opp_Server_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );
static MBT_VOID mbt_opp_Client_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );

LOCAL void mbt_opp_send_fail_evt(T_MBT_OPP_OPERATION operation)
{
	if ( operation == MBT_OPC_PUSH )
		mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_FAIL, 0);
	else if ( operation == MBT_OPC_PULL )
		mbt_postevent(MBTEVT_OPP_CLIENT_PULL_FAIL, 0);
	else if ( operation == MBT_OPC_EXCH_PUSH )
		mbt_postevent(MBTEVT_OPP_CLIENT_EXCH_FAIL, 0);
	else
		MBT_ERR("unknown operation!!",0,0,0);
}

LOCAL void mbt_opp_cutFileNameOneByte(uint16* name)
{
	int i;
	for(i= BT_PF_MAX_FILENAME_LEN-30; i<BT_PF_MAX_FILENAME_LEN+1; i++)
		name[i] = name[i+1];
}
LOCAL bt_cmd_status_type mbt_opp_remove(T_MBT_OPP_OBJECT *opp_obj, MBT_SHORT *name_str, MBT_SHORT name_len)
{
	bt_cmd_status_type cmd_status;
	uint16 filename_len;
	// make filename with full path
	/*
	filename_len = mbt_utf8_to_local(opp_obj->DirName,
				strlen(opp_obj->DirName),
				filename,
				sizeof(filename),
				'_');
	if ( filename[filename_len-1] != '/' )
		filename[filename_len++] = '/';
	filename[filename_len] = 0x00;
	mbt_ucs2_to_local(name_str, name_len,
						(MBT_CHAR*)&filename[filename_len], sizeof(filename)-filename_len, '_');
	*/
	filename_len = strlen(opp_obj->DirName);
	if ( opp_obj->DirName[filename_len-1] != '/' )
		opp_obj->DirName[filename_len++] = '/';
	opp_obj->DirName[filename_len] = 0x00;
	sprintf(filename, "%s%s", opp_obj->DirName, opp_obj->FileName);
	cmd_status = qbt_file_remove(filename);

	return cmd_status;
}


LOCAL bt_cmd_status_type mbt_opp_open_read(mbt_qbt_opp_object *opp_data, T_MBT_OPP_OBJECT *opp_obj, MBT_SHORT *name_str, MBT_SHORT name_len)
{
	bt_cmd_status_type cmd_status;

	if ( opp_obj->StorageType == MBT_MEMORY_BUFFER )
	{
		opp_data->fs_handle = 0;
		cmd_status = OI_OK;
	}
	else
	{
		uint16 filename_len;

		// make filename with full path
		/*
		filename_len = mbt_utf8_to_local(opp_obj->DirName,
					strlen(opp_obj->DirName),
					filename,
					sizeof(filename),
					'_');
		*/
		filename_len = strlen(opp_obj->DirName);
		if ( opp_obj->DirName[filename_len-1] != '/' )
			opp_obj->DirName[filename_len++] = '/';
		opp_obj->DirName[filename_len] = 0x00;
		//mbt_ucs2_to_local(name_str, name_len,
		//			(MBT_CHAR*)&filename[filename_len], sizeof(filename)-filename_len, '_');
		/*
		mbt_ucs2_to_utf8(name_str, name_len,
					(MBT_CHAR*)&filename[filename_len], sizeof(filename)-filename_len, '_');
		
		mbt_ucs2_to_utf8((MBT_SHORT*)bt_ev_msg_ptr->name_str,
				bt_ev_msg_ptr->name_len,
				sdcOppStatus->ReceivingFile.FileName,
				sizeof(sdcOppStatus->ReceivingFile.FileName));

		*/
		sprintf(filename, "%s%s", opp_obj->DirName, opp_obj->FileName);
		cmd_status = qbt_file_open_read(&opp_data->fs_handle, &opp_obj->ObjectSize, filename);
	}

	return cmd_status;
}

LOCAL bt_cmd_status_type mbt_opp_open_write(mbt_qbt_opp_object *opp_data, T_MBT_OPP_OBJECT *opp_obj, MBT_SHORT *name_str, MBT_SHORT name_len)
{
	bt_cmd_status_type cmd_status;
	uint16 filename_len;

	if ( opp_obj->StorageType == MBT_MEMORY_BUFFER )
	{
		opp_data->fs_handle = 0;
		cmd_status = OI_OK;
	}
	else
	{
		// make filename with full path
		/*
		filename_len = mbt_utf8_to_local(opp_obj->DirName,
					strlen(opp_obj->DirName),
					filename,
					sizeof(filename),
					'_');
		*/
		filename_len = strlen(opp_obj->DirName);
		if ( opp_obj->DirName[filename_len-1] != '/' )
			opp_obj->DirName[filename_len++] = '/';
		opp_obj->DirName[filename_len] = 0x00;
		//mbt_ucs2_to_local(name_str, name_len,
		//			&filename[filename_len], sizeof(filename)-filename_len, '_');
		sprintf(filename, "%s%s", opp_obj->DirName, opp_obj->FileName);
		cmd_status = qbt_file_open_write(&opp_data->fs_handle, filename);
	}

	return cmd_status;
}

LOCAL bt_cmd_status_type mbt_opp_read(mbt_qbt_opp_object *opp_data, T_MBT_OPP_OBJECT *opp_obj, MBT_UINT max_len, MBT_BYTE **data_ptr, MBT_UINT *data_len)
{
	bt_cmd_status_type	cmd_status;

	// read data
	if ( opp_obj->StorageType == MBT_MEMORY_BUFFER )
	{
		// calculate read size
		if ( opp_obj->ObjectSize-opp_data->sent_size > max_len )
		{
			*data_len = max_len;
			cmd_status = OI_OK;
		}
		else
		{
			*data_len = opp_obj->ObjectSize-opp_data->sent_size;
			cmd_status = OI_STATUS_END_OF_FILE;
		}

		*data_ptr = (MBT_BYTE*)&opp_obj->PBuffer[opp_data->sent_size];
	}
	else
	{
		if(max_len > sizeof(mbt_qbt_opp_buf))
			max_len = sizeof(mbt_qbt_opp_buf);
		*data_len = sizeof(mbt_qbt_opp_buf);
		*data_ptr = mbt_qbt_opp_buf;
		cmd_status = qbt_file_read(opp_data->fs_handle,
					max_len, (uint32*)data_len, *data_ptr, opp_obj->ObjectSize);
	}

	opp_data->sent_size += *data_len;

	return cmd_status;
}

LOCAL bt_cmd_status_type mbt_opp_write(mbt_qbt_opp_object *opp_data, T_MBT_OPP_OBJECT *opp_obj, MBT_BYTE *data_ptr, MBT_UINT data_len)
{
	bt_cmd_status_type	cmd_status;
	uint16 filename_len;

	if ( opp_obj->StorageType == MBT_MEMORY_BUFFER )
	{
		cmd_status = OI_OK;

		if ( opp_data->sent_size+data_len >= opp_obj->AllocBufferSize )
		{
			// buffer overflow, change to file type

			opp_obj->StorageType = MBT_INTERNAL_FS;

			// make filename with full path
			/*
			filename_len = mbt_utf8_to_local(opp_obj->DirName, strlen(opp_obj->DirName),
						filename, sizeof(filename), '_');

			if ( filename[filename_len-1] != '/' )
				filename[filename_len++] = '/';
		
			mbt_utf8_to_local(opp_obj->FileName, strlen(opp_obj->FileName),
						&filename[filename_len], sizeof(filename)-filename_len, '_');
			*/
			filename_len = strlen(opp_obj->DirName);
			if ( opp_obj->DirName[filename_len-1] != '/' )
				opp_obj->DirName[filename_len++] = '/';
			opp_obj->DirName[filename_len] = 0x00;
			sprintf(filename, "%s%s", opp_obj->DirName, opp_obj->FileName);
			cmd_status = qbt_file_open_write(&opp_data->fs_handle, filename);
		}
		else
		{
			memcpy((void*)&opp_obj->PBuffer[opp_obj->ObjectSize],
						data_ptr,
						data_len);
			cmd_status = OI_OK;
		}
	}
	else
	{
		cmd_status = qbt_file_write(opp_data->fs_handle, data_ptr, data_len);
	}

	opp_data->sent_size += data_len;

	return cmd_status;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_server_enable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_server_enable (MBT_VOID)
{
	bt_cmd_status_type opp_rst;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	if(sdcOppStatus->bServerEnabled == MBT_FALSE)
	{
		opp_rst = bt_cmd_pf_opp_srv_register( qbt_opp_server.app_id,
#ifdef FOR_BLUETOOTH_SIG
												BT_PF_OPP_SRV_OBJ_FORMAT_MASK & 0xffff001f,
#else
												BT_PF_OPP_SRV_OBJ_FORMAT_MASK,
#endif
												"LGE OPP Server");
		if(mbt_opp_CheckCmdStatus(opp_rst))
		{	
			sdcOppStatus->bServerEnabled = MBT_TRUE;
			sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
			MBT_PI("OPP Server Enabled",0,0,0);
			mbt_postevent(MBTEVT_OPP_SERVER_ENABLE_SUCCESS, 0);
		}
		else
		{
			sdcOppStatus->bServerEnabled = MBT_FALSE;
			sdcOppStatus->OppState = MBT_OPP_STATE_CLOSED;
			MBT_ERR("OPP Server Enable Fail. Reason code : %x",opp_rst,0,0);
			mbt_postevent(MBTEVT_OPP_SERVER_ENABLE_FAIL, 0);
			return;
		}
	}
	else
	{
		MBT_WARN("mbt_opp_server_enable> Opp is aleady enabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_OPP_SERVER_ENABLE_FAIL, 0);
		return;
	}

}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_server_disable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_server_disable (MBT_VOID)
{
	bt_cmd_status_type opp_rst;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	if(sdcOppStatus->bServerEnabled == MBT_TRUE)
	{
		opp_rst = bt_cmd_pf_opp_srv_force_disconnect( qbt_opp_server.app_id,
				qbt_opp_server.conn_id);
		if(mbt_opp_CheckCmdStatus(opp_rst))
		{
			sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
		}
		else
		{
			MBT_ERR("mbt_opp_server_disable> force disconnect fail. Reason code : %x",opp_rst,0,0);
			mbt_postevent(MBTEVT_OPP_SERVER_DISABLE_FAIL, 0);
			return;
		}
		
		opp_rst = bt_cmd_pf_opp_srv_deregister( qbt_opp_server.app_id);
		if(mbt_opp_CheckCmdStatus(opp_rst))
		{
			sdcOppStatus->bServerEnabled = MBT_FALSE;
			sdcOppStatus->OppState = MBT_OPP_STATE_CLOSED;
		}
		else
		{
			MBT_ERR("mbt_opp_server_disable> server deregister fail. Reason code : %x",opp_rst,0,0);
			mbt_postevent(MBTEVT_OPP_SERVER_DISABLE_FAIL, 0);
			return;
		}
		/*
		opp_rst = bt_cmd_ec_free_application_id(qbt_opp_server.app_id);
		if(mbt_opp_CheckCmdStatus(opp_rst))
		{
			MBT_PI("OPP Server Disabled",0,0,0);
		}
		else
		{
			MBT_ERR("mbt_opp_server_disable> free app_id fail. Reason code : %x",opp_rst,0,0);
			mbt_postevent(MBTEVT_OPP_SERVER_DISABLE_FAIL, 0);
			return;
		}
		qbt_opp_server.app_id = BT_APP_ID_NULL;
		*/
		mbt_postevent(MBTEVT_OPP_SERVER_DISABLE_SUCCESS, 0);
	}
	else
	{
		MBT_WARN("mbt_opp_server_disable> Opp is aleady enabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_OPP_SERVER_DISABLE_FAIL, 0);
		return;
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_server_disconnect (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_server_disconnect(MBT_VOID)
{
	bt_cmd_status_type cmd_status;
//	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_server_disconnect> ",0,0,0);

	cmd_status = bt_cmd_pf_opp_srv_force_disconnect( qbt_opp_server.app_id,
				qbt_opp_server.conn_id);

	if(mbt_opp_CheckCmdStatus(cmd_status))
	{
	}
	else
	{
		MBT_ERR("mbt_opp_server_disc> force disconnect fail. Reason code : %x",cmd_status,0,0);
		mbt_postevent(MBTEVT_OPP_SERVER_DISCONNECT, 0);
		return;
	}
}

bt_cmd_status_type  mbt_opp_server_fail_push_start(T_MBTEVT* mbt_evt)
{
	bt_cmd_status_type cmd_status;
	cmd_status = bt_cmd_pf_opp_srv_open_write_done(qbt_opp_server.app_id,
				qbt_opp_server.conn_id,
				(bt_pf_opp_handle_type)qbt_opp_server.fs_handle,
				OI_FAIL);
	bt_cmd_pf_opp_srv_force_disconnect( qbt_opp_server.app_id, qbt_opp_server.conn_id);
	*mbt_evt = MBTEVT_OPP_SERVER_PUSH_FAIL;
	return cmd_status;
}


/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_server_access_response (T_MBT_AUTHRES Reply)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_server_access_response(T_MBT_AUTHRES Reply)
{
	bt_cmd_status_type cmd_status;
	bt_cmd_status_type cmd_status_rsp;
	T_MBTEVT		mbt_evt;
	MBT_SHORT		name_len;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	if ( sdcOppStatus->Operation == MBT_OPS_PUSH )
	{
		if ( Reply == MBT_ALLOW_RES )
		{
			MBT_PI("mbt_opp_acc_res> accept push", 0, 0, 0);

			if (sdcOppStatus->OppState != MBT_OPP_STATE_CONNECTED ) 
			{
				MBT_WARN("[OPP] INVAILD STATE(%d) or filename_len(%d)", sdcOppStatus->OppState, strlen(sdcOppStatus->ReceivingFile.FileName), 0);
				mbt_opp_server_fail_push_start(&mbt_evt);
				mbt_postevent(mbt_evt, 0);
				return;
			}

			//�ӽ�.
			if(sdcOppStatus->ReceivingFile.DirName[strlen(sdcOppStatus->ReceivingFile.DirName)-1] != '/')
			{
				sdcOppStatus->ReceivingFile.DirName[strlen(sdcOppStatus->ReceivingFile.DirName)+1] = 0x00;
				sdcOppStatus->ReceivingFile.DirName[strlen(sdcOppStatus->ReceivingFile.DirName)] = '/';
				MBT_WARN("Added '/' to Dirname ~~~", 0,0,0);
			}
			else
			{
				MBT_PI("Dir name is OK...", 0,0,0);
			}
			/*
			name_len = mbt_utf8_to_ucs2(sdcOppStatus->ReceivingFile.FileName,
						strlen(sdcOppStatus->ReceivingFile.FileName),
						name_str, sizeof(name_str));
			*/
			// open file
			cmd_status_rsp = mbt_opp_open_write(&qbt_opp_server,
						&sdcOppStatus->ReceivingFile,
						NULL, 0);
			// reply to stack
			cmd_status = bt_cmd_pf_opp_srv_open_write_done(qbt_opp_server.app_id,
						qbt_opp_server.conn_id,
						(bt_pf_opp_handle_type)qbt_opp_server.fs_handle,
						cmd_status_rsp);
			if ( cmd_status_rsp == OI_OK )
			{
				mbt_evt = MBTEVT_OPP_SERVER_PUSH_START;
				sdcOppStatus->OppState = MBT_OPP_STATE_RECEIVING;
			}
			else
			{
				MBT_WARN("[MBT_OPP_SERVER  file open error!!", 0,0,0);
				bt_cmd_pf_opp_srv_force_disconnect( qbt_opp_server.app_id, qbt_opp_server.conn_id);
				mbt_evt = MBTEVT_OPP_SERVER_PUSH_FAIL;	
			}

			qbt_opp_server.sent_size = 0;
			// make mbt event
			mbt_postevent(mbt_evt, 0);
		}
		else
		{
			MBT_PI("mbt_opp_acc_res> reject push :%x", Reply, 0, 0);
			cmd_status = bt_cmd_pf_opp_srv_open_write_done(qbt_opp_server.app_id,
						qbt_opp_server.conn_id,
						0,
						OI_OBEX_UNSUPPORTED_MEDIA_TYPE);
			bt_cmd_pf_opp_srv_force_disconnect( qbt_opp_server.app_id, qbt_opp_server.conn_id);
		}
		
	}
	else if ( sdcOppStatus->Operation == MBT_OPS_PULL )
	{
		if ( Reply == MBT_ALLOW_RES )
		{
			MBT_PI("mbt_opp_acc_res> accept pull", 0, 0, 0);
			
			name_len = mbt_utf8_to_ucs2(sdcOppStatus->SendingFile.FileName,
						strlen(sdcOppStatus->SendingFile.FileName),
						name_str, sizeof(name_str));
			
			cmd_status_rsp = mbt_opp_open_read(&qbt_opp_server,
						&sdcOppStatus->SendingFile,
						NULL, name_len);

			if ( cmd_status_rsp == OI_OK )
			{
				mbt_evt = MBTEVT_OPP_SERVER_PULL_START;
				sdcOppStatus->OppState = MBT_OPP_STATE_SENDING;
			}
			else
				mbt_evt = MBTEVT_OPP_SERVER_PULL_FAIL;

			qbt_opp_server.sent_size = 0;

			// reply to stack
			cmd_status = bt_cmd_pf_opp_srv_open_read_done(qbt_opp_server.app_id,
						qbt_opp_server.conn_id,
						(bt_pf_opp_handle_type)qbt_opp_server.fs_handle,
						NULL,
						"",
						sdcOppStatus->SendingFile.ObjectSize,
						cmd_status_rsp);

			mbt_postevent(mbt_evt, 0);
		}
		else
		{
			MBT_PI("mbt_opp_acc_res> reject pull :%x", Reply, 0, 0);
			cmd_status = bt_cmd_pf_opp_srv_open_read_done(qbt_opp_server.app_id,
						qbt_opp_server.conn_id,
						0, NULL, "", 0, OI_FAIL);
		}
	}
	else
	{
		MBT_ERR("mbt_opp_acc_res> invalid status oper:%x", sdcOppStatus->Operation, Reply, 0);
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_client_enable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_client_enable(MBT_VOID)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	if(sdcOppStatus->bClientEnabled == MBT_FALSE)
	{
		MBT_PI("OP Cli Enabled : app_id:%x", qbt_opp_client.app_id, 0, 0);
		sdcOppStatus->bClientEnabled = MBT_TRUE;
		mbt_postevent(MBTEVT_OPP_CLIENT_ENABLE_SUCCESS, 0);
	}
	else
	{
		MBT_WARN("mbt_opp_cli_enable> Opp is aleady enabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_OPP_CLIENT_ENABLE_FAIL, 0);
		return;
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_client_disable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_client_disable(MBT_VOID)
{
	//bt_cmd_status_type opp_rst;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	if(sdcOppStatus->bClientEnabled == TRUE)
	{
		sdcOppStatus->bClientEnabled = MBT_FALSE;
		MBT_PI("OP Cli Disabled : app_id:%x", qbt_opp_client.app_id, 0, 0);
		/*
		opp_rst = bt_cmd_ec_free_application_id(qbt_opp_client.app_id);
		if(mbt_opp_CheckCmdStatus(opp_rst))
		{
			qbt_opp_client.app_id = BT_APP_ID_NULL;
			sdcOppStatus->bClientEnabled = MBT_FALSE;
			MBT_PI("OP Cli Disabled : app_id:%x", qbt_opp_client.app_id, 0, 0);
			mbt_postevent(MBTEVT_OPP_CLIENT_DISABLE_SUCCESS, 0);
		}
		else
		{
			MBT_ERR("mbt_opp_client_disable>OPP Client app id free error. Reason code : %d",opp_rst,0,0);
			mbt_postevent(MBTEVT_OPP_CLIENT_DISABLE_FAIL, 0);
		}
		*/
	}
	else
	{
		MBT_WARN("mbt_opp_cli_disable> Opp is aleady enabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_OPP_CLIENT_DISABLE_FAIL, 0);
		return;
	}
}


/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_client_pushobject (MBT_VOBJECT *MBtObject)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_client_pushobject (T_MBT_BDADDR RemoteBDAddr,T_MBT_OPP_OBJECT *MBTObject)
{
	bt_cmd_status_type cmd_status;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("OP Cli Push : state:%x oper:%x store:%d", sdcOppStatus->OppState, sdcOppStatus->Operation, MBTObject->StorageType);

	memcpy(sdcOppStatus->BDAddr,RemoteBDAddr, MBT_BDADDR_LEN);

	sdcOppStatus->Operation = MBT_OPC_PUSH;
	strcpy(sdcOppStatus->SendingFile.DirName , MBTObject->DirName);
	strcpy(sdcOppStatus->SendingFile.FileName , MBTObject->FileName);
	sdcOppStatus->SendingFile.ObjectSize = MBTObject->ObjectSize;			// �ؿ��� �����;� ��. 
	sdcOppStatus->SendingFile.ObjectType = MBTObject->ObjectType;
	sdcOppStatus->SendingFile.PBuffer = MBTObject->PBuffer;
	sdcOppStatus->SendingFile.StorageType = MBTObject->StorageType;		//client������ �ʿ� ���� 
	need_disconnect = FALSE;
	
	if ( sdcOppStatus->OppState == MBT_OPP_STATE_IDLE )
	{
		mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
#ifdef MBT_OPP_USE_SCN_SEARCH
		cmd_status = bt_cmd_sd_get_server_channel_number(qbt_opp_client.app_id,
					(bt_bd_addr_type *)RemoteBDAddr,
					BT_SD_SERVICE_CLASS_OBEX_OBJECT_PUSH);
#else
		cmd_status = bt_cmd_pf_opp_cli_connect(qbt_opp_client.app_id,
					(bt_bd_addr_type *)RemoteBDAddr,
					0);
#endif
	}
	else if ( sdcOppStatus->OppState == MBT_OPP_STATE_CONNECTED )
	{
		//rex_sleep(4000);		//multi ������ ��� UI task ���� �� 4�ʰ� delay�� �ش�. 
		mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
		sdcOppStatus->OppState = MBT_OPP_STATE_SENDING;
		if(BT_PF_MAX_FILENAME_LEN -1 < mbt_utf8_to_ucs2(sdcOppStatus->SendingFile.FileName,
					strlen(sdcOppStatus->SendingFile.FileName),
					name_str, sizeof(name_str)))
		{
			mbt_opp_cutFileNameOneByte(name_str);
		}
		cmd_status = bt_cmd_pf_opp_cli_push(qbt_opp_client.app_id,
					qbt_opp_client.conn_id, name_str, "");
	}
	else
	{
		mbt_gap_restore_role_switch(sdcOppStatus->BDAddr);
		MBT_ERR("OP Cli Push : invalid state : %x", sdcOppStatus->OppState, 0, 0);
		mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_FAIL, 0);
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_client_pullobject (MBT_VOBJECT *MBtObject)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_client_pullobject(T_MBT_BDADDR RemoteBDAddr,T_MBT_OPP_OBJECT * MBTObject)
{
	bt_cmd_status_type cmd_status;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("OP Cli Pull : state:%x oper:%x store:%d", sdcOppStatus->OppState, sdcOppStatus->Operation, MBTObject->StorageType);

	memcpy(sdcOppStatus->BDAddr, RemoteBDAddr, MBT_BDADDR_LEN);

	sdcOppStatus->Operation = MBT_OPC_PULL;
	strcpy(sdcOppStatus->ReceivingFile.DirName , MBTObject->DirName);
//	strcpy(sdcOppStatus->ReceivingFile.FileName , MBTObject->FileName);	// not used
//	sdcOppStatus->ReceivingFile.ObjectSize = MBTObject->ObjectSize;	// not used
//	sdcOppStatus->ReceivingFile.ObjectType = MBTObject->ObjectType;	// not used
	sdcOppStatus->ReceivingFile.PBuffer = MBTObject->PBuffer;
	sdcOppStatus->ReceivingFile.StorageType = MBTObject->StorageType;

	if ( sdcOppStatus->OppState == MBT_OPP_STATE_IDLE )
	{
#ifdef MBT_OPP_USE_SCN_SEARCH
		cmd_status = bt_cmd_sd_get_server_channel_number(qbt_opp_client.app_id,
					(bt_bd_addr_type *)RemoteBDAddr,
					BT_SD_SERVICE_CLASS_OBEX_OBJECT_PUSH);
#else
		mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
		cmd_status = bt_cmd_pf_opp_cli_connect(qbt_opp_client.app_id,
					(bt_bd_addr_type *)RemoteBDAddr,
					0);
#endif
	}
	else if ( sdcOppStatus->OppState == MBT_OPP_STATE_CONNECTED )
	{
		mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
		sdcOppStatus->OppState = MBT_OPP_STATE_PULLING;
		cmd_status = bt_cmd_pf_opp_cli_pull(qbt_opp_client.app_id,
					qbt_opp_client.conn_id);
	}
	else
	{
		mbt_gap_restore_role_switch(sdcOppStatus->BDAddr);
		MBT_ERR("OP Cli Pull : invalid state : %x", sdcOppStatus->OppState, 0, 0);
		mbt_postevent(MBTEVT_OPP_CLIENT_PULL_FAIL, 0);
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_client_exchobject (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_client_exchobject (T_MBT_BDADDR RemoteBDAddr,T_MBT_OPP_OBJECT * SendObject,T_MBT_OPP_OBJECT * RecvObject)
{
	bt_cmd_status_type cmd_status;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("OP Cli Exch : state:%x oper:%x store:%d", sdcOppStatus->OppState, sdcOppStatus->Operation, SendObject->StorageType);

	memcpy(sdcOppStatus->BDAddr,RemoteBDAddr,MBT_BDADDR_LEN);

	sdcOppStatus->Operation = MBT_OPC_EXCH_PUSH;
	strcpy(sdcOppStatus->SendingFile.DirName , SendObject->DirName);
	strcpy(sdcOppStatus->SendingFile.FileName , SendObject->FileName);
	sdcOppStatus->SendingFile.ObjectSize = SendObject->ObjectSize;
	sdcOppStatus->SendingFile.ObjectType = SendObject->ObjectType;
	sdcOppStatus->SendingFile.PBuffer = SendObject->PBuffer;
	sdcOppStatus->SendingFile.StorageType = SendObject->StorageType;

	strcpy(sdcOppStatus->ReceivingFile.DirName , RecvObject->DirName);
	strcpy(sdcOppStatus->ReceivingFile.FileName , RecvObject->FileName);
	sdcOppStatus->ReceivingFile.ObjectSize = RecvObject->ObjectSize;
	sdcOppStatus->ReceivingFile.ObjectType = RecvObject->ObjectType;
	sdcOppStatus->ReceivingFile.PBuffer = RecvObject->PBuffer;
	sdcOppStatus->ReceivingFile.StorageType = RecvObject->StorageType;

	if ( sdcOppStatus->OppState == MBT_OPP_STATE_IDLE )
	{
#ifdef MBT_OPP_USE_SCN_SEARCH
		cmd_status = bt_cmd_sd_get_server_channel_number(qbt_opp_client.app_id,
					(bt_bd_addr_type *)RemoteBDAddr, BT_SD_SERVICE_CLASS_OBEX_OBJECT_PUSH);
#else
		mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
		cmd_status = bt_cmd_pf_opp_cli_connect(qbt_opp_client.app_id,
					(bt_bd_addr_type *)RemoteBDAddr,
					0);
#endif
	}
	else if ( sdcOppStatus->OppState == MBT_OPP_STATE_CONNECTED )
	{
		mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
		sdcOppStatus->OppState = MBT_OPP_STATE_SENDING;
		if(BT_PF_MAX_FILENAME_LEN -1 < mbt_utf8_to_ucs2(sdcOppStatus->SendingFile.FileName,
					strlen(sdcOppStatus->SendingFile.FileName),
					name_str, sizeof(name_str)))
		{
			mbt_opp_cutFileNameOneByte(name_str);
		}
		cmd_status = bt_cmd_pf_opp_cli_push(qbt_opp_client.app_id,
					qbt_opp_client.conn_id, name_str, "");
	}
	else
	{
		mbt_gap_restore_role_switch(sdcOppStatus->BDAddr);
		MBT_ERR("OP Cli Exch : invalid state : %x", sdcOppStatus->OppState, 0, 0);
		mbt_postevent(MBTEVT_OPP_CLIENT_EXCH_FAIL, 0);
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_client_disconnect (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_opp_client_disconnect(MBT_VOID)
{
	bt_cmd_status_type cmd_status;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("OP Cli Disconn : state:%x oper:%x", sdcOppStatus->OppState, sdcOppStatus->Operation, 0);
	mbt_gap_restore_role_switch(sdcOppStatus->BDAddr);
	if ( sdcOppStatus->OppState == MBT_OPP_STATE_CONNECTED )
	{
		cmd_status = bt_cmd_pf_opp_cli_disconnect(qbt_opp_client.app_id, qbt_opp_client.conn_id);
		if (cmd_status != BT_CS_GN_PENDING && cmd_status != BT_CS_GN_SUCCESS) {
			MBT_PI("[OPP] opp_cli_disconnect is already disconnected.", 0, 0, 0);
			sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
			qbt_opp_client.conn_id = BT_PF_OPP_NO_CONN_ID;
		}
	}
	else if(sdcOppStatus->OppState == MBT_OPP_STATE_SENDING )
	{
		//MBT_ERR("OP Cli Disconn : invalid state : %x", sdcOppStatus->OppState, 0, 0);
		//mbt_postevent(MBTEVT_OPP_CLIENT_DISCONNECT, 0);
		//abort ó�� �߰� �䱸��.
		// dkmoon20070817 cancel�� abort cmd�� �ѹ��� ó���ǵ��� ����. abort cmd ó���� delay �߰�.
		if (qbt_opp_client.conn_id!= BT_PF_OPP_NO_CONN_ID) {
			MBT_PI("[OPP] Client_Abort_Object app_id conn_id [%d], sdcOppStatus [%d]", qbt_opp_client.conn_id, sdcOppStatus->OppState, 0);
			bt_cmd_pf_opp_cli_abort(qbt_opp_client.app_id, qbt_opp_client.conn_id);
			//pMe->state = OPP_ABORTING;
			isOnAborting = TRUE;
			rex_sleep(1000);
		}
		need_disconnect = FALSE;
		cmd_status = bt_cmd_pf_opp_cli_disconnect(qbt_opp_client.app_id, qbt_opp_client.conn_id);
		if (cmd_status != BT_CS_GN_PENDING && cmd_status != BT_CS_GN_SUCCESS) {
			MBT_PI("[OPP] opp_cli_disconnect is already disconnected.", 0, 0, 0);
			sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
			qbt_opp_client.conn_id = BT_PF_OPP_NO_CONN_ID;
		}
	}
	else if( sdcOppStatus->OppState == MBT_OPP_STATE_CLOSED)
	{
		need_disconnect = TRUE;
	}
	else if(sdcOppStatus->OppState == MBT_OPP_STATE_PULLING)
	{
	}
	else if(sdcOppStatus->OppState == MBT_OPP_STATE_RECEIVING)
	{
	}
#if 0
	else if(sdcOppStatus->OppState ==MBT_OPP_STATE_IDLE)
	{
		need_disconnect = TRUE;
		mbt_postevent(MBTEVT_OPP_CLIENT_DISCONNECT, 0);	// JG Kwon. 2009.06.16
	}
#endif	// moved to below. JG Kwon. 2009.11.19
	else
	{
		cmd_status = bt_cmd_pf_opp_cli_disconnect(qbt_opp_client.app_id, qbt_opp_client.conn_id);
		need_disconnect = FALSE;

		if(sdcOppStatus->OppState ==MBT_OPP_STATE_IDLE)
		{
			need_disconnect = TRUE;
			mbt_postevent(MBTEVT_OPP_CLIENT_DISCONNECT, 0); // JG Kwon. 2009.06.16
		}		// moved from above. JG Kwon. 2009.11.19


		if (cmd_status != BT_CS_GN_PENDING && cmd_status != BT_CS_GN_SUCCESS) {
			MBT_PI("[OPP] opp_cli_disconnect is already disconnected.", 0, 0, 0);
			sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
			qbt_opp_client.conn_id = BT_PF_OPP_NO_CONN_ID;
		}
	}
	
}


static MBT_BOOL mbt_opp_CheckCmdStatus( bt_cmd_status_type stat )
{
	switch (stat)
	{
		case BT_CS_GN_SUCCESS:
		case BT_CS_GN_PENDING:
			return MBT_TRUE; //SUCCESS;

		case BT_CS_GN_CMD_Q_FULL:
			MBT_ERR("mbt_opp_CheckCmdStatus state:%d", stat,0,0);
			return MBT_FALSE; //ENOMEMORY;

		default:
			MBT_ERR("mbt_opp_CheckCmdStatus state:%d", stat,0,0);
			return MBT_FALSE; //EFAILED;
	}
}

MBT_VOID qbt_proc_evt_opp_srv_con_ind(bt_pf_ev_opp_srv_con_ind_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_srv_con_ind> conn_id:%x opp_stat:%d", bt_ev_msg_ptr->conn_id, sdcOppStatus->OppState, 0);
	if ( sdcOppStatus->bServerEnabled && sdcOppStatus->OppState == MBT_OPP_STATE_IDLE )
	{
		qbt_opp_server.conn_id = bt_ev_msg_ptr->conn_id;
		sdcOppStatus->OppState = MBT_OPP_STATE_CONNECTED;
		memcpy(sdcOppStatus->BDAddr, (void*)bt_ev_msg_ptr->bd_addr.bd_addr_bytes, MBT_BDADDR_LEN);

		cmd_status = bt_cmd_pf_opp_srv_accept_connect(qbt_opp_server.app_id,
					qbt_opp_server.conn_id, TRUE, FALSE);
	}
	else
	{
		MBT_ERR("mbt_opp_srv_con_ind> invalid_stat:%d force disconnect", bt_ev_msg_ptr->conn_id, sdcOppStatus->OppState, 0);
		cmd_status = bt_cmd_pf_opp_srv_force_disconnect(qbt_opp_server.app_id,
					bt_ev_msg_ptr->conn_id);
	}
}

MBT_VOID qbt_proc_evt_opp_srv_dcn_ind(bt_pf_ev_opp_srv_dcn_ind_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_srv_disc_ind> conn_id:%x opp_stat:%d", bt_ev_msg_ptr->conn_id, sdcOppStatus->OppState, 0);

	sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
	qbt_opp_server.conn_id = BT_PF_OPP_NO_CONN_ID;
	mbt_postevent(MBTEVT_OPP_SERVER_DISCONNECT, 0);
}

MBT_VOID qbt_proc_evt_opp_srv_open_read_req(bt_pf_ev_opp_srv_open_read_req_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_srv_open_read> conn_id:%x name_len:%d state:%x", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->name_len, sdcOppStatus->OppState);

	sdcOppStatus->Operation = MBT_OPS_PULL;
	qbt_opp_server.sent_size = 0;
	mbt_postevent(MBTEVT_OPP_SERVER_ACCESS_REQUEST, 0);

}

MBT_VOID qbt_proc_evt_opp_srv_open_write_req(bt_pf_ev_opp_srv_open_write_req_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_srv_open_write> conn_id:%x name_len:%d obj_size:%d", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->name_len, bt_ev_msg_ptr->obj_size);
	sdcOppStatus->Operation = MBT_OPS_PUSH;
	sdcOppStatus->ReceivingFile.ObjectSize = bt_ev_msg_ptr->obj_size;

	// store received name
	mbt_ucs2_to_utf8((MBT_SHORT*)bt_ev_msg_ptr->name_str,
				bt_ev_msg_ptr->name_len,
				sdcOppStatus->ReceivingFile.FileName,
				sizeof(sdcOppStatus->ReceivingFile.FileName));
	mbt_postevent(MBTEVT_OPP_SERVER_ACCESS_REQUEST, 0);
}

MBT_VOID qbt_proc_evt_opp_srv_close_req(bt_pf_ev_opp_srv_close_req_type *bt_ev_msg_ptr)
{
	//bt_cmd_status_type cmd_status;
	bt_cmd_status_type cmd_status_rsp;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);
	fs_rsp_msg_type fs_rsp;

	// [+] OPP�� ������ ������ ���� �Ϸ� �� handle���� srv close �ѹ� �� �����. �� �׷���? JG Kwon. 2009.06.18
	BOOL skip_post_event = FALSE;
	if(0 == qbt_opp_server.fs_handle)
		skip_post_event = TRUE;
	// [-] JG Kwon. 2009.06.18

	MBT_PI("mbt_opp_srv_close> conn_id:%x hndl:%d stat:%d", bt_ev_msg_ptr->conn_id, qbt_opp_server.fs_handle, bt_ev_msg_ptr->status);

	sdcOppStatus->OppState = MBT_OPP_STATE_CONNECTED;

	fs_close(qbt_opp_server.fs_handle, NULL, &fs_rsp);
	MBT_PI("mbt_opp_srv_close> hndl:%x res:%d", qbt_opp_server.fs_handle, fs_rsp.close.status, 0);
	qbt_opp_server.fs_handle = 0;

	if(bt_ev_msg_ptr->status == BT_CS_GN_SUCCESS)
	{
		if(FALSE == skip_post_event)	// handle�� ���� srv close�� ��� File Manager�� update���� ����. JG Kwon. 2009.06.18
		{
			//�������� ������ close req. 
			MBT_PI("[OPP] write complete.", 0, 0, 0);
			if ( sdcOppStatus->Operation == MBT_OPS_PUSH )
				mbt_postevent(MBTEVT_OPP_SERVER_PUSH_SUCCESS, 0);
			else if ( sdcOppStatus->Operation == MBT_OPS_PULL )
				mbt_postevent(MBTEVT_OPP_SERVER_PULL_SUCCESS, 0);
			else
				MBT_ERR("mbt_opp_close> invalid status oper:%x stat:%x", sdcOppStatus->Operation, sdcOppStatus->OppState, 0);
		}
		else
		{
			MBT_PI("[OPP] No handle for file. skip post event MBTEVT_OPP_SERVER_PUSH_SUCCESS.", 0, 0, 0);
		}
	}
	else
	{
		//���������� ����� ���� close req.
		MBT_SHORT		name_len = 0;
		MBT_ERR("[OPP] close fail(err:%x)", fs_rsp.close.status, 0, 0);
		/*
		name_len = mbt_utf8_to_ucs2(sdcOppStatus->ReceivingFile.FileName,
				strlen(sdcOppStatus->ReceivingFile.FileName),
				name_str, sizeof(name_str));
		*/
		cmd_status_rsp = mbt_opp_remove(&sdcOppStatus->ReceivingFile,NULL, name_len);
		if ( sdcOppStatus->Operation == MBT_OPS_PUSH )
		{
			mbt_postevent(MBTEVT_OPP_SERVER_PUSH_FAIL, 0);
		}
		else if ( sdcOppStatus->Operation == MBT_OPS_PULL )
		{
			mbt_postevent(MBTEVT_OPP_SERVER_PULL_FAIL, 0);
		}
		else
		{
			MBT_ERR("mbt_opp_close> invalid status oper:%x stat:%x", sdcOppStatus->Operation, sdcOppStatus->OppState, 0);
		}
	}
}

MBT_VOID qbt_proc_evt_opp_srv_read_req(bt_pf_ev_opp_srv_read_req_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	bt_cmd_status_type cmd_status_rsp;
	T_MBTEVT		mbt_evt;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);
	MBT_BYTE	*data_ptr;
	MBT_UINT	data_len;

	MBT_PI("mbt_opp_srv_read> conn_id:%x hndl:%d max_read:%d", bt_ev_msg_ptr->conn_id, qbt_opp_server.fs_handle, bt_ev_msg_ptr->max_read);

	cmd_status_rsp = mbt_opp_read(&qbt_opp_server, &sdcOppStatus->SendingFile, bt_ev_msg_ptr->max_read, &data_ptr, &data_len);

	if ( cmd_status_rsp == OI_OK || cmd_status_rsp == OI_STATUS_END_OF_FILE )
	{
		sdcOppStatus->TxProgress = qbt_opp_server.sent_size;
		mbt_evt = MBTEVT_OPP_SERVER_PROGRESSIVE_UPDATE;
		MBT_PI("mbt opp : succ send : %d/%d", sdcOppStatus->TxProgress, sdcOppStatus->ReceivingFile.ObjectSize, 0);
	}
	else
		mbt_evt = MBTEVT_OPP_SERVER_PULL_FAIL;

	cmd_status = bt_cmd_pf_opp_srv_read_done(qbt_opp_client.app_id,
				qbt_opp_client.conn_id,
				(bt_pf_opp_handle_type)qbt_opp_server.fs_handle,
				(byte*)data_ptr,
				data_len,
				cmd_status_rsp);

	// make mbt event
	mbt_postevent(mbt_evt, 0);
}

MBT_VOID qbt_proc_evt_opp_srv_write_req(bt_pf_ev_opp_srv_write_req_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	bt_cmd_status_type cmd_status_rsp;
	T_MBTEVT		mbt_evt;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_srv_write> size:%d hndl:%x store:%x", bt_ev_msg_ptr->buffer_len, qbt_opp_server.fs_handle, sdcOppStatus->ReceivingFile.StorageType);

	cmd_status_rsp = mbt_opp_write(&qbt_opp_server,
				&sdcOppStatus->ReceivingFile,
				bt_ev_msg_ptr->buffer_ptr,
				bt_ev_msg_ptr->buffer_len);
	cmd_status = bt_cmd_pf_opp_srv_write_done(qbt_opp_server.app_id,
				qbt_opp_server.conn_id,
				(bt_pf_opp_handle_type)qbt_opp_server.fs_handle,
				cmd_status_rsp);
	if ( cmd_status_rsp == OI_OK )
	{
		mbt_evt = MBTEVT_OPP_SERVER_PROGRESSIVE_UPDATE;
		sdcOppStatus->TxProgress = qbt_opp_server.sent_size;
		MBT_PI("mbt opp : succ recv : %d/%d", sdcOppStatus->TxProgress, sdcOppStatus->ReceivingFile.ObjectSize, 0);
	}
	else
	{
		//qbt ���� disconnect�� ���ְ� ����. 
		bt_cmd_pf_opp_srv_force_disconnect( qbt_opp_server.app_id, qbt_opp_server.conn_id);
		mbt_evt = MBTEVT_OPP_SERVER_PULL_FAIL;
	}
	// make mbt event
	mbt_postevent(mbt_evt, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_Server_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
*	Description : QBT Opp server callback function
********************************************************************************/
static MBT_VOID mbt_opp_Server_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{
	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
			MBT_PI("mbt_opp_srv_cmd_done> cmd:%x status:%x", bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type, bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status, 0);
	      		break;

  		case BT_EV_PF_OPP_SRV_CON_IND:
			qbt_proc_evt_opp_srv_con_ind(&bt_ev_msg_ptr->ev_msg.ev_opp_srv_con_ind);
			break;

  		case BT_EV_PF_OPP_SRV_DCN_IND:
			qbt_proc_evt_opp_srv_dcn_ind(&bt_ev_msg_ptr->ev_msg.ev_opp_srv_dcn_ind);
			break;

  		case BT_EV_PF_OPP_SRV_OPEN_READ_REQ:
			qbt_proc_evt_opp_srv_open_read_req(&bt_ev_msg_ptr->ev_msg.ev_opp_srv_open_read_req);
			break;

  		case BT_EV_PF_OPP_SRV_OPEN_WRITE_REQ:
			qbt_proc_evt_opp_srv_open_write_req(&bt_ev_msg_ptr->ev_msg.ev_opp_srv_open_write_req);
			break;

	  	case BT_EV_PF_OPP_SRV_CLOSE_REQ:
			qbt_proc_evt_opp_srv_close_req(&bt_ev_msg_ptr->ev_msg.ev_opp_srv_close_req);
			break;

  		case BT_EV_PF_OPP_SRV_READ_REQ://���۵����� �ϱ� ��û. ���� ���� ?? 
			qbt_proc_evt_opp_srv_read_req(&bt_ev_msg_ptr->ev_msg.ev_opp_srv_read_req);
			break;

  		case BT_EV_PF_OPP_SRV_WRITE_REQ:
			qbt_proc_evt_opp_srv_write_req(&bt_ev_msg_ptr->ev_msg.ev_opp_srv_write_req);
			break;

		default:
			MBT_ERR("mbt_opp_srv_unknown> evt:%d", bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0);
			break;
  	}
}

#ifdef MBT_OPP_USE_SCN_SEARCH
MBT_VOID qbt_proc_evt_opp_scn_resp(bt_ev_sd_server_channel_number_resp_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_sd_succ> get scn success. scn:%x oper:%x state:%x",bt_ev_msg_ptr->scn, sdcOppStatus->Operation, sdcOppStatus->OppState);
	qbt_opp_client.scn = bt_ev_msg_ptr->scn;
	cmd_status = bt_cmd_pf_opp_cli_connect(qbt_opp_client.app_id,
				&bt_ev_msg_ptr->bd_addr,
				qbt_opp_client.scn);

	if (cmd_status != BT_CS_GN_PENDING && cmd_status != BT_CS_GN_SUCCESS) 
	{
		MBT_PI("[OPP] bt_cmd_pf_opp_cli_connect was FAIL(%d)", cmd_status, 0, 0);
		//System_BT_Event_OPP_UI_Client_Push_Complete(CLIENT_PUSH_FAIL);
		mbt_opp_send_fail_evt(sdcOppStatus->Operation);
		//sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
		//qbt_opp_client.conn_id = BT_PF_OPP_NO_CONN_ID;
		qbt_opp_client.scn = 0;
	}
}

MBT_VOID qbt_proc_evt_opp_sd_error_resp(bt_ev_sd_error_resp_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_ERR("mbt_opp_sd_fail> get scn fail. err_code :%x oper:%x state:%x",bt_ev_msg_ptr->error_code, sdcOppStatus->Operation, sdcOppStatus->OppState);
	sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
	mbt_gap_restore_role_switch(sdcOppStatus->BDAddr);
	mbt_opp_send_fail_evt(sdcOppStatus->Operation);
	qbt_opp_client.scn = 0;
}

MBT_VOID qbt_proc_evt_opp_sd_timeout_resp(bt_ev_sd_timeout_resp_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_ERR("mbt_opp_sd_fail> get scn timeout. oper:%x state:%x", sdcOppStatus->Operation, sdcOppStatus->OppState, 0);
	sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
	mbt_opp_send_fail_evt(sdcOppStatus->Operation);
	qbt_opp_client.scn = 0;
}
#endif

MBT_VOID qbt_proc_evt_opp_cli_con_cfm(bt_pf_ev_opp_cli_con_cfm_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	if (bt_ev_msg_ptr->status != OI_OK) 
	{
		// ���� ó��
		MBT_PI("[OPP] Client_Connect_Cfm NEGITIVE (%d)", bt_ev_msg_ptr->status, 0, 0);
		//mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_FAIL, 0);
		mbt_gap_restore_role_switch(sdcOppStatus->BDAddr);
		mbt_opp_send_fail_evt(sdcOppStatus->Operation);
		qbt_opp_client.conn_id = BT_PF_OPP_NO_CONN_ID;
		sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
		qbt_opp_client.scn = 0;
		//dkmoon 2006-10-10 opp problem [XP BT driver]
		//mbt_gap_restore_role_switch(NULL, NULL); =>>>>>>>>>>>>>>>>>>>
		//dkmoon 2006-10-10 
		//return System_BT_OPP_CheckCmdStatus(con_cfm->status);
	}
	else 
	{
		MBT_PI("[OPP] Client_Connect_Cfm SUCCESS (%d)", bt_ev_msg_ptr->status, 0, 0);
		qbt_opp_client.conn_id = bt_ev_msg_ptr->conn_id;
		sdcOppStatus->OppState = MBT_OPP_STATE_CONNECTED;

		if(need_disconnect == TRUE) 
		{
			MBT_PI("[OPP] Need Disconnect", 0, 0, 0);
			mbt_opp_client_disconnect();
			//mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_FAIL, 0);
			mbt_opp_send_fail_evt(sdcOppStatus->Operation);
			//return System_BT_OPP_CheckCmdStatus(con_cfm->status);
		}
		else
		{
			//pancho: add connect confirm event for ui 2007/01/20
			//System_BT_Event_OPP_UI_Client_Connect_Confirm();
			mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
			if ( sdcOppStatus->Operation == MBT_OPC_PUSH )
			{
				//mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
				sdcOppStatus->OppState = MBT_OPP_STATE_SENDING;
				if(BT_PF_MAX_FILENAME_LEN -1 < mbt_utf8_to_ucs2(sdcOppStatus->SendingFile.FileName,
							strlen(sdcOppStatus->SendingFile.FileName),
							name_str, sizeof(name_str)))
				{
					mbt_opp_cutFileNameOneByte(name_str);
				}
				cmd_status = bt_cmd_pf_opp_cli_push(qbt_opp_client.app_id,
							qbt_opp_client.conn_id, name_str, "");
				if (cmd_status != BT_CS_GN_PENDING && cmd_status != BT_CS_GN_SUCCESS) 
				{
					MBT_PI("[OPP] bt_cmd_pf_opp_cli_push was FAIL (%d)", cmd_status, 0, 0);
					mbt_opp_send_fail_evt(sdcOppStatus->Operation);
					mbt_opp_client_disconnect();
				}
				
			}
			else if ( sdcOppStatus->Operation == MBT_OPC_PULL )
			{
				//mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
				sdcOppStatus->OppState = MBT_OPP_STATE_PULLING;
				cmd_status = bt_cmd_pf_opp_cli_pull(qbt_opp_client.app_id, qbt_opp_client.conn_id);
			}
			else if ( sdcOppStatus->Operation == MBT_OPC_EXCH_PUSH )
			{
				mbt_gap_allow_role_switch(sdcOppStatus->BDAddr);
				sdcOppStatus->OppState = MBT_OPP_STATE_SENDING;
				if(BT_PF_MAX_FILENAME_LEN -1 < mbt_utf8_to_ucs2(sdcOppStatus->SendingFile.FileName,
							strlen(sdcOppStatus->SendingFile.FileName),
							name_str, sizeof(name_str)))
				{
					mbt_opp_cutFileNameOneByte(name_str);
				}
				cmd_status = bt_cmd_pf_opp_cli_push(qbt_opp_client.app_id,
							qbt_opp_client.conn_id, name_str, "");
				if (cmd_status != BT_CS_GN_PENDING && cmd_status != BT_CS_GN_SUCCESS) 
				{
					MBT_PI("[OPP] bt_cmd_pf_opp_cli_push was FAIL (%d)", cmd_status, 0, 0);
					mbt_opp_send_fail_evt(sdcOppStatus->Operation);
					mbt_opp_client_disconnect();
				}
			}
		}
	}
/*
	if ( bt_ev_msg_ptr->status == BT_CS_GN_SUCCESS )
	{
		MBT_PI("mbt_opp_con_succ> conn_id:%x oper:%x state:%x", bt_ev_msg_ptr->conn_id, sdcOppStatus->Operation, sdcOppStatus->OppState);
//				mbt_gap_contable_add(sdcOppStatus->BDAddr, MBT_SVCUUID_OBEX_OBJECT_PUSH);
		sdcOppStatus->OppState = MBT_OPP_STATE_CONNECTED;
		qbt_opp_client.conn_id = bt_ev_msg_ptr->conn_id;

		if ( sdcOppStatus->Operation == MBT_OPC_PUSH )
		{
			sdcOppStatus->OppState = MBT_OPP_STATE_SENDING;
			mbt_utf8_to_ucs2(sdcOppStatus->SendingFile.FileName,
						strlen(sdcOppStatus->SendingFile.FileName),
						name_str, sizeof(name_str));
			cmd_status = bt_cmd_pf_opp_cli_push(qbt_opp_client.app_id,
						qbt_opp_client.conn_id, name_str, "");
		}
		else if ( sdcOppStatus->Operation == MBT_OPC_PULL )
		{
			sdcOppStatus->OppState = MBT_OPP_STATE_PULLING;
			cmd_status = bt_cmd_pf_opp_cli_pull(qbt_opp_client.app_id, qbt_opp_client.conn_id);
		}
		else if ( sdcOppStatus->Operation == MBT_OPC_EXCH_PUSH )
		{
			sdcOppStatus->OppState = MBT_OPP_STATE_SENDING;
			mbt_utf8_to_ucs2(sdcOppStatus->SendingFile.FileName,
						strlen(sdcOppStatus->SendingFile.FileName),
						name_str, sizeof(name_str));
			cmd_status = bt_cmd_pf_opp_cli_push(qbt_opp_client.app_id,
						qbt_opp_client.conn_id, name_str, "");
		}
	}
	else
	{
		MBT_ERR("mbt_opp_con_fail> status:%x oper:%x state:%x", bt_ev_msg_ptr->status, sdcOppStatus->Operation, sdcOppStatus->OppState);
		sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;

		// send fail event
		if ( sdcOppStatus->Operation == MBT_OPC_PUSH )
			mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_FAIL, 0);
		else if ( sdcOppStatus->Operation == MBT_OPC_PULL )
			mbt_postevent(MBTEVT_OPP_CLIENT_PULL_FAIL, 0);
		else if ( sdcOppStatus->Operation == MBT_OPC_EXCH_PUSH )
			mbt_postevent(MBTEVT_OPP_CLIENT_EXCH_FAIL, 0);
	}
*/

}

MBT_VOID qbt_proc_evt_opp_cli_dcn_cfm(bt_pf_ev_opp_cli_dcn_cfm_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_disc> conn_id:%x stat:%x op_state:%x", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->status, sdcOppStatus->OppState);
	mbt_gap_restore_role_switch(sdcOppStatus->BDAddr);
	sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
	qbt_opp_client.conn_id = BT_PF_OPP_NO_CONN_ID;
	qbt_opp_client.scn = 0;
	isOnAborting = FALSE;
	//mbt_gap_restore_role_switch(NULL, NULL);=>>>>>>>>>>>>>>>>>>>
/*
	MBT_PI("mbt_opp_disc> conn_id:%x stat:%x op_state:%x", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->status, sdcOppStatus->OppState);
//			mbt_gap_contable_remove(sdcOppStatus->BDAddr, MBT_SVCUUID_OBEX_OBJECT_PUSH);
	sdcOppStatus->OppState = MBT_OPP_STATE_IDLE;
	qbt_opp_client.conn_id = BT_PF_OPP_NO_CONN_ID;
	qbt_opp_client.scn = 0;
	mbt_postevent(MBTEVT_OPP_CLIENT_DISCONNECT, 0);
*/

}

MBT_VOID qbt_proc_evt_opp_cli_psh_dne(bt_pf_ev_opp_cli_push_done_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_push_done> status:%x oper:%x state:%x", bt_ev_msg_ptr->status, sdcOppStatus->Operation, sdcOppStatus->OppState);
	MBT_PI( "[OPP] Client_Push_Done, Status: %d, Conn: %d",
		bt_ev_msg_ptr->status, bt_ev_msg_ptr->conn_id, 0 );

	//sdcOppStatus->TxProgress = 0;
	if (bt_ev_msg_ptr->status== BT_CS_GN_SUCCESS)
	{
		mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_SUCCESS, 0);
	}
	else
	{
		mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_FAIL, 0);
		mbt_opp_send_fail_evt(sdcOppStatus->Operation);
		//�̰�찡 �߻��ϴ��� Ȯ�� �� close ind�� ���� �ϳ��� ���� �� ��. 
	}
}

MBT_VOID qbt_proc_evt_opp_cli_pul_dne(bt_pf_ev_opp_cli_pull_done_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_pull_done> status:%x oper:%x state:%x", bt_ev_msg_ptr->status, sdcOppStatus->Operation, sdcOppStatus->OppState);

	if (bt_ev_msg_ptr->status== BT_CS_GN_SUCCESS)
	{
		mbt_postevent(MBTEVT_OPP_CLIENT_PULL_SUCCESS, 0);
	}
	else
	{
		//mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_FAIL, 0);
		mbt_opp_send_fail_evt(sdcOppStatus->Operation);
		//�̰�찡 �߻��ϴ��� Ȯ�� �� close ind�� ���� �ϳ��� ���� �� ��. 
	}
}

MBT_VOID qbt_proc_evt_opp_cli_open_read_req(bt_pf_ev_opp_cli_open_read_req_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	bt_cmd_status_type cmd_status_rsp;
	T_MBTEVT mbt_evt;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_cli_open_read> name_len:%d oper:%x state:%x", bt_ev_msg_ptr->name_len, sdcOppStatus->Operation, sdcOppStatus->OppState);
	//conn_id = open_read_req->conn_id;
		MBT_PI( "BT_EV_PF_OPP_CLI_OPEN_READ_REQ: cli open read req, Conn: %x",  
				bt_ev_msg_ptr->conn_id, 0, 0 );
	//name�� full path ���� Ȯ�� �� ��....
	cmd_status_rsp = mbt_opp_open_read(&qbt_opp_client, &sdcOppStatus->SendingFile,
			(MBT_SHORT*)bt_ev_msg_ptr->name_str,
			bt_ev_msg_ptr->name_len);
	qbt_opp_client.sent_size = 0;
	if ( cmd_status_rsp !=  OI_OK && sdcOppStatus->OppState != MBT_OPP_STATE_SENDING)
	{
		MBT_WARN("unexpected oppstate or read fail cmd_status_rsp:%d, oppstate:%d", cmd_status_rsp,sdcOppStatus->OppState,0); 
		cmd_status = bt_cmd_pf_opp_cli_open_read_done(qbt_opp_client.app_id,
					qbt_opp_client.conn_id,
					(bt_pf_opp_handle_type)qbt_opp_client.fs_handle,
					(uint16*)bt_ev_msg_ptr->name_str,
					bt_ev_msg_ptr->type_str,
					sdcOppStatus->SendingFile.ObjectSize,
					cmd_status_rsp);
		mbt_evt = MBTEVT_OPP_CLIENT_PUSH_FAIL;
		mbt_opp_client_disconnect();
	}
	cmd_status = bt_cmd_pf_opp_cli_open_read_done(qbt_opp_client.app_id,
				qbt_opp_client.conn_id,
				(bt_pf_opp_handle_type)qbt_opp_client.fs_handle,
				(uint16*)bt_ev_msg_ptr->name_str,
				bt_ev_msg_ptr->type_str,
				sdcOppStatus->SendingFile.ObjectSize,
				cmd_status_rsp);
	if (cmd_status != BT_CS_GN_PENDING && cmd_status != BT_CS_GN_SUCCESS) 
	{
		MBT_WARN("[OPP] bt_cmd_pf_opp_cli_open_read_done was FAIL(%d)", cmd_status, 0, 0);
		mbt_evt = MBTEVT_OPP_CLIENT_PUSH_FAIL;
		mbt_opp_client_disconnect();
	}
	else
	{
		mbt_evt =MBTEVT_OPP_CLIENT_PUSH_START;
	}
	mbt_postevent(mbt_evt,0);
}

MBT_VOID qbt_proc_evt_opp_cli_open_write_req(bt_pf_ev_opp_cli_open_write_req_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	bt_cmd_status_type cmd_status_rsp;
	T_MBTEVT		mbt_evt;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_cli_open_write> name_len:%d obj_size:%d state:%x", bt_ev_msg_ptr->name_len, bt_ev_msg_ptr->obj_size, sdcOppStatus->OppState);

	// store received name
	mbt_ucs2_to_utf8((MBT_SHORT*)bt_ev_msg_ptr->name_str,
				bt_ev_msg_ptr->name_len,
				sdcOppStatus->ReceivingFile.FileName,
				sizeof(sdcOppStatus->ReceivingFile.FileName));

	// open file
	cmd_status_rsp = mbt_opp_open_write(&qbt_opp_client,
				&sdcOppStatus->ReceivingFile,
				NULL,
				0);

	if ( cmd_status_rsp == OI_OK )
		mbt_evt = MBTEVT_OPP_CLIENT_PULL_START;
	else
		mbt_evt = MBTEVT_OPP_CLIENT_PULL_FAIL;

	qbt_opp_client.sent_size = 0;
	sdcOppStatus->ReceivingFile.ObjectSize = bt_ev_msg_ptr->obj_size;

	// reply to stack
	cmd_status = bt_cmd_pf_opp_cli_open_write_done(qbt_opp_client.app_id,
				qbt_opp_client.conn_id,
				(bt_pf_opp_handle_type)qbt_opp_client.fs_handle,
				cmd_status_rsp);

	// make mbt event
	mbt_postevent(mbt_evt, 0);
}

MBT_VOID qbt_proc_evt_opp_cli_close_req(bt_pf_ev_opp_cli_close_req_type *bt_ev_msg_ptr)
{
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);
	fs_rsp_msg_type fs_rsp;

	MBT_PI("mbt_opp_close_req> hndl:%x status:%x", qbt_opp_client.fs_handle, bt_ev_msg_ptr->status, 0);
	if ( sdcOppStatus->SendingFile.StorageType == MBT_MEMORY_BUFFER )
	{
	}
	else
	{
		fs_close(qbt_opp_client.fs_handle, NULL, &fs_rsp);
		MBT_PI("mbt_opp_close_req> close_fs hndl:%x res:%x", qbt_opp_client.fs_handle, fs_rsp.close.status, 0);
		qbt_opp_client.fs_handle = 0;
	}
	if(sdcOppStatus->OppState == MBT_OPP_STATE_SENDING)
		sdcOppStatus->OppState = MBT_OPP_STATE_CONNECTED;
	if( bt_ev_msg_ptr->status == BT_CS_PF_OBEX_CLIENT_ABORTED_COMMAND)
	{
		MBT_PI("[OPP] reason: ABORT !!!", 0, 0, 0);
		//mbt_postevent(MBTEVT_OPP_CLIENT_PUSH_FAIL, 0); //�� �̺�Ʈ�� �ʿ��Ѱ�. ������ push done���� �÷������ٵ�...
		//mbt_opp_send_fail_evt(sdcOppStatus->Operation);
	 }
}

MBT_VOID qbt_proc_evt_opp_cli_read_req(bt_pf_ev_opp_cli_read_req_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	bt_cmd_status_type cmd_status_rsp;
	T_MBTEVT		mbt_evt;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);
	MBT_BYTE	*data_ptr;
	MBT_UINT	data_len;

	MBT_PI("mbt_opp_read_req> max_read:%d oper:%x state:%x", bt_ev_msg_ptr->max_read, sdcOppStatus->Operation, sdcOppStatus->OppState);

	// calculate progress rate
	if ( sdcOppStatus->Operation != MBT_OPC_PUSH )
	{
		MBT_ERR("mbt_opp_cli_read> invalid stat oper:%x stat:%x", sdcOppStatus->Operation, sdcOppStatus->OppState, 0);
	}
	cmd_status_rsp = mbt_opp_read(&qbt_opp_client, &sdcOppStatus->SendingFile, bt_ev_msg_ptr->max_read, &data_ptr, &data_len);
	
	if ( (cmd_status_rsp == OI_OK || cmd_status_rsp == OI_STATUS_END_OF_FILE) && sdcOppStatus->OppState == MBT_OPP_STATE_SENDING )
	{
		MBT_PI("mbt opp : succ send : %d/%d", sdcOppStatus->TxProgress, sdcOppStatus->SendingFile.ObjectSize, 0);
		sdcOppStatus->TxProgress = qbt_opp_client.sent_size;
		mbt_evt = MBTEVT_OPP_CLIENT_PROGRESSIVE_UPDATE;
		cmd_status = bt_cmd_pf_opp_cli_read_done(qbt_opp_client.app_id,
				qbt_opp_client.conn_id,
				(bt_pf_opp_handle_type)qbt_opp_client.fs_handle,
				(byte*)data_ptr,
				data_len,
				cmd_status_rsp);
	}
	else 
	{
		mbt_evt = MBTEVT_OPP_CLIENT_PUSH_FAIL;
		//abort�� ������ �ϴ°� ??  
		cmd_status = bt_cmd_pf_opp_cli_read_done(qbt_opp_client.app_id,
					qbt_opp_client.conn_id,
					(bt_pf_opp_handle_type)qbt_opp_client.fs_handle,
					NULL, 
					data_len,
					cmd_status_rsp);
		if(isOnAborting != TRUE)
		{
			mbt_opp_client_disconnect();
		}
	}

	// make mbt event
	mbt_postevent(mbt_evt, 0);
}

MBT_VOID qbt_proc_evt_opp_cli_write_req(bt_pf_ev_opp_cli_write_req_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	bt_cmd_status_type cmd_status_rsp;
	T_MBTEVT		mbt_evt;
	T_MBT_OPP_STATUS * sdcOppStatus = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);

	MBT_PI("mbt_opp_cli_write> size:%d hndl:%x store:%x", bt_ev_msg_ptr->buffer_len, qbt_opp_client.fs_handle, sdcOppStatus->ReceivingFile.StorageType);

	cmd_status_rsp= mbt_opp_write(&qbt_opp_client, &sdcOppStatus->ReceivingFile, bt_ev_msg_ptr->buffer_ptr, bt_ev_msg_ptr->buffer_len);

	if ( cmd_status_rsp == OI_OK )
	{
		sdcOppStatus->RxProgress = qbt_opp_client.sent_size;
		mbt_evt = MBTEVT_OPP_CLIENT_PROGRESSIVE_UPDATE;
		MBT_PI("mbt opp : succ read : %d/%d", sdcOppStatus->RxProgress, sdcOppStatus->ReceivingFile.ObjectSize, 0);
	}
	else
		mbt_evt = MBTEVT_OPP_CLIENT_PULL_FAIL;

	cmd_status = bt_cmd_pf_opp_cli_write_done(qbt_opp_client.app_id,
				qbt_opp_client.conn_id,
				(bt_pf_opp_handle_type)qbt_opp_client.fs_handle,
				cmd_status_rsp);

	// make mbt event
	mbt_postevent(mbt_evt, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_Client_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
*	Description : QBT Opp client callback function
********************************************************************************/
static MBT_VOID mbt_opp_Client_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{
	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
			MBT_PI("mbt_opp_cli_cmd_done> cmd:%x status:%x", bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type, bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status, 0);
	      		break;

#ifdef MBT_OPP_USE_SCN_SEARCH
		case BT_EV_SD_SERVER_CHANNEL_NUMBER_RESP:
			qbt_proc_evt_opp_scn_resp(&bt_ev_msg_ptr->ev_msg.ev_sd_scn_resp);
			break;

		case BT_EV_SD_ERROR_RESP:
			qbt_proc_evt_opp_sd_error_resp(&bt_ev_msg_ptr->ev_msg.ev_sd_error_resp);
			break;

		case BT_EV_SD_TIMEOUT_RESP:
			qbt_proc_evt_opp_sd_timeout_resp(&bt_ev_msg_ptr->ev_msg.ev_sd_timeout_resp);
			break;
#endif

		case BT_EV_PF_OPP_CLI_CON_CFM:
			qbt_proc_evt_opp_cli_con_cfm(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_con_cfm);
			break;

		case BT_EV_PF_OPP_CLI_DCN_CFM:
			qbt_proc_evt_opp_cli_dcn_cfm(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_dcn_cfm);
			break;

		case BT_EV_PF_OPP_CLI_PSH_DNE:
			qbt_proc_evt_opp_cli_psh_dne(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_push_done);
			break;

		case BT_EV_PF_OPP_CLI_PUL_DNE:
			qbt_proc_evt_opp_cli_pul_dne(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_pull_done);
			break;

		case BT_EV_PF_OPP_CLI_OPEN_READ_REQ:
			qbt_proc_evt_opp_cli_open_read_req(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_open_read_req);
			break;

		case BT_EV_PF_OPP_CLI_OPEN_WRITE_REQ:
			qbt_proc_evt_opp_cli_open_write_req(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_open_write_req);
			break;
			
		case BT_EV_PF_OPP_CLI_CLOSE_REQ:
			qbt_proc_evt_opp_cli_close_req(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_close_req);
			break;

		case BT_EV_PF_OPP_CLI_READ_REQ:
			qbt_proc_evt_opp_cli_read_req(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_read_req);
			break;

		case BT_EV_PF_OPP_CLI_WRITE_REQ:
			qbt_proc_evt_opp_cli_write_req(&bt_ev_msg_ptr->ev_msg.ev_opp_cli_write_req);
			break;

		default:
			MBT_ERR("mbt_opp_cli_unknown> evt:%d", bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0);
			break;
	}
}
#endif

/********************************************************************************
*	Prototype	: MBT_VOID mbt_opp_init(MBT_VOID)
*	Description : opp initialize
********************************************************************************/
MBT_VOID mbt_opp_init(MBT_VOID)
{
	//Clien side
	if (qbt_opp_client.app_id == BT_APP_ID_NULL) 
	{
		qbt_opp_client.app_id = bt_cmd_ec_get_app_id_and_register(mbt_opp_Client_EventCallback);
		if (qbt_opp_client.app_id == BT_APP_ID_NULL) 
		{
			MBT_ERR("OPP Client App id register error. app_id : NULL",0,0,0);
			mbt_postevent(MBTEVT_OPP_CLIENT_ENABLE_FAIL, 0);
			return;
		}
	}
	else
	{
		MBT_FATAL("##OPC Initialize Over time Error. app_id ");
	}

	//Server side
	if (qbt_opp_server.app_id == BT_APP_ID_NULL) 
	{
		qbt_opp_server.app_id = bt_cmd_ec_get_app_id_and_register(mbt_opp_Server_EventCallback);
		if (qbt_opp_server.app_id == BT_APP_ID_NULL) 
		{
			MBT_ERR("mbt_opp_server_enable> OPP Server App id register error. app_id : NULL",0,0,0);
			mbt_postevent(MBTEVT_OPP_SERVER_ENABLE_FAIL, 0);
			return;
		}
	}
	else
	{
		MBT_FATAL("##OPS Initialize Over time Error. app_id ");
	}
}
