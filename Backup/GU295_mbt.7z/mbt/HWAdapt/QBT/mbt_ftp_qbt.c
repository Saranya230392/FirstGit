/********************************************************************************
*	File Name	: mbt_ftp_brcm.c
*	Description	:
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.04.09		Kim,Hyunseok			Created
********************************************************************************/
#include "mbt_ftp.h"
#include "mbt_sdc.h"
#include "mbt_evhandler.h"
#include "mbt_gap.h"
#include "qbt_utils/qbt_fs.h"
#include "qbt_utils/qbt_lang.h"
#include "bt.h"
#include "btsd.h"
#include "fs_public.h"
#include "fs_parms.h"
#include "fs_sys_types.h"
#include "mbt_debugmsg.h"
#include "stdio.h"

//#define MBT_FTP_VIRTUAL_FOLDER FALSE
#define MBT_FTP_CUR_DIR_LOG
#define MBT_FTP_FILENAME_LOG

#if (MBT_FTP == MBT_TRUE)
typedef struct {
	bt_app_id_type		app_id;
	bt_pf_ftp_srv_conn_id_type conn_id;
	uint8				scn;
	fs_handle_type		fs_handle;
	MBT_UINT			done_size;
	MBT_CHAR			cur_dir[MBT_MAX_FILE_NAME_LEN];
#if MBT_FTP_VIRTUAL_FOLDER == FALSE
	MBT_CHAR			root_dir[MBT_MAX_FILE_NAME_LEN];
#endif
} mbt_qbt_ftp_object;

//static mbt_qbt_ftp_object qbt_ftp_client  = { BT_APP_ID_NULL, 0, 0, 0, 0 };
static mbt_qbt_ftp_object qbt_ftp_server = { BT_APP_ID_NULL, 0, 0, 0, 0 };
static MBT_BYTE mbt_qbt_ftp_buf[MBT_OBEX_FILE_BUF_LEN];

const char MBT_FTP_XML_VERSION[] 	= "<?xml version=\"1.0\"?>\n";
const char MBT_FTP_XML_DOCTYPE[] 	= "<!DOCTYPE folder-listing SYSTEM \"obex-folder-listing.dtd\">\n";
const char MBT_FTP_XML_LIST_OPEN[] 	= "<folder-listing version=\"1.0\">\n";
const char MBT_FTP_XML_LIST_CLOSE[] 	= "</folder-listing>\n";
const char MBT_FTP_XML_PARENT[] 		= "<parent-folder/>\n";
const char MBT_FTP_XML_FOLDER_OPEN[]	= "<folder ";
const char MBT_FTP_XML_FILE_OPEN[] 	= "<file ";
const char MBT_FTP_XML_NAME[] 		= "name=\"";
const char MBT_FTP_XML_SIZE[] 		= "size=\"";
const char MBT_FTP_XML_PERMISSION[]	= "user-perm=\"RWD\" ";
const char MBT_FTP_XML_MODIFIED[] 	= "modified=\"20040128T100808Z\" ";
const char MBT_FTP_XML_CREATED[] 	= "created=\"20040128T100808Z\" ";
const char MBT_FTP_XML_ACCESSED[] 	= "accessed=\"20040128T100808Z\" ";
const char MBT_FTP_XML_UNQUOTE[]	= "\" ";
const char MBT_FTP_XML_CLOSE[] 		= "/>\n";
#if MBT_FTP_VIRTUAL_FOLDER == FALSE
#define  MAX_INCLUDED_FOLDER_CNT				1
#define  MAX_EXCLUDED_FOLDER_CNT				2
const char includedFolderList[MAX_INCLUDED_FOLDER_CNT+1][32] = {
#if 0
	{"/LGAPP/Media/Sounds/"},
	{"/LGAPP/Media/Videos/"},
	{"/LGAPP/Media/Images/"},
	{"/LGAPP/Media/Others/"},
#else
	{"/LGAPP/Media/STD_Public"},
#endif	
	{""}
};
const char excludedFolderList[MAX_EXCLUDED_FOLDER_CNT+1][60] = {
#if 1
	{"/LGAPP/Media/STD_Public/Default files/"},
//	{"/LGAPP/Media/STD_Public/Default Files/Default Images/"},
//	{"/LGAPP/Media/STD_Public/Default Files/Default Sounds/"},
	{"/LGAPP/Media/STD_Public/LGSYS/"},
	{""}
#else
	{"/LGAPP/Media/Sounds/Default sounds/"},
	{"/LGAPP/Media/Images/Default images/"},
	{"/LGAPP/Media/Images/Avatars Visio/"},
	{"/LGAPP/Media/Sounds/Playlists/"},
	{""}
#endif
};

/*
char internalFileRoot[] = "/LGAPP/Media";
char externalFileRoot[] = "mmc1" ;
*/

#endif

MBT_BOOL mbt_ftp_CheckCmdStatus( bt_cmd_status_type stat );
MBT_VOID mbt_ftp_Server_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );
MBT_VOID mbt_ftp_Client_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );

#if MBT_FTP_VIRTUAL_FOLDER == TRUE
MBT_INT mbt_ftp_find_virtual_index(MBT_CHAR *p_path)
{
	T_MBT_FTP_STATUS* btFtpStatus = 	(T_MBT_FTP_STATUS*)	mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);
	MBT_SHORT i;
	for(i = 0; i < btFtpStatus->NumFTPDir; i++ )
	{
		if( strncmp( p_path, btFtpStatus->FTPDirName[i].VirtualDir, strlen(btFtpStatus->FTPDirName[i].VirtualDir)) == 0 )
		{
			return i;
		}
	}

	return -1;
}

MBT_INT mbt_ftp_find_real_index(MBT_CHAR *p_path)
{
	T_MBT_FTP_STATUS* btFtpStatus = 	(T_MBT_FTP_STATUS*)	mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);
	MBT_SHORT i;
	for(i = 0; i < btFtpStatus->NumFTPDir; i++ )
	{
		if( strncmp( p_path, btFtpStatus->FTPDirName[i].VirtualDir, strlen(btFtpStatus->FTPDirName[i].RealDir)) == 0 )
		{
			return i;
		}
	}

	return -1;
}
#else
MBT_BOOL mbt_ftp_check_valid_folder_for_browsing(MBT_CHAR* path, MBT_BOOL isRoot)
{	
	MBT_SHORT i = 0;
	MBT_BOOL ret = FALSE;

//	if(isRoot == TRUE)	//root
	if(FALSE)
	{
		while(includedFolderList[i][0])
		{
			// only include folder is allowed in root folder
			if(!strcmp(path, (const char*)includedFolderList[i]))
			{
				ret = TRUE;
				break;
			}
			i++;
		}
		if(includedFolderList[i][0] == 0x00)
			ret = FALSE;
	}
	else
	{
		ret = TRUE;
		while(excludedFolderList[i][0])
		{
			// exclude folder is not allowed in non root folder
			if(!strcmp(path, (const char*)excludedFolderList[i]))
			{
				ret = FALSE;
				break;
			}
			i++;
		}
		if(excludedFolderList[i][0] == 0x00)
			ret = TRUE;
	}
	return ret;
}

boolean mbt_ftp_is_root(
	MBT_CHAR* cur_folder_name)
{
	if(!strncmp(cur_folder_name, qbt_ftp_server.root_dir, strlen(cur_folder_name)-1))
		return TRUE;
	else 
		return FALSE;
}

#endif

LOCAL bt_cmd_status_type mbt_ftp_make_browse_list(MBT_CHAR *filename)
{
	bt_cmd_status_type cmd_status;
	EFSDIR *dir_handle;
	struct fs_dirent	*enum_dir_name_ptr;
	struct fs_stat		enum_file_stat;
	MBT_UINT	buf_len;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);
	fs_handle_type fs_handle;
	fs_rsp_msg_type  fs_rsp;
	MBT_SHORT dirname_len;
	MBT_CHAR fullPath[MBT_MAX_FILE_NAME_LEN] = {0,};
	//MBT_CHAR utf8_filename[MBT_MAX_FILE_NAME_LEN] = {0,};

	// open file for result XML
	cmd_status = qbt_file_open_write(&fs_handle, filename);
	if ( cmd_status != OI_OK )
	{
		MBT_ERR("fail make browse list", 0, 0, 0);
		return cmd_status;
	}
/*
	// get local string for current dir
	memset(local_dirname, 0, sizeof(local_dirname));
	dirname_len = mbt_utf8_to_local(qbt_ftp_server.cur_dir,
				strlen(qbt_ftp_server.cur_dir),
				local_dirname, sizeof(local_dirname), '_');
	if ( local_dirname[dirname_len-1] != '/' )
		local_dirname[dirname_len++] ='/';
*/
//	strcpy(local_dirname, qbt_ftp_server.cur_dir);
	// open current dir
	dir_handle = efs_opendir(qbt_ftp_server.cur_dir);
	if ( dir_handle == NULL )
	{
		MBT_ERR("make browse list", 0, 0, 0);
		fs_close(fs_handle, NULL, &fs_rsp);
		return OI_FAIL;
	}

	// write header info
	qbt_file_write( fs_handle, (byte*)MBT_FTP_XML_VERSION, sizeof( MBT_FTP_XML_VERSION)-1 );
  	qbt_file_write( fs_handle, (byte*)MBT_FTP_XML_DOCTYPE, sizeof( MBT_FTP_XML_DOCTYPE )-1 );
  	qbt_file_write( fs_handle, (byte*)MBT_FTP_XML_LIST_OPEN, sizeof( MBT_FTP_XML_LIST_OPEN )-1 );

	// write parent element when not root
	//�̰� ���� ivt���� listing�� �ȵȴ�.
//	if ( !(local_dirname[0] == '/' && local_dirname[1] == 0) )
	if(!mbt_ftp_is_root(qbt_ftp_server.cur_dir))
		qbt_file_write( fs_handle, (byte*)MBT_FTP_XML_PARENT, sizeof( MBT_FTP_XML_PARENT)-1 );

	buf_len = 0;
	while ( (enum_dir_name_ptr = efs_readdir( dir_handle )) != NULL )
	{
		MBT_PI("make browse list : read one %c %c", enum_dir_name_ptr->d_name[0], enum_dir_name_ptr->d_name[1], 0);
		// skip current dir and parent dir
		if (enum_dir_name_ptr->d_name[0] == '.')
		{
      			continue;
		}
//		if(strcmp(enum_dir_name_ptr->d_name, (char*)"folder_browsing.idx") == 0)
		if(strcmp(enum_dir_name_ptr->d_name, sdcFtpStatus->TargetFile.FileName) == 0)
		{
			continue;
    	}

		strcpy(fullPath, qbt_ftp_server.cur_dir);
		strcat(fullPath, enum_dir_name_ptr->d_name);
		

		// get dir/file info
		if(qbt_ftp_server.cur_dir[0] == '/' )
		{
			if(efs_stat(fullPath, &enum_file_stat) < 0 )
			{
				MBT_ERR( "[UTIL] make browse list : fs_nametest failed on browse err:%x", fs_rsp.nametest.status, 0, 0 );
				continue;
			}
		}
		else
		{
			 enum_file_stat.st_mode = enum_dir_name_ptr->d_stat.st_mode;
			 enum_file_stat.st_size = enum_dir_name_ptr->d_stat.st_size;
			 enum_file_stat.st_mtime = enum_dir_name_ptr->d_stat.st_mtime;
		}

		MBT_PI("list dir : namelen:%d mode:%x mtime:%x", strlen(enum_dir_name_ptr->d_name), enum_file_stat.st_mode, enum_file_stat.st_mtime);

		// get utf8 string of each dir/file name
	//	memset(utf8_filename, 0, sizeof(utf8_filename));
	//	mbt_local_to_utf8(enum_dir_name_ptr->d_name,
	//				strlen(enum_dir_name_ptr->d_name),
	//				utf8_filename, sizeof(utf8_filename));

		// expect buffer overflow size
		if ( buf_len + strlen(enum_dir_name_ptr->d_name) + 32 > sizeof(mbt_qbt_ftp_buf) )
		{
	      		qbt_file_write( fs_handle, (byte*)mbt_qbt_ftp_buf, buf_len );
	      		buf_len = 0;
		}

		// make dir/file element string
		if ( S_ISDIR( enum_file_stat.st_mode ) )
		{
			//file system Ư���� ���� '/'�� ���� ���� ���� ���� �ֱ⶧���� '/' üũ�� ����.
			dirname_len = strlen(fullPath);
			if(fullPath[dirname_len-1] != '/' )
			{
				fullPath[dirname_len++] ='/';
				fullPath[dirname_len] = 0x00;
			}
			if ( qbt_ftp_server.cur_dir[0] == '/' )
			{
				if(!mbt_ftp_check_valid_folder_for_browsing(fullPath,mbt_ftp_is_root(qbt_ftp_server.cur_dir)))
					continue;
			}

//			sprintf( (char*)mbt_qbt_ftp_buf, "%s%s%s%s%s%s%s%s\0",
			sprintf( (char*)&mbt_qbt_ftp_buf[buf_len], "%s%s%s%s%s\0",
				MBT_FTP_XML_FOLDER_OPEN,
				MBT_FTP_XML_NAME,
				enum_dir_name_ptr->d_name,
				MBT_FTP_XML_UNQUOTE,
//				MBT_FTP_XML_PERMISSION,
//				MBT_FTP_XML_CREATED,
//				MBT_FTP_XML_MODIFIED,
				MBT_FTP_XML_CLOSE );
		}
		else if ( S_ISREG( enum_file_stat.st_mode ) )
		{
			if(mbt_ftp_is_root(qbt_ftp_server.cur_dir) && qbt_ftp_server.cur_dir[0] == '/')
			{
//#ifndef FOR_BLUETOOTH_SIG
//				continue;
//#endif
			}

//			sprintf( (char*)mbt_qbt_ftp_buf, "%s%s%s%s%s%ld%s%s%s%s%s\0",
			sprintf( (char*)&mbt_qbt_ftp_buf[buf_len], "%s%s%s%s%s%ld%s%s\0",
				MBT_FTP_XML_FILE_OPEN,
				MBT_FTP_XML_NAME,
				enum_dir_name_ptr->d_name,
				MBT_FTP_XML_UNQUOTE,
				MBT_FTP_XML_SIZE,
				enum_file_stat.st_size,
				MBT_FTP_XML_UNQUOTE,
//				MBT_FTP_XML_PERMISSION,
//				MBT_FTP_XML_CREATED,
//				MBT_FTP_XML_MODIFIED,
				MBT_FTP_XML_CLOSE );
		}
		else
		{
			continue;
		}

		buf_len += strlen((char*)&mbt_qbt_ftp_buf[buf_len]);
    }

	if ( buf_len > 0 )
  		qbt_file_write( fs_handle, (byte*)mbt_qbt_ftp_buf, buf_len );


	// close dir/file list info
	efs_closedir( dir_handle );

	// write xml close
	qbt_file_write( fs_handle, (byte*)MBT_FTP_XML_LIST_CLOSE, sizeof( MBT_FTP_XML_LIST_CLOSE )-1 );

	// close xml file
	fs_close(fs_handle, NULL, &fs_rsp);

  	return(OI_OK);
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_server_enable (MBT_VOID)
*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_server_enable (MBT_VOID)
{
	bt_cmd_status_type cmd_status;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	// FTP SERVER app id register
	
	if(sdcFtpStatus->bServerEnabled == MBT_FALSE)
	{
		cmd_status = bt_cmd_pf_ftp_srv_register( qbt_ftp_server.app_id,
					BT_PF_GOEP_SRV_AUTH_NONE, FALSE, TRUE, "LGE FTP Server");

		if(mbt_ftp_CheckCmdStatus(cmd_status))
		{
			sdcFtpStatus->bServerEnabled = MBT_TRUE;
			sdcFtpStatus->FtpState = MBT_FTP_STATE_IDLE;
			MBT_PI("FTP Server Enabled",0,0,0);
			mbt_postevent(MBTEVT_FTP_SERVER_ENABLE_SUCCESS, 0);
		}
		else
		{
			sdcFtpStatus->bServerEnabled = MBT_FALSE;
			sdcFtpStatus->FtpState = MBT_FTP_STATE_CLOSED;
			MBT_ERR("FTP Server Enable Fail. Reason code : %x",cmd_status,0,0);
			mbt_postevent(MBTEVT_FTP_SERVER_ENABLE_FAIL, 0);
			return;
		}
	}
	else
	{
		MBT_WARN("mbt_ftp_server_enable> Ftp is aleady enabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_FTP_SERVER_ENABLE_FAIL, 0);
		return;
	}

}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_server_disable (MBT_VOID)
*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_server_disable (MBT_VOID)
{
	bt_cmd_status_type cmd_status;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	if(sdcFtpStatus->bServerEnabled == MBT_TRUE)
	{
		
		cmd_status = bt_cmd_pf_ftp_srv_force_disconnect( qbt_ftp_server.app_id,
					qbt_ftp_server.conn_id);
		if(mbt_ftp_CheckCmdStatus(cmd_status))
		{
			sdcFtpStatus->FtpState = MBT_FTP_STATE_IDLE;
		}
		else
		{
			MBT_ERR("mbt_ftp_server_disable> force disconnect fail. Reason code : %x",cmd_status,0,0);
			mbt_postevent(MBTEVT_FTP_SERVER_DISABLE_FAIL, 0);
			return;
		}

		cmd_status = bt_cmd_pf_ftp_srv_deregister( qbt_ftp_server.app_id);
		if(mbt_ftp_CheckCmdStatus(cmd_status))
		{
			sdcFtpStatus->bServerEnabled = MBT_FALSE;
			sdcFtpStatus->FtpState = MBT_FTP_STATE_CLOSED;
		}
		else
		{
			MBT_ERR("mbt_ftp_server_disable> server deregister fail. Reason code : %x",cmd_status,0,0);
			mbt_postevent(MBTEVT_FTP_SERVER_DISABLE_FAIL, 0);
			return;
		}
		/*
		cmd_status = bt_cmd_ec_free_application_id(qbt_ftp_server.app_id);
		if(mbt_ftp_CheckCmdStatus(cmd_status))
		{
			MBT_PI("FTP Server Disabled",0,0,0);
		}
		else
		{
			MBT_ERR("mbt_ftp_server_disable> free app_id fail. Reason code : %x",cmd_status,0,0);
			mbt_postevent(MBTEVT_FTP_SERVER_DISABLE_FAIL, 0);
			return;
		}
		qbt_ftp_server.app_id = BT_APP_ID_NULL;
		*/
		mbt_postevent(MBTEVT_FTP_SERVER_DISABLE_SUCCESS, 0);
	}
	else
	{
		MBT_WARN("mbt_ftp_server_disable> FTP server  is aleady Disabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_FTP_SERVER_DISABLE_FAIL, 0);
		return;
		
	}

}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_server_access_response (T_MBT_AUTHRES Reply)
*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_server_access_response( T_MBT_AUTHRES Reply )
{
	bt_cmd_status_type cmd_status;
	bt_cmd_status_type	cmd_status_rsp;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);
	MBT_UINT	filesize;
	MBT_CHAR filename[MBT_MAX_FILE_NAME_LEN] = {0,};
	fs_rsp_msg_type	fs_rsp;

	MBT_PI("ftp srv access resp : Oper:%x Reply:%d", sdcFtpStatus->Operation, Reply, 0);

	switch(sdcFtpStatus->Operation)
	{
		case MBT_FTP_OPER_PUT:
			if ( Reply == MBT_ALLOW_RES )
			{
				// make full path name
				memset(filename, 0, sizeof(filename));
				qbt_file_make_full_path(sdcFtpStatus->ReceivingFile.DirName,
							sdcFtpStatus->ReceivingFile.FileName,
							filename, sizeof(filename));

				MBT_PI("mbt ftp : try to open receiving file name_len:%d", strlen(filename), 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
				{
					int i;
					for ( i = 0 ; i < strlen(filename) ; i+=3 )
						MBT_PI("(%c%c%c)", filename[i], filename[i+1], filename[i+2]);
				}
#endif
				// open file to write
				cmd_status_rsp = qbt_file_open_write(&qbt_ftp_server.fs_handle, filename);

				// response to stack
				cmd_status = bt_cmd_pf_ftp_srv_open_done(qbt_ftp_server.app_id,
							qbt_ftp_server.conn_id,
							(bt_pf_ftp_handle_type)qbt_ftp_server.fs_handle,
							0,
							cmd_status_rsp);

				// make event to UI
				if ( cmd_status_rsp == OI_OK )
				{
					qbt_ftp_server.done_size = 0;
					sdcFtpStatus->FtpState = MBT_FTP_STATE_RECEIVING;
					mbt_postevent(MBTEVT_FTP_SERVER_PUT_START, 0);
				}
				else
				{
					mbt_postevent(MBTEVT_FTP_SERVER_PUT_FAIL, 0);
				}
			}
			else
			{
				MBT_PI("mbt_ftp_acc_res> reject put :%x", Reply, 0, 0);
				cmd_status = bt_cmd_pf_ftp_srv_open_done(qbt_ftp_server.app_id,
							qbt_ftp_server.conn_id,
							(bt_pf_ftp_handle_type)0,
							0,
							OI_FAIL);
			}

			break;

		case MBT_FTP_OPER_GET:
			if ( Reply == MBT_ALLOW_RES )
			{
				// make full path name
				memset(filename, 0, sizeof(filename));
				qbt_file_make_full_path(sdcFtpStatus->SendingFile.DirName,
							sdcFtpStatus->SendingFile.FileName,
							filename, sizeof(filename));

				MBT_PI("mbt ftp : try to open sending file name_len:%d", strlen(filename), 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
				{
					int i;
					for ( i = 0 ; i < strlen(filename) ; i+=3 )
						MBT_PI("(%c%c%c)", filename[i], filename[i+1], filename[i+2]);
				}
#endif
				// open file to read
				cmd_status_rsp = qbt_file_open_read(&qbt_ftp_server.fs_handle,
							(MBT_UINT*)&sdcFtpStatus->SendingFile.ObjectSize, filename);

				// response to stack
				cmd_status = bt_cmd_pf_ftp_srv_open_done(qbt_ftp_server.app_id,
							qbt_ftp_server.conn_id,
							(bt_pf_ftp_handle_type)qbt_ftp_server.fs_handle,
							sdcFtpStatus->SendingFile.ObjectSize,
							cmd_status_rsp);

				// make event to UI
				if ( cmd_status_rsp == OI_OK )
				{
					qbt_ftp_server.done_size = 0;
					sdcFtpStatus->FtpState = MBT_FTP_STATE_RECEIVING;
					mbt_postevent(MBTEVT_FTP_SERVER_GET_START, 0);
				}
				else
					mbt_postevent(MBTEVT_FTP_SERVER_GET_FAIL, 0);
			}
			else
			{
				MBT_PI("mbt_ftp_acc_res> reject put :%x", Reply, 0, 0);
				cmd_status = bt_cmd_pf_ftp_srv_open_done(qbt_ftp_server.app_id,
							qbt_ftp_server.conn_id,
							(bt_pf_ftp_handle_type)0,
							0,
							OI_FAIL);
			}

			break;

		case MBT_FTP_OPER_DEL_FILE:
			if ( Reply == MBT_ALLOW_RES )
			{
				// make full path name
				memset(filename, 0, sizeof(filename));
				qbt_file_make_full_path(sdcFtpStatus->TargetFile.DirName,
							sdcFtpStatus->TargetFile.FileName,
							filename, sizeof(filename));

				MBT_PI("mbt ftp : try to delete file name_len:%d", strlen(filename), 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
				{
					int i;
					for ( i = 0 ; i < strlen(filename) ; i+=3 )
						MBT_PI("(%c%c%c)", filename[i], filename[i+1], filename[i+2]);
				}
#endif
				// delete file
				fs_remove(filename, NULL, &fs_rsp);
				MBT_PI("mbt ftp : del file name_len:%d res:%x", strlen(filename), fs_rsp.rmfile.status, 0);

				// response to stack, make event to UI
				if ( fs_rsp.rmfile.status == FS_OKAY_S )
				{
					cmd_status = bt_cmd_pf_ftp_srv_delete_done(qbt_ftp_server.app_id,
								qbt_ftp_server.conn_id, OI_OK);
					mbt_postevent(MBTEVT_FTP_SERVER_DELFILE_SUCCESS, 0);
				}
				else
				{
					cmd_status = bt_cmd_pf_ftp_srv_delete_done(qbt_ftp_server.app_id,
								qbt_ftp_server.conn_id, OI_FAIL);
					mbt_postevent(MBTEVT_FTP_SERVER_DELFILE_FAIL, 0);
				}
			}
			else
			{
				MBT_PI("mbt_ftp_acc_res> reject put :%x", Reply, 0, 0);
				cmd_status = bt_cmd_pf_ftp_srv_delete_done(qbt_ftp_server.app_id,
							qbt_ftp_server.conn_id,
							OI_FAIL);
			}

			break;

		case MBT_FTP_OPER_DEL_DIR:
			if ( Reply == MBT_ALLOW_RES )
			{
				// make full path name
				memset(filename, 0, sizeof(filename));
				qbt_file_make_full_path(sdcFtpStatus->TargetFile.DirName,
							sdcFtpStatus->TargetFile.FileName,
							filename, sizeof(filename));

				MBT_PI("mbt ftp : try to delete dir name_len:%d", strlen(filename), 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
				{
					int i;
					for ( i = 0 ; i < strlen(filename) ; i+=3 )
						MBT_PI("(%c%c%c)", filename[i], filename[i+1], filename[i+2]);
				}
#endif

				// delete file
				fs_remove(filename, NULL, &fs_rsp);

				// response to stack, make event to UI
				if ( fs_rsp.rmdir.status == FS_OKAY_S )
				{
					cmd_status = bt_cmd_pf_ftp_srv_delete_done(qbt_ftp_server.app_id,
								qbt_ftp_server.conn_id, OI_OK);
					mbt_postevent(MBTEVT_FTP_SERVER_DELDIR_SUCCESS, 0);
				}
				else
				{
					cmd_status = bt_cmd_pf_ftp_srv_delete_done(qbt_ftp_server.app_id,
								qbt_ftp_server.conn_id, OI_FAIL);
					mbt_postevent(MBTEVT_FTP_SERVER_DELDIR_FAIL, 0);
				}
			}
			else
			{
				MBT_PI("mbt_ftp_acc_res> reject put :%x", Reply, 0, 0);
				cmd_status = bt_cmd_pf_ftp_srv_delete_done(qbt_ftp_server.app_id,
							qbt_ftp_server.conn_id,
							OI_FAIL);
			}

			break;

		case MBT_FTP_OPER_LIST_DIR:
			if ( Reply == MBT_ALLOW_RES )
			{
				// make XML file name
				//DirName�� browsing req���� �־��ְ� index file �̸��� phmgr_bt_proc���� �־���. 
				memset(filename, 0, sizeof(filename));
				qbt_file_make_full_path(sdcFtpStatus->TargetFile.DirName,
							sdcFtpStatus->TargetFile.FileName,
							filename, sizeof(filename));

				MBT_PI("mbt ftp : make folder list file name_len:%d", strlen(filename), 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
				{
					int i;
					for ( i = 0 ; i < strlen(filename) ; i+=3 )
						MBT_PI("(%c%c%c)", filename[i], filename[i+1], filename[i+2]);
				}
#endif

#ifdef MBT_FTP_CUR_DIR_LOG
				{
					int i;
					MBT_PI("make browse list :cur dir len:%d", strlen(qbt_ftp_server.cur_dir), 0, 0);
					for ( i = 0 ; i < strlen(qbt_ftp_server.cur_dir) ; i+=3 )
						MBT_PI("(%c%c%c)", qbt_ftp_server.cur_dir[i], qbt_ftp_server.cur_dir[i+1], qbt_ftp_server.cur_dir[i+2]);
				}
#endif

				cmd_status_rsp = mbt_ftp_make_browse_list(filename);

				if ( cmd_status_rsp == OI_OK )
				{
					cmd_status_rsp = qbt_file_open_read(&qbt_ftp_server.fs_handle,
								&filesize, filename);
					if ( cmd_status_rsp == OI_OK )
					{
						qbt_ftp_server.done_size = 0;
						sdcFtpStatus->FtpState = MBT_FTP_STATE_SENDING;
						sdcFtpStatus->SendingFile.ObjectSize = filesize;
					}
				}
			}
			else
			{
				cmd_status_rsp = OI_FAIL;
			}

			cmd_status = bt_cmd_pf_ftp_srv_browse_done(qbt_ftp_server.app_id,
						qbt_ftp_server.conn_id,
						(bt_pf_ftp_handle_type)qbt_ftp_server.fs_handle,
						filesize,
						cmd_status_rsp);

			break;

		case MBT_FTP_OPER_CHG_DIR:
		{
			if ( Reply == MBT_ALLOW_RES )
			{
				cmd_status_rsp = OI_OK;
				memset(qbt_ftp_server.cur_dir, 0, MBT_MAX_FILE_NAME_LEN);
				strncpy(qbt_ftp_server.cur_dir, sdcFtpStatus->TargetFile.FileName, MBT_MAX_FILE_NAME_LEN);

				MBT_PI("set path succ: cur dir len:%d", strlen(qbt_ftp_server.cur_dir), 0, 0);
#ifdef MBT_FTP_CUR_DIR_LOG
				{
					int i;
					for ( i = 0 ; i < strlen(qbt_ftp_server.cur_dir) ; i+=3 )
						MBT_PI("(%c%c%c)", qbt_ftp_server.cur_dir[i], qbt_ftp_server.cur_dir[i+1], qbt_ftp_server.cur_dir[i+2]);
				}
#endif
			}
			else
			{
				if(Reply == MBT_NOT_FOUND_RES)
					cmd_status_rsp = BT_CS_PF_OBEX_NOT_FOUND;	//OI_STATUS_NOT_FOUND;
				else
					cmd_status_rsp = OI_FAIL;
			}
			cmd_status = bt_cmd_pf_ftp_srv_set_folder_done(qbt_ftp_server.app_id,
						qbt_ftp_server.conn_id,
						cmd_status_rsp);

			break;
		}

		case MBT_FTP_OPER_MK_DIR:
			if ( Reply == MBT_ALLOW_RES )
			{
				memset(filename, 0, sizeof(filename));
				mbt_utf8_to_local(sdcFtpStatus->SendingFile.FileName,
							strlen(sdcFtpStatus->SendingFile.FileName),
							filename, sizeof(filename), '_');

				MBT_PI("mbt ftp : make folder name_len:%d", strlen(filename), 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
				{
					int i;
					for ( i = 0 ; i < strlen(filename) ; i+=3 )
						MBT_PI("(%c%c%c)", filename[i], filename[i+1], filename[i+2]);
				}
#endif
				fs_mkdir(filename, NULL, &fs_rsp);
				if ( fs_rsp.mkdir.status == FS_OKAY_S )
				{
					cmd_status_rsp = OI_OK;
				}
				else
				{
					cmd_status_rsp = OI_FAIL;
				}
			}
			else
			{
				cmd_status_rsp = OI_FAIL;
			}
			cmd_status = bt_cmd_pf_ftp_srv_set_folder_done(qbt_ftp_server.app_id, qbt_ftp_server.conn_id, cmd_status_rsp);

			break;

		default:
			break;
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_server_auth_response (T_MBT_OBEX_AUTH *auth_reply)
*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_server_auth_response( T_MBT_OBEX_AUTH *auth_reply )
{
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_server_setrootfolder (MBT_CHAR *RootFolde)
*	Description	: FTP Server �� Root Folder �� �����Ѵ�.
*	Return	:	Folder ������  ���� ����
********************************************************************************/
MBT_BOOL mbt_ftp_server_setrootfolder(MBT_CHAR *RootFolder)
{
#if MBT_FTP_VIRTUAL_FOLDER == FALSE
	memset(qbt_ftp_server.root_dir, 0, MBT_MAX_FILE_NAME_LEN);
	strncpy(qbt_ftp_server.root_dir, RootFolder, sizeof(qbt_ftp_server.root_dir));
	//memset(qbt_ftp_server.cur_dir, 0, MBT_MAX_FILE_NAME_LEN);
	//strncpy(qbt_ftp_server.cur_dir, qbt_ftp_server.root_dir, MBT_MAX_FILE_NAME_LEN);
	//MBT_PI("set root folder len:%d, cur dir len:%d", strlen(qbt_ftp_server.root_dir), strlen(qbt_ftp_server.cur_dir), 0);
	
#ifdef MBT_FTP_CUR_DIR_LOG
	{
		int i;
		MBT_PI("set root folder len:%d", strlen(qbt_ftp_server.root_dir), 0, 0);
		for ( i = 0 ; i < strlen(qbt_ftp_server.root_dir) ; i+=3 )
			MBT_PI("(%c%c%c)", qbt_ftp_server.root_dir[i], qbt_ftp_server.root_dir[i+1], qbt_ftp_server.root_dir[i+2]);
	}
#endif
#endif
	return MBT_FALSE;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_server_enable (MBT_VOID)
*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_client_enable (MBT_VOID)
{
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_server_disable (MBT_VOID)
*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_client_disable (MBT_VOID)
{
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_client_open(T_MBT_BDADDR RemoteBDAddr)
*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_client_open(T_MBT_BDADDR RemoteBDAddr)
{
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_close(MBT_VOID)

*	Description	: ftp client close the connection
********************************************************************************/
MBT_VOID mbt_ftp_client_close(MBT_VOID)
{
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_client_auth_response( T_MBT_OBEX_AUTH *auth_reply )

*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_client_auth_response( T_MBT_OBEX_AUTH *auth_reply )
{
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_client_putfile(T_MBT_FTP_OBJECT *MBTObject)

*	Description	: ftp client sent a file to connected peer ftp serser
********************************************************************************/
MBT_VOID mbt_ftp_client_putfile(T_MBT_FTP_OBJECT * MBTObject)
{
}


/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_client_getfile (MBT_CHAR *pLocalFileName, MBT_CHAR *pRemFileName)

*	Description	: ftp client get a file from connected peer ftp server
********************************************************************************/
MBT_VOID mbt_ftp_client_getfile (T_MBT_FTP_OBJECT * MBTObject)
{
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_client_chdir (T_MBT_FTP_OBJECT * MBTObject)

*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_client_chdir(T_MBT_FTP_OBJECT * MBTObject)
{
}

/********************************************************************************
*	Prototype	: void mbt_ftp_client_mkdir (T_MBT_FTP_OBJECT * MBTObject)

*	Description	: ftp client make a new directory on the connected peer ftp server
********************************************************************************/
MBT_VOID mbt_ftp_client_mkdir(T_MBT_FTP_OBJECT * MBTObject)
{
}

/********************************************************************************
*	Prototype	: void mbt_ftp_client_listdir (T_MBT_FTP_OBJECT * MBTObject)

*	Description	: ftp client get directory and file list on the connected peer ftp server
********************************************************************************/
MBT_VOID mbt_ftp_client_listdir(T_MBT_FTP_OBJECT * MBTObject)
{
}

/********************************************************************************
*	Prototype	: void mbt_ftp_client_deldir (T_MBT_FTP_OBJECT * MBTObject)

*	Description	: ftp client delete a directory on the connected peer ftp server
********************************************************************************/
MBT_VOID mbt_ftp_client_deldir(T_MBT_FTP_OBJECT * MBTObject)
{
}

/********************************************************************************
*	Prototype	: void mbt_ftp_client_delfile (T_MBT_FTP_OBJECT * MBTObject)

*	Description	: ftp client delete a file on the connected peer ftp server
********************************************************************************/
MBT_VOID mbt_ftp_client_delfile(T_MBT_FTP_OBJECT * MBTObject)
{
}

/********************************************************************************
*	Prototype	: void mbt_ftp_client_abort (MBT_VOID)

*	Description	:
********************************************************************************/
MBT_VOID mbt_ftp_client_abort(MBT_VOID)
{
}

MBT_BOOL mbt_ftp_CheckCmdStatus( bt_cmd_status_type stat )
{
	switch (stat)
	{
		case BT_CS_GN_SUCCESS:
		case BT_CS_GN_PENDING:
			return MBT_TRUE; //SUCCESS;

		case BT_CS_GN_CMD_Q_FULL:
			return MBT_FALSE; //ENOMEMORY;

		default:
			return MBT_FALSE; //EFAILED;
	}
}

MBT_VOID qbt_proc_evt_ftp_srv_con_ind(bt_pf_ev_ftp_srv_con_ind_type* bt_ev_msg_ptr)
{
	uint16 name_str[BT_PF_MAX_FILENAME_LEN + 1];
	bt_cmd_status_type cmd_status;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	MBT_PI("mbt_ftp_srv_con_ind> conn_id:%x auth:%d ftp_stat:%d", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->unauthorized, sdcFtpStatus->FtpState);
	if ( sdcFtpStatus->bServerEnabled && sdcFtpStatus->FtpState == MBT_FTP_STATE_IDLE )
	{
		qbt_ftp_server.conn_id = bt_ev_msg_ptr->conn_id;
#if MBT_FTP_VIRTUAL_FOLDER == TRUE
		qbt_ftp_server.cur_dir[0] = '/';
		qbt_ftp_server.cur_dir[1] = 0;
#else
		memset(qbt_ftp_server.cur_dir, 0, MBT_MAX_FILE_NAME_LEN);
		strncpy(qbt_ftp_server.cur_dir, qbt_ftp_server.root_dir, MBT_MAX_FILE_NAME_LEN);

//		MBT_PI("mbt ftp : conn ind : default dir len:%d", strlen(qbt_ftp_server.cur_dir), 0, 0);   
#ifdef MBT_FTP_CUR_DIR_LOG
		{
			int i;
			for ( i = 0 ; i < strlen(qbt_ftp_server.cur_dir) ; i += 3 )
				MBT_PI("(%c%c%c)", qbt_ftp_server.cur_dir[i], qbt_ftp_server.cur_dir[i+1], qbt_ftp_server.cur_dir[i+2]);
		}
#endif
#endif
		sdcFtpStatus->FtpState = MBT_FTP_STATE_CONNECTED;
		memcpy(sdcFtpStatus->BDAddr, (void*)bt_ev_msg_ptr->bd_addr.bd_addr_bytes, MBT_BDADDR_LEN);

		name_str[0] = 0;
		cmd_status = bt_cmd_pf_ftp_srv_accept_connect(qbt_ftp_server.app_id,
					qbt_ftp_server.conn_id, TRUE, name_str);

		mbt_postevent(MBTEVT_FTP_SERVER_CONNECT_SUCCESS, 0);
	}
	else
	{
		MBT_ERR("mbt_ftp_srv_con_ind> invalid_stat:%d force disconnect", bt_ev_msg_ptr->conn_id, sdcFtpStatus->FtpState, 0);
		cmd_status = bt_cmd_pf_ftp_srv_force_disconnect(qbt_ftp_server.app_id,
					bt_ev_msg_ptr->conn_id);
	}
}

MBT_VOID qbt_proc_evt_ftp_srv_dcn_ind(bt_pf_ev_ftp_srv_dcn_ind_type* bt_ev_msg_ptr)
{
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	MBT_PI("mbt_ftp_srv_disc_ind> conn_id:%x ftp_stat:%d", bt_ev_msg_ptr->conn_id, sdcFtpStatus->FtpState, 0);
	sdcFtpStatus->FtpState = MBT_FTP_STATE_IDLE;
	qbt_ftp_server.conn_id = BT_PF_FTP_NO_CONN_ID;

	mbt_postevent(MBTEVT_FTP_SERVER_DISCONNECT_SUCCESS, 0);
}

MBT_VOID qbt_proc_evt_ftp_srv_browse_req(bt_pf_ev_ftp_srv_browse_req_type* bt_ev_msg_ptr)
{
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	MBT_PI("mbt_ftp_srv_browse> conn_id:%x ftp_stat:%d", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->folder_name_len, sdcFtpStatus->FtpState);

	sdcFtpStatus->Operation = MBT_FTP_OPER_LIST_DIR;
	//memset(sdcFtpStatus->TargetFile.DirName, 0, MBT_MAX_FILE_NAME_LEN);
	//strncpy(sdcFtpStatus->TargetFile.DirName, qbt_ftp_server.cur_dir, MBT_MAX_FILE_NAME_LEN);

	MBT_PI("mbt ftp : browse req : dir len:%d", strlen(sdcFtpStatus->TargetFile.DirName), 0, 0);
#ifdef MBT_FTP_CUR_DIR_LOG
	{
		int i;
		for ( i = 0 ; i < strlen(sdcFtpStatus->TargetFile.DirName) ; i+=3 )
			MBT_PI("(%c%c%c)", sdcFtpStatus->TargetFile.DirName[i], sdcFtpStatus->TargetFile.DirName[i+1], sdcFtpStatus->TargetFile.DirName[i+2]);
	}
#endif

	mbt_postevent(MBTEVT_FTP_SERVER_ACCESS_REQUEST, 0);
}

MBT_VOID qbt_proc_evt_ftp_srv_open_req(bt_pf_ev_ftp_srv_open_req_type* bt_ev_msg_ptr)
{
//	MBT_SHORT name_len;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);
	T_MBT_FTP_OBJECT *obj_ptr;
	MBT_SHORT ucs2_filename[MBT_MAX_FILE_NAME_LEN];

	if ( bt_ev_msg_ptr->mode == BT_PF_FTP_MODE_READ )
	{
		sdcFtpStatus->Operation = MBT_FTP_OPER_GET;
		obj_ptr = &sdcFtpStatus->SendingFile;
	}
	else
	{
		sdcFtpStatus->ReceivingFile.ObjectSize = bt_ev_msg_ptr->obj_size;
		sdcFtpStatus->Operation = MBT_FTP_OPER_PUT;
		obj_ptr = &sdcFtpStatus->ReceivingFile;
	}

	MBT_PI("mbt_ftp_srv_open> conn_id:%x mode:%d obj_size:%d", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->mode, bt_ev_msg_ptr->obj_size);
	MBT_PI("mbt_ftp_srv_open> name_len:%d", bt_ev_msg_ptr->name_len, 0, 0);

	// set default download folder
	//memset(obj_ptr, 0, sizeof(T_MBT_FTP_OBJECT));
	strncpy(obj_ptr->DirName, qbt_ftp_server.cur_dir, MBT_MAX_FILE_NAME_LEN-1);

	// set file name
	memcpy((void*)ucs2_filename, (void*)bt_ev_msg_ptr->name_str, bt_ev_msg_ptr->name_len*2);
	ucs2_filename[bt_ev_msg_ptr->name_len] = 0;		// struct byte align
	mbt_ucs2_to_utf8((MBT_SHORT*)ucs2_filename, 
						bt_ev_msg_ptr->name_len, 
						obj_ptr->FileName,
						MBT_MAX_FILE_NAME_LEN);

#ifdef MBT_FTP_FILENAME_LOG
	{
		int i;
		MBT_PI("open folder req:len:%d oper:%d", strlen(obj_ptr->DirName), sdcFtpStatus->Operation, 0);
		for ( i = 0 ; i < strlen(obj_ptr->DirName) ; i+=3 )
			MBT_PI("(%c%c%c)", obj_ptr->DirName[i], obj_ptr->DirName[i+1], obj_ptr->DirName[i+2]);
		MBT_PI("open file req:len:%d", strlen(obj_ptr->FileName), 0, 0);
		for ( i = 0 ; i < strlen(obj_ptr->FileName) ; i+=3 )
			MBT_PI("(%c%c%c)", obj_ptr->FileName[i], obj_ptr->FileName[i+1], obj_ptr->FileName[i+2]);
	}
#endif

	mbt_postevent(MBTEVT_FTP_SERVER_ACCESS_REQUEST, 0);
}

MBT_VOID qbt_proc_evt_ftp_srv_close_req(bt_pf_ev_ftp_srv_close_req_type* bt_ev_msg_ptr)
{
	fs_rsp_msg_type	fs_rsp;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	MBT_PI("mbt_ftp_srv_close> conn_id:%x stat:%x ftp_stat:%d", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->conn_id, sdcFtpStatus->FtpState);

	if ( qbt_ftp_server.fs_handle > 0 )
	{
		fs_close(qbt_ftp_server.fs_handle, NULL, &fs_rsp);
		MBT_PI("mbt ftp close fs hndl:%x res:%x", qbt_ftp_server.fs_handle, fs_rsp.close.status, 0);
		qbt_ftp_server.fs_handle = 0;
	}

	if(bt_ev_msg_ptr->status == BT_CS_GN_SUCCESS)
	{
		if ( sdcFtpStatus->Operation == MBT_FTP_OPER_GET )
		{
			MBT_PI("[FTP] read complete.", 0, 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
			{
				int i;
			MBT_PI("dir_len:%d", strlen(sdcFtpStatus->SendingFile.DirName), 0, 0);
				for ( i = 0 ; i < strlen(sdcFtpStatus->SendingFile.DirName) ; i+=3 )
					MBT_PI("(%c%c%c)", sdcFtpStatus->SendingFile.DirName[i], sdcFtpStatus->SendingFile.DirName[i+1], sdcFtpStatus->SendingFile.DirName[i+2]);
			MBT_PI("file_len:%d", strlen(sdcFtpStatus->SendingFile.FileName), 0, 0);
				for ( i = 0 ; i < strlen(sdcFtpStatus->SendingFile.FileName) ; i+=3 )
					MBT_PI("(%c%c%c)", sdcFtpStatus->SendingFile.FileName[i], sdcFtpStatus->SendingFile.FileName[i+1], sdcFtpStatus->SendingFile.FileName[i+2]);
			}
#endif
			sdcFtpStatus->FtpState = MBT_FTP_STATE_CONNECTED;	// JG Kwon. 2009.12.08
			mbt_postevent(MBTEVT_FTP_SERVER_GET_SUCCESS, 0);
		}
		else if ( sdcFtpStatus->Operation == MBT_FTP_OPER_PUT )
		{
			MBT_PI("[FTP] write complete.", 0, 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
			{
				int i;
			MBT_PI("dir_len:%d", strlen(sdcFtpStatus->ReceivingFile.DirName), 0, 0);
				for ( i = 0 ; i < strlen(sdcFtpStatus->ReceivingFile.DirName) ; i+=3 )
					MBT_PI("(%c%c%c)", sdcFtpStatus->ReceivingFile.DirName[i], sdcFtpStatus->ReceivingFile.DirName[i+1], sdcFtpStatus->ReceivingFile.DirName[i+2]);
			MBT_PI("file_len:%d", strlen(sdcFtpStatus->ReceivingFile.FileName), 0, 0);
				for ( i = 0 ; i < strlen(sdcFtpStatus->ReceivingFile.FileName) ; i+=3 )
					MBT_PI("(%c%c%c)", sdcFtpStatus->ReceivingFile.FileName[i], sdcFtpStatus->ReceivingFile.FileName[i+1], sdcFtpStatus->ReceivingFile.FileName[i+2]);
			}
#endif
			sdcFtpStatus->FtpState = MBT_FTP_STATE_CONNECTED;	// JG Kwon. 2009.12.08
			mbt_postevent(MBTEVT_FTP_SERVER_PUT_SUCCESS, 0);
		}
		else if ( sdcFtpStatus->Operation == MBT_FTP_OPER_LIST_DIR )
		{
			MBT_PI("mbt_ftp_close> complete list dir: stat:%x", sdcFtpStatus->FtpState, 0, 0);
		}
		else
			MBT_ERR("mbt_ftp_close> invalid status oper:%x stat:%x", sdcFtpStatus->Operation, sdcFtpStatus->FtpState, 0);
	}
	else
	{
		//���������� ����� ���� close req.
		MBT_CHAR		filename[MBT_MAX_FILE_NAME_LEN];
		T_MBT_FTP_OBJECT	*obj_ptr;
		bt_cmd_status_type	cmd_status_rsp;

		MBT_ERR("[FTP] close fail(err:%x)", bt_ev_msg_ptr->status, 0, 0);
		if ( sdcFtpStatus->Operation == MBT_FTP_OPER_GET )
		{
			obj_ptr = &sdcFtpStatus->SendingFile;
			MBT_PI("[FTP] read aborted.", 0, 0, 0);
			mbt_postevent(MBTEVT_FTP_SERVER_GET_FAIL, 0);
		}
		else if ( sdcFtpStatus->Operation == MBT_FTP_OPER_PUT )
		{
			obj_ptr = &sdcFtpStatus->ReceivingFile;

			// make full path to be deleted
			memset(filename, 0, sizeof(filename));
			qbt_file_make_full_path(obj_ptr->DirName, obj_ptr->FileName,
						filename, sizeof(filename));
			MBT_PI("mbt ftp : try to delete gabage file name_len:%d", strlen(filename), 0, 0);
#ifdef MBT_FTP_FILENAME_LOG
			{
				int i;
				for ( i = 0 ; i < strlen(filename) ; i+=3 )
					MBT_PI("(%c%c%c)", filename[i], filename[i+1], filename[i+2]);
			}
#endif

			// delete gabage file
			cmd_status_rsp = qbt_file_remove(filename);

			MBT_PI("[FTP] write aborted.", 0, 0, 0);
			mbt_postevent(MBTEVT_FTP_SERVER_PUT_FAIL, 0);
		}
		else
		{
			MBT_ERR("mbt_ftp_close> invalid status oper:%x stat:%x", sdcFtpStatus->Operation, sdcFtpStatus->FtpState, 0);
			return;
		}
	}

}

MBT_VOID qbt_proc_evt_ftp_srv_read_req(bt_pf_ev_ftp_srv_read_req_type* bt_ev_msg_ptr)
{
	T_MBTEVT		mbt_evt;
	bt_cmd_status_type	cmd_status_rsp;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	MBT_UINT	data_len;
	MBT_SHORT	reading;

	MBT_PI("mbt_ftp_srv_read> conn_id:%x ftp_stat:%d", bt_ev_msg_ptr->conn_id, sdcFtpStatus->FtpState, 0);

	//Max transmit size limitation
	if (bt_ev_msg_ptr->max_read > MBT_OBEX_FILE_BUF_LEN)
		reading= MBT_OBEX_FILE_BUF_LEN;
	else
		reading = bt_ev_msg_ptr->max_read;

	data_len = sizeof(mbt_qbt_ftp_buf);
	cmd_status_rsp = qbt_file_read(qbt_ftp_server.fs_handle,
				//bt_ev_msg_ptr->max_read,
				reading,
				(uint32*)&data_len, mbt_qbt_ftp_buf,
				sdcFtpStatus->SendingFile.ObjectSize);

	if ( cmd_status_rsp == OI_OK || cmd_status_rsp == OI_STATUS_END_OF_FILE )
	{
		mbt_evt = MBTEVT_FTP_SERVER_GET_PROGRESS;
		qbt_ftp_server.done_size += data_len;
		sdcFtpStatus->TxProgress = qbt_ftp_server.done_size;
		MBT_PI("mbt ftp : succ send : %d/%d", sdcFtpStatus->TxProgress, sdcFtpStatus->SendingFile.ObjectSize, 0);
	}
	else
	{
		mbt_evt = MBTEVT_FTP_SERVER_GET_FAIL;
	}

	bt_cmd_pf_ftp_srv_read_done(qbt_ftp_server.app_id,
				qbt_ftp_server.conn_id,
				(bt_pf_ftp_handle_type)qbt_ftp_server.fs_handle,
				mbt_qbt_ftp_buf,
				data_len,
				cmd_status_rsp);

	if ( sdcFtpStatus->Operation == MBT_FTP_OPER_GET )
		mbt_postevent(mbt_evt, 0);
}

MBT_VOID qbt_proc_evt_ftp_srv_write_req(bt_pf_ev_ftp_srv_write_req_type* bt_ev_msg_ptr)
{
	T_MBTEVT		mbt_evt;
	bt_cmd_status_type	cmd_status_rsp;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	MBT_PI("mbt_ftp_srv_write> conn_id:%x ftp_stat:%d", bt_ev_msg_ptr->conn_id, sdcFtpStatus->FtpState, 0);

	cmd_status_rsp = qbt_file_write(qbt_ftp_server.fs_handle,
				bt_ev_msg_ptr->buffer_ptr,
				bt_ev_msg_ptr->buffer_len);

	if ( cmd_status_rsp == OI_OK )
	{
		mbt_evt = MBTEVT_FTP_SERVER_PUT_PROGRESS;
		qbt_ftp_server.done_size += bt_ev_msg_ptr->buffer_len;
		sdcFtpStatus->RxProgress = qbt_ftp_server.done_size;
		MBT_PI("mbt ftp : recv send : %d/%d", sdcFtpStatus->RxProgress, sdcFtpStatus->ReceivingFile.ObjectSize, 0);
	}
	else
	{
		mbt_evt = MBTEVT_FTP_SERVER_PUT_FAIL;
	}

	bt_cmd_pf_ftp_srv_write_done(qbt_ftp_server.app_id,
				qbt_ftp_server.conn_id,
				(bt_pf_ftp_handle_type)qbt_ftp_server.fs_handle,
				cmd_status_rsp);

	if ( sdcFtpStatus->Operation == MBT_FTP_OPER_PUT )
		mbt_postevent(mbt_evt, 0);
}

MBT_VOID qbt_proc_evt_ftp_srv_delete_req(bt_pf_ev_ftp_srv_delete_req_type* bt_ev_msg_ptr)
{
	MBT_CHAR	filename[MBT_MAX_FILE_NAME_LEN] = {0,};
	fs_rsp_msg_type	fs_rsp;
	bt_cmd_status_type cmd_status;
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	MBT_BOOL bSucc = MBT_FALSE;
	MBT_PI("mbt_ftp_srv_delete> conn_id:%x ftp_stat:%d", bt_ev_msg_ptr->conn_id, sdcFtpStatus->FtpState, 0);

	// make full path name of file or folder to be deleted
	qbt_file_make_full_path_ucs2(qbt_ftp_server.cur_dir,
				(MBT_SHORT*)bt_ev_msg_ptr->name_str, bt_ev_msg_ptr->name_len,
				filename, sizeof(filename));

	// check whether it is folder
	fs_nametest(filename, FS_TEST_DIR, NULL, &fs_rsp);
	if ( fs_rsp.nametest.status == FS_OKAY_S && fs_rsp.nametest.name_found )
	{
		sdcFtpStatus->Operation = MBT_FTP_OPER_DEL_DIR;
		bSucc = MBT_TRUE;
		MBT_PI("mbt_ftp_srv_delete : make delete req", 0,  0, 0);
	}
	// check whether it is file
	fs_nametest(filename, FS_TEST_FILE, NULL, &fs_rsp);
	if ( fs_rsp.nametest.status == FS_OKAY_S && fs_rsp.nametest.name_found )
	{
		sdcFtpStatus->Operation = MBT_FTP_OPER_DEL_FILE;
		bSucc = MBT_TRUE;
		MBT_PI("mbt_ftp_srv_delete : make delete req", 0,  0, 0);
	}

	// make UI event
	if ( bSucc )
	{
		// make folder name to be deleted
		memset(&sdcFtpStatus->TargetFile, 0, sizeof(T_MBT_FTP_OBJECT));
		strncpy(sdcFtpStatus->TargetFile.DirName, qbt_ftp_server.cur_dir, MBT_MAX_FILE_NAME_LEN);

		// make file name to be deleted
		mbt_ucs2_to_utf8((MBT_SHORT*)bt_ev_msg_ptr->name_str,
					bt_ev_msg_ptr->name_len,
					sdcFtpStatus->TargetFile.FileName, MBT_MAX_FILE_NAME_LEN);

#ifdef MBT_FTP_FILENAME_LOG
	{
		int i;
		MBT_PI("delete filename req:dir_len:%d", strlen(sdcFtpStatus->TargetFile.DirName), 0, 0);
		for ( i = 0 ; i < strlen(sdcFtpStatus->TargetFile.DirName) ; i+=3 )
			MBT_PI("(%c%c%c)", sdcFtpStatus->TargetFile.DirName[i], sdcFtpStatus->TargetFile.DirName[i+1], sdcFtpStatus->TargetFile.DirName[i+2]);
		MBT_PI("delete filename req:file_len:%d", strlen(sdcFtpStatus->TargetFile.FileName), 0, 0);
		for ( i = 0 ; i < strlen(sdcFtpStatus->TargetFile.FileName) ; i+=3 )
			MBT_PI("(%c%c%c)", sdcFtpStatus->TargetFile.FileName[i], sdcFtpStatus->TargetFile.FileName[i+1], sdcFtpStatus->TargetFile.FileName[i+2]);
	}
#endif

		mbt_postevent(MBTEVT_FTP_SERVER_ACCESS_REQUEST, 0);
	}
	else
	{
		cmd_status = bt_cmd_pf_ftp_srv_delete_done(qbt_ftp_server.app_id,
					qbt_ftp_server.conn_id, OI_OBEX_NOT_FOUND);
	}
}

MBT_VOID qbt_proc_evt_ftp_srv_set_folder_req(bt_pf_ev_ftp_srv_set_folder_req_type* bt_ev_msg_ptr)
{
	T_MBT_FTP_STATUS * sdcFtpStatus = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);

	MBT_PI("mbt_ftp_srv_set_folder> conn_id:%x create:%x ftp_stat:%d", bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->create, sdcFtpStatus->FtpState);
	MBT_PI("mbt_ftp_srv_set_folder> level:%d folder name len:%d", bt_ev_msg_ptr->level, bt_ev_msg_ptr->folder_name_len, 0);

	if ( bt_ev_msg_ptr->create )	// create folder req
	{
#if 0
		MBT_SHORT	name_len;
		sdcFtpStatus->Operation = MBT_FTP_OPER_MK_DIR;
		memset(sdcFtpStatus->TargetFile.FileName, 0, MBT_MAX_FILE_NAME_LEN);
		strncpy(sdcFtpStatus->TargetFile.FileName, qbt_ftp_server.cur_dir, MBT_MAX_FILE_NAME_LEN-1);
		name_len = strlen(sdcFtpStatus->TargetFile.FileName);
		
		if ( sdcFtpStatus->TargetFile.FileName[name_len-1] != '/' )
			sdcFtpStatus->TargetFile.FileName[name_len++] = '/';
		
		mbt_ucs2_to_utf8((MBT_SHORT*)bt_ev_msg_ptr->folder_name_str,
					bt_ev_msg_ptr->folder_name_len,
					&sdcFtpStatus->TargetFile.FileName[name_len],
					MBT_MAX_FILE_NAME_LEN-name_len);
#else
		MBT_PI("mbt ftp : does not support create folder", 0, 0, 0);
		bt_cmd_pf_ftp_srv_set_folder_done(qbt_ftp_server.app_id, qbt_ftp_server.conn_id, OI_FAIL);
#endif
		return;
	}
	else		// set path req
	{
		sdcFtpStatus->Operation = MBT_FTP_OPER_CHG_DIR;
		if (bt_ev_msg_ptr->level == 0 )	// cd root
		{
#if MBT_FTP_VIRTUAL_FOLDER == TRUE
			sdcFtpStatus->TargetFile.FileName[0] = '/';
			sdcFtpStatus->TargetFile.FileName[1] = 0;
#else
			memset(sdcFtpStatus->TargetFile.FileName, 0, MBT_MAX_FILE_NAME_LEN);
			strncpy(sdcFtpStatus->TargetFile.FileName, qbt_ftp_server.root_dir, MBT_MAX_FILE_NAME_LEN);
			MBT_PI("mbt ftp : cd root req : dir len:%d", strlen(sdcFtpStatus->TargetFile.FileName), 0, 0);
#endif
		}
		else		// forward or backward
		{
			if ( bt_ev_msg_ptr->folder_name_len == 0 ||
						bt_ev_msg_ptr->folder_name_str[0] == 0 )	// cd backward
			{
//				if ( qbt_ftp_server.cur_dir[0] == '/' &&  qbt_ftp_server.cur_dir[1] == 0 )	// already root folder
				if ( mbt_ftp_is_root(qbt_ftp_server.cur_dir) )
					bt_cmd_pf_ftp_srv_set_folder_done(qbt_ftp_server.app_id, qbt_ftp_server.conn_id, OI_FAIL);
				else
				{
#if MBT_FTP_VIRTUAL_FOLDER == TRUE
						// cd up
						MBT_CHAR	*ptr;
						MBT_SHORT  dir_len;

						// make up folder name
						memset(sdcFtpStatus->TargetFile.FileName, 0, MBT_MAX_FILE_NAME_LEN);
						strncpy(sdcFtpStatus->TargetFile.FileName, qbt_ftp_server.cur_dir, MBT_MAX_FILE_NAME_LEN);
						dir_len = strlen(sdcFtpStatus->TargetFile.FileName);
						if(sdcFtpStatus->TargetFile.FileName[dir_len-1] == '/' )
							sdcFtpStatus->TargetFile.FileName[--dir_len] = 0;	// remove last slash
						ptr = StrrChr(sdcFtpStatus->TargetFile.FileName, dir_len, '/');		// find last slash
						if ( ptr == 0 )
						{
							sdcFtpStatus->TargetFile.FileName[0] = '/';
							sdcFtpStatus->TargetFile.FileName[1] = 0;
						}
						else
						{
							*ptr = 0;		// remove last slash
						}
#else
					// cd up
					MBT_SHORT idx;
					idx = strlen(qbt_ftp_server.cur_dir)-2;	
					for( ; idx > 0 ; idx-- )
					{
						if ( qbt_ftp_server.cur_dir[idx] == '/' )
							break;
					}
					memset(sdcFtpStatus->TargetFile.FileName, 0, MBT_MAX_FILE_NAME_LEN);
					if(idx < strlen(qbt_ftp_server.root_dir) || idx < 1 )
						strncpy(sdcFtpStatus->TargetFile.FileName, qbt_ftp_server.root_dir, MBT_MAX_FILE_NAME_LEN);
					else
						strncpy(sdcFtpStatus->TargetFile.FileName, qbt_ftp_server.cur_dir, idx+1);
#endif
					MBT_PI("mbt ftp : cd up req : dir len:%d", strlen(sdcFtpStatus->TargetFile.FileName), 0, 0);
				}
			}
			else		// cd forward
			{
#if MBT_FTP_VIRTUAL_FOLDER == TRUE
				// move down directory
				MBT_INT	idx;
				if ( qbt_ftp_server.cur_dir[0] == '/' &&  qbt_ftp_server.cur_dir[1] == 0 )	// current root
				{
					mbt_ucs2_to_utf8((MBT_SHORT*)bt_ev_msg_ptr->folder_name_str,
								bt_ev_msg_ptr->folder_name_len,
								sdcFtpStatus->TargetFile.FileName, MBT_MAX_FILE_NAME_LEN-1);
					idx = mbt_ftp_find_virtual_index(sdcFtpStatus->TargetFile.FileName);
					if ( idx == -1 )		// path not found
					{
						bt_cmd_pf_ftp_srv_set_folder_done(qbt_ftp_server.app_id, qbt_ftp_server.conn_id, OI_FAIL);
						return;
					}
					else
						strcpy(sdcFtpStatus->TargetFile.FileName, sdcFtpStatus->FTPDirName[idx].RealDir);
				}
				else
				{
					bt_cmd_pf_ftp_srv_set_folder_done(qbt_ftp_server.app_id, qbt_ftp_server.conn_id, OI_FAIL);
					return;
				}
#else
				// move down directory
				MBT_INT	path_len;

				memset(sdcFtpStatus->TargetFile.FileName, 0, MBT_MAX_FILE_NAME_LEN);
				strncpy(sdcFtpStatus->TargetFile.FileName,
							qbt_ftp_server.cur_dir,
							MBT_MAX_FILE_NAME_LEN);
				path_len = strlen(sdcFtpStatus->TargetFile.FileName);
				if(sdcFtpStatus->TargetFile.FileName[path_len-1] != '/' )
					sdcFtpStatus->TargetFile.FileName[path_len++] = '/';
				
				mbt_ucs2_to_utf8((MBT_SHORT*)bt_ev_msg_ptr->folder_name_str,
							bt_ev_msg_ptr->folder_name_len,
							(MBT_CHAR*)&sdcFtpStatus->TargetFile.FileName[path_len],
							MBT_MAX_FILE_NAME_LEN-path_len);
				path_len = strlen(sdcFtpStatus->TargetFile.FileName);
				if(sdcFtpStatus->TargetFile.FileName[path_len-1] != '/' )
					sdcFtpStatus->TargetFile.FileName[path_len++] = '/';
				sdcFtpStatus->TargetFile.FileName[path_len] = 0x00;
				
				//�������� �ʴ� ������ ���ؼ� error�� �����ϴ� �ڵ尡 ����. 
#endif
				MBT_PI("mbt ftp : cd down req : dir len:%d", strlen(sdcFtpStatus->TargetFile.FileName), 0, 0);
			}
		}
#ifdef MBT_FTP_CUR_DIR_LOG
		{
			int i;
			for ( i = 0 ; i < strlen(sdcFtpStatus->TargetFile.FileName) ; i+=3 )
				MBT_PI("(%c%c%c)", sdcFtpStatus->TargetFile.FileName[i], sdcFtpStatus->TargetFile.FileName[i+1], sdcFtpStatus->TargetFile.FileName[i+2]);
		}
#endif
	}

	mbt_postevent(MBTEVT_FTP_SERVER_ACCESS_REQUEST, 0);
}

MBT_VOID mbt_ftp_Server_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{

	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
			MBT_PI("mbt_ftp_srv_cmd_done cmd:%x status:%x",
						bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type,
						bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status, 0);
	      		break;

  		case BT_EV_PF_FTP_SRV_CON_IND:
			qbt_proc_evt_ftp_srv_con_ind(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_con_ind);
			break;

  		case BT_EV_PF_FTP_SRV_DCN_IND:
  			qbt_proc_evt_ftp_srv_dcn_ind(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_dcn_ind);
			break;

		case BT_EV_PF_FTP_SRV_BROWSE_REQ:
			qbt_proc_evt_ftp_srv_browse_req(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_browse_req);
			break;

		case BT_EV_PF_FTP_SRV_OPEN_REQ:
			qbt_proc_evt_ftp_srv_open_req(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_open_req);
			break;

		case BT_EV_PF_FTP_SRV_CLOSE_REQ:
			qbt_proc_evt_ftp_srv_close_req(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_close_req);
			break;

		case BT_EV_PF_FTP_SRV_READ_REQ:
			qbt_proc_evt_ftp_srv_read_req(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_read_req);
			break;

		case BT_EV_PF_FTP_SRV_WRITE_REQ:
			qbt_proc_evt_ftp_srv_write_req(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_write_req);
			break;

		case BT_EV_PF_FTP_SRV_DELETE_REQ:
			qbt_proc_evt_ftp_srv_delete_req(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_delete_req);
			break;

		case BT_EV_PF_FTP_SRV_SET_FOLDER_REQ:
			qbt_proc_evt_ftp_srv_set_folder_req(&bt_ev_msg_ptr->ev_msg.ev_ftp_srv_set_folder_req);
			break;

		default:
			MBT_ERR( "mbt_ftp_srv_cb - unexpect event %x",  bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0 );
			break;
  	}
}

MBT_VOID mbt_ftp_Client_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ftp_init (MBT_VOID)
*	Description : 
********************************************************************************/
MBT_VOID mbt_ftp_init(MBT_VOID)
{
	if(qbt_ftp_server.app_id == BT_APP_ID_NULL)
	{
		qbt_ftp_server.app_id = bt_cmd_ec_get_app_id_and_register(mbt_ftp_Server_EventCallback);
		if (qbt_ftp_server.app_id == BT_APP_ID_NULL)
		{
			MBT_ERR("mbt_ftp_server_enable> FTP Server App id register error. app_id :%d",qbt_ftp_server.app_id,0,0);
			mbt_postevent(MBTEVT_FTP_SERVER_ENABLE_FAIL, 0);
			return;
		}
	}
	else
	{
		MBT_FATAL("##FTS Initialize Over time Error. app_id ");
	}
}

#endif	//#if (MBT_FTP == MBT_TRUE)
