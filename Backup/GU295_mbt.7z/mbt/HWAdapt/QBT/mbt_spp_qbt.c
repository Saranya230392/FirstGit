/*******************************************************************************
*	SPP�� MBT 1.0���� ���Ե��� ������ �׽�Ʈ ���� �ʾҽ��ϴ�.
********************************************************************************/
/********************************************************************************
*	File Name	: mbt_spp_brcm.c
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.04.12	Kim,Hyunseok		Created
********************************************************************************/
#include "mbt_spp.h"
#include "mbt_sdc.h"
#include "mbt_evhandler.h"
#include "mbt_gap.h"
#include "qbt_utils/qbt_fs.h"
#include "qbt_utils/qbt_lang.h"
#include "qbt_utils/qbt_utils.h"
#include "qbt_utils/btumtssync.h"
#include "bt.h"
#include "btsd.h"


static bt_app_id_type  mbt_spp_app_id = BT_APP_ID_NULL;
MBT_VOID mbt_spp_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );
#if (MBT_SPP == MBT_TRUE)

/********************************************************************************
*	Prototype	: MBT_VOID mbt_spp_init (MBT_VOID)
*	Description : 
********************************************************************************/
MBT_VOID mbt_spp_init(MBT_VOID)
{
	if(mbt_spp_app_id == BT_APP_ID_NULL)
	{
		mbt_spp_app_id = bt_cmd_ec_get_app_id_and_register( mbt_spp_EventCallback );
		if ( mbt_spp_app_id == BT_APP_ID_NULL )
		{
			  if ( mbt_spp_app_id != BT_APP_ID_NULL )
			  {
					bt_cmd_ec_free_application_id(mbt_spp_app_id );
					mbt_spp_app_id = BT_APP_ID_NULL;
			  }
		}
	}	
	else
	{
		MBT_FATAL("##SPP Initialize Over time Error. app_id ");
	}
}
/*=========================================================================== 
*	Prototype	:		MBT_VOID mbt_spp_enable (MBT_VOID)
*	Description: 		SPP ���������� Ȱ��ȭ ��Ų��.
*	Return	:		NONE
*	Expected Event:	MBTEVT_SPP_ENABLE_FAIL
*		                     MBTEVT_SPP_ENABLE_SUCCESS
===========================================================================*/
MBT_VOID mbt_spp_enable (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else	
	T_MBT_SPP_STATUS * sdcSppStatus = (T_MBT_SPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_SPP_STATUS);

	if(sdcSppStatus->bEnabled == MBT_FALSE)
	{
		bt_umts_sync_server_enable(mbt_spp_app_id);		
		//mbt_postevent(MBTEVT_SPP_ENABLE_SUCCESS, 0); // LEECHANGHOON 2008-2-1 Callback���� �ø���.
	}
	else
	{
		MBT_WARN("mbt_spp_enable> SPP is aleady enabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_SPP_ENABLE_FAIL, 0);
	}
	
#endif
}

/*===========================================================================
*	Prototype	:	MBT_VOID mbt_spp_disable (MBT_VOID)
*	Description:	SPP ���������� ��Ȱ��ȭ ��Ų��.
*	Return	:	NONE
*	Expected Event:	MBTEVT_SPP_DISABLE_FAIL
*                 			MBTEVT_SPP_DISABLE_SUCCESS
===========================================================================*/
MBT_VOID mbt_spp_disable (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	bt_umts_sync_server_disable(mbt_spp_app_id);
#endif
}

/*===========================================================================
*	Prototype	:	MBT_VOID mbt_spp_connect (T_MBT_BDADDR *remoteBdAddr)
*	Description:	SPP service connection �� ���� ��Ų��
*	Return	:	NONE
*	Expected Event:	MBTEVT_SPP_DISCONNECT_FAIL
*  		                     MBTEVT_SPP_DISCONNECT_SUCCESS
===========================================================================*/
MBT_VOID mbt_spp_connect(T_MBT_BDADDR remoteBdAddr)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/*===========================================================================
*	Prototype	:	MBT_VOID mbt_spp_disonnect (T_MBT_BDADDR *remoteBdAddr)
*	Description:	SPP service connection �� ������ ���� ��Ų��
*	Return	:	NONE
*	Expected Event:	 MBTEVT_SPP_DISCONNECT_FAIL
*		                     MBTEVT_SPP_DISCONNECT_SUCCESS
===========================================================================*/
MBT_VOID mbt_spp_disconnect(T_MBT_BDADDR remoteBdAddr)
{	
#ifdef MBT_EMULATOR
#else
#endif
}

/*===========================================================================
*	Prototype	:	MBT_VOID mbt_spp_senddata(MBT_VOID)
*	Description:	Terminal ������, Data �� �����Ѵ�
*	Return	:	NONE
*	Expected Event:	    MBTEVT_SPP_SEND_DATA_FAIL
*                  			    MBTEVT_SPP_SEND_DATA_SUCCESS
===========================================================================*/
MBT_VOID mbt_spp_senddata(T_MBT_SPP_DATA *txData)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/*===========================================================================
*	Prototype	:		MBT_VOID mbt_spp_listen (MBT_VOID)
*	Description: 		SPP ���������� Ȱ��ȭ ��Ų��.
*	Return	:		NONE
*	Expected Event:
===========================================================================*/
MBT_VOID mbt_spp_listen(MBT_VOID)
{
}

/*===========================================================================
* Listen stop
===========================================================================*/
MBT_VOID mbt_spp_listenstop(MBT_VOID)
{
}

MBT_VOID mbt_spp_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{
	T_MBT_SPP_STATUS * sdcSPPStatus = (T_MBT_SPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_SPP_STATUS);

	MBT_WARN("SPP_EventType : 0x%x", (bt_ev_msg_ptr->ev_hdr.ev_type ),0,0);

	switch(bt_ev_msg_ptr->ev_hdr.ev_type)
	{
	  	case BT_EV_GN_CMD_DONE:		
			{
				bt_ev_gn_cmd_done_type* pm =    (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;
				MBT_SDC("SPP_Event BT_EV_GN_CMD_DONE cmd = 0x%x, status= %d",   pm->cmd_type, pm->cmd_status,0);
	  		}
			break;
			
		case BT_EV_UMTS_SYNC_ENABLED:
			sdcSPPStatus->bEnabled = MBT_TRUE;		
			sdcSPPStatus->bConection= MBT_FALSE;
			mbt_postevent(MBTEVT_SPP_ENABLE_SUCCESS, 0);
			MBT_SDC("SPP_Event SPP_ENALBED", 0, 0, 0);
			break;
			
		case BT_EV_UMTS_SYNC_ENABLE_FAIL:
			sdcSPPStatus->bEnabled = MBT_FALSE;
			sdcSPPStatus->bConection= MBT_FALSE;
			mbt_postevent(MBTEVT_SPP_ENABLE_FAIL, 0);
			break;
			
		case BT_EV_UMTS_SYNC_DISABLED:
			sdcSPPStatus->bEnabled = MBT_FALSE;
			mbt_postevent(MBTEVT_SPP_DISABLE_SUCCESS, 0);
			break;
			
		case BT_EV_RM_DISCONNECTED_ACL:
		case BT_EV_UMTS_SYNC_CONN_CLOSE:
			sdcSPPStatus->bConection= MBT_FALSE;
			mbt_postevent(MBTEVT_SPP_DISCONNECT_SUCCESS, 0);
			break;
			
		case BT_EV_UMTS_SYNC_CONN_ESTABLISHED:
			sdcSPPStatus->bConection= MBT_TRUE;		
			mbt_postevent(MBTEVT_SPP_CONNECT_SUCCESS, 0);
			break;
			
		default:
			MBT_WARN("MBT_SPP CALLBACK Unexpect ev_type:%d ",bt_ev_msg_ptr->ev_hdr.ev_type,0,0);
			break;
	}
}

#endif
