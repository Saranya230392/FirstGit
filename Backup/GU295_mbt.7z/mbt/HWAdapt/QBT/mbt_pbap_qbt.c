/*-----------------------------------------------------------------------------
File qbt_pbap.c

GENERAL DESCRIPTION
This file contains pbap hooks to/from QBT Stack from/to MBT BT Layer.

Copyright (c) 2009 QUALCOMM Incorporated.
All Rights Reserved.
Qualcomm Confidential and Proprietary
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------

                        EDIT HISTORY FOR MODULE

  This section contains comments describing changes made to the module.
  Notice that changes are listed in reverse chronological order.

  $Header: None $
  $DateTime: None $
  $Author: ytkim $

  when        who  what, where, why
  ----------  ---  ------------------------------------------------------------
  2009-01-15   BK  Initial Revision

-----------------------------------------------------------------------------*/

#include "mbt_sdc.h"
#include "mbt_pbap.h"
#include "MBTType.h"
#include "oi_unicode.h"
#include "UnicodeLib.h"
#include "btpfcmdi.h"
#include "AEEstd.h"
#include "btpf.h"
#include "btmsg.h"

#include "qbt_utils/qbt_fs.h"
#include "qbt_utils/qbt_lang.h"


#include <stdio.h>
#include <string.h>

#define MBT_PBAP_FILENAME_LOG

#define MBT_PBAP_PB_TYPE_PB              "pb.vcf"
#define MBT_PBAP_PB_TYPE_ICH             "ich.vcf"
#define MBT_PBAP_PB_TYPE_OCH             "och.vcf"
#define MBT_PBAP_PB_TYPE_MCH             "mch.vcf"
#define MBT_PBAP_PB_TYPE_CCH             "cch.vcf"

#define PBAP_SPLIT_SEND	//sliver97

typedef enum {
  MBT_PBAP_OP_TYPE_NONE,
  MBT_PBAP_OP_TYPE_PULL_PHONEBOOK,
  MBT_PBAP_OP_TYPE_SET_PATH,
  MBT_PBAP_OP_TYPE_GET_FOLDER_LISTING,
  MBT_PBAP_OP_TYPE_PULL_VCARD
} qbt_pbap_op_type;

typedef enum {
  MBT_PBAP_CURR_DIR_ROOT,
  MBT_PBAP_CURR_DIR_SIM1,
  MBT_PBAP_CURR_DIR_TELECOM,
  MBT_PBAP_CURR_DIR_PHONE_BOOK
} qbt_pbap_dir_type;

typedef struct {
	bt_app_id_type		          app_id;
	bt_pf_pbap_srv_conn_id_type conn_id;
  fs_handle_type              fs_handle;
  unsigned int                obj_size;
  T_MBT_PBAP_STORAGE          rep_type;
  qbt_pbap_dir_type           curr_dir;
  T_MBT_PBAP_DIR              pb_type;
  qbt_pbap_op_type            curr_op;
  uint8 *                     new_missed_calls_ptr;
} mbt_qbt_pbap_srv_object;

static mbt_qbt_pbap_srv_object qbt_pbap_srv = { 
  BT_APP_ID_NULL, BT_PF_PBAP_NO_CONN_ID, 0, 0, 0, 0, 0, 0, 0 };

static char filename[BT_PF_MAX_FILENAME_LEN*3+1];
static MBT_BYTE mbt_qbt_pbap_buf[MBT_OBEX_FILE_BUF_LEN];

static unsigned char folder_str[BT_PF_MAX_FILENAME_LEN*3+1];
static unsigned short folder_wstr[BT_PF_MAX_FILENAME_LEN];

static bt_pf_byte_seq_type pbap_byte_seq = {0, 0};

static char qbt_pbap_root_folder_listing_str[] = 
"<?xml version=\"1.0\"?>\n\
<!DOCTYPE vcard-listing SYSTEM \"vcard-listing.dtd\">\n\
<vCard-listing version=\"1.0\">\n\
<folder name=\"telecom\"/>\n\
<folder name=\"SIM1\"/>\n\
</vCard-listing>";

static char qbt_pbap_sim1_folder_listing_str[] = 
"<?xml version=\"1.0\"?>\n\
<!DOCTYPE vcard-listing SYSTEM \"vcard-listing.dtd\">\n\
<vCard-listing version=\"1.0\">\n\
<folder name=\"telecom\"/>\n\
</vCard-listing>";

static char qbt_pbap_telecom_folder_listing_str[] = 
"<?xml version=\"1.0\"?>\n\
<!DOCTYPE vcard-listing SYSTEM \"vcard-listing.dtd\">\n\
<vCard-listing version=\"1.0\">\n\
<folder name=\"pb\"/>\n\
<folder name=\"ich\"/>\n\
<folder name=\"och\"/>\n\
<folder name=\"mch\"/>\n\
<folder name=\"cch\"/>\n\
</vCard-listing>";

static MBT_BOOL mbt_pbap_CheckCmdStatus( bt_cmd_status_type stat );
static MBT_VOID mbt_pbap_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );
static MBT_VOID qbt_pbap_srv_send_dir_data(bt_cmd_status_type stat);
static MBT_VOID qbt_pbap_srv_send_one_vcard(bt_cmd_status_type stat);
static MBT_VOID qbt_pbap_srv_send_dir_list(bt_cmd_status_type stat);
static MBT_VOID qbt_pbap_notify_app(bt_cmd_status_type status);
static MBT_VOID qbt_pbap_file_close(MBT_VOID);

#if (MBT_PBAP == MBT_TRUE)

/********************************************************************************
*	Prototype	: mbt_pbap_init(void)
*	Description	: 
********************************************************************************/
void mbt_pbap_init(void)
{
   T_MBT_PBAP_STATUS * sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

   memset(sdcPbapStatus, 0x00, sizeof(sdcPbapStatus));

   qbt_pbap_srv.app_id = BT_APP_ID_NULL;
   qbt_pbap_srv.conn_id = BT_PF_PBAP_NO_CONN_ID;
   
   return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_pbap_server_enable (MBT_VOID)
*	Description	: 
********************************************************************************/
void mbt_pbap_server_enable (void)
{
  bt_cmd_status_type pbap_rst;
  T_MBT_PBAP_STATUS * sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

  if(sdcPbapStatus->bEnabled == MBT_FALSE)
  {
    /* get app_id */
    qbt_pbap_srv.app_id = bt_cmd_ec_get_app_id_and_register(mbt_pbap_EventCallback);
    if (qbt_pbap_srv.app_id == BT_APP_ID_NULL) 
    {
      MBT_ERR("mbt_pbap_server_enable> PBAP App id register error. app_id : NULL",0,0,0);
      mbt_postevent(MBTEVT_PBAP_SERVER_ENABLE_FAIL, 0);
      return;
    }
  }
  else
  {
    MBT_WARN("mbt_pbap_server_enable> PBAP is aleady enabled. Don't proceed & return",0,0,0);
    mbt_postevent(MBTEVT_PBAP_SERVER_ENABLE_FAIL, 0);
    return;
  }

  pbap_rst = bt_cmd_pf_pbap_srv_register( qbt_pbap_srv.app_id,
                                         "LGE PBAP Server",
                                         0x03, /* repositories, both local and sim */
                                         BT_PF_GOEP_SRV_AUTH_NONE);
  if(!mbt_pbap_CheckCmdStatus(pbap_rst))
  {	
    MBT_ERR("PBAP Server Enable Fail. Reason code : %x",pbap_rst,0,0);
    mbt_postevent(MBTEVT_PBAP_SERVER_ENABLE_FAIL, 0);
  }
  else
  {
    sdcPbapStatus->bEnabled = MBT_TRUE;
    sdcPbapStatus->State = MBT_PBAP_STATE_ENABLED;
  }

  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_pbap_server_disable (MBT_VOID)
*	Description	: 
********************************************************************************/
void mbt_pbap_server_disable (void)
{
	bt_cmd_status_type pbap_rst;
	T_MBT_PBAP_STATUS * sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

	if(sdcPbapStatus->bEnabled == MBT_TRUE)
	{
    pbap_rst = bt_cmd_pf_pbap_srv_deregister(qbt_pbap_srv.app_id);
    if(!mbt_pbap_CheckCmdStatus(pbap_rst))
    {
      MBT_ERR("mbt_pbap_server_disable> deregister fail. Reason code : %x",pbap_rst,0,0);
      mbt_postevent(MBTEVT_PBAP_SERVER_DISABLE_FAIL, 0);
    }
	}
	else
	{
		MBT_WARN("mbt_pbap_server_disable> Pbap is aleady disabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_PBAP_SERVER_DISABLE_FAIL, 0);
	}

  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_pbap_server_accessresponse (MBT_BOOL b_allow)
*	Description	: 
********************************************************************************/
void mbt_pbap_server_accessresponse(MBT_BOOL b_allow)
{
	bt_cmd_status_type stat = BT_CS_PF_OBEX_BAD_REQUEST;
	T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

  MBT_PI("mbt_pbap_server_accessresponse> allow:%d op:%d", b_allow, sdcPbapStatus->Operation, 0);

  if (b_allow == MBT_TRUE) 
  {
    // do nothing as we expect writedata() to be called later..
    return;
  }

  if (sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_DIRECTORY_DATA)
  {
    qbt_pbap_srv_send_dir_data(stat);
  }
  else if (sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_DIRECTORY_NUM)
  {
    if (qbt_pbap_srv.curr_op == MBT_PBAP_OP_TYPE_PULL_PHONEBOOK) 
    {
      qbt_pbap_srv_send_dir_data(stat);
    }
    else // curr_op == MBT_PBAP_OP_TYPE_GET_FOLDER_LISTING
    {
      qbt_pbap_srv_send_dir_list(stat);
    }
  }
  else if (sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_DIRECTORY_LIST) 
  {
    qbt_pbap_srv_send_dir_list(stat);
  }
  else if (sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_ONE_VCARD)
  {
    qbt_pbap_srv_send_one_vcard(stat);
  }
  else
  {
    MBT_ERR("mbt_pbap_server_accessresponse> invalid operation state %d", 
            sdcPbapStatus->Operation, 0, 0);
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_pbap_server_authenticate (char *p_password, char *p_userid)
*	Description	: 
********************************************************************************/
void mbt_pbap_server_authenticate(char *p_password, char *p_userid)
{
  T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

  MBT_PI("PBAP auth response : state:%x", sdcPbapStatus->State, 0, 0);

  (void) bt_cmd_pf_pbap_srv_auth_response(qbt_pbap_srv.app_id,
                                          qbt_pbap_srv.conn_id,
                                          p_password); // TODO: no provision to send userid
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_pbap_server_close (MBT_VOID)
*	Description	: 
********************************************************************************/
void mbt_pbap_server_close(void)
{
  T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

  MBT_PI("PBAP server close: state:%x", sdcPbapStatus->State, 0, 0);
  if (sdcPbapStatus->State >= MBT_PBAP_STATE_CONNECTED) 
  {
    bt_cmd_pf_pbap_srv_force_disconnect(qbt_pbap_srv.app_id, qbt_pbap_srv.conn_id);
  }
  else
  {
    MBT_ERR("PBAP server close failed: no connection", 0, 0, 0);
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_pbap_server_writedata (T_MBT_PBAP_OP Operation)
*	Description	: 
********************************************************************************/
void mbt_pbap_server_writedata(T_MBT_PBAP_OP Operation)
{
	T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);
	bt_cmd_status_type status;
	uint8 num_missed_calls = 0;

	MBT_PI("PBAP server writedata: state:%x", sdcPbapStatus->State, 0, 0);

  	status = (sdcPbapStatus->vCardOut.Result==MBT_TRUE)?BT_CS_GN_SUCCESS:BT_CS_PF_OBEX_BAD_REQUEST;

	if ((sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_DIRECTORY_DATA && sdcPbapStatus->PullDirectoryDataIn.MaxListCount == 0) 
	  ||(sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_DIRECTORY_LIST && sdcPbapStatus->PullDirectoryListIn.MaxListCount == 0)
	  || sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_DIRECTORY_NUM)
	{

		if (qbt_pbap_srv.pb_type == MBT_PBAP_DIR_MCH) {
			num_missed_calls = (uint8)sdcPbapStatus->vCardOut.NewMissedCallCount;
    	}
	
    	if (qbt_pbap_srv.curr_op == MBT_PBAP_OP_TYPE_PULL_PHONEBOOK) 
    	{
      		(void) bt_cmd_pf_pbap_srv_pull_phone_book_response(
        		qbt_pbap_srv.app_id,
        		qbt_pbap_srv.conn_id,
        		NULL, /* data */
        		(uint16*)&sdcPbapStatus->vCardOut.vCardTotalCount, /* phone book size */
        		&num_missed_calls, /* new missed calls */
        		1,    /* final */
        		status);
    	}
    	else // curr_op == MBT_PBAP_OP_TYPE_GET_FOLDER_LISTING
    	{
      		(void) bt_cmd_pf_pbap_srv_pull_vcard_listing_response(
        		qbt_pbap_srv.app_id,
        		qbt_pbap_srv.conn_id,
        		NULL,  /* data */
        		(uint16*) &sdcPbapStatus->vCardOut.vCardListTotalCount, /* phone book size */
        		&num_missed_calls, /* new missed calls */
        		1,    /* final */
        		status);
    	}
  	}
  	else if (sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_DIRECTORY_DATA) 
  	{
    	qbt_pbap_srv_send_dir_data(status);
  	}
  	else if (sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_DIRECTORY_LIST) 
  	{
    	qbt_pbap_srv_send_dir_list(status);
  	}	
  	else if (sdcPbapStatus->Operation == MBT_PBAP_OP_PULL_ONE_VCARD)
  	{
    	qbt_pbap_srv_send_one_vcard(status);
  	}
  	else
  	{
    	// unknown op
    	MBT_ERR("mbt_pbap_server_writedata> unknown op! %d", sdcPbapStatus->Operation, 0, 0);
  	}
}

/********************************************************************************
*	Prototype	: MBT_BOOL mbt_pbap_CheckCmdStatus (bt_cmd_status_type stat)
*	Description	: 
********************************************************************************/
static MBT_BOOL mbt_pbap_CheckCmdStatus(bt_cmd_status_type stat)
{
	switch (stat)
	{
		case BT_CS_GN_SUCCESS:
		case BT_CS_GN_PENDING:
			return MBT_TRUE; //SUCCESS;

		case BT_CS_GN_CMD_Q_FULL:
			MBT_ERR("mbt_pbap_CheckCmdStatus status:%d", stat,0,0);
			return MBT_FALSE; //ENOMEMORY;

		default:
			MBT_ERR("mbt_pbap_CheckCmdStatus status:%d", stat,0,0);
			return MBT_FALSE; //EFAILED;
	}
}


/********************************************************************************
*	Prototype	: MBT_VOID mbt_pbap_HandleCmdDone( bt_ev_msg_type* bt_ev_msg_ptr )
*	Description :
********************************************************************************/
static MBT_VOID mbt_pbap_HandleCmdDone( bt_ev_gn_cmd_done_type* pCmdDn )
{
	T_MBT_PBAP_STATUS * sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);
  bt_cmd_status_type pbap_rst;

  switch (pCmdDn->cmd_type)
  {
    case BT_PF_CMD_PBAP_SRV_REGISTER:
    {
      if(mbt_pbap_CheckCmdStatus(pCmdDn->cmd_status))
      {	
        sdcPbapStatus->bEnabled = MBT_TRUE;
        sdcPbapStatus->State = MBT_PBAP_STATE_ENABLED;
        MBT_PI("PBAP Server Enabled",0,0,0);
        mbt_postevent(MBTEVT_PBAP_SERVER_ENABLE_SUCCESS, 0);
      }
      else
      {
        sdcPbapStatus->bEnabled = MBT_FALSE;
        sdcPbapStatus->State = MBT_PBAP_STATE_DISABLED;
        MBT_ERR("PBAP Server Enable Fail. Reason code : %x",pCmdDn->cmd_status,0,0);
        mbt_postevent(MBTEVT_PBAP_SERVER_ENABLE_FAIL, 0);
      }
      break;
    }
    case BT_PF_CMD_PBAP_SRV_DEREGISTER:
    {
      if(mbt_pbap_CheckCmdStatus(pCmdDn->cmd_status))
      {	
        sdcPbapStatus->bEnabled = MBT_FALSE;
        sdcPbapStatus->State = MBT_PBAP_STATE_DISABLED;

        pbap_rst = bt_cmd_ec_free_application_id(qbt_pbap_srv.app_id);
        if(mbt_pbap_CheckCmdStatus(pbap_rst))
        {
          MBT_PI("PBAP Disabled",0,0,0);
          qbt_pbap_srv.app_id = BT_APP_ID_NULL;
          mbt_postevent(MBTEVT_PBAP_SERVER_DISABLE_SUCCESS, 0);
        }
        else
        {
          MBT_ERR("mbt_pbap_dereg_and_free_app_id> free app_id fail. Reason code : %x",pbap_rst,0,0);
          mbt_postevent(MBTEVT_PBAP_SERVER_DISABLE_FAIL, 0);
        }
      }
      else
      {
        MBT_ERR("PBAP Server Disable Fail. Reason code : %x",pCmdDn->cmd_status,0,0);
        mbt_postevent(MBTEVT_PBAP_SERVER_DISABLE_FAIL, 0);
      }
      break;
    }
    default:
    {
      MBT_PI("mbt_pbap_HandleCmdDone, cmd=%x, status=%x", 
             pCmdDn->cmd_type, pCmdDn->cmd_status, 0);
    }
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_pbap_srv_con_ind (
              bt_pf_ev_pbap_srv_con_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_proc_evt_pbap_srv_con_ind(
  bt_pf_ev_pbap_srv_con_ind_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	T_MBT_PBAP_STATUS * sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

  MBT_PI("qbt_proc_evt_pbap_srv_con_ind, conn_id:%x auth:%d ftp_stat:%d", 
         bt_ev_msg_ptr->conn_id, sdcPbapStatus->State, 0);

	if ( sdcPbapStatus->bEnabled && sdcPbapStatus->State == MBT_PBAP_STATE_ENABLED )
	{
		qbt_pbap_srv.conn_id = bt_ev_msg_ptr->conn_id;
		sdcPbapStatus->State = MBT_PBAP_STATE_CONNECTED;
		memcpy(sdcPbapStatus->BDAddr, (void*)bt_ev_msg_ptr->bd_addr.bd_addr_bytes, MBT_BDADDR_LEN);

		cmd_status = bt_cmd_pf_pbap_srv_accept_connect(qbt_pbap_srv.app_id,
                                                   qbt_pbap_srv.conn_id, TRUE);

		mbt_postevent(MBTEVT_PBAP_SERVER_CONNECT_SUCCESS, 0);
	}
	else
	{
		MBT_ERR("qbt_proc_evt_pbap_srv_con_ind> invalid_stat:%d reject connection", 
            bt_ev_msg_ptr->conn_id, sdcPbapStatus->State, 0);
		cmd_status = bt_cmd_pf_pbap_srv_accept_connect(qbt_pbap_srv.app_id,
                                                   qbt_pbap_srv.conn_id, FALSE);
	}
	mbt_misc_clearpbapfiles();
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_pbap_srv_dcn_ind (
              bt_pf_ev_pbap_srv_dcn_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_proc_evt_pbap_srv_dcn_ind(
  bt_pf_ev_pbap_srv_dcn_ind_type *bt_ev_msg_ptr)
{
	T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

	MBT_PI("qbt_proc_evt_pbap_srv_dcn_ind> conn_id:%x state:%d", 
         bt_ev_msg_ptr->conn_id, sdcPbapStatus->State, 0);

	sdcPbapStatus->State = MBT_PBAP_STATE_ENABLED;
	qbt_pbap_srv.conn_id = BT_PF_PBAP_NO_CONN_ID;
  qbt_pbap_srv.curr_op = MBT_PBAP_OP_TYPE_NONE;
  qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_ROOT;
  qbt_pbap_file_close();
  mbt_misc_clearpbapfiles();

	mbt_postevent(MBTEVT_PBAP_SERVER_DISCONNECT_SUCCESS, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_pbap_srv_auth_ind (
              bt_pf_ev_pbap_srv_auth_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_proc_evt_pbap_srv_auth_ind(
  bt_pf_ev_pbap_srv_auth_ind_type *bt_ev_msg_ptr)
{
	T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

	MBT_PI("qbt_proc_evt_pbap_srv_auth_ind> conn_id:%x state:%d", 
         bt_ev_msg_ptr->conn_id, sdcPbapStatus->State, 0);
	sdcPbapStatus->bIsObexUserID = FALSE;  // TODO: no provision to send user-id or 
                                         // indicate user-id is requred in PBAP
	qbt_pbap_srv.conn_id = bt_ev_msg_ptr->conn_id;

	mbt_postevent(MBTEVT_PBAP_SERVER_OBEX_AUTHREQ, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_srv_send_dir_data()
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_pbap_srv_send_dir_data(bt_cmd_status_type stat)
{
  bt_cmd_status_type cmd_status = BT_CS_GN_SUCCESS;
  bt_cmd_status_type status;
  uint8 filename_len;
  uint8* data_ptr = NULL;
  uint16 data_len = 0;
  MBT_BOOL final = 1;

  T_MBT_PBAP_STATUS *sdcPbapStatus = 
    (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

  qbt_pbap_srv.new_missed_calls_ptr = NULL;

	MBT_PI("MBT_PBAP  fs_handle(%d)", qbt_pbap_srv.fs_handle, 0, 0);

  if (stat == BT_CS_PF_OBEX_BAD_REQUEST) 
  {
    status = stat;
  }
  else
  {
    if (qbt_pbap_srv.fs_handle == 0) 
    {
      // first time, build dir/filename string
      filename_len = strlen(sdcPbapStatus->vCardOut.DirName);
      if ( sdcPbapStatus->vCardOut.DirName[filename_len-1] != '/' )
      {
        sdcPbapStatus->vCardOut.DirName[filename_len++] = '/';
      }
      sdcPbapStatus->vCardOut.DirName[filename_len] = 0x00;
      sprintf(filename, "%s%s", sdcPbapStatus->vCardOut.DirName, sdcPbapStatus->vCardOut.FileName);

      if (qbt_pbap_srv.pb_type == MBT_PBAP_DIR_MCH) 
      {
        qbt_pbap_srv.new_missed_calls_ptr = (uint8*)&sdcPbapStatus->vCardOut.NewMissedCallCount;
      }

      cmd_status = qbt_file_open_read(&qbt_pbap_srv.fs_handle, 
                                      (MBT_UINT*)&qbt_pbap_srv.obj_size, 
                                      (MBT_CHAR*)filename);
    }

    if (mbt_pbap_CheckCmdStatus(cmd_status)) 
    {
      data_ptr = mbt_qbt_pbap_buf;

      cmd_status = qbt_file_read(qbt_pbap_srv.fs_handle, MBT_OBEX_FILE_BUF_LEN, 
                                 (uint32*)&data_len, (byte*)data_ptr, 
                                 (uint32)qbt_pbap_srv.obj_size);

		MBT_PI("SEND PABP Data obj_size(%d), data_len(%d)", qbt_pbap_srv.obj_size, data_len, 0);
		MBT_PI("SEND PABP Data vCardMergedCount(%d), vCardTotalCount(%d)", sdcPbapStatus->vCardOut.vCardMergedCount, sdcPbapStatus->vCardOut.vCardTotalCount, 0);

	  if ( cmd_status == OI_OK || cmd_status == OI_STATUS_END_OF_FILE )
      { 
        pbap_byte_seq.data = data_ptr;
        pbap_byte_seq.len = data_len;
        final = (data_len < MBT_OBEX_FILE_BUF_LEN)?MBT_TRUE:MBT_FALSE;
		
//		�ΰ��� ���� ���� ������ UI�� �̺�Ʈ�� �ٽ� ���� ���� file�� �����ϵ��� ��û�Ѵ�.
#ifdef PBAP_SPLIT_SEND
		if(final == TRUE &&
			sdcPbapStatus->vCardOut.vCardMergedCount < sdcPbapStatus->vCardOut.vCardTotalCount)
		{
			MBT_PI("SEND PBAP complete first file made by UI  and let's send another request", 0, 0, 0);
			qbt_pbap_file_close();
			final = MBT_FALSE;
		}
#endif	
        status = (final)?BT_CS_GN_SUCCESS:BT_CS_PF_OBEX_CONTINUE;
      }
      else
      {
        MBT_ERR("qbt_pbap_srv_send_dir_data> error in file read, status=%x", cmd_status, 0, 0);
        status = BT_CS_PF_OBEX_INTERNAL_SERVER_ERROR;
      }
    }
    else
    {
      MBT_ERR("qbt_pbap_srv_send_dir_data> error in file open, status=%x", cmd_status, 0, 0);
      status = BT_CS_PF_OBEX_INTERNAL_SERVER_ERROR;
    }
  }

  (void) bt_cmd_pf_pbap_srv_pull_phone_book_response(
    qbt_pbap_srv.app_id,
    qbt_pbap_srv.conn_id,
    &pbap_byte_seq,
    NULL,  /* phone book size */
    qbt_pbap_srv.new_missed_calls_ptr,
    final,
    status);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_srv_send_dir_list()
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_pbap_srv_send_dir_list(bt_cmd_status_type stat)
{
  bt_cmd_status_type cmd_status = BT_CS_GN_SUCCESS;
  bt_cmd_status_type status;
  uint8 filename_len;
  uint8* data_ptr = NULL;
  uint16 data_len = 0;
  MBT_BOOL final = 1;

  T_MBT_PBAP_STATUS *sdcPbapStatus = 
    (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

  if (stat == BT_CS_PF_OBEX_BAD_REQUEST) 
  {
    status = stat;
  }
  else
  {
    if (qbt_pbap_srv.fs_handle == 0) 
    {
      // first time, build dir/filename string
      filename_len = strlen(sdcPbapStatus->vCardOut.DirName);
      if ( sdcPbapStatus->vCardOut.DirName[filename_len-1] != '/' )
      {
        sdcPbapStatus->vCardOut.DirName[filename_len++] = '/';
      }
      sdcPbapStatus->vCardOut.DirName[filename_len] = 0x00;
      sprintf(filename, "%s%s", sdcPbapStatus->vCardOut.DirName, sdcPbapStatus->vCardOut.FileName);

      cmd_status = qbt_file_open_read(&qbt_pbap_srv.fs_handle, 
                                      (MBT_UINT*)&qbt_pbap_srv.obj_size, 
                                      (MBT_CHAR*)filename);
    }

    if (mbt_pbap_CheckCmdStatus(cmd_status)) 
    {
      data_ptr = mbt_qbt_pbap_buf;

      cmd_status = qbt_file_read(qbt_pbap_srv.fs_handle, MBT_OBEX_FILE_BUF_LEN, 
                                 (uint32*)&data_len, (byte*)data_ptr, 
                                 (uint32)qbt_pbap_srv.obj_size);

	  if ( cmd_status == OI_OK || cmd_status == OI_STATUS_END_OF_FILE )
      { 
        pbap_byte_seq.data = data_ptr;
        pbap_byte_seq.len = data_len;
        final = (data_len < MBT_OBEX_FILE_BUF_LEN)?MBT_TRUE:MBT_FALSE;
        status = (final)?BT_CS_GN_SUCCESS:BT_CS_PF_OBEX_CONTINUE;
      }
      else
      {
        MBT_ERR("qbt_pbap_srv_send_dir_list> error in file read, status=%x", cmd_status, 0, 0);
        status = BT_CS_PF_OBEX_INTERNAL_SERVER_ERROR;
      }
    }
    else
    {
      MBT_ERR("qbt_pbap_srv_send_dir_list> error in file open, status=%x", cmd_status, 0, 0);
      status = BT_CS_PF_OBEX_INTERNAL_SERVER_ERROR;
    }
  }

  (void) bt_cmd_pf_pbap_srv_pull_vcard_listing_response(
    qbt_pbap_srv.app_id,
    qbt_pbap_srv.conn_id,
    &pbap_byte_seq,
    NULL, /* phone book size ptr */
    NULL, /* new missed calls ptr */
    final,
    status);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_srv_send_one_vcard()
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_pbap_srv_send_one_vcard(bt_cmd_status_type stat)
{
  bt_cmd_status_type cmd_status = BT_CS_GN_SUCCESS;
  bt_cmd_status_type status;
  uint8 filename_len;
  uint8* data_ptr = NULL;
  uint16 data_len = 0;
  MBT_BOOL final = 1;

  T_MBT_PBAP_STATUS *sdcPbapStatus = 
    (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);

  if (stat == BT_CS_PF_OBEX_BAD_REQUEST) 
  {
    status = stat;
  }
  else
  {
    if (qbt_pbap_srv.fs_handle == 0) 
    {
      // first time, build dir/filename string
      filename_len = strlen(sdcPbapStatus->vCardOut.DirName);
      if ( sdcPbapStatus->vCardOut.DirName[filename_len-1] != '/' )
      {
        sdcPbapStatus->vCardOut.DirName[filename_len++] = '/';
      }
      sdcPbapStatus->vCardOut.DirName[filename_len] = 0x00;
      sprintf(filename, "%s%s", sdcPbapStatus->vCardOut.DirName, sdcPbapStatus->vCardOut.FileName);

      cmd_status = qbt_file_open_read(&qbt_pbap_srv.fs_handle, 
                                      (MBT_UINT*)&qbt_pbap_srv.obj_size, 
                                      (MBT_CHAR*)filename);
    }

    if (mbt_pbap_CheckCmdStatus(cmd_status)) 
    {
      data_ptr = mbt_qbt_pbap_buf;

      cmd_status = qbt_file_read(qbt_pbap_srv.fs_handle, MBT_OBEX_FILE_BUF_LEN, 
                                 (uint32*)&data_len, (byte*)data_ptr, 
                                 (uint32)qbt_pbap_srv.obj_size);

	  if ( cmd_status == OI_OK || cmd_status == OI_STATUS_END_OF_FILE )
      {
        pbap_byte_seq.data = data_ptr;
        pbap_byte_seq.len = data_len;
        final = (data_len < MBT_OBEX_FILE_BUF_LEN)?MBT_TRUE:MBT_FALSE;
        status = (final)?BT_CS_GN_SUCCESS:BT_CS_PF_OBEX_CONTINUE;
      }
      else
      {
        MBT_ERR("qbt_pbap_srv_send_one_vcard> error in file read, status=%x", cmd_status, 0, 0);
        status = BT_CS_PF_OBEX_INTERNAL_SERVER_ERROR;
      }
    }
    else
    {
      MBT_ERR("qbt_pbap_srv_send_one_vcard> error in file open, status=%x", cmd_status, 0, 0);
      status = BT_CS_PF_OBEX_INTERNAL_SERVER_ERROR;
    }
  }

  (void) bt_cmd_pf_pbap_srv_pull_vcard_entry_response(
    qbt_pbap_srv.app_id,
    qbt_pbap_srv.conn_id,
    &pbap_byte_seq,
    final,
    status);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_srv_send_folder_listing_resp()
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_pbap_srv_send_folder_listing_resp()
{
  bt_cmd_status_type status = BT_CS_GN_SUCCESS;
  MBT_BOOL final = 1;

  if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_ROOT) 
  {
    pbap_byte_seq.data = (byte*) qbt_pbap_root_folder_listing_str;
    pbap_byte_seq.len = strlen(qbt_pbap_root_folder_listing_str) + 1; // including null
  }
  else if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_SIM1)
  {
    pbap_byte_seq.data = (byte*) qbt_pbap_sim1_folder_listing_str;
    pbap_byte_seq.len = strlen(qbt_pbap_sim1_folder_listing_str) + 1; // including null
  }
  else if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_TELECOM)
  {
    pbap_byte_seq.data = (byte*) qbt_pbap_telecom_folder_listing_str;
    pbap_byte_seq.len = strlen(qbt_pbap_telecom_folder_listing_str) + 1; // including null
  }
  else
  {
    // can never get here
    MBT_ERR("qbt_pbap_srv_send_folder_listing_resp>invalid curr_dir %d",
            qbt_pbap_srv.curr_dir, 0, 0);

    status = BT_CS_PF_OBEX_BAD_REQUEST;
  }

  (void) bt_cmd_pf_pbap_srv_pull_vcard_listing_response(
    qbt_pbap_srv.app_id,
    qbt_pbap_srv.conn_id,
    &pbap_byte_seq,
    NULL, /* phone book size ptr */
    NULL, /* new missed calls ptr */
    final,
    status);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_srv_get_vcard_mask(uint64 attrib_mask, char* attrib_str)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_pbap_srv_get_vcard_mask(uint64 attrib_mask, char* attrib_str)
{
  uint8 i = 0;
  for (i=0; i<8; i++) 
  {
     attrib_str[i] = (uint8)((attrib_mask >> (2*i))&0xFF);
  }
}

/********************************************************************************
*	Prototype	: MBT_BOOL qbt_pbap_srv_get_pb_type(uint16* obj_name, uint8 obj_len, T_MBT_PBAP_DIR *dest_dir)
*	Description	: 
********************************************************************************/
static MBT_BOOL qbt_pbap_srv_get_pb_type(PACKED uint16* obj_name, uint8 obj_len, T_MBT_PBAP_DIR *dest_dir)
{
  char obj_str[BT_PF_MAX_FILENAME_LEN*2+1];
  char* pb_ptr = NULL;
  char pb_str[12];
  MBT_BOOL ret_val = MBT_TRUE;

  memcpy((void*)folder_wstr, (void*)obj_name, obj_len*2);
  folder_wstr[obj_len] = 0;
  (void) mbt_ucs2_to_utf8((MBT_SHORT*)folder_wstr, (OI_INT)obj_len,
                        (MBT_CHAR*)obj_str, ARR_SIZE(obj_str));

  pb_ptr = strrchr(obj_str, '/');
  if (pb_ptr == NULL) 
  {
    MBT_ERR("qbt_pbap_srv_get_dir> invalid obj name", 0, 0, 0);
    ret_val = MBT_FALSE;
  }
  else
  {
    memcpy(pb_str, pb_ptr+1, strlen(pb_ptr+1));
    pb_str[strlen(pb_ptr+1)] = 0; //null terminate
    if (strncmp(pb_str, MBT_PBAP_PB_TYPE_PB, strlen(MBT_PBAP_PB_TYPE_PB)) == 0)
    {
      *dest_dir = MBT_PBAP_DIR_PB;
    }
    else if (strncmp(pb_str, MBT_PBAP_PB_TYPE_ICH, strlen(MBT_PBAP_PB_TYPE_ICH)) == 0)
    {
      *dest_dir = MBT_PBAP_DIR_ICH;
    }
    else if (strncmp(pb_str, MBT_PBAP_PB_TYPE_OCH, strlen(MBT_PBAP_PB_TYPE_OCH)) == 0)
    {
      *dest_dir = MBT_PBAP_DIR_OCH;
    }
    else if (strncmp(pb_str, MBT_PBAP_PB_TYPE_MCH, strlen(MBT_PBAP_PB_TYPE_MCH)) == 0)
    {
      *dest_dir = MBT_PBAP_DIR_MCH;
    }
    else if (strncmp(pb_str, MBT_PBAP_PB_TYPE_CCH, strlen(MBT_PBAP_PB_TYPE_CCH)) == 0)
    {
      *dest_dir = MBT_PBAP_DIR_CCH;
    }
    else
    {
      MBT_ERR("qbt_pbap_srv_get_dir>invalid pb type %s", pb_str, 0, 0);
      ret_val = MBT_FALSE;
    }
  }
  return ret_val;
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_srv_get_repository(uint16* obj_name, uint8 obj_len, T_MBT_PBAP_STORAGE* dest_rep)
*	Description	: 
********************************************************************************/
static MBT_BOOL qbt_pbap_srv_get_repository(PACKED uint16* obj_name, uint8 obj_len, T_MBT_PBAP_STORAGE* dest_rep)
{
  char obj_str[BT_PF_MAX_FILENAME_LEN*2+1];
  char* pb_ptr = NULL;
  char rep_str[12];
  MBT_BOOL ret_val = MBT_TRUE;

  memcpy((void*)folder_wstr, (void*)obj_name, obj_len*2);
  folder_wstr[obj_len]= 0;
  (void) mbt_ucs2_to_utf8((MBT_SHORT*)folder_wstr, (OI_INT)obj_len,
                       (MBT_CHAR*)obj_str, ARR_SIZE(obj_str));

  pb_ptr = strrchr(obj_str, '/');
  if (pb_ptr == NULL) 
  {
    MBT_ERR("qbt_pbap_srv_get_repository> invalid obj name", 0, 0, 0);
    ret_val = MBT_FALSE;
  }
  else
  {
    memcpy(rep_str, obj_str, (pb_ptr - obj_str));
    rep_str[pb_ptr - obj_str] = 0; //null terminate
    if (strncmp(rep_str, "telecom", 7) == 0)
    {
      *dest_rep = MBT_PBAP_REPOSIT_INTERNAL;
    }
    else if (strncmp(rep_str, "SIM1", 4) == 0) 
    {
      *dest_rep = MBT_PBAP_REPOSIT_SIM;
    }
    else
    {
      MBT_ERR("qbt_pbap_srv_get_repository> invalid rep type in obj name", 0, 0, 0);
      ret_val = MBT_FALSE;
    }
  }

  return ret_val;
}

/********************************************************************************
*	Prototype	: MBT_BOOL qbt_pbap_srv_get_vcard_index(uint16* vcard_str, uint8 len, MBT_SHORT* dest_index)
*	Description	: 
********************************************************************************/
static MBT_BOOL qbt_pbap_srv_get_vcard_index(PACKED uint16* vcard_str, uint8 len, MBT_SHORT* dest_index)
{
  char obj_str[BT_PF_MAX_FILENAME_LEN+1];
  char* obj_ptr = NULL;
  char index_str[12];
  MBT_BOOL ret_val = MBT_TRUE;

  memcpy((void*)folder_wstr, (void*)vcard_str, len*2);
  folder_wstr[len] = 0;
  (void) mbt_ucs2_to_utf8((MBT_SHORT*)folder_wstr, (OI_INT)len,
                       (MBT_CHAR*)obj_str, ARR_SIZE(obj_str));

  obj_ptr = strrchr(obj_str, '.');
  if (obj_ptr == NULL) 
  {
    MBT_ERR("qbt_pbap_srv_get_vcard_index> invalid vcard name %s", obj_str, 0, 0);
    ret_val = MBT_FALSE;
  }
  else
  {
    memcpy(index_str, obj_str, (obj_ptr - obj_str));
    index_str[obj_ptr - obj_str] = 0; //null terminate

    *dest_index = atoi(index_str);
  }

  return ret_val;
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_srv_set_cur_objects(unsigned short *logical_path, unsigned short *object_name)
*	Description	: 
********************************************************************************/
#if 0	// sliver97@lge.com  subnam�� �ö���°�쿡�� strcat������ �����ϵ��� �Ѵ�. 
static MBT_VOID qbt_pbap_srv_set_cur_objects(unsigned short *logical_path, unsigned short *object_name)
#else
static MBT_VOID qbt_pbap_srv_set_cur_objects(unsigned short *logical_path)
#endif
{
	int len = 0;

	switch(qbt_pbap_srv.curr_dir) 
	{
		case MBT_PBAP_CURR_DIR_ROOT:
			MBT_PI("CurObj root/",0,0,0);
			UniLib_Strcpy(logical_path, L"root/");
			break;
		case MBT_PBAP_CURR_DIR_SIM1:
			MBT_PI("CurObj root/SIM1/",0,0,0);
			UniLib_Strcpy(logical_path, L"root/SIM1/");
			break;
		case MBT_PBAP_CURR_DIR_TELECOM:
			if (qbt_pbap_srv.rep_type == MBT_PBAP_REPOSIT_INTERNAL) 
			{
				MBT_PI("CurObj root/telecom/",0,0,0);
				UniLib_Strcpy(logical_path, L"root/telecom/");
			} 
			else if (qbt_pbap_srv.rep_type == MBT_PBAP_REPOSIT_SIM) 
			{
				MBT_PI("CurObj root/SIM1/telecom/",0,0,0);
				UniLib_Strcpy(logical_path, L"root/SIM1/telecom/");
			}
			break;
		case MBT_PBAP_CURR_DIR_PHONE_BOOK:
			if (qbt_pbap_srv.rep_type == MBT_PBAP_REPOSIT_INTERNAL) 
			{
				switch(qbt_pbap_srv.pb_type) 
				{
					case MBT_PBAP_DIR_PB:
						MBT_PI("CurObj root/telecom/pb/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/telecom/pb/");
						break;
					case MBT_PBAP_DIR_ICH:
						MBT_PI("CurObj root/telecom/ich/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/telecom/ich/");
						break;
					case MBT_PBAP_DIR_OCH:
						MBT_PI("CurObj root/telecom/och/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/telecom/och/");
						break;
					case MBT_PBAP_DIR_MCH:
						MBT_PI("CurObj root/telecom/mch/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/telecom/mch/");
						break;
					case MBT_PBAP_DIR_CCH:
						MBT_PI("CurObj root/telecom/cch/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/telecom/cch/");
						break;
					default:
						MBT_PI("CurObj root/telecom/ default",0,0,0);
						UniLib_Strcpy(logical_path, L"root/telecom/");
						break;
				}
			} 
			else if (qbt_pbap_srv.rep_type == MBT_PBAP_REPOSIT_SIM) 
			{
				switch(qbt_pbap_srv.pb_type) 
				{
					case MBT_PBAP_DIR_PB:
						MBT_PI("CurObj root/SIM1/telecom/pb/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/SIM1/telecom/pb/");
						break;
					case MBT_PBAP_DIR_ICH:
						MBT_PI("CurObj root/SIM1/telecom/ich/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/SIM1/telecom/ich/");
						break;
					case MBT_PBAP_DIR_OCH:
						MBT_PI("CurObj root/SIM1/telecom/och/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/SIM1/telecom/och/");
						break;
					case MBT_PBAP_DIR_MCH:
						MBT_PI("CurObj root/SIM1/telecom/mch/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/SIM1/telecom/mch/");
						break;
					case MBT_PBAP_DIR_CCH:
						MBT_PI("CurObj root/SIM1/telecom/cch/",0,0,0);
						UniLib_Strcpy(logical_path, L"root/SIM1/telecom/cch/");
						break;
					default:
						MBT_PI("CurObj root/SIM1/telecom/ default",0,0,0);
						UniLib_Strcpy(logical_path, L"root/SIM1/telecom/");
						break;
				}
			}
			break;	

		default:
			MBT_PI("CurObj root/ default",0,0,0);
			UniLib_Strcpy(logical_path, L"root/");
			break;
	}
#if 0	// sliver97@lge.com  subnam�� �ö���°�쿡�� strcat������ �����ϵ��� �Ѵ�. 
	UniLib_Strcat(logical_path, (MBT_SHORT*)object_name);

	len = UniLib_Strlen(logical_path);
	if (len != 0 && logical_path[len-1] == '/')
		logical_path[len-1] = NULL;
#endif
	return;
}



/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_pbap_srv_auth_ind (
              bt_pf_ev_pbap_srv_pull_phone_book_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_proc_evt_pbap_srv_pull_phone_book_ind(
  bt_pf_ev_pbap_srv_pull_phone_book_ind_type *bt_ev_msg_ptr)
{
	T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);
	unsigned short objname_wstr[BT_PF_MAX_FILENAME_LEN+1];

	MBT_PI("qbt_proc_evt_pbap_srv_pull_phone_book_ind, conn_id:%x state:%d, status=%x", 
         bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->state, bt_ev_msg_ptr->status);

	if (bt_ev_msg_ptr->state == PBAP_REQUEST_INITIAL)
	{
	    memset(&sdcPbapStatus->PullDirectoryDataIn, 0x00, sizeof(T_MBT_PBAP_PULL_DIRECTORY_DATA_IN));
		memset(&sdcPbapStatus->vCardOut, 0x00, sizeof(T_MBT_PBAP_PULL_OPERATION_RESULT));
	
		// build request and notify app
		sdcPbapStatus->Operation = MBT_PBAP_OP_PULL_DIRECTORY_DATA;

		// build ReqPath
		memcpy((void*)objname_wstr, (void*)bt_ev_msg_ptr->obj_name, bt_ev_msg_ptr->obj_name_len*2);
		objname_wstr[bt_ev_msg_ptr->obj_name_len] = 0;
		
		UniLib_Strcpy(folder_wstr, L"root/");
		UniLib_Strcat(folder_wstr, (MBT_SHORT*)objname_wstr);
		UniLib_UCS2ToUTF8(folder_wstr, sdcPbapStatus->ReqPath);

#ifdef MBT_PBAP_FILENAME_LOG
{
	int i;
	for ( i = 0 ; i < strlen(sdcPbapStatus->ReqPath) ; i+=3 )
		MBT_PI("(%c%c%c)", sdcPbapStatus->ReqPath[i], sdcPbapStatus->ReqPath[i+1], sdcPbapStatus->ReqPath[i+2]);
}
#endif

	    // build op request object 		
	    sdcPbapStatus->PullDirectoryDataIn.Format = (T_MBT_PBAP_VCARD_VERSION)bt_ev_msg_ptr->format;
	    sdcPbapStatus->PullDirectoryDataIn.ListStartOffset = bt_ev_msg_ptr->list_start_offset;
	    sdcPbapStatus->PullDirectoryDataIn.MaxListCount = bt_ev_msg_ptr->max_list_count;
	    qbt_pbap_srv_get_vcard_mask(bt_ev_msg_ptr->attribute_mask,
	                                sdcPbapStatus->PullDirectoryDataIn.vCardMask);
	    if (!qbt_pbap_srv_get_pb_type(bt_ev_msg_ptr->obj_name, bt_ev_msg_ptr->obj_name_len, 
	                                  &sdcPbapStatus->PullDirectoryDataIn.Dir))
	    {
	      // reject bad request
	      qbt_pbap_srv_send_dir_data(BT_CS_PF_OBEX_BAD_REQUEST);
	    }
	    else if (!qbt_pbap_srv_get_repository(bt_ev_msg_ptr->obj_name, bt_ev_msg_ptr->obj_name_len, 
	                                          &sdcPbapStatus->PullDirectoryDataIn.Storage))
	    {
	      // reject bad request
	      qbt_pbap_srv_send_dir_data(BT_CS_PF_OBEX_BAD_REQUEST);
	    }
	    else
	    {
#ifdef PBAP_SPLIT_SEND
		  sdcPbapStatus->vCardOut.vCardMergedCount = 0;
		  sdcPbapStatus->vCardOut.vCardTotalCount = 0;
#endif
	      qbt_pbap_srv.curr_op = MBT_PBAP_OP_TYPE_PULL_PHONEBOOK;
	      mbt_postevent(MBTEVT_PBAP_SERVER_OP_REQUEST, 0);
	    }
	}
	else if (bt_ev_msg_ptr->state == PBAP_REQUEST_CONTINUE) 
	{
#ifdef PBAP_SPLIT_SEND
		if(qbt_pbap_srv.fs_handle == 0
			&& sdcPbapStatus->vCardOut.vCardMergedCount < sdcPbapStatus->vCardOut.vCardTotalCount)
		{
			MBT_PI("############MBT_PBAP  Send Next Request####################", 0, 0, 0);
			mbt_postevent(MBTEVT_PBAP_SERVER_OP_REQUEST, 0);
		}
		else
#endif
			qbt_pbap_srv_send_dir_data(bt_ev_msg_ptr->status);
	}
	else // state = CLEANUP
	{
		qbt_pbap_file_close();
		qbt_pbap_notify_app(bt_ev_msg_ptr->status);
#ifdef PBAP_SPLIT_SEND
        sdcPbapStatus->vCardOut.vCardMergedCount = 0;
		sdcPbapStatus->vCardOut.vCardTotalCount = 0;
		mbt_misc_clearpbapfiles();
#endif		
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_pbap_srv_set_phone_book_ind(
              bt_pf_ev_pbap_srv_set_phone_book_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_proc_evt_pbap_srv_set_phone_book_ind(
  bt_pf_ev_pbap_srv_set_phone_book_ind_type *bt_ev_msg_ptr)
{
  bt_cmd_status_type status = BT_CS_GN_SUCCESS;

  MBT_PI("qbt_proc_evt_pbap_srv_set_phone_book_ind, conn_id:%x level:%d folder_len:%d", 
         bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->level, bt_ev_msg_ptr->folder_len);

  /* validate request */
  if (bt_ev_msg_ptr->level == 0) 
  {
    // set path to root
    qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_ROOT;
  }
  else if (bt_ev_msg_ptr->folder_len == 0)
  {
    // one level up
    if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_PHONE_BOOK) 
    {
      qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_TELECOM;
    }
    else if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_TELECOM) 
    {
      if (qbt_pbap_srv.rep_type == MBT_PBAP_REPOSIT_SIM) 
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_SIM1;
      }
      else
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_ROOT;
      }
    }
    else if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_SIM1) 
    {
      qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_ROOT;
    }
    else
    {
      // already in root
      //status = BT_CS_PF_OBEX_BAD_REQUEST;
    }
  }
  else
  {
    OI_STATUS stat;
	
    // set path to folder
    if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_ROOT) 
    {
      // folder can be "SIM1" or "telecom"
      if (UniLib_Strcmp(bt_ev_msg_ptr->folder_str, L"telecom") == 0)
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_TELECOM;
        qbt_pbap_srv.rep_type = MBT_PBAP_REPOSIT_INTERNAL;
      }
	  else if (UniLib_Strcmp(bt_ev_msg_ptr->folder_str, L"SIM1") == 0)
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_SIM1;
        qbt_pbap_srv.rep_type = MBT_PBAP_REPOSIT_SIM;
      }
      else
      {	
        MBT_PI("qbt_proc_evt_pbap_srv_set_phone_book_ind>bad request, curr_dir=%d",
                qbt_pbap_srv.curr_dir, 0, 0);
        status = BT_CS_PF_OBEX_BAD_REQUEST;
      }
    }
    else if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_SIM1) 
    {
      // folder can be only "telecom"
      if (UniLib_Strcmp(bt_ev_msg_ptr->folder_str, L"telecom") == 0)
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_TELECOM;
      }
      else
      {
        MBT_PI("qbt_proc_evt_pbap_srv_set_phone_book_ind>bad request, curr_dir=%d, folder_str=%s",
                qbt_pbap_srv.curr_dir, folder_str, 0);
        status = BT_CS_PF_OBEX_BAD_REQUEST;
      }
    }
    else if (qbt_pbap_srv.curr_dir == MBT_PBAP_CURR_DIR_TELECOM) 
    {
      // folder can be "pb", "ich", "och", "mch" or "cch"
      if (UniLib_Strcmp(bt_ev_msg_ptr->folder_str, L"pb") == 0)
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_PHONE_BOOK;
        qbt_pbap_srv.pb_type = MBT_PBAP_DIR_PB;
      }
      else if (UniLib_Strcmp(bt_ev_msg_ptr->folder_str, L"ich") == 0)
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_PHONE_BOOK;
        qbt_pbap_srv.pb_type = MBT_PBAP_DIR_ICH;
      }
      else if (UniLib_Strcmp(bt_ev_msg_ptr->folder_str, L"och") == 0)
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_PHONE_BOOK;
        qbt_pbap_srv.pb_type = MBT_PBAP_DIR_OCH;
      }
      else if (UniLib_Strcmp(bt_ev_msg_ptr->folder_str, L"mch") == 0)
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_PHONE_BOOK;
        qbt_pbap_srv.pb_type = MBT_PBAP_DIR_MCH;
      }
      else if (UniLib_Strcmp(bt_ev_msg_ptr->folder_str, L"cch") == 0)
      {
        qbt_pbap_srv.curr_dir = MBT_PBAP_CURR_DIR_PHONE_BOOK;
        qbt_pbap_srv.pb_type = MBT_PBAP_DIR_CCH;
      }
      else
      {
        MBT_PI("qbt_proc_evt_pbap_srv_set_phone_book_ind>bad request, curr_dir=%d",
                qbt_pbap_srv.curr_dir, 0, 0);
        status = BT_CS_PF_OBEX_BAD_REQUEST;
      }
    }
    else // curr_dir = MBT_PBAP_CURR_DIR_PHONE_BOOK
    {
      MBT_PI("qbt_proc_evt_pbap_srv_set_phone_book_ind>bad request, curr_dir=%d",
              qbt_pbap_srv.curr_dir, 0, 0);
      status = BT_CS_PF_OBEX_BAD_REQUEST;
    }
  }

  (void) bt_cmd_pf_pbap_srv_set_phone_book_response(qbt_pbap_srv.app_id,
                                                    qbt_pbap_srv.conn_id,
                                                    status);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_pbap_srv_pull_vcard_listing_ind (
              bt_pf_ev_pbap_srv_pull_vcard_listing_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_proc_evt_pbap_srv_pull_vcard_listing_ind(
  bt_pf_ev_pbap_srv_pull_vcard_listing_ind_type *bt_ev_msg_ptr)
{
	T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);	
	unsigned short objname_wstr[BT_PF_MAX_FILENAME_LEN+1];
	
  MBT_PI("qbt_proc_evt_pbap_srv_pull_vcard_listing_ind> conn_id:%x state:%d, max_list=%d", 
         bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->state, bt_ev_msg_ptr->max_list_count);
  MBT_PI("qbt_proc_evt_pbap_srv_pull_vcard_listing_ind> curr_dir=%d, rep_type=%d",
         qbt_pbap_srv.curr_dir, qbt_pbap_srv.rep_type, 0);
#if 0
  if (qbt_pbap_srv.curr_dir != MBT_PBAP_CURR_DIR_PHONE_BOOK) 
  {
    if (bt_ev_msg_ptr->state == PBAP_REQUEST_INITIAL) 
    {
      // handle request within QBT without notifying app. 
      // note: app params max_list_count, start_offset and search value will be ignored
      qbt_pbap_srv_send_folder_listing_resp();
    }
    // else ignore other states
    return;
  }
#endif
  if (bt_ev_msg_ptr->state == PBAP_REQUEST_INITIAL)
  {

	memset(&sdcPbapStatus->PullDirectoryListIn, 0x00, sizeof(T_MBT_PBAP_PULL_DIRECTORY_LIST_IN));

	// build request and notify app
	sdcPbapStatus->Operation = MBT_PBAP_OP_PULL_DIRECTORY_LIST;


// sliver97@lge.com	// name�� ���°�츸 strcat�۾��� ������ �ش�. 
#if 0
	// build ReqPath
	memcpy((void*)objname_wstr, (void*)bt_ev_msg_ptr->obj_name, bt_ev_msg_ptr->obj_name_len*2);
	objname_wstr[bt_ev_msg_ptr->obj_name_len] = 0;
	qbt_pbap_srv_set_cur_objects((unsigned short*)folder_wstr, (unsigned short*)objname_wstr);
#else
	// build ReqPath
	qbt_pbap_srv_set_cur_objects((unsigned short*)folder_wstr);

	if(bt_ev_msg_ptr->obj_name_len != 0 && bt_ev_msg_ptr->obj_name[0] != NULL)
	{	
		memcpy((void*)objname_wstr, (void*)bt_ev_msg_ptr->obj_name, bt_ev_msg_ptr->obj_name_len*2);
		objname_wstr[bt_ev_msg_ptr->obj_name_len] = 0;		
		UniLib_Strcat(folder_wstr, (MBT_SHORT*)objname_wstr);
	}
	{
		int len = 0;
		len = UniLib_Strlen(folder_wstr);
		if (len != 0 && folder_wstr[len-1] == '/')
			folder_wstr[len-1] = NULL;	
	}
#endif	

	UniLib_UCS2ToUTF8(folder_wstr, sdcPbapStatus->ReqPath);

#ifdef MBT_PBAP_FILENAME_LOG
{
	int i;
	for ( i = 0 ; i < strlen(sdcPbapStatus->ReqPath) ; i+=3 )
		MBT_PI("(%c%c%c)", sdcPbapStatus->ReqPath[i], sdcPbapStatus->ReqPath[i+1], sdcPbapStatus->ReqPath[i+2]);
}
#endif

    // build op request object 
    sdcPbapStatus->PullDirectoryListIn.Dir = qbt_pbap_srv.pb_type; // ignore obj_name in evt
    sdcPbapStatus->PullDirectoryListIn.ListStartOffset = bt_ev_msg_ptr->list_start_offset;
    sdcPbapStatus->PullDirectoryListIn.MaxListCount = bt_ev_msg_ptr->max_list_count;
    sdcPbapStatus->PullDirectoryListIn.SearchMethod = bt_ev_msg_ptr->search_attrib; 

	if(bt_ev_msg_ptr->value_len > 0)
	{
		uint8	valueLen = bt_ev_msg_ptr->value_len;
		memset(sdcPbapStatus->PullDirectoryListIn.SearchVal, 0x0, sizeof(MBT_CHAR)*MBT_PBAP_MAX_NAME_LENGTH);
		valueLen = (valueLen > MBT_PBAP_MAX_NAME_LENGTH)? (MBT_PBAP_MAX_NAME_LENGTH-1) : valueLen;	
		memcpy(sdcPbapStatus->PullDirectoryListIn.SearchVal, (void*)bt_ev_msg_ptr->value, valueLen);
	}
	
	//memcpy((void*)folder_wstr, (void*)bt_ev_msg_ptr->value, bt_ev_msg_ptr->value_len*2);
	//folder_wstr[bt_ev_msg_ptr->value_len] = 0;
    //(void) mbt_ucs2_to_utf8((MBT_SHORT*)folder_wstr, 
    //                      bt_ev_msg_ptr->value_len,
    //                      (MBT_CHAR*)sdcPbapStatus->PullDirectoryListIn.SearchVal, 
    //                      ARR_SIZE(sdcPbapStatus->PullDirectoryListIn.SearchVal));

#ifdef MBT_PBAP_FILENAME_LOG
{
	int i;
	for ( i = 0 ; i < strlen(sdcPbapStatus->PullDirectoryListIn.SearchVal) ; i+=3 )
		MBT_PI("(%c%c%c)", sdcPbapStatus->PullDirectoryListIn.SearchVal[i], sdcPbapStatus->PullDirectoryListIn.SearchVal[i+1], sdcPbapStatus->PullDirectoryListIn.SearchVal[i+2]);
}
#endif

    qbt_pbap_srv.curr_op = MBT_PBAP_OP_TYPE_GET_FOLDER_LISTING;
    mbt_postevent(MBTEVT_PBAP_SERVER_OP_REQUEST, 0);
  }
  else if (bt_ev_msg_ptr->state == PBAP_REQUEST_CONTINUE) 
  {
    qbt_pbap_srv_send_dir_list(bt_ev_msg_ptr->status);
  }
  else // state = CLEANUP
  {
    qbt_pbap_file_close();
    qbt_pbap_notify_app(bt_ev_msg_ptr->status);
#ifdef PBAP_SPLIT_SEND
		mbt_misc_clearpbapfiles();
#endif			
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_pbap_srv_pull_vcard_entry_ind (
              bt_pf_ev_pbap_srv_pull_vcard_entry_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_proc_evt_pbap_srv_pull_vcard_entry_ind(
  bt_pf_ev_pbap_srv_pull_vcard_entry_ind_type *bt_ev_msg_ptr)
{
  T_MBT_PBAP_STATUS *sdcPbapStatus = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);
  unsigned short objname_wstr[BT_PF_MAX_FILENAME_LEN+1];

  MBT_PI("qbt_proc_evt_pbap_srv_pull_vcard_entry_ind, conn_id:%x state:%d, status=%x", 
         bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->state, bt_ev_msg_ptr->status);

  if (bt_ev_msg_ptr->state == PBAP_REQUEST_INITIAL)
  {
	memset(&sdcPbapStatus->PullvCardIn, 0x00, sizeof(T_MBT_PBAP_PULL_VCARD_IN));
	memset(&sdcPbapStatus->vCardOut, 0x00, sizeof(T_MBT_PBAP_PULL_OPERATION_RESULT));

    sdcPbapStatus->Operation = MBT_PBAP_OP_PULL_ONE_VCARD;
#if 0	// sliver97@lge.com	// name�� ���°�츸 strcat�۾��� ������ �ش�. 
	// build ReqPath
	memcpy((void*)objname_wstr, (void*)bt_ev_msg_ptr->obj_name, bt_ev_msg_ptr->obj_name_len*2);
	objname_wstr[bt_ev_msg_ptr->obj_name_len] = 0;
	qbt_pbap_srv_set_cur_objects((unsigned short*)folder_wstr, (unsigned short*)objname_wstr);
#else
	// build ReqPath
	qbt_pbap_srv_set_cur_objects((unsigned short*)folder_wstr);

	if(bt_ev_msg_ptr->obj_name_len != 0 && bt_ev_msg_ptr->obj_name[0] != NULL)
	{	
		MBT_PI("qbt_proc_evt_pbap_srv_pull_vcard_end_ind, string cat ", 0, 0, 0);
		memcpy((void*)objname_wstr, (void*)bt_ev_msg_ptr->obj_name, bt_ev_msg_ptr->obj_name_len*2);
		objname_wstr[bt_ev_msg_ptr->obj_name_len] = 0;		
		UniLib_Strcat(folder_wstr, (MBT_SHORT*)objname_wstr);
	}

	{
		int len = 0;
		len = UniLib_Strlen(folder_wstr);
		if (len != 0 && folder_wstr[len-1] == '/')
			folder_wstr[len-1] = NULL;	
	}

#endif

	UniLib_UCS2ToUTF8(folder_wstr, sdcPbapStatus->ReqPath);

#ifdef MBT_PBAP_FILENAME_LOG
{
	int i;
	for ( i = 0 ; i < strlen(sdcPbapStatus->ReqPath) ; i+=3 )
		MBT_PI("(%c%c%c)", sdcPbapStatus->ReqPath[i], sdcPbapStatus->ReqPath[i+1], sdcPbapStatus->ReqPath[i+2]);	
}
#endif

    // build op request object 
    sdcPbapStatus->PullvCardIn.Dir = qbt_pbap_srv.pb_type;
    sdcPbapStatus->PullvCardIn.Format = (T_MBT_PBAP_VCARD_VERSION)bt_ev_msg_ptr->format;
    sdcPbapStatus->PullvCardIn.Storage = qbt_pbap_srv.rep_type;
    qbt_pbap_srv_get_vcard_mask(bt_ev_msg_ptr->attribute_mask,
                                sdcPbapStatus->PullDirectoryDataIn.vCardMask);
    if (!qbt_pbap_srv_get_vcard_index(bt_ev_msg_ptr->obj_name, bt_ev_msg_ptr->obj_name_len, 
                                      &sdcPbapStatus->PullvCardIn.Index))
    {
      // reject request 
      qbt_pbap_srv_send_one_vcard(BT_CS_PF_OBEX_BAD_REQUEST);
    }
    else
    {
      qbt_pbap_srv.curr_op = MBT_PBAP_OP_TYPE_PULL_VCARD;
      mbt_postevent(MBTEVT_PBAP_SERVER_OP_REQUEST, 0);
    }
  }
  else if (bt_ev_msg_ptr->state == PBAP_REQUEST_CONTINUE) 
  {
    qbt_pbap_srv_send_one_vcard(bt_ev_msg_ptr->status);
  }
  else // state = CLEANUP
  {
    qbt_pbap_file_close();
    qbt_pbap_notify_app(bt_ev_msg_ptr->status);
#ifdef PBAP_SPLIT_SEND
	mbt_misc_clearpbapfiles();
#endif		
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_file_close ()
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_pbap_file_close(MBT_VOID)
{
  fs_rsp_msg_type fs_rsp;
  if (qbt_pbap_srv.fs_handle != 0) 
  {
    fs_close(qbt_pbap_srv.fs_handle, NULL, &fs_rsp); 
    qbt_pbap_srv.fs_handle = 0;
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_pbap_notify_app ()
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_pbap_notify_app(bt_cmd_status_type status)
{
  if (qbt_pbap_srv.curr_op != MBT_PBAP_OP_TYPE_NONE)
  {
    mbt_postevent((status == BT_CS_GN_SUCCESS)?
                   MBTEVT_PBAP_SERVER_OP_SUCCESS:MBTEVT_PBAP_SERVER_OP_FAIL, 0);
    qbt_pbap_srv.curr_op = MBT_PBAP_OP_TYPE_NONE;
  }
  else
  {
    MBT_PI("qbt_pbap_notify_app>req rejected by QBT, no need to notify app", 0, 0, 0);
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_pbap_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
*	Description :
********************************************************************************/
static MBT_VOID mbt_pbap_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{
	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
			MBT_PI("mbt_pbap_cmd_done> cmd:%x status:%x", 
             bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type, 
             bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status, 0);
      		mbt_pbap_HandleCmdDone(&bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done);
	    	break;

		case BT_EV_PF_PBAP_SRV_CON_IND:
			qbt_proc_evt_pbap_srv_con_ind(&bt_ev_msg_ptr->ev_msg.ev_pbap_srv_con_ind);
			break;

		case BT_EV_PF_PBAP_SRV_DCN_IND:
			qbt_proc_evt_pbap_srv_dcn_ind(&bt_ev_msg_ptr->ev_msg.ev_pbap_srv_dcn_ind);
			break;

    	case BT_EV_PF_PBAP_SRV_AUTH_IND:
			qbt_proc_evt_pbap_srv_auth_ind(&bt_ev_msg_ptr->ev_msg.ev_pbap_srv_auth_ind);
			break;

    	case BT_EV_PF_PBAP_SRV_PULL_PHONE_BOOK_IND:
      		qbt_proc_evt_pbap_srv_pull_phone_book_ind(&bt_ev_msg_ptr->ev_msg.ev_pbap_srv_pull_phone_book_ind);
			break;

    	case BT_EV_PF_PBAP_SRV_SET_PHONE_BOOK_IND:
      		qbt_proc_evt_pbap_srv_set_phone_book_ind(&bt_ev_msg_ptr->ev_msg.ev_pbap_srv_set_phone_book_ind);
			break;

    	case BT_EV_PF_PBAP_SRV_PULL_VCARD_LISTING_IND:
      		qbt_proc_evt_pbap_srv_pull_vcard_listing_ind(&bt_ev_msg_ptr->ev_msg.ev_pbap_srv_pull_vcard_listing_ind);
			break;

    	case BT_EV_PF_PBAP_SRV_PULL_VCARD_ENTRY_IND:
      		qbt_proc_evt_pbap_srv_pull_vcard_entry_ind(&bt_ev_msg_ptr->ev_msg.ev_pbap_srv_pull_vcard_entry_ind);
			break;

		default:
			MBT_ERR("mbt_pbap_EventCallback> evt:%d", bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0);
			break;
	}
}

#endif
