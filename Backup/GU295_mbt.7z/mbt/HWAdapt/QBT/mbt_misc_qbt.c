/********************************************************************************
*	File Name	: mbt_misc_qbt.c
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.11.26	Lee,DongHyun		Created
********************************************************************************/
#include <stdio.h>
#include <string.h>
#include "mbt_misc.h"
#include "mbt_sdc.h"
#include "mbt_gap.h"
#include "mbt_evhandler.h"
#include "include/mbt_internal_func.h"


#include "bt.h"
#include "bti.h"

#include "fs.h"
#include "fs_public.h"
#include "fs_parms.h"
#include "fs_sys_types.h"
#include "fs_config.h"
#include "fs_namei.h"

#define MBT_FS_MAX_PATH_PBAP		80

// dkmoon 20090121_S DUT RF TEST �����û
const uint8 factory_bd_addr_table[32] = { 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x10,
							      0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x20,
							      0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x30,
							      0x31, 0x32};
// dkmoon 20090121_E

const char removeFolderList[][MBT_FS_MAX_PATH_PBAP]		=
{
	{"/LGAPP/Media/Temp/browse/"},
	{"/LGAPP/Media/Temp/browse/ich/"},
	{"/LGAPP/Media/Temp/browse/cch/"},
	{"/LGAPP/Media/Temp/browse/mch/"},
	{"/LGAPP/Media/Temp/browse/och/"},
	{"/LGAPP/Media/Temp/browse/vCard/"},
	{"/LGAPP/Media/Temp/vObject/"},
	{""}
};


enum
{
	BT_DUT_SET_DEFAULT,
	BT_DUT_SET_CN_BDADDR = 10,
	BT_DUT_SET_MAX
};
extern	bt_app_id_type bt_l2_app_id;
extern 	bt_app_id_type  mbt_rm_app_id;
int onOff = MBT_FALSE;
int  diableAll = FALSE;

static MBT_BOOL mbt_misc_CheckCmdStatus( bt_cmd_status_type stat )
{
	MBT_PI( __func__"##########################", 0, 0, 0);
	switch (stat)
	{
		case BT_CS_GN_SUCCESS:
		case BT_CS_GN_PENDING:
			return MBT_TRUE; //SUCCESS;

		case BT_CS_GN_CMD_Q_FULL:
			return MBT_FALSE; //ENOMEMORY;

		default:
			return MBT_FALSE; //EFAILED;
	}
}

MBT_VOID mbt_misc_dutenable(MBT_INT value)
{
	//dkmoon 2006-9-1 [START] Test Mode�� "0x0005C9000000" addr�� �������ش�. 
	bt_bd_addr_type bd_addr = { 0x00, 0x00, 0x00, 0xC9, 0x05, 0x00 };
	static bt_bd_addr_type hexBTAddr;
	//dkmoon 2006-9-1 [END]
	bt_cmd_status_type	stat;
	uint8 new_addr = 0x0;
	int  cn_value = 0;

	if(onOff == MBT_TRUE)
		return;
	//dkmoon 2006-9-1 [START] Test Mode�� "0x0005C9000000" addr�� �������ش�. 

	// dkmoon 20090121_S DUT RF TEST �����û
	if(value > BT_DUT_SET_CN_BDADDR)
	{
		cn_value = value - 11;
		new_addr = factory_bd_addr_table[cn_value];
		bd_addr.bd_addr_bytes[0] = new_addr;
		MBT_PI("bd_addr.bd_addr_bytes[0] 0x%x", bd_addr.bd_addr_bytes[0], 0, 0);
	}
	// dkmoon 20090121_E

	if(!bt_cmd_dc_is_bt_on())
	{
		MBT_WARN(__func__"  bt_cmd_dc_is_bt_on -> FALSE ", 0, 0, 0);
	}
	//BT_BD_ADDR_NULL(&hexBTAddr);
	memset((byte*)(&hexBTAddr), 0, sizeof(bt_bd_addr_type));
	bt_cmd_dc_get_bd_addr(&hexBTAddr);

	if(!BT_BD_ADDRS_EQUAL(&bd_addr, &hexBTAddr))
	{
		if(bt_cmd_dc_is_bt_on())
		{
			bt_cmd_hc_set_new_bd_addr((bt_bd_addr_type*) &bd_addr);
		}
		else
		{
			bt_cmd_dc_set_bd_addr((bt_bd_addr_type*)&bd_addr);
		}
	}
	//dkmoon 2006-9-1 [END]

	//bt_cmd_hc_wr_loopback_mode(BT_LOOPBACK_REMOTE);		// audio loopback�� ���� vendorspecific cmd�� �����ش�. 

	stat = bt_cmd_rm_test_mode_enable( bt_l2_app_id, MBT_TRUE );
}


MBT_VOID mbt_misc_dutdisable(MBT_VOID)
{
	bt_cmd_status_type	stat;
	if(onOff == MBT_FALSE)
		return;
	stat = bt_cmd_rm_test_mode_enable( bt_l2_app_id, MBT_FALSE );
}

MBT_VOID mbt_misc_setfccmode(T_MBT_BDADDR testMyAddr, T_MBT_TEST_MODE mode)
{
}

MBT_BOOL mbt_misc_getversion(MBT_VOID)
{
	T_MBT_MISC_VERSION * miscVersion = (T_MBT_MISC_VERSION*)mbt_sdc_getrecord(MBTSDC_REC_MISC_VERSION);
	
	strcpy(miscVersion->MbtVersion,MBT_VERSION_STR);

	//miscVersion->BluetoothVersion
	//miscVersion->StackVersion1
	//miscVersion->StackVersion2

	return MBT_TRUE;
	
}

MBT_BOOL	mbt_misc_getlocalinfo(MBT_VOID)
{
	//My BD Addrs ������.
	T_MBT_MYINFO* btMyInfo = (T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);
	bt_bd_addr_type 	addr;
	MBT_CHAR  btName[MBT_MAX_NAME_LEN+1];
	bt_cmd_rm_get_local_info(NULL, &addr, MBT_NULL, MBT_NULL, MBT_NULL, btName, MBT_NULL);
	memcpy((MBT_BYTE*)btMyInfo->BdAddr, (MBT_BYTE*)&addr.bd_addr_bytes, MBT_BDADDR_LEN);
	memcpy((MBT_BYTE*)btMyInfo->Name, btName, sizeof(btMyInfo->Name));	

	return MBT_TRUE;

}
MBT_BOOL	mbt_misc_radioon(MBT_VOID)
{
	bt_cmd_status_type  stat;
	TASKLOCK();
  	stat = bt_cmd_rm_disable_radio(mbt_rm_app_id, FALSE );
  	TASKFREE();
	return mbt_misc_CheckCmdStatus(stat);
}
MBT_BOOL	mbt_misc_radiooff(MBT_VOID)
{
	bt_cmd_status_type  stat;
	diableAll = TRUE;
	TASKLOCK();
  	stat = bt_cmd_rm_disable_radio(mbt_rm_app_id, TRUE );
  	TASKFREE();
	return mbt_misc_CheckCmdStatus(stat);
}

MBT_BOOL mbt_misc_factorytestmode(T_MBT_BDADDR testMyAddr)
{
	return MBT_FALSE;
}


extern MBT_BOOL mbt_misc_clearpbapfiles(MBT_VOID)
{
	EFSDIR* dir_handle; 
	struct fs_dirent* enum_dir_name_ptr;
	struct fs_stat enum_file_stat;
	fs_rsp_msg_type resp;
	char removeFilePath[MBT_FS_MAX_PATH_PBAP];
	int ret,i;

	MBT_PI("staring mbt_misc_clearpbapfiles ...",0,0,0);
	i=0;
	while(removeFolderList[i][0] != 0x00)
	{
		MBT_PI(" ======>  %d th folder removing .. ",i,0,0);
		if ( (dir_handle = efs_opendir(removeFolderList[i])) == NULL) 
		{
			MBT_ERR("[UTIL] efs_opendir FAIL", 0, 0, 0);
			i++;
			continue;
		}

		enum_dir_name_ptr = efs_readdir(dir_handle);
	  	if (enum_dir_name_ptr == NULL) 
		{
			MBT_ERR("[UTIL] Virtual file system : efs_readdir not found", 0, 0, 0);
			efs_closedir(dir_handle);
			i++;
	   		continue;
		}

		do  
		{
			if(removeFolderList[i][0] == '/')	// internal 
			{
				strcpy(removeFilePath, removeFolderList[i]);
				strcat(removeFilePath, enum_dir_name_ptr->d_name);
			    ret = efs_stat( removeFilePath, &enum_file_stat );
		    	if (ret == -1) 
				{
	      			MBT_ERR( "[UTIL] Virtual file system: efs_stat failed on browse", 0, 0, 0 );
	      			continue;
		    	}
			}
			else
			{
				 enum_file_stat.st_mode = enum_dir_name_ptr->d_stat.st_mode;
				 enum_file_stat.st_size = enum_dir_name_ptr->d_stat.st_size;
			}
			
	    	if(S_ISDIR (enum_file_stat.st_mode)) 
			{
	    	} 
			else if (S_ISREG( enum_file_stat.st_mode)) 
			{ 
				fs_remove (removeFilePath, NULL, &resp);
				if (resp.rmfile.status != FS_OKAY_S) 
				{
					MBT_PI("Fail to Remove file...reason(%d)",resp.rmfile.status,0,0);
				}
				else
				{
					MBT_PI("Removing Completed...",0,0,0);
				}
			}
			else
			{
				MBT_ERR("=========> this is not file and directory!!!",0,0,0);
			}
	  	} while ((enum_dir_name_ptr = efs_readdir(dir_handle)) != NULL );
		efs_closedir(dir_handle);
		i++;
	}
	MBT_PI("ending mbt_misc_clearpbapfiles ...",0,0,0);
	return TRUE;
}

MBT_BOOL mbt_misc_setsspdebugmode(MBT_BOOL bEnable)
{
	if(bEnable == MBT_TRUE)
		bt_cmd_rm_set_sm4_debug_mode(mbt_rm_app_id, TRUE);
	else
		bt_cmd_rm_set_sm4_debug_mode(mbt_rm_app_id, FALSE);

	return MBT_TRUE;
}

