/*-----------------------------------------------------------------------------
File qbt_a2dp.c

GENERAL DESCRIPTION
This file contains a2dp hooks to/from QBT Stack from/to MBT BT Layer.

Copyright (c) 2009 QUALCOMM Incorporated.
All Rights Reserved.
Qualcomm Confidential and Proprietary
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------

                        EDIT HISTORY FOR MODULE

  This section contains comments describing changes made to the module.
  Notice that changes are listed in reverse chronological order.

  $Header: None $
  $DateTime: None $
  $Author: ytkim $

  when        who  what, where, why
  ----------  ---  ------------------------------------------------------------
  2009-01-15   BK  Initial Revision

-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
                     INCLUDE FILES FOR MODULE
-----------------------------------------------------------------------------*/
#include "bt.h"
#include "btpf.h"
#include "btmsg.h"
#include "btpfi.h"
#include "btpfcmdi.h"
#include "bti.h"
#include "btcomdef.h"
#ifdef FEATURE_BT_EXTPF_AV
#include "audiosbcenc.h"
#endif /* FEATURE_BT_EXTPF_AV */

#include "mbt_a2dp.h"
#include "mbt_sdc.h"
#include "mbt_evhandler.h"
#include "qbt_utils/qbt_utils.h"

#include <stdio.h>
#include <stdlib.h>

#define BT_MSG_LAYER QBT_MSG_A2DP

/* currently supports only one a2dp connection */
#define QBT_AA_MAX_CONNECTIONS	MBT_A2DP_MAX_CONN_NUM
#define QBT_AA_NUM_BDADDR_BYTES	6
#define QBT_AVDTP_PSM			0x0019

/* Null bluetooth device address */
static const bt_bd_addr_type QBT_AA_NULL_BD_ADDR = {0,0,0,0,0,0};

// A2DP states
#define QBT_AA_STATE_INIT			0
#define QBT_AA_STATE_ENABLE_PEND	1
#define QBT_AA_STATE_ENABLED		2
#define QBT_AA_STATE_CONN_PEND		3
#define QBT_AA_STATE_CONNECTED		4
#define QBT_AA_STATE_DISC_PEND		5
#define QBT_AA_STATE_DISABLE_PEND	6
#define QBT_AA_STATE_DISABLE_DISCONNECT_PEND	7

/* keeps track of each a2dp connection */
typedef struct _QBTA2DPCon
{
	bt_bd_addr_type bdAddr;
	uint32 a2ConState;
	boolean bFree;
} QBTA2DPCon;

/* a2dp object maintained by the QBT a2dp glue layer */
typedef struct _QBTA2DP
{
	bt_app_id_type appId;
	MBT_BOOL bDirection;  
	MBT_BOOL bAuthorizedA2DP;
	// Keeps track of the current active bdAddr in "aConn" for which open/close is initiated,
	// assuming dual audio is not supported
	bt_bd_addr_type bdAddr;
	uint32 state;
	uint32 numCon;
	boolean isConnected;
	bt_security_type btSec;
	QBTA2DPCon aConn[QBT_AA_MAX_CONNECTIONS];
} QBTA2DP;

static QBTA2DP qbtA2dp = {BT_APP_ID_NULL, BT_RM_ATZRQ_OUTGOING, };
#define QBTAAOBJ() (qbtA2dp)
#define QBTAA(s) (qbtA2dp.s)

/*------------------------------------------------------------------------------
                          STATIC FUNCTION DEFINITIONS
------------------------------------------------------------------------------*/

#ifdef FEATURE_BT_EXTPF_AV

/*=============================================================================
FUNCTION:  qbt_a2dp_conn_init
=============================================================================*/
/**
    Internal function used to initialize globals

    @see
    @return      None
*/
static void qbt_a2dp_conn_init(QBTA2DPCon *pCon)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	T_MBT_A2DP_STATUS *psdc_a2dp_stat = NULL;

  	BT_MSG_HIGH("QBT A2DP: A2DP initialize",0,0,0);

  	memset((void*)pCon, 0, sizeof(QBTA2DPCon));
  	pCon->bFree = TRUE;

  	psdc_a2dp_stat = (T_MBT_A2DP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_A2DP_STATUS);
  	if (psdc_a2dp_stat != NULL) {
  		memset(psdc_a2dp_stat, 0x00, sizeof(T_MBT_A2DP_STATUS));
  	}

#endif
#endif
   return;
}


/*=============================================================================
FUNCTION:  qbt_a2dp_convert_bt_cmd_status
=============================================================================*/
/**
    Internal function to convert BT driver command status to boolean status

    @see
    @return      boolean
*/
static boolean qbt_a2dp_convert_bt_cmd_status (bt_cmd_status_type stat)
{
   switch (stat)
   {
     case BT_CS_GN_SUCCESS:
     case BT_CS_GN_PENDING:
       return TRUE;

     case BT_CS_GN_CMD_Q_FULL:
     default:
       return FALSE;
   }
}

/*=============================================================================
FUNCTION:  qbt_a2dp_update_security
=============================================================================*/
/**
    Internal function to set a2dp service security

    @see
    @return      None
*/
static void qbt_a2dp_update_security (bt_security_type bSec)
{
  bt_service_id_type svcIdent;
  bt_cmd_status_type stat;

  memset((void*)&svcIdent, 0, sizeof(bt_service_id_type));

  svcIdent.service_id_method = BT_SIM_L2CAP_PSM;
  svcIdent.l2cap_psm = QBT_AVDTP_PSM;
  stat = bt_cmd_rm_set_service_security (QBTAA(appId), &svcIdent, bSec,
                                         TRUE, FALSE);
  BT_MSG_HIGH( "QBT A2DP CMD: Set service security status for PSM 0x%x = 0x%x",
               svcIdent.l2cap_psm, qbt_a2dp_convert_bt_cmd_status(stat), 0);

  return;
}

/*=============================================================================
FUNCTION:  qbt_a2dp_find_conn
=============================================================================*/
/**
    Internal function to find a2dp connection

    @see
    @return      QBTA2DPCon
*/
static QBTA2DPCon* qbt_a2dp_find_conn(bt_bd_addr_type* pBDAddr, boolean create)
{
   QBTA2DPCon *pConn = NULL;
   uint32 i;

   for (i = 0; i < QBT_AA_MAX_CONNECTIONS ; i++)
   {
     // check if connection entry exists
     if ( (BT_BD_ADDRS_EQUAL(&(QBTAA(aConn[i].bdAddr)), pBDAddr) != FALSE) &&
                    (QBT_AA_STATE_INIT != QBTAA(aConn[i].a2ConState)) )
     {
       pConn = &(QBTAA(aConn[i]));
       break;
     }
   }

   if ((NULL == pConn) && (TRUE == create))
   {
     // get a new connection entry
     for (i = 0; i < QBT_AA_MAX_CONNECTIONS; i++)
     {
       if (TRUE == QBTAA(aConn[i].bFree))
       {
         QBTAA(aConn[i].bFree) = FALSE;
         pConn = &(QBTAA(aConn[i]));
         pConn->bdAddr = *pBDAddr;
         break;
       }
     }
   }

   return pConn;
}

/*=============================================================================
FUNCTION:  qbt_a2dp_enable
=============================================================================*/
/**
    Internal function to enable a2dp service

    @see
    @return      boolean
*/
static boolean qbt_a2dp_enable(void)
{
	boolean ret = FALSE;
	bt_cmd_status_type status;

	if (QBTAA(state) != QBT_AA_STATE_INIT)
	{
		BT_MSG_HIGH("QBT A2DP: Invalid state %x", QBTAA(state), 0, 0);
		return FALSE;
	}

	BT_MSG_HIGH("QBT A2DP: Enable a2dp, aid = 0x%x", QBTAA(appId), 0, 0);

	// update security for a2dp service.. has to be moved to GAP layer
	//qbt_a2dp_update_security(QBTAA(btSec));

	// Register with the A2DP layer
	status = bt_cmd_pf_a2dp_enable(QBTAA(appId));

	ret = qbt_a2dp_convert_bt_cmd_status(status);

	if (TRUE == ret)
	{
		(void)bt_cmd_rm_set_connectable(QBTAA(appId), TRUE, BT_RM_AVP_AUTOMATIC);

		// the app controls the a2dp start
		//status = bt_cmd_pf_a2dp_ctl(QBTAA(appId), BT_PF_A2DP_CTL_APP_START, 0);
		// change reconfig by reconfig for short media.
		status = bt_cmd_pf_a2dp_ctl(QBTAA(appId), BT_PF_A2DP_CTL_RECFG_BY_RECFG, 0);
		status = bt_cmd_pf_a2dp_ctl(QBTAA(appId), BT_PF_A2DP_CTL_IGNORE_IN_USE, 0);
		ret = qbt_a2dp_convert_bt_cmd_status(status);
		if (TRUE == ret)
		{
			QBTAA(state) = QBT_AA_STATE_ENABLE_PEND;
		}
	}

   return ret;
}

/*=============================================================================
FUNCTION:  qbt_a2dp_disconnect
=============================================================================*/
/**
    Internal function to disconnect a2dp service

    @see
    @return      None
*/
static void qbt_a2dp_disconnect(bt_bd_addr_type* pBDAddr)
{
  QBTA2DPCon *pCurCon = NULL;

    BT_MSG_HIGH("QBT A2DP: Disconnect failed, state 0x%x", QBTAA(state), 0, 0);


  if (NULL == pBDAddr)
  {
    BT_MSG_HIGH("QBT A2DP: Disconnect failed, state 0x%x", QBTAA(state), 0, 0);
    return;
  }

  QBTAA(bdAddr) = *pBDAddr;
  pCurCon = qbt_a2dp_find_conn(&(QBTAA(bdAddr)), FALSE);

  if (NULL == pCurCon)
  {
    BT_MSG_HIGH ("QBT A2DP: No conn handle found!", 0, 0, 0);
    return;
  }
  else if (QBT_AA_STATE_CONNECTED != pCurCon->a2ConState)
  {
    // not connected to given device
    BT_MSG_HIGH ("QBT A2DP: Disconnect failed! a2ConState %d", pCurCon->a2ConState, 0, 0);
    return;
  }
  else
  {
    bt_cmd_status_type status;
    boolean ret;

    BT_MSG_HIGH("QBT A2DP CMD: Disconnect a2dp aid = 0x%x",QBTAA(appId), 0, 0);

    status = bt_cmd_pf_a2dp_disconnect(QBTAA(appId));
    ret = qbt_a2dp_convert_bt_cmd_status(status);
    if (TRUE == ret)
    {
      // mark the connection state as disconn pending
      pCurCon->a2ConState = QBT_AA_STATE_DISC_PEND;
      // mark the engine state as disconn pending
      BT_MSG_HIGH("QBT A2DP: Disconnect a2dp state = %x", QBTAA(state), 0, 0);

/// sy_lee [2009/9/4] first disconnect A2DP[[		      
	if(QBTAA(state) == QBT_AA_STATE_DISABLE_DISCONNECT_PEND)
		rex_sleep(200);
/// sy_lee [2009/9/4] first disconnect A2DP]]
	else	  
	      QBTAA(state) = QBT_AA_STATE_DISC_PEND;
	
      BT_MSG_HIGH("QBT A2DP: Disconnect a2dp pending", 0, 0, 0);
    }
    else
    {
      BT_MSG_HIGH("QBT A2DP: disconnect failed to queue", 0, 0, 0);
    }
  }

  return;
}

/*=============================================================================
FUNCTION:  qbt_a2dp_notify_mbt
=============================================================================*/
/**
    Internal function to notify a2dp events to MBT UI

    @see
    @return      None
*/
static void qbt_a2dp_notify_mbt(bt_event_type event)
{
	//boolean isPlaying;
	T_MBT_A2DP_STATUS *psdc_a2dp_stat = NULL;

	switch(event)
	{
	// a2dp connection successful
	case BT_EV_PF_A2DP_CON:
		BT_MSG_HIGH( "QBT A2DP EV: Connected Event", 0, 0, 0 );
		psdc_a2dp_stat = (T_MBT_A2DP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_A2DP_STATUS);
		if (psdc_a2dp_stat != NULL) {
			psdc_a2dp_stat->A2dpConn[0].ConStatus = MBT_A2DP_CONSTATUS_CONNECTED;
			psdc_a2dp_stat->ConNum = 1;
			bdcpy(psdc_a2dp_stat->A2dpConn[0].BdAddr, (void*)&(QBTAA(bdAddr.bd_addr_bytes)));
		}
		mbt_postevent(MBTEVT_A2DP_SOURCE_CONNECT_SUCCESS, 0);
		break;

	// a2dp connection failed
	case BT_EV_PF_A2DP_CON_FAILED:
		BT_MSG_HIGH( "QBT A2DP EV: Connection failed", 0, 0, 0 );
		psdc_a2dp_stat = (T_MBT_A2DP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_A2DP_STATUS);
		if (psdc_a2dp_stat != NULL) {
			psdc_a2dp_stat->A2dpConn[0].ConStatus = MBT_A2DP_CONSTATUS_DISCONNECTED;
			psdc_a2dp_stat->ConNum = 0;
		}
		mbt_postevent(MBTEVT_A2DP_SOURCE_CONNECT_FAIL, 0);
		break;

	// a2dp disconnected
	case BT_EV_PF_A2DP_DISCON:
		BT_MSG_HIGH( "QBT A2DP EV: Disconnect Event", 0, 0, 0 );
		psdc_a2dp_stat = (T_MBT_A2DP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_A2DP_STATUS);
		if (psdc_a2dp_stat != NULL) {
			psdc_a2dp_stat->ConNum = 0;
			psdc_a2dp_stat->A2dpConn[0].ConStatus = MBT_A2DP_CONSTATUS_DISCONNECTED;
		}
		mbt_postevent(MBTEVT_A2DP_SOURCE_DISCONNECT_SUCCESS, 0);

		//qbt_cmd_avrcp_clearkey();
		break;

	// a2dp started
    case BT_EV_PF_A2DP_START:
		BT_MSG_HIGH( "QBT A2DP EV: Start Event", 0, 0, 0 );
		psdc_a2dp_stat = (T_MBT_A2DP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_A2DP_STATUS);
		if (psdc_a2dp_stat != NULL) {
			//psdc_a2dp_stat->A2dpConn[0].ConStatus = MBT_A2DP_CONSTATUS_STARTING;
			psdc_a2dp_stat->A2dpConn[0].ConStatus = MBT_A2DP_CONSTATUS_PLAY;
		}
		mbt_postevent(MBTEVT_A2DP_SOURCE_START_SUCCESS, NULL);
		break;

	// a2dp suspended
    case BT_EV_PF_A2DP_SUSPEND:
		BT_MSG_HIGH( "QBT A2DP EV: Suspend Event", 0, 0, 0 );
		psdc_a2dp_stat = (T_MBT_A2DP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_A2DP_STATUS);
		if (psdc_a2dp_stat != NULL) {
			psdc_a2dp_stat->A2dpConn[0].ConStatus = MBT_A2DP_CONSTATUS_CONNECTED;
		}
		//mbt_postevent(MBTEVT_A2DP_SOURCE_PAUSE_SUCCESS, NULL);
		mbt_postevent(MBTEVT_A2DP_SOURCE_STOP_SUCCESS, NULL);
		break;

    default:
      BT_MSG_HIGH( "QBT A2DP EV: Unknown Event[%d]", event, 0, 0 );
      break;
  }
}

/*=============================================================================
FUNCTION:  qbt_a2dp_handle_cmd_done_events
=============================================================================*/
/**
    Internal function to handle command done events for initiated a2dp cmds

    @see
    @return      None
*/
static void qbt_a2dp_handle_cmd_done_events(bt_ev_msg_type* bt_ev_msg_ptr)
{
  bt_ev_gn_cmd_done_type* pm = (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;
  bt_pf_cmd_type cmd = pm->cmd_type;

	BT_MSG_HIGH("qbt_a2dp_handle_cmd_done_events cmd(%x), status(%x)", cmd, pm->cmd_status, 0);

  switch (cmd)
  {
    case BT_PF_CMD_A2DP_ENABLE:
    {
      if(pm->cmd_status != BT_CS_GN_SUCCESS)
      {
        // a2dp service enable failed
        BT_MSG_HIGH( "QBT A2DP EV: A2dp state - init stat=%x", pm->cmd_status, 0, 0 );
        QBTAA(state) = QBT_AA_STATE_INIT;

        mbt_postevent(MBTEVT_A2DP_SOURCE_ENABLE_FAIL, 0);
      }
      else
      {
        // a2dp service enable succeeded
        if (QBT_AA_STATE_ENABLE_PEND == QBTAA(state))
        {
          BT_MSG_HIGH( "QBT A2DP EV: A2dp state - enabled", 0, 0, 0 );
          QBTAA(state) = QBT_AA_STATE_ENABLED;

          mbt_postevent(MBTEVT_A2DP_SOURCE_ENABLE_SUCCESS, 0);
        }
      }
      break;
    }

    case BT_PF_CMD_A2DP_DISABLE:
    {
      uint32 i;
/*      
      if (QBTAA(state) == QBT_AA_STATE_DISABLE_PEND)
      {
        BT_MSG_HIGH( "QBT A2DP EV: A2dp state - init ", 0, 0, 0 );
        qbt_a2dp_update_security (BT_SEC_NONE);
        QBTAA(state) = QBT_AA_STATE_INIT;
        for ( i = 0; i < QBT_AA_MAX_CONNECTIONS; i++)
        {
          qbt_a2dp_conn_init(&(QBTAA(aConn[i])));
        }
      }
*/      
      BT_MSG_HIGH("QBT A2DP EV: a2dp disconnect cmd done callback = %x", QBTAA(state), 0, 0);	

      if (QBTAA(state) == QBT_AA_STATE_DISABLE_PEND)
	        QBTAA(state) = QBT_AA_STATE_INIT;


		//bt_cmd_ec_free_application_id(QBTAA(appId));
		//QBTAA(appId) = BT_APP_ID_NULL;
      mbt_postevent(MBTEVT_A2DP_SOURCE_DISABLE_SUCCESS, 0);
      break;
    }

    case BT_PF_CMD_A2DP_CONNECT:
    {
      if(pm->cmd_status != BT_CS_GN_SUCCESS)
      {
        // a2dp connect failed
        QBTA2DPCon *pCon = NULL;

        pCon = qbt_a2dp_find_conn(&(QBTAA(bdAddr)), FALSE);
        if (pCon != NULL)
        {
          if (QBT_AA_STATE_CONN_PEND == QBTAA(state))
          {
            QBTAA(state) = QBT_AA_STATE_ENABLED;
          }
          // reset the conn state for the object
          qbt_a2dp_conn_init(pCon);
        }
        // notify SAP that a2dp connection failed
        qbt_a2dp_notify_mbt(BT_EV_PF_A2DP_CON_FAILED);
      }
      break;
    }

    case BT_PF_CMD_A2DP_DISCONNECT:
    {
      if(pm->cmd_status != BT_CS_GN_SUCCESS)
      {
        // a2dp disconnect failed
        BT_MSG_HIGH("QBT A2DP EV: a2dp disconnect failed", 0, 0, 0);
      }
      break;
    }

    default:
    {
      BT_MSG_HIGH("QBT A2DP EV: a2dp unexpected cmd done 0x%x", cmd, 0, 0);
    }
  }
}

/*=============================================================================
FUNCTION:  qbt_a2dp_event_cb
=============================================================================*/
/**
    Internal function to notify about a2dp events from BT driver

    @see
    @return      None
*/
static void qbt_a2dp_event_cb(bt_ev_msg_type* bt_ev_msg_ptr)
{
  bt_event_type event = bt_ev_msg_ptr->ev_hdr.ev_type;
  
	BT_MSG_HIGH("qbt_a2dp_event_cb event = %x", event, 0, 0);

  switch (event)
  {
    case BT_EV_GN_CMD_DONE:
    {
		BT_MSG_HIGH("QBT A2DP EV: BT_EV_GN_CMD_DONE", 0, 0, 0);
      qbt_a2dp_handle_cmd_done_events(bt_ev_msg_ptr);
      break;
    }

    case BT_EV_PF_A2DP_OPEN:
    {
      BT_MSG_HIGH("QBT A2DP EV: a2dp open cfm", 0, 0, 0);
      // notify mbt
      qbt_a2dp_notify_mbt(event);
      break;
    }

    case BT_EV_PF_A2DP_START:
    {
      BT_MSG_HIGH("QBT A2DP EV: a2dp start cfm", 0, 0, 0);
      // notify mbt
      qbt_a2dp_notify_mbt(event);
      break;
    }

    case BT_EV_PF_A2DP_SUSPEND:
    {
      BT_MSG_HIGH("QBT A2DP EV: a2dp suspend cfm", 0, 0, 0);
      // notify mbt
      qbt_a2dp_notify_mbt(event);
      break;
    }

    case BT_EV_PF_A2DP_CLOSE:
    {
      BT_MSG_HIGH("QBT A2DP EV: a2dp close cfm", 0, 0, 0);
      break;
    }

    case BT_EV_PF_A2DP_CON:
    {
      QBTA2DPCon *pCon = NULL;
      //T_MBT_A2DP_STATUS *psdc_a2dp_stat = NULL;

      BT_MSG_HIGH("QBT A2DP EV: a2dp connected status = %x", QBTAA(state), 0, 0);

      // set this device as none-connectable
      bt_cmd_rm_set_connectable( QBTAA(appId), FALSE, BT_RM_AVP_AUTOMATIC );

      // put this device as a2dp source
      bt_cmd_pf_a2dp_set_device( QBTAA(appId), &bt_ev_msg_ptr->ev_msg.ev_a2dp_con.bd_addr);

      pCon = qbt_a2dp_find_conn(&bt_ev_msg_ptr->ev_msg.ev_a2dp_con.bd_addr,
                                TRUE);
      if (pCon != NULL)
      {
        // either remote or locally initiated conn
        if (QBT_AA_STATE_CONN_PEND == pCon->a2ConState)
        {
          QBTAA(state) = QBT_AA_STATE_ENABLED;
        }
        pCon->a2ConState = QBT_AA_STATE_CONNECTED;
        QBTAA(bdAddr)  = pCon->bdAddr;
        QBTAA(isConnected) = TRUE;
        QBTAA(bAuthorizedA2DP) = TRUE;
        QBTAA(numCon)++;
        if (QBTAA(bDirection) == BT_RM_ATZRQ_OUTGOING) {
          static audiosbcenc_data_type voc_sbc_data_dummy = {{40},{21}, 4, 32};
          TASKLOCK();
          (void)bt_cmd_pf_a2dp_start(QBTAA(appId), &voc_sbc_data_dummy);
          (void)bt_cmd_pf_a2dp_suspend(QBTAA(appId));
          TASKFREE();
          (void)bt_cmd_pf_a2dp_ctl(QBTAA(appId), BT_PF_A2DP_CTL_RECFG_BY_RECFG, 0);
          (void)bt_cmd_pf_a2dp_ctl(QBTAA(appId), BT_PF_A2DP_CTL_SUSPEND_ON_END, 0);
        }
      }
      else
      {
        // disconnect a2dp connection
	      BT_MSG_HIGH("QBT A2DP EV: a2dp connected fail status = %x", QBTAA(state), 0, 0);
        
        qbt_a2dp_disconnect(&bt_ev_msg_ptr->ev_msg.ev_a2dp_con.bd_addr);
      }

      // notify mbt
      qbt_a2dp_notify_mbt(event);
      break;
    }

    case BT_EV_PF_A2DP_DISCON:
    {
      QBTA2DPCon *pCon = NULL;

      BT_MSG_HIGH("QBT A2DP EV: a2dp disconnect event callback state = %x", QBTAA(state), 0, 0);	

      (void)bt_cmd_rm_set_connectable(QBTAA(appId), TRUE, BT_RM_AVP_AUTOMATIC);

      pCon = qbt_a2dp_find_conn(&bt_ev_msg_ptr->ev_msg.ev_a2dp_discon.bd_addr,
                                FALSE);
      if (pCon != NULL)
      {
        qbt_a2dp_conn_init(pCon);
        QBTAA(numCon)--;
        if ( (QBT_AA_STATE_DISC_PEND == QBTAA(state)) ||
                    (QBT_AA_STATE_CONN_PEND == QBTAA(state)) )
        {
          QBTAA(state) = QBT_AA_STATE_ENABLED;
        }
        QBTAA(isConnected) = FALSE;
        QBTAA(bAuthorizedA2DP) = FALSE;
        QBTAA(bdAddr) = QBT_AA_NULL_BD_ADDR;
      }
     else
	{
	      BT_MSG_HIGH("QBT A2DP EV: a2dp disconnect fail  = %x", QBTAA(state), 0, 0);	
     	}

/// sy_lee [2009/9/4] first disconnect A2DP[[		
	if(QBTAA(state) == QBT_AA_STATE_DISABLE_DISCONNECT_PEND)			
	{
		(void)bt_cmd_rm_set_connectable(QBTAA(appId), FALSE, BT_RM_AVP_AUTOMATIC);
		bt_cmd_pf_a2dp_disable(QBTAA(appId));
		QBTAA(isConnected) = FALSE;			
/*		
#if TRUE
		QBTAA(state) = QBT_AA_STATE_ENABLED;
		 mbt_postevent(MBTEVT_A2DP_SOURCE_ENABLE_SUCCESS, 0);	
		 
#endif
*/
		QBTAA(state) = QBT_AA_STATE_DISABLE_PEND;
	}
/// sy_lee [2009/9/4] first disconnect A2DP]]			  
      // put this device as not in use
      //qbt_dm_put_in_use(&bt_ev_msg_ptr->ev_msg.ev_a2dp_discon.bd_addr, FALSE);

      // notify mbt
      qbt_a2dp_notify_mbt(event);
      break;
    }

    case BT_EV_PF_A2DP_CON_FAILED:
    {
      QBTA2DPCon *pCon = NULL;

      pCon = qbt_a2dp_find_conn(
                &bt_ev_msg_ptr->ev_msg.ev_a2dp_con_failed.bd_addr, FALSE );
      if (pCon != NULL)
      {
        if (QBT_AA_STATE_CONN_PEND == QBTAA(state))
        {
          QBTAA(state) = QBT_AA_STATE_ENABLED;
          QBTAA(bdAddr)= QBT_AA_NULL_BD_ADDR;
        }
        qbt_a2dp_conn_init(pCon);
      }

      // notify mbt
      qbt_a2dp_notify_mbt(event);
      break;
    }

    default:
    {
      BT_MSG_HIGH( "QBT A2DP EV: unknown event[%d] not handled", event, 0, 0 );
      break;
    }
  }

  return;
}

#endif

/*-----------------------------------------------------------------------------
                       EXTERN FUNCTION DEFINITIONS
-----------------------------------------------------------------------------*/

/*=============================================================================
FUNCTION:  mbt_a2dp_is_connected
=============================================================================*/
/**
    Check if a2dp connection is present or not

    @see
    @return      boolean
*/
boolean mbt_a2dp_is_connected(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	return QBTAA(isConnected);
#endif
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
void mbt_a2dp_init(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	uint32 i;

	for (i = 0; i < QBT_AA_MAX_CONNECTIONS; i++)
	{
		qbt_a2dp_conn_init(&(QBTAA(aConn[i])));
	}

	return;
#endif
#endif
}


/*=============================================================================
FUNCTION:  mbt_a2dp_source_enable
=============================================================================*/
/**
    Enable A2DP service

    @see
    @return       None
*/
void mbt_a2dp_source_enable(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	if (QBTAA(state) != QBT_AA_STATE_INIT)
	{
		BT_MSG_HIGH("QBT A2DP: Already enabled!!!",0,0,0);
		return;
	}

   if (BT_APP_ID_NULL == QBTAA(appId))
   {
	  QBTAA(appId) = bt_cmd_ec_get_app_id_and_register(qbt_a2dp_event_cb);
   }

	BT_MSG_HIGH("QBT A2DP CMD: Enable a2dp  aid(%d) ", QBTAA(appId), 0, 0);
	
	if (BT_APP_ID_NULL == QBTAA(appId))
	{
		BT_MSG_HIGH("QBT A2DP: Could not allocate app id",0, 0, 0);
	}
	else
	{
		boolean ret;
		uint32 i;
		
		//memset((void*)&(QBTAAOBJ()), 0, sizeof(QBTA2DP));
		QBTAA(bdAddr)		  = QBT_AA_NULL_BD_ADDR;
		QBTAA(state)		  = QBT_AA_STATE_INIT;
		QBTAA(numCon)		  = 0;
		QBTAA(isConnected)	  = FALSE;
		QBTAA(btSec)		  = BT_SEC_NONE;

		for (i = 0; i < QBT_AA_MAX_CONNECTIONS; i++)
		{
			qbt_a2dp_conn_init(&(QBTAA(aConn[i])));
		}
		// Register with the A2DP layer
		ret = qbt_a2dp_enable();

		BT_MSG_HIGH("QBT A2DP: Enable a2dp, ret = 0x%x", ret, 0, 0);
	}
#endif
#endif
	return;
}

/*=============================================================================
FUNCTION:  mbt_a2dp_source_disable
=============================================================================*/
/**
    Disable A2DP service

    @see
    @return      None
*/
void mbt_a2dp_source_disable(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	BT_MSG_HIGH("QBT A2DP CMD: Disabling a2dp, aid = 0x%x", QBTAA(appId), 0, 0);

	if (QBTAA(state) < QBT_AA_STATE_ENABLED)
	{
		BT_MSG_HIGH("QBT A2DP: Bad state, state = 0x%x",QBTAA(state), 0, 0);
		return;
	}

	if (BT_APP_ID_NULL != QBTAA(appId))
	{
		if ( TRUE == QBTAA(isConnected) )
		{
			// should disconnect before disabling
			qbt_a2dp_disconnect(&(QBTAA(bdAddr)));
			QBTAA(state) = QBT_AA_STATE_DISABLE_DISCONNECT_PEND;			
		}
/// sy_lee [2009/9/4] first disconnect A2DP[[		
		else
		{
			QBTAA(state) = QBT_AA_STATE_DISABLE_PEND;
			(void)bt_cmd_rm_set_connectable(QBTAA(appId), FALSE, BT_RM_AVP_AUTOMATIC);
			bt_cmd_pf_a2dp_disable(QBTAA(appId));
			QBTAA(isConnected) = FALSE;			

/*			
#if TRUE
		        QBTAA(state) = QBT_AA_STATE_ENABLED;
		         mbt_postevent(MBTEVT_A2DP_SOURCE_ENABLE_SUCCESS, 0);	
#endif	
*/
		}
/// sy_lee [2009/9/4] first disconnect A2DP]]		
  }

	
#endif
#endif
  return;
}

/*=============================================================================
FUNCTION:  qbt_cmd_a2dp_connect
=============================================================================*/
/**
    Setup an A2DP connection

    @see
    @return      None
*/
void mbt_a2dp_source_connect(T_MBT_BDADDR pAddr)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	QBTA2DPCon *pCurCon = NULL;
	bt_bd_addr_type* pBDAddr = NULL;

		BT_MSG_HIGH("QBT A2DP CMD: Connect failed state = %d %d %d", QBTAA(state),QBTAA(numCon), 0);

	if ( (NULL == pAddr) || (QBT_AA_STATE_INIT == QBTAA(state)) ||
       (QBT_AA_MAX_CONNECTIONS == QBTAA(numCon)) )
	{
		BT_MSG_HIGH("QBT A2DP CMD: Connect failed state = %d %d %d", QBTAA(state),QBTAA(numCon), 0);
		// notify sap
		qbt_a2dp_notify_mbt(BT_EV_PF_A2DP_CON_FAILED);
		return;
	}

	memcpy((void*)&(QBTAA(bdAddr.bd_addr_bytes)), pAddr, QBT_AA_NUM_BDADDR_BYTES);
	pBDAddr = &(QBTAA(bdAddr));
	pCurCon = qbt_a2dp_find_conn(pBDAddr, TRUE);
	if (NULL == pCurCon)
	{
		QBTAA(bdAddr) = QBT_AA_NULL_BD_ADDR;
		BT_MSG_HIGH ("QBT A2DP CMD: A2dp connect, no more connection!", 0, 0, 0);
		return;
	}
	else if (QBT_AA_STATE_CONNECTED == pCurCon->a2ConState)
	{
		QBTAA(bdAddr) = QBT_AA_NULL_BD_ADDR;
		BT_MSG_HIGH ("QBT A2DP CMD: A2dp already connected, no more connection!",
				0, 0, 0);
		return;
	}
	else
	{
		bt_cmd_status_type status;
		boolean ret;

		BT_MSG_HIGH("QBT A2DP CMD: Connect a2dp, aid = 0x%x", QBTAA(appId), 0, 0);

		status = bt_cmd_pf_a2dp_connect(QBTAA(appId), pBDAddr);
		ret = qbt_a2dp_convert_bt_cmd_status(status);
		if (TRUE == ret)
		{
			// mark the connection obj as not free
			pCurCon->bFree = FALSE;
			// mark the connection state as conn pending
			pCurCon->a2ConState = QBT_AA_STATE_CONN_PEND;
			// mark the engine state
			QBTAA(state) = QBT_AA_STATE_CONN_PEND;
			// mark the current device in the engine for which the connection is pend
			QBTAA(bdAddr)= *pBDAddr;

			BT_MSG_HIGH("QBT A2DP: A2dp connect pending", 0, 0, 0);
		}
		else
		{
			BT_MSG_HIGH("QBT A2DP: A2dp connect failed to queue", 0, 0, 0);
			qbt_a2dp_conn_init( pCurCon );
		}
	}
#endif
#endif
  return;
}

/*=============================================================================
FUNCTION:  mbt_a2dp_source_disconnect
=============================================================================*/
/**
    Disconnects from a connected A2DP device

    @see
    @return      None
*/
void mbt_a2dp_source_disconnect(T_MBT_BDADDR BdAddr)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	//if ( (QBT_AA_STATE_ENABLED != QBTAA(state)) || (!QBTAA(isConnected)) )
	//{
	//	BT_MSG_HIGH ("QBT A2DP: Disconnect a2dp failed! state=%d, isConnected=%d", QBTAA(state), QBTAA(isConnected), 0);
	//	return;
	//}
	BT_MSG_HIGH("QBT A2DP CMD: Connect failed state = %d %d %d", QBTAA(state),QBTAA(numCon), 0);

	BT_MSG_HIGH ("QBT A2DP CMD: Disconnect a2dp, aid = 0x%x state = %x num = %x",QBTAA(appId),  QBTAA(state),QBTAA(numCon));
	qbt_a2dp_disconnect(&QBTAA(bdAddr));

#endif
#endif
  return;
}

/*=============================================================================
FUNCTION:  mbt_a2dp_source_start
=============================================================================*/
/**
    Setup streaming audio data with the remote device

    @see
    @return      None
*/
void mbt_a2dp_source_start(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	audiosbcenc_data_type stvoc_sbc_data_dummy = {{40},{21}, 4, 32};

	if ( (QBT_AA_STATE_ENABLED != QBTAA(state)) ||
		(BT_APP_ID_NULL == QBTAA(appId)) )
	{
		BT_MSG_HIGH ("QBT A2DP CMD: Start a2dp failed, state = 0x%x",
				QBTAA(state), 0, 0);
		return;
	}

	if ( TRUE != QBTAA(isConnected) )
	{
		BT_MSG_HIGH ("QBT A2DP CMD: Start a2dp failed!", 0, 0, 0);
		return;
	}

	BT_MSG_HIGH ("QBT A2DP CMD: Start a2dp, aid = 0x%x", QBTAA(appId), 0, 0);

	(void)bt_cmd_pf_a2dp_start(QBTAA(appId), &stvoc_sbc_data_dummy);

#endif
#endif
  return;
}

/*=============================================================================
FUNCTION:  mbt_a2dp_source_stop
=============================================================================*/
/**
    Suspends a started audio stream

    @see
    @return      None
*/
void mbt_a2dp_source_stop(void)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
	if ( (QBT_AA_STATE_ENABLED != QBTAA(state)) ||
		(BT_APP_ID_NULL == QBTAA(appId)) )
	{
		BT_MSG_HIGH("QBT A2DP CMD: Suspend a2dp failed, state = 0x%x",
				QBTAA(state), 0, 0);
		return;
	}

	if (TRUE != QBTAA(isConnected))
	{
		BT_MSG_HIGH ("QBT A2DP: Suspend a2dp failed!", 0, 0, 0);
		return;
	}

	// suspend the stream
	BT_MSG_HIGH ("QBT A2DP CMD: Suspend a2dp, aid = 0x%x", QBTAA(appId), 0, 0);
	bt_cmd_pf_a2dp_ctl(QBTAA(appId), BT_PF_A2DP_CTL_SUSPEND_ON_END, 0);

	// close/suspend the stream based on "suspend" argument
	(void)bt_cmd_pf_a2dp_suspend(QBTAA(appId));

#endif
#endif
	return;
}

/*=============================================================================
FUNCTION:  mbt_a2dp_source_pause
=============================================================================*/
/**
    Suspends a started audio stream

    @see
    @return      None
*/
MBT_VOID mbt_a2dp_source_pause(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
#endif
#endif
}

/*=============================================================================
FUNCTION:  mbt_a2dp_source_resume
=============================================================================*/
/**
    resume a started audio stream

    @see
    @return      None
*/
MBT_VOID mbt_a2dp_source_resume(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#ifdef FEATURE_BT_EXTPF_AV
#endif
#endif
}

/*=============================================================================
internal functions
=============================================================================*/
MBT_VOID mbt_a2dp_set_direction(MBT_BOOL direction)
{
	BT_MSG_HIGH ("QBT A2DP CMD: Set Connecting direction = 0x%x", direction, 0, 0);  
	QBTAA(bDirection) = direction;
}

MBT_BOOL mbt_a2dp_get_authorized_channel(MBT_VOID)
{
  return QBTAA(bAuthorizedA2DP);
}

MBT_VOID mbt_a2dp_set_authorized_channel(MBT_BOOL bAuth)
{
  BT_MSG_HIGH ("QBT A2DP CMD: set authorized a2dp %d", bAuth, 0, 0);
  QBTAA(bAuthorizedA2DP) = bAuth;
  return;
}

