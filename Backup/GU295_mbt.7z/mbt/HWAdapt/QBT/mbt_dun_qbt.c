/*******************************************************************************
*	DUN�� MBT 1.0���� ���Ե��� ������ �׽�Ʈ ���� �ʾҽ��ϴ�.
********************************************************************************/
/********************************************************************************
*	File Name	: mbt_dun_brcm.c
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.04.12		Kim,Hyunseok			Created
********************************************************************************/
#include "mbt_dun.h"
#include "mbt_sdc.h"
#include "mbt_evhandler.h"
#include "mbt_gap.h"
#include "qbt_utils/qbt_fs.h"
#include "qbt_utils/qbt_lang.h"
#include "qbt_utils/qbt_utils.h"
#include "bt.h"
#include "btsd.h"

static bt_app_id_type  mbt_dun_app_id = BT_APP_ID_NULL;
MBT_VOID mbt_dun_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );

#if (MBT_DUN == MBT_TRUE)

/********************************************************************************
*	Prototype	: MBT_VOID mbt_dun_init (MBT_VOID)
*	Description : 
********************************************************************************/
MBT_VOID mbt_dun_init(MBT_VOID)
{
	if(mbt_dun_app_id == BT_APP_ID_NULL)
	{
		mbt_dun_app_id = bt_cmd_ec_get_app_id_and_register(mbt_dun_EventCallback);

		if (mbt_dun_app_id == BT_APP_ID_NULL)
		{
			MBT_ERR("DUN App id register error. app_id :%d",mbt_dun_app_id,0,0);
			mbt_postevent(MBTEVT_DUN_ENABLE_FAIL, 0);
			return;
		}
		else
		{
			MBT_PI("DUN Init Success. app_id :%d",mbt_dun_app_id,0,0);
		}
	}	
	else
	{
		MBT_FATAL("##DUN Initialize Over time Error. app_id ");
	}
}

/*=========================================================================== 
*	Prototype	:		MBT_VOID mbt_dun_enable (MBT_VOID)
*	Description: 		DUN ���������� Ȱ��ȭ ��Ų��.
*	Return	:		NONE
*	Expected Event:	MBTEVT_DUN_ENABLE_FAIL
*		                     MBTEVT_DUN_ENABLE_SUCCESS
===========================================================================*/
MBT_VOID mbt_dun_enable (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	T_MBT_DUN_STATUS * sdcDUNStatus = (T_MBT_DUN_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_DUN_STATUS);
//	if(sdcDUNStatus->bEnabled == MBT_FALSE)
	if(TRUE)
	{
		bt_cmd_na_enable(mbt_dun_app_id);
		//mbt_postevent(MBTEVT_DUN_ENABLE_SUCCESS, 0); // LEECHANGHOON 2008-2-1 Callback���� �÷���.
	}
	else
	{
		MBT_ERR("Already DUN service enabled.  app_id :%d",mbt_dun_app_id,0,0);
		mbt_postevent(MBTEVT_DUN_ENABLE_FAIL, 0);
	}
	 
#endif
}

/*===========================================================================
*	Prototype	:	MBT_VOID mbt_dun_disable (MBT_VOID)
*	Description:	DUN ���������� ��Ȱ��ȭ ��Ų��.
*	Return	:	NONE
*	Expected Event:	MBTEVT_DUN_DISABLE_FAIL
*                 			MBTEVT_DUN_DISABLE_SUCCESS
===========================================================================*/
MBT_VOID mbt_dun_disable (MBT_VOID)
{
	T_MBT_DUN_STATUS * sdcDUNStatus = (T_MBT_DUN_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_DUN_STATUS);
#ifdef MBT_EMULATOR
#else
	if(sdcDUNStatus->bEnabled == MBT_TRUE)
	{
		bt_cmd_na_disable(mbt_dun_app_id);
	}
	else
	{
		MBT_ERR("Already DUN service disabled.",0,0,0);
		mbt_postevent(MBTEVT_DUN_DISABLE_FAIL, 0);
	}

#endif
}

/*===========================================================================
*	Prototype	:	MBT_VOID mbt_dun_disconnect (T_MBT_BDADDR *remoteBdAddr)
*	Description:	DUN service connection �� ������ ���� ��Ų��
*	Return	:	NONE
*	Expected Event:	 MBTEVT_DUN_DISCONNECT_FAIL
*		                     MBTEVT_DUN_DISCONNECT_SUCCESS
===========================================================================*/
MBT_VOID mbt_dun_disconnect(T_MBT_BDADDR remoteBdAddr)
{	
#ifdef MBT_EMULATOR
#else
#endif
}
/*===========================================================================
* Listen start
===========================================================================*/
MBT_VOID mbt_dun_listen(MBT_VOID)
{
	//BTA_DgListen(BTA_DUN_SERVICE_ID, BTA_SEC_AUTHORIZE|BTA_SEC_AUTHENTICATE, "Dial-up Networking", 0);
	//BTA_DgListen(BTA_SPP_SERVICE_ID, BTA_SEC_AUTHORIZE|BTA_SEC_AUTHENTICATE, "Serial Port A", 1);
}

/*===========================================================================
*	Prototype	:	MBT_VOID mbt_dun_senddata(MBT_VOID)
*	Description:	Terminal ������, Data �� �����Ѵ�
*	Return	:	NONE
*	Expected Event:	    MBTEVT_DUN_SEND_DATA_FAIL
*                  			    MBTEVT_DUN_SEND_DATA_SUCCESS
===========================================================================*/
MBT_VOID mbt_dun_listenstop(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else

	


#endif
}

MBT_VOID mbt_dun_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{
	T_MBT_DUN_STATUS * sdcDUNStatus = (T_MBT_DUN_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_DUN_STATUS);
  	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
  	{			
	  	case BT_EV_GN_CMD_DONE:		
			{
				bt_ev_gn_cmd_done_type* pm =    (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;
				MBT_SDC("DUN_Event BT_EV_GN_CMD_DONE cmd = 0x%x, status= %d",   pm->cmd_type, pm->cmd_status,0);
	  		}
			break;

    	case BT_EV_NA_ENABLED:		
	    	{
				sdcDUNStatus->bEnabled = MBT_TRUE;
				sdcDUNStatus->State = MBT_DUN_STATE_IDLE;
				MBT_PI("DUN Enabled : app_id:%x", mbt_dun_app_id, 0, 0);
				mbt_postevent(MBTEVT_DUN_ENABLE_SUCCESS, 0);
	    	}
			break;
			
		case BT_EV_NA_DISABLED:		
	    	{
				sdcDUNStatus->bEnabled = MBT_FALSE;
				sdcDUNStatus->State = MBT_DUN_CLOSED;
				memset(sdcDUNStatus->BdAddr, 0x00, sizeof(sdcDUNStatus->BdAddr));
				MBT_PI("DUN Disabled.", 0, 0, 0);
				mbt_postevent(MBTEVT_DUN_DISABLE_SUCCESS, 0);
	    	}
			break;

	    	case BT_EV_NA_CONNECTED:
	    	{
				MBT_PI("BT_EV_NA_CONNECTED", 0,0,0);
				sdcDUNStatus->State = MBT_DUN_CONNECTED;
				bdcpy(sdcDUNStatus->BdAddr, bt_ev_msg_ptr->ev_msg.ev_na_conn.bd_addr.bd_addr_bytes);
		   	}
			break;
    		case BT_EV_NA_DISCONNECTED:
    		{
				MBT_PI("BT_EV_NA_DISCONNECTED", 0,0,0);
				sdcDUNStatus->State = MBT_DUN_STATE_IDLE;
    		}
			break;

		default:
			{
				MBT_WARN( "DUN callback - unexpect event %x",  bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0 );
	    	}
			break;
      	}
}

#endif	//#if (MBT_DUN == MBT_TRUE)
