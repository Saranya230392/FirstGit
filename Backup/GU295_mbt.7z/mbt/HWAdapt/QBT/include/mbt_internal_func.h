#ifndef _MBT_INT_PI_H_
#define	_MBT_INT_PI_H_

#include "MBTType.h"
#include "bt.h"

/*======== GAP ===========*/
bt_cmd_status_type mbt_gap_allow_role_switch(T_MBT_BDADDR RemoteBDAddr);
bt_cmd_status_type mbt_gap_restore_role_switch(T_MBT_BDADDR RemoteBDAddr);
void mbt_gap_ev_rm_authoReq(bt_ev_msg_type* bt_ev_msg_ptr);
MBT_VOID mbt_gap_init(MBT_VOID);
MBT_VOID mbt_gap_update_pairedList(MBT_VOID);

int mbt_gap_set_connection_role( const T_MBT_BDADDR*  pBDAddr, MBT_BOOL bMaster);
bt_role_type mbt_gap_get_connection_role(const T_MBT_BDADDR* pBDAddr);


/*======== AG ===========*/
MBT_VOID mbt_ag_init(MBT_VOID);

/*======== OPP ===========*/
MBT_VOID mbt_opp_init(MBT_VOID);

/*======== FTP ===========*/
MBT_VOID mbt_ftp_init(MBT_VOID);

/*======== SPP ===========*/
MBT_VOID mbt_spp_init(MBT_VOID);

/*======== DUN ===========*/
MBT_VOID mbt_dun_init(MBT_VOID);

/*======== A2DP ===========*/
MBT_VOID mbt_a2dp_init(MBT_VOID);
MBT_VOID mbt_a2dp_set_direction(MBT_BOOL direction);
MBT_BOOL mbt_a2dp_get_authorized_channel(MBT_VOID);
MBT_VOID mbt_a2dp_set_authorized_channel(MBT_BOOL bAuth);

/*======== AVRCP ===========*/
MBT_VOID mbt_avrcp_init(MBT_VOID);

/*======== JSR82 ===========*/
MBT_INT mbt_jsr82_getEmptyIdx(MBT_VOID);

#endif
