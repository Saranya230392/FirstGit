/********************************************************************************
*	File Name	: mbt_ag_brcm.c
*	Description	: 
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.04.05		Lee,MyungHee		Created
*	07.11.25		LEE CHANG HOON		Modified
********************************************************************************/
#include <stdio.h>
#include <string.h>
#include "mbt_ag.h"
#include "mbt_sdc.h"
#include "mbt_evhandler.h"
#include "qbt_utils/qbt_utils.h"

#include "bt.h"
#include "btag.h"
#include "keypad.h"
#include "voc.h"


// LEECHANGHOON 2007-12-11 For QBT
#define MBT_AG_RING_COUNT	20
#define MBT_AG_RING_PERIOD	10
#define BT_HF_F_VR_ACTIVATION         0x00000008
#define BT_HF_F_REMOTE_VOL_CTRL       0x00000010

static bt_app_id_type  mbt_ag_app_id = BT_APP_ID_NULL;
static rex_timer_type  sco_timer;
static uint8 sco_timer_tick = 0;
static MBT_BOOL ring_alert_ongoing = MBT_FALSE;
static boolean vrState = 0;
/// sy_lee [2009/9/16] sco play error[[
#ifdef FEATURE_AVS_BT_SCO_REWORK
static uint32 playback_status = 0x00;
#endif
static uint32 ag_audiostatus = 0x00;
enum{
	AG_AUDIO_INIT = 0x00,
	AG_AUDIO_CONNECTING,
	AG_AUDIO_CONNECTED,	
	AG_AUDIO_DISCONNECTING,		
	AG_AUDIO_DISCONNECTED,		
	AG_AUDIO_MAX
};

/// sy_lee [2009/9/16] sco play error[[

void BTRPrintf(char* str)
{
	int i;
	for(i=0; i<strlen(str); i++)
		MBT_PI("sent[%d] : %c", i,str[i], 0);
}


//-----------------------Rm Evt Callback ���� ------------------------------------//
void mbt_ag_ev_cmdDone(bt_ev_msg_type* bt_ev_msg_ptr)
{
	// LEECHANGHOON 2007-11-13 bt_cmd ������ EV callback �������� ó���Ұ͵� ���⼭...
	bt_ev_gn_cmd_done_type* pm =    (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;
	MBT_SDC("AG_Event BT_EV_GN_CMD_DONE cmd = 0x%x, status= 0x%x",   pm->cmd_type, pm->cmd_status,0);
}

void mbt_ag_ev_enabled(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);
	sdcAgStatus->bEnalbed = MBT_TRUE;
	ag_audiostatus	= AG_AUDIO_INIT;
	mbt_postevent(MBTEVT_AG_ENABLE_SUCCESS,0);
}

void mbt_ag_ev_disabled(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);
	sdcAgStatus->bEnalbed = MBT_FALSE;
	ag_audiostatus	= AG_AUDIO_INIT;	
	sdcAgStatus->bSupportBVRA = MBT_FALSE;
	sdcAgStatus->bSupportRemoteVolCtrl = MBT_FALSE;	
	vrState = FALSE;
	mbt_postevent(MBTEVT_AG_DISABLE_SUCCESS,0);
}

void mbt_ag_ev_connected(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);
	ag_audiostatus	= AG_AUDIO_INIT;	
	MBT_PI(" ag connected evt device:%d", bt_ev_msg_ptr->ev_msg.ev_ag_connected.audio_device, 0,0);
	if(bt_ev_msg_ptr->ev_msg.ev_ag_connected.audio_device == BT_AD_HEADSET)
	{
		sdcAgStatus->bAudioPath = MBT_FALSE;
		sdcAgStatus->bConection = MBT_TRUE;
		bdcpy(sdcAgStatus->BdAddr, bt_ev_msg_ptr->ev_msg.ev_ag_connected.bd_addr.bd_addr_bytes);
		MBT_PI("MBT EV Only HS Connected %s", bdAddrToString(sdcAgStatus->BdAddr),0,0);
		//mbt_gap_contable_add(sdcAgStatus->BdAddr, MBT_SVCUUID_HEADSET);
		mbt_postevent(MBTEVT_AG_CONNECT_SUCCESS,0);
	}
	else
	{
		MBT_PI("MBT EV RFComm HF Connected %s", 0,0,0);
	}
}

void mbt_ag_ev_connectFail(bt_ev_msg_type* bt_ev_msg_ptr)
{
	ag_audiostatus	= AG_AUDIO_INIT;
	mbt_postevent(MBTEVT_AG_CONNECT_FAIL,0);
}

void mbt_ag_ev_disconnected(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);
	ag_audiostatus	= AG_AUDIO_INIT;
	bdcpy(sdcAgStatus->BdAddr, bt_ev_msg_ptr->ev_msg.ev_ag_disconnected.bd_addr.bd_addr_bytes);
	//mbt_gap_contable_remove(sdcAgStatus->BdAddr, MBT_SVCUUID_HF_HANDSFREE);
	//mbt_gap_contable_remove(sdcAgStatus->BdAddr, MBT_SVCUUID_HEADSET);
	sdcAgStatus->bAudioPath = MBT_FALSE;
	sdcAgStatus->bConection = MBT_FALSE;
	sdcAgStatus->bSupportBVRA = MBT_FALSE;
	sdcAgStatus->bSupportRemoteVolCtrl = MBT_FALSE;
	vrState = FALSE;
	memset(sdcAgStatus->BdAddr, 0x0, sizeof(T_MBT_BDADDR));
	bt_cmd_ag_ring_audio_device(mbt_ag_app_id, 0, 0);
	mbt_postevent(MBTEVT_AG_DISCONNECT_SUCCESS,0);
}

void mbt_ag_ev_audioConnected(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);

	ag_audiostatus	= AG_AUDIO_CONNECTED;
	sdcAgStatus->bAudioPath = MBT_TRUE;
	mbt_postevent(MBTEVT_AG_AUDIO_CONNECT_SUCCESS,0);
}

void mbt_ag_ev_audioDisconnected(bt_ev_msg_type* bt_ev_msg_ptr)
{
#if 0
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);
	sdcAgStatus->bAudioPath = MBT_FALSE;
	mbt_postevent(MBTEVT_AG_AUDIO_DISCONNECT_SUCCESS,0);
#else
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord( MBTSDC_REC_AG_INDICATION );
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE); 
	ag_audiostatus	= AG_AUDIO_DISCONNECTED;

	sdcAgStatus->bAudioPath = MBT_FALSE;
	mbt_postevent(MBTEVT_AG_AUDIO_DISCONNECT_SUCCESS,0); 

	if (ring_alert_ongoing == MBT_TRUE) 
	{
		ring_alert_ongoing = MBT_FALSE;
		bt_cmd_ag_ring_audio_device(mbt_ag_app_id, MBT_AG_RING_COUNT, MBT_AG_RING_PERIOD); 
	}
#endif
}

void mbt_ag_ev_audioConnectFail(bt_ev_msg_type* bt_ev_msg_ptr)
{
	ag_audiostatus	= AG_AUDIO_INIT;
	mbt_postevent(MBTEVT_AG_AUDIO_CONNECT_FAIL, 0);
}

void mbt_ag_ev_slcChanged(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);
	//MBT_WARN("BT_EV_AG_SLC_CHANGED, slc_up = %x", bt_ev_msg_ptr->ev_msg.ev_ag_slc_changed.slc_up ,0,0);
	// Searching ���� ���� disconnect�Ѵ�. lhs. 060516
	/*
			if(sdStatus == BTSD_SEARCHING)
			{
			mbt_ag_disconnect(bt_ev_msg_ptr->ev_msg.ev_ag_slc_changed.bd_addr.bd_addr_bytes, MBT_SVCUUID_HF_HANDSFREE);
		break;
			}
			*/
	if ( bt_ev_msg_ptr->ev_msg.ev_ag_slc_changed.slc_up )
	{
		sdcAgStatus->bAudioPath = MBT_FALSE;
		sdcAgStatus->bConection = MBT_TRUE;
		bdcpy(sdcAgStatus->BdAddr, bt_ev_msg_ptr->ev_msg.ev_ag_connected.bd_addr.bd_addr_bytes);
		MBT_WARN("MBT EV Only HF Connected SLC_UP %s", bdAddrToString(sdcAgStatus->BdAddr),0,0);
		//mbt_gap_contable_add(sdcAgStatus->BdAddr, MBT_SVCUUID_HF_HANDSFREE);

		sdcAgStatus->bSupportBVRA = ((bt_ev_msg_ptr->ev_msg.ev_ag_slc_changed.features_bitmap & BT_HF_F_VR_ACTIVATION) == BT_HF_F_VR_ACTIVATION) ? MBT_TRUE : MBT_FALSE; 
		sdcAgStatus->bSupportRemoteVolCtrl = ((bt_ev_msg_ptr->ev_msg.ev_ag_slc_changed.features_bitmap & BT_HF_F_REMOTE_VOL_CTRL) == BT_HF_F_REMOTE_VOL_CTRL) ? MBT_TRUE : MBT_FALSE; 

		MBT_PI("MBT slcChanged  feature_bitmap(0x%04x), supportBVRA(%d), supportRemoteVolCtrl(%d)", bt_ev_msg_ptr->ev_msg.ev_ag_slc_changed.features_bitmap, sdcAgStatus->bSupportBVRA, sdcAgStatus->bSupportRemoteVolCtrl);
		
		// [DKMOON_S] for dual profile
		if(mbt_gap_get_connection_role((T_MBT_BDADDR*)sdcAgStatus->BdAddr)== BT_ROLE_SLAVE)
		{
			MBT_PI("[AG] Current role is slave, Change to master role.", 0,0,0);			
			mbt_gap_set_connection_role((T_MBT_BDADDR*)sdcAgStatus->BdAddr, TRUE);
		}
		else
		{
			MBT_PI("[AG] Current role is Master", 0,0,0);
		}
		// [DKMOON_E]

		mbt_postevent(MBTEVT_AG_CONNECT_SUCCESS,0);
	}
	else //Disconnect
	{
		MBT_WARN("MBT EV Only HF Disconnected SLC_DOWN", 0,0,0);
	}
}

void mbt_ag_ev_buttonPressed(bt_ev_msg_type* bt_ev_msg_ptr)
{
	// LEECHANGHOON 2007-12-14 �����غ���. HS�� ���� �Ŵ°��� �޴°��� �˼��� ����.
	//mbt_postevent(MBTEVT_AG_CALL_ANSWER,0);
	//Send UI Evnet to Call module
	KEYPAD_PASS_KEY_CODE(HS_BT_HOOK_K, HS_NONE_K);
	KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, HS_BT_HOOK_K);
}

void mbt_ag_ev_pickup(bt_ev_msg_type* bt_ev_msg_ptr)
{
	mbt_postevent(MBTEVT_AG_CALL_ANSWER,0);
}

void mbt_ag_ev_chld(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_3WAY *sdc3WayType = mbt_sdc_getrecord(MBTSDC_REC_AG_3WAYCALL_TYPE);
	sdc3WayType->CallIndex = bt_ev_msg_ptr->ev_msg.ev_ag_dev_hold.hold_call_id;
	sdc3WayType->CHLDValue = bt_ev_msg_ptr->ev_msg.ev_ag_dev_hold.hold_mode;
	sdc3WayType->bIsExtended = bt_ev_msg_ptr->ev_msg.ev_ag_dev_hold.is_hold_index_mode;
	//extended mode �߰��Ǿ�� ��. 
	mbt_postevent(MBTEVT_AG_CALL_3WAY,0);
}

void mbt_ag_ev_hangup(bt_ev_msg_type* bt_ev_msg_ptr)
{
	mbt_postevent(MBTEVT_AG_CALL_END,0);
}

void mbt_ag_ev_toggle(bt_ev_msg_type* bt_ev_msg_ptr)
{
//	vrState = bt_ev_msg_ptr->ev_msg.ev_ag_vr_state.vr_enabled;
	if(bt_ev_msg_ptr->ev_msg.ev_ag_vr_state.vr_enabled)
		mbt_postevent(MBTEVT_AG_VR_ACT,0);
	else
		mbt_postevent(MBTEVT_AG_VR_DEACT,0);
}

void mbt_ag_ev_dial(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_DIALINFO *sdcAgDialInfo = mbt_sdc_getrecord(MBTSDC_REC_AG_DIALINFO);

	sdcAgDialInfo->DialNum = strlen((MBT_CHAR *)bt_ev_msg_ptr->ev_msg.ev_ag_dev_dial.phone_num);
	sdcAgDialInfo->DialType = MBT_AG_CALL_NORMALDIAL;
	strcpy((MBT_CHAR *)sdcAgDialInfo->Digit, (MBT_CHAR *)bt_ev_msg_ptr->ev_msg.ev_ag_dev_dial.phone_num);
	MBT_PI("phone number length : %d, digit[0]:%c, digit[1]:%c", 
						sdcAgDialInfo->DialNum,sdcAgDialInfo->Digit[0],sdcAgDialInfo->Digit[1]);
	mbt_postevent(MBTEVT_AG_CALL_DIAL,0);
}

void mbt_ag_ev_memoryDial(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_DIALINFO *sdcAgDialInfo = mbt_sdc_getrecord(MBTSDC_REC_AG_DIALINFO);
				
	sdcAgDialInfo->DialNum = strlen((MBT_CHAR *)bt_ev_msg_ptr->ev_msg.ev_ag_dev_mem_dial.mem_entry);
	sdcAgDialInfo->DialType = MBT_AG_CALL_MEMDIAL;
	strcpy((MBT_CHAR *)sdcAgDialInfo->Digit, (MBT_CHAR *)bt_ev_msg_ptr->ev_msg.ev_ag_dev_mem_dial.mem_entry);
	MBT_PI("Memory Dial DialLength:%d, Digit[0]:%c, Digit[1]:%c", 
						sdcAgDialInfo->DialNum,sdcAgDialInfo->Digit[0],sdcAgDialInfo->Digit[1]);
	mbt_postevent(MBTEVT_AG_CALL_MEMDIAL,0);
}

void mbt_ag_ev_reDial(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_DIALINFO *sdcAgDialInfo = mbt_sdc_getrecord(MBTSDC_REC_AG_DIALINFO);
				
	sdcAgDialInfo->DialType = MBT_AG_CALL_REDIAL;
	mbt_postevent(MBTEVT_AG_CALL_REDIAL,0);
}

void mbt_ag_ev_spkGainReport(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_SPKGAIN *sdcAgSpkGain = mbt_sdc_getrecord(MBTSDC_REC_AG_SPKGAIN);

	sdcAgSpkGain->VolumeLevel = (MBT_BYTE)bt_ev_msg_ptr->ev_msg.ev_ag_ad_spkr_gain_report.ad_speaker_gain;
	mbt_postevent(MBTEVT_AG_SPK,0);
}

void mbt_ag_ev_micGainReport(bt_ev_msg_type* bt_ev_msg_ptr)
{
}

void mbt_ag_ev_sendDTMF(bt_ev_msg_type* bt_ev_msg_ptr)
{
	//mbt_postevent(MBTEVT_AG_CALL_DTMF);
	if(bt_ev_msg_ptr->ev_msg.ev_ag_dev_send_dtmf.dtmf_char == 0x23)
		bt_ev_msg_ptr->ev_msg.ev_ag_dev_send_dtmf.dtmf_char = HS_POUND_K;
	// UI�� DTMF key ���� �÷��ش�.
	KEYPAD_PASS_KEY_CODE((hs_key_type) bt_ev_msg_ptr->ev_msg.ev_ag_dev_send_dtmf.dtmf_char, HS_NONE_K);
	KEYPAD_PASS_KEY_CODE(HS_RELEASE_K, (hs_key_type) bt_ev_msg_ptr->ev_msg.ev_ag_dev_send_dtmf.dtmf_char);
}

void mbt_ag_ev_cops(bt_ev_msg_type* bt_ev_msg_ptr)
{
	mbt_postevent(MBTEVT_AG_OPERATOR,0);
}

void mbt_ag_ev_cnum(bt_ev_msg_type* bt_ev_msg_ptr)
{
	mbt_postevent(MBTEVT_AG_SUBSCRIBER,0);
}

void mbt_ag_ev_clcc(bt_ev_msg_type* bt_ev_msg_ptr)
{
	mbt_postevent(MBTEVT_AG_CALLLIST,0);
}

void mbt_ag_ev_cscs(bt_ev_msg_type* bt_ev_msg_ptr)
{
	char str[BT_AG_MAX_SEND_LENGTH+1];
	sprintf(str, "%s", "+CSCS: (\"GSM\")");
	BTRPrintf(str);
	bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)str);
	mbt_ag_sendresponse(MBT_TRUE);
}

void mbt_ag_ev_setCharset(bt_ev_msg_type* bt_ev_msg_ptr)
{
	//mbt_postevent(MBTEVT_AG_PB_CSCS_SET,0);
	MBT_PI(" charset selected : %c,%c,%c", bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_charset[0],
		bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_charset[1],
		bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_charset[2]);
	MBT_PI(" charset selected : %c,%c,%c", bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_charset[3],
		bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_charset[4],
		bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_charset[5]);
	mbt_ag_sendresponse(MBT_TRUE);
}

void mbt_ag_ev_getPbList(bt_ev_msg_type* bt_ev_msg_ptr)
{
	mbt_postevent(MBTEVT_AG_PB_CPBS_TEST,0);
}

void mbt_ag_ev_setPb(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_PB_CPBS * sdcAGPBRXcpbs = (T_MBT_AG_PB_CPBS*)mbt_sdc_getrecord(MBTSDC_REC_AG_RXCPBS);
	char str[BT_AG_MAX_SEND_LENGTH+1];
	//phonebook �� index sync�� ���� �ʾ� ���Ƿ� �Ʒ��� ���� ���� ... index ���� �� ��. 
	if(!strcmp(bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_phonebook, "ME"))
	{
		sdcAGPBRXcpbs->selectedPbType = MBT_AG_PB_DEV_ME;
		mbt_ag_sendresponse(MBT_TRUE);
		MBT_PI("Set ME to primary phonebook",0,0,0);
	}
	else if(!strcmp(bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_phonebook, "SM"))
	{
		sdcAGPBRXcpbs->selectedPbType = MBT_AG_PB_DEV_SM;
		mbt_ag_sendresponse(MBT_TRUE);
		MBT_PI("Set SM to primary phonebook",0,0,0);
		
	}
	else if(!strcmp(bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_phonebook, "DC"))
	{
		sdcAGPBRXcpbs->selectedPbType = MBT_AG_PB_DEV_DC;
		mbt_ag_sendresponse(MBT_TRUE);
		MBT_PI("ME Dialed calls list",0,0,0);
	}
	else if(!strcmp(bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_phonebook, "MC"))
	{
		sdcAGPBRXcpbs->selectedPbType = MBT_AG_PB_DEV_MC;
		mbt_ag_sendresponse(MBT_TRUE);
		MBT_PI("ME missed calls list",0,0,0);
	}
	else if(!strcmp(bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.current_phonebook, "RC"))
	{
		sdcAGPBRXcpbs->selectedPbType = MBT_AG_PB_DEV_RC;
		mbt_ag_sendresponse(MBT_TRUE);
		MBT_PI("ME received calls list",0,0,0);
	}
	else
	{
		sprintf(str, "+CME ERROR: %d", MBT_AG_CME_ERR_MEMORY_FAILURE);
		BTRPrintf(str);
		bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)str);
	}
}

void mbt_ag_ev_getPbSize(bt_ev_msg_type* bt_ev_msg_ptr)
{
	mbt_postevent(MBTEVT_AG_PB_CPBS_READ,0);
}

void mbt_ag_ev_getPbIndex(bt_ev_msg_type* bt_ev_msg_ptr)
{
	mbt_postevent(MBTEVT_AG_PB_CPBR_TEST,0);
}

void mbt_ag_ev_getPbRecord(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AG_PB_CPBR * sdcAGPBRXcpbr = (T_MBT_AG_PB_CPBR*)mbt_sdc_getrecord(MBTSDC_REC_AG_RXCPBR);
	sdcAGPBRXcpbr->bStartIdx = bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.pb_index_start;
	sdcAGPBRXcpbr->bEndIdx = bt_ev_msg_ptr->ev_msg.ev_ag_pb_info.pb_index_end;
	mbt_postevent(MBTEVT_AG_PB_CPBR_SET,0);
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ag_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
*	Description	: EV Callback ó���� ����.
********************************************************************************/
MBT_VOID mbt_ag_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
{
	MBT_WARN("AG_EventType : %x",(bt_ev_msg_ptr->ev_hdr.ev_type - BT_CMD_EV_AG_BASE),0,0);

	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
			mbt_ag_ev_cmdDone(bt_ev_msg_ptr);
			break;

		case BT_EV_AG_ENABLED:
			mbt_ag_ev_enabled(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_DISABLED:
			mbt_ag_ev_disabled(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_CONNECTED:
			mbt_ag_ev_connected(bt_ev_msg_ptr);
			break;
		
		case BT_EV_AG_CONNECTION_FAILED:
			mbt_ag_ev_connectFail(bt_ev_msg_ptr);
			break;
		
		case BT_EV_AG_DISCONNECTED:
			mbt_ag_ev_disconnected(bt_ev_msg_ptr);
			break;
		
		case BT_EV_AG_AUDIO_CONNECTED:
			mbt_ag_ev_audioConnected(bt_ev_msg_ptr);
			break;
		
		case BT_EV_AG_AUDIO_DISCONNECTED:
			mbt_ag_ev_audioDisconnected(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_AUDIO_CONNECT_FAILED:
			mbt_ag_ev_audioConnectFail(bt_ev_msg_ptr);
			break;
		
		case BT_EV_AG_SLC_CHANGED: //HF Only
			mbt_ag_ev_slcChanged(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_BUTTON_PRESSED://HS Only
			mbt_ag_ev_buttonPressed(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_DEV_PICKUP://HF Only
			mbt_ag_ev_pickup(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_DEV_CHLD:
			mbt_ag_ev_chld(bt_ev_msg_ptr);
			break;
		case BT_EV_AG_DEV_HANGUP:
			mbt_ag_ev_hangup(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_VR_TOGGLE:
			mbt_ag_ev_toggle(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_DEV_DIAL:
			mbt_ag_ev_dial(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_DEV_MEM_DIAL:
			mbt_ag_ev_memoryDial(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_DEV_REDIAL:
			mbt_ag_ev_reDial(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_SPKR_GAIN_REPORT:
			mbt_ag_ev_spkGainReport(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_MIC_GAIN_REPORT:
			mbt_ag_ev_micGainReport(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_RING_FAILED: //Ring send�� ���� Failó��. AD�� ������ ���� ���..
			MBT_WARN("NO BT AD, use normal earpiece",0,0,0);
			break;
			
		case BT_EV_AG_DEV_SEND_DTMF:			
			mbt_ag_ev_sendDTMF(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_DEV_COPS_READ:
			mbt_ag_ev_cops(bt_ev_msg_ptr);
			break;
		case BT_EV_AG_DEV_CNUM:
			mbt_ag_ev_cnum(bt_ev_msg_ptr);
			
			break;
		case BT_EV_AG_DEV_CLCC:
			mbt_ag_ev_clcc(bt_ev_msg_ptr);
			break;

		case BT_EV_AG_CSCS:	// AT+CSCS=?
			mbt_ag_ev_cscs(bt_ev_msg_ptr);
			//mbt_postevent(MBTEVT_AG_PB_CSCS_TEST,0);
			break;
			
		case BT_EV_AG_CSCS_SET_CHARSET://AT+CSCS=<seleted charset>
			mbt_ag_ev_setCharset(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_CPBS_GET_PB_LIST: //AT+CPBS=?
			mbt_ag_ev_getPbList(bt_ev_msg_ptr);
			break;

		// ���� �ø��� �ʰ� . ���⼭ ó��. ������ sdc�� �Ʒ����� ������. 
		case BT_EV_AG_CPBS_SET_PB: //AT+CPBS=<selected phonebook>
			mbt_ag_ev_setPb(bt_ev_msg_ptr);
			//mbt_postevent(MBTEVT_AG_PB_CPBS_SET,0);
			break;
			
		case BT_EV_AG_CPBS_GET_PB_MAXSIZE: //AT+CPBS?
			mbt_ag_ev_getPbSize(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_CPBR_GET_PB_INDEX: //AT+CPBR=?
			mbt_ag_ev_getPbIndex(bt_ev_msg_ptr);
			break;
			
		case BT_EV_AG_CPBR_GET_PB_RECORD://AT+CPBR=start index, end index 
			mbt_ag_ev_getPbRecord(bt_ev_msg_ptr);
			break;
		// LEECHANGHOON 2007-11-26 ��� �߰��ϼ���..
	}
}

#if 0
extern unsigned char Pal_Get_BtAudioSet(void);
#else
extern unsigned char lgoem_DeviceSND_GetOutPath();
#endif
#define SCO_DISCONNECT_TIME (1000)

static void mbt_ag_SCOEventCallBack( uint32 audio_type )
{
#if 0
  unsigned char sndDev = Pal_Get_BtAudioSet();
#else
  unsigned char sndDev = lgoem_DeviceSND_GetOutPath();
#endif

  MBT_WARN("mbt_ag_SCOEventCallBack() type = %d sco_timer_tick = %d, dev=%d",
  	audio_type, sco_timer_tick, sndDev);

/// sy_lee [2009/9/16] sco play error[[
#ifdef FEATURE_AVS_BT_SCO_REWORK
  playback_status = audio_type;
#endif
/// sy_lee [2009/9/16] sco play error[[

  switch ( audio_type )
  {
#ifdef FEATURE_AVS_BT_SCO_REWORK
    case VOC_PLAYBACK_STOP:       /* no audio                   */
	  if (mbt_ag_getaudiostatus() == TRUE &&
	  	vrState == 0)	// JG Kwon. 2009.10.06 do not disconnect SCO if Voice Command is enabled.
      {
		sco_timer_tick = TRUE;		
		rex_set_timer( &sco_timer,SCO_DISCONNECT_TIME );
      }
	  else
	  {
		MBT_WARN("mbt_ag_SCOEventCallBack()  VoiceCommand ignores SCO_DISCONNECT", 0, 0, 0);
	  }
      break;
    case VOC_PLAYBACK_SCO:        /* BT SCO supported audio     */
	  if (mbt_ag_getconstatus() == TRUE &&
		#if 0
	  	sndDev== 2 /*LGOEM_BT_AUDIO_PATH_BT_HEADSET*/)
	  	#else
	  	sndDev == 7 /*DEVSND_OUTPATH_BT_HEADSET*/)
	  	#endif
	  {
        //snd_set_volume(SND_DEVICE_BT_HEADSET, SND_METHOD_VOICE, 6, NULL, NULL); // TEMP
  	    //snd_set_volume(SND_DEVICE_BT_A2DP_HEADSET, SND_METHOD_VOICE, 6, NULL, NULL); // TEMP
		if ( mbt_ag_getaudiostatus()== TRUE)
		{
          if (sco_timer_tick)
          {
            rex_clr_timer( &sco_timer );
			sco_timer_tick = FALSE;
          }
		}
	    else
	    {
	      bt_cmd_ag_audio_connect(mbt_ag_app_id,10000);
			ag_audiostatus	= AG_AUDIO_CONNECTING;
	    }
      }
      break;
    case VOC_PLAYBACK_A2DP:       /* BT non-SCO supported audio */
      break;
    case VOC_PLAYBACK_OTHER:      /* non BT support audio       */
      break;
    case VOC_PLAYBACK_OTHER_STOP: /* non BT support audio       */
      break;      
    case (VOC_PLAYBACK_SCO | VOC_PLAYBACK_A2DP):
	  if (mbt_ag_getconstatus() == TRUE && 
	  	#if 0
	  	sndDev== 2 /*LGOEM_BT_AUDIO_PATH_BT_HEADSET*/)
	  	#else
	  	sndDev == 7 /*DEVSND_OUTPATH_BT_HEADSET*/)
	  	#endif
      {
        //snd_set_volume(SND_DEVICE_BT_HEADSET, SND_METHOD_MIDI, 6, NULL, NULL); // TEMP
        //snd_set_volume(SND_DEVICE_BT_A2DP_HEADSET, SND_METHOD_MIDI, 6, NULL, NULL); // TEMP
  	    
	  	if (mbt_a2dp_is_connected() == FALSE) 
        {
            if ( mbt_ag_getaudiostatus()== TRUE)
			{
			  if (sco_timer_tick)
			  {
				rex_clr_timer( &sco_timer );
				sco_timer_tick = FALSE;
			   }
			 }
			 else
			 {
			  bt_cmd_ag_audio_connect(mbt_ag_app_id,10000);
				ag_audiostatus	= AG_AUDIO_CONNECTING;			  
			 }
        }
	  }
      break;
    case VOC_PLAYBACK_DTMF_START: /* playing DTMF               */
      break;
    case VOC_PLAYBACK_DTMF_STOP:  /* stop playing DTMF          */
      break;
    case VOC_PLAYBACK_DTMF_RINGER_START: /* start playing DTMF ring */
      break;
    case VOC_PLAYBACK_DTMF_RINGER_STOP: /* stop playing DTMF ring */
      break;
#endif /* FEATURE_AVS_BT_SCO_REWORK */
    default:
      MBT_ERR( "AGAuChg - unexpect evt=0x%X", audio_type, 
                 0, 0 );
  }

  return;
}

LOCAL void mbt_ag_SCO_disconnect_timeout_cb( unsigned long unused )
{
  MBT_WARN("mbt_ag_SCO_disconnect_timeout_cb",0,0,0);
  /// sy_lee [2009/9/16] sco play error[[
#ifdef FEATURE_AVS_BT_SCO_REWORK
  if(((playback_status&VOC_PLAYBACK_A2DP ) || (playback_status&VOC_PLAYBACK_SCO ))
      && (ag_audiostatus == AG_AUDIO_CONNECTED)
      && (lgoem_DeviceSND_GetOutPath() == SND_DEVICE_BT_HEADSET)	// ignore�Ǿ��� ��Ȳ�̶�� mono headset�� ��쿡�� ����. JG Kwon. 2010.06.08
  )
    MBT_WARN("Voc playback was played so ignore timeout callback ",0,0,0);		
  else
#endif
/// sy_lee [2009/9/16] sco play error[[
  {
    bt_cmd_ag_audio_disconnect(mbt_ag_app_id);
    ag_audiostatus	= AG_AUDIO_DISCONNECTING;	
  }
  sco_timer_tick = FALSE;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_ag_init(MBT_VOID)
*	Description	: 
*	CallBack EV	: BT_EV_AG_ENABLED
********************************************************************************/
MBT_VOID mbt_ag_init(MBT_VOID)
{
	bt_cmd_status_type	 stat;

	if(mbt_ag_app_id == BT_APP_ID_NULL)
	{
	//CallBack ���
		mbt_ag_app_id = bt_cmd_ec_get_application_id();
		if ( mbt_ag_app_id == BT_APP_ID_NULL )
		{
			MBT_ERR("ERROR bt_cmd_ec_get_application_id : NULL",0,0,0);
			return;
		}
		stat = bt_cmd_ec_reg_event_set_any_app_id( mbt_ag_app_id,
		                                         mbt_ag_EventCallback,
		                                         BT_EC_ES_AUDIO_GATEWAY,
		                                         BT_EV_NULL,
		                                         BT_EV_NULL );
		if ( stat == BT_CS_GN_SUCCESS )
		{
			stat = bt_cmd_ec_register_event_set( mbt_ag_app_id,
		                                     mbt_ag_EventCallback,
		                                     BT_EC_ES_CUSTOM,
		                                     BT_EV_GN_CMD_DONE, 
		                                     BT_EV_GN_CMD_DONE );
		}
		else
		{
			MBT_ERR("ERROR bt_cmd_ec_reg_event_set_any_app_id :0x%x",stat,0,0);
		}
		
		//AG Config
		bt_cmd_ag_config(mbt_ag_app_id, BT_AGIM_LOW_POWER, 0);
		bt_cmd_ag_set_inband_ring(mbt_ag_app_id, FALSE);

		// SCO REWORK		
		snd_set_bt_cb_func( mbt_ag_SCOEventCallBack );

		// Define timer
		sco_timer_tick = FALSE;
		rex_def_timer_ex(&sco_timer,
		  mbt_ag_SCO_disconnect_timeout_cb,
		  SCO_DISCONNECT_TIME );
	}
	else
	{
		MBT_FATAL("##AG Initialize Over time Error. app_id ");
	}
	ag_audiostatus	= AG_AUDIO_INIT;	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
*	CallBack EV	: BT_EV_AG_ENABLED
********************************************************************************/
MBT_VOID mbt_ag_enable(MBT_VOID)
{
	bt_bd_addr_type 	addr;
	bt_cmd_status_type	 stat;

	ag_audiostatus	= AG_AUDIO_INIT;	

	//AG Enable	
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	stat = bt_cmd_ag_enable(mbt_ag_app_id, &addr, BT_AD_HANDSFREE); //NULL_BD_Addr�̸� HS/HF ��� ���.
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_disable(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_ag_disable(mbt_ag_app_id);
	ag_audiostatus	= AG_AUDIO_INIT;	
#endif
}


/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_connect(T_MBT_BDADDR RemoteBDAddr, MBT_SERVICE_ID MBtSvc)
{
#ifdef MBT_EMULATOR
#else
	bt_bd_addr_type 	addr;
	bt_cmd_status_type	 stat;
	bt_audio_device_type dev_type;

	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);

	if(MBtSvc == MBT_SVCUUID_HF_HANDSFREE)
	{
		dev_type = BT_AD_HANDSFREE;
	}
	else if(MBtSvc == MBT_SVCUUID_HEADSET) 
	{
		dev_type = BT_AD_HEADSET;
	}
	else 
		dev_type = BT_AD_HANDSFREE;
	
	stat = bt_cmd_ag_connect( mbt_ag_app_id, &addr, dev_type );
	ag_audiostatus	= AG_AUDIO_INIT;	

#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_disconnect(T_MBT_BDADDR RemoteBDAddr, MBT_SERVICE_ID MBtSvc)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_ag_disconnect(mbt_ag_app_id);
	ag_audiostatus	= AG_AUDIO_INIT;	
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� ������ �����Ѵ�. vocfunc.c - voc_check_bt_ag()
********************************************************************************/
MBT_VOID mbt_ag_audioconnect(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	if (mbt_ag_getaudiostatus())
	{
		if (sco_timer_tick)
		{
		  rex_clr_timer( &sco_timer );
		  sco_timer_tick = FALSE;
		}
	}
	else 
	{
		int j = 0;
		for(j= 0 ;j<5;j++)
		{
			if(ag_audiostatus == AG_AUDIO_DISCONNECTING)
				rex_sleep(50);
			else
				break;
		}
		
		bt_cmd_ag_audio_connect(mbt_ag_app_id,10000);
		ag_audiostatus	= AG_AUDIO_CONNECTING;					
	}
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� ������ �����Ѵ�. vocfunc.c - voc_check_bt_ag()
********************************************************************************/
MBT_VOID mbt_ag_audiodisconnect(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else	
	if (mbt_ag_getaudiostatus())
	{
		T_MBT_A2DP_STATUS* psdc_a2dp_stat = (T_MBT_A2DP_STATUS*)MBT_SDC_GetRecord(MBTSDC_REC_A2DP_STATUS);

		MBT_PI("mbt_ag_audiodisconnect - SDC A2DP ConStatus:%d",
			psdc_a2dp_stat->A2dpConn[0].ConStatus,
			0,0);	// 0 disconnected, 1 disconnecting, 2 canceling, 3 connecting, 4 connected, 5 started, 6 play, 7 paused, 8 stopping

		if(psdc_a2dp_stat->A2dpConn[0].ConStatus == MBT_A2DP_CONSTATUS_CONNECTED)	// mono play�� A2DP ����ȴٸ� SCO disconnect�� delay ���� �ʰ� �ٷ� �ؾ� �ҵ�. JG Kwon. 2009.12.09
		{
			MBT_WARN("mbt_ag_SCO_disconnect_timeout_cb",0,0,0);
			bt_cmd_ag_audio_disconnect(mbt_ag_app_id);
			ag_audiostatus	= AG_AUDIO_DISCONNECTING;
		}
		else
		{
			sco_timer_tick = TRUE;
			rex_set_timer( &sco_timer,SCO_DISCONNECT_TIME );
		}
/*
#if 1
		sco_timer_tick = TRUE;		
		rex_set_timer( &sco_timer,SCO_DISCONNECT_TIME );
#else
		MBT_WARN("mbt_ag_SCO_disconnect_timeout_cb",0,0,0);
		bt_cmd_ag_audio_disconnect(mbt_ag_app_id);
		ag_audiostatus	= AG_AUDIO_DISCONNECTING;					
		rex_sleep(50);
#endif
*/	// old code. blocked. JG Kwon. 2009.12.09
	}
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_ag_getconstatus(MBT_VOID)
{
#ifdef MBT_EMULATOR
	return mbt_sdc_getvalue(MBTSDC_VAL_AG_DEVCON);
#else
	return mbt_sdc_getvalue(MBTSDC_VAL_AG_DEVCON);
#endif	
}


/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_ag_getaudiostatus(MBT_VOID)
{
#ifdef MBT_EMULATOR
	return mbt_sdc_getvalue(MBTSDC_VAL_AG_SCOOPEN);
#else
	return mbt_sdc_getvalue(MBTSDC_VAL_AG_SCOOPEN);
#endif	
}


/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_setconnectable(MBT_BOOL connectable)
{
#ifdef MBT_EMULATOR
#else
		// LEECHANGHOON 2007-12-5 �ʿ俩�� Ȯ�� ����.
#endif
}


/********************************************************************************
*	Prototype	: 
*	Description	: audiopath : TRUE�̸� BT ��ġ�� FALSE�̸� ���� ����� �н� ����
********************************************************************************/
MBT_VOID mbt_ag_setaudiopath(MBT_BOOL audiopath)
{
#ifdef MBT_EMULATOR
#else
		// LEECHANGHOON 2007-12-5 �ʿ俩�� Ȯ�� ����.
#endif
}


/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_setspkvolume(MBT_BYTE Level)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_status_type stat;
	T_MBT_AG_SPKGAIN *sdcAgSpkGain = mbt_sdc_getrecord(MBTSDC_REC_AG_SPKGAIN);

	sdcAgSpkGain->VolumeLevel = Level;
	
	stat = bt_cmd_ag_set_ad_spkr_gain(mbt_ag_app_id, Level);
#endif
}


/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_setmicvolume(MBT_BYTE Level)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_status_type stat;

	// SSS mic volume ������ �ʿ� ����.

	stat = bt_cmd_ag_set_ad_mic_gain(mbt_ag_app_id, Level);	
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: // LEECHANGHOON 2007-12-7
*					QBT�� ��� CM�� BT�� BT���ó��� �ٷ� ������ �Ǿ� �־
*					Call���� event�� �ٷ� �޾Ƽ� ���ÿ� ó���ϴ� ����̴�.
*					�ٷ� ������ �ٸ� BTĨ���� �ٸ����̴�.
*					�׷��� �� API�� ���ݵ� ������ �ȴ�. ���� Stack���� CALL IND���� �����ִ�
*					����������, QBT������ Empty�Լ��θ� �����ϵ��� �Ѵ�.
********************************************************************************/
MBT_VOID mbt_ag_callstatechange(T_MBT_AG_PHONE_CALLSTATE NewState )
{
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord( MBTSDC_REC_AG_STATUS_TYPE );
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord( MBTSDC_REC_AG_INDICATION );

	
	MBT_WARN("mbt_ag_callstatechange() State : current =  %d, new = %d", sdcAgStatus->PhoneCallState, NewState,0);
	
	switch( sdcAgStatus->PhoneCallState )
	{
		case MBT_AG_PHONE_CALL_NONE :
			switch( NewState )
			{
				case MBT_AG_PHONE_CALL_INCOMING :
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_INCOMING;

					// LEECHANGHOON 2007-12-11 QBT�� Incoming�϶� Ring�� �︮���� cmd�� �ش�.
					bt_cmd_ag_ring_audio_device(mbt_ag_app_id, MBT_AG_RING_COUNT, MBT_AG_RING_PERIOD);

					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_IN_CALL_RES, &data );
					break;
				case MBT_AG_PHONE_CALL_ORIGINATING:
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_ORIGINATING;
					
					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_OUT_CALL_ORIG_RES, &data );
					break;
					
				case MBT_AG_PHONE_CALL_ALERTING:
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_ALERTING;
					
					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_OUT_CALL_ALERT_RES, &data);
					break;
			}
			break;
		case MBT_AG_PHONE_CALL_ACTIVE:
			switch( NewState )
			{
				case MBT_AG_PHONE_CALL_HELD :
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_IDLE;
					sdcAgInd->bCallStatus = MBT_AG_CALLSTATUS_END;
					
					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_END_CALL_RES, NULL );
					
				case MBT_AG_PHONE_CALL_NONE :
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_IDLE;
					sdcAgInd->bCallStatus = MBT_AG_CALLSTATUS_END;
					
					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_END_CALL_RES, NULL );
					break;
				case MBT_AG_PHONE_CALL_INCOMING :	// SSS call waiting notification
					// LEECHANGHOON 2007-12-11 QBT�� Incoming�϶� Ring�� �︮���� cmd�� �ش�.
					bt_cmd_ag_ring_audio_device(mbt_ag_app_id, MBT_AG_RING_COUNT, MBT_AG_RING_PERIOD);
					break;
				case MBT_AG_PHONE_CALL_ORIGINATING :
					break;
			}
			break;
		case MBT_AG_PHONE_CALL_INCOMING:
			switch( NewState )
			{
				case MBT_AG_PHONE_CALL_NONE :
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_IDLE;
					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_END_CALL_RES, NULL );
					break;
				case MBT_AG_PHONE_CALL_ACTIVE :
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_IDLE;
					sdcAgInd->bCallStatus = MBT_AG_CALLSTATUS_ACTIVE;
					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_IN_CALL_CONN_RES, NULL );
					break;
				case MBT_AG_PHONE_CALL_HELD :
					//if( btapp_ag_btrh_cmd == BTA_AG_BTRH_SET_HOLD )
					{
						sdcAgStatus->PhoneCallState = NewState;
						sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_IDLE;
						sdcAgInd->bCallStatus = MBT_AG_CALLSTATUS_ACTIVE;
						//btapp_ag_btrh_state = BTA_AG_BTRH_SET_HOLD;

						//btapp_ag_audio_handle = BTA_AG_HANDLE_NONE;

						/* KBNAM : Call list ó�� ? [2007/10/10 17:51:20] */

						//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_IN_CALL_HELD_RES, &data );
					}
					break;
			}
			break;
		case MBT_AG_PHONE_CALL_ORIGINATING:
			switch( NewState )
			{
				case MBT_AG_PHONE_CALL_NONE :
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_IDLE;

					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_END_CALL_RES, &data );
					break;
			#if 0	// SSS outgoing call������ alert�� ���ǹ���					
				case MBT_AG_PHONE_CALL_ALERTING:
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_ALERTING;
					BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_OUT_CALL_ALERT_RES, &data);
					break;
			#endif
				case MBT_AG_PHONE_CALL_ACTIVE :
					break;
			}
			break;
		case MBT_AG_PHONE_CALL_ALERTING:
			switch( NewState )
			{
				case MBT_AG_PHONE_CALL_NONE :
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_IDLE;
					//btapp_ag_audio_handle = BTA_AG_HANDLE_NONE;

					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_END_CALL_RES, &data );
					break;
				case MBT_AG_PHONE_CALL_ACTIVE :
					sdcAgStatus->PhoneCallState = NewState;
					sdcAgInd->bCallSetupStatus = MBT_AG_CALLSETUP_IDLE;
					sdcAgInd->bCallStatus = MBT_AG_CALLSTATUS_ACTIVE;

					//if( btapp_ag_call_handle != BTA_AG_HANDLE_NONE )
					//btapp_ag_audio_handle = btapp_ag_call_handle;

					//BTA_AgResult( BTA_AG_HANDLE_ALL, BTA_AG_OUT_CALL_CONN_RES, &data );
					break;
			}
			break;
		case MBT_AG_PHONE_CALL_HELD:
			break;
		default :
			MBT_WARN("mbt_ag_callstatechange() Unknown State = %d", sdcAgStatus->PhoneCallState,0,0);
			break;
	}
}

/********************************************************************************
*	Prototype	: 
*	Description	:  QBT�� ������ ���ǵ� Stack API�� ����. bt_ag_process_cm_ss_event() ���� �����ϰ� ����.
********************************************************************************/
MBT_VOID mbt_ag_setnetworkstatus(T_MBT_AG_NETSTATE	State)
{
#ifdef MBT_EMULATOR
#else
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord(MBTSDC_REC_AG_INDICATION);

	sdcAgInd->bNetStatus = State;
	
	// LEECHANGHOON 2007-12-5 QBT���� �ʿ俩�� Ȯ������.
	
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_setcid(MBT_CHAR* Num, MBT_BYTE len)
{
#ifdef MBT_EMULATOR
#else
	T_MBT_AG_DIALINFO *sdcAgDialInfo = mbt_sdc_getrecord(MBTSDC_REC_AG_DIALINFO);

	sdcAgDialInfo->DialNum = len;
	memset(sdcAgDialInfo->Digit, 0x0, MBT_MAX_DIALNUM_LEN+1);
	strcpy(sdcAgDialInfo->Digit, Num);
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_ag_setsignalstrength(MBT_BYTE Level)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type stat;
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord(MBTSDC_REC_AG_INDICATION);
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord( MBTSDC_REC_AG_STATUS_TYPE );
	if(!sdcAgStatus->bConection)
	{
		return MBT_FALSE;
	}
	else
	{
		sdcAgInd->bSignalLevel = Level;
		stat = bt_cmd_ag_set_rssi(mbt_ag_app_id, (bt_ag_rssi_level_type)Level);
		return MBT_TRUE;
	}
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� ������ ���ǵ� Stack API�� ����. bt_ag_process_cm_ss_event() ���� �����ϰ� ����.
********************************************************************************/
MBT_BOOL mbt_ag_setroamingstatus(MBT_BYTE Level)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type stat;
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord(MBTSDC_REC_AG_INDICATION);
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord( MBTSDC_REC_AG_STATUS_TYPE );
	if(!sdcAgStatus->bConection)
	{
		return MBT_FALSE;
	}
	sdcAgInd->bRoamingStatus = Level;
	stat = bt_cmd_ag_setRoam(mbt_ag_app_id, Level);
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_ag_setbatterylevel(MBT_BYTE Level)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type stat;
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord(MBTSDC_REC_AG_INDICATION);
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord( MBTSDC_REC_AG_STATUS_TYPE );
	if(!sdcAgStatus->bConection)
	{
		return MBT_FALSE;
	}
	sdcAgInd->bBatteryLevel = Level;
	stat = bt_cmd_ag_set_battchg_ind(mbt_ag_app_id, Level);
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� ������ ���ǵ� Stack API�� ����. bt_ag_process_cm_call_event() ���� �����ϰ� ����.
********************************************************************************/
/* KBNAM : Send [2007/10/10 19:20:45] */
MBT_BOOL mbt_ag_setcallheldstatus(T_MBT_AG_CALL_HELD value)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord(MBTSDC_REC_AG_INDICATION);
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord( MBTSDC_REC_AG_STATUS_TYPE );
	if(!sdcAgStatus->bConection)
	{
		return MBT_FALSE;
	}
	if(sdcAgInd->bHeldStatus != value)
	{
		sdcAgInd->bHeldStatus = value;
	}
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: BT_EV_AG_DEV_COPS_READ �� �ް� ó��. (AT+COPS? : HFP 1.5 4.8��)
********************************************************************************/
/* KBNAM : set�� send�� �ٲٰų�, 
                  Ȥ�� get���� �ٲپ stack���� �ʿ��� �� ���� �����ؼ� ������ �ϴ°� ���? [2007/10/10 13:33:46] */
MBT_BOOL mbt_ag_setoperatorselection(T_MBT_AG_NETMODE Netmode,MBT_BYTE* OpName)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type stat;
	char 	sendData[90] = {0,};

	sprintf((char*)sendData, "+COPS: %d,0,\"%s\"", Netmode, OpName);
	
	stat = bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)sendData);
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� ������ ���ǵ� Stack API�� ����. BT_AG_CMD_CMEE (AT+CMEE)�� �ް� ó��.
*				  HF_DATA.ext_err_enabled = TRUE;�� �����ϰ� ����. 
********************************************************************************/
MBT_BOOL mbt_ag_setextendederror(T_MBT_AG_CME_ERR ErrorCode)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: BT_EV_AG_DEV_CNUM �� �ް� ó��.(AT+CNUM)
********************************************************************************/
MBT_BOOL mbt_ag_setsubscribernumber(MBT_CHAR* Num, MBT_BYTE NumType, MBT_BYTE Len, T_MBT_AG_SERVICE Service,MBT_BOOL FinalFlag)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type stat;
	char 	sendData[90] = {0,};

	sprintf((char*)sendData, "+CNUM: ,\"%s\", %d,,%d", Num, NumType, Service);

	stat = bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)sendData);
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� ������ ���ǵ� Stack API�� ����. bt_ag_cpe_process_call_waiting_act()���� �����ϰ� ����.
********************************************************************************/
MBT_BOOL mbt_ag_setcallwaiting(MBT_CHAR* Num, MBT_BYTE Len)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_sendresponse(MBT_BOOL Response)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_status_type stat;
	char 	sendData[90] = {0,};

	if(Response)
	{
		sendData[0] = 'O';
		sendData[1] = 'K';
	}
	else
	{
		sendData[0] = 'E'; 
		sendData[1] = 'R';
		sendData[2] = 'R';
		sendData[3] = 'O';
		sendData[4] = 'R';
	}
	
	stat = bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)sendData);

#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_ag_setcind(T_MBT_AG_NETSTATE Net, T_MBT_AG_CALLSTATUS CallState, T_MBT_AG_CALLSETUP SetupState, MBT_BYTE SignalLevel, MBT_BYTE RoamingStatus, MBT_BYTE BatteryLevel,T_MBT_AG_CALL_HELD value)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	return MBT_FALSE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: BT_EV_AG_DEV_CLCC�� �ް� ó��.(AT+ CLCC)
********************************************************************************/
MBT_BOOL mbt_ag_setcurrentcalllist(MBT_BYTE Idx,
										T_MBT_AG_CL_DIR Dir,
										T_MBT_AG_CL_STATUS Status,
										T_MBT_AG_CL_MODE Mode,
										T_MBT_AG_CL_MPTY Mprty,
										MBT_CHAR* Num,
										MBT_BYTE NumType,
										MBT_BYTE Len, 
										MBT_BOOL FinalFlag)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type stat;
	uint8 	sendData[90] = {0,};

	sprintf((char*)sendData, "+CLCC: %d,%d,%d,%d,%d,\"%s\",%d", Idx, Dir, Status, Mode, Mprty, Num, NumType );
	stat = bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)sendData);
	BTRPrintf((char*)sendData);
	return MBT_TRUE;
#endif
	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_startvr(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);
	bt_cmd_status_type stat;
	vrState = TRUE;
	//stat = bt_cmd_ag_set_vr_capable(mbt_ag_app_id, TRUE );// LEECHANGHOON 2007-12-7 ��Ȯ�� �ٶ�.
	MBT_PI("mbt_ag_startvr - bSupportBVRA : %d", sdcAgStatus->bSupportBVRA, 0, 0);
	if(sdcAgStatus->bSupportBVRA)
	{
		stat = bt_cmd_ag_update_vr_state(mbt_ag_app_id, TRUE);
		MBT_PI("return value of bt_cmd_ag_update_vr_state : %d", stat, 0, 0);
	}
	else
	{
		mbt_ag_audiodisconnect();
	}
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_stopvr(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	T_MBT_AG_STATUS *sdcAgStatus = mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);
	bt_cmd_status_type stat;
	vrState = FALSE;
	//stat = bt_cmd_ag_set_vr_capable(mbt_ag_app_id, FALSE );// LEECHANGHOON 2007-12-7 ��Ȯ�� �ٶ�.
	MBT_PI("mbt_ag_stopvr - bSupportBVRA : %d", sdcAgStatus->bSupportBVRA, 0, 0);
	if(sdcAgStatus->bSupportBVRA)
	{
		stat = bt_cmd_ag_update_vr_state(mbt_ag_app_id, FALSE);
		MBT_PI("return value of bt_cmd_ag_update_vr_state : %d", stat, 0, 0);
	}
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_ringstart(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_status_type stat;

  if (mbt_ag_getaudiostatus()) {
    ring_alert_ongoing = MBT_TRUE;
  } else {
    ring_alert_ongoing = MBT_FALSE;
	stat = bt_cmd_ag_ring_audio_device(mbt_ag_app_id, MBT_AG_RING_COUNT, MBT_AG_RING_PERIOD);
  }
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_ringstop(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_status_type stat;

  ring_alert_ongoing = MBT_FALSE;
	stat = bt_cmd_ag_ring_audio_device(mbt_ag_app_id, 0, 0);

#endif
}

char *mbt_ag_qbt_pb_str[MBT_AG_PB_DEV_MAX] = {
	"\"ME\"",	/* ME phonebook list                  */
	"\"DC\"",	/* ME Dialed calls list               */
	"\"MC\"",	/* ME missed calls list               */
	"\"RC\"",	/* ME received calls list             */
	"\"SM\"",	/* SIM phonebook list                 */
	"\"FD\"",	/* SIM fix-dialing phonebook list     */
	"\"LD\"",	/* SIM last-dialing phonebook list    */
	"\"MT\"",	/* combined ME and SIM phonebook list */
};

uint8 okResp[ ] = { 'O', 'K', 0 };
uint8 errorResp[ ] = { 'E', 'R', 'R', 'O', 'R', 0 };

/********************************************************************************
*	Prototype	: 
*	Description	: // AT+CPBS=?  
********************************************************************************/
MBT_VOID mbt_ag_sendsupportedpblist(T_MBT_AG_PB_CPBS supportedPbList)
{
#ifdef MBT_EMULATOR
#else
	char str[BT_AG_MAX_SEND_LENGTH+1];
	int i;

	if( supportedPbList.bSupportedNum > 0 && supportedPbList.bSupportedNum < MBT_AG_PB_DEV_MAX )
	{
		strcpy(str, "+CPBS: (");
		strcat(str, mbt_ag_qbt_pb_str[supportedPbList.pbType[0]]);
		if( supportedPbList.bSupportedNum > 1 )
		{
			for( i = 1; i < supportedPbList.bSupportedNum; i++ )
			{
				strcat(str, ",");
				strcat(str, mbt_ag_qbt_pb_str[supportedPbList.pbType[i]]);
			}
		}
		strcat(str, ")");
		BTRPrintf(str);
		bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)str);
		mbt_ag_sendresponse(MBT_TRUE);
	}
	else
	{
		MBT_WARN(" phonebook list is empty bSupportedNum:%d", supportedPbList.bSupportedNum,0,0);
		mbt_ag_sendresponse(MBT_FALSE);
	}
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_sendselectedpbinfo(T_MBT_AG_PB_RETURN result, MBT_SHORT usedRecs, MBT_SHORT totalRecs)
{
#ifdef MBT_EMULATOR
#else

	T_MBT_AG_PB_CPBS* sdcAGcpbs = (T_MBT_AG_PB_CPBS*)mbt_sdc_getrecord(MBTSDC_REC_AG_RXCPBS);
	char str[BT_AG_MAX_SEND_LENGTH+1];
	
	if( result.bResult == MBT_TRUE)
	{
		sprintf(str, "+CPBS: %s,%d,%d", mbt_ag_qbt_pb_str[sdcAGcpbs->selectedPbType], usedRecs, totalRecs);
		BTRPrintf(str);
		bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)str);
		mbt_ag_sendresponse(MBT_TRUE);
	}
	else
	{
		MBT_WARN(" ther is no selectedpbinfo ", 0,0,0);
		sprintf(str, "+CME ERROR: %d", result.bErrorCode);
		mbt_ag_sendresponse(MBT_FALSE);
	}
#endif
}

MBT_VOID mbt_ag_sendpbselectresult(T_MBT_AG_PB_RETURN result)
{
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_sendpbentriesinfo(T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt)
{
#ifdef MBT_EMULATOR
#else
	char str[BT_AG_MAX_SEND_LENGTH+1];
	if(result.bResult == TRUE)
	{
		sprintf(str,"+CPBR: (%d-%d),%d,%d", indexStart, indexEnd, maxLenNum, maxLenTxt);
		BTRPrintf(str);
		bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)str);
		mbt_ag_sendresponse(MBT_TRUE);
	}
	else
	{
		MBT_WARN(" there is no pbentriesinfo ", 0,0,0);
		sprintf(str, "+CME ERROR: %d", result.bErrorCode);
		mbt_ag_sendresponse(MBT_FALSE);
	}
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_sendpbreadresult(T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec,  MBT_BOOL finalEntry)
{
#ifdef MBT_EMULATOR
#else
	//T_MBT_AG_PB_CPBR* sdcAGcpbr = (T_MBT_AG_PB_CPBR*)mbt_sdc_getrecord(MBTSDC_REC_AG_RXCPBR);
	char str[BT_AG_MAX_SEND_LENGTH+1];
	if( result.bResult == TRUE )
	{
		MBT_PI("index:%d, numtype:%d", pbRec->bIndex, pbRec->bType, 0);
		if(finalEntry != TRUE)
		{
			sprintf(str,"+CPBR: %d,\"%s\",%d,\"%s\"", pbRec->bIndex, pbRec->number, pbRec->bType,pbRec->text);
			bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)str);
		}
		else
		{
			sprintf(str,"+CPBR: %d,\"%s\",%d,\"%s\"", pbRec->bIndex, pbRec->number, pbRec->bType,pbRec->text);
			bt_cmd_ag_sendResponse(mbt_ag_app_id, (uint8*)str);
			mbt_ag_sendresponse(MBT_TRUE);
		}
		
		BTRPrintf(str);
	}
	else
	{
		MBT_WARN(" ther is no readresult ", 0,0,0);
		sprintf(str, "+CME ERROR: %d", result.bErrorCode);
		mbt_ag_sendresponse(MBT_FALSE);		
	}

#endif
}

MBT_VOID mbt_ag_sendpbfindentriesinfo(T_MBT_AG_PB_RETURN result, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt)
{
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_sendpbfindresult(T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec, MBT_BOOL finalEntry)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_ag_sendpbwriteinfo(T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxlenNum, MBT_SHORT typeStart, MBT_SHORT typeEnd, MBT_SHORT maxlenTxt)
{
#ifdef MBT_EMULATOR
#else
#endif
}

MBT_VOID mbt_ag_sendpbwriteresult(T_MBT_AG_PB_RETURN result)
{
}

MBT_VOID mbt_ag_setcallstatus(T_MBT_AG_CALLSTATUS CurrentStatus)
{
#ifdef FEATURE_BTEM
	tBTA_AG_RES_DATA data;
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord(MBTSDC_REC_AG_INDICATION);

	MBT_WARN("mbt_ag_setcallstatus  CurrentStatus =  %d", CurrentStatus, 0,0);

	if(sdcAgInd->bCallStatus != CurrentStatus)
	{
		sdcAgInd->bCallStatus = CurrentStatus;
		data.ind.id = BTA_AG_IND_CALL;
		data.ind.value = CurrentStatus;
	}
	BTA_AgResult(btapp_ag_handle, BTA_AG_CALL_IND_RES, &data);
#endif
}

MBT_VOID mbt_ag_setcallsetup(T_MBT_AG_CALLSETUP CurrentCallSetup)
{
#ifdef FEATURE_BTEM

	tBTA_AG_RES_DATA data;
	T_MBT_AG_INDICATION *sdcAgInd = mbt_sdc_getrecord(MBTSDC_REC_AG_INDICATION);

	MBT_WARN("mbt_ag_setcallsetup  CurrentStatus =  %d", CurrentCallSetup, 0,0);

	if(sdcAgInd->bCallSetupStatus!= CurrentCallSetup)
	{
		sdcAgInd->bCallSetupStatus = CurrentCallSetup;
		data.ind.id = BTA_AG_IND_CALLSETUP;
		data.ind.value = CurrentCallSetup;
	}
	BTA_AgResult(btapp_ag_handle, BTA_AG_CALL_SETUP_RES, &data);
#endif
}
MBT_VOID mbt_ag_setcgm(MBT_CHAR* manufacturerid, MBT_CHAR* modelid)
{
#ifdef FEATURE_BTEM

	T_MBT_AG_CGM_ID *sdcAgCgm = mbt_sdc_getrecord(MBTSDC_REC_AG_CGM);

	if( manufacturerid != NULL )
		strncpy(sdcAgCgm->manufacturerID, manufacturerid, MBT_AG_CGM_LEN);

	if( modelid != NULL )
		strncpy(sdcAgCgm->modelID, modelid, MBT_AG_CGM_LEN);
#endif

}

MBT_VOID mbt_ag_setcscs(T_MBT_AG_CSCS * AgCSList)
{
#ifdef FEATURE_BTEM

	T_MBT_AG_CSCS *sdcAgCscs = mbt_sdc_getrecord(MBTSDC_REC_AG_CSCS);

	memcpy( (void *)sdcAgCscs, (void *)AgCSList, sizeof(T_MBT_AG_CSCS));
#endif
}

