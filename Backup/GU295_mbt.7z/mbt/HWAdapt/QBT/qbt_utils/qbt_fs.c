/*------------------------------------------------------------------------------
 * Copyright (c) 2006 LG Electronics, Seoul, Republic of KOREA.
 * Any reproduction without written permission is prohibited by law.
 *------------------------------------------------------------------------------
 * Produced by LG Electronics Mobile Communications Company
 *------------------------------------------------------------------------------
 * Component: OPP - included client and server
 * File     : System_BT_Utils.c
 * Project  : QBT
 * Date     : April 4th, 2006
 * Author   : YT Kim (bestyt@lge.com)
 *------------------------------------------------------------------------------
 * Description:
 *  Implementation Code of OPP
 *------------------------------------------------------------------------------
 * History :
 *       DATE          NAME      VERSION      COMMENTS
 *       20060403    YT KIM    0.5               Created.
 *       20060530    YT KIM    0.7               change the function from efs to fs apis to access external memory
 *	   20071201    DHLEE     0.8               MBT Porting (winapi@lge.com)
 *------------------------------------------------------------------------------
 */

#include "comdef.h"
#include "oi_stddefs.h"

#include "bt.h"
#include "btpf.h"
#include "btag.h"
#include "btmsg.h"
#include "fs_public.h"
#include "fs_parms.h"
#include "fs_sys_types.h"
#include "fs_namei.h"

#include <string.h>
#include <stdio.h>
#include <stdarg.h>

#include "MBTType.h"
#include "qbt_fs.h"
#include "qbt_lang.h"


/*-------------------------------------------------------------------------------------------------
 * Definitions
 *-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
 * Macro definitions 
 *-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
 *   Type definitions
 *-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
 *   Function prototypes
 *-------------------------------------------------------------------------------------------------*/

/*-------------------------------------------------------------------------------------------------
 *   Static data
 *-------------------------------------------------------------------------------------------------*/


/*===========================================================================

FUNCTION
  qbt_file_make_full_path    
   
DESCRIPTION
  make full path name with dir name and file name.
  input string is UTF8 and result string is local char.
   
===========================================================================*/
MBT_SHORT qbt_file_make_full_path(
	MBT_CHAR *utf8_dir,
	MBT_CHAR *utf8_file,
	MBT_CHAR *local_full,
	MBT_SHORT buf_len)
{
	MBT_SHORT filename_len;
	filename_len = strlen(utf8_dir);
	if ( utf8_dir[filename_len-1] != '/' )
		utf8_dir[filename_len++] = '/';
	utf8_dir[filename_len] = 0x00;
	/*
	filename_len = mbt_utf8_to_local(utf8_dir, strlen(utf8_dir),
				local_full, buf_len, '_');
	if ( local_full[filename_len-1] != '/' )
		local_full[filename_len++] = '/';
	filename_len += mbt_utf8_to_local(utf8_file, strlen(utf8_file),
				&local_full[filename_len], buf_len-filename_len, '_');
	*/
	sprintf(local_full, "%s%s", utf8_dir, utf8_file);
	return filename_len;
}

MBT_SHORT qbt_file_make_full_path_ucs2(
	MBT_CHAR *utf8_dir,
	MBT_SHORT *ucs2_file,
	MBT_SHORT ucs2_len,
	MBT_CHAR *local_full,
	MBT_SHORT buf_len)
{
	extern int UniLib_UCS2ToUTF8(unsigned short* ucs2_string, char *utf8 );
	MBT_SHORT filename_len;
	char utf8_file[MBT_MAX_FILE_NAME_LEN];
	char tempStr[]={'%','s','/','%','s',0x00};
	UniLib_UCS2ToUTF8(ucs2_file, utf8_file);
	filename_len = strlen(utf8_dir);
	if ( utf8_dir[filename_len-1] != '/' )
	{
		sprintf(local_full, tempStr, utf8_dir, utf8_file);
	}
	else
	{
		sprintf(local_full, "%s%s", utf8_dir, utf8_file);
	}
	
	return strlen(local_full);
}

/*===========================================================================

FUNCTION
  opp_open    
   
DESCRIPTION
  Opens an object for reading.
   
===========================================================================*/
bt_cmd_status_type qbt_file_open_read(
	fs_handle_type* 	handle_ptr,
	MBT_UINT* 		filesize_ptr,
	MBT_CHAR*		filename)
{
  	bt_cmd_status_type    	status;
	fs_rsp_msg_type  		fs_rsp_msg;

	fs_open( filename, FS_OA_READONLY, 0, 0, &fs_rsp_msg );
	if ( fs_rsp_msg.open.status == FS_OKAY_S )
	{
		MBT_PI("[UTIL] fs_open success fd(%d)", fs_rsp_msg.open.handle, 0, 0);
		*handle_ptr = fs_rsp_msg.open.handle;
	}
	else
	{
		int i;
		MBT_ERR( "[UTIL] fs_open failed status(%d)", fs_rsp_msg.open.status, 0, 0 );
		for(i=0; i<strlen(filename); i++)
			MBT_WARN("mbt_opp_open_write   file name[%d]:%c (%02X)", i, filename[i], filename[i]);
		status = OI_FAIL;
		*handle_ptr = NULL;
		*filesize_ptr = 0;
		return status;
	}

	fs_file_size( filename, NULL, &fs_rsp_msg );
	if ( fs_rsp_msg.file_size.status == FS_OKAY_S )
	{
		status = OI_OK;
		*filesize_ptr = fs_rsp_msg.file_size.size;
	}
	else
	{
		MBT_ERR("[UTIL] fs_file_size failed error(%d)", fs_rsp_msg.file_size.status, 0, 0);
		status = OI_FAIL;
		*filesize_ptr = 0;
	}

	return( status );
}

/*===========================================================================

FUNCTION
  opp_open_write    
   
DESCRIPTION
  Opens an object for writing.
   
===========================================================================*/
bt_cmd_status_type qbt_file_open_write( 
	fs_handle_type* 	handle_ptr,
	MBT_CHAR*		filename)
{
  	bt_cmd_status_type status;
	fs_rsp_msg_type     resp;
	fs_open_xparms_type    options;
	options.create.cleanup_option = FS_OC_CLOSE;
	options.create.buffering_option = FS_OB_ALLOW;
	options.create.attribute_mask = FS_FA_UNRESTRICTED;
	
	fs_open( filename, FS_OA_CREATE, &options, NULL, &resp);
	if (resp.open.status == FS_FILE_ALREADY_EXISTS_S)
	{
		options.truncate.position = 0;
		fs_open(filename, FS_OA_TRUNCATE,&options,NULL,&resp);
	}

	if (resp.open.status == FS_OKAY_S)
	{
		MBT_PI("[UTIL] fs_open success fd(%d)", resp.open.handle, 0, 0);
		status = OI_OK;
		*handle_ptr = resp.open.handle;
	}
	else
	{
		int i;
		MBT_ERR("[UTIL] fs_open failed error(%d)", resp.open.status, 0, 0);
		for(i=0; i<strlen(filename); i++)
			MBT_WARN("mbt_opp_open_write   file name[%d]:%c (%02X)", i, filename[i], filename[i]);
		status = OI_FAIL;
		*handle_ptr = NULL;
	}

	return(status);
}


/*===========================================================================

FUNCTION
  opp_read    
   
DESCRIPTION
  Reads from an object.
   
===========================================================================*/
bt_cmd_status_type qbt_file_read( 
	fs_handle_type	fs_handle,
  	uint16			max_read,
  	uint32*           	to_read,
  	byte*	       	data_ptr,
  	uint32			file_size)
{
	bt_cmd_status_type status; 
	int offset;//, ret;
	fs_rsp_msg_type  resp;

	MBT_PI("[UTIL] file_read : handle(%d) file_size(%d)", fs_handle, file_size, 0);
	
	fs_tell(fs_handle, 0, &resp); 
	if (resp.tell.status == FS_OKAY_S)
	{
		MBT_PI("[UTIL] fs_tell offset(%d)", resp.tell.position, 0, 0);
		offset = resp.tell.position;
	}
	else
	{
		MBT_ERR("[UTIL] Virtual object system : fs_tell error(%d)", resp.tell.status, 0, 0);
		status = OI_FAIL;
		*to_read = 0;
		return status;
	}
	
	/* 
	 * How many bytes can we read?
	 */
	*to_read = (uint32)(file_size - offset);
	if (*to_read >= max_read)
	{
		*to_read = max_read;
		status = OI_OK;
	}
	else
	{
		status = OI_STATUS_END_OF_FILE;
	}

	if ( *to_read > 0 )
	{
		fs_read(fs_handle, (void*)data_ptr, *to_read, 0, &resp);
		if (resp.read.status != FS_OKAY_S)
		{
			BT_MSG_HIGH("[UTIL] Virtual object system : fs_read error(%d)", resp.read.status, 0, 0);
			*to_read = 0;
			status = OI_FAIL;
		}
		else
		{
			BT_MSG_HIGH("[UTIL] Virtual object system : Read %d bytes", resp.read.count, 0, 0);
			*to_read = resp.read.count;
		}
	}

  	return(status);
}             


/*===========================================================================

FUNCTION
  opp_write    
   
DESCRIPTION
  Writes to an object.
   
===========================================================================*/
bt_cmd_status_type qbt_file_write(
  fs_handle_type 	fs_handle,
  byte*                 	buf_ptr,
  uint16               	buf_len )
{
	bt_cmd_status_type status = OI_OK;
	fs_rsp_msg_type     resp;

	MBT_PI("[UTIL] file_write : handle(%d) data_len:%d", (int)fs_handle, buf_len, 0);

	if ( buf_len > 0 )
	{
		fs_write( fs_handle, (void*)buf_ptr, buf_len, NULL, &resp);
		if (resp.write.status == FS_OKAY_S)
		{
			MBT_PI( "[UTIL] Virtual object system: Written %d bytes", resp.write.count, 0, 0);
		}
		else
		{
			MBT_ERR( "[UTIL] Virtual object system: Write error(%d)", resp.write.status, 0, 0);
			status = OI_FAIL;
		}
	}

	return(status);
}


/*===========================================================================

FUNCTION
  qbt_file_remove 
   
DESCRIPTION
  Deletes an object.
   
===========================================================================*/
bt_cmd_status_type qbt_file_remove(	
	MBT_CHAR*				filename)
{

  	bt_cmd_status_type status;
//  	int /*ret,*/len;
//	char	buf[FS_FILENAME_MAX_LENGTH_P];
	fs_rsp_msg_type     resp;


	if (*filename == NULL) {
  		MBT_ERR("[UTIL] file_delete : name_ptr is NULL", 0, 0, 0);
		status = OI_FAIL;
		return status;
	}
	fs_remove (filename, NULL, &resp);
	if (resp.rmfile.status != FS_OKAY_S) 
	{
#if defined (ALLOW_CREATE_DELETE_FOLDER)
  		fs_rmdir(filename, NULL, &resp);
		if (resp.rmdir.status != FS_OKAY_S) {
			BT_MSG_HIGH("[UTIL] fs_remove fail and fs_rmdir fail", 0, 0, 0);
			return OI_FAIL;
		} else {
			BT_MSG_HIGH("[UTIL] fs_redir success", 0, 0, 0);
		}
		return OI_OK;
#else
		MBT_ERR("[UTIL] remove fail status:%d ", resp.rmfile.status, 0, 0);
		return OI_FAIL;
#endif
	} 
	else 
	{
		MBT_PI("[UTIL] fs_remove success\n", 0, 0, 0);
	}

	return OI_OK;
	
}

bt_cmd_status_type qbt_file_close(fs_handle_type fd)
{ 
	//int ret;
	fs_rsp_msg_type     resp;
	
	if (fd == NULL) {
		BT_MSG_HIGH("[UTIL] already closed", 0, 0, 0);
		return OI_OK;
	}

#if 0
	ret = efs_close( (int)fd );
	if (ret == -1) {
		BT_MSG_HIGH( "[UTIL] Virtual object system: Close obj on error %x", ret, 0, 0);
  	} else {
  		BT_MSG_HIGH( "[UTIL] Virtual object system: obj closed", 0, 0, 0);
	}	
#else
    fs_close( (int)fd, 0, &resp );
	if (resp.close.status != FS_OKAY_S) {
		MBT_PI( "[UTIL] Virtual object system: Close obj on error %d", resp.close.status, 0, 0);
	} else {
  		MBT_PI( "[UTIL] Virtual object system: obj closed", 0, 0, 0);
	}
#endif
  	return OI_OK;
}

