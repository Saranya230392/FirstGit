/*=========================================================================

FILE:      SYSTEM_BT_L2.c

Copyright (c) 2006       by LGE All Rights Reserved.

when     who         what, where, why
------   -----     ----------------------------------------------------------
060714   chosw      L2CAP Created
070319   neohacz   L2CAP Updated
------   -----     ----------------------------------------------------------
=========================================================================*/

#include "comdef.h"		 
// LEECHANGHOON 2008-1-17 delete under 1 line
//#include "System_BT.h"	

#if defined(FEATURE_SYSTEM_BT_JSR82)
#include "bt.h"
#include "bti.h"
#include "btsd.h"
#ifndef FEATURE_LGE_DEVICE
#include "btbb.h"
#endif
//#include "msg.h"	
#include "btmsg.h"

//#include "..\..\..\..\..\PAL\PhonePal\include\PalDef_OemBt.h"
#include "PalDef_OemBt.h"
#include "qbt_bt_l2.h"	

#include "mbt_sdc.h"
#include "mbt_evhandler.h"
#include "../include/mbt_internal_func.h"
// LEECHANGHOON 2008-1-17 delete under 4 line
//#include "System_BT_Var.h"	
//#include "System_BT_DB.h"	
//#include "System_BT_PDK_Handler.h"	
//#include "System_BT_JSR82.h"	 // 2006-11-10

//==========================================================================
//   Macro definitions
//==========================================================================

#define BT_MSG_LAYER  BT_MSG_L2
#include "btmsg.h"

/* How often L2 polls to see if a stream is writable */
#define BT_L2_FLOW_POLL_MS 100

#if 1	// 2006-09-19 LX550 Sync
//TODO - pre-defined values
#define	L2CAP_REGISTER_VERSION	0x0100
#define	L2CAP_SCN 				BT_RC_SCN_NOT_SPECIFIED

#define	MAX_L2CAP_SERVICE		5
#define	MAX_L2CAP_CONNECTION	5
#define	MAX_L2CAP_BUFFER_SIZE	1000
#define	MAX_JL2CAP_RING_BUF_LEN	3000
#endif

//==========================================================================
//   Function prototypes
//==========================================================================

System_BT_L2obj_t* System_BT_L2_CreateMe( void );
boolean System_BT_L2_InsertHandle( System_BT_L2obj_t* pMe, uint8 ParentHandle, uint8 Handle );
uint8 System_BT_L2_FindServerHandlebyMe(System_BT_L2obj_t* pMe);
System_BT_L2obj_t* System_BT_L2_FindMeAndHandleMgrbyHandle(uint8 handle, int* index);
System_BT_L2obj_t* System_BT_L2_FindMebyHandle(uint8 handle);
System_BT_L2obj_Handle_t* System_BT_L2_FindHandleMgrbyHandle(uint8 handle);
System_BT_L2obj_Handle_t* System_BT_L2_FindHandleMgrbyMeAndHandle(System_BT_L2obj_t* pMe, uint8 handle);
System_BT_L2obj_Handle_t* System_BT_L2_FindHandleMgrbyMeAndCID(System_BT_L2obj_t* pMe, uint16 wCid);
System_BT_L2obj_Handle_t* System_BT_L2_FindHandleMgrbyCID( uint16 wCid );
int System_BT_L2_FindIndexbyHandle(System_BT_L2obj_t* pMe, uint8 handle);
uint8 System_BT_L2_FindHandlebyCID( uint16 wCid );
int System_BT_L2_IsFirstCreateMe( void );
int System_BT_L2_DeleteHandle(System_BT_L2obj_t* pMe, uint8 handle);
int System_BT_L2_CheckMeUsed( System_BT_L2obj_t* pMe );
int System_BT_L2_ReleaseMe(System_BT_L2obj_t* pMe);

static int System_BT_L2_ConvertCmdStatus( bt_cmd_status_type cmd_status );
static void  System_BT_L2_EventCallback( struct bt_ev_msg_struct* bt_ev_msg_ptr );
static System_BT_L2obj_t* System_BT_L2_FindMe_byAID(bt_app_id_type appId);
static System_BT_L2obj_t* System_BT_L2_FindMe_byPSM(bt_app_id_type appId);

//==========================================================================
//   Static data
//==========================================================================

static System_BT_L2obj_t  	gMe[8];		
static rex_crit_sect_type 	gsOEMBTExtL2_cs;

static BTL2Opened			pN_L2Open;
static BTL2Connected		pN_L2Connect;			
static BTL2ConnectFailed	pN_L2ConnectFailded;	
static BTL2Reconfigured		pN_L2Reconfigured;		
static BTL2Disconnected		pN_L2Disconnected;		
static System_BT_L2Accept_t  gL2Accept[8];

//static uint8 gAcceptHandle = 0;
uint8 pL2_OpenHandle = 0; // LEECHANGHOON 2008-1-18 L2CAP OpenServer�ÿ� ����� Handle��.

static bt_ev_l2_disconnected_type    ev_l2_disc_pending;
static uint8 bL2caDisconnPending = FALSE;
//==========================================================================
//   Public Funtions
//==========================================================================

/*===========================================================================

Function:  System_BT_L2_Init()

Description:
   This is called from the upper layer when an app tries to create an instance

Parameters:
   uint8 handle: unique value to parent structure allocated by upper layer

Return Value:

Componts:      None

Side Effects: 

===========================================================================*/
int System_BT_L2_Init(
	uint8 handle
)
{
  System_BT_L2obj_t* pMe;
  int i,j;
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__"####  handle:%d", handle, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__" �ߡ� gL2Accept table initialize. �ߡ� ", 0, 0, 0);
  for(i=0;i<8;i++)
  {
  	gL2Accept[i].bUsed = FALSE;
	gL2Accept[i].handle = 0;
	for(j=0;j<2;j++)
	{
		gL2Accept[i].gL2AcceptHandle[j] = 0;
	}
  }
 

  
  pMe = System_BT_L2_CreateMe();
  if(pMe == NULL)
  {
    BT_MSG_HIGH(__func__" �ߡ� L2CAP Create pMe Error!�ߡ�",  0, 0, 0);
    return FALSE;
  }

  // init BT layer
  pMe->appId = bt_cmd_ec_get_app_id_and_register(System_BT_L2_EventCallback);
  BT_MSG_HIGH(__func__" �ߡ� L2CAP APP ID [0x%x] �ߡ�", pMe->appId, 0, 0);
  
  if ( pMe->appId == BT_APP_ID_NULL )
  {
    System_BT_L2_ReleaseMe(pMe);
    return FALSE;
  }

  if( !System_BT_L2_InsertHandle(pMe, 0, handle) )
  {
    System_BT_L2_ReleaseMe(pMe);
    return FALSE;
  }
  
  if(System_BT_L2_IsFirstCreateMe())
  {
    rex_init_crit_sect( &gsOEMBTExtL2_cs );
  }

  // Default values for a connection:
  pMe->sConfigInfo.psm = BT_L2_PSM_INVALID;
  pMe->sConfigInfo.in_flush_to = BT_L2_DEFAULT_FLUSH_TIMEOUT;
  pMe->sConfigInfo.in_mtu = BT_L2_DEFAULT_MTU;
  pMe->sConfigInfo.out_mtu = BT_L2_DEFAULT_MTU;
  pMe->sConfigInfo.in_qos = BT_QOS_BEST_EFFORT;
  pMe->sConfigInfo.token_rate = BT_L2_DEFAULT_TOKEN_RATE;
  pMe->sConfigInfo.token_bucket_size = BT_L2_DEFAULT_TOKEN_BUCKET_SIZE;
  pMe->sConfigInfo.peak_bandwidth = BT_L2_DEFAULT_PEAK_BANDWIDTH;
  pMe->sConfigInfo.latency = BT_L2_DEFAULT_LATENCY;
  pMe->sConfigInfo.delay_variation = BT_L2_DEFAULT_DELAY_VARIATION;
  
  return TRUE;
}


uint32 System_BT_L2_Release( 
	uint8 handle
)
{
  System_BT_L2obj_t*  pMe;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_L2_FindMebyHandle(handle);
  if( pMe == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pMe[0x%x] == NULL �ߡ�", pMe, 0, 0);
    return FALSE;
  }
  
  if( !System_BT_L2_DeleteHandle(pMe, handle) )
  {
    return FALSE;
  }
  
  if( !System_BT_L2_CheckMeUsed(pMe) )
  {
    /* This is the last L2 object using this App ID */
    (void)bt_cmd_rm_set_connectable( pMe->appId, FALSE, BT_RM_AVP_AUTOMATIC );
    bt_cmd_ec_free_application_id( pMe->appId );
    System_BT_L2_ReleaseMe( pMe );
  }

  return TRUE;
}

uint32 System_BT_L2_ReleaseAll(void)
{
  System_BT_L2obj_t*  pMe;
  int i, j;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__" �ߡ� gL2Accept table initialize. �ߡ� ", 0, 0, 0);  
  for(i=0;i<8;i++)
  {
  	gL2Accept[i].bUsed = FALSE;
	gL2Accept[i].handle = 0;
	for(j=0;j<2;j++)
	{
		gL2Accept[i].gL2AcceptHandle[j] = 0;
	}
  }

  for(i=0; i<8; i++)
  {
      if(gMe[i].bUsed == TRUE) 
      	{
		BT_MSG_HIGH(" [System_BT_L2_ReleaseAll] pMe[%d] Release",i, 0, 0);
	  	pMe = &(gMe[i]);
		for(j=0; j<3; j++)
		{
			BT_MSG_HIGH(" [System_BT_L2_ReleaseAll] pMe->HandleMgr[%d].nHandle:%d",j, pMe->HandleMgr[j].nHandle, 0);
			if(pMe->HandleMgr[j].nHandle != 0)
			{
				System_BT_L2_Disconnect(pMe->HandleMgr[j].nHandle);
			}
		}
      	}
  }
  return TRUE;
}


int32 System_BT_L2_Read( 
	uint8 handle, 
	void* buffer, 
	uint32 bytes 
)
{
  System_BT_L2obj_Handle_t *pHandleMgr;
  int32 rv = 0;
  int32 dsm_len = -1;
  
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  
  pHandleMgr = System_BT_L2_FindHandleMgrbyHandle( handle );
  if( pHandleMgr == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pHandleMgr == NULL �ߡ�", 0, 0, 0);
    rv = PDK_L2_ERROR;
  }
  else  
  {
    BT_MSG_HIGH(" �ߡ� pHandleMgr->pRcvbuf  0x%x �ߡ�",pHandleMgr->pRcvbuf, 0, 0);
    rex_enter_crit_sect( &gsOEMBTExtL2_cs );
    if( pHandleMgr->pRcvbuf )
    {
      rv = dsm_pullup(&pHandleMgr->pRcvbuf, buffer, (uint16)bytes);
    }
    else
    {
      // No data to read
      rv = PDK_L2_WOULDBLOCK;
    }
    rex_leave_crit_sect( &gsOEMBTExtL2_cs );
  }

  rex_enter_crit_sect( &gsOEMBTExtL2_cs );
  if( pHandleMgr->pRcvbuf )
  {
    dsm_len = dsm_length_packet(pHandleMgr->pRcvbuf);
  }
  rex_leave_crit_sect( &gsOEMBTExtL2_cs );  

  if (/*dsm_len == 0 &&*/ bL2caDisconnPending == TRUE) 
  {
    bL2caDisconnPending = FALSE;
    System_BT_L2_Handle_Ev_Disc(&ev_l2_disc_pending);
  }
  
  BT_MSG_HIGH( __func__" | length[%d] rv[%d]", bytes, rv, 0);	
  
  return rv;
}


int System_BT_L2_Readable( 
   uint8 handle
)	
{
  System_BT_L2obj_Handle_t *pHandleMgr;
  int32 dsm_len = 0;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  
  pHandleMgr = System_BT_L2_FindHandleMgrbyHandle( handle );
  if( pHandleMgr == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pHandleMgr == NULL �ߡ�", 0, 0, 0);
    return FALSE;
  }

  dsm_len = dsm_length_packet(pHandleMgr->pRcvbuf);

  BT_MSG_HIGH( __func__"-> pHandleMgr->pRcvbuf[0x%x], dsm_len %d", pHandleMgr->pRcvbuf, dsm_len, 0);  
  //if( pHandleMgr->pRcvbuf )
  //{
  //	return TRUE;
  //}
  //return FALSE;
  return dsm_len; 
}

void System_BT_L2_Cancel( 
  uint8 handle, 
  void* pUser 
)
{
  System_BT_L2obj_t *pMe;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
   
  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pMe[0x%x] == NULL �ߡ�", pMe, 0, 0);
    return;
  }

}


int System_BT_L2_Register( 
  uint8 handle,
  uint32 PSM 
)
{
  System_BT_L2obj_t *pMe;
  int rv;
  bt_cmd_status_type status;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
  	BT_MSG_HIGH(" �ߡ� pMe[0x%x] == NULL �ߡ�", pMe, 0, 0);
    return FALSE;
  }
  
  BT_MSG_HIGH( "BT OEM L2 CMD RX: Register. PSM %x",
             PSM, 0, 0 );

  pMe->sConfigInfo.psm = PSM;
  status = bt_cmd_l2_register( pMe->appId, PSM );
  rv = System_BT_L2_ConvertCmdStatus( status /*pMe->CmdDoneStatus*/ );
  
  BT_MSG_HIGH( "BT OEM L2 CMD RX: Register. rv %x", rv, 0, 0 );
  if( rv == PDK_L2_ERR_NONE )
  {
    status = bt_cmd_rm_set_connectable( pMe->appId, TRUE, BT_RM_AVP_AUTOMATIC );
    rv = System_BT_L2_ConvertCmdStatus( status );
  }

  return rv;
}

int System_BT_L2_Deregister( 
  uint8 handle
)
{
  System_BT_L2obj_t *pMe;
  int rv;
  bt_cmd_status_type status;
  
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pMe == NULL �ߡ�", 0, 0, 0);
    return PDK_L2_ERR_BAD_PARAMS;
  }  

  BT_MSG_HIGH( "BT OEM L2 CMD RX: Deregister. PSM %x", pMe->sConfigInfo.psm, 0, 0 );
  
  status = bt_cmd_l2_unregister( pMe->appId, pMe->sConfigInfo.psm );
  rv = System_BT_L2_ConvertCmdStatus( status /*pMe->CmdDoneStatus*/ );

  status = bt_cmd_rm_set_connectable( pMe->appId, FALSE, BT_RM_AVP_AUTOMATIC );
  if( rv == PDK_L2_ERR_NONE )
  {
    rv = System_BT_L2_ConvertCmdStatus( status );
  }

  return rv;
}


int System_BT_L2_SetParams( 
	uint8 handle,
	uint16 proto_id, 
	const BTL2ConfigInfo* info 
)
{
  System_BT_L2obj_t *pMe;
  System_BT_L2obj_Handle_t *pHandleMgr;
  int rv;
  bt_cmd_status_type status;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);

  BT_MSG_HIGH( "handle(0x%x), proto_id - psm(0x%x)", handle, proto_id, 0);
  
  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pMe == NULL �ߡ�", 0, 0, 0);
    return PDK_L2_ERR_BAD_PARAMS;
  }  

  pHandleMgr = System_BT_L2_FindHandleMgrbyMeAndHandle( pMe, handle );
  if( pHandleMgr == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pHandleMgr == NULL �ߡ�", 0, 0, 0);
    return PDK_L2_UNSPECIFIED_ERROR;
  }
  
  rex_enter_crit_sect( &gsOEMBTExtL2_cs );
// LEECHANGHOON 2008-3-10 MBT���� [S] L2CAP Connect�ÿ� pSamePSM ���ǿ� ���� ���� �ʾ� Fail���� ������ ����.
  //pMe->sConfigInfo.psm				 = proto_id;	// LEECHANGHOON 2008-1-18 L2CAP OpenServer�Ŀ� PSM������ ����.
// LEECHANGHOON 2008-3-10 MBT����[E]
  pMe->sConfigInfo.in_flush_to       = info->in_flush_to;
  pMe->sConfigInfo.in_mtu            = info->in_mtu;
  pMe->sConfigInfo.in_qos            = info->in_qos;
  pMe->sConfigInfo.token_rate        = info->token_rate;
  pMe->sConfigInfo.token_bucket_size = info->token_bucket_size;
  pMe->sConfigInfo.peak_bandwidth    = info->peak_bandwidth;
  pMe->sConfigInfo.latency           = info->latency;
  pMe->sConfigInfo.delay_variation   = info->delay_variation;

  status = bt_cmd_l2_set_params( pMe->appId,
                                 pHandleMgr->cid,
                                 proto_id,
                                 info->in_flush_to,
                                 info->in_mtu,
                                 info->in_qos,
                                 info->token_rate,
                                 info->token_bucket_size,
                                 info->peak_bandwidth,
                                 info->latency,
                                 info->delay_variation );
  rex_leave_crit_sect( &gsOEMBTExtL2_cs );

  rv = System_BT_L2_ConvertCmdStatus( status /*pMe->CmdDoneStatus*/ );

  BT_MSG_HIGH( __func__" status[0x%x] rv[0x%x] ", status, rv, 0);
	
  return rv;
}


int System_BT_L2_Connect( 
	uint8 handle,
	uint16 proto_id, 
	const BTBDAddr* pBDAddr )
{
  System_BT_L2obj_t *pMe;
  System_BT_L2obj_t *pSamePSM;
  System_BT_L2obj_Handle_t *pHandleMgr;
  int rv;
  bt_cmd_status_type status;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  
  pHandleMgr = System_BT_L2_FindHandleMgrbyHandle( handle );
  if( pHandleMgr == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pHandleMgr == NULL �ߡ�", 0, 0, 0);
    return FALSE;
  }  

  BT_MSG_HIGH( __func__" cid[0x%x]", pHandleMgr->cid, 0, 0);

  if( pHandleMgr->cid != BT_L2_NULL_CID )
  {
    BT_MSG_HIGH( __func__" PDK_L2_ALREADY_CONNECTED  cid[0x%x]", pHandleMgr->cid, 0, 0);
    rv = PDK_L2_ALREADY_CONNECTED;
  }
  else
  {
    BT_MSG_HIGH( "     INPUT psm[0x%x]", proto_id, 0, 0);	

    // 2007-03-15 : psm = 0x1001�� OpenServer �� OpenClient�ϰ� 
    // �ٽ� psm = 0x1001�� Connect �� �� ���� ��ƾ�� Ÿ�� �Ǿ� Error �߻�
    pMe = System_BT_L2_FindMebyHandle(handle);
    if( (pSamePSM = System_BT_L2_FindMe_byPSM( proto_id )) != NULL )
    {
      /* There's another L2 instance using this PSM. Lets use that appID */
      //(void)bt_cmd_ec_free_application_id( pMe->appId );
      System_BT_L2_Release( handle );
      pMe = pSamePSM;
      if(!System_BT_L2_InsertHandle( pMe, 0, handle )) return PDK_L2_CONN_ALL_USED;
      pHandleMgr = System_BT_L2_FindHandleMgrbyHandle( handle );
    }
	
    BT_MSG_HIGH( "BT OEM L2 CMD RX: Connect. PSM %x, BDA %x %x",
               proto_id, pBDAddr->uAddr[4], pBDAddr->uAddr[5] );
	
    BT_BDA( MSG_HIGH, "   >> INPUT bdAddr",(bt_bd_addr_type *)pBDAddr);

    status = bt_cmd_l2_connect_immediate_cid( pMe->appId,
                                              proto_id,
                                              (bt_bd_addr_type*)pBDAddr,
                                              &pHandleMgr->cid );
    BT_MSG_HIGH( "BT OEM L2 CMD RX: Connect. LCID %x", pHandleMgr->cid, 0, 0 );

    rv = System_BT_L2_ConvertCmdStatus( status /*pHandleMgr->CmdDoneStatus*/ );
    if( rv == PDK_L2_ERR_NONE )
    {
      pMe->sConfigInfo.psm = proto_id;
      pHandleMgr->bdAddr = *pBDAddr;
    }
  }
  return rv;
}


int System_BT_L2_Disconnect( 
	uint8 handle
)
{
  System_BT_L2obj_t *pMe;
  System_BT_L2obj_Handle_t *pHandleMgr;
  int rv;
  bt_cmd_status_type status;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( " >>>> handle[%d]", handle, 0, 0);
 
  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pMe == NULL �ߡ�", 0, 0, 0);
    return PDK_L2_ERR_BAD_PARAMS;
  }  

  pHandleMgr = System_BT_L2_FindHandleMgrbyHandle( handle );
  if( pHandleMgr == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pHandleMgr == NULL �ߡ�", 0, 0, 0);
    return PDK_L2_UNSPECIFIED_ERROR;
  }  

  BT_MSG_HIGH( __func__" cid[0x%x]", pHandleMgr->cid, 0, 0);

  if(pHandleMgr->bServer)
  {
    int i;
	
    BT_MSG_HIGH("������ Server Disconnect (Deregister/Release) ", 0, 0,0);

    // disconnect all connection related server
    for(i=0; i<3; i++)
    {
      if( pMe->HandleMgr[i].nParentHandle == handle )
      {
        status = bt_cmd_l2_disconn_immediate( pMe->appId, pMe->HandleMgr[i].cid );
        rv = System_BT_L2_ConvertCmdStatus( status );
        BT_MSG_HIGH("bt_cmd_l2_disconn_immediate : status(0x%x) rv(0x%x) ", status, rv,0);

        rv = System_BT_L2_Release( pMe->HandleMgr[i].nHandle );
        BT_MSG_HIGH("System_BT_L2_Release - peer: rv(0x%x) ", rv, 0, 0);
      }
    }

    // unregister l2cap server and service
    rv = System_BT_L2_Disable( handle );
    BT_MSG_HIGH("System_BT_L2_Disable : rv(0x%x) ", rv, 0, 0);

    // release handle
//    rv = System_BT_L2_Release( pMe->HandleMgr[i].nHandle );
    rv = System_BT_L2_Release( handle);

    BT_MSG_HIGH("System_BT_L2_Release - parent : rv(0x%x) ", rv, 0, 0);
  }
  else if( pHandleMgr->cid == BT_L2_NULL_CID )
  {
    BT_MSG_HIGH( " PDK_L2_NOT_CONNECTED  cid[0x%x]", pHandleMgr->cid, 0, 0);
    rv = PDK_L2_NOT_CONNECTED;
  }
  else
  {
    BT_MSG_HIGH( "BT OEM L2 CMD RX: Disconnect. PSM %x, CID %x, BDA %x",
               pMe->sConfigInfo.psm, pMe->sConfigInfo.cid, pHandleMgr->bdAddr.uAddr[5] );

    status = bt_cmd_l2_disconnect( pMe->appId, pHandleMgr->cid );
    rv = System_BT_L2_ConvertCmdStatus( status );
  }
  	
  return rv;
}


int32 System_BT_L2_Write( 
	uint8 handle,
	const byte* buf, 
	uint32 length 
)
{
  System_BT_L2obj_t *pMe;
  dsm_item_type* dsm_ptr;
  int rv = 0;
  bt_cmd_status_type status;
  int index;
  
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_L2_FindMeAndHandleMgrbyHandle( handle, &index );
  if( pMe == NULL )
  {
  	BT_MSG_HIGH(" �ߡ� pMe == NULL �ߡ�", 0, 0, 0);
    return PDK_L2_ERROR;
  }

  if( pMe->HandleMgr[index].cid == BT_L2_NULL_CID )
  {
    rv = PDK_L2_ERROR;
  }
  else
  {
    dsm_ptr = bt_get_free_dsm_ptr( BT_TL_L2CAP, length );
    if( !dsm_ptr )
    {
      status = BT_CS_GN_CMD_Q_FULL;
    }
    else
    {
      rv = dsm_pushdown_tail( &dsm_ptr,
                              buf,
                              length,
                              DSM_DS_POOL_SIZE( length ) );
      if( rv != length )
      {
        status = BT_CS_GN_CMD_Q_FULL;
        BT_MSG_HIGH( "BT OEM L2: Write error filling DSM", 0,0,0 );    
        dsm_free_buffer( dsm_ptr );
      }
      else
      {
        BT_MSG_HIGH( __func__" >>>> appId[0x%x] cid[0x%x] dsm_ptr[0x%x]", pMe->appId, pMe->HandleMgr[index].cid, dsm_ptr);    
        status = bt_cmd_l2_write( pMe->appId, pMe->HandleMgr[index].cid, dsm_ptr, NULL);
      }
    }
	
    if( status == BT_CS_GN_CMD_Q_FULL )
    {
      rv = PDK_L2_WOULDBLOCK;
    }
    else if( System_BT_L2_ConvertCmdStatus( status /*pMe->CmdDoneStatus*/ ) != PDK_L2_ERR_NONE )
    {
      rv = PDK_L2_ERROR;
    }
  }
  return rv;
}

void System_BT_L2_FlowCB( 
  uint8 handle
)
{
  System_BT_L2obj_t *pMe;

  BT_MSG_HIGH( __func__, 0, 0, 0);

  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
  	BT_MSG_HIGH(" �ߡ� pMe[0x%x] == NULL �ߡ�", pMe, 0, 0);
    return;
  }
#if 0
  if( bt_bb_tx_flow_on )
  {
    //AEE_APP_RESUME( &pMe->m_cbWrite, pMe->m_pac );
  }  
  else
  {
    // Currently, we don't have real flow control for L2
    // Just poll to see when bb flow is back on again.
    //AEE_SetSysTimer( BT_L2_FLOW_POLL_MS, (PFNNOTIFY)System_BT_L2_FlowCB, (void*)pParent );
  }
#endif  
}

void System_BT_L2_Writable( 
  uint8 handle,	
  void* pUser )
{
  System_BT_L2obj_t *pMe;

  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
  	BT_MSG_HIGH(" �ߡ� pMe[0x%x] == NULL �ߡ�", pMe, 0, 0);  	
    return;
  }
  
  //OEMBTExtL2_FlowCB( pParent );
  System_BT_L2_FlowCB( handle);
}

uint16 System_BT_L2_NumConn( 
  uint8 handle,
  const BTBDAddr *pBdAddr )
{
  System_BT_L2obj_t *pMe;
  uint16 num_conn;

  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pMe[0x%x] == NULL �ߡ�", pMe, 0, 0);  	
    return 0;
  }

  bt_cmd_l2_get_num_conn( pMe->appId, (bt_bd_addr_type*)pBdAddr, &num_conn );

  return num_conn;
}

uint32 System_BT_L2_Accept( 
  uint8 handle, uint8 peerhandle
)
{
	int i,j;
	BT_MSG_HIGH(__func__" handle:%d  peerhandle: %d", handle, peerhandle, 0);
	for(i=0;i<8;i++)
	{
		if(gL2Accept[i].handle == handle)
		{
			for(j=0;j<2;j++)
			{
				if(gL2Accept[i].gL2AcceptHandle[j] ==0)
				{
					gL2Accept[i].gL2AcceptHandle[j] = peerhandle;
					BT_MSG_HIGH(" gL2Accept[%d].gL2AcceptHandle[j]:%d  Update!", i,j, gL2Accept[i].gL2AcceptHandle[j]);
					break;
				}
			}
			if(j>2)
			{
				BT_MSG_HIGH(__func__" gL2Accept[].gL2AcceptHandle is full.", 0, 0, 0);
				return PDK_L2_CONN_ALL_USED;
			}
			break;
		}
		
	}
	if(i>7)
	{
		for(i=0;i<8;i++)
		{
			BT_MSG_HIGH(__func__"gL2Accept[%d].bUsed:%d",i, gL2Accept[i].bUsed, 0);
			if(gL2Accept[i].bUsed==FALSE)
			{
				gL2Accept[i].gL2AcceptHandle[0]=peerhandle;
				gL2Accept[i].handle = handle;
				gL2Accept[i].bUsed = TRUE;
				BT_MSG_HIGH(__func__" gL2Accept[%d]: handle:%d ,gL2AcceptHandle[0]:%d  Add!", i, handle, peerhandle);
				break;
			}
		}
	} 
	if(i>7)
	{
		BT_MSG_HIGH(__func__" gL2Accept[].handle is full.", 0, 0, 0);
		return PDK_L2_CONN_ALL_USED;
	}
	return PDK_L2_ERR_NONE;
}

//==========================================================================
//   static helper functions
//==========================================================================
static System_BT_L2obj_t* System_BT_L2_FindMe_byAID(bt_app_id_type appId)
{
  System_BT_L2obj_t* pMe = NULL;
  int index;

  rex_enter_crit_sect( &gsOEMBTExtL2_cs );
  for(index=0; index<8; index++)
  {
    if( gMe[index].appId == appId && gMe[index].bUsed == TRUE )
    {
      pMe = &(gMe[index]);
      break;
    }
  }
  rex_leave_crit_sect( &gsOEMBTExtL2_cs );
  return pMe;
}

static System_BT_L2obj_t* System_BT_L2_FindMe_byPSM(uint16 PSM)
{
  System_BT_L2obj_t* pMe = NULL;
  int index;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);

  rex_enter_crit_sect( &gsOEMBTExtL2_cs );
  for( index=0; index<8; index++ )
  {
    //BT_MSG_HIGH("   -> pMe->sConfigInfo.psm[0x%x] Input PSM[0x%x]", pMe->sConfigInfo.psm, PSM, 0);
    if ( gMe[index].sConfigInfo.psm == PSM && gMe[index].bUsed == TRUE )
    {
      BT_MSG_HIGH(__func__" pMe->sConfigInfo.psm[%x] == PSM[%x]", gMe[index].sConfigInfo.psm, PSM, 0);
      pMe = &(gMe[index]);
      break;
    }
  }
  rex_leave_crit_sect( &gsOEMBTExtL2_cs );
  return pMe;
}

static System_BT_L2obj_t* System_BT_L2_FindMe_byCID(uint16 wCid)
{
  System_BT_L2obj_t* pMe = NULL;
  int i, j;

  rex_enter_crit_sect( &gsOEMBTExtL2_cs );
  for( i=0; i<8; i++ )
  {
    if( gMe[i].bUsed == TRUE )
    {
      for( j=0; j<3; j++)
      {
        if( gMe[i].HandleMgr[j].cid == wCid && gMe[i].HandleMgr[j].nHandle != 0 )
        {
	   pMe = &(gMe[i]);
          break;
        }
      }
    }
  }
  rex_leave_crit_sect( &gsOEMBTExtL2_cs );
  return pMe;
}

static int System_BT_L2_ConvertCmdStatus( bt_cmd_status_type cmd_status )
{
  BT_MSG_HIGH( __func__" --> cmd_status %x �ߡߡߡ�", cmd_status, 0, 0 );
  switch ( cmd_status )
  {  
    case BT_CS_GN_SUCCESS:
    case BT_CS_GN_PENDING:
      return PDK_L2_ERR_NONE;

    case BT_CS_L2_SETPRM_REG_FULL:
      return PDK_L2_SETPRM_REG_FULL;

    case BT_CS_L2_REG_FULL:
      return PDK_L2_REG_FULL;

    case BT_CS_L2_REG_DUPLICATE:
      return PDK_L2_REG_DUPLICATE;

    case BT_CS_L2_CONN_NOT_REGISTERED:
      return PDK_L2_CONN_NOT_REGISTERED;

    case BT_CS_L2_CONN_ALL_USED:
      return PDK_L2_CONN_ALL_USED;

    case BT_CS_L2_WRITE_CID_NOT_FOUND:
      return PDK_L2_WRITE_CID_NOT_FOUND;

    case BT_CS_L2_WRITE_BIG_PKT_SIZE:
      return PDK_L2_WRITE_BIG_PKT_SIZE;

    case BT_CS_L2_DISC_CID_NOT_FOUND:
      return PDK_L2_DISC_CID_NOT_FOUND;

    case BT_CS_L2_DISC_ERROR:
      return PDK_L2_DISC_ERROR;

    case BT_CS_L2_UNREG_NOT_FOUND:
      return PDK_L2_UNREG_NOT_FOUND;

    case BT_CS_L2_INVALID_PSM:
      return PDK_L2_INVALID_PSM;

    case BT_CS_L2_CONN_NOT_UP:
      return PDK_L2_CONN_NOT_UP;

    case BT_CS_GN_BAD_CMD_STATE:
      return PDK_L2_UNSPECIFIED_ERROR;

    case BT_CS_GN_CMD_Q_FULL:
      return PDK_L2_WOULDBLOCK;

    case BT_CS_GN_BAD_APP_ID:
      return PDK_L2_UNSPECIFIED_ERROR;

    case BT_CS_GN_UNRECOGNIZED_CMD:
      return PDK_L2_UNSPECIFIED_ERROR;

    case BT_CS_GN_MAX_CMD_RETRIES:
      return PDK_L2_UNSPECIFIED_ERROR;

    case BT_CS_GN_RETRY_CMD_LATER:
      return PDK_L2_UNSPECIFIED_ERROR;

    default:
      return PDK_L2_UNSPECIFIED_ERROR;
  }
}

static uint16 System_BT_L2_ConvertEvReason( bt_event_reason_type ev_reason )
{
  BT_MSG_HIGH( __func__" >>>> ev_reason[%x] �ߡߡߡ�", ev_reason, 0, 0 );	
  switch ( ev_reason )
  {
    case BT_EVR_GN_SUCCESS:
      return PDK_L2_ERR_NONE;
    case BT_EVR_L2_CONFIG_PARAMS_NOT_AGREEABLE:
      return PDK_L2_CONFIG_PARAMS_NOT_AGREEABLE;
    case BT_EVR_L2_LOCAL_REJECT_CONNECTION:
      return PDK_L2_LOCAL_REJECT_CONNECTION;
    case BT_EVR_L2_REMOTE_REJECT_CONNECTION:
      return PDK_L2_REMOTE_REJECT_CONNECTION;
    case BT_EVR_L2_PAGE_FAILED:
      return PDK_L2_PAGE_FAILED;
    case BT_EVR_L2_LINK_LOST:
      return PDK_L2_LINK_LOST;
    case BT_EVR_L2_AUTHENTICATION_FAILED:
      return PDK_L2_AUTHENTICATION_FAILED;
    case BT_EVR_L2_UNSPECIFIED_ERROR:
      return PDK_L2_UNSPECIFIED_ERROR;
    case BT_EVR_L2_NORMAL_DISCONNECT:
      return PDK_L2_ERR_NONE;
    case BT_EVR_L2_PING_SUCCESS:
      return PDK_L2_ERR_NONE;
    case BT_EVR_L2_PING_FAILED:
      return PDK_L2_PING_FAILED;
    case BT_EVR_L2_CONFIG_SUCCESS:
      return PDK_L2_ERR_NONE;

    default:
      return PDK_L2_UNSPECIFIED_ERROR;
  }
}

void System_BT_L2_Handle_Ev_Disc(bt_ev_l2_disconnected_type *ev_l2_disc_ptr)
{
  uint16 uID = NULL;
  System_BT_L2obj_t* pMe = NULL;
  System_BT_L2obj_Handle_t *pHandleMgr = NULL;
  int event_index = NULL;
  int i,j;
	
  uint8 ServerHandle = 0; // LEECHANGHOON 2008-1-20 Client�� ������ ������� ������ ����.
  uint8 ClientHandle = 0;
  T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);		
	 
  pMe = System_BT_L2_FindMe_byCID(ev_l2_disc_ptr->cid);
  pHandleMgr = System_BT_L2_FindHandleMgrbyCID(ev_l2_disc_ptr->cid);

  if( pMe != NULL && pHandleMgr != NULL )
  {
    uID = PDK_L2_EVT_DISCONNECTED;								
    BT_MSG_HIGH(__func__" ������ PDK_L2_EVT_DISCONNECTED",0,0,0);	

    pHandleMgr->cid = BT_L2_NULL_CID;							// 2006-10-19 Disconnect �� �ٽ� Connect�� cid �� ���� ���� �ȵ�.

    pN_L2Disconnected.uError = System_BT_L2_ConvertEvReason( ev_l2_disc_ptr->reason );	 
    pN_L2Disconnected.cid = ev_l2_disc_ptr->cid;											 
    pN_L2Disconnected.psm = pMe->sConfigInfo.psm;
    pN_L2Disconnected.bdAddr = pHandleMgr->bdAddr;
    pN_L2Disconnected.handle = pHandleMgr->nHandle;

    for(i=0;i<8;i++)
    {
      for(j=0;j<2;j++)
      {
        if(gL2Accept[i].gL2AcceptHandle[j] == pHandleMgr->nHandle)
        {
          gL2Accept[i].gL2AcceptHandle[j] = 0;
          ServerHandle = gL2Accept[i].handle; // LEECHANGHOON 2008-1-20 MBT����
          BT_MSG_HIGH("[DISCONNECTED] gL2Accept[%d].gL2AcceptHandle[%d]:%d", i, j,gL2Accept[i].gL2AcceptHandle[j]);
          break;
        }
      }	
			
      if((gL2Accept[i].gL2AcceptHandle[0]==0)&&(gL2Accept[i].gL2AcceptHandle[1]==0))
      {
        gL2Accept[i].handle = 0;
        gL2Accept[i].bUsed = FALSE;
        BT_MSG_HIGH("[DISCONNECTED] gL2Accept[%d].handle:%d, bUsed:%d", i, gL2Accept[i].handle,gL2Accept[i].bUsed);
      }
      break;
    }
   	  
    BT_MSG_HIGH("������ PDK_L2_EVT_DISCONNECTED      pMe->sConfigInfo.psm[0x%x] pHandleMgr->nHandle[0x%x]", pMe->sConfigInfo.psm, pHandleMgr->nHandle,0);

#if 0		 
 		//if(pMe->sConfigInfo.psm == BT_L2_PSM_SDP)	 2006-12-08 : Disconnect�� SDP Unregister �߰� 
   		//2007-02-27 : Connect Disconnect �ݺ��� pMe�� PSM ���� Clear ���� �ʴ� �������� ���� 
 		{
 			BT_MSG_HIGH(__func__" UnRegister >>> appId[0x%x] psm[%x]", pMe->appId, pMe->sConfigInfo.psm, 0);
 			//bt_cmd_l2_unregister(pMe->appId, pMe->sConfigInfo.psm);
			pMe->sConfigInfo.psm = NULL;
 		}
#endif		
    ClientHandle = pHandleMgr->nHandle;

    // LEECHANGHOON 2008-1-18 �Ʒ� 2���� ����
    //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));	
    //ui_bt_event_ptr->event_data 	= (void*)&pN_L2Disconnected;		 
    BT_MSG_HIGH(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);		

    event_index = mbt_jsr82_getEmptyIdx();
    System_BT_L2_Release(pHandleMgr->nHandle);
    if(event_index == -1)
    {
      MBT_FATAL("EVENT INFO NO FREE SPACE...");
      if(pHandleMgr->bServer == TRUE) //Server���忡�� Client�� ���� ���.
      {
        mbt_postevent(MBTEVT_JSR82_L2CAP_CLOSE_FAIL, 0);
      }
      else
      {
        mbt_postevent(MBTEVT_JSR82_L2CAP_DISCONNECT_FAIL, 0);
      }
    }
    else
    {
      if(pHandleMgr->bServer == TRUE) //Server���忡�� Client�� ���� ���.
      {
        sdcJSR82Status->EvInfo[event_index].Used = TRUE;
        sdcJSR82Status->EvInfo[event_index].ServerHandle= ServerHandle; // LEECHANGHOON 2008-1-20 MBT����
        sdcJSR82Status->EvInfo[event_index].Val.PSM = pMe->sConfigInfo.psm;
        memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)pHandleMgr->bdAddr.uAddr, MBT_BDADDR_LEN);
        mbt_postevent(MBTEVT_JSR82_L2CAP_CLOSE_SUCCESS, event_index);
      }
      else//Client�� ������ ������ �������, Client�̸鼭 ������ ���� ���.
      {
        sdcJSR82Status->EvInfo[event_index].Used = TRUE;
        sdcJSR82Status->EvInfo[event_index].ClientHandle = ClientHandle; //pHandleMgr->nHandle;
        sdcJSR82Status->EvInfo[event_index].Val.PSM = pMe->sConfigInfo.psm;
        memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)pHandleMgr->bdAddr.uAddr, MBT_BDADDR_LEN);
        mbt_postevent(MBTEVT_JSR82_L2CAP_DISCONNECT_SUCCESS, event_index);
      }				
    } 

    //bt_send_ui_cmd(uID, ui_bt_event_ptr); // LEECHANGHOON 2008-1-18 MBT����
    //mbt_postevent(MBTEVT_JSR82_L2CAP_DISCONNECT_SUCCESS, event_index);
  }
  
  return;
}

// called from BT task context; so just queue the event
static void System_BT_L2_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
{
  uint16 uID = NULL;
  System_BT_L2obj_t* pMe = NULL;
  System_BT_L2obj_Handle_t *pHandleMgr = NULL;
  int event_index = NULL;
  //uint8 check_index = NULL;
  int i,j;
  
  // LEECHANGHOON 2008-1-18 2Line ����
  //extern lgoem_bt_event_type	ui_bt_event_buf;						
  //lgoem_bt_event_type*			ui_bt_event_ptr	= &ui_bt_event_buf;		

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH(__func__" -> ev_type[0x%x]", bt_ev_msg_ptr->ev_hdr.ev_type,0,0);	
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);

  switch (bt_ev_msg_ptr->ev_hdr.ev_type)
  {
    case BT_EV_GN_CMD_DONE:
    {
	  T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
      BT_MSG_HIGH( "BT PF L2 RX EV: Cmd Done, Status: 0x%x, App: 0x%x, Cmd: 0x%x", 
                 bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status,
                 bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.bt_app_id,
                 bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type );

      if(bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type == BT_CMD_L2_WRITE &&	
	  	bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status == BT_CS_GN_SUCCESS)	
      {
        BT_MSG_HIGH(__func__" ������ PDK_L2_EVT_TX_DATA", 0,0,0);	
        //bt_send_ui_cmd(PDK_L2_EVT_TX_DATA, NULL);	 // LEECHANGHOON 2008-1-18 ����

		// LEECHANGHOON 2008-1-18 MBT���� SDC ����Ÿ ����� �ϴµ�. �޾ƿ��°��� ����.
        mbt_postevent(MBTEVT_JSR82_L2CAP_WRITE_SUCCESS, 0);
      }
      else if( bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type == BT_CMD_L2_REGISTER )
      {
	    if( bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status == BT_CS_GN_SUCCESS )
        {
          pN_L2Open.bSuccess= TRUE;
	    } 
		else
        {
          pN_L2Open.bSuccess= FALSE;
	    }
		
		pMe = System_BT_L2_FindMebyHandle(pL2_OpenHandle);
		if(pMe == NULL)
		{
			MBT_WARN("Handle not exist IN BT_CMD_L2_REGISTER",0,0,0);
			break;
		}
		
		event_index = mbt_jsr82_getEmptyIdx();
		
		if(event_index == -1)
		{
			MBT_FATAL("EVENT INFO NO FREE SPACE...");
			mbt_postevent(MBTEVT_JSR82_L2CAP_OPEN_FAIL, 0);
			break;
		}
		else
		{
			sdcJSR82Status->EvInfo[event_index].Used = TRUE;
			sdcJSR82Status->EvInfo[event_index].Val.PSM = pMe->sConfigInfo.psm;
			sdcJSR82Status->EvInfo[event_index].ServerHandle = pL2_OpenHandle;
		}

		// LEECHANGHOON 2008-1-18 2���� ����
        //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));
        //ui_bt_event_ptr->event_data 	= (void*)&pN_L2Open;

        BT_MSG_HIGH(__func__" ������ PDK_L2_EVT_OPENED : handle (0x%x), success (0x%x)", 0, pN_L2Open.bSuccess, 0);

		//bt_send_ui_cmd(PDK_L2_EVT_OPENED, ui_bt_event_ptr);		
        mbt_postevent(MBTEVT_JSR82_L2CAP_OPEN_SUCCESS, event_index);
      }
//      pHandleMgr->CmdDoneStatus = bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status;
    } // end of case BT_EV_GN_CMD_DONE
    break;

    case BT_EV_L2_CONNECTED:
    {
	  T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
      pMe = System_BT_L2_FindMe_byCID(bt_ev_msg_ptr->ev_msg.ev_l2_conn.cid);
      pHandleMgr = System_BT_L2_FindHandleMgrbyCID( bt_ev_msg_ptr->ev_msg.ev_l2_conn.cid );
      if( pMe == NULL )
      {
        int iAcceptHandle = 0;
		System_BT_L2obj_t* pServer = NULL;
        uint8 nServerHandle = 0;
	 
	 /* This is not a response to a connection request, but an incomming connection */
        pServer = System_BT_L2_FindMe_byAID(bt_ev_msg_ptr->ev_hdr.bt_app_id);
        if( pServer == NULL)
        {
			MBT_FATAL("After L2_CONNECTED, again Disconnect ");
          	bt_cmd_l2_disconnect( pServer->appId, bt_ev_msg_ptr->ev_msg.ev_l2_conn.cid );
          break;
        }

        // TBD
        nServerHandle = System_BT_L2_FindServerHandlebyMe(pServer);
		 for(i=0;i<8;i++)
	 	{
			if(gL2Accept[i].handle==nServerHandle)
			{
				for(j=0;j<2;j++)
				{
					if(gL2Accept[i].gL2AcceptHandle[j] !=0)
					{
						iAcceptHandle = gL2Accept[i].gL2AcceptHandle[j];
						gL2Accept[i].gL2AcceptHandle[j] = 0;
						BT_MSG_HIGH(__func__" [CONNECTED] iAcceptHandle:%d", iAcceptHandle, 0, 0);
						BT_MSG_HIGH(__func__"         gL2Accept[%d].gL2AcceptHandle[%d]:%d", i, j, gL2Accept[i].gL2AcceptHandle[j]);
						break;
					}
				}			
				if((gL2Accept[i].gL2AcceptHandle[0]==0)&&(gL2Accept[i].gL2AcceptHandle[1]==0))
				{
					gL2Accept[i].handle = 0;
					gL2Accept[i].bUsed = FALSE;
					BT_MSG_HIGH(__func__"         gL2Accept[%d].handle:0, bUsed:FALSE", i, 0, 0);
				}
				break;
			}
	 	}
	 
        if( nServerHandle == 0 || !System_BT_L2_InsertHandle( pServer, nServerHandle, iAcceptHandle) )
        {
			MBT_FATAL("After L2_CONNECTED, again Disconnect ");
          bt_cmd_l2_disconnect( pServer->appId, bt_ev_msg_ptr->ev_msg.ev_l2_conn.cid );
          break;
        }

        pMe = pServer; 
        pHandleMgr = System_BT_L2_FindHandleMgrbyMeAndHandle(pServer, iAcceptHandle);

 //       gAcceptHandle = 0;

      }

      if( pMe != NULL && pHandleMgr != NULL )
      {
          uID = PDK_L2_EVT_CONNECTED;								
          BT_MSG_HIGH(__func__" ������ PDK_L2_EVT_CONNECTED", 0,0,0);	

          rex_enter_crit_sect( &gsOEMBTExtL2_cs );

          pHandleMgr->cid = bt_ev_msg_ptr->ev_msg.ev_l2_conn.cid;
          pMe->sConfigInfo.out_mtu   = bt_ev_msg_ptr->ev_msg.ev_l2_conn.mtu;
		  
          if( pHandleMgr->pRcvbuf != NULL )
          {
            /* There is still data left over from a previous connection, free it now */
            dsm_free_packet( &pHandleMgr->pRcvbuf );
          }
          rex_leave_crit_sect( &gsOEMBTExtL2_cs );				

          pN_L2Connect.bdAddr = *((BTBDAddr*)&bt_ev_msg_ptr->ev_msg.ev_l2_conn.bd_addr);
	      BT_BDA( MSG_HIGH, " PDK_L2_EVT_CONNECTED ev_l2_conn.bd_addr ", (bt_bd_addr_type *)&pN_L2Connect.bdAddr );

          memcpy(&pHandleMgr->bdAddr, &pN_L2Connect.bdAddr, 6);
	      BT_BDA( MSG_HIGH, " PDK_L2_EVT_CONNECTED pHandleMgr->bdAddr ", (bt_bd_addr_type *)&pHandleMgr->bdAddr );
		  	
          pN_L2Connect.handle = pHandleMgr->nHandle;
          pN_L2Connect.info = pMe->sConfigInfo;
          pN_L2Connect.info.cid = pHandleMgr->cid;
		  
		  event_index = mbt_jsr82_getEmptyIdx();

		  BT_MSG_HIGH(__func__" TX MTU:%d, handle:%d", pMe->sConfigInfo.out_mtu,pHandleMgr->nHandle,0);	
		  
		  if(event_index == -1)
		  {
			  MBT_FATAL("EVENT INFO NO FREE SPACE...");
			  mbt_postevent(MBTEVT_JSR82_L2CAP_CONNECT_FAIL, 0);
			  break;
		  }
		  else
		  {
			  sdcJSR82Status->EvInfo[event_index].Used = TRUE;
			  sdcJSR82Status->EvInfo[event_index].ClientHandle = pHandleMgr->nHandle;
			  sdcJSR82Status->EvInfo[event_index].Val.MTU.TxMTU = pMe->sConfigInfo.out_mtu;
			  memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)pN_L2Connect.bdAddr.uAddr, MBT_BDADDR_LEN);
		  }

          BT_BDA( MSG_HIGH, " pN_L2Connect.bdAddr",(bt_bd_addr_type *)&pN_L2Connect.bdAddr);

		  // LEECHANGHOON 2008-1-18 MBT���� 2Line ����
          //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));	
          //ui_bt_event_ptr->event_data 	= (void*)&pN_L2Connect;				 
          BT_MSG_HIGH(__func__" --> bt_send_ui_cmd uID[0x%x] PDK_L2_EVT_CONNECTED[%d]",uID,PDK_L2_EVT_CONNECTED,0);		 

          //bt_send_ui_cmd(uID, ui_bt_event_ptr); // LEECHANGHOON 2008-1-18 MBT����
          mbt_postevent(MBTEVT_JSR82_L2CAP_CONNECT_SUCCESS, event_index);
      }
      else
      {
        BT_ERR( "BT OEM L2: Can't find entry for connected event! CID %x AID %x",
                bt_ev_msg_ptr->ev_msg.ev_l2_conn.cid,
                bt_ev_msg_ptr->ev_hdr.bt_app_id, 0 );
		mbt_postevent(MBTEVT_JSR82_L2CAP_CONNECT_FAIL, 0);
      }
     }
      break;

    case BT_EV_L2_CONNECTION_FAILED:
		{
		T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
	      pMe = System_BT_L2_FindMe_byCID(bt_ev_msg_ptr->ev_msg.ev_l2_conn_failed.cid);
	      pHandleMgr = System_BT_L2_FindHandleMgrbyCID(bt_ev_msg_ptr->ev_msg.ev_l2_conn_failed.cid);

	      if( pMe != NULL && pHandleMgr != NULL )
	      {
	          uID = PDK_L2_EVT_CONNECT_FAILED;									
	          BT_MSG_HIGH(__func__" ������ PDK_L2_EVT_CONNECT_FAILED", 0,0,0);	
	          
	          pHandleMgr->cid = BT_L2_NULL_CID;
	          pN_L2ConnectFailded.uError = System_BT_L2_ConvertEvReason( bt_ev_msg_ptr->ev_msg.ev_l2_conn_failed.reason );  
	          pN_L2ConnectFailded.psm = pMe->sConfigInfo.psm;
	          pN_L2ConnectFailded.bdAddr = pHandleMgr->bdAddr;

	          BT_BDA( MSG_HIGH, " BT_EV_L2_CONNECTION_FAILED pHandleMgr->bdAddr ", (bt_bd_addr_type *)&pHandleMgr->bdAddr );

	          BT_MSG_HIGH(__func__" -> PDK_L2_EVT_CONNECT_FAILED psm[0x%x] uError[0x%x]", pN_L2ConnectFailded.psm,pN_L2ConnectFailded.uError,0);	

	          pN_L2ConnectFailded.handle = pHandleMgr->nHandle; 

	          BT_MSG_HIGH("������ PDK_L2_EVT_CONNECT_FAILED      pMe->sConfigInfo.psm[0x%x]", pMe->sConfigInfo.psm, 0,0);
			 
	   		 event_index = mbt_jsr82_getEmptyIdx();
	   		 
	   		 if(event_index == -1)
	   		 {
	   			 MBT_FATAL("EVENT INFO NO FREE SPACE...");
				 mbt_postevent(MBTEVT_JSR82_L2CAP_CONNECT_FAIL, 0);
				 break;
	   		 }
	   		 else
	   		 {
	   			 sdcJSR82Status->EvInfo[event_index].Used = TRUE;
	   			 sdcJSR82Status->EvInfo[event_index].ClientHandle = pHandleMgr->nHandle;
				 sdcJSR82Status->EvInfo[event_index].Val.PSM = pMe->sConfigInfo.psm;
				 memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)pHandleMgr->bdAddr.uAddr, MBT_BDADDR_LEN);

			 }
	          // LEECHANGHOON 2008-1-18 2���� ����.
	          //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));	
	          //ui_bt_event_ptr->event_data 	= (void*)&pN_L2ConnectFailded;		 

			  BT_MSG_HIGH(__func__" --> bt_send_ui_cmd uID[0x%x] PDK_L2_EVT_CONNECT_FAILED[%d]",uID,PDK_L2_EVT_CONNECT_FAILED,0);		 
	          BT_MSG_HIGH(__func__" --> bt_send_ui_cmd uID[%d]",uID,0,0);		 

	          System_BT_L2_Release(pHandleMgr->nHandle);
			  
	          //bt_send_ui_cmd(uID, ui_bt_event_ptr); // LEECHANGHOON 2008-1-18 MBT����          
			  mbt_postevent(MBTEVT_JSR82_L2CAP_CONNECT_FAIL, event_index);
	      }
	    }
      break;

    case BT_EV_L2_RX_DATA:
		{
		T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
		uint32 dsm_len = 0;
		
	      BT_MSG_HIGH(__func__" --> BT_EV_L2_RX_DATA",0,0,0);	
	//      pMe = System_BT_L2_FindMe_byCID(bt_ev_msg_ptr->ev_msg.ev_l2_rxd.cid);
	      pHandleMgr = System_BT_L2_FindHandleMgrbyCID(bt_ev_msg_ptr->ev_msg.ev_l2_rxd.cid);

	      if( pHandleMgr != NULL )
	      {
	        uID = PDK_L2_EVT_RX_DATA;									 
	        BT_MSG_HIGH(__func__" ������ PDK_L2_EVT_RX_DATA", 0,0,0);	
	        BT_MSG_HIGH("      ������ PDK_L2_EVT_RX_DATA  pHandleMgr->pRcvbuf[0x%x]", pHandleMgr->pRcvbuf,0,0);	
	        rex_enter_crit_sect( &gsOEMBTExtL2_cs );				
	        if( pHandleMgr->pRcvbuf )
	        {
	          dsm_item_type *dsm_ptr = bt_ev_msg_ptr->ev_msg.ev_l2_rxd.dsm_ptr;

	          BT_MSG_HIGH("      pHandleMgr->pRcvbuf == TRUE", 0,0,0);	
			  
	          // Add the incoming DSM to the receive buffer
	          dsm_append( &pHandleMgr->pRcvbuf, &dsm_ptr );
	        }
	        else
	        {
	          pHandleMgr->pRcvbuf = bt_ev_msg_ptr->ev_msg.ev_l2_rxd.dsm_ptr;
	        }
	        dsm_len = dsm_length_packet(bt_ev_msg_ptr->ev_msg.ev_l2_rxd.dsm_ptr);
	        rex_leave_crit_sect( &gsOEMBTExtL2_cs );				
	        // Call the read callback
	        //AEE_APP_RESUME( &pMe->m_cbRead, pMe->m_pac );			     

	        BT_MSG_HIGH("      ������ PDK_L2_EVT_RX_DATA  dsm_length_packet[0x%x]", dsm_len, 0, 0);	
	        BT_BDA( MSG_HIGH, " PDK_L2_EVT_RX_DATA bdAddr",(bt_bd_addr_type *)&pHandleMgr->bdAddr);	
	      }
		  
		  event_index = mbt_jsr82_getEmptyIdx();
		  
		  if(event_index == -1)
		  {
			  MBT_FATAL("EVENT INFO NO FREE SPACE...");
			  mbt_postevent(MBTEVT_JSR82_L2CAP_READ_FAIL, 0);
			  break;
		  }
		  else
		  {
			  sdcJSR82Status->EvInfo[event_index].Used = TRUE;
	  		  sdcJSR82Status->EvInfo[event_index].Val.ReadLen = dsm_len;
			  sdcJSR82Status->EvInfo[event_index].ClientHandle = pHandleMgr->nHandle;
			  memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)pHandleMgr->bdAddr.uAddr, MBT_BDADDR_LEN);
		  }

		  // LEECHANGHOON 2008-1-18 MBT���� 3���� ����
	      //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));	
	      //ui_bt_event_ptr->event_data = &(pHandleMgr->nHandle);     
	      //bt_send_ui_cmd(uID, ui_bt_event_ptr);				
	      mbt_postevent(MBTEVT_JSR82_L2CAP_READ_SUCCESS, event_index);
	    }
      break;

    case BT_EV_L2_RECONFIGURED:
      pMe = System_BT_L2_FindMe_byCID(bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.cid);
      pHandleMgr = System_BT_L2_FindHandleMgrbyCID(bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.cid);
      if( pMe != NULL && pHandleMgr != NULL )
      {
          uID = PDK_L2_EVT_RECONFIGURED;								
          BT_MSG_HIGH(__func__" ������ PDK_L2_EVT_RECONFIGURED",0,0,0);	

          rex_enter_crit_sect( &gsOEMBTExtL2_cs );						
          pMe->sConfigInfo.out_mtu = bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.out_mtu;
          pMe->sConfigInfo.in_flush_to = bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.in_flush_to;
          pMe->sConfigInfo.in_qos = (uint8)bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.in_qos.service_type;
          pMe->sConfigInfo.token_rate = (uint8)bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.in_qos.token_rate;
          pMe->sConfigInfo.token_bucket_size = (uint8)bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.in_qos.token_bucket_size;
          pMe->sConfigInfo.peak_bandwidth = (uint8)bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.in_qos.peak_bandwidth;
          pMe->sConfigInfo.latency = (uint8)bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.in_qos.latency;
          pMe->sConfigInfo.delay_variation = (uint8)bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.in_qos.delay_variation;
          pN_L2Reconfigured.info = pMe->sConfigInfo;										 
          pN_L2Reconfigured.info.cid = pHandleMgr->cid;
          rex_leave_crit_sect( &gsOEMBTExtL2_cs );											
          
          pN_L2Reconfigured.uError = System_BT_L2_ConvertEvReason( bt_ev_msg_ptr->ev_msg.ev_l2_reconfig.reason );  
          //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));	
          //ui_bt_event_ptr->event_data 	= (void*)&pN_L2Reconfigured;		 
          BT_MSG_HIGH(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);		 

          //bt_send_ui_cmd(uID, ui_bt_event_ptr);								 
      }
      break;

    case BT_EV_L2_DISCONNECTED:
	{
	  uint32 recv_data = 0;
	  pHandleMgr = System_BT_L2_FindHandleMgrbyCID(bt_ev_msg_ptr->ev_msg.ev_l2_disc.cid);

	  rex_enter_crit_sect( &gsOEMBTExtL2_cs );
	  if( pHandleMgr->pRcvbuf ) 
	  {
	    recv_data = dsm_length_packet(pHandleMgr->pRcvbuf);
	  }
	  rex_leave_crit_sect( &gsOEMBTExtL2_cs );

	  if (recv_data != 0) 
	  {
  	    BT_MSG_HIGH(__func__" enqueue bt ev l2 disconnected", 0, 0, 0);		 
	    /* Let us know the remote has disconnected after recieved data will be consumed by JVM. */
	    ev_l2_disc_pending = bt_ev_msg_ptr->ev_msg.ev_l2_disc;
	    bL2caDisconnPending = TRUE;
	    break;
	  }
	  
	  System_BT_L2_Handle_Ev_Disc(&bt_ev_msg_ptr->ev_msg.ev_l2_disc);
    	}
      break;

    case BT_EV_L2_PING:
    {
#if 0
      /* Note: This assumes that notifications are broadcast to everyone. This
       * will send the L2 Ping to all of the L2 instances. */
      pMe = gMgr.pNextL2;
      if( pMe != NULL )
      {
        byte* data = (byte*)bt_ev_msg_ptr->ev_msg.ev_l2_ping.data;
        pN = OEMBTExtL2_GetFreeNotification( pMe->m_pNotifier );	
        //if( pN != NULL )											
        {
          //pN->uID = AEEBT_L2_EVT_PING_RSP;
          uID = PDK_L2_EVT_PING_RSP;								
          BT_MSG_HIGH(__func__" --> PDK_L2_EVT_PING_RSP",0,0,0);	
          
          pN->data.sL2PingRsp.data = MALLOC( bt_ev_msg_ptr->ev_msg.ev_l2_ping.length );
          pN->data.sL2PingRsp.bdAddr = *((AEEBTBDAddr*)&bt_ev_msg_ptr->ev_msg.ev_l2_ping.bd_addr);
          pN->data.sL2PingRsp.size = bt_ev_msg_ptr->ev_msg.ev_l2_ping.length;
          MEMCPY(pN->data.sL2PingRsp.data, 
                 data,
                 pN->data.sL2PingRsp.size );
          pN->data.sL2PingRsp.uError = bt_ev_msg_ptr->ev_msg.ev_l2_ping.reason;

		  memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));			
		  ui_bt_event_ptr->event_data 	= (void*)&bt_ev_msg_ptr->ev_msg.ev_l2_ping;	
		  
        }
      }
#endif	  
    }
    break;

    default:
    {
      BT_ERR( "BT OEM L2: unexpect event %x", 
              bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0 );
      return;
    }
  } // end of switch (ev_type)

}

//###############################################################################################################
#if 1 // 2006-09-16 Server Open Sequence ��� ����(LX550 ����)

int System_BT_L2_Enable( uint8 handle, BTL2ConfigInfo* info )
{
  System_BT_L2obj_t *pMe;
  System_BT_L2obj_Handle_t *pHandleMgr;
  int rv;
  uint16 uuid;
  char *srv_name = "System_BT_L2CAP";
  
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__"Handle:%d, info->psm", handle, info->psm, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pMe[0x%x] == NULL �ߡ�", pMe, 0, 0); 	
    return PDK_L2_ERROR;
  }

  pHandleMgr = System_BT_L2_FindHandleMgrbyHandle( handle );
  if( pHandleMgr == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pHandleMgr == NULL �ߡ�", 0, 0, 0);
    return PDK_L2_UNSPECIFIED_ERROR;
  }  
  
  //uuid = 0x0100;	//060225 caravine L2CAP UUID is default in case of no 16bit UUID input
  uuid = LGOEM_BT_SD_PROTOCOL_L2CAP;
  pL2_OpenHandle = pHandleMgr->nHandle; // LEECHANGHOON 2008-1-18 L2_OPEN_SUCCESS�� Handle�� �������ֱ� ����.

  /* register service */
  //bt_cmd_sd_register_serv_ext(pMe->appId, 
  //								uuid, 
  //								L2CAP_REGISTER_VERSION, L2CAP_SCN, 
  //								info->psm, 
  //								TRUE, 
  //								srv_name);
  System_BT_L2_SetParams( handle, info->psm, info );

  rv = System_BT_L2_Register( handle, info->psm );
  BT_MSG_HIGH(__func__"      �ߡ� RETURN rv[0x%x] �ߡ�", rv, 0, 0); 	

  if(rv == PDK_L2_ERR_NONE)
  {
    pHandleMgr->bServer = TRUE;
  }
  

  BT_MSG_HIGH(__func__"      �ߡ� pL2_OpenHandle [0x%x] �ߡ�", pL2_OpenHandle, 0, 0); 	
  
  return rv;
}

// 2007-02-13 : LX550 ���� ������ �߰� 
int System_BT_L2_Disable(
  uint8 handle
)
{
  extern mbt_jsr82_app_id;	
  System_BT_L2obj_t *pMe;
  System_BT_L2obj_Handle_t *pHandleMgr;
  uint16 uuid;
  int rv;

  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_L2_FindMebyHandle( handle );
  if( pMe == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pMe[0x%x] == NULL �ߡ�", pMe, 0, 0); 	
    return PDK_L2_ERROR;
  }
  
  pHandleMgr = System_BT_L2_FindHandleMgrbyHandle( handle );
  if( pHandleMgr == NULL )
  {
    BT_MSG_HIGH(" �ߡ� pHandleMgr == NULL �ߡ�", 0, 0, 0);
    return PDK_L2_UNSPECIFIED_ERROR;
  }  

  uuid = 0x0100;
    
  System_BT_L2_Deregister(handle);
  
  BT_MSG_HIGH(" �ߡ� INPUT appId[0x%x] uuid[0x%x] psm[0x%x] �ߡ�  chosw0213", pMe->appId, uuid, pMe->sConfigInfo.psm); 	
  
  //bt_cmd_sd_unregister_srv_by_psm(pMe->appId, uuid, pMe->sConfigInfo.psm);
  //bt_cmd_sd_unregister_srv_by_psm(pMe->appId, uuid, BT_L2_PSM_SDP);
  //rv = bt_cmd_sd_unregister_service(pMe->appId, uuid);

  // Unregister SD record.
  if (pMe->uuid != BT_SD_SERVICE_CLASS_SERIAL_PORT) 
  {
    rv = bt_cmd_sd_unregister_service(mbt_jsr82_app_id, pMe->uuid);
  }
  else
  {
    rv = bt_cmd_sd_unregister_custom_service(mbt_jsr82_app_id, &pMe->uuid128);		
  }

  pHandleMgr->bServer = FALSE;
  return rv;

}

/*
LOCAL void System_BT_L2_Unregister(
  uint8 handle, 
  int psm
)
{
  //bt_l2_reg_table_type *reg_ptr;	
  System_BT_L2obj_t *pMe;
  System_BT_L2obj_t *pSamePSM;
  
//  pMe = &gMe; 
  pMe = System_BT_L2_FindMebyHandle( handle );
  
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__, 0, 0, 0);
  BT_MSG_HIGH( "-------------------------------------------", 0, 0, 0);
  BT_MSG_HIGH( __func__" �ߡߡߡ� appId[0x%x]", pMe->appId, 0, 0);
  
  if( ((pSamePSM = System_BT_L2_FindMe_byPSM( BT_L2_PSM_SDP )) != NULL )||(psm == BT_L2_PSM_SDP))
  //if(( ((bt_l2_reg_table_type *)reg_ptr = bt_l2_find_reg_table_entry_psm(psm )) != NULL ) &&
  //    ( reg_ptr->bt_app_id != pMe->appId ) && (reg_ptr->psm == BT_L2_PSM_SDP))  
  {
    //BT_MSG_HIGH( __func__" �ߡߡߡ� SDP_PSM Unregister reg_ptr->bt_app_id[0x%x]", reg_ptr->bt_app_id, 0, 0);  	
    //bt_cmd_l2_unregister( reg_ptr->bt_app_id, BT_L2_PSM_SDP );
    BT_MSG_HIGH( __func__" �ߡߡߡ� SDP_PSM Unregister pSamePSM->appId[0x%x]", pSamePSM->appId, 0, 0);  	
    bt_cmd_l2_unregister( 0x04, BT_L2_PSM_SDP );	// bt_sd_app_id
  }
  else
  {
    BT_MSG_HIGH( __func__" �ߡߡߡ� No SDP_PSM", 0, 0, 0);  	  	
  }	
}
*/

#endif // 2006-09-16 ���� Open Sequence ��� ����(LX550 ����)
//##########################################################################################################################

// added by neohacz for multi-point
System_BT_L2obj_t* System_BT_L2_CreateMe()
{
  int index, ret_index;

  for(index=0; index<8; index++)
  {
    if(gMe[index].bUsed == FALSE) break;
  }

  BT_MSG_HIGH(__func__" �ߡ� L2CAP Create pMe : index[%d] �ߡ�", index, 0, 0);

  if(index>7) return NULL;

  ret_index = index;

  gMe[ret_index].bUsed = TRUE;
  for(index=0; index<2; index++)
  {
    gMe[ret_index].HandleMgr[index].nParentHandle= 0;
    gMe[ret_index].HandleMgr[index].nHandle= 0;
    gMe[ret_index].HandleMgr[index].bServer= FALSE;
    gMe[ret_index].HandleMgr[index].cid= BT_L2_NULL_CID;
    gMe[ret_index].HandleMgr[index].pRcvbuf= NULL;
  }

  return &(gMe[ret_index]);
}

boolean System_BT_L2_InsertHandle(System_BT_L2obj_t* pMe, uint8 ParentHandle, uint8 Handle )
{
  int j;

  for(j=0; j<3; j++)
  {
    if(pMe->HandleMgr[j].nHandle == 0) break;
  }

  if(j>2 || pMe->bUsed==FALSE) return FALSE;
  
  pMe->HandleMgr[j].nHandle = Handle;
  pMe->HandleMgr[j].nParentHandle = ParentHandle;

  return TRUE;  
}

uint8 System_BT_L2_FindServerHandlebyMe(System_BT_L2obj_t* pMe)
{
  int j;
  
  for(j=0; j<3; j++)
  {
    if(pMe->HandleMgr[j].bServer) return pMe->HandleMgr[j].nHandle;
  }

  return 0;
}

System_BT_L2obj_t* System_BT_L2_FindMeAndHandleMgrbyHandle(uint8 handle, int* index)
{
  int i, j;

  for(i=0; i<8; i++)
  {
    for(j=0; j<3; j++)
    {
      if(gMe[i].HandleMgr[j].nHandle == handle)
      {
        *index = j;
        return &(gMe[i]);
      }
    }
  }

  return NULL;
}

System_BT_L2obj_t* System_BT_L2_FindMebyHandle(uint8 handle)
{
  int i, j;

  for(i=0; i<8; i++)
  {
    BT_MSG_HIGH(__func__" gMe[%d]", i,0,0);
    for(j=0; j<3; j++)
    {
      BT_MSG_HIGH(__func__" HandleMgr[%d].nHandle : %d ", j,gMe[i].HandleMgr[j].nHandle, 0);

      if(gMe[i].HandleMgr[j].nHandle == handle) 
      	{
              BT_MSG_HIGH(__func__" return   gMe[%d]",  i,0, 0);
	  	return &(gMe[i]);
      	}
    }
  }

  return NULL;
}

System_BT_L2obj_Handle_t* System_BT_L2_FindHandleMgrbyHandle(uint8 handle)
{
  int i, j;

  for(i=0; i<8; i++)
  {
    for(j=0; j<3; j++)
    {
      if(gMe[i].HandleMgr[j].nHandle == handle) return &(gMe[i].HandleMgr[j]);
    }
  }

  return NULL;
}

System_BT_L2obj_Handle_t* System_BT_L2_FindHandleMgrbyMeAndHandle(System_BT_L2obj_t* pMe, uint8 handle)
{
  int j;

  for(j=0; j<3; j++)
  {
    if(pMe->HandleMgr[j].nHandle == handle) return &(pMe->HandleMgr[j]);
  }

  return NULL;
}

System_BT_L2obj_Handle_t* System_BT_L2_FindHandleMgrbyMeAndCID(System_BT_L2obj_t* pMe, uint16 wCid)
{
  int j;

  for(j=0; j<3; j++)
  {
    if(pMe->HandleMgr[j].cid == wCid) return &(pMe->HandleMgr[j]);
  }

  return NULL;
}

System_BT_L2obj_Handle_t* System_BT_L2_FindHandleMgrbyCID( uint16 wCid )
{
  int i, j;

  for( i=0; i<8; i++ )
  {
    if( gMe[i].bUsed == TRUE )
    {
      for( j=0; j<3; j++)
      {
        if( gMe[i].HandleMgr[j].cid == wCid && gMe[i].HandleMgr[j].nHandle != 0 )
        {
	   return &(gMe[i].HandleMgr[j]);
        }
      }
    }
  }

  return NULL;
}

int System_BT_L2_FindIndexbyHandle(System_BT_L2obj_t* pMe, uint8 handle)
{
  int j;

  for(j=0; j<3; j++)
  {
    if(pMe->HandleMgr[j].nHandle == handle) return j;
  }

  return -1;
}

uint8 System_BT_L2_FindHandlebyCID( uint16 wCid )
{
  int i, j;

  for( i=0; i<8; i++ )
  {
    if( gMe[i].bUsed == TRUE )
    {
      for( j=0; j<3; j++)
      {
        if( gMe[i].HandleMgr[j].cid == wCid && gMe[i].HandleMgr[j].nHandle != 0 )
        {
	   return gMe[i].HandleMgr[j].nHandle;
        }
      }
    }
  }

  return 0;
}

int System_BT_L2_IsFirstCreateMe( void )
{
  int index, cnt = 0;

  for(index=0; index<8; index++)
  {
    if(gMe[index].bUsed == TRUE) cnt++;
  }

  if(cnt == 1) return TRUE;
  return FALSE;
}

int System_BT_L2_DeleteHandle(System_BT_L2obj_t* pMe, uint8 handle)
{
  int j;

  for(j=0; j<3; j++)
  {
    if(pMe->HandleMgr[j].nHandle == handle)
    {
      pMe->HandleMgr[j].nHandle = 0;
      pMe->HandleMgr[j].nParentHandle = 0;
      break;
    }
  }

  if(j>2) return FALSE;

  return TRUE;
}

int System_BT_L2_CheckMeUsed( System_BT_L2obj_t* pMe )
{
  int j;
  boolean bUsed = FALSE;
  
  for(j=0; j<3; j++)
  {
    if( pMe->HandleMgr[j].nHandle> 0 )
      bUsed = TRUE;
  }

  if(bUsed) return TRUE;
  return FALSE;
}

int System_BT_L2_ReleaseMe(System_BT_L2obj_t* pMe)
{
  int j;

  for(j=0; j<3; j++)
  {
    if(pMe->HandleMgr[j].nHandle > 0) break;
  }

  if(j<3) return FALSE;

  pMe->bUsed = FALSE;
  pMe->appId = BT_APP_ID_NULL;
  
  return TRUE;
}

#endif // defined(FEATURE_SYSTEM_BT_JSR82)
