#ifndef _SYSTEM_BT_L2_H_
#define _SYSTEM_BT_L2_H_
/*------------------------------------------------------------------------------
 * Copyright (c) 2006 LG Electronics, Seoul, Republic of KOREA.
 * Any reproduction without written permission is prohibited by law.
 *------------------------------------------------------------------------------
 * Produced by LG Electronics Mobile Communications Company
 *------------------------------------------------------------------------------
 * File     : System_BT_L2.h
 * Project  : QBT
 *------------------------------------------------------------------------------
 * Description:
 *  Header of L2
 *------------------------------------------------------------------------------
 */

//==========================================================================
//   Type definitions
//==========================================================================
typedef struct System_BT_L2obj_Handle_struct
{
  uint8 nParentHandle;
  uint8 nHandle;
  uint16 cid;
  BTBDAddr bdAddr;
  boolean bServer;
  bt_cmd_status_type CmdDoneStatus;

  // Rcv Data associated with this connection
  dsm_item_type*     pRcvbuf;
} System_BT_L2obj_Handle_t;

typedef struct System_BT_L2obj_struct
{
  // Variables to keep track of BT core info
  bt_app_id_type     appId;
  BTL2ConfigInfo     sConfigInfo;


  // added by neohacz 
  boolean                 bUsed;
  System_BT_L2obj_Handle_t HandleMgr[3];

  uint16                uuid;       	             //yucha 2008/01/12 �߰� 
  bt_sd_uuid128_type        uuid128;    	//yucha 2008/01/12 �߰�     
} System_BT_L2obj_t;
typedef struct System_BT_L2Accept
{
  uint8               handle;
  uint8               gL2AcceptHandle[2];
  boolean           bUsed;
} System_BT_L2Accept_t;

//
// Only one of these:
//
typedef struct
{
  System_BT_L2obj_t* pNextL2;
} System_BT_L2_Mgr;

//==========================================================================
//   Function prototypes
//==========================================================================

int    System_BT_L2_Init( uint8 handle );

uint32 System_BT_L2_Release( uint8 handle );
uint32 System_BT_L2_ReleaseAll(void);

int32  System_BT_L2_Read( uint8 handle, void* buffer, uint32 bytes );

int    System_BT_L2_Readable( uint8 handle );

void   System_BT_L2_Cancel( uint8 handle, void* pUser );

int    System_BT_L2_Register( uint8 handle, uint32 PSM );

int    System_BT_L2_Deregister( uint8 handle );

int    System_BT_L2_SetParams( uint8 handle, uint16 proto_id, const BTL2ConfigInfo* info );

int    System_BT_L2_Connect( uint8 handle, uint16 proto_id, const BTBDAddr* pBDAddr );

int    System_BT_L2_Disconnect( uint8 handle );

int32  System_BT_L2_Write( uint8 handle, const byte* buf, uint32 length );

void   System_BT_L2_Writable( uint8 handle, void* pUser );

uint16 System_BT_L2_NumConn( uint8 handle, const BTBDAddr *pBdAddr );

uint32 System_BT_L2_Accept( uint8 handle , uint8 peerhandle);

void   System_BT_L2_Handle_Ev_Disc(bt_ev_l2_disconnected_type *ev_l2_disc_ptr);

System_BT_L2obj_t* System_BT_L2_FindMebyHandle(uint8 handle);

#if 1 // 2006-09-16 Server Open Sequence ��� ����(LX550 ����)
int System_BT_L2_Enable( uint8 handle, BTL2ConfigInfo* info );
int System_BT_L2_Disable( uint8 handle );
// void System_BT_L2_Unregister( uint8 handle, int psm );
#endif //2006-09-16 ���� Open Sequence ��� ����(LX550 ����)
//##########################################################################################################################

#endif /* _SYSTEM_BT_L2_H_ */
