/*=========================================================================

FILE:      SYSTEM_BT_SPP.c

Copyright (c) 2006       by LGE All Rights Reserved.

when     who       what, where, why
------   -----     ----------------------------------------------------------
060714   chosw     SPP Created
070319   neohacz   SPP Updated
------   -----     ----------------------------------------------------------
=========================================================================*/

#include "comdef.h"		 
// LEECHANGHOON 2008-1-17 delete under 1 line
//#include "System_BT.h"	

#if defined(FEATURE_SYSTEM_BT_JSR82)
#include "bt.h"
#include "bti.h"
#include "btsio.h"
#include "btsd.h"
#include "btmsg.h"

//#include "..\..\..\..\..\PAL\PhonePal\include\PalDef_OemBt.h"
#include "PalDef_OemBt.h"
#include "qbt_bt_spp.h"

#include "mbt_sdc.h"
#include "mbt_evhandler.h"
#include "../include/mbt_internal_func.h"

// LEECHANGHOON 2008-1-17 delete under 3 line
//#include "System_BT_Var.h"	
//#include "System_BT_DB.h"	
//#include "System_BT_PDK_Handler.h"	

#undef	BUF_MAL_TEST
#undef  BUF_ARR_TEST

//==========================================================================
//   Macro definitions
//==========================================================================

#define WATERMARK_HI           3000
#define WATERMARK_LO           1000
#define WATERMARK_MAX         10000
#define WATERMARK_ENQUEUE_SIZE  200

#define MAX_SPP_STREAMS           5

#define SYSTEM_BT_SPP_NUM_EVENTS   50

//==========================================================================
//   Type definitions
//==========================================================================

static  boolean           gSPP_bIdxTaken[ MAX_SPP_STREAMS ];

static BTSPPOpened		pN_SPPOpened;
static BTSPPConnected		pN_SPPConnected;	
static BTSPPClosed			pN_SPPClosed;		

#ifdef BUF_MAL_TEST
void* SPP_buf;  			// RFCOMM Disconnect�� ���� �ִ� Data�� ���� 
#endif

#ifdef BUF_ARR_TEST
char SPP_buf[2870];  		// RFCOMM Disconnect�� ���� �ִ� Data�� ���� 
#endif

boolean isReading;
uint32						uID = NULL;

//static uint8                gSPPAcceptHandle = 0;
static System_BT_SPPAccept_t  gSPPAccept[8]; // JSR82. OutputStream2020 ����

uint8 pRC_OpenHandle = 0;

boolean gSPP_Release_all = FALSE;
extern MBT_BOOL JSR82BT_enable;


//==========================================================================
//   Function prototypes
//==========================================================================

System_BT_SPPobj_t* System_BT_SPP_CreateMe(uint8 handle);
System_BT_SPPobj_t* System_BT_SPP_FindMebyHandle(uint8 handle);
int System_BT_SPP_FindIndexbyHandle(uint8 handle);
int System_BT_SPP_IsFirstCreateMe(void);
int System_BT_SPP_IsNoneMe(void);
int System_BT_SPP_ReleaseMe(int index);
//fnclamp
void System_BT_SPP_PrintSPPobj(int index);
void System_BT_SPP_PrintSPPobjAll(void);
// static helper functions
static System_BT_SPPobj_t* System_BT_SPP_FindMe( sio_stream_id_type streamID);
static uint16 System_BT_SPP_ConvertBTReason( bt_event_reason_type bt_reason );
static void System_BT_SPP_StatusChangeCB( bt_spp_status_type* pStatus );
static void System_BT_SPP_ConfigChangeCB( bt_spp_cfg_rpt_type* pCfg );
static void System_BT_SPP_ModemStatusCB( bt_spp_ms_type* pModemStatus );
static void System_BT_Spp_LineErrorCB( bt_spp_le_type* pLineError );

static void System_BT_SPP_DataReceived1( void );
static void System_BT_SPP_DataReceived2( void );
static void System_BT_SPP_DataReceived3( void );
static void System_BT_SPP_DataReceived4( void );
static void System_BT_SPP_DataReceived5( void );
static void System_BT_SPP_RxHiWater1( void );
static void System_BT_SPP_RxHiWater2( void );
static void System_BT_SPP_RxHiWater3( void );
static void System_BT_SPP_RxHiWater4( void );
static void System_BT_SPP_RxHiWater5( void );
static void System_BT_SPP_RxLoWater1( void );
static void System_BT_SPP_RxLoWater2( void );
static void System_BT_SPP_RxLoWater3( void );
static void System_BT_SPP_RxLoWater4( void );
static void System_BT_SPP_RxLoWater5( void );
static void System_BT_SPP_TxLoWater1( void );
static void System_BT_SPP_TxLoWater2( void );
static void System_BT_SPP_TxLoWater3( void );
static void System_BT_SPP_TxLoWater4( void );
static void System_BT_SPP_TxLoWater5( void );
static void System_BT_SPP_TxHiWater1( void );
static void System_BT_SPP_TxHiWater2( void );
static void System_BT_SPP_TxHiWater3( void );
static void System_BT_SPP_TxHiWater4( void );
static void System_BT_SPP_TxHiWater5( void );
static void System_BT_SPP_EnableDTR1( void );
static void System_BT_SPP_EnableDTR2( void );
static void System_BT_SPP_EnableDTR3( void );
static void System_BT_SPP_EnableDTR4( void );
static void System_BT_SPP_EnableDTR5( void );
static void System_BT_SPP_FlushTx1( void );
static void System_BT_SPP_FlushTx2( void );
static void System_BT_SPP_FlushTx3( void );
static void System_BT_SPP_FlushTx4( void );
static void System_BT_SPP_FlushTx5( void );

static void System_BT_SPP_store_bt_event( bt_ev_msg_type* bt_ev_ptr );
static uint16 System_BT_SPP_get_max_event_bytes( void );


// Event handler functions:
static void System_BT_SPP_ev_flush_tx( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_enable_dtr( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_tx_lo_wm( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_rx_hi_wm( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_rx_lo_wm( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_rx_gne( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_line_error( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_modem_status( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_config_change( bt_ev_msg_type *bt_ev_ptr );
static void System_BT_SPP_ev_status_change( bt_ev_msg_type *bt_ev_ptr );

// The main event processor:
static void System_BT_SPP_process_ev_queue( void );

// The order of the event handler table must match the order of events
// in bt.h:
static const System_BT_SPP_ev_hndlr_type System_BT_SPP_ev_hndlr_table[] = 
  { System_BT_SPP_ev_flush_tx,
    System_BT_SPP_ev_enable_dtr,
    NULL, /* tx_hi_wm */
    System_BT_SPP_ev_tx_lo_wm,
    NULL, /* tx_gne */
    NULL, /* tx_empty */
    System_BT_SPP_ev_rx_hi_wm,
    System_BT_SPP_ev_rx_lo_wm,
    System_BT_SPP_ev_rx_gne,
    NULL, /* rx_empty */
    System_BT_SPP_ev_line_error,
    System_BT_SPP_ev_modem_status,
    System_BT_SPP_ev_config_change,
    System_BT_SPP_ev_status_change
  };
    
    

//==========================================================================
//   Static data
//==========================================================================
static System_BT_SPPobj_t  gMe[8];

static wm_cb_type non_empty_func_table[ ] =
{
  System_BT_SPP_DataReceived1,
  System_BT_SPP_DataReceived2,
  System_BT_SPP_DataReceived3,
  System_BT_SPP_DataReceived4,
  System_BT_SPP_DataReceived5
};

static wm_cb_type rx_hiwater_func_table[ ] =
{
  System_BT_SPP_RxHiWater1,
  System_BT_SPP_RxHiWater2,
  System_BT_SPP_RxHiWater3,
  System_BT_SPP_RxHiWater4,
  System_BT_SPP_RxHiWater5
};

static wm_cb_type rx_lowater_func_table[ ] =
{
  System_BT_SPP_RxLoWater1,
  System_BT_SPP_RxLoWater2,
  System_BT_SPP_RxLoWater3,
  System_BT_SPP_RxLoWater4,
  System_BT_SPP_RxLoWater5
};

static wm_cb_type tx_hiwater_func_table[ ] =
{
  System_BT_SPP_TxHiWater1,
  System_BT_SPP_TxHiWater2,
  System_BT_SPP_TxHiWater3,
  System_BT_SPP_TxHiWater4,
  System_BT_SPP_TxHiWater5
};

static wm_cb_type tx_lowater_func_table[ ] =
{
  System_BT_SPP_TxLoWater1,
  System_BT_SPP_TxLoWater2,
  System_BT_SPP_TxLoWater3,
  System_BT_SPP_TxLoWater4,
  System_BT_SPP_TxLoWater5
};

static sio_vv_func_ptr_type enable_dtr_func_table[ ] =
{
  System_BT_SPP_EnableDTR1,
  System_BT_SPP_EnableDTR2,
  System_BT_SPP_EnableDTR3,
  System_BT_SPP_EnableDTR4,
  System_BT_SPP_EnableDTR5
};

static sio_vv_func_ptr_type flush_tx_func_table[ ] =
{
  System_BT_SPP_FlushTx1,
  System_BT_SPP_FlushTx2,
  System_BT_SPP_FlushTx3,
  System_BT_SPP_FlushTx4,
  System_BT_SPP_FlushTx5
};

static bt_event_q_info_type Systme_BT_SPP_ev_q_info;
static q_type               Systme_BT_SPP_ev_q;

// Used not for protecting data, but for task synchronisation
static rex_crit_sect_type System_BT_SPP_crit_sect;

//==========================================================================
//   Public Funtions
//==========================================================================

/*===========================================================================

Function:  System_BT_SPP_Init()

Description:
   This is called when an app tries to create an instance

Parameters:

Return Value:  

Componts: None

Side Effects:

===========================================================================*/

int System_BT_SPP_Init_jsr82(
  uint8 handle
)
{
  System_BT_SPPobj_t* pMe;
  uint8 i,index;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

    for ( i=0; i<MAX_SPP_STREAMS; i++ )
    {
      if ( gSPP_bIdxTaken[ i ] == FALSE )
      {
        break;
      }
    }
  for(index=0; index<8; index++)
  {
       MBT_PI( " gSPPAccept[%d].handle:%d  gSPPAcceptHandle:%d", index,gSPPAccept[index].handle,gSPPAccept[index].gSPPAcceptHandle );
	gSPPAccept[index].gSPPAcceptHandle = 0;
	gSPPAccept[index].bUsed =FALSE;
	gSPPAccept[index].handle = 0;
  }	
  pMe = System_BT_SPP_CreateMe( handle );

//TCK. EunYong.
  if( pMe == NULL )
  	MBT_PI("pMe is NULL =============>>> Check. EunYong. ", 0, 0, 0);//chosw 

  gSPP_bIdxTaken[ i ] = TRUE;
  pMe->uIndex         = i;
  pMe->streamID       = SIO_NO_STREAM_ID;

  if(System_BT_SPP_IsFirstCreateMe())
  {
    q_init( &Systme_BT_SPP_ev_q );
    Systme_BT_SPP_ev_q_info.event_q_ptr = &Systme_BT_SPP_ev_q;
    Systme_BT_SPP_ev_q_info.max_q_depth = SYSTEM_BT_SPP_NUM_EVENTS;
    Systme_BT_SPP_ev_q_info.event_q_bit_mask = BT_EVQ_BREW_SPP_B;
    Systme_BT_SPP_ev_q_info.max_event_bytes = System_BT_SPP_get_max_event_bytes();
    bt_ec_register_brew_spp( System_BT_SPP_process_ev_queue );
  }

  return TRUE;
}


int System_BT_SPP_Release(
  uint8 handle
)
{
  extern mbt_jsr82_app_id;
  System_BT_SPPobj_t*  pMe;
  //System_BT_SPPobj_t** ppc;
  int index;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__"        INPUT handle[%d]", handle, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMebyHandle( handle );
  
  if ( pMe != NULL )
  {
    MBT_PI("       pMe->uIndex[0x%x] ", pMe->uIndex, 0, 0);
    index = System_BT_SPP_FindIndexbyHandle( handle );

    MBT_PI("       pMe->streamID[0x%x]", pMe->streamID, 0, 0);
    if ( pMe->streamID != SIO_NO_STREAM_ID )
    {
        // Unregister SD record.
        if (pMe->uuid != MBT_NULL) 
            bt_cmd_sd_unregister_service(mbt_jsr82_app_id, pMe->uuid);
        else
            bt_cmd_sd_unregister_custom_service(mbt_jsr82_app_id, &pMe->uuid128);

      sio_close( pMe->streamID, NULL );

      // just assume sio_close() succeeds
      pMe->streamID = SIO_NO_STREAM_ID;
    }

    System_BT_SPP_ReleaseMe(index);

    if ( System_BT_SPP_IsNoneMe() )
    {
      bt_ec_deregister_brew_spp(System_BT_SPP_process_ev_queue);
    }

    return TRUE;
  }
  return FALSE;
}
void  System_BT_SPP_ReleaseAll(void)
{
  extern mbt_jsr82_app_id;
  System_BT_SPPobj_t*  pMe;
  int index;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__"", 0, 0, 0);
  MBT_PI( __func__" �ߡ� gSPPAccept table initialize. �ߡ� ", 0, 0, 0);  
  for(index=0; index<8; index++)
  {
	gSPPAccept[index].gSPPAcceptHandle = 0;
	gSPPAccept[index].bUsed =FALSE;
	gSPPAccept[index].handle = 0;
  }	
		
  for(index=0; index<8; index++)
  {
	if(gMe[index].bUsed == TRUE) 
	{	
		pMe = &(gMe[index]);
		MBT_PI("       pMe->uIndex   : 0x%x ", pMe->uIndex, 0, 0);
		MBT_PI("       pMe->streamID: 0x%x", pMe->streamID, 0, 0);
		if ( pMe->streamID != SIO_NO_STREAM_ID )
		{
			if(pMe->streamID != SIO_NO_STREAM_ID)
			{
				// Unregister SD record.
				if (pMe->uuid != MBT_NULL) 
					bt_cmd_sd_unregister_service(mbt_jsr82_app_id, pMe->uuid);
				else
					bt_cmd_sd_unregister_custom_service(mbt_jsr82_app_id, &pMe->uuid128);			

				MBT_PI("       sio_close( 0x%x, NULL )!!", pMe->streamID, 0, 0);
				sio_close( pMe->streamID, NULL );
			}

			// just assume sio_close() succeeds
			pMe->streamID = SIO_NO_STREAM_ID;
		}

		System_BT_SPP_ReleaseMe(index);

		/* dkmoon 20070830 block
		if ( System_BT_SPP_IsNoneMe() && JSR82BT_enable == FALSE)
		{
		      bt_ec_deregister_brew_spp(System_BT_SPP_process_ev_queue);
		}
		*/
	}
   }
   
   // dkmoon 20070830_S
   gSPP_Release_all = TRUE;
  
   if ( System_BT_SPP_IsNoneMe() && JSR82BT_enable == FALSE )
   {
         bt_ec_deregister_brew_spp(System_BT_SPP_process_ev_queue);
	  gSPP_Release_all = FALSE;
   }
   // dkmoon 20070830_E
}


int System_BT_SPP_Open( 
  uint8 handle,  
  const BTSppOpenConfig* pOpenCfg
)
{
  sio_open_type       so;
  bt_spp_open_type    bso;
  char                svcName[ BT_SD_MAX_SERVICE_NAME_LEN ];
  System_BT_SPPobj_t  *pMe;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMebyHandle( handle );

  if ( (pMe == NULL) || (pOpenCfg == NULL) )
  {
    MBT_PI( __func__" >>>> pMe=NULL pOpenCfg=NULL ERROR!!", 0, 0, 0);
    return FALSE; 
  }
  
  if ( pOpenCfg->pBDAddr != NULL )
  {
    pMe->BDAddr = *pOpenCfg->pBDAddr;
  }

  if ( pOpenCfg->pSvcName != NULL )
  {

    #if 1  // Wstr -> str ��ȯ func �ϴ� ���´�. 
    memcpy(svcName, pOpenCfg->pSvcName, BT_SD_MAX_SERVICE_NAME_LEN);
  	MBT_PI( __func__" >>>> Server Name = %c%c%c", svcName[0], svcName[1], svcName[2]);
  	MBT_PI( __func__" >>>> Server Name = %c%c%c", svcName[3], svcName[4], svcName[5]);
  	MBT_PI( __func__" >>>> Server Name = %c%c%c", svcName[6], svcName[7], svcName[8]);
	#endif
  }

  /* set up TX watermark */
  (void) q_init( &pMe->tx_q );
  pMe->tx_wm.lo_watermark         = WATERMARK_LO;
  pMe->tx_wm.hi_watermark         = WATERMARK_HI;
  pMe->tx_wm.dont_exceed_cnt      = WATERMARK_MAX;
  pMe->tx_wm.current_cnt          = 0;
  pMe->tx_wm.lowater_func_ptr     = tx_lowater_func_table[ pMe->uIndex ];
  pMe->tx_wm.gone_empty_func_ptr  = NULL;
  pMe->tx_wm.non_empty_func_ptr   = NULL;
  pMe->tx_wm.hiwater_func_ptr     = tx_hiwater_func_table[ pMe->uIndex ];
  pMe->tx_wm.q_ptr                = &pMe->tx_q;

  /* set up RX watermark */
  (void) q_init( &pMe->rx_q );
  pMe->rx_wm.lo_watermark         = WATERMARK_LO;
  pMe->rx_wm.hi_watermark         = WATERMARK_HI;
  pMe->rx_wm.dont_exceed_cnt      = WATERMARK_MAX;
  pMe->rx_wm.current_cnt          = 0;
  pMe->rx_wm.lowater_func_ptr     = rx_lowater_func_table[ pMe->uIndex ];
  pMe->rx_wm.gone_empty_func_ptr  = NULL;
  pMe->rx_wm.non_empty_func_ptr   = non_empty_func_table[ pMe->uIndex ];
  pMe->rx_wm.hiwater_func_ptr     = rx_hiwater_func_table[ pMe->uIndex ];
  pMe->rx_wm.q_ptr                = &pMe->rx_q;
  pMe->dsm_item_ptr               = NULL;

  so.port_id      = SIO_PORT_BT_SPP;
  so.stream_mode  = SIO_GENERIC_MODE;
  so.tx_flow      = SIO_FCTL_OFF;
  so.rx_flow      = SIO_FCTL_OFF;
  so.tx_queue     = &pMe->tx_wm;
  so.rx_queue     = &pMe->rx_wm;
  so.rx_func_ptr  = NULL;
  so.bt_open_ptr  = &bso;

  bso.client_app            = pOpenCfg->bClientApp;
  bso.bd_addr_ptr           = (bt_bd_addr_type*)&pMe->BDAddr;
  bso.service_uuid          = pOpenCfg->uSvcId;
  bso.service_version       = pOpenCfg->uSvcVersion;
  bso.rc_server_channel     = pOpenCfg->uChannelNumber;
  bso.service_name_str_ptr  = ( pOpenCfg->pSvcName != NULL ) ? svcName : NULL;
  bso.max_frame_size        = pOpenCfg->uMaxFrameSize;
  bso.status_change_fptr    = System_BT_SPP_StatusChangeCB;
  bso.config_change_fptr    = System_BT_SPP_ConfigChangeCB;
  bso.modem_status_fptr     = System_BT_SPP_ModemStatusCB;
  bso.line_error_fptr       = System_BT_Spp_LineErrorCB;

  MBT_PI( __func__" ##### rc_server_channel[0x%x]  bClientApp[%d]", bso.rc_server_channel, pOpenCfg->bClientApp, 0);  

  rex_enter_crit_sect( &System_BT_SPP_crit_sect );
  pMe->streamID = SIO_MAX_STREAM; // indicates opening
  pMe->streamID = sio_open( &so );
  rex_leave_crit_sect( &System_BT_SPP_crit_sect );

  pMe->scn = pOpenCfg->uChannelNumber;
  pRC_OpenHandle = handle;

  MBT_PI( __func__" >>>> pMe->streamID[0x%x] ", pMe->streamID , 0, 0);  

  return ( pMe->streamID == SIO_NO_STREAM_ID ) ? FALSE : TRUE;
}

// not used...
int System_BT_SPP_IOCtl( 
  uint8 handle,
  BTIOCtlCommand cmd,
  BTIoCtlParam*  pParam
)
{
  sio_ioctl_cmd_type    ioctl_cmd;
  sio_ioctl_param_type  param;
  bt_spp_status_type    spp_status;
  bt_spp_config_type    spp_cfg;
  System_BT_SPPobj_t    *pMe;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMebyHandle( handle );

  if ( (pMe == NULL) || (cmd >= BT_IOCTL_MAX) )
  {
    return FALSE;
  }

  if ( pMe->streamID == SIO_NO_STREAM_ID )
  {
    return FALSE;
  }

  switch ( cmd )
  {
    case BT_IOCTL_INBOUND_FLOW_ENABLE:
      ioctl_cmd = SIO_IOCTL_INBOUND_FLOW_ENABLE;
      break;
    case BT_IOCTL_INBOUND_FLOW_DISABLE:
      ioctl_cmd = SIO_IOCTL_INBOUND_FLOW_DISABLE;
      break;
    case BT_IOCTL_FLUSH_TX:
      ioctl_cmd = SIO_IOCTL_FLUSH_TX;
      param.record_flush_func_ptr = flush_tx_func_table[ pMe->uIndex ];
      break;
    case BT_IOCTL_CD_ASSERT:
      ioctl_cmd = SIO_IOCTL_CD_ASSERT;
      break;
    case BT_IOCTL_CD_DEASSERT:
      ioctl_cmd = SIO_IOCTL_CD_DEASSERT;
      break;
    case BT_IOCTL_RI_ASSERT:
      ioctl_cmd = SIO_IOCTL_RI_ASSERT;
      break;
    case BT_IOCTL_RI_DEASSERT:
      ioctl_cmd = SIO_IOCTL_RI_DEASSERT;
      break;
    case BT_IOCTL_DSR_ASSERT:
      ioctl_cmd = SIO_IOCTL_DSR_ASSERT;
      break;
    case BT_IOCTL_DSR_DEASSERT:
      ioctl_cmd = SIO_IOCTL_DSR_DEASSERT;
      break;
    case BT_IOCTL_ENABLE_DTR_EVENT:
      ioctl_cmd = SIO_IOCTL_ENABLE_DTR_EVENT;
      param.enable_dte_ready_event = enable_dtr_func_table[ pMe->uIndex ];
      break;
    case BT_IOCTL_GET_DTR:
      if ( pParam == NULL )
      {
		return FALSE;
      }
      ioctl_cmd = SIO_IOCTL_DTE_READY_ASSERTED;
      param.dte_ready_asserted = pParam->pbDTRAsserted;
      break;
    case BT_IOCTL_DISABLE_DTR_EVENT:
      ioctl_cmd = SIO_IOCTL_DISABLE_DTR_EVENT;
      break;
    case BT_IOCTL_GET_RTS:
      if ( pParam == NULL )
      {
		return FALSE;
      }
      ioctl_cmd = SIO_IOCTL_GET_CURRENT_RTS;
      param.rts_asserted = pParam->pbRTSAsserted;
      break;
    case BT_IOCTL_BT_CONFIGURE:
      if ( pParam == NULL )
      {
		return FALSE;
      }
      spp_cfg.baudrate       = pParam->pSppConfig->uBaudRate; 
      spp_cfg.format         = pParam->pSppConfig->uFormat;
      spp_cfg.flow_ctrl      = pParam->pSppConfig->uFlowCtrl;
      spp_cfg.xon_char       = pParam->pSppConfig->uXonChar;
      spp_cfg.xoff_char      = pParam->pSppConfig->uXoffChar;
      spp_cfg.max_frame_size = pParam->pSppConfig->uMaxFrameSize;
      ioctl_cmd = SIO_IOCTL_BT_CONFIGURE;
      param.bt_spp_config_ptr = &spp_cfg;
      break;
    case BT_IOCTL_BT_DISCONNECT:
      ioctl_cmd = SIO_IOCTL_BT_DISCONNECT;
      break;
    case BT_IOCTL_BT_GET_STATUS:
      if ( pParam == NULL )
      {
		return FALSE;
      }
      ioctl_cmd = SIO_IOCTL_BT_GET_STATUS;
      param.bt_spp_status_ptr = &spp_status;
      break;
    default:
      return FALSE;
  }

  sio_ioctl( pMe->streamID, ioctl_cmd, &param );

  if ( cmd == BT_IOCTL_BT_GET_STATUS )
  {
    /*lint -e645*/
    /*lint -e613*/
    if ( BT_BD_ADDRS_EQUAL( &spp_status.bd_addr, &pMe->BDAddr ) == FALSE )
    {
	  return FALSE;
    }
    pParam->pSppStatus->pBDAddr     = &pMe->BDAddr;
    pParam->pSppStatus->uID         = pMe->uIndex;
    pParam->pSppStatus->bClientApp  = spp_status.client_app;
    pParam->pSppStatus->state       = (BTSppState)spp_status.spp_state;
    pParam->pSppStatus->uSvcID      = spp_status.service_uuid;
    pParam->pSppStatus->uSvcVersion = spp_status.service_version;
    pParam->pSppStatus->uReason     = 
      System_BT_SPP_ConvertBTReason( spp_status.spp_reason );
    pParam->pSppStatus->uChannelNumber = spp_status.rc_server_channel;
    /*lint +e613*/
    /*lint +e645*/
  }

  return FALSE;
}


int32 System_BT_SPP_Read( 
  uint8 handle,
  char* pDst, 
  int32 uMaxBytes
)
{
  int32 bytesRead = 0;
  int32 totalBytesRead = 0;
  System_BT_SPPobj_t            *pMe;

  isReading = TRUE;	//chosw
	
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__" ������ INPUT uMaxBytes[0x%x]", uMaxBytes, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMebyHandle( handle );

  if ( (pMe == NULL) || (pDst == NULL) || (uMaxBytes == 0) )
  {
    return BT_STREAM_ERROR;
  }

  if ( pMe->streamID == SIO_NO_STREAM_ID )
  {
    return BT_STREAM_ERROR;
  }

  while (TRUE)
  {
    if ( pMe->dsm_item_ptr != NULL )
    {
      bytesRead = dsm_pullup( &pMe->dsm_item_ptr, (pDst+totalBytesRead), 
                              (uMaxBytes-totalBytesRead) );

	  MBT_PI( __func__" >>>> uMaxBytes[%d] totalBytesRead[%d] uMaxBytes-totalBytesRead[%d]", 
	  	uMaxBytes, totalBytesRead, uMaxBytes-totalBytesRead);

	  MBT_PI( __func__" �¢¢¢� bytesRead[%d] ", bytesRead, 0, 0);
	  

      if ( bytesRead == 0 )
      {
        MSG_ERROR( "System_BT_SPP_Read - dsm_pullup() returned 0", 0, 0, 0 );
      }

      totalBytesRead += bytesRead;
      if ( totalBytesRead >= uMaxBytes ) // destination full?
      {
        break;
      }
      /* dsm_pullup will free the dsm_item after pulling off the last byte */
    }
    if ( pMe->dsm_item_ptr == NULL )  // DSM item has been freed?
    {
      pMe->dsm_item_ptr = dsm_dequeue( &pMe->rx_wm ); // get next one
      if ( pMe->dsm_item_ptr == NULL )  // rx queue is empty?
      {
         MBT_PI( __func__" pMe->dsm_item_ptr == NULL ", 0, 0, 0);
        break;
      }
    }
  }

  MBT_PI( __func__" �¢¢¢� uID[0x%04x], totalBytesRead[%d] �¢¢¢�", uID, totalBytesRead, 0);

//#ifdef SYSTEM_BT_JSR82_SPP_BUFFER // LEECHANGHOON 2008-1-20 MBT���� system_bt.h ���ǵȰ� ����.
  if(uID == PDK_SPP_EVT_DISCONNECTED && (totalBytesRead != 1) )
  {
    MBT_PI( __func__" >>>> PDK_SPP_EVT_DISCONNECTED --> dsm_Free", 0, 0, 0);
    dsm_empty_queue( &pMe->rx_wm );
    dsm_empty_queue( &pMe->tx_wm );
    dsm_free_packet( &pMe->dsm_item_ptr );
  }

  isReading = FALSE;
//#endif
  
  if ( totalBytesRead == 0 )
  {
    return BT_STREAM_WOULDBLOCK;
  }
  else
  {
    return totalBytesRead;
  }
}


int  System_BT_SPP_Readable( 
  uint8 handle
)
{
  int32 dsm_len = 0;
  System_BT_SPPobj_t            *pMe;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);  
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMebyHandle( handle );

  if ((pMe == NULL) || (pMe->streamID == SIO_NO_STREAM_ID))
  {
    return dsm_len;
  }

  rex_enter_crit_sect( &System_BT_SPP_crit_sect );

  // readable?
  //if ( q_cnt( pMe->rx_wm.q_ptr ) > 0 )
  dsm_len = dsm_queue_cnt(&pMe->rx_wm);
  MBT_PI( __func__"-> pMe->rx_wm.q_ptr[0x%x], dsm_len %d", pMe->rx_wm.q_ptr, dsm_len, 0); 

  rex_leave_crit_sect( &System_BT_SPP_crit_sect );

  return dsm_len;
}



int32 System_BT_SPP_Write( 
  uint8 handle,
  char* pSrc, 
  int32 uNumBytes
)
{
  dsm_item_type*  dsm_ptr;
  uint16 count;
  int32 bytesWritten = 0;
  System_BT_SPPobj_t            *pMe;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__"handle:%d", handle, 0, 0); // JSR82. OutputStream2020 ����
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMebyHandle( handle );

  if ( (pMe == NULL) || (pSrc == NULL) )
  {
    return BT_STREAM_ERROR;
  }

  if ( pMe->streamID == SIO_NO_STREAM_ID )
  {
    return BT_STREAM_ERROR;
  }

  while ( (pMe->status.state == BT_SPP_ST_CONNECTED) &&
          pMe->bOKToSend && (uNumBytes > 0) &&
          (dsm_ptr = bt_get_free_dsm_ptr( BT_TL_RFCOMM, 
                                          WATERMARK_ENQUEUE_SIZE )) != NULL )
  {
    count = dsm_pushdown_tail( &dsm_ptr, pSrc, 
                               MIN( WATERMARK_ENQUEUE_SIZE, uNumBytes ), 
                               (dsm_mempool_id_enum_type)dsm_ptr->pool_id );
    MBT_PI( __func__" [fnclamp] dsm_pushdown_tail() count: %d", count, 0, 0);
    sio_transmit(pMe->streamID, dsm_ptr );

    pSrc          += count;
    bytesWritten  += count;
    uNumBytes     -= count;
  }
  
  if ( bytesWritten == 0 )
  {
    MSG_ERROR( "System_BT_SPP_Write - fail=%d dsm=0x%x cnt=%d", pMe->bOKToSend, // JSR82. OutputStream2020 ����
               dsm_ptr, uNumBytes );
    return BT_STREAM_WOULDBLOCK;
  }
  else
  {
    return bytesWritten;
  }
}


int System_BT_SPP_Writeable(
  uint8 handle
)
{
  BOOL					result = FALSE;
  System_BT_SPPobj_t            *pMe;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMebyHandle( handle );

  if ((pMe == NULL) || (pMe->streamID == SIO_NO_STREAM_ID))
  {
    return FALSE;
  }

  rex_enter_crit_sect( &System_BT_SPP_crit_sect );

  // writeable?
  if ( pMe->bOKToSend )
  {
    result =  TRUE;	
  }

  rex_leave_crit_sect( &System_BT_SPP_crit_sect );

  return result;	

}


int System_BT_SPP_Close( 
 	uint8 handle
)
{
  extern mbt_jsr82_app_id;
  System_BT_SPPobj_t            *pMe;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__" [fnclamp] handle:%d", handle, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMebyHandle( handle );

  if ( pMe == NULL )
  {
    MBT_PI( __func__" [fnclamp] System_BT_SPP_FindMebyHandle  Fail", 0, 0, 0);
    return FALSE; //chosw change: <- EBADPARM
  }

  MBT_PI( __func__" >>>> pMe->streamID[%x] <<<<", pMe->streamID, 0, 0);

  if ( pMe->streamID == SIO_NO_STREAM_ID )
  {
      MBT_PI( __func__" [fnclamp] retrun FALSE(streamID:%d) ", pMe->streamID, 0, 0);
    return FALSE; 
  }

  if(pMe->parenthandle > 0)
  {
    MBT_PI(" [fnclamp] sio_ioctl(streamID:%d) ", pMe->streamID, 0, 0);
    // when this is child client of server
    sio_ioctl( pMe->streamID, SIO_IOCTL_BT_DISCONNECT, NULL);
  }
  else
  {
    // when this is server and oriented client

    // Unregister SD record.
    if (pMe->uuid != BT_SD_SERVICE_CLASS_SERIAL_PORT) 
    {
        bt_cmd_sd_unregister_service(mbt_jsr82_app_id, pMe->uuid);
    }
    else
    {
        bt_cmd_sd_unregister_custom_service(mbt_jsr82_app_id, &pMe->uuid128);		
    }
	
    // free all DSM items
    dsm_empty_queue( &pMe->tx_wm );
    dsm_empty_queue( &pMe->rx_wm );
    dsm_free_packet( &pMe->dsm_item_ptr );
    MBT_PI(" [fnclamp] sio_close(streamID:%d) ", pMe->streamID, 0, 0);
    sio_close( pMe->streamID, NULL );
  }

  return TRUE; 
}

// JSR82. OutputStream2020 ����
int System_BT_SPP_Accept( 
  uint8 handle, uint8 peerhandle
)
{
  int i;
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);	
  for(i=0;i<8;i++)
 {
	if(gSPPAccept[i].bUsed==FALSE)
	{
		gSPPAccept[i].gSPPAcceptHandle=peerhandle;
		gSPPAccept[i].handle = handle;
		gSPPAccept[i].bUsed = TRUE;
	  	MBT_PI(__func__"gSPPAccept[i]. handle [%d] ,gSPPAcceptHandle [%d]",i, handle, peerhandle);
		break;
	}
 }
  if(i>7)
  { 
	MBT_PI(__func__" gSPPAcceptHandle[] is full.", 0, 0, 0);
	return FALSE;
  }
  return TRUE;
}

//==========================================================================
//   static helper functions
//==========================================================================
static uint16 System_BT_SPP_ConvertBTReason( bt_event_reason_type bt_reason )
{
  switch ( bt_reason )
  {
    case BT_EVR_GN_SUCCESS:
      return PDK_SPP_ERR_NONE;
    case BT_EVR_SPP_OUT_OF_SERVER_CHANNELS:
    case BT_EVR_SPP_SDP_REGISTRATION_FAILED:
    case BT_EVR_SPP_RFCOMM_REGISTRATION_FAILED:
      return PDK_SPP_ERR_OUT_OF_RESOURCES;
    case BT_EVR_SPP_SDP_TIMEOUT:
      return PDK_SPP_ERR_REMOTE_TIMEOUT;
    default:
      return PDK_SPP_ERR_FAILED;
  }
}

static System_BT_SPPobj_t* System_BT_SPP_FindMe( sio_stream_id_type streamID)
{
  System_BT_SPPobj_t* pSPP = NULL;
  int index;

  if ( streamID != SIO_NO_STREAM_ID )
  {
    for ( index = 0; index < 8; index++ )
    {
      if ( gMe[index].streamID == streamID )
      {
        pSPP = &(gMe[index]);
        break;
      }
    }
  }
  return pSPP;
}

///////////////////////////////////////////////////////////////////////
// Event handler functions:
///////////////////////////////////////////////////////////////////////

//extern lgoem_bt_event_type	ui_bt_event_buf;						
//lgoem_bt_event_type*		ui_bt_event_ptr	= &ui_bt_event_buf;		
static void System_BT_SPP_ev_flush_tx( bt_ev_msg_type *bt_ev_ptr )
{
  System_BT_SPPobj_t*   pMe;
  
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_SPP_FindMe( bt_ev_ptr->ev_msg.ev_spp_flush_tx.stream_id );
  if( pMe )
  {
    uID = PDK_SPP_EVT_TX_FLUSHED;
//    memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));	
//    ui_bt_event_ptr->event_data 	= (void*)&pMe->uIndex;				  

	MBT_PI(__func__" ������ PDK_SPP_EVT_TX_FLUSHED ",0,0,0);			 	  	
    MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);	

//    bt_send_ui_cmd(uID, ui_bt_event_ptr);	
  }
}

static void System_BT_SPP_ev_enable_dtr( bt_ev_msg_type *bt_ev_ptr )
{
  System_BT_SPPobj_t*   pMe;
  
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_SPP_FindMe( bt_ev_ptr->ev_msg.ev_spp_enable_dtr.stream_id );
  if( pMe )
  {
    uID = PDK_SPP_EVT_DTR_CHANGED;
//    memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));	
//    ui_bt_event_ptr->event_data 	= (void*)&pMe->uIndex;				  

	MBT_PI(__func__" ������ PDK_SPP_EVT_DTR_CHANGED ",0,0,0);			 		  	
    MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);	

//    bt_send_ui_cmd(uID, ui_bt_event_ptr);	
  }
}

static void System_BT_SPP_ev_tx_lo_wm( bt_ev_msg_type *bt_ev_ptr )
{
  System_BT_SPPobj_t*   pMe;
    
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_SPP_FindMe( bt_ev_ptr->ev_msg.ev_spp_tx_lo_wm.stream_id );
  if( (pMe != NULL) && (pMe->status.state == BT_SPP_ST_CONNECTED) )
  {
    pMe->bOKToSend = TRUE;
  }
}

static void System_BT_SPP_ev_rx_hi_wm( bt_ev_msg_type *bt_ev_ptr )
{
  
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  
  sio_ioctl( bt_ev_ptr->ev_msg.ev_spp_rx_hi_wm.stream_id, 
             SIO_IOCTL_INBOUND_FLOW_DISABLE, NULL );
}

static void System_BT_SPP_ev_rx_lo_wm( bt_ev_msg_type *bt_ev_ptr )
{
  
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  

  sio_ioctl( bt_ev_ptr->ev_msg.ev_spp_rx_lo_wm.stream_id, 
             SIO_IOCTL_INBOUND_FLOW_ENABLE, NULL );
}

static void System_BT_SPP_ev_rx_gne( bt_ev_msg_type *bt_ev_ptr )
{
  System_BT_SPPobj_t*   pMe;
  uint8				    event_index = NULL; 
  T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
  
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
	
  pMe = System_BT_SPP_FindMe( bt_ev_ptr->ev_msg.ev_spp_rx_gne.stream_id );
  if( pMe )
  {
	uID = PDK_SPP_EVT_RX_RECEIVED;											
    //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));		
    //ui_bt_event_ptr->event_data 	= (void*)&pMe->lineError;				  
	MBT_PI(" ������ PDK_SPP_EVT_RX_RECEIVED ",0,0,0);			
	BT_BDA( MSG_HIGH, "    >>>> DATA Receive bdAddr",(bt_bd_addr_type *)&pMe->BDAddr);

	//memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type)); // LEECHANGHOON 2008-1-20 MBT���� ����
	//ui_bt_event_ptr->event_data = &pMe->handle;    // LEECHANGHOON 2008-1-20 MBT���� ����

	event_index = mbt_jsr82_getEmptyIdx();
	
	if(event_index == -1)
	{
		MBT_FATAL("EVENT INFO NO FREE SPACE...");
		mbt_postevent(MBTEVT_JSR82_RFCOMM_READ_FAIL, 0);
		return;
	}
	else
	{
		sdcJSR82Status->EvInfo[event_index].Used = TRUE;
		sdcJSR82Status->EvInfo[event_index].ClientHandle = pMe->handle;
		memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)pMe->BDAddr.uAddr, MBT_BDADDR_LEN);
	}
	  
    MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);	

    //bt_send_ui_cmd(uID, ui_bt_event_ptr); // LEECHANGHOON 2008-1-20 MBT���� ����
    mbt_postevent(MBTEVT_JSR82_RFCOMM_READ_SUCCESS, event_index);
  }
}

static void System_BT_SPP_ev_line_error( bt_ev_msg_type *bt_ev_ptr )
{
  System_BT_SPPobj_t*   pMe;
  bt_spp_le_type*     line_error_ptr = 
    &bt_ev_ptr->ev_msg.ev_spp_line_error.line_error;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  
  pMe = System_BT_SPP_FindMe( line_error_ptr->stream_id );
  if( pMe )
  {
    switch ( line_error_ptr->cur_line_error )
    {
      case BT_SPP_LE_NONE:
        pMe->lineError.lineErrorType  = PDK_SPP_LE_NONE;
        break;
      case BT_SPP_LE_OVERRUN_ERROR:
        pMe->lineError.lineErrorType  = PDK_SPP_LE_OVERRUN_ERROR;
        pMe->lineError.overruns       = line_error_ptr->overruns;
        break;
      case BT_SPP_LE_PARITY_ERROR:
        pMe->lineError.lineErrorType  = PDK_SPP_LE_PARITY_ERROR;
        pMe->lineError.parityErrors   = line_error_ptr->parity_errors;
        break;
      case BT_SPP_LE_FRAMING_ERROR:
        pMe->lineError.lineErrorType  = PDK_SPP_LE_FRAMING_ERROR;
        pMe->lineError.framingErrors  = line_error_ptr->framing_errors;
        break;
      default:
        return;
    }
	
	uID = PDK_SPP_EVT_LINE_ERROR;
//    memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));		
//    ui_bt_event_ptr->event_data 	= (void*)&pMe->lineError;				  

	MBT_PI(__func__" ������ PDK_SPP_EVT_LINE_ERROR ",0,0,0);			 			  	
    MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);	

//    bt_send_ui_cmd(uID, ui_bt_event_ptr);										
  }
}


static void System_BT_SPP_ev_modem_status( bt_ev_msg_type *bt_ev_ptr )
{
  System_BT_SPPobj_t*   pMe;
  bt_spp_ms_type*     modem_status_ptr = 
    &bt_ev_ptr->ev_msg.ev_spp_modem_status.modem_status;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  

  pMe = System_BT_SPP_FindMe( modem_status_ptr->stream_id );
  if( pMe )
  {
    pMe->modemStatus.uID          = pMe->uIndex;
    pMe->modemStatus.changedMask  = 
      (BTModemStatusBitmap) modem_status_ptr->ms_changed_mask;
    pMe->modemStatus.status       = 
      (BTModemStatusBitmap) modem_status_ptr->modem_status;
    pMe->modemStatus.breakPresent = modem_status_ptr->break_present;
    pMe->modemStatus.breakLength  = modem_status_ptr->break_length;
    pMe->modemStatus.breaks       = modem_status_ptr->breaks;

	uID = PDK_SPP_EVT_MODEM_STATUS;
    //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));		
    //ui_bt_event_ptr->event_data 	= (void*)&pMe->modemStatus;				  
	//MBT_PI(__func__" ������ PDK_SPP_EVT_MODEM_STATUS ",0,0,0);			 		  	
    //MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);			
    //bt_send_ui_cmd(uID, ui_bt_event_ptr);											
  }
}

static void System_BT_SPP_ev_config_change( bt_ev_msg_type *bt_ev_ptr )
{
  System_BT_SPPobj_t*    pMe;
  bt_spp_cfg_rpt_type* config_ptr =
    &bt_ev_ptr->ev_msg.ev_spp_config_change.config_change;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  pMe = System_BT_SPP_FindMe( config_ptr->stream_id );
  if( pMe )
  {
    pMe->config.uID           = pMe->uIndex;
    pMe->config.uBaudRate     = config_ptr->spp_config.baudrate;
    pMe->config.uFormat       = config_ptr->spp_config.format;
    pMe->config.uFlowCtrl     = config_ptr->spp_config.flow_ctrl;
    pMe->config.uXonChar      = config_ptr->spp_config.xon_char;
    pMe->config.uXoffChar     = config_ptr->spp_config.xoff_char;
    pMe->config.uMaxFrameSize = config_ptr->spp_config.max_frame_size;

	uID = PDK_SPP_EVT_CONFIG_CHANGED;
    //memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));		
    //ui_bt_event_ptr->event_data 	= (void*)&pMe->config;				  
	MBT_PI(__func__" ������ PDK_SPP_EVT_CONFIG_CHANGED ",0,0,0);			 
    //MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);	
    //bt_send_ui_cmd(uID, ui_bt_event_ptr);										
  }
}

static void System_BT_SPP_ev_status_change( bt_ev_msg_type *bt_ev_ptr )
{
	int                   event_index = NULL;
	//uint8                 check_index = NULL; 
	int16                 bufsize ;
	int i; // JSR82. gSPPAccept ����
	System_BT_SPPobj_t*   pMe;
	bt_spp_status_type* pStatus =
	&bt_ev_ptr->ev_msg.ev_spp_status_change.status_change;


	MBT_PI( "-------------------------------------------", 0, 0, 0);
	MBT_PI( __func__, 0, 0, 0);
	System_BT_SPP_PrintSPPobjAll();
	MBT_PI( "-------------------------------------------", 0, 0, 0);


	uID = NULL;		
	//memset((byte*)ui_bt_event_ptr, 0x0, sizeof(lgoem_bt_event_type));

	// dkmoon 20070830_S
	if(pStatus->spp_state == BT_SPP_ST_CLOSED)
	{
		MBT_PI(__func__" JSR82BT_enable (%d)  gSPP_Release_all (%d)", JSR82BT_enable, gSPP_Release_all, 0);
		if(JSR82BT_enable == TRUE && gSPP_Release_all == TRUE)
		{
			// dereg
			bt_ec_deregister_brew_spp(System_BT_SPP_process_ev_queue);
			MBT_PI(__func__" BT On, JSR82 Off -->  BT Service Enable ", 0, 0, 0);
#if 0 // LEECHANGHOON 2008-1-20 MBT���� ���� //�ٸ� ���� disable ��Ű�� ��ƾ�� dual �������� ���ŵ�.
			System_BT_NA_Enable();
			System_BT_SPP_Enable();
			System_BT_OPP_Server_Service_Enable();
			System_BT_FTP_Server_Service_Enable();
			System_BT_AG_Enable(NULL, AG_AUDIO_DEVICE_HANDSFREE);
#endif
			// dkmoon 20070829 enable �Ϸ�. Flag off.
			JSR82BT_enable = FALSE;
			gSPP_Release_all = FALSE;
		}
	}
	// dkmoon 20070830_E

  	pMe = System_BT_SPP_FindMe( pStatus->stream_id );
	if( pMe )
	{
		MSG_MED( "StatusChangeCB - id=%x st=%x r=%x", 
		pMe->uIndex, pStatus->spp_state, pStatus->spp_reason );
		pMe->BDAddr             = *((BTBDAddr*)&pStatus->bd_addr);
		pMe->streamID           = pStatus->stream_id;

		pMe->status.pBDAddr     = &pMe->BDAddr;
		pMe->status.uID         = pMe->uIndex;
		pMe->status.bClientApp  = pStatus->client_app;
		pMe->status.state       = (BTSppState) pStatus->spp_state;
		pMe->status.uSvcID      = pStatus->service_uuid;
		pMe->status.uSvcVersion = pStatus->service_version;
		pMe->status.uChannelNumber  = pStatus->rc_server_channel;

		switch ( pStatus->spp_state )
		{
			case BT_SPP_ST_CLOSED:
			{
				T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
				MBT_PI(__func__" ������ BT_SPP_ST_CLOSED",0,0,0);	
				pMe->streamID = SIO_NO_STREAM_ID;

				uID = PDK_SPP_EVT_DISCONNECTED;// 2007-01-15 : ���� PDK_SPP_EVT_CLOSED �̳� Disconnect �׽�Ʈ�� ������.

				pN_SPPClosed.handle = pMe->handle;		
				pN_SPPClosed.streamID = pMe->streamID;	

				event_index = mbt_jsr82_getEmptyIdx();

				if(event_index == -1)
				{
					MBT_FATAL("EVENT INFO NO FREE SPACE...");
					mbt_postevent(MBTEVT_JSR82_RFCOMM_CLOSE_FAIL, 0);
					break;
				}
				else
				{
					sdcJSR82Status->EvInfo[event_index].Used = TRUE;
					sdcJSR82Status->EvInfo[event_index].ServerHandle = pMe->handle;
				}

				MBT_PI("     BT_SPP_ST_CLOSED handle[0x%x] streamID[0x%x]", pN_SPPClosed.handle, pN_SPPClosed.streamID, 0);	
				//ui_bt_event_ptr->event_data 	= (void*)&pN_SPPClosed;	// LEECHANGHOON 2008-1-20 MBT���� ����

				MBT_PI("[chosw0321]     BT_SPP_ST_CLOSED ==> System_BT_SPP_Release  CALL ", 0, 0, 0);	

				if( !pMe->status.bClientApp ) // JSR82. gSPPAccept ����
				{
					MBT_PI( " pMe->handle:%d ", pMe->handle,0 ,0);
					for(i=0;i<8;i++)
					{
						if(pMe->handle == gSPPAccept[i].handle)
						{
							MBT_PI( " [CLOSED] gSPPAccept[%d].handle:%d  gSPPAcceptHandle:%d", i,gSPPAccept[i].handle,gSPPAccept[i].gSPPAcceptHandle );
							gSPPAccept[i].gSPPAcceptHandle = 0;
							gSPPAccept[i].bUsed =FALSE;
							gSPPAccept[i].handle = 0;
							break;
						}
					}

				}

				System_BT_SPP_Release(pMe->handle);//chosw 2007-03-21

				MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);	
				System_BT_SPP_PrintSPPobjAll();

				//bt_send_ui_cmd(uID, ui_bt_event_ptr); // LEECHANGHOON 2008-1-20 MBT���� ���� 
				mbt_postevent(MBTEVT_JSR82_RFCOMM_CLOSE_SUCCESS, event_index);
			}
				break;

			case BT_SPP_ST_OPENING:
				MBT_PI(__func__" ������ BT_SPP_ST_OPENING",0,0,0);	
				System_BT_SPP_PrintSPPobjAll();
				return;

			case BT_SPP_ST_OPEN_ERROR:
			{
				T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
				MBT_PI(__func__" ������ BT_SPP_ST_OPEN_ERROR",0,0,0);	
				uID = PDK_SPP_EVT_OPENED;

				pMe->status.uReason = System_BT_SPP_ConvertBTReason( pStatus->spp_reason );
				MBT_PI(__func__" --> Error reason : [0x%x]", pStatus->spp_reason, 0, 0 );

				pN_SPPOpened.handle = pMe->handle;
				pN_SPPOpened.bSuccess= FALSE;

				event_index = mbt_jsr82_getEmptyIdx();

				if(event_index == -1)
				{
					MBT_FATAL("EVENT INFO NO FREE SPACE...");
					mbt_postevent(MBTEVT_JSR82_RFCOMM_OPEN_FAIL, 0);
					break;
				}
				else
				{
					sdcJSR82Status->EvInfo[event_index].Used = TRUE;
					sdcJSR82Status->EvInfo[event_index].ServerHandle = pMe->handle;
				}
				//ui_bt_event_ptr->event_data 	= (void*)&pN_SPPOpened; // LEECHANGHOON 2008-1-20 MBT���� ����

				MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);
				System_BT_SPP_PrintSPPobjAll();
				//bt_send_ui_cmd(uID, ui_bt_event_ptr); // LEECHANGHOON 2008-1-20 MBT���� ����.
				mbt_postevent(MBTEVT_JSR82_RFCOMM_OPEN_FAIL, event_index);
			}
			break;

			case BT_SPP_ST_OPEN:
			{
				T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
				MBT_PI(__func__" ������ BT_SPP_ST_OPEN",0,0,0);	

				pMe->bOKToSend = FALSE;
				dsm_empty_queue( &pMe->tx_wm );
				dsm_empty_queue( &pMe->rx_wm );
				dsm_free_packet( &pMe->dsm_item_ptr );

				event_index = mbt_jsr82_getEmptyIdx();

				if(pStatus->spp_reason != BT_EVR_GN_SUCCESS)
				{
					if(event_index == -1)
					{
						MBT_FATAL("EVENT INFO NO FREE SPACE...");
/*
						if(pMe->status.bClientApp == FALSE) 
						{
							mbt_postevent(MBTEVT_JSR82_RFCOMM_CLOSE_FAIL, 0);
						}
						else
						{
							mbt_postevent(MBTEVT_JSR82_RFCOMM_DISCONNECT_FAIL, 0);
						}
*/						
						break;
					}
					else
					{			
						if( !pMe->status.bClientApp )//Client ���忡�� ��������, Client�� ������ ������ ���� ���.
						{
							MBT_PI( " pMe->handle:%d ", pMe->handle,0 ,0);
							for(i=0;i<8;i++) // JSR82. gSPPAccept ����
							{
								if(pMe->handle == gSPPAccept[i].handle)
								{
									MBT_PI( " [OPEN] gSPPAccept[%d].handle:%d  gSPPAcceptHandle:%d ", i,gSPPAccept[i].handle,gSPPAccept[i].gSPPAcceptHandle );
									gSPPAccept[i].gSPPAcceptHandle = 0;
									gSPPAccept[i].bUsed =FALSE;
									gSPPAccept[i].handle = 0;
									break;
								}
							}
							sdcJSR82Status->EvInfo[event_index].ClientHandle = pMe->handle;
							pMe->handle = pMe->parenthandle;
							pMe->parenthandle = 0;
						}
						else
							sdcJSR82Status->EvInfo[event_index].ClientHandle = pMe->handle;

						pMe->status.uReason = pStatus->spp_reason;
						pN_SPPClosed.handle = pMe->handle;		
						pN_SPPClosed.streamID = pMe->streamID;			

						sdcJSR82Status->EvInfo[event_index].Used = TRUE;
						memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)&pMe->BDAddr.uAddr, MBT_BDADDR_LEN);
						MBT_PI("	 MBTEVT_JSR82_RFCOMM_DISCONNECT  handle[0x%x] streamID[0x%x]", sdcJSR82Status->EvInfo[event_index].ClientHandle, pN_SPPClosed.streamID, 0);	
						mbt_postevent(MBTEVT_JSR82_RFCOMM_DISCONNECT_SUCCESS, event_index);
						
					}
				}
				else
				{
					if(event_index == -1)
					{
						MBT_FATAL("EVENT INFO NO FREE SPACE...");
//						mbt_postevent(MBTEVT_JSR82_RFCOMM_OPEN_FAIL, 0);
						break;
					}
					else
					{
						sdcJSR82Status->EvInfo[event_index].Used = TRUE;
						sdcJSR82Status->EvInfo[event_index].Val.SCN = pMe->status.uChannelNumber;
						sdcJSR82Status->EvInfo[event_index].ServerHandle = pMe->handle;
						//yucha �߰�. 
						memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)&pMe->BDAddr.uAddr, MBT_BDADDR_LEN);
						pMe->status.uReason = PDK_SPP_ERR_NONE;

						pN_SPPOpened.handle = pMe->handle;
						pN_SPPOpened.bSuccess= TRUE;

						mbt_postevent(MBTEVT_JSR82_RFCOMM_OPEN_SUCCESS, event_index);
						MBT_PI("	 BT_SPP_ST_OPEN handle[0x%x] ", pN_SPPOpened.handle, 0, 0);	
					}
				}

				System_BT_SPP_PrintSPPobjAll();
			}
				break;

			case BT_SPP_ST_CONNECTED: // JSR82. OutputStream2020 ����
			{
				T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
				MBT_PI(__func__" ������ BT_SPP_ST_CONNECTED",0,0,0);	
				MBT_PI( " pMe->status.bClientApp:%d ", pMe->status.bClientApp,0,0 );
				if( !pMe->status.bClientApp )
				{
					int i;
					pMe->parenthandle = pMe->handle;
					MBT_PI( " pMe->handle:%d ", pMe->handle,0 ,0);

					for(i=0;i<8;i++) // JSR82. gSPPAccept ����
					{
						if(pMe->handle == gSPPAccept[i].handle)
						{
							MBT_PI( " [CONNECTED] gSPPAccept[%d].handle:%d  gSPPAcceptHandle:%d", i,gSPPAccept[i].handle,gSPPAccept[i].gSPPAcceptHandle );
							pMe->handle = gSPPAccept[i].gSPPAcceptHandle;
							gSPPAccept[i].gSPPAcceptHandle = 0;
							gSPPAccept[i].bUsed =FALSE;
							gSPPAccept[i].handle = 0;
							break;
						}
					}

				}

				pMe->bOKToSend = TRUE;
				pN_SPPConnected.handle = pMe->handle;		
				pN_SPPConnected.bOKToSend = pMe->bOKToSend;			
				memcpy(&pN_SPPConnected.bdAddr, &pMe->BDAddr, 6); // pMe->bdAddr�� connected bdaddr �߰� 

				event_index = mbt_jsr82_getEmptyIdx();

				if(event_index == -1)
				{
					MBT_FATAL("EVENT INFO NO FREE SPACE...");
					mbt_postevent(MBTEVT_JSR82_RFCOMM_CONNECT_FAIL, 0);
					break;
				}
				else
				{
					sdcJSR82Status->EvInfo[event_index].Used = TRUE;
					sdcJSR82Status->EvInfo[event_index].ClientHandle = pMe->handle;
					memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)&pMe->BDAddr.uAddr, MBT_BDADDR_LEN);
				}

				BT_BDA( MSG_HIGH, " PDK_SPP_EVT_CONNECTED pMe->bdAddr ", (bt_bd_addr_type *)&pMe->BDAddr );

				uID = PDK_SPP_EVT_CONNECTED;
				//ui_bt_event_ptr->event_data 	= (void*)&pN_SPPConnected;	 // LEECHANGHOON 2008-1-20 MBT���� ����
				MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);	
				System_BT_SPP_PrintSPPobjAll();
				//bt_send_ui_cmd(uID, ui_bt_event_ptr); // LEECHANGHOON 2008-1-20 MBT���� ����
				mbt_postevent(MBTEVT_JSR82_RFCOMM_CONNECT_SUCCESS, event_index);
			}
			break;
			
			case BT_SPP_ST_DISCONNECTING:
				MBT_PI(__func__" ������ BT_SPP_ST_DISCONNECTING",0,0,0);	
				pMe->bOKToSend = FALSE;
				return;

			case BT_SPP_ST_DISCONNECTED:
			{
				T_MBT_JSR82_STATUS* sdcJSR82Status = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
				MBT_PI(__func__" ������ BT_SPP_ST_DISCONNECTED",0,0,0);	

				if( !pMe->status.bClientApp )
				{
					MBT_PI( " pMe->handle:%d ", pMe->handle,0 ,0);
					for(i=0;i<8;i++) // JSR82. gSPPAccept ����
					{
						if(pMe->handle == gSPPAccept[i].handle)
						{
							MBT_PI( " [DISCONNECTED] gSPPAccept[%d].handle:%d  gSPPAcceptHandle:%d ", i,gSPPAccept[i].handle,gSPPAccept[i].gSPPAcceptHandle );
							gSPPAccept[i].gSPPAcceptHandle = 0;
							gSPPAccept[i].bUsed =FALSE;
							gSPPAccept[i].handle = 0;
							break;
						}
					}
					pMe->handle = pMe->parenthandle;
					pMe->parenthandle = 0;
				}

				pMe->bOKToSend = FALSE;
				uID = PDK_SPP_EVT_DISCONNECTED;

				//#ifdef SYSTEM_BT_JSR82_SPP_BUFFER	// LEECHANGHOON 2008-1-20 MBT���� system_bt.h ���ǵȰ� ����.
				pMe->dsm_item_ptr = dsm_dequeue( &pMe->rx_wm );
				MBT_PI(" PDK_SPP_EVT_DISCONNECTED >> pMe->dsm_item_ptr[0x%x]",pMe->dsm_item_ptr,0,0);	
				//2006-01-05 : dms�� Data ���� ���� �� 
				if((bufsize = dsm_length_packet(pMe->dsm_item_ptr)) != 0)
				{
					MBT_PI(" ######### No Empty >> bufsize[0x%x]",bufsize,0,0);	
					isReading = TRUE;//dms�� Data ���� ���� �� TRUE
				}		

				if(isReading != TRUE)	
				{
					dsm_empty_queue( &pMe->rx_wm );
					dsm_empty_queue( &pMe->tx_wm );
					dsm_free_packet( &pMe->dsm_item_ptr );
				}
				//#endif
				pN_SPPClosed.handle = pMe->handle;		
				pN_SPPClosed.streamID = pMe->streamID;	

				event_index = mbt_jsr82_getEmptyIdx();

				if(event_index == -1)
				{
					MBT_FATAL("EVENT INFO NO FREE SPACE...");
					if(pMe->status.bClientApp == FALSE) 
					{
						mbt_postevent(MBTEVT_JSR82_RFCOMM_CLOSE_FAIL, 0);
					}
					else
					{
						mbt_postevent(MBTEVT_JSR82_RFCOMM_DISCONNECT_FAIL, 0);
					}
					
					break;
				}
				else
				{			
					if(pMe->status.bClientApp == FALSE) //Server���忡�� Client�� ���� ���.
					{
						sdcJSR82Status->EvInfo[event_index].Used = TRUE;
						sdcJSR82Status->EvInfo[event_index].ServerHandle = pMe->handle;
						memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)&pMe->BDAddr.uAddr, MBT_BDADDR_LEN);
						mbt_postevent(MBTEVT_JSR82_RFCOMM_CLOSE_SUCCESS, event_index);
					}
					else //Client ���忡�� ��������, Client�� ������ ������ ���� ���.
					{
						sdcJSR82Status->EvInfo[event_index].Used = TRUE;
						sdcJSR82Status->EvInfo[event_index].ClientHandle = pMe->handle;
						memcpy((uint8*)sdcJSR82Status->EvInfo[event_index].BDAddr, (uint8*)&pMe->BDAddr.uAddr, MBT_BDADDR_LEN);
						mbt_postevent(MBTEVT_JSR82_RFCOMM_DISCONNECT_SUCCESS, event_index);
					}
				}

				//ui_bt_event_ptr->event_data 	= (void*)&pN_SPPClosed;	// LEECHANGHOON 2008-1-20 MBT���� ����

				MBT_PI("     BT_SPP_ST_DISCONNECTED handle[0x%x] streamID[0x%x]", pN_SPPClosed.handle, pN_SPPClosed.streamID, 0);	
				System_BT_SPP_Release(pMe->handle); //JSR82 Release���� ���� ����.
				
				MBT_PI(__func__" --> bt_send_ui_cmd uID[0x%x]",uID,0,0);	
				System_BT_SPP_PrintSPPobjAll();
				//bt_send_ui_cmd(uID, ui_bt_event_ptr); // LEECHANGHOON 2008-1-20 MBT���� ����        
				
			}
				break;

			default:
				return;
		}
	}
}

static void System_BT_SPP_process_ev_queue( void )
{
  ////////////////////////////////////////////////////////
  // This function is called from the BT task's signal
  // processing loop.
  ////////////////////////////////////////////////////////
  bt_ev_msg_type*  bt_ev_ptr;
  uint16           idx;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  
  BT_VSTAT_MAX( (q_cnt( &Systme_BT_SPP_ev_q )), OEMBTEXTSPP_MAX_EV_Q_DEPTH );
  
  while ( (bt_ev_ptr = (bt_ev_msg_type *) q_get( &Systme_BT_SPP_ev_q ) ) != NULL )
  {
    idx = bt_ev_ptr->ev_hdr.ev_type - BT_CMD_EV_SP_BASE;

    MBT_PI( __func__" >>>> idx[0x%x]", idx, 0, 0);
	
    if( System_BT_SPP_ev_hndlr_table[ idx ] )
    {
      rex_enter_crit_sect( &System_BT_SPP_crit_sect );
      System_BT_SPP_ev_hndlr_table[ idx ]( bt_ev_ptr );
      rex_leave_crit_sect( &System_BT_SPP_crit_sect );
    }
    q_put( &bt_event_free_q, &bt_ev_ptr->ev_hdr.link );
  }
}


////////////////////////////////////////////////////////////////////////////////
// Callbacks from either BT or DSM watermarks
////////////////////////////////////////////////////////////////////////////////

static void System_BT_SPP_StatusChangeCB( bt_spp_status_type* pStatus )
{
  bt_ev_msg_type bt_ev;
  bt_ev.ev_hdr.ev_type = BT_EV_SPP_STATUS_CHANGE;
  bt_ev.ev_msg.ev_spp_status_change.status_change = *pStatus;
  System_BT_SPP_store_bt_event( &bt_ev );
}

static void System_BT_SPP_ConfigChangeCB( bt_spp_cfg_rpt_type* config_ptr )
{
  bt_ev_msg_type bt_ev;
  bt_ev.ev_hdr.ev_type = BT_EV_SPP_CONFIG_CHANGE;
  bt_ev.ev_msg.ev_spp_config_change.config_change = *config_ptr;
  System_BT_SPP_store_bt_event( &bt_ev );
}

static void System_BT_SPP_ModemStatusCB( bt_spp_ms_type* modem_status_ptr )
{
  bt_ev_msg_type bt_ev;
  bt_ev.ev_hdr.ev_type = BT_EV_SPP_MODEM_STATUS;
  bt_ev.ev_msg.ev_spp_modem_status.modem_status = *modem_status_ptr;
  System_BT_SPP_store_bt_event( &bt_ev );
}

static void System_BT_Spp_LineErrorCB( bt_spp_le_type* line_error_ptr )
{
  bt_ev_msg_type bt_ev;
  bt_ev.ev_hdr.ev_type = BT_EV_SPP_LINE_ERROR;
  bt_ev.ev_msg.ev_spp_line_error.line_error = *line_error_ptr;
  System_BT_SPP_store_bt_event( &bt_ev );
}

static void System_BT_SPP_DataReceived( wm_cb_type rx_non_empty_func_ptr )
{
  /////////////////////////////////////////////////////////
  // NOTE: This DSM callback is called with tasks locked //
  /////////////////////////////////////////////////////////

  System_BT_SPPobj_t* pMe;
  bt_ev_msg_type bt_ev;
  boolean    found = FALSE;
  int index;

  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__, 0, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  for ( index = 0; index < 8; index++ )
  {
    pMe = &(gMe[index]);
    MBT_PI( "index(%d), pMe(%x), compare value(%x)", index, pMe->rx_wm.non_empty_func_ptr, rx_non_empty_func_ptr);
	
    if (pMe->rx_wm.non_empty_func_ptr == rx_non_empty_func_ptr)
    {
      found = TRUE;
      bt_ev.ev_hdr.ev_type = BT_EV_SPP_RX_GNE;
      bt_ev.ev_msg.ev_spp_rx_gne.stream_id = pMe->streamID;
      System_BT_SPP_store_bt_event( &bt_ev );
    }
  }
}
static void System_BT_SPP_DataReceived1( void )
{
  System_BT_SPP_DataReceived( System_BT_SPP_DataReceived1 );
}
static void System_BT_SPP_DataReceived2( void )
{
  System_BT_SPP_DataReceived( System_BT_SPP_DataReceived2 );
}
static void System_BT_SPP_DataReceived3( void )
{
  System_BT_SPP_DataReceived( System_BT_SPP_DataReceived3 );
}
static void System_BT_SPP_DataReceived4( void )
{
  System_BT_SPP_DataReceived( System_BT_SPP_DataReceived4 );
}
static void System_BT_SPP_DataReceived5( void )
{
  System_BT_SPP_DataReceived( System_BT_SPP_DataReceived5 );
}

static void System_BT_SPP_RxLoWater( wm_cb_type rx_lowater_func_ptr )
{
  /////////////////////////////////////////////////////////
  // NOTE: This DSM callback is called with tasks locked //
  /////////////////////////////////////////////////////////

  System_BT_SPPobj_t* pMe;
  bt_ev_msg_type bt_ev;
  boolean found = FALSE;
  int index;

  for ( index = 0; index < 8; index++ )
  {
    pMe = &(gMe[index]);
    if ( pMe->rx_wm.lowater_func_ptr == rx_lowater_func_ptr )
    {
      bt_ev.ev_hdr.ev_type = BT_EV_SPP_RX_LO_WM;
      bt_ev.ev_msg.ev_spp_rx_lo_wm.stream_id = pMe->streamID;
      System_BT_SPP_store_bt_event( &bt_ev );
      found = TRUE;
    }
  }
}
static void System_BT_SPP_RxLoWater1( void )
{
  System_BT_SPP_RxLoWater( System_BT_SPP_RxLoWater1 );
}
static void System_BT_SPP_RxLoWater2( void )
{
  System_BT_SPP_RxLoWater( System_BT_SPP_RxLoWater2 );
}
static void System_BT_SPP_RxLoWater3( void )
{
  System_BT_SPP_RxLoWater( System_BT_SPP_RxLoWater3 );
}
static void System_BT_SPP_RxLoWater4( void )
{
  System_BT_SPP_RxLoWater( System_BT_SPP_RxLoWater4 );
}
static void System_BT_SPP_RxLoWater5( void )
{
  System_BT_SPP_RxLoWater( System_BT_SPP_RxLoWater5 );
}

static void System_BT_SPP_RxHiWater( wm_cb_type rx_hiwater_func_ptr )
{
  /////////////////////////////////////////////////////////
  // NOTE: This DSM callback is called with tasks locked //
  /////////////////////////////////////////////////////////

  System_BT_SPPobj_t* pMe;
  bt_ev_msg_type bt_ev;
  boolean found = FALSE;
  int index;

  for ( index = 0; index < 8; index++ )
  {
    pMe = &(gMe[index]);
    if ( pMe->rx_wm.hiwater_func_ptr == rx_hiwater_func_ptr )
    {
      bt_ev.ev_hdr.ev_type = BT_EV_SPP_RX_HI_WM;
      bt_ev.ev_msg.ev_spp_rx_hi_wm.stream_id = pMe->streamID;
      System_BT_SPP_store_bt_event( &bt_ev );

      found = TRUE;
    }
  }
}
static void System_BT_SPP_RxHiWater1( void )
{
  System_BT_SPP_RxHiWater( System_BT_SPP_RxHiWater1 );
}
static void System_BT_SPP_RxHiWater2( void )
{
  System_BT_SPP_RxHiWater( System_BT_SPP_RxHiWater2 );
}
static void System_BT_SPP_RxHiWater3( void )
{
  System_BT_SPP_RxHiWater( System_BT_SPP_RxHiWater3 );
}
static void System_BT_SPP_RxHiWater4( void )
{
  System_BT_SPP_RxHiWater( System_BT_SPP_RxHiWater4 );
}
static void System_BT_SPP_RxHiWater5( void )
{
  System_BT_SPP_RxHiWater( System_BT_SPP_RxHiWater5 );
}

static void System_BT_SPP_TxLowWater( wm_cb_type tx_lowater_func_ptr )
{
  /////////////////////////////////////////////////////////
  // NOTE: This DSM callback is called with tasks locked //
  /////////////////////////////////////////////////////////

  System_BT_SPPobj_t* pMe;
  bt_ev_msg_type bt_ev;
  boolean found = FALSE;
  int index;

  for ( index = 0; index < 8; index++ )
  {
    pMe = &(gMe[index]);
    if ( pMe->tx_wm.lowater_func_ptr == tx_lowater_func_ptr )
    {
      //pMe->bOKToSend = TRUE;
      found = TRUE;
      bt_ev.ev_hdr.ev_type = BT_EV_SPP_TX_LO_WM;
      bt_ev.ev_msg.ev_spp_tx_lo_wm.stream_id = pMe->streamID;
      System_BT_SPP_store_bt_event( &bt_ev );
    }
  }
}
static void System_BT_SPP_TxLoWater1( void )
{
  System_BT_SPP_TxLowWater( System_BT_SPP_TxLoWater1 );
}
static void System_BT_SPP_TxLoWater2( void )
{
  System_BT_SPP_TxLowWater( System_BT_SPP_TxLoWater2 );
}
static void System_BT_SPP_TxLoWater3( void )
{
  System_BT_SPP_TxLowWater( System_BT_SPP_TxLoWater3 );
}
static void System_BT_SPP_TxLoWater4( void )
{
  System_BT_SPP_TxLowWater( System_BT_SPP_TxLoWater4 );
}
static void System_BT_SPP_TxLoWater5( void )
{
  System_BT_SPP_TxLowWater( System_BT_SPP_TxLoWater5 );
}

static void System_BT_SPP_TxHiWater( wm_cb_type tx_hiwater_func_ptr )
{
  /////////////////////////////////////////////////////////
  // NOTE: This DSM callback is called with tasks locked //
  /////////////////////////////////////////////////////////

  System_BT_SPPobj_t* pMe;
  boolean found = FALSE;
  int index;

  for ( index = 0; index < 8; index++ )
  {
    pMe = &(gMe[index]);
    if ( pMe->tx_wm.hiwater_func_ptr == tx_hiwater_func_ptr )
    {
      pMe->bOKToSend = FALSE;
      found = TRUE;
    }
  }

}
static void System_BT_SPP_TxHiWater1( void )
{
  System_BT_SPP_TxHiWater( System_BT_SPP_TxHiWater1 );
}
static void System_BT_SPP_TxHiWater2( void )
{
  System_BT_SPP_TxHiWater( System_BT_SPP_TxHiWater2 );
}
static void System_BT_SPP_TxHiWater3( void )
{
  System_BT_SPP_TxHiWater( System_BT_SPP_TxHiWater3 );
}
static void System_BT_SPP_TxHiWater4( void )
{
  System_BT_SPP_TxHiWater( System_BT_SPP_TxHiWater4 );
}
static void System_BT_SPP_TxHiWater5( void )
{
  System_BT_SPP_TxHiWater( System_BT_SPP_TxHiWater5 );
}

static void System_BT_SPP_EnableDTR( int8 index )
{
  /////////////////////////////////////////////////////////
  // NOTE: This DSM callback is called with tasks locked //
  /////////////////////////////////////////////////////////

  System_BT_SPPobj_t* pMe;
  bt_ev_msg_type bt_ev;
  boolean found = FALSE;
  int i;

  for ( i = 0; i < 8; i++ )
  {
    pMe = &(gMe[i]);
    if ( pMe->uIndex == index )
    {
      found = TRUE;
      bt_ev.ev_hdr.ev_type = BT_EV_SPP_ENABLE_DTR;
      bt_ev.ev_msg.ev_spp_enable_dtr.stream_id = pMe->streamID;
      System_BT_SPP_store_bt_event( &bt_ev );
    }
  }
}
static void System_BT_SPP_EnableDTR1( void )
{
  System_BT_SPP_EnableDTR( 1 );
}
static void System_BT_SPP_EnableDTR2( void )
{
  System_BT_SPP_EnableDTR( 2 );
}
static void System_BT_SPP_EnableDTR3( void )
{
  System_BT_SPP_EnableDTR( 3 );
}
static void System_BT_SPP_EnableDTR4( void )
{
  System_BT_SPP_EnableDTR( 4 );
}
static void System_BT_SPP_EnableDTR5( void )
{
  System_BT_SPP_EnableDTR( 5 );
}


static void System_BT_SPP_FlushTx( int8 index )
{
  /////////////////////////////////////////////////////////
  // NOTE: This DSM callback is called with tasks locked //
  /////////////////////////////////////////////////////////

  System_BT_SPPobj_t* pMe;
  bt_ev_msg_type bt_ev;
  boolean found = FALSE;
  int i;

  for ( i = 0; i < 8; i++ )
  {
    pMe = &(gMe[i]);
    if ( pMe->uIndex == index )
    {
      found = TRUE;
      bt_ev.ev_hdr.ev_type = BT_EV_SPP_FLUSH_TX;
      bt_ev.ev_msg.ev_spp_flush_tx.stream_id = pMe->streamID;
      System_BT_SPP_store_bt_event( &bt_ev );
    }
  }
}
static void System_BT_SPP_FlushTx1( void )
{
  System_BT_SPP_FlushTx( 1 );
}
static void System_BT_SPP_FlushTx2( void )
{
  System_BT_SPP_FlushTx( 2 );
}
static void System_BT_SPP_FlushTx3( void )
{
  System_BT_SPP_FlushTx( 3 );
}
static void System_BT_SPP_FlushTx4( void )
{
  System_BT_SPP_FlushTx( 4 );
}
static void System_BT_SPP_FlushTx5( void )
{
  System_BT_SPP_FlushTx( 5 );
}

static void System_BT_SPP_store_bt_event( bt_ev_msg_type* bt_ev_ptr )
{
  MBT_PI( "-------------------------------------------", 0, 0, 0);
  MBT_PI( __func__" >>>> ev_type[0x%x]", bt_ev_ptr->ev_hdr.ev_type, 0, 0);
  MBT_PI( "-------------------------------------------", 0, 0, 0);

  bt_store_bt_event( bt_ev_ptr, &Systme_BT_SPP_ev_q_info );
}

static uint16 System_BT_SPP_get_max_event_bytes( void )
{
  uint16 max_eb;

  max_eb =              sizeof( bt_ev_spp_flush_tx_type      )  ;
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_enable_dtr_type    ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_tx_hi_wm_type      ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_tx_lo_wm_type      ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_tx_gne_type        ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_rx_hi_wm_type      ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_rx_lo_wm_type      ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_rx_gne_type        ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_line_error_type    ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_modem_status_type  ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_config_change_type ) );
  max_eb = MAX( max_eb, sizeof( bt_ev_spp_status_change_type ) );

  max_eb += sizeof( bt_ev_hdr_type );

  return max_eb;
}

// added by neohacz for multi-point
System_BT_SPPobj_t* System_BT_SPP_CreateMe(uint8 handle)
{
  int index;

  for(index=0; index<8; index++)
  {
    if(gMe[index].bUsed == FALSE) break;
  }

  MBT_PI(__func__" �ߡ� SPP Create pMe : index[%d] �ߡ�", index, 0, 0);

  if(index>7) return NULL;

  gMe[index].bUsed = TRUE;
  gMe[index].handle = handle;		//���⼭ handle �ʱ�ȭ ��Ŵ. 
  gMe[index].parenthandle = 0;
  
  return &(gMe[index]);
}
void System_BT_SPP_PrintSPPobjAll(void)
{
  int index;

  for(index=0; index<8; index++)
  {
  	if(gMe[index].bUsed)
	{
	  	MBT_PI(" [fnclamp] gMe[%d] ========================", index, 0, 0);
	  	MBT_PI("                      handle:%d",  gMe[index].handle, 0,0);
	  	MBT_PI("                      parenthandle:%d",  gMe[index].parenthandle, 0,0);
	  	MBT_PI("                      streamID:%d",  gMe[index].streamID, 0,0);
	  	MBT_PI("                      bUsed:%d",  gMe[index].bUsed, 0,0);
	}
  }

}
void System_BT_SPP_PrintSPPobj(int index)
{

  MBT_PI(" [fnclamp] gMe[%d] ========================", index, 0, 0);
  MBT_PI("                      handle:%d",  gMe[index].handle, 0,0);
  MBT_PI("                      parenthandle:%d",  gMe[index].parenthandle, 0,0);
  MBT_PI("                      streamID:%d",  gMe[index].streamID, 0,0);
  MBT_PI("                      bUsed:%d",  gMe[index].bUsed, 0,0);
}
System_BT_SPPobj_t* System_BT_SPP_FindMebyHandle(uint8 handle)
{
  int index;

  for(index=0; index<8; index++)
  {
    if(gMe[index].handle == handle) break;
  }

  if(index>7) return NULL;

  return &(gMe[index]);
}

int System_BT_SPP_FindIndexbyHandle(uint8 handle)
{
  int index;

  for(index=0; index<8; index++)
  {
    if(gMe[index].handle == handle) break;
  }

  if(index>7) return -1;

  return index;
}

int System_BT_SPP_IsFirstCreateMe(void)
{
  int index, cnt = 0;

  for(index=0; index<8; index++)
  {
    if(gMe[index].bUsed == TRUE) cnt++;
  }

  if(cnt == 1) return TRUE;
  return FALSE;
}

int System_BT_SPP_IsNoneMe(void)
{
  int index, cnt = 0;

  for(index=0; index<8; index++)
  {
    if(gMe[index].bUsed == TRUE) cnt++;
  }

  if(cnt == 0) return TRUE;
  return FALSE;
}

int System_BT_SPP_ReleaseMe(int index)
{
  gMe[index].bUsed = FALSE;
  gMe[index].streamID = SIO_NO_STREAM_ID;
  gSPP_bIdxTaken[ gMe[index].uIndex ] = FALSE;

  return TRUE;
}

#endif // FEATURE_SYSTEM_BT_JSR82
