#ifndef _SYSTEM_BT_SPP_H_
#define _SYSTEM_BT_SPP_H_
/*------------------------------------------------------------------------------
 * Copyright (c) 2006 LG Electronics, Seoul, Republic of KOREA.
 * Any reproduction without written permission is prohibited by law.
 *------------------------------------------------------------------------------
 * Produced by LG Electronics Mobile Communications Company
 *------------------------------------------------------------------------------
 * File     : System_BT_SPP.h
 * Project  : QBT
 *------------------------------------------------------------------------------
 * Description:
 *  Header of SPP
 *------------------------------------------------------------------------------
 */

//==========================================================================
//   Type definitions
//==========================================================================

typedef struct System_BT_SPP_Evt System_BT_SPP_Evt;
typedef struct System_BT_SPPAccept
{
  uint8               handle;
  uint8               gSPPAcceptHandle;
  boolean             bUsed;
} System_BT_SPPAccept_t;


typedef struct System_BT_SPPstruct
{
  uint8               uIndex; // index into watermark callback function tables

  dsm_watermark_type  tx_wm;
  dsm_watermark_type  rx_wm;
  q_type              tx_q;
  q_type              rx_q;
  dsm_item_type*      dsm_item_ptr;

  // valid from Open to Close
  BTBDAddr            BDAddr;
  sio_stream_id_type  streamID;

  BTSppStatus         status;
  BTSppConfig         config;
  BTModemStatus       modemStatus;
  BTLineError         lineError;

  boolean             bOKToSend;

  // added by neohacz 
  uint8               handle;
  uint8               parenthandle;
  boolean             bUsed;

  uint8		     scn;  // server channel number
  uint16                uuid;       	//yucha 2008/01/12 �߰� 
  bt_sd_uuid128_type        uuid128;    	//yucha 2008/01/12 �߰�   
  
} System_BT_SPPobj_t;

typedef void (*System_BT_SPP_ev_hndlr_type) (bt_ev_msg_type* bt_ev_ptr);

//==========================================================================
//   Function prototypes
//==========================================================================

int System_BT_SPP_Init_jsr82( uint8 handle );

int System_BT_SPP_Release( uint8 handle );

void  System_BT_SPP_ReleaseAll(void);
int System_BT_SPP_Open( uint8 handle, const BTSppOpenConfig* pOpenCfg );

int System_BT_SPP_IOCtl( uint8 handle, BTIOCtlCommand cmd, BTIoCtlParam* pParam );

int32 System_BT_SPP_Read( uint8 handle, char* pDst, int32 uMaxBytes );

int  System_BT_SPP_Readable( uint8 handle );

int32 System_BT_SPP_Write( uint8 handle, char* pSrc, int32 uNumBytes );

int System_BT_SPP_Writeable( uint8 handle );

int System_BT_SPP_Close( uint8 handle );
int System_BT_SPP_Accept(uint8 handle, uint8 peerhandle);
System_BT_SPPobj_t* System_BT_SPP_FindMebyHandle(uint8 handle);

#endif /* _SYSTEM_BT_SPP_H_ */
