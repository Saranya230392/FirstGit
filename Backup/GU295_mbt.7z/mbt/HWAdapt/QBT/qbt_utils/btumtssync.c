/*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*

                     BLUETOOTH UMTS SYNCMODULE

GENERAL DESCRIPTION
  This module contains UMTS U8300 LG Sync module using Bluetooth SPP.  
 

FIRST CREATED
  August 20, 2004
  
AUTHOR
  Seung Bum Hong(redionne@lge.com)
    	
Copyright (c) 2004 by LG Electronics, Ltd., All Rights Reserved.
*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*/


/*===========================================================================

                        EDIT HISTORY FOR MODULE

  This section contains comments describing changes made to the module.
  Notice that changes are listed in reverse chronological order.

 *    Rev 1.0   August 20, 2004	 18:00:00   redionne
 *    Rev 2.0   August 20, 2005      15:00:00   redionne       changed U880 PC sync spec. 
 												 PC -> U880    "AT+GMM\r"  
 												 Phone->U880  "AT+GMM\r\r\nU880\r\nOK\n"   <--U880 is model name      
 												 PC->U880      "AT$LGAPP=1\r\n"
 												 U880->PC      "AT%LGAPP=1\n"
  *    Rev 2.1  Sep 30, 2005 pf task �и�
 * Initial revision.

===========================================================================*/


/*===========================================================================
						   Include Header File
===========================================================================*/
#include "customer.h"
#include "comdef.h"

// lhs
//#include "System_BT.h"

#ifdef FEATURE_BT
#ifdef FEATURE_BT_UMTS_SYNC
#include "btumtssync.h"
#include "btmsg.h"
#include "bt.h"
#include "btpf.h"
#include "lg_oem_sync.h"

//#include "dsatlgcmd.h" //dkmoon 2007-1-11
#include "dstask.h"  //dkmoon 2007-1-11
#include "nv.h"  //dkmoon 2007-1-11 

//#define BT_MSG_LAYER  BT_MSG_UMTS_SYNC   /* necessary for btmsg.h */
#define BT_MSG_LAYER  BT_MSG_SP   /* necessary for btmsg.h */


/*===========================================================================
					       Variable Declaration (static local variable)
===========================================================================*/
static bt_umts_sync_data_type bt_umts_sync;
static char bt_umts_sync_server_name[] = "LG Sync SPP";
static int umts_sync_rx_state =0;
static lgoem_sync_buffer_type testbuffer;
static unsigned char tempbuf[30/*25*/];

// [LGE_UPDATE_S] dkmoon 2007328 Send IMEI to PC Sync.
char Imeitemp[8+7+2+2]; /* part1 + part2 + SV + redundancy*/
// [LGE_UPDATE_E]



/*===========================================================================
					       Funection Declaration 
===========================================================================*/
LOCAL void bt_umts_sync_init_sio_open_params(sio_open_type* so_ptr,  bt_spp_open_type*  bso_ptr );
LOCAL void bt_umts_sync_update_sio_conn_status(  bt_spp_status_type*  spp_status_ptr);
LOCAL void bt_umts_sync_every_rx_data_cb(void);
LOCAL void bt_umts_sync_send_to_ui(bt_event_type event_type);

extern void lgoem_sync_bt_status(lgoem_pdk_sync_event_type sync_event);
//dkmoon 2007-1-17 for IMEI
extern nv_stat_enum_type ui_get_nv(nv_items_enum_type item, nv_item_type *data_ptr);

extern int bt_umts_sync_server_readpkt(lgoem_sync_buffer_type *rx_buf_ptr);
extern boolean bt_umts_sync_server_sendpkt(byte *pkt, word pktlen);

/*===========================================================================

FUNCTION
  bt_umts_sync_update_sio_conn_status

DESCRIPTION
  SPP connection status callback..indication sio spp status..
  
===========================================================================*/
LOCAL void bt_umts_sync_update_sio_conn_status( bt_spp_status_type*  spp_status_ptr )
{

	switch(spp_status_ptr->spp_state)
	{
		case BT_SPP_ST_OPEN:
			BT_MSG_HIGH( "BT UMTS OPEN", 0, 0, 0 );		
			bt_umts_sync.state = BT_UMTS_SYNC_RUNNING_STATE;
			bt_umts_sync_send_to_ui(BT_EV_UMTS_SYNC_ENABLED);

			//clear parser state
			umts_sync_rx_state = 0;
			break;

		case BT_SPP_ST_OPEN_ERROR:
			BT_MSG_HIGH( "BT UMTS OPEN ERROR", 0, 0, 0 );	
			bt_umts_sync.state = BT_UMTS_SYNC_INIT_STATE;
			// [DKMOON 20080301] stream id�� ����. for test
			//bt_umts_sync.sio_stream_id = SIO_NO_STREAM_ID;
			bt_umts_sync_send_to_ui(BT_EV_UMTS_SYNC_ENABLE_FAIL);
			break;

		case BT_SPP_ST_CONNECTED:
			BT_MSG_HIGH( "BT UMTS CONNECTED", 0, 0, 0 );	
			bt_umts_sync_send_to_ui(BT_EV_UMTS_SYNC_CONN_ESTABLISHED);
			break;
			
		case BT_SPP_ST_DISCONNECTED:
			BT_MSG_HIGH( "BT UMTS ST DISCONECTED", 0, 0, 0 );			
			bt_umts_sync.sio_stream_id = SIO_NO_STREAM_ID;
			//send connection close event to UI
			bt_umts_sync_send_to_ui(BT_EV_UMTS_SYNC_CONN_CLOSE);

			//for pc sync
			lgoem_sync_bt_status(LGOEM_EVT_BT_DISCONNECT);
			break;
			
		case BT_SPP_ST_CLOSED:
			BT_MSG_HIGH( "BT UMTS ST CLOSED", 0, 0, 0 );		
			bt_umts_sync.state = BT_UMTS_SYNC_INIT_STATE;
			bt_umts_sync_send_to_ui(BT_EV_UMTS_SYNC_DISABLED);
			break;


		default:
			BT_MSG_DEBUG( "BT UMTS Sync: Ignored SPP State %x", spp_status_ptr->spp_state, 0, 0 );			
			break;
	}
}



/*===========================================================================

FUNCTION
  bt_umts_sync_server_init

DESCRIPTION
  Initialize SIO Server parameters
  
 ===========================================================================*/
void bt_umts_sync_server_init(void)
{
	
	BT_MSG_HIGH( "[HSB] bt umts sync sever init",0,0,0);


	/*  Set up TX watermark.  */
	(void) q_init( &bt_umts_sync.to_sio_q );
	bt_umts_sync.tx_wm.lo_watermark        = 0;
	bt_umts_sync.tx_wm.hi_watermark        = 1000; // recover  10000;
	//increase the pc sync transfer speed by bluetooth	2005/12/20
	bt_umts_sync.tx_wm.dont_exceed_cnt     = 10000; // 2000;
	bt_umts_sync.tx_wm.current_cnt         = 0;
	bt_umts_sync.tx_wm.lowater_func_ptr    = NULL;
	bt_umts_sync.tx_wm.gone_empty_func_ptr = NULL;
	bt_umts_sync.tx_wm.non_empty_func_ptr  = NULL;
	bt_umts_sync.tx_wm.hiwater_func_ptr    = NULL;
	bt_umts_sync.tx_wm.q_ptr               = &bt_umts_sync.to_sio_q;

	/*  Set up RX watermark.  */
	(void) q_init( &bt_umts_sync.from_sio_q );
	bt_umts_sync.rx_wm.lo_watermark        = 0;
	bt_umts_sync.rx_wm.hi_watermark        = 1000;
	//increase the pc sync transfer speed by bluetooth	2005/12/20
	bt_umts_sync.rx_wm.dont_exceed_cnt     = 10000; //2000;
	bt_umts_sync.rx_wm.current_cnt         = 0;
	bt_umts_sync.rx_wm.lowater_func_ptr    = NULL;
	bt_umts_sync.rx_wm.gone_empty_func_ptr = NULL;
	bt_umts_sync.rx_wm.non_empty_func_ptr  = bt_umts_sync_every_rx_data_cb;
	bt_umts_sync.rx_wm.hiwater_func_ptr    = NULL;
	bt_umts_sync.rx_wm.q_ptr               = &bt_umts_sync.from_sio_q;

}



/*===========================================================================

FUNCTION
  bt_umts_sync_open_sio

DESCRIPTION
  Opens SIO connection.
  
===========================================================================*/
LOCAL sio_stream_id_type bt_umts_sync_open_sio(sio_open_type*  so_ptr)
{
  
  sio_stream_id_type  sio_stream_id;

  /*  Open new SIO stream.  */
  sio_stream_id = sio_open( so_ptr );
  if ( sio_stream_id != SIO_NO_STREAM_ID )
  {
      BT_MSG_HIGH( "BT UMTS Sync Info: SIO open sid=%d, srvr=%d",
                  sio_stream_id, so_ptr->bt_open_ptr->client_app?0:1, 0 );
  }
  else  /* failed to open SIO connection */
  {
    BT_MSG_HIGH( "BT UMTS_SYNC ERR: sio_open() failed", 0, 0, 0 );

  }

  return ( sio_stream_id );

}



/*===========================================================================

FUNCTION
  bt_umts_sync_init_sio_open_params

DESCRIPTION
  Initialize SIO Server parameter.
  
===========================================================================*/
LOCAL void bt_umts_sync_init_sio_open_params(sio_open_type* so_ptr,  bt_spp_open_type*  bso_ptr )
{

  /*  Fill out generic SIO information.  */
  so_ptr->port_id        = SIO_PORT_BT_SPP;
  so_ptr->rx_flow        = SIO_FCTL_OFF;
  so_ptr->tx_flow        = SIO_FCTL_OFF;
  so_ptr->stream_mode    = SIO_GENERIC_MODE;
  so_ptr->tx_queue       = &bt_umts_sync.tx_wm;
  so_ptr->rx_queue       = &bt_umts_sync.rx_wm;
  so_ptr->tail_char_used = FALSE;
  so_ptr->rx_func_ptr    = NULL;

  /*  Fill out Bluetooth specific information.  */
  so_ptr->bt_open_ptr           = bso_ptr;
  bso_ptr->status_change_fptr   = bt_umts_sync_update_sio_conn_status;
  bso_ptr->config_change_fptr   = NULL;
  bso_ptr->modem_status_fptr    = NULL;
  bso_ptr->line_error_fptr      = NULL;
  bso_ptr->service_version      = 0;
  bso_ptr->service_name_str_ptr = NULL;

}



/*===========================================================================

FUNCTION
  bt_umts_sync_server_enable

DESCRIPTION
 enable umts sync server
 
===========================================================================*/
void bt_umts_sync_server_enable(bt_app_id_type appid)
{
	sio_open_type        so;
	bt_spp_open_type     bso;

	BT_MSG_HIGH( "bt_umts_sync_server_enable %d", appid, 0, 0 );


	if( bt_umts_sync.state != BT_UMTS_SYNC_INIT_STATE || appid == BT_APP_ID_NULL)
	{
		BT_MSG_HIGH( "bt_umts_sync_server already enabled %d %d", bt_umts_sync.state, appid, 0 );
		bt_umts_sync_send_to_ui(BT_EV_UMTS_SYNC_ENABLE_FAIL);
		return;
	}
	else
	{
		bt_umts_sync.bt_app_id = appid;
		
		//init server..
		bt_umts_sync_server_init();

		//init parameter
		bt_umts_sync_init_sio_open_params(&so, &bso );

		/*  Set server specific parameters.  */
		bso.client_app        = FALSE;
		bso.bd_addr_ptr       = NULL;
		bso.service_uuid      = BT_SD_SERVICE_CLASS_SERIAL_PORT;
		bso.service_version = 0x0100;
		bso.rc_server_channel = BT_SPP_SCN_UNSPECIFIED;
		bso.max_frame_size = BT_SPP_MFS_AUTOMATIC;
		bso.service_name_str_ptr = bt_umts_sync_server_name;

		bt_umts_sync.sio_stream_id = bt_umts_sync_open_sio( &so );
	}

	BT_MSG_HIGH("[HSB]sync stream id %d",bt_umts_sync.sio_stream_id,0,0); 

}



/*===========================================================================

FUNCTION
  bt_umts_sync_server_disable

DESCRIPTION
 disable umts sync server
 
===========================================================================*/
void bt_umts_sync_server_disable(bt_app_id_type appid)
{
	BT_MSG_API( "umts sync server disable..close %d stream %d",bt_umts_sync.sio_stream_id , appid, 0 );

	if( bt_umts_sync.state != BT_UMTS_SYNC_RUNNING_STATE)
	{
		BT_MSG_HIGH( "bt_umts_sync_server already disabled %d", bt_umts_sync.state, 0, 0 );
		//send  server disable event to UI
		bt_umts_sync_send_to_ui(BT_EV_UMTS_SYNC_DISABLED);
	}
	else
	{
		if(bt_umts_sync.sio_stream_id != SIO_NO_STREAM_ID)
		{
			sio_close(bt_umts_sync.sio_stream_id,NULL);
		}
		else
		{
			BT_MSG_HIGH( "[Error] sio_stream_id = %d", bt_umts_sync.sio_stream_id, 0, 0 );
		}
	
		BT_MSG_HIGH( "bt_umts_sync_server disabled %d", bt_umts_sync.state, 0, 0 );
	}


}




/*===========================================================================

FUNCTION
  bt_umts_sync_server_close

DESCRIPTION
 ���� connection�� �����Ѵ�. port�� open �� �����̴�. 

===========================================================================*/
void bt_umts_sync_server_close(bt_app_id_type appid)
{
	BT_MSG_API("umts sync server close current connection %d",appid,0,0);
	sio_ioctl(bt_umts_sync.sio_stream_id, SIO_IOCTL_BT_DISCONNECT, NULL);
}




/*===========================================================================

FUNCTION
  bt_umts_sync_server_sendpkt

DESCRIPTION
 send packet.. 
 
===========================================================================*/
boolean bt_umts_sync_server_sendpkt(byte *pkt, word pktlen)
{
	dsm_item_type *tx_ptr;
	uint16 count;

	//hsb for blocking sio assert error
	if( bt_umts_sync.sio_stream_id != SIO_NO_STREAM_ID)
	{
  	  if ( (tx_ptr = bt_get_free_dsm_ptr( BT_TL_RFCOMM, pktlen ))  != NULL )
	  {
	 	count = dsm_pushdown_tail( &tx_ptr, pkt,  pktlen,  (dsm_mempool_id_enum_type)tx_ptr->pool_id );
	
		sio_transmit( bt_umts_sync.sio_stream_id, tx_ptr);
		BT_MSG_HIGH("bt send done %d",count,0,0);
  		return TRUE;
	  }
	  else
	  {
		BT_MSG_HIGH( "BT send ERR: no free DSM", 0, 0, 0 );
		return FALSE;
	  }
    }
    else
    {
		//irregal state..disconnet PC SYNC
		BT_MSG_HIGH("[HSB] btsync irregal state...disconect PC SYNC",0,0,0);
		lgoem_sync_bt_status(LGOEM_EVT_BT_DISCONNECT);	
    }
    return TRUE;

}


int bt_umts_sync_server_readpkt(lgoem_sync_buffer_type *rx_buf_ptr)
{
//	int result = FALSE;
	dsm_item_type *dsm_item_ptr = NULL; /* Pointer to a DSM item from the WM */
	uint16 dsm_item_len = 0;         /* Length of DSM item payload, in bytes */
	uint16 bufpos = 0;
	uint16 copylen = 0;
	uint16 pulluplen = 0;

	if( rx_buf_ptr->buf_ptr != NULL && rx_buf_ptr->buflen > 0 )
	{

		while ( (dsm_item_ptr = dsm_dequeue( &bt_umts_sync.rx_wm )) != NULL )
		{

			do
			{

			      dsm_item_len = dsm_length_packet( dsm_item_ptr );

				if( dsm_item_len >= rx_buf_ptr->buflen - bufpos )
				{
					BT_MSG_HIGH("[BTSYNC] ok buffer full %d",bufpos,0,0);
					break;
				}
				else 
				{
					copylen = dsm_item_len;
					//BT_MSG_HIGH("[BTSYNC] copylen %d", copylen,0,0);
				}

 				//copy data to read buffer
				pulluplen = dsm_pullup( &dsm_item_ptr, (void*)((rx_buf_ptr->buf_ptr)+bufpos), copylen ); 

				//incread buffer point
			       bufpos += pulluplen;
				
			}while( pulluplen > 0);

			dsm_free_packet( &dsm_item_ptr );  /*  Just to be safe.  */

		}
	}

	BT_MSG_HIGH("read done %d", bufpos,0,0);
	umts_sync_rx_state = 1;
	return bufpos;
}



int bt_umts_sync_server_term(void)
{
	BT_MSG_HIGH("[hsb] bt_umts_sync_server_term",0,0,0);
	umts_sync_rx_state = 0;
	return 1;
}



/*===========================================================================

FUNCTION
  bt_umts_sync_every_rx_data_cb

DESCRIPTION
 recevie callback.. 
 
===========================================================================*/
// LG add  Kim jihyung add for pc sync  
#define BT_PF_CMD_PCSYNC_SIG                           0x20000000
// 
LOCAL void bt_umts_sync_every_rx_data_cb(  void )
{
	BT_MSG_HIGH("bt_umts_sync_every_rx_data_cb",0,0,0);

// lhs �ϴ� ����. 060519
#if 0
	bt_ob_set_sigs( BT_SPP_RX_UMTS_SYNC_SERVER_DATA_SIG );
	rex_set_sigs(&btpf_tcb, BTPF_OB_RX_DATA_SIG);
#endif 
       rex_set_sigs(&bt_pf_tcb, BT_PF_CMD_PCSYNC_SIG);
}
/*===========================================================================

FUNCTION
  bt_spp_check_rx_wm_data

DESCRIPTION
 recevie process.. 
 
===========================================================================*/
#define BT_AT_CMD_BUF_MAX 25
static char bt_at_cmd[25];
static int bt_at_cmd_len = 0;
extern const char ver_dir[];
extern int SVN; //dkmoon 2007-1-11 

// [LGE_UPDATE_S] dkmoon 2007328 Get imei from NV item.
BOOL bt_spp_get_imei(void)
{

	nv_cmd_type  rd_imei_nv_cmd;
	nv_item_type  nv_item;
	
	boolean result = TRUE;
	byte imei_bcd_len = 0;
	byte n = 0;
	byte digit;
	char imei_ascii[(NV_UE_IMEI_SIZE-1)*2];
	
	/* Read IMEI from NV */
	rd_imei_nv_cmd.item       = NV_UE_IMEI_I;
	rd_imei_nv_cmd.cmd        = NV_READ_F;
	rd_imei_nv_cmd.data_ptr   = &nv_item;
	rd_imei_nv_cmd.tcb_ptr    = &bt_pf_tcb;
	rd_imei_nv_cmd.sigs       = BT_PF_WAIT_SIG;
	rd_imei_nv_cmd.done_q_ptr = NULL;

	(void) rex_clr_sigs( rex_self(), BT_PF_WAIT_SIG );
	nv_cmd( &rd_imei_nv_cmd );
	(void) rex_wait( BT_PF_WAIT_SIG );
	(void) rex_clr_sigs( rex_self(), BT_PF_WAIT_SIG );

	if ( rd_imei_nv_cmd.status == NV_DONE_S )
	{
		/* Convert it to ASCII */
		imei_bcd_len = nv_item.ue_imei.ue_imei[0];

		if( imei_bcd_len <= (NV_UE_IMEI_SIZE-1) )
		{
			/* This is a valid IMEI */
			memset(imei_ascii, 0, (NV_UE_IMEI_SIZE-1)*2);

			for( n = 1; n <= imei_bcd_len; n++ )
			{
				digit = nv_item.ue_imei.ue_imei[n] & 0x0F;
				if( ( digit <= 9 ) || ( n <= 1 ) )
				{
					imei_ascii[ (n - 1) * 2 ] = digit + '0';
				}
				else
				{
					imei_ascii[ (n - 1) * 2 ] = '\0';
					break;
				}

				digit = nv_item.ue_imei.ue_imei[n] >> 4;
				if( ( digit <= 9 ) || ( n <= 1 ) )
				{
					imei_ascii[ ((n - 1) * 2) + 1 ] = digit + '0';
				}
				else
				{
					imei_ascii[ ((n - 1) * 2) + 1 ] = '\0';
					break;
				}
			}
		  
		  /* Lose the first byte because it is just the ID */
		  memcpy( Imeitemp, imei_ascii + 1, (NV_UE_IMEI_SIZE-1)*2-1 );
		}
		else
		{
			/* This is an invalid IMEI */
			ERR("Invalid IMEI value from NV", 0,0,0);
			result = FALSE;
		}
	}
	else if( rd_imei_nv_cmd.status == NV_NOTACTIVE_S )
	{
		/* NV not programmed with IMEI */
		ERR("IMEI not programmed in NV", 0,0,0);
		result = FALSE;
	}
	else
	{
		ERR("Problem reading IMEI from NV", 0,0,0);
		result = FALSE;
	}

	return result;
}
// [LGE_UPDATE_E]

// [LGE_UPDATE_S] dkmoon 2007328 Check imei version.
void bt_spp_imei_check_ver(void)
{
	nv_cmd_type   rd_imei_cks_ver;
	nv_item_type  nv_item2;

	/* Read IMEI_CKS_VER from NV */
	rd_imei_cks_ver.item       = NV_IMEI_CKS_VER_I;
	rd_imei_cks_ver.cmd        = NV_READ_F;
	rd_imei_cks_ver.data_ptr   = &nv_item2;
	rd_imei_cks_ver.tcb_ptr    = &bt_pf_tcb;
	rd_imei_cks_ver.sigs       = BT_PF_WAIT_SIG;
	rd_imei_cks_ver.done_q_ptr = NULL;

	(void) rex_clr_sigs( rex_self(), BT_PF_WAIT_SIG );
	nv_cmd( &rd_imei_cks_ver );
	(void) rex_wait( BT_PF_WAIT_SIG );
	(void) rex_clr_sigs( rex_self(), BT_PF_WAIT_SIG );

	if( rd_imei_cks_ver.status != NV_DONE_S)
	{
		int cksum=0;
		int i;

		for(i=0;i<=13;++i) 
		{
			if(i==1||i==3||i==5||i==7||i==9||i==11||i==13) 
			{
				int t=(Imeitemp[i]-'0')*2;
				if (t>=10) 
					cksum+=(t-10)+1;
				else 
					cksum+=t;
			}
			else 
			{
				cksum+=Imeitemp[i]-'0';
			}
		}

		cksum=cksum%10;
		if (cksum!=0) 
			cksum=10-cksum;

		Imeitemp[14]=cksum+'0';
		Imeitemp[15]=0;

		BT_MSG_HIGH("[MDK] NV_IMEI_CKS_VER_I --> FAIL reason %d",rd_imei_cks_ver.status,0,0);
		sprintf((char*)testbuffer.buf_ptr, "%c%s%d%d%c\r\n\r\nOK\r\n",0x02,Imeitemp,SVN/10,SVN%10,0x03);
	}
	else
	{    
		/* rechanged by angelyun to support backup checksum and SVN */
		Imeitemp[14]=(nv_item2.cks_ver&0xf)+'0';
		Imeitemp[15]=((nv_item2.cks_ver&0xf0)/0x10)+'0';
		Imeitemp[16]=((nv_item2.cks_ver&0xf00)/0x100)+'0';
		Imeitemp[17]=0;

		BT_MSG_HIGH("[MDK] NV_IMEI_CKS_VER_I --> NV_DONE_S ",0,0,0);
		sprintf((char*)testbuffer.buf_ptr,"%c%s%c\r\n\r\nOK\r\n",0x02,Imeitemp,0x03);
	}
						
}
// [LGE_UPDATE_E]

void bt_spp_check_rx_wm_data(int index)
{
	int readlen = 0;
	int IsCmd;
	BT_MSG_HIGH("[HSB] umts sync data indication",0,0,0);
	rex_sleep(3);
		
	switch( umts_sync_rx_state)
		{

		case 0:
			testbuffer.buf_ptr = tempbuf;
			testbuffer.buflen = 30/*25*/;
			readlen = bt_umts_sync_server_readpkt( &testbuffer);
			
			BT_MSG_HIGH("[HSB] umts sync 1 %d %d",readlen,bt_at_cmd_len,0);

			//dump received data
			BT_MSG_HIGH("%c %c %c", testbuffer.buf_ptr[3],testbuffer.buf_ptr[4],testbuffer.buf_ptr[5]);
			BT_MSG_HIGH("%x %x %x", testbuffer.buf_ptr[6],testbuffer.buf_ptr[7],testbuffer.buf_ptr[8]);
			BT_MSG_HIGH("%x %x %x", testbuffer.buf_ptr[9],testbuffer.buf_ptr[10],testbuffer.buf_ptr[11]);
			BT_MSG_HIGH("%x %x %x", testbuffer.buf_ptr[12],testbuffer.buf_ptr[13],testbuffer.buf_ptr[14]);


			if( bt_at_cmd_len + readlen > BT_AT_CMD_BUF_MAX)
			{
				BT_MSG_HIGH("read length over flow",0,0,0);
				readlen = BT_AT_CMD_BUF_MAX - bt_at_cmd_len;
			}
			
			memcpy( &bt_at_cmd[bt_at_cmd_len], testbuffer.buf_ptr, readlen);
			bt_at_cmd_len += readlen;
			
			if( bt_at_cmd_len > 6)
			{
				//AT+GMM 
				IsCmd = memcmp( bt_at_cmd, "AT+GMM",6);
				
				BT_MSG_HIGH("check recived data GMM?%d app_cmd_len:%d", IsCmd,bt_at_cmd_len,0);

				if( IsCmd == 0)
				{
					BT_MSG_HIGH("AT+GMM is received",0,0,0);
						
					memset( testbuffer.buf_ptr, 0, 30/*25*/);
					sprintf((char *)testbuffer.buf_ptr,"AT+GMM\r\r%s\r\nOK\n",ver_dir);
					testbuffer.buflen  = strlen((char *)testbuffer.buf_ptr);
					
					BT_MSG_HIGH("tx AT GMM data %d",testbuffer.buflen,0,0);
					bt_umts_sync_server_sendpkt( testbuffer.buf_ptr,testbuffer.buflen);
					umts_sync_rx_state = 0;
				}
				else
				{	
					IsCmd = memcmp( bt_at_cmd, "AT%IMEI", 7);

					if(IsCmd == 0)
					{
						//char temp[8+7+2+2]; /* part1 + part2 + SV + redundancy*/

						BT_MSG_HIGH("AT%IMEI is received",0,0,0);
						memset(testbuffer.buf_ptr, 0, 30);

						// [LGE_UPDATE_S] dkmoon 2007328 Send IMEI to PC Sync.
						/* IMEI Read Function */
						if (bt_spp_get_imei() == TRUE)
						{
							bt_spp_imei_check_ver();	
						}
						else
						{
							sprintf((char*)testbuffer.buf_ptr, "%c35030526000000165%c\r\n\r\nOK\r\n",0x02,0x03);
						}
						// [LGE_UPDATE_E]

						testbuffer.buflen  = strlen((char *)testbuffer.buf_ptr);
						BT_MSG_HIGH(" IMEI length %d ",testbuffer.buflen,0,0);

						bt_umts_sync_server_sendpkt( testbuffer.buf_ptr,testbuffer.buflen);
						umts_sync_rx_state = 0;
					}
					else 
					{
						//at$lgapp=1
						IsCmd = memcmp( bt_at_cmd, "at$lga",6);
						if( IsCmd == 0)
						{
							BT_MSG_HIGH("AT$LGAPP is received",0,0,0);
							
							memset( testbuffer.buf_ptr, 0, 13);
							memcpy(testbuffer.buf_ptr,"at$lgapp=1\n",11);

							BT_MSG_HIGH("tx AT$LGAPP=1 data ",0,0,0);

							bt_umts_sync_server_sendpkt( testbuffer.buf_ptr,11);
							umts_sync_rx_state = 1;

							lgoem_sync_bt_status(LGOEM_EVT_BT_CONNECT);
						}
						else
						{
							BT_MSG_HIGH("not supported command %c %c% %c",testbuffer.buf_ptr[0],testbuffer.buf_ptr[1],testbuffer.buf_ptr[2]);
						}
						
					}
				}
				bt_at_cmd_len = 0;
			}
			BT_MSG_HIGH("step 0(command state) end at_cmd_len:%d",bt_at_cmd_len,0,0);
			break;
			
		case 1:
			BT_MSG_HIGH("[HSB] step 1..connect state..send data receive",0,0,0);
			lgoem_sync_bt_status(LGOEM_EVT_BT_DATAIN);
			umts_sync_rx_state  =2;
			break;
			
		case 2:
			BT_MSG_HIGH("[HSB] step 2..reading state",0,0,0);
			break;

	}
}





/*===========================================================================
 Function Name:	bt_umts_sync_process_command	
	
 Description:

	Processes all commands from UI/application

 Arguments:
		
	bt_cmd_msg_type		*umts_sync_cmd_ptr	command message type									  	
	
 Returns:	
		
	None
		
 Comments:
		
===========================================================================*/
void bt_umts_sync_process_command(bt_cmd_msg_type* umts_sync_cmd_ptr)
{
	umts_sync_cmd_ptr->cmd_hdr.cmd_status = BT_CS_GN_SUCCESS;
	
	switch(umts_sync_cmd_ptr->cmd_hdr.cmd_type)
	{
		case BT_CMD_UMTS_SYNC_SVR_ENABLE:
			bt_umts_sync_server_enable(umts_sync_cmd_ptr->cmd_hdr.bt_app_id);
			break;
		
		case BT_CMD_UMTS_SYNC_SVR_DISABLE:
			bt_umts_sync_server_disable(umts_sync_cmd_ptr->cmd_hdr.bt_app_id );
			break;

		case BT_CMD_UMTS_SYNC_SVR_DISCONNECT:
			bt_umts_sync_server_close(umts_sync_cmd_ptr->cmd_hdr.bt_app_id );
			break;
	}


}



/*===========================================================================

FUNCTION
  bt_umts_sync_send_to_ui

DESCRIPTION
  send event to UI
  
===========================================================================*/
LOCAL void bt_umts_sync_send_to_ui(bt_event_type event_type)
{
	bt_ev_msg_type  		 ev_umts_sync_to_ui ;	
	ev_umts_sync_to_ui.ev_hdr.bt_app_id = bt_umts_sync.bt_app_id ;	

	ev_umts_sync_to_ui.ev_hdr.ev_type = event_type ;					
	bt_ec_send_event( &ev_umts_sync_to_ui );	
}
#endif  /*FEATURE_BT_UMTS_SYNC*/

#endif /*FEATURE_BT */

