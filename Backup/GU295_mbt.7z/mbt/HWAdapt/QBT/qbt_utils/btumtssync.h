#ifndef _BTUMTSSYNC_H_
#define _BTUMTSSYNC_H_


#ifdef FEATURE_BT
#ifdef FEATURE_BT_UMTS_SYNC

/*===========================================================================

                     INCLUDE FILES FOR MODULE

===========================================================================*/

#include "customer.h"

#ifdef T_WINNT
#include "comdeff.h"
#else
#include "comdef.h"
#endif

#include "bt.h"
#include "btsd.h"
#include "fs.h"
#include "dsati.h"
#include "btcmdi.h"



/*===========================================================================

                DEFINITIONS AND DECLARATIONS FOR MODULE

This section contains definitions for constants, macros, types, variables
and other items needed by this module.

===========================================================================*/
/* spp application ID */
#define BT_SPP_SERVER_INDEX_UMTS_SYNC	1

#define BT_UMTS_SYNC_INIT_STATE			0
#define BT_UMTS_SYNC_RUNNING_STATE		1




/*-------------------------------------------------------------------------*/
/*                                                                       									  */
/*                         Data Type Definitions                          							 */
/*                                                                        									 */
/*-------------------------------------------------------------------------*/
typedef enum
{
	BT_UMTS_SYNCS_DISABLED,            /* no SIO conn.             */
	BT_UMTS_SYNCS_CLOSED,              /* SIO connection closed    */
	BT_UMTS_SYNCS_OPENING,             /* opening SIO connection   */
	BT_UMTS_SYNCS_OPENED,              /* SIO connection opened    */
	BT_UMTS_SYNCS_CLOSING,             /* SIO connection closing   */
	BT_UMTS_SYNCS_MAX
} bt_umts_sync_state_type;

typedef struct
{
	bt_umts_sync_state_type	state;
	sio_stream_id_type		sio_stream_id;
	dsm_watermark_type		tx_wm;
	dsm_watermark_type		rx_wm;
	q_type					to_sio_q;
	q_type					from_sio_q;	
	bt_app_id_type			bt_app_id;
} bt_umts_sync_data_type;



extern void bt_umts_sync_server_init(void);
extern void bt_umts_sync_server_enable(bt_app_id_type appid);
extern void bt_umts_sync_server_disable(bt_app_id_type appid);
extern void bt_umts_sync_server_close(bt_app_id_type appid);
extern boolean bt_umts_sync_server_sendpkt(byte *pkt, word pktlen);
extern void bt_spp_check_rx_wm_data(int index);
extern void bt_umts_sync_process_command(bt_cmd_msg_type* umts_sync_cmd_ptr);



#endif /* FEATURE_BT_UMTS_SYNC */
#endif /* FEATURE_BT */

#endif  /*  _BTUMTSSYNC_H  */
