/********************************************************************************
*	File Name	: mbt_misc_qbt.c
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.11.26	Lee,DongHyun		Created
********************************************************************************/
#include "mbt_misc.h"

#include "UnicodeLib.h"

#define QBT_LANG_USE_LIB

/*=========================================================================== 
*	Prototype	:		
*	Description: 		
*	Return	:		NONE
*	Expected Event:	
===========================================================================*/
MBT_SHORT mbt_ucs2_to_local(
	MBT_SHORT *ucs2_str,
	MBT_SHORT ucs2_len,
	MBT_CHAR *local_str,
	MBT_SHORT buf_len,
	MBT_CHAR subst_char)
{
#if 1
	extern int UniLib_UCS2ToUTF8(unsigned short * ucs2_string, char *utf8);
	return UniLib_UCS2ToUTF8(ucs2_str, local_str);
#else
	MBT_SHORT	ucs2_idx;
	MBT_SHORT	local_len;
	MBT_SHORT  	wChar;

	if(!ucs2_str || !local_str || ucs2_len == 0)
		return 0;

	local_len = 0;
	ucs2_idx = 0;
	while (ucs2_idx < ucs2_len && local_len < buf_len-1)
	{
		wChar = ucs2_str[ucs2_idx++];

		if ( wChar < 0x100 )
			local_str[local_len++] = (MBT_CHAR)wChar;
		else
		{
			MBT_ERR("BT UTF16 decoder : invalid char:%04X", wChar, 0, 0);
			local_str[local_len++] = subst_char;
		}
	}
	local_str[local_len] = 0;

	return(local_len);
#endif
}

/*=========================================================================== 
*	Prototype	:		
*	Description: 		
*	Return	:		NONE
*	Expected Event:	
===========================================================================*/
MBT_SHORT mbt_ucs2_to_utf8(
	MBT_SHORT *ucs2_str,
	MBT_SHORT ucs2_len,
	MBT_CHAR *utf8_str,
	MBT_SHORT buf_len)
{
#if 1
	extern int UniLib_UCS2ToUTF8(unsigned short * ucs2_string, char *utf8);
	return UniLib_UCS2ToUTF8(ucs2_str, utf8_str);
#else
	MBT_SHORT	ucs2_idx;
	MBT_SHORT	utf8_len;
	MBT_SHORT  	wChar;

	if(!ucs2_str || !utf8_str || ucs2_len == 0)
		return 0;

	utf8_len = 0;
	ucs2_idx = 0;
	while (ucs2_idx < ucs2_len && utf8_len < buf_len-1)
	{
		wChar = ucs2_str[ucs2_idx++];

		if ( wChar < 0x80 )
		{
			utf8_str[utf8_len++] = (MBT_CHAR)wChar;
		}
		else if ( wChar < 0x800 )
		{
			utf8_str[utf8_len++] = 0xC0 | ((wChar>>6)&0x1F);	// upper 5 bits
			utf8_str[utf8_len++] = 0x80 | (wChar & 0x3F);		// lower 6 bits
		}
		else if ( wChar < 0x10000 )
		{
			utf8_str[utf8_len++] = 0xE0 | ((wChar>>12)&0x0F);	// upper 4 bits
			utf8_str[utf8_len++] = 0x80 | ((wChar>>6) & 0x3F);	// next 6 bits
			utf8_str[utf8_len++] = 0x80 | ((wChar) & 0x3F);	// next 6 bits
		}
		else
		{
			utf8_str[utf8_len++] = 0xF0 | ((wChar>>18)&0x03);	// upper 3 bits
			utf8_str[utf8_len++] = 0x80 | ((wChar>>12)&0x3F);	// next 6 bits
			utf8_str[utf8_len++] = 0x80 | ((wChar>>6) & 0x3F);	// next 6 bits
			utf8_str[utf8_len++] = 0x80 | ((wChar) & 0x3F);	// next 6 bits
		}
	}
	utf8_str[utf8_len] = 0;

	return(utf8_len);
#endif
}

/*=========================================================================== 
*	Prototype	:		
*	Description: 		
*	Return	:		NONE
*	Expected Event:	
===========================================================================*/
MBT_SHORT mbt_utf8_to_ucs2(
	MBT_CHAR *utf8_str,
	MBT_SHORT utf8_len,
	MBT_SHORT *ucs2_str,
	MBT_SHORT buf_len)
{
#if 1
	extern int UniLib_UTF8ToUCS2(char *utf8, unsigned short* ucs2_string );
	return UniLib_UTF8ToUCS2(utf8_str, ucs2_str);
#else
	MBT_SHORT local_len;
	MBT_BYTE    b;
	MBT_UINT  wChar;

	if(!utf8_str || !ucs2_str || utf8_len == 0)
		return 0;

	local_len = 0;
	while (utf8_len > 0 && local_len < buf_len-1)
	{
		b = *utf8_str++; 

		if (b & 0x80)
		{
			if (b & 0x40)
			{
				if (b & 0x20)
				{
					if (b & 0x10)
					{
						if ( utf8_len < 4 )
							return 0;
						wChar = (b&0x07);
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						utf8_len -= 4;
					}
					else
					{
						if ( utf8_len < 3 )
							return 0;
						wChar = (b&0x0F);
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						utf8_len -= 3;
					}
				}
				else
				{
					if ( utf8_len < 2 )
						return 0;
					wChar = (unsigned short)(b & 0x1F);
					b = *utf8_str++;
					if ((b & 0xc0) != 0x80) 
						return(0);
					wChar = ((wChar << 6)|( b & 0x3F)) & 0xffff;
					utf8_len -= 2;
				}
			}
			else
			{
				return 0;
			}
		}
		else
		{
			wChar = (MBT_UINT)b;
			utf8_len--;
		}

		if ( wChar < 0x10000 )
			ucs2_str[local_len++] = (MBT_SHORT)wChar;
		else
		{
			MBT_ERR("BT UTF8 decoder : invalid char:%08X", wChar, 0, 0);
			ucs2_str[local_len++] = (MBT_SHORT)(wChar & 0xFFFF);
		}
	}
	ucs2_str[local_len] = 0;

	return(local_len);
#endif
}

/*=========================================================================== 
*	Prototype	:		
*	Description: 		
*	Return	:		NONE
*	Expected Event:	
===========================================================================*/
MBT_SHORT mbt_utf8_to_local(
	MBT_CHAR *utf8_str,
	MBT_SHORT utf8_len,
	MBT_CHAR *local_str,
	MBT_SHORT buf_len,
	MBT_CHAR subst_char)
{
#if 1
	if ( utf8_len > buf_len-1 )
	{
		memcpy(local_str, utf8_str, buf_len-1);
		local_str[buf_len-1] = 0;
		return buf_len-1;
	}
	else
	{
		memcpy(local_str, utf8_str, utf8_len);
		local_str[utf8_len] = 0;
		return utf8_len;
	}
#else
	MBT_SHORT local_len;
	MBT_BYTE    b;
	MBT_UINT  wChar;

	if(!utf8_str || !local_str || utf8_len == 0)
		return 0;

	local_len = 0;
	while (utf8_len > 0 && local_len < buf_len-1)
	{
		b = *utf8_str++; 

		if (b & 0x80)
		{
			if (b & 0x40)
			{
				if (b & 0x20)
				{
					if (b & 0x10)
					{
						if ( utf8_len < 4 )
							return 0;
						wChar = (b&0x07);
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						utf8_len -= 4;
					}
					else
					{
						if ( utf8_len < 3 )
							return 0;
						wChar = (b&0x0F);
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						b = *utf8_str++;
						if ((b & 0xC0) != 0x80)
							return(0);
						wChar = ((wChar << 6)|(b & 0x3F)) & 0xffff;
						utf8_len -= 3;
					}
				}
				else
				{
					if ( utf8_len < 2 )
						return 0;
					wChar = (unsigned short)(b & 0x1F);
					b = *utf8_str++;
					if ((b & 0xc0) != 0x80) 
						return(0);
					wChar = ((wChar << 6)|( b & 0x3F)) & 0xffff;
					utf8_len -= 2;
				}
			}
			else
			{
				return 0;
			}
		}
		else
		{
			wChar = (MBT_UINT)b;
			utf8_len--;
		}

		if ( wChar < 0x100 )
			local_str[local_len++] = (MBT_CHAR)wChar;
		else
		{
			MBT_ERR("BT UTF8 decoder : invalid char:%08X", wChar, 0, 0);
			local_str[local_len++] = subst_char;
		}
	}
	local_str[local_len] = 0;

	return(local_len);
#endif
}

MBT_SHORT mbt_local_to_utf8(
	MBT_CHAR *local_str,
	MBT_SHORT local_len,
	MBT_CHAR *utf8_str,
	MBT_SHORT buf_len)
{
#if 1
	if ( local_len > buf_len-1 )
	{
		memcpy(utf8_str, local_str, buf_len-1);
		local_str[buf_len-1] = 0;
		return buf_len-1;
	}
	else
	{
		memcpy(utf8_str, local_str, local_len);
		local_str[local_len] = 0;
		return local_len;
	}
#else
	MBT_SHORT idx;
	MBT_SHORT utf8_len;

	if(!local_str || !utf8_str || local_len == 0)
		return 0;

	idx = 0;
	utf8_len = 0;
	while(idx<local_len && utf8_len < buf_len-1)
	{
		if ( local_str[idx] < 128 )
		{
			utf8_str[utf8_len++] = local_str[idx];
		}
		else
		{
			utf8_str[utf8_len++] = 0xC0 | ((local_str[idx]>>6)&0x1F);
			utf8_str[utf8_len++] = 0x80 | (local_str[idx] & 0x3F);
		}
		idx++;
	}
	utf8_str[utf8_len] = 0;

	return utf8_len;
#endif
}

