
#ifndef _QBT_UTILS_H_
#define _QBT_UTILS_H_
#include "Qbt_fs.h"

MBT_VOID bdcpy(T_MBT_BDADDR a, const T_MBT_BDADDR b);
MBT_INT bdcmp(const T_MBT_BDADDR a, const T_MBT_BDADDR b);
MBT_CHAR *bdAddrToString( T_MBT_BDADDR Addr);
boolean  qbt_file_exist(MBT_CHAR* filename, MBT_CHAR* dirname);
bt_cmd_status_type qbt_file_check_overwrite_rule(MBT_CHAR* filename, MBT_CHAR* dirname);
bt_cmd_status_type qbt_file_check_name_type(MBT_CHAR* file_name);
MBT_BOOL qbt_IsLastCharSlash(MBT_CHAR *str);
#endif //_QBT_UTILS_H_


