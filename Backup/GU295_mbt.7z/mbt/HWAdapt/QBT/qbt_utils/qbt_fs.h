#ifndef _QBT_FS_H_
#define _QBT_FS_H_
/*------------------------------------------------------------------------------
 * Copyright (c) 2006 LG Electronics, Seoul, Republic of KOREA.
 * Any reproduction without written permission is prohibited by law.
 *------------------------------------------------------------------------------
 * Produced by LG Electronics Mobile Communications Company
 *------------------------------------------------------------------------------
 * Component: FTP - included client and server
 * File     : qbt_fs.h
 * Project  : QBT
 * Date     : April 3th, 2006
 * Author   : YT Kim (bestyt@lge.com)
 *------------------------------------------------------------------------------
 * Description:
 *  Header of Utils
 *------------------------------------------------------------------------------
 */
#include "bt.h"
#include "fs.h"
#include "MBTType.h"
#include "mbt_debugmsg.h"
/*-------------------------------------------------------------------------------------------------
 * Definitions
 *-------------------------------------------------------------------------------------------------*/


/*-------------------------------------------------------------------------------------------------
 * Function prototypes 
 *-------------------------------------------------------------------------------------------------*/
MBT_SHORT qbt_file_make_full_path(
	MBT_CHAR *utf8_dir,
	MBT_CHAR *utf8_file,
	MBT_CHAR *local_full,
	MBT_SHORT buf_len);

MBT_SHORT qbt_file_make_full_path_ucs2(
	MBT_CHAR *utf8_dir,
	MBT_SHORT *ucs2_file,
	MBT_SHORT ucs2_len,
	MBT_CHAR *local_full,
	MBT_SHORT buf_len);

bt_cmd_status_type qbt_file_open_read(
	fs_handle_type* 	handle_ptr,
	MBT_UINT* 		filesize_ptr,
	MBT_CHAR*		filename);


bt_cmd_status_type qbt_file_open_write( 
	fs_handle_type* 	handle_ptr,
	MBT_CHAR*		filename);


bt_cmd_status_type qbt_file_read( 
	fs_handle_type	handle,
  	uint16			max_read,
  	uint32*               	to_read,
  	byte*	              data_ptr,
  	uint32			file_size);


bt_cmd_status_type qbt_file_write(
  fs_handle_type 	handle,
  byte*              	buf_ptr,
  uint16             	buf_len );

bt_cmd_status_type qbt_file_remove(	
	MBT_CHAR*				filename);

bt_cmd_status_type qbt_file_close(
	fs_handle_type fd);

#endif //  _QBT_FS_H_
