#include <stdio.h>
#include <stdlib.h>

#include "MBTType.h"
#include "qbt_utils.h"
#include "mbt_debugmsg.h"


#define   UTF8_FILE_NAME_MAX_LEN 					127
//path_temp => stack�޸𸮸� ���̱� ���� ���. ���� static���� ���Ǹ�, ���� .c ���Ͽ� �մ� �Լ��� ȣ������ �� ��
static char    path_temp[FS_FILENAME_MAX_LENGTH_P];

/*******************************************************************************
** Function         bdcpy
** Description      Copy bd addr b to a.
** Returns          MBT_VOID 
*******************************************************************************/
MBT_VOID bdcpy(T_MBT_BDADDR a, const T_MBT_BDADDR b)
{
    MBT_INT i;

    for (i = MBT_BDADDR_LEN; i != 0; i--)
    {
        *a++ = *b++;
    }
}

/*******************************************************************************
** Function         bdcmp
** Description      Compare bd addr b to a.
** Returns          Zero if b==a, nonzero otherwise (like memcmp).
*******************************************************************************/
MBT_INT bdcmp(const T_MBT_BDADDR a, const T_MBT_BDADDR b)
{
    MBT_INT i;

    for (i = MBT_BDADDR_LEN; i != 0; i--)
    {
        if (*a++ != *b++)
        {
            return -1;
        }
    }
    return 0;
}

/*******************************************************************************
** Function         bdAddrToString
** Description      BD Addr to string for debugging
** Returns          string pointer.
*******************************************************************************/
MBT_CHAR *bdAddrToString( T_MBT_BDADDR Addr)
{
    static MBT_CHAR AddrString[20] = {0,};

	sprintf(AddrString, "%02x:%02x:%02x:%02x:%02x:%02x",
		Addr[0], Addr[1], Addr[2], Addr[3], Addr[4], Addr[5]);

	return AddrString;
}


/*===========================================================================

FUNCTION
  file_exist 
   
DESCRIPTION
   
===========================================================================*/
MBT_BOOL  qbt_file_exist(MBT_CHAR* filename, MBT_CHAR* dirname)
{
	fs_rsp_msg_type     resp;
	//int i;

	strcpy(path_temp, dirname);
	strcat(path_temp, filename);
	
 	/* 
 	 * Now check the existance of directory 
 	 */
 	
  	fs_nametest(path_temp, FS_TEST_FILE, NULL, &resp);
   	if(resp.nametest.name_found == MBT_FALSE) {
		/*
		 * Not exist
		 */
		return MBT_FALSE;
   	}

	return MBT_TRUE;
}

/*===========================================================================

FUNCTION
  file_check_overwrite_rule 
   
DESCRIPTION
   
===========================================================================*/
bt_cmd_status_type qbt_file_check_overwrite_rule(MBT_CHAR* filename, MBT_CHAR* dirname)
{
	char *p;
	int i;
	boolean duplicate_file = FALSE;
	int try_count =0;
	
	do {
		duplicate_file = qbt_file_exist(filename, dirname);
		if (duplicate_file == FALSE) {
			MBT_PI("[UTIL] file path is OK...", 0,0,0);
			return OI_OK;
		}
		
		/*
		  * change file name
		  */
		p = filename;
		if(strlen(p) + 4 > UTF8_FILE_NAME_MAX_LEN)
		{
			MBT_WARN("[UTIL] exceed max name length, cann't create new name length:%d", strlen(p), 0,0);
			return OI_FAIL;
		}
		
		if ((p[0] == '('  && p[3] == ')' )  ) {
			p = p + 4;
		}
		//������ ù�� ° ���ǽ��� ���� �Ȱ�... ���Ͱ��� ���ǽ� ������. 
		//UniLib_Sprintf(filename_buf, L"(%2d)%s\0", rand()%100, p);
		//BTPrintf("[UTIL] new filename (%S)\n", filename_buf);
		sprintf(path_temp, "(%2d)%s\0", rand()%100, p);
		/* 
		 * Update new file name
		 */
		//memcpy((char*)filename_ptr, (char*)filename_buf, sizeof(TChar)*wcslen(filename_buf));
		//filename_ptr[wcslen(filename_buf)] = '\0';
		memcpy(filename, path_temp, strlen(path_temp));
		filename[strlen(filename)] = '\0';
		
	} while(try_count ++ < 100);

	//BTPrintf("[UTIL] file path is INVALID.. [%S%S]\n", dirname_ptr, filename_ptr);
	for(i=0; i<strlen(filename);i++)
		MBT_PI(" new filename[%d]:%c", i,filename[i], 0);
	for(i=0; i<strlen(dirname);i++)
		MBT_PI(" new dirname[%d]:%c", i,dirname[i], 0);
	return OI_FAIL;
	 
}

/*===========================================================================

FUNCTION
  file_check_overwrite_rule 
   
DESCRIPTION
   
===========================================================================*/
bt_cmd_status_type qbt_file_check_name_type(MBT_CHAR* file_name)
{
	char* p;
	int strLen = strlen(file_name);
	strcpy(path_temp, file_name);
	p = path_temp;
	for(;;)
	{
		if (*p == 0x0000)
			break;
		if (*p >0x0040 && *p <0x005B)
			*p	+= 0x20;
		p++;
	}
	p = path_temp;
#ifndef SYSTEM_BT_SUPPORT_VMSG_VNOTE
	if (strLen > strlen(".vnt")) 
	{
		p += strLen - strlen(".vnt");
	}
	if (strcmp(p, ".vnt") == 0) {
		/*
		* Reject VNote
		*/
		MBT_PI("[UTIL] vnote format is not supported",0, 0, 0);
		return OI_STRING_FORMAT_ERROR;
	}
#endif
	return OI_OK;
}

MBT_BOOL qbt_IsLastCharSlash(MBT_CHAR *str)
{
	MBT_BYTE pos = strlen(str) - 1;

	if(*(str + pos) == '/' || *(str + pos) == '\\')
	{
		MBT_PI("     IsLastCharSlash TRUE : %s", str, 0, 0);
		return TRUE;
	}
	else
	{
		MBT_PI("     IsLastCharSlash FALSE : %s", str, 0, 0);
		return FALSE;
	}
		
}

