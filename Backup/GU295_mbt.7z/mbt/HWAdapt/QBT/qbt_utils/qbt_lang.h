/*******************************************************************************
********************************************************************************/
#ifndef _QBT_LANG_PI_H_
#define _QBT_LANG_PI_H_
/********************************************************************************
*	File Name	: qbt_lang.h
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.11.26		Lee,DongHyun			Created
********************************************************************************/
#include "MBTType.h"

MBT_SHORT mbt_ucs2_to_local(
	MBT_SHORT *ucs2_str,
	MBT_SHORT ucs2_len,
	MBT_CHAR *local_str,
	MBT_SHORT buf_len,
	MBT_CHAR subst_char);

MBT_SHORT mbt_ucs2_to_utf8(
	MBT_SHORT *ucs2_str,
	MBT_SHORT ucs2_len,
	MBT_CHAR *utf8_str,
	MBT_SHORT buf_len);

MBT_SHORT mbt_utf8_to_ucs2(
	MBT_CHAR *utf8_str,
	MBT_SHORT utf8_len,
	MBT_SHORT *ucs2_str,
	MBT_SHORT buf_len);

MBT_SHORT mbt_utf8_to_local(
	MBT_CHAR *utf8_str,
	MBT_SHORT utf8_len,
	MBT_CHAR *local_str,
	MBT_SHORT buf_len,
	MBT_CHAR subst_char);

MBT_SHORT mbt_local_to_utf8(
	MBT_CHAR *local_str,
	MBT_SHORT local_len,
	MBT_CHAR *utf8_str,
	MBT_SHORT buf_len);

#endif//_QBT_LANG_PI_H_
