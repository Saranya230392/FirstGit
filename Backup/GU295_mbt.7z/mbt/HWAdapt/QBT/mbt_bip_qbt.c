/********************************************************************************
*	File Name	: mbt_bip_qbt.c
*	Description	:
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.12.12	Su-Hui, Kim			Created
********************************************************************************/
#include "mbt_bip.h"

#if (MBT_BIP == MBT_TRUE)
/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_enable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_initiator_enable(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#endif
}


/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_disable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_initiator_disable (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_pushimage (T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBtObject)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_initiator_pushimage(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBtObject)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_pushthumbnail (T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBtObject)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_initiator_pushthumbnail(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBtObject)
{
#ifdef MBT_EMULATOR
#else
#endif
}

MBT_VOID mbt_bip_Initiator_auth_response(T_MBT_OBEX_AUTH *auth_reply)
{
#ifdef MBT_EMULATOR
#else
#endif
}

MBT_VOID mbt_bip_Initiator_getcapability_request(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBtObject)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_enable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_responder_enable(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_disable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_responder_disable (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_responder_disconnect (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_responder_disconnect(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#endif
}

MBT_VOID mbt_bip_responder_auth_response(T_MBT_OBEX_AUTH *auth_reply)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_responder_access_response (T_MBT_AUTHRES Reply)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_responder_access_response(T_MBT_AUTHRES Reply)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bip_getcapabilityresp (T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBtObject)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bip_responder_getcapability_response(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBtObject)
{
#ifdef MBT_EMULATOR
#else
#endif
}
#endif	//#if (MBT_BIP == MBT_TRUE)

