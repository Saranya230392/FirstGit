/*-----------------------------------------------------------------------------
File qbt_bpp.c

GENERAL DESCRIPTION
This file contains bpp hooks to/from QBT Stack from/to MBT BT Layer.

Copyright (c) 2009 QUALCOMM Incorporated.
All Rights Reserved.
Qualcomm Confidential and Proprietary
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------

                        EDIT HISTORY FOR MODULE

  This section contains comments describing changes made to the module.
  Notice that changes are listed in reverse chronological order.

  $Header: None $
  $DateTime: None $
  $Author: ytkim $

  when        who  what, where, why
  ----------  ---  ------------------------------------------------------------
  2009-01-15   BK  Initial Revision

-----------------------------------------------------------------------------*/
#include "mbt_bpp.h"
#include "btpfcmdi.h"
#include "btpf.h"
#include "oi_unicode.h"
#include "AEEstd.h"

#include "qbt_utils/qbt_fs.h"
#include "qbt_utils/qbt_utils.h"

#define MBT_BPP_FILENAME_LOG

// MIME media-type formats
#define MBT_BPP_DOC_TYPE_XHTML_PRINT      "application/vnd.pwg-xhtml-print+xml:0.95"
#define MBT_BPP_DOC_TYPE_XHTML_PRINT10    "application/vnd.pwg-xhtml-print+xml:1.0"
#define MBT_BPP_DOC_TYPE_MULTIPLEXED      "application/vnd.pwg-multiplexed"
#define MBT_BPP_DOC_TYPE_BASIC_TEXT       "text/plain"
#define MBT_BPP_DOC_TYPE_VCARD            "text/x-vcard:2.1"
#define MBT_BPP_DOC_TYPE_VCARD_3_0        "text/x-vcard:3.0"
#define MBT_BPP_DOC_TYPE_VCALENDAR        "text/x-vcalendar:1.0"
#define MBT_BPP_DOC_TYPE_ICALENDAR        "text/calendar:2.0"
#define MBT_BPP_DOC_TYPE_VMESSAGE         "text/x-vmessage:1.1"
#define MBT_BPP_DOC_TYPE_VNOTE            "text/x-vnote:1.1"
#define MBT_BPP_DOC_TYPE_JPEG             "image/jpeg"
#define MBT_BPP_DOC_TYPE_GIF              "image/gif"
#define MBT_BPP_DOC_TYPE_POSTSCRIPT       "application/postscript"
#define MBT_BPP_DOC_TYPE_PCL5E            "application/vnd.hp-PCL:5E"
#define MBT_BPP_DOC_TYPE_PCL3C            "application/vnd.hp-PCL:3C"
#define MBT_BPP_DOC_TYPE_PDF              "application/PDF"

typedef struct {
	bt_app_id_type		          app_id;
	bt_pf_bpp_sndr_conn_id_type conn_id;
	uint8                       scn;
  	bt_pf_bpp_target_type       target;
	fs_handle_type  	          fs_handle;
	uint32                      sent_size;
  	uint16                      file_name[MBT_MAX_FILE_NAME_LEN+1];
} mbt_qbt_bpp_object;

static mbt_qbt_bpp_object qbt_bpp_sndr = { 
  BT_APP_ID_NULL, BT_PF_BPP_NO_CONN_ID, 0, 0, 0, 0 };

static char filename[BT_PF_MAX_FILENAME_LEN*3+1];
static MBT_BYTE mbt_qbt_bpp_buf[MBT_OBEX_FILE_BUF_LEN+1];

static bt_pf_byte_seq_type bpp_byte_seq = {0, 0};

static MBT_BOOL mbt_bpp_CheckCmdStatus( bt_cmd_status_type stat );
static MBT_VOID mbt_bpp_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );
static T_MBT_AUTHRES qbt_bpp_MapCmdStatus(bt_cmd_status_type status);
static bt_cmd_status_type qbt_bpp_send_file(T_MBT_BPP_OBJECT* bpp_obj);
static MBT_VOID qbt_bpp_disconnect(MBT_VOID);
static MBT_VOID qbt_bpp_file_close(MBT_VOID);
static char* qbt_bpp_MapDocumentType(T_MBT_MIME_MEDIA docType);

#if (MBT_BPP == MBT_TRUE)
/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_enable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bpp_enable(MBT_VOID)
{
#ifdef MBT_EMULATOR
  	MBT_ERR("BPP Sender enable called with MBT_EMULATOR defined", 0, 0, 0);
#else
  	bt_cmd_status_type bpp_rst;
  	T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

 	 if(sdcBppStatus->bEnabled == MBT_FALSE)
  	{
    		/* get app_id */
    		qbt_bpp_sndr.app_id = bt_cmd_ec_get_app_id_and_register(mbt_bpp_EventCallback);
    		if (qbt_bpp_sndr.app_id == BT_APP_ID_NULL) 
    		{
     			 MBT_ERR("mbt_bpp_enable> BPP App id register error. app_id : NULL",0,0,0);
      			mbt_postevent(MBTEVT_BPP_ENABLE_FAIL, 0);
      			return;
    		}
  	}
	else
	{
    		MBT_WARN("mbt_bpp_enable> Bpp is aleady enabled. Don't proceed & return",0,0,0);
    		mbt_postevent(MBTEVT_BPP_ENABLE_FAIL, 0);
    		return;
	}

  	bpp_rst = bt_cmd_pf_bpp_sndr_register( qbt_bpp_sndr.app_id,
                                         "LGE BPP Sender");
  	if(!mbt_bpp_CheckCmdStatus(bpp_rst))
  	{	
    		MBT_ERR("BPP Sender Enable Fail. Reason code : %x",bpp_rst,0,0);
    		mbt_postevent(MBTEVT_BPP_ENABLE_FAIL, 0);
  	}
#endif
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_disable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bpp_disable (MBT_VOID)
{
#ifdef MBT_EMULATOR
  MBT_ERR("BPP Sender disable called with MBT_EMULATOR defined", 0, 0, 0);
#else
	bt_cmd_status_type bpp_rst;
	T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

	if(sdcBppStatus->bEnabled == MBT_TRUE)
	{
    		bpp_rst = bt_cmd_pf_bpp_sndr_deregister(qbt_bpp_sndr.app_id);
   		if(!mbt_bpp_CheckCmdStatus(bpp_rst))
    		{
      			MBT_ERR("mbt_bpp_disable> deregister fail. Reason code : %x",bpp_rst,0,0);
      			mbt_postevent(MBTEVT_BPP_DISABLE_FAIL, 0);
    		}
	}
	else
	{
		MBT_WARN("mbt_bpp_disable> Bpp is aleady disabled. Don't proceed & return",0,0,0);
		mbt_postevent(MBTEVT_BPP_DISABLE_FAIL, 0);
	}
#endif
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_print (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bpp_print(T_MBT_BDADDR BdAddr, T_MBT_BPP_OBJECT *MBtObject)
{
#ifdef MBT_EMULATOR
  	MBT_ERR("BPP Sender Print called with MBT_EMULATOR defined", 0, 0, 0);
#else
  	bt_cmd_status_type cmd_status = BT_CS_GN_SUCCESS;
  	T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

  	MBT_PI("BPP print: state:%x", sdcBppStatus->State, 0, 0);
	memcpy(sdcBppStatus->BDAddr,BdAddr, MBT_BDADDR_LEN);

  	memcpy((void*)&sdcBppStatus->PrintingFile,
         	(void*)MBtObject,
         	sizeof(sdcBppStatus->PrintingFile));

  	if (sdcBppStatus->State == MBT_BPP_STATE_ENABLED) 
  	{
    		mbt_gap_allow_role_switch(sdcBppStatus->BDAddr);
    		(void) bt_cmd_pf_bpp_sndr_connect(qbt_bpp_sndr.app_id,
                                      		(bt_bd_addr_type*) BdAddr,
                                      		0, // scn
                                      		BT_PF_BPP_TARGET_DPS);

    		sdcBppStatus->State = MBT_BPP_STATE_PRINTING;
  	}
	else if (sdcBppStatus->State == MBT_BPP_STATE_CONNECTED)
	{
    		cmd_status = qbt_bpp_send_file(&sdcBppStatus->PrintingFile);
    		if (!mbt_bpp_CheckCmdStatus(cmd_status)) 
    		{
      			mbt_gap_restore_role_switch(sdcBppStatus->BDAddr);
      			sdcBppStatus->FailReason = qbt_bpp_MapCmdStatus(cmd_status);
      			mbt_postevent(MBTEVT_BPP_PRINT_COMPLETE_FAIL, 0);
    		}
    		else
    		{
      			sdcBppStatus->State = MBT_BPP_STATE_PRINTING;
      			mbt_postevent(MBTEVT_BPP_PROGRESS, 0);
    		}
	}
	else
	{
		mbt_gap_restore_role_switch(sdcBppStatus->BDAddr);
		MBT_ERR("BPP print: invalid state : %x", sdcBppStatus->State, 0, 0);

    		sdcBppStatus->FailReason = qbt_bpp_MapCmdStatus(cmd_status);
		mbt_postevent(MBTEVT_BPP_PRINT_COMPLETE_FAIL, 0);
	}
#endif
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_getprinterattribute (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bpp_getprinterattribute(T_MBT_BDADDR BdAddr, MBT_INT PrinterAttr)
{
#ifdef MBT_EMULATOR
  MBT_ERR("BPP Sender GetAttrib called with MBT_EMULATOR defined", 0, 0, 0);
#else
  MBT_ERR("BPP Sender GetAttrib not supported", 0, 0, 0);
#endif
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_disconnect (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bpp_disconnect(MBT_VOID)
{
#ifdef MBT_EMULATOR
  MBT_ERR("BPP Sender disconnect called with MBT_EMULATOR defined", 0, 0, 0);
#else
  T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

  MBT_PI("BPP disconnect : state:%x", sdcBppStatus->State, 0, 0);
  mbt_gap_restore_role_switch(sdcBppStatus->BDAddr);
  if (sdcBppStatus->State == MBT_BPP_STATE_CONNECTED)
  {
    qbt_bpp_disconnect();
  }
  else if(sdcBppStatus->State == MBT_BPP_STATE_PRINTING)
  {
    MBT_PI("mbt_bpp_disconnect: aborting file transfer", 0, 0, 0);
    (void) bt_cmd_pf_bpp_sndr_abort(qbt_bpp_sndr.app_id, qbt_bpp_sndr.conn_id);

#if 0
    // issue dummy PUT request for Abort to be actually sent
    (void) bt_cmd_pf_bpp_sndr_send_file(qbt_bpp_sndr.app_id, qbt_bpp_sndr.conn_id,
                                        NULL, NULL, NULL, NULL, NULL, 1);
#else	// original code do not work properly. just do like normal disconnection. JG Kwon. 2009.11.17
    qbt_bpp_file_close();
    qbt_bpp_disconnect();
    mbt_postevent(MBTEVT_BPP_CANCEL_SUCCESS, 0);
#endif
  }
  else if(sdcBppStatus->State < MBT_BPP_STATE_CONNECTED) 
  {
    MBT_ERR("mbt_bpp_disconnect> Disconnect failed.  No connection", 0,0,0);
    mbt_postevent(MBTEVT_BPP_DISCONNECT_FAIL, 0);
  }
  else
  {
    MBT_ERR("mbt_bpp_disconnect> Disconnect failed.  Invalid state %x", 
            sdcBppStatus->State,0,0);
    mbt_postevent(MBTEVT_BPP_DISCONNECT_FAIL, 0);
  }
#endif
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_auth_response (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_bpp_auth_response(T_MBT_OBEX_AUTH *auth_reply)
{
#ifdef MBT_EMULATOR
  MBT_ERR("BPP Sender auth response called with MBT_EMULATOR defined", 0, 0, 0);
#else
  T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

  MBT_PI("BPP auth response : state:%x", sdcBppStatus->State, 0, 0);

  (void) bt_cmd_pf_bpp_sndr_auth_response(qbt_bpp_sndr.app_id,
                                          qbt_bpp_sndr.target,
                                          (sdcBppStatus->bIsObexUserID)?(byte*)auth_reply->UserId:NULL,
                                          (sdcBppStatus->bIsObexUserID)?std_strlen(auth_reply->UserId):0,
                                          (auth_reply->bAuth)?(auth_reply->Passwd):NULL);
#endif
  return;
}


/********************************************************************************
*	Prototype	: MBT_VOID qbt_bpp_send_file (MBT_VOID)
*	Description	: 
********************************************************************************/
static bt_cmd_status_type qbt_bpp_send_file(T_MBT_BPP_OBJECT* bpp_obj)
{
	bt_cmd_status_type cmd_status = BT_CS_GN_SUCCESS;
  	T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);
  	uint16 filename_len;
  	uint16* file_name = NULL;
  	char* mime_type = NULL;
	MBT_BYTE* data_ptr = NULL;
	uint32	data_len = 0;
  	MBT_BOOL  final = MBT_FALSE;		

  	if (qbt_bpp_sndr.fs_handle == 0) 
  	{	
    		// first time, reset counters
    		sdcBppStatus->TxProgress = 0;

    		// convert filename to wide string
		mbt_ucs2_to_utf8(bpp_obj->FileName, 0,  qbt_bpp_sndr.file_name, 0);
   		file_name = qbt_bpp_sndr.file_name;

    		// convert mime_type enum to string
    		mime_type = qbt_bpp_MapDocumentType(bpp_obj->MimeType);

		// build dir/filename string
    		filename_len = strlen(bpp_obj->DirName);
    		if ( bpp_obj->DirName[filename_len-1] != '/' )
    		{
      			bpp_obj->DirName[filename_len++] = '/';
    		}
    		bpp_obj->DirName[filename_len] = 0x00;
		sprintf(filename, "%s%s", bpp_obj->DirName, bpp_obj->FileName);

    		// open file for reading
    		cmd_status = qbt_file_open_read(&qbt_bpp_sndr.fs_handle, &bpp_obj->ObjectSize, filename);
  	}

  	if (mbt_bpp_CheckCmdStatus(cmd_status)) 
  	{
  		data_ptr = mbt_qbt_bpp_buf;
		
    		// read the first chunck of data
    		cmd_status = qbt_file_read(qbt_bpp_sndr.fs_handle, MBT_OBEX_FILE_BUF_LEN, 
                               		(uint32*)&data_len, data_ptr, 
                               		(uint32)bpp_obj->ObjectSize);

		if ( cmd_status == OI_OK || cmd_status == OI_STATUS_END_OF_FILE )
    		{
      			bpp_byte_seq.data = data_ptr;
      			bpp_byte_seq.len = (uint16)data_len;
      			final = (data_len < MBT_OBEX_FILE_BUF_LEN)?MBT_TRUE:MBT_FALSE;
	
      			cmd_status = bt_cmd_pf_bpp_sndr_send_file(qbt_bpp_sndr.app_id,
                        	                        qbt_bpp_sndr.conn_id,
                                	                mime_type,
                                	                NULL, /* description string */
                                	                file_name,
                                	                NULL, /* job_id_ptr */
                                	                &bpp_byte_seq,
                                	                final);

      			if (mbt_bpp_CheckCmdStatus(cmd_status))
      			{
        			sdcBppStatus->TxProgress += (uint16)data_len; 
		    		MBT_PI("mbt bpp: succ read : %d/%d", sdcBppStatus->TxProgress, 
               			sdcBppStatus->PrintingFile.ObjectSize, 0);
      			}
    		}
  	}

  	return cmd_status;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_send_fail_evt (mbt_qbt_bpp_operation operation)
*	Description	: 
********************************************************************************/
static MBT_VOID mbt_bpp_send_fail_evt(T_MBT_BPP_STATE state)
{
	if (state == MBT_BPP_STATE_PRINTING)
  {
		//mbt_postevent(MBTEVT_BPP_PRINT_COMPLETE_FAIL, 0);	// �� �Լ��� PRINTING state���� �Ҹ��� ���� connect�� ���� ������ ���̴�.
		mbt_postevent(MBTEVT_BPP_CONNECT_FAIL, 0);	 		//MBTEVT_BPP_PRINT_COMPLETE_FAIL �� �÷��ָ� PhoneMngr���� disconnect�� �����ؼ� �̺�Ʈ�� ���δ�. JG Kwon. 2009.11.13
  }
  else
  {
		MBT_ERR("mbt_bpp_send_fail_evt> unexpected state! %d", state,0,0);
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_bpp_con_cfm (bt_pf_ev_bpp_sndr_con_cfm_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_proc_evt_bpp_con_cfm(bt_pf_ev_bpp_sndr_con_cfm_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status;
	T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

  	MBT_PI("qbt_proc_evt_bpp_con_cfm, status=%x", bt_ev_msg_ptr->status, 0, 0);
	if (!mbt_bpp_CheckCmdStatus(bt_ev_msg_ptr->status)) 
	{
		MBT_ERR("qbt_proc_evt_bpp_con_cfm, conn failed, status = %x",
            		bt_ev_msg_ptr->status, 0, 0);
		mbt_gap_restore_role_switch(sdcBppStatus->BDAddr);
		mbt_bpp_send_fail_evt(sdcBppStatus->State);
    		sdcBppStatus->State = MBT_BPP_STATE_ENABLED;
		qbt_bpp_sndr.scn = 0;
	}
	else 
	{
		qbt_bpp_sndr.conn_id = bt_ev_msg_ptr->conn_id;
    		if (sdcBppStatus->State == MBT_BPP_STATE_PRINTING) 
    		{
      			cmd_status = qbt_bpp_send_file(&sdcBppStatus->PrintingFile);
      			if (!mbt_bpp_CheckCmdStatus(cmd_status)) 
      			{
        			sdcBppStatus->FailReason = qbt_bpp_MapCmdStatus(cmd_status);
        			sdcBppStatus->State = MBT_BPP_STATE_CONNECTED;
        			mbt_bpp_send_fail_evt(sdcBppStatus->State);

        			qbt_bpp_file_close();
        			qbt_bpp_disconnect();
      			}
      			else
      			{
        			mbt_postevent(MBTEVT_BPP_PROGRESS, 0);
      			}
    		}
    		else
    		{
		  	MBT_ERR("qbt_proc_evt_bpp_con_cfm, bad state = %x, disconnecting..",
             			sdcBppStatus->State, 0, 0);
      			mbt_gap_restore_role_switch(sdcBppStatus->BDAddr);
      			qbt_bpp_disconnect();
    		}	
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_bpp_dcn_cfm (bt_pf_ev_bpp_sndr_dcn_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_bpp_dcn_ind(bt_pf_ev_bpp_sndr_dcn_ind_type *bt_ev_msg_ptr)
{
	T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

	MBT_PI("qbt_proc_evt_bpp_dcn_ind> conn_id:%x state:%x", 
         bt_ev_msg_ptr->conn_id, sdcBppStatus->State, 0);
	mbt_gap_restore_role_switch(sdcBppStatus->BDAddr);
	sdcBppStatus->State = MBT_BPP_STATE_ENABLED;
	qbt_bpp_sndr.conn_id = BT_PF_BPP_NO_CONN_ID;
	qbt_bpp_sndr.scn = 0;

  if (sdcBppStatus->State == MBT_BPP_STATE_DISCONNECTING)
  {
    mbt_postevent(MBTEVT_BPP_DISCONNECT_SUCCESS, 0);
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_bpp_auth_req (bt_pf_ev_bpp_sndr_dcn_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_bpp_auth_req(bt_pf_ev_bpp_sndr_auth_req_type *bt_ev_msg_ptr)
{
	T_MBT_BPP_STATUS *sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

	MBT_PI("qbt_proc_evt_bpp_auth_req> target:%x user_id_req:%x state:%x", 
         bt_ev_msg_ptr->target, bt_ev_msg_ptr->user_id_required, sdcBppStatus->State);
  sdcBppStatus->bIsObexUserID = bt_ev_msg_ptr->user_id_required;
  qbt_bpp_sndr.target = bt_ev_msg_ptr->target; /* need to send this in resp */
  mbt_postevent(MBTEVT_BPP_OBEX_AUTHREQ, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_bpp_send_file_cfm (bt_pf_ev_bpp_sndr_dcn_ind_type *bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_bpp_send_file_cfm(bt_pf_ev_bpp_sndr_send_file_cfm_type *bt_ev_msg_ptr)
{
	bt_cmd_status_type cmd_status = BT_CS_GN_SUCCESS;
	T_MBTEVT mbt_evt = MBTEVT_BPP_PROGRESS;
	T_MBT_BPP_STATUS *sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);
 	fs_rsp_msg_type fs_rsp;

	MBT_PI("qbt_proc_evt_bpp_send_file_cfm> conn_id:%x status:%x state=%x", 
         bt_ev_msg_ptr->conn_id, bt_ev_msg_ptr->status, sdcBppStatus->State);

  	if (bt_ev_msg_ptr->status == BT_CS_PF_OBEX_CONTINUE) 
  	{
    		// more to send
    		cmd_status = qbt_bpp_send_file(&sdcBppStatus->PrintingFile);
    		if (!mbt_bpp_CheckCmdStatus(cmd_status)) 
    		{
      			mbt_evt = MBTEVT_BPP_PRINT_COMPLETE_FAIL;
      			sdcBppStatus->FailReason = qbt_bpp_MapCmdStatus(cmd_status);
      			qbt_bpp_file_close();
      			qbt_bpp_disconnect();
    		}
  	}
  	else if (bt_ev_msg_ptr->status == BT_CS_GN_SUCCESS) 
  	{
    		// file transfer completed succesfully 
    		qbt_bpp_file_close();
		qbt_bpp_disconnect();
			
    		mbt_evt = MBTEVT_BPP_PRINT_COMPLETE_SUCCESS;
  	}
  	else if (bt_ev_msg_ptr->status == BT_CS_PF_OBEX_UNSUPPORTED_MEDIA_TYPE) 
  	{
    		qbt_bpp_file_close();
    		sdcBppStatus->FailReason = qbt_bpp_MapCmdStatus(cmd_status);
    		mbt_evt = MBTEVT_BPP_PRINT_STATUS;  

    		// app will retry with content type XHTML
    		// leave the connection open
  	}
  	else
  	{
    		// some error occurred, clean up
    		sdcBppStatus->FailReason = qbt_bpp_MapCmdStatus(bt_ev_msg_ptr->status);
    		mbt_evt = MBTEVT_BPP_PRINT_COMPLETE_FAIL;

    		qbt_bpp_file_close();
    		qbt_bpp_disconnect();
  	}

  	mbt_postevent(mbt_evt, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_bpp_disconnect ()
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_bpp_disconnect()
{
  	bt_cmd_status_type cmd_status;
	T_MBT_BPP_STATUS *sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);

  	cmd_status = bt_cmd_pf_bpp_sndr_disconnect(qbt_bpp_sndr.app_id, qbt_bpp_sndr.conn_id);
  	if (!mbt_bpp_CheckCmdStatus(cmd_status))
  	{
    		MBT_ERR("qbt_bpp_disconnect> disconnect failed, reason=%x", 
            		cmd_status, 0, 0);
  	}
  	else
  	{
    		sdcBppStatus->State = MBT_BPP_STATE_DISCONNECTING;
    		/* disconnected evt will be sent to the app after cmd_done evt is rx'ed */
  	}
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_bpp_file_close (MBT_VOID)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_bpp_file_close(MBT_VOID)
{
  	fs_rsp_msg_type fs_rsp;

  	MBT_PI("qbt_bpp_file_close> close file handle %d", qbt_bpp_sndr.fs_handle, 0, 0);
  	if (qbt_bpp_sndr.fs_handle != 0) 
  	{
    		fs_close(qbt_bpp_sndr.fs_handle, NULL, &fs_rsp); 
    		qbt_bpp_sndr.fs_handle = 0;
  	}
}

/********************************************************************************
*	Prototype	: char* qbt_bpp_MapCmdStatus (bt_cmd_status_type status)
*	Description	: 
********************************************************************************/
static T_MBT_AUTHRES qbt_bpp_MapCmdStatus(bt_cmd_status_type status)
{
  	switch (status)
  	{
  		case BT_CS_PF_OBEX_ACCESS_DENIED:
    			return MBT_FORBID_RES;
  		case BT_CS_PF_OBEX_ERROR:
    			return MBT_ERROR_RES;
  		case BT_CS_PF_OBEX_UNAUTHORIZED:
    			return MBT_UNAUTHORIZED_RES;
  		case BT_CS_PF_OBEX_NOT_FOUND:
    			return MBT_NOT_FOUND_RES;
  		case BT_CS_PF_OBEX_UNSUPPORTED_MEDIA_TYPE:
    			return MBT_UNSUPPORTED_MEDIA_TYPE_RES;
  		case BT_CS_PF_OBEX_SERVICE_UNAVAILABLE:
    			return MBT_SERVICE_UNAVAILABLE_RES;
  		case BT_CS_PF_OBEX_DATABASE_FULL:
    			return MBT_DATABASE_FULL_RES;
  		case BT_CS_PF_OBEX_INTERNAL_SERVER_ERROR:
  		default:
    			return MBT_INTERNAL_SERVER_ERROR_RES;
  }
}

/********************************************************************************
*	Prototype	: char* qbt_bpp_MapDocumentType (T_MBT_MIME_MEDIA docType)
*	Description	: 
********************************************************************************/
static char* qbt_bpp_MapDocumentType(T_MBT_MIME_MEDIA docType)
{
  	switch ( docType ) 
  	{
  		case MBT_MIME_TYPE_APPLICATION_XHTML_PRINT:
    			return (char*) MBT_BPP_DOC_TYPE_XHTML_PRINT;
  		case MBT_MIME_TYPE_APPLICATION_XHTML_PRINT10:
    			return (char*) MBT_BPP_DOC_TYPE_XHTML_PRINT10;
  		case MBT_MIME_TYPE_APPLICATION_MULTIPLEXED:
    			return (char*) MBT_BPP_DOC_TYPE_MULTIPLEXED;
  		case MBT_MIME_TYPE_TEXT_PLAIN:
    			return (char*) MBT_BPP_DOC_TYPE_BASIC_TEXT;
  		case MBT_MIME_TYPE_TEXT_VCARD:
    			return (char*) MBT_BPP_DOC_TYPE_VCARD;
  		case MBT_MIME_TYPE_TEXT_VCARD30:
    			return (char*) MBT_BPP_DOC_TYPE_VCARD_3_0;
  		case MBT_MIME_TYPE_TEXT_VCALENDAR:
    			return (char*) MBT_BPP_DOC_TYPE_VCALENDAR;
  		case MBT_MIME_TYPE_TEXT_ICALENDAR20:
    			return (char*) MBT_BPP_DOC_TYPE_ICALENDAR;
  		case MBT_MIME_TYPE_TEXT_VMESSAGE:
    			return (char*) MBT_BPP_DOC_TYPE_VMESSAGE;
  		case MBT_MIME_TYPE_TEXT_VNOTE:
    			return (char*) MBT_BPP_DOC_TYPE_VNOTE;
  		case MBT_MIME_TYPE_IMAGE_JPEG:
    			return (char*) MBT_BPP_DOC_TYPE_JPEG;
  		case MBT_MIME_TYPE_IMAGE_GIF:
    			return (char*) MBT_BPP_DOC_TYPE_GIF;
  		case MBT_MIME_TYPE_APPLICATION_POSTSCRIPT:
    			return (char*) MBT_BPP_DOC_TYPE_POSTSCRIPT;
  		case MBT_MIME_TYPE_APPLICATION_HP_PCL_5E:
    			return (char*) MBT_BPP_DOC_TYPE_PCL5E;
  		case MBT_MIME_TYPE_APPLICATION_HP_PCL_3C:
    			return (char*) MBT_BPP_DOC_TYPE_PCL3C;
  		case MBT_MIME_TYPE_APPLICATION_PDF:
    			return (char*) MBT_BPP_DOC_TYPE_PDF;
  		default:
    			MBT_ERR( "qbt_bpp_MapDocumentType> wrong document type=%x", docType, 0, 0 );
    			return NULL;
  	}
}

/********************************************************************************
*	Prototype	: MBT_BOOL mbt_bpp_CheckCmdStatus (bt_cmd_status_type stat)
*	Description	: 
********************************************************************************/
static MBT_BOOL mbt_bpp_CheckCmdStatus(bt_cmd_status_type stat)
{
	switch (stat)
	{
		case BT_CS_GN_SUCCESS:
		case BT_CS_GN_PENDING:
			return MBT_TRUE; //SUCCESS;

		case BT_CS_GN_CMD_Q_FULL:
			MBT_ERR("mbt_bpp_CheckCmdStatus state:%d", stat,0,0);
			return MBT_FALSE; //ENOMEMORY;

		default:
			MBT_ERR("mbt_bpp_CheckCmdStatus state:%d", stat,0,0);
			return MBT_FALSE; //EFAILED;
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_HandleCmdDone( bt_ev_msg_type* bt_ev_msg_ptr )
*	Description :
********************************************************************************/
static MBT_VOID mbt_bpp_HandleCmdDone( bt_ev_gn_cmd_done_type* pCmdDn )
{
	T_MBT_BPP_STATUS * sdcBppStatus = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);
  	bt_cmd_status_type bpp_rst;

  	switch ( pCmdDn->cmd_type )
  	{
    		case BT_PF_CMD_BPP_SNDR_REGISTER:
    		{
      			if(mbt_bpp_CheckCmdStatus(pCmdDn->cmd_status))
      			{	
        			sdcBppStatus->bEnabled = MBT_TRUE;
        			sdcBppStatus->State = MBT_BPP_STATE_ENABLED;
        			MBT_PI("BPP Sender Enabled",0,0,0);
        			mbt_postevent(MBTEVT_BPP_ENABLE_SUCCESS, 0);
      			}
      			else
      			{
        			sdcBppStatus->bEnabled = MBT_FALSE;
        			sdcBppStatus->State = MBT_BPP_STATE_DISABLED;
        			MBT_ERR("BPP Sender Enable Fail. Reason code : %x",pCmdDn->cmd_status,0,0);
        			mbt_postevent(MBTEVT_BPP_ENABLE_FAIL, 0);
      			}
      			break;
    		}
    		case BT_PF_CMD_BPP_SNDR_DEREGISTER:
    		{
      			if(mbt_bpp_CheckCmdStatus(pCmdDn->cmd_status))
      			{	
        			sdcBppStatus->bEnabled = MBT_FALSE;
        			sdcBppStatus->State = MBT_BPP_STATE_DISABLED;

        			bpp_rst = bt_cmd_ec_free_application_id(qbt_bpp_sndr.app_id);
        			if(mbt_bpp_CheckCmdStatus(bpp_rst))
        			{
          				MBT_PI("BPP Disabled",0,0,0);
          				qbt_bpp_sndr.app_id = BT_APP_ID_NULL;
          				mbt_postevent(MBTEVT_BPP_DISABLE_SUCCESS, 0);
        			}
        			else
        			{
          				MBT_ERR("mbt_bpp_dereg_and_free_app_id> free app_id fail. Reason code : %x",bpp_rst,0,0);
          				mbt_postevent(MBTEVT_BPP_DISABLE_FAIL, 0);
        			}
      			}
      			else
      			{
        			MBT_ERR("BPP Sender Disable Fail. Reason code : %x",pCmdDn->cmd_status,0,0);
        			mbt_postevent(MBTEVT_BPP_DISABLE_FAIL, 0);
      			}
      			break;
    		}
    		case BT_PF_CMD_BPP_SNDR_DISCONNECT:
    		{
      			if(!mbt_bpp_CheckCmdStatus(pCmdDn->cmd_status))
      			{
        			MBT_PI("BPP Disconnect failed, status=%x", pCmdDn->cmd_status,0,0);
        			mbt_postevent(MBTEVT_BPP_DISCONNECT_FAIL, 0);
      			}  
      			break;
    		}
    		case BT_PF_CMD_BPP_SNDR_CONNECT:
    		{
      			if(!mbt_bpp_CheckCmdStatus(pCmdDn->cmd_status))
      			{
        			MBT_PI("BPP Connect failed, status=%x", pCmdDn->cmd_status,0,0);
        			mbt_postevent(MBTEVT_BPP_CONNECT_FAIL, 0);
      			}  
      			break;
    		}
    		default:
    		{
      			MBT_PI("mbt_bpp_HandleCmdDone, cmd=%x, status=%x", 
             			pCmdDn->cmd_type, pCmdDn->cmd_status, 0);
    		}
  	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_bpp_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
*	Description :
********************************************************************************/
static MBT_VOID mbt_bpp_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{
	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
			MBT_PI("mbt_bpp_cmd_done> cmd:%x status:%x", 
             			bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type, 
             			bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status, 0);
      			mbt_bpp_HandleCmdDone(&bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done);
	    		break;

		case BT_EV_PF_BPP_SNDR_CON_CFM:
			qbt_proc_evt_bpp_con_cfm(&bt_ev_msg_ptr->ev_msg.ev_bpp_sndr_con_cfm);
			break;

		case BT_EV_PF_BPP_SNDR_DCN_IND:
			qbt_proc_evt_bpp_dcn_ind(&bt_ev_msg_ptr->ev_msg.ev_bpp_sndr_dcn_ind);
			break;

		case BT_EV_PF_BPP_SNDR_SEND_FILE_CFM:
			qbt_proc_evt_bpp_send_file_cfm(&bt_ev_msg_ptr->ev_msg.ev_bpp_sndr_send_file_cfm);
			break;

    		case BT_EV_PF_BPP_SNDR_AUTH_REQ:
			qbt_proc_evt_bpp_auth_req(&bt_ev_msg_ptr->ev_msg.ev_bpp_sndr_auth_req);
			break;

		default:
			MBT_ERR("mbt_bpp_EventCallback> evt:%d", bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0);
			break;
	}
}

#endif

