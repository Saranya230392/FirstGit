/********************************************************************************
*	File Name	: mbt_gap_brcm.c
*	Description	:
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.11.07		Lee,ChangHoon			Created
********************************************************************************/
#include "mbt_gap.h"
#if (MBT_AG == MBT_TRUE)
#include "mbt_ag.h"
#endif
#if (MBT_OPP == MBT_TRUE)
#include "mbt_opp.h"
#endif
#if (MBT_FTP == MBT_TRUE)
#include "mbt_ftp.h"
#endif
#if (MBT_DUN == MBT_TRUE)
#include "mbt_dun.h"
#endif
#if (MBT_SPP == MBT_TRUE)
#include "mbt_spp.h"
#endif
#if (MBT_A2DP == MBT_TRUE)
#include "mbt_a2dp.h"
#endif
#if (MBT_AVRCP == MBT_TRUE)
#include "mbt_avrcp.h"
#endif

#include "mbt_sdc.h"
#include "qbt_utils/qbt_utils.h"
#include "mbt_evhandler.h"
#include "include/mbt_internal_func.h"

#include "bt.h"
#include "btsd.h"

#include <math.h>

typedef enum
{
	BTSD_IDLE,
	BTSD_SEARCHING,
	BTSD_NAME_REQUEST,
	BTSD_CANCEL
} MBT_SD_state_type;

enum
{
	UNPAIR_CMD,
	UNPAIR_ALL_CMD
};


#define BT_L2_PSM_AVCTP 0x0017
#define BT_L2_PSM_AVDTP 0x0019


#define COD_MINOR_CLASS(u8, pd)         {u8  = pd[2]&0xFC;}
#define COD_MAJOR_CLASS(u8, pd)         {u8  = pd[1]&0x1F;}
#define COD_SERVICE_CLASS(u16, pd)      {u16 = pd[0]; u16<<=8; u16 += pd[1]&0xE0;}


//----------------ACL link ���� -------------------------//
#define MBT_MAX_ACL_CONNECTION	4
typedef struct _MBT_RM_HANDLE_TYPE
{
	MBT_BOOL           		bInUse;
	bt_rm_handle_type 	handle;
	bt_bd_addr_type   		bdAddr;
} MBT_RM_HANDLE_TYPE;

MBT_RM_HANDLE_TYPE handleMap[MBT_MAX_ACL_CONNECTION];



MBT_SD_state_type sdStatus = BTSD_IDLE;
static uint16 gDeviceRecordsIdx = 0;
bt_app_id_type  mbt_rm_app_id = BT_APP_ID_NULL; //RM
bt_app_id_type  mbt_sd_app_id = BT_APP_ID_NULL; //SD
static MBT_INT btNameRespIdx = 0;

/*------------AUTHORIZATION-------------*/
static bt_sd_uuid_type  		auth_service_type;
static bt_serv_id_method_type  auth_service_id_method;

/*------------extern variable-------------*/
extern int  diableAll;
extern MBT_BOOL authoReqJSR82;
extern bt_app_id_type  mbt_jsr82_app_id;


/*------------extern functions-------------*/
extern bt_rm_handle_type 	jsr82Handle;
extern bt_app_id_type		acl_app_id;
extern MBT_BOOL bSearchPending;
/*-----------------local variable-----------------------*/// �Լ������� stack ������ �����ϱ⿡ �ʹ� ��ġ�� Ŀ�� �������� ������ ���. �ΰ����� ���ÿ� ��� ����
bt_device_type      device;
bt_service_type     svcs[MBT_MAXNUM_SVC_FIELD]; // AEEBT_MAX_NUM_OF_SRV_REC ];
uint16 UUIDs16[MBT_MAXNUM_SVC_FIELD];
bt_rm_dev_iterator_type iterator;
bt_bd_addr_type pairreq_addr; // LEECHANGHOON 2008-1-7 local -> remote pair req�ϴ� bd addrs.
MBT_BYTE Unpair_cmd_flag;	// LEECHANGHOON 2008-2-14 Unpair,Unpair_all cmd������ ����.
MBT_BYTE Unpair_cnt;	// LEECHANGHOON 2008-2-14 Unpair,Unpair_all cmd������ ����.
MBT_BYTE Unpaired_cnt;	// LEECHANGHOON 2008-2-14 Unpair,Unpair_all cmd������ ����.


/*------------static functions-------------*/

static MBT_INT mbt_gap_db_deviceread(bt_app_id_type        bt_app_id, bt_device_type* pDevice);
static MBT_BOOL mbt_gap_CheckCmdStatus( bt_cmd_status_type stat );
static MBT_VOID mbt_gap_RM_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr);
static MBT_INT mbt_gap_register_ACL_ConStatus(void);

static MBT_BOOL mbt_gap_CheckCmdStatus( bt_cmd_status_type stat )
{
	switch (stat)
	{
		case BT_CS_GN_SUCCESS:
		case BT_CS_GN_PENDING:
			return MBT_TRUE; //SUCCESS;

		case BT_CS_GN_CMD_Q_FULL:
			return MBT_FALSE; //ENOMEMORY;

		default:
			return MBT_FALSE; //EFAILED;
	}
}

MBT_VOID mbt_gap_update_pairedList()
{
	T_MBT_PAIRED_DEV_LIST* btPairedList =(T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
	MBT_INT i=0,j;
	MBT_BYTE uNumSvcs;
	bt_cmd_status_type  stat;

	memset((void*)btPairedList, 0x00, sizeof(T_MBT_PAIRED_DEV_LIST));
	
	iterator.reset = MBT_TRUE;
	iterator.bonded = MBT_TRUE;
	iterator.control = BT_RM_IC_MATCH_BONDED;
	uNumSvcs = MBT_MAXNUM_SVC_FIELD;

	MBT_WARN("Update pairedList starting....",0,0,0);
	stat = bt_cmd_rm_device_read_iter( mbt_rm_app_id, &iterator, &device, &uNumSvcs, svcs );
	 
	if(mbt_gap_CheckCmdStatus(stat))
	{
		for(i=0; i< MBT_MAXNUM_PAIRED_DEV; i++)//while( device.valid )
		{
			if(!device.valid)
				break;
			memcpy(btPairedList->PairedList[i].BdAddr, (uint8*)device.bd_addr.bd_addr_bytes, MBT_BDADDR_LEN);
			memcpy(btPairedList->PairedList[i].Name, (uint8*)device.name_str, MBT_MAX_NAME_LEN+1);
			memcpy(btPairedList->PairedList[i].NickName, (uint8*)device.nick_name_str, MBT_MAX_NAME_LEN+1);

			for(j=0; j< uNumSvcs; j++)
				btPairedList->PairedList[i].ServiceList.Service[j] = svcs[j].service_class;

			btPairedList->PairedList[i].bAuthorized = device.value_2;
			btPairedList->PairedList[i].MajorClass = (device.major_dev_class) >> 8;
			btPairedList->PairedList[i].MinorClass = device.minor_dev_class;
			btPairedList->PairedList[i].ServiceClass = device.service_class;
			//btPairedList->PairedList[i].bLinkKeyValid = 
			//btPairedList->PairedList[i].LinkKey = 
			btPairedList->PairedList[i].Security = device.security;
			iterator.reset = MBT_FALSE;
			stat = bt_cmd_rm_device_read_iter( mbt_rm_app_id, &iterator, &device, &uNumSvcs, svcs );
			if(!mbt_gap_CheckCmdStatus(stat))
			{
				if(stat == BT_CS_RM_NO_DEVICE)
					MBT_ERR("Device read NO Device",0,0,0);
				else
					MBT_ERR("Device read ERROR",0,0,0);
				break;
			}
		}
	}
	else
	{
		if(stat == BT_CS_RM_NO_DEVICE)
			MBT_ERR("Device read NO Device",0,0,0);
		else
			MBT_ERR("Device read ERROR",0,0,0);
	}
	
	btPairedList->PairedCount = i;
}


//----------------------- ACL link ���� ------------------------------------//
static int mbt_gap_findHandle(bt_rm_handle_type handle, MBT_RM_HANDLE_TYPE* handleMap)
{
	int i = 0;
	for (i = 0; i < MBT_MAX_ACL_CONNECTION; i++) {
		if (handleMap[i].bInUse == TRUE && handleMap[i].handle == handle) 
		{
			MBT_PI("mbt_gap_findHandle : find handle success index:%d ", i, 0, 0);
			return i;
		}
	}

	return -1;
}

static void mbt_gap_addHandle(bt_ev_rm_connected_acl_type *info, MBT_RM_HANDLE_TYPE* handleMap)
{
	int i;
	
	if (mbt_gap_findHandle(info->handle, handleMap) != -1) {
		MBT_PI("[RM] handle(%d) is already registered", info->handle, 0, 0);
		return;
	}
	
  	for (i = 0; i < MBT_MAX_ACL_CONNECTION; i++) 
	{
   		if( handleMap[i].bInUse == FALSE ) 
		{
      		handleMap[i].bInUse = TRUE;
      		handleMap[i].handle = info->handle;
      		handleMap[i].bdAddr = *(bt_bd_addr_type*)(&info->bd_addr);
			MBT_PI("mbt_gap_addHandle : add handle success, handle:%x ", info->handle, 0, 0);
      		return;
		}
  	}
  	MBT_WARN("System_BT_RM: Connection table full! handle(%d)",info->handle,0,0);
}

static bt_bd_addr_type* mbt_gap_removeHandle(bt_ev_rm_disconnected_acl_type *info, MBT_RM_HANDLE_TYPE* handleMap)
{
  	int index;
	int debug_cnt;
	if ( (index=mbt_gap_findHandle(info->handle, handleMap)) == -1) {
		MBT_PI("[RM] handle(%d) is already unregistered", info->handle, 0, 0);
		return NULL;
	}
	MBT_PI("mbt_gap_removeHandle : remove handle success handle:%x", info->handle, 0, 0);
	handleMap[index].bInUse = FALSE;

	//debug start
	debug_cnt = 0;
	for(index = 0; index<MBT_MAX_ACL_CONNECTION; index++)
	{
		if(handleMap[index].bInUse != FALSE)
			debug_cnt++;
	}
	MBT_WARN("current active ACL CNT : %d", debug_cnt, 0,0);
	//debug end
	
	return (bt_bd_addr_type*)(&handleMap[index].bdAddr);
}

static int mbt_gap_getAclLinkCnt(MBT_RM_HANDLE_TYPE* handleMap)
{
	int i = 0;
	int ConnLinkCnt = 0;

	for (i = 0; i < MBT_MAX_ACL_CONNECTION; i++) 
	{
		if (handleMap[i].bInUse == TRUE) 
		{
			ConnLinkCnt++;
		}
	}
	MBT_PI("[mbt_gap_getAclLinkCnt] ConnLink Count %d", ConnLinkCnt, 0, 0);
	return ConnLinkCnt;
}


static int mbt_gap_isAGService(bt_service_id_type service_id)
{
	if( service_id.service_id_method == BT_SIM_SDP_UUID &&
		(service_id.sdp_uuid == BT_SD_SERVICE_CLASS_HEADSET_AUDIO_GATEWAY ||
		service_id.sdp_uuid ==BT_SD_SERVICE_CLASS_HANDSFREE_AUDIO_GATEWAY))
	{
		MBT_PI("[RM] HF/HS Service", 0, 0, 0);
		return TRUE;
	}
	return FALSE;
}

static int mbt_gap_isA2DPService(bt_service_id_type service_id)
{
#if (MBT_A2DP == MBT_TRUE)
	if( service_id.service_id_method == BT_SIM_L2CAP_PSM &&
		service_id.l2cap_psm == BT_L2_PSM_AVDTP)
	{
		MBT_PI("[RM] A2DP Service", 0, 0, 0);
		return TRUE;
	}
#endif
	return FALSE;
}


//-----------------------Rm Evt Callback ���� ------------------------------------//
void mbt_gap_ev_rm_cmdDone(bt_ev_msg_type* bt_ev_msg_ptr)
{
	// LEECHANGHOON 2007-11-13 bt_cmd ������ EV callback �������� ó���Ұ͵� ���⼭...
	bt_ev_gn_cmd_done_type* pm =    (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;
	MBT_SDC("RM_Event BT_EV_GN_CMD_DONE cmd = 0x%x, status= 0x%x",   pm->cmd_type, pm->cmd_status,0);
}

//System_BT_EV_RM_Bonded
void mbt_gap_ev_rm_bonded(bt_ev_msg_type* bt_ev_msg_ptr)
{
	int i;
	T_MBT_PAIRED_DEV_LIST* btPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);
//sy_lee@lge.com 091109 ssp link key change�ÿ��� setauthorizeg���� �ʵ��� [[
	bt_device_type  stDevice;

	bdcpy(stDevice.bd_addr.bd_addr_bytes, bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes);
	if (mbt_gap_db_deviceread(mbt_rm_app_id, &stDevice) == MBT_TRUE)
	{
		if (stDevice.link_key_type == BT_HC_LINK_KEY_CHANGED)
		{
			MBT_PI("mbt_gap_ev_rm_bonded : link key has been changed.", 0, 0, 0);
			return;
		}
	}
//sy_lee@lge.com 091109 ssp link key change�ÿ��� setauthorizeg���� �ʵ��� ]]
	mbt_gap_update_pairedList();
	MBT_PI(__func__"", 0, 0, 0);
	for(i=0; i < btPairedList->PairedCount; i++)
	{
		if(!bdcmp(btPairedList->PairedList[i].BdAddr, bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes))
		{
			mbt_gap_setauthorize(bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes, MBT_TRUE);	// make default to TRUE. JG Kwon. 2009.11.04
			mbt_gap_setnickname(bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes, 
									btPairedList->PairedList[i].Name);
			strcpy(btPairedList->PairedList[i].NickName, btPairedList->PairedList[i].Name);
			break;
		}
	}
	mbt_gap_restore_role_switch(bt_ev_msg_ptr->ev_msg.ev_rm_bond.bd_addr.bd_addr_bytes);
	if(*sdcGAPStatus == MBT_GAP_STATUS_PAIR_RES)
		mbt_postevent(MBTEVT_GAP_PAIR_REPLY_SUCCESS, 0);
	else
		mbt_postevent(MBTEVT_GAP_PAIR_REQ_SUCCESS, 0);

	*sdcGAPStatus = MBT_GAP_STATUS_IDLE;
}


void mbt_gap_ev_rm_bondFail(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);

	mbt_gap_restore_role_switch(bt_ev_msg_ptr->ev_msg.ev_rm_bondf.bd_addr.bd_addr_bytes);
	if(*sdcGAPStatus == MBT_GAP_STATUS_PAIR_RES)
		mbt_postevent(MBTEVT_GAP_PAIR_REPLY_FAIL, 0);
	else
		mbt_postevent(MBTEVT_GAP_PAIR_REQ_FAIL, 0);

	*sdcGAPStatus = MBT_GAP_STATUS_IDLE;
}

void mbt_gap_ev_rm_rebondReq(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_cmd_rm_authorize_rebond(mbt_rm_app_id, &bt_ev_msg_ptr->ev_msg.ev_rm_rebreq.bd_addr, TRUE, BT_RM_AB_DONT_CARE);	
}

void mbt_gap_ev_rm_pinReq(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_PINREPLY* btPinReply =(T_MBT_PINREPLY*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PINREPLY);			
	bt_device_type	remoteDev;
	
	bdcpy(btPinReply->BdAddr,  bt_ev_msg_ptr->ev_msg.ev_rm_pinrq.bd_addr.bd_addr_bytes);
	bdcpy(remoteDev.bd_addr.bd_addr_bytes,   bt_ev_msg_ptr->ev_msg.ev_rm_pinrq.bd_addr.bd_addr_bytes);
	
	mbt_gap_db_deviceread(mbt_rm_app_id, &remoteDev);

	strncpy(btPinReply->Name, (char *)remoteDev.name_str, MBT_MAX_NAME_LEN);
	btPinReply->ServiceClass = (MBT_SHORT)remoteDev.service_class;
	btPinReply->MajorClass = (MBT_SHORT)(remoteDev.major_dev_class)>>8;	// LEECHANGHOON 2007-12-17 QBT���� Define�� ���� �޶�..
	btPinReply->MinorClass = (MBT_SHORT)remoteDev.minor_dev_class;
	
	mbt_postevent(MBTEVT_GAP_PAIR_REPLY_REQUESTED, 0);
}

void mbt_gap_ev_rm_usrConfirmReq(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_SSP* btSSPInfo =(T_MBT_SSP*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SSPINFO);
	bt_device_type remoteDev;
	char *passKey = NULL, digit;
	unsigned long NKeyValue;
	int i, len;

	MBT_PI(__func__"", 0, 0, 0);

	bdcpy(btSSPInfo->BdAddr,  bt_ev_msg_ptr->ev_msg.ev_rm_ucr.bd_addr.bd_addr_bytes);
	bdcpy(remoteDev.bd_addr.bd_addr_bytes,   bt_ev_msg_ptr->ev_msg.ev_rm_ucr.bd_addr.bd_addr_bytes);
	passKey = bt_ev_msg_ptr->ev_msg.ev_rm_ucr.passkey;

	mbt_gap_db_deviceread(mbt_rm_app_id, &remoteDev);

	strncpy(btSSPInfo->Name, (char *)remoteDev.name_str, MBT_MAX_NAME_LEN);
	btSSPInfo->ServiceClass = (MBT_SHORT)remoteDev.service_class;
	btSSPInfo->MajorClass = (MBT_SHORT)(remoteDev.major_dev_class)>>8;
	btSSPInfo->MinorClass = (MBT_SHORT)remoteDev.minor_dev_class;	

	if (strlen(passKey) != 0) {
		btSSPInfo->AssoModel = MBT_GAP_SSP_NUMERIC_COMPARISON;
	} 
	else
	{
		btSSPInfo->AssoModel = MBT_GAP_SSP_JUST_WORKS;
		// FOR TEMP
		//mbt_gap_sspres(TRUE);
		//return;
	}

	NKeyValue = 0;
	len = strlen(passKey);
	for (i = len-1; i >= 0; i--)
	{
		if (passKey[i] == ' ')
			digit = 0;
		else 
			digit = passKey[i]- '0';

		NKeyValue += digit * pow(10, (len-1)-i);
	}
		
	btSSPInfo->nKeyValue = NKeyValue;

	MBT_PI(__func__"[RM] AssoModel(%s) RemoteName[0](%c) [1] (%c)", (btSSPInfo->AssoModel==MBT_GAP_SSP_NUMERIC_COMPARISON ? "Numeric Comparison":"Just Works"), btSSPInfo->Name[0], btSSPInfo->Name[1]);
	mbt_postevent(MBTEVT_GAP_SSP_REQUESTED, 0);
	// �ӽ�
	//mbt_gap_sspres(TRUE); 
	return;
}

void mbt_gap_ev_rm_passKeyReq(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_device_type remoteDev;

	bdcpy(remoteDev.bd_addr.bd_addr_bytes,   bt_ev_msg_ptr->ev_msg.ev_rm_ucr.bd_addr.bd_addr_bytes);

	mbt_gap_db_deviceread(mbt_rm_app_id, &remoteDev);
	MBT_PI(__func__"", 0, 0, 0);
	bt_cmd_rm_keypress_notification(mbt_rm_app_id, &remoteDev.bd_addr, BT_RM_KPN_STARTED);
	bt_cmd_rm_keypress_notification(mbt_rm_app_id, &remoteDev.bd_addr, BT_RM_KPN_COMPLETED);
	bt_cmd_rm_passkey_reply(mbt_rm_app_id, &remoteDev.bd_addr, "2945", TRUE);

	return;
}

void mbt_gap_ev_rm_passKeyNotification(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_SSP* btSSPInfo =(T_MBT_SSP*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SSPINFO);
	char *passKey = NULL, digit;	
	bt_device_type remoteDev;
	unsigned long NKeyValue;
	int i, len;

	bdcpy(btSSPInfo->BdAddr,  bt_ev_msg_ptr->ev_msg.ev_rm_ucr.bd_addr.bd_addr_bytes);
	bdcpy(remoteDev.bd_addr.bd_addr_bytes,   bt_ev_msg_ptr->ev_msg.ev_rm_ucr.bd_addr.bd_addr_bytes);

	passKey = bt_ev_msg_ptr->ev_msg.ev_rm_ucr.passkey;

	mbt_gap_db_deviceread(mbt_rm_app_id, &remoteDev);

	strncpy(btSSPInfo->Name, (char *)remoteDev.name_str, MBT_MAX_NAME_LEN);
	btSSPInfo->ServiceClass = (MBT_SHORT)remoteDev.service_class;
	btSSPInfo->MajorClass = (MBT_SHORT)(remoteDev.major_dev_class)>>8;
	btSSPInfo->MinorClass = (MBT_SHORT)remoteDev.minor_dev_class;	
	btSSPInfo->AssoModel = MBT_GAP_SSP_PASSKEY_ENTRY;

	NKeyValue = 0;
	len = strlen(passKey);
	for (i = len-1; i >= 0; i--)
	{
		if (passKey[i] == ' ')
			digit = 0;
		else 
			digit = passKey[i]- '0';

		NKeyValue += digit * pow(10, (len-1)-i);
	}
		
	btSSPInfo->nKeyValue = NKeyValue;

	mbt_postevent(MBTEVT_GAP_SSP_REQUESTED, 0);
}

void mbt_gap_ev_rm_keyPressNotification(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_rm_keypress_notification_type key = bt_ev_msg_ptr->ev_msg.ev_rm_keypress_notif.key;

	switch(key) 
	{
		case BT_RM_KPN_STARTED:
			MBT_WARN("MBT GAP ev kpn started",0,0,0);
			mbt_postevent(MBTEVT_GAP_SSP_PASSKEY_STARTED, 0);
			break;

		case BT_RM_KPN_DIGIT_ENTERED:
			MBT_WARN("MBT GAP ev kpn digit entered",0,0,0);
			mbt_postevent(MBTEVT_GAP_SSP_PASSKEY_ENTERED, 0);
			break;			

		case BT_RM_KPN_DIGIT_ERASED:
			MBT_WARN("MBT GAP ev kpn digit erased",0,0,0);
			mbt_postevent(MBTEVT_GAP_SSP_PASSKEY_ERASED, 0);
			break;			

		case BT_RM_KPN_CLEARED:
			MBT_WARN("MBT GAP ev kpn cleared",0,0,0);
			mbt_postevent(MBTEVT_GAP_SSP_PASSKEY_CLEARED, 0);
			break;			

		case BT_RM_KPN_COMPLETED:
			MBT_WARN("MBT GAP ev kpn completed",0,0,0);
			mbt_postevent(MBTEVT_GAP_SSP_PASSKEY_COMPLETE, 0);
			break;			

		default:
			MBT_WARN("MBT GAP ev type error",0,0,0);
			break;			
	}

	return;
}

void mbt_gap_ev_rm_deviceUpdated(bt_ev_msg_type* bt_ev_msg_ptr)
{
	// LEECHANGHOON 2008-2-14 MBT����Ʒ� 3����
	//bt_ev_gn_cmd_done_type* pm =    (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;
	//mbt_gap_update_pairedList();
	//mbt_postevent(MBTEVT_GAP_UNPAIR_ALLDEV_SUCCESS, 0);
	bt_ev_rm_device_updated_type* devUpdate = (bt_ev_rm_device_updated_type*)&bt_ev_msg_ptr->ev_msg;
	MBT_WARN("DEVICE_UPDATED_Status : %d, Success: %d",devUpdate->update_status,devUpdate->success,0);
	switch (devUpdate->update_status)
	{
		case BT_RM_DUS_UNBONDED_B: //Unpair , Unpair all �̰� �����.
			Unpaired_cnt++;
			if(devUpdate->success == MBT_TRUE)
			{
				
				if(Unpair_cmd_flag == UNPAIR_CMD)
				{	
					mbt_gap_update_pairedList();
					mbt_postevent(MBTEVT_GAP_UNPAIR_DEV_SUCCESS, 0);
				}
				else
				{
					if(Unpair_cnt == Unpaired_cnt)
					{
						mbt_gap_update_pairedList();
						mbt_postevent(MBTEVT_GAP_UNPAIR_ALLDEV_SUCCESS, 0);
					}
				}
			}
			else
			{
				if(Unpair_cmd_flag == UNPAIR_CMD)
				{	
					mbt_postevent(MBTEVT_GAP_UNPAIR_DEV_FAIL, 0);
				}
				else
				{
					if(Unpair_cnt == Unpaired_cnt)
					{
						mbt_gap_update_pairedList();
						mbt_postevent(MBTEVT_GAP_UNPAIR_ALLDEV_FAIL, 0);
					}
				}
			}
			break;
			
		case BT_RM_DUS_NICK_NAME_B: //Set_Nickname
			if(devUpdate->success == MBT_TRUE)
			{			
				mbt_gap_update_pairedList();
				mbt_postevent(MBTEVT_GAP_SETNICKNAME_SUCCESS, 0);
			}
			else
			{
				mbt_postevent(MBTEVT_GAP_SETNICKNAME_FAIL, 0);
			}
			break;

		case BT_RM_DUS_SECURITY_B:
			break;
		case BT_RM_DUS_VALUE_2_B:
			mbt_gap_update_pairedList();
			break;
		default:
			mbt_gap_update_pairedList();
			break;
	}
}

void mbt_gap_ev_rm_authoReq(bt_ev_msg_type* bt_ev_msg_ptr)
{
	T_MBT_AUTHREPLY* btAuthReply = (T_MBT_AUTHREPLY *)mbt_sdc_getrecord(MBTSDC_REC_GAP_AUTHREPLY);
	bt_device_type	remoteDev;
	bt_rm_atzrq_type authorize_dir;
	
	bdcpy(btAuthReply->BdAddr, bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.bd_addr.bd_addr_bytes);				
	bdcpy(remoteDev.bd_addr.bd_addr_bytes, bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.bd_addr.bd_addr_bytes);
	
	mbt_gap_db_deviceread(mbt_rm_app_id, &remoteDev);
#if 0
	strncpy(btAuthReply->Name, (char *)(remoteDev.name_str), MBT_MAX_NAME_LEN);
#else	// copy NICKNAME if available. JG Kwon. 2009.05.07
	if(strlen((char*)(remoteDev.nick_name_str)))
		strncpy(btAuthReply->Name, (char *)(remoteDev.nick_name_str), MBT_MAX_NAME_LEN);	
	else
		strncpy(btAuthReply->Name, (char *)(remoteDev.name_str), MBT_MAX_NAME_LEN);		
#endif
	
	authorize_dir = bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.authorize_dir;
	auth_service_id_method = bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.service_id_method;
	
	switch(auth_service_id_method) 
	{
		case BT_SIM_SDP_UUID:
			auth_service_type = bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.sdp_uuid;
			break;
		case BT_SIM_RFCOMM_SCN:
			auth_service_type = bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.rfcomm_scn;
			break;
		case BT_SIM_L2CAP_PSM:
			auth_service_type = bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.l2cap_psm;
			break;
		case BT_SIM_DEFAULT_L2CAP:
			MBT_WARN("[fnclamp] sdp_uuid:0x%x, rfcomm_scn:0x%x, l2cap_psm:0x%x", 
				bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.sdp_uuid, 
				bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.rfcomm_scn,
				bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.l2cap_psm);
			auth_service_type = bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.l2cap_psm;
			break;
	}
	
	MBT_WARN("BT_EV_RM_AUTHORIZE_REQUEST auth_service_type:0x%x, auth_service_id_method:%d", auth_service_type, auth_service_id_method,0);

	if(authorize_dir != BT_RM_ATZRQ_OUTGOING)
	{
#ifdef MBT_DUAL_PROFILE
		if(auth_service_type == MBT_SVCUUID_AG_HANDSFREE || auth_service_type == MBT_SVCUUID_HEADSET_AUDIO_GATEWAY ||auth_service_type == MBT_SVCUUID_AUDIO_SOURCE)
		{
			if(mbt_sdc_getvalue(MBTSDC_VAL_AG_DEVCON) && auth_service_type == MBT_SVCUUID_AG_HANDSFREE)
			{
				mbt_gap_authorizationres(MBT_FALSE, NULL);
			}
			else if(mbt_sdc_getvalue(MBTSDC_VAL_AG_DEVCON) && auth_service_type == MBT_SVCUUID_HEADSET_AUDIO_GATEWAY)
			{
				mbt_gap_authorizationres(MBT_FALSE, NULL);
			}
			else if(mbt_sdc_getvalue(MBTSDC_VAL_A2DP_DEVCON) && auth_service_type == MBT_SVCUUID_AUDIO_SOURCE)
			{
				mbt_gap_authorizationres(MBT_FALSE, NULL);
			}
			else if(auth_service_type == MBT_SVCUUID_AUDIO_SOURCE && mbt_gap_getAclLinkCnt(handleMap)>1)
			{
				mbt_gap_authorizationres(MBT_FALSE, NULL);
			}
			//mbt_gap_getAclLinkCnt(handleMap)
		}
		else
		{
			if(mbt_sdc_getvalue(MBTSDC_VAL_FILE_TRANS_STATUS))
			{
				if(auth_service_id_method !=  BT_SIM_DEFAULT_L2CAP)
				{
					MBT_PI("[BT_EV_RM_AUTHORIZE_REQUEST] Aleady data link is connected. Reject request !!!", 0, 0,0);
					mbt_gap_authorizationres(MBT_FALSE, NULL);
					return;
				}
			}
		}
#endif

		if(mbt_gap_isauthorized(remoteDev.bd_addr.bd_addr_bytes))
		{
			if(auth_service_type != MBT_SVCUUID_OBEX_FILE_TRANSFER)
				mbt_gap_authorizationres(MBT_TRUE, MBT_NULL);
			else
				mbt_postevent(MBTEVT_FTP_SERVER_AUTHREQ,0);
		}
		else
		{

          if ( (bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.service_id_method == BT_SIM_L2CAP_PSM) && 
                (bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.l2cap_psm == BT_SD_PROTOCOL_AVDTP) &&
                (mbt_a2dp_get_authorized_channel() == TRUE) )
          {
            MBT_PI("EV_RM_AUTHOREQ - accept because media channel doesn't need to be authorized again", 0, 0, 0 );
            mbt_gap_authorizationres(MBT_TRUE, MBT_NULL);
            return;
          }

			switch(auth_service_type)
			{
				case MBT_SVCUUID_AG_HANDSFREE:
				case MBT_SVCUUID_HEADSET_AUDIO_GATEWAY:
					//HF_HS AUTHó��
					mbt_postevent(MBTEVT_AG_AUTHREQ,0);
					break;
					
				case MBT_SVCUUID_OBEX_OBJECT_PUSH:
					//OPP AUTH ó��
					mbt_postevent(MBTEVT_OPP_SERVER_AUTHREQ,0);
					break;
					
				case MBT_SVCUUID_OBEX_FILE_TRANSFER:
					//FTP AUTHó��
					mbt_postevent(MBTEVT_FTP_SERVER_AUTHREQ,0);
					break;
					
				case MBT_SVCUUID_DIALUP_NETWORKING:
					//DUN AUTHó��
					mbt_postevent(MBTEVT_DUN_AUTHREQ,0);
					break;
					
				case MBT_SVCUUID_SERIAL_PORT:
					//SPP AUTHó��
					mbt_postevent(MBTEVT_SPP_AUTHREQ,0);
					break;
					
			case MBT_SVCUUID_AUDIO_SINK:
			case MBT_PROTOCOL_UUID_AVDTP:				
				//�ӽ�... 
				mbt_postevent(MBTEVT_A2DP_SOURCE_AUTHREQ,0);
				break;
				
			case MBT_SVCUUID_AV_REMOTE_CONTROL:
				//�ӽ�... 
				mbt_postevent(MBTEVT_SPP_AUTHREQ,0);
				break;
				
				default:
					MBT_WARN("invalid uuid !!!", 0,0,0);
					mbt_postevent(MBTEVT_OPP_SERVER_AUTHREQ,0);
					break;

			}
		}
	}
	else
	{
		mbt_gap_authorizationres(MBT_TRUE, MBT_NULL);
	}

  if ( (bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.service_id_method == BT_SIM_L2CAP_PSM) && 
       (bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.service_id.l2cap_psm == BT_SD_PROTOCOL_AVDTP) )
   {
      mbt_a2dp_set_direction(bt_ev_msg_ptr->ev_msg.ev_rm_atzrq.authorize_dir);
   }
   
}

void mbt_gap_ev_rm_radioDisabled(bt_ev_msg_type* bt_ev_msg_ptr)
{
	MBT_PI("BT_EV_RM_RADIO_DISABLED disable=%d disableAll=%d", bt_ev_msg_ptr->ev_msg.ev_rm_radio.disabled,diableAll,0);	  
  	//pancho: start -> add this function to guarantee the reliable working of flight mode and default setting
	if(diableAll == TRUE)
	{
		if(bt_ev_msg_ptr->ev_msg.ev_rm_radio.disabled == TRUE)//disabled
		{
  		//automatically enable radio
  		TASKLOCK();
	  	bt_cmd_rm_disable_radio(mbt_rm_app_id, FALSE );
	  	TASKFREE();
		}
		else//enabled
		{
  		//automatically turn Bluetooth off
  		diableAll = FALSE;
		mbt_gap_bluetoothoff();
		}
	}
	//pancho: end -> 2008/01/12
}

void mbt_gap_ev_rm_aclConnected(bt_ev_msg_type* bt_ev_msg_ptr)
{
	int i;
	MBT_PI(__func__" BT_EV_RM_CONNECTED_ACL : appid:%d, handle:0x%x", bt_ev_msg_ptr->ev_hdr.bt_app_id, bt_ev_msg_ptr->ev_msg.ev_rm_conna.handle, 0);
	for(i=0; i<MBT_BDADDR_LEN; i++)
		MBT_PI("Connected ACL addr[%d] : %x", i, bt_ev_msg_ptr->ev_msg.ev_rm_conna.bd_addr.bd_addr_bytes[i], 0);
	//audio 1 + data 1 �� ���, a2dp�� play ���� ���, ������ ������ �̹� acl�� 2�� ���� ���� acl�� �ٽ� disconnect ��Ŵ. 
	if((mbt_sdc_getvalue(MBTSDC_VAL_FILE_TRANS_STATUS) && mbt_sdc_getvalue(MBTSDC_VAL_AG_DEVCON)) ||
		mbt_sdc_getvalue(MBTSDC_VAL_A2DP_PLAY) ||
		(mbt_gap_getAclLinkCnt(handleMap) > 1))
	{
		MBT_PI(" Disconnect ACL link !!! bt_app_id %d handle %d", bt_ev_msg_ptr->ev_hdr.bt_app_id, bt_ev_msg_ptr->ev_msg.ev_rm_conns.handle, 0);
		bt_cmd_rm_disconnect_acl(mbt_rm_app_id , bt_ev_msg_ptr->ev_msg.ev_rm_conns.handle, BT_RMDR_USER_ENDED);
	}
	else
	{    
		mbt_gap_addHandle(&bt_ev_msg_ptr->ev_msg.ev_rm_conna, handleMap);
		if(bSearchPending == MBT_TRUE)
		{
			jsr82Handle = bt_ev_msg_ptr->ev_msg.ev_rm_conna.handle;
			acl_app_id = bt_ev_msg_ptr->ev_hdr.bt_app_id;
		}
	}
}

void mbt_gap_ev_rm_aclDisconnected(bt_ev_msg_type* bt_ev_msg_ptr)
{
	MBT_PI(__func__" BT_EV_RM_DISCONNECTED_ACL : appid:%d, handle:%x", bt_ev_msg_ptr->ev_hdr.bt_app_id, bt_ev_msg_ptr->ev_msg.ev_rm_disca.handle, 0);
	mbt_gap_removeHandle(&bt_ev_msg_ptr->ev_msg.ev_rm_disca, handleMap);
	if((bt_ev_msg_ptr->ev_msg.ev_rm_disca.handle == jsr82Handle) && (bt_ev_msg_ptr->ev_hdr.bt_app_id == acl_app_id))
	{
		jsr82Handle = 0xff;
		acl_app_id = 0xff;
	}
}


/********************************************************************************
*	Prototype	: MBT_VOID mbt_gap_RM_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
*	Description	: EV Callback ó���� ����.
********************************************************************************/
static MBT_VOID mbt_gap_RM_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
{
	MBT_WARN("RM_EventType : %x", (bt_ev_msg_ptr->ev_hdr.ev_type),0,0);
	
	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
			mbt_gap_ev_rm_cmdDone(bt_ev_msg_ptr);
			break;

		case BT_EV_RM_BONDED:
			mbt_gap_ev_rm_bonded(bt_ev_msg_ptr);
			break;
			
		case BT_EV_RM_BOND_FAILED:
			mbt_gap_ev_rm_bondFail(bt_ev_msg_ptr);
			break;

		case BT_EV_RM_REBOND_REQUEST:
			mbt_gap_ev_rm_rebondReq(bt_ev_msg_ptr);
			break;
			
		case BT_EV_RM_PIN_REQUEST:
			mbt_gap_ev_rm_pinReq(bt_ev_msg_ptr);
			break;

		case BT_EV_RM_USER_CONFIRMATION_REQUEST:
			mbt_gap_ev_rm_usrConfirmReq(bt_ev_msg_ptr);
			break;

		case BT_EV_RM_PASSKEY_REQUEST:
			mbt_gap_ev_rm_passKeyReq(bt_ev_msg_ptr);
			break;

		case BT_EV_RM_PASSKEY_NOTIFICATION:
			mbt_gap_ev_rm_passKeyNotification(bt_ev_msg_ptr);
			break;

		case BT_EV_RM_KEYPRESS_NOTIFICATION:
			mbt_gap_ev_rm_keyPressNotification(bt_ev_msg_ptr);
			break;
			
		case BT_EV_RM_DEVICE_UPDATED:
			mbt_gap_ev_rm_deviceUpdated(bt_ev_msg_ptr);
			break;
						
		case BT_EV_RM_LINK_STATUS:
			break;
							
		case BT_EV_RM_AUTHORIZE_REQUEST:			  
			authoReqJSR82 = MBT_FALSE;
			mbt_gap_ev_rm_authoReq(bt_ev_msg_ptr);
			break;
								
		case BT_EV_RM_RADIO_DISABLED:
	  		mbt_gap_ev_rm_radioDisabled(bt_ev_msg_ptr);
			 break;
		case BT_EV_RM_CONNECTED_ACL:
			mbt_gap_ev_rm_aclConnected(bt_ev_msg_ptr);
  			break;
		case BT_EV_RM_DISCONNECTED_ACL:
			mbt_gap_ev_rm_aclDisconnected(bt_ev_msg_ptr);
			break;

		default:
			{
			 	 MBT_ERR( "SDEvCb - unexpect event %x", 
						 bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0 );
			}
			break;
	}
}

//-----------------------Sd Evt Callback ���� ------------------------------------//

void mbt_gap_ev_sd_cmdDone(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_bd_addr_type addr;
	// LEECHANGHOON 2007-11-13 bt_cmd ������ EV callback �������� ó���Ұ͵� ���⼭...
	bt_ev_gn_cmd_done_type* pm =    (bt_ev_gn_cmd_done_type*)&bt_ev_msg_ptr->ev_msg;

	MBT_SDC("SD_Event BT_EV_GN_CMD_DONE cmd = 0x%x, status= 0x%x",   pm->cmd_type, pm->cmd_status,0);
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	switch ( pm->cmd_type )
	{
		case BT_CMD_SD_DISCOVER_DEVICES:	  
		{
			switch(pm->cmd_status)
			{
				case BT_CS_GN_SUCCESS:
				{				
					T_MBT_SEARCHED_DEV_LIST* SearchedList =   (T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);

					gDeviceRecordsIdx = 0;
					// Device index�� �����.						
					memset(SearchedList, 0x00, sizeof(T_MBT_SEARCHED_DEV_LIST));
					
					//system_bt_var_set(BTVAR_SD_NEW_DEV_IDX, 0);
					//system_bt_var_set(BTVAR_SD_NAME_RESP_IDX , 0);
					//system_bt_var_set(BTVAR_SD_LAST_DEV_CNT,0);
				}
					break;
				case BT_CS_SD_DEVICE_DISCOVERY_ALREADY_IN_PROGRESS:
					MBT_WARN("DEVICE_DISCOVERY_ALREADY_IN_PROGRESS",0,0,0);
					mbt_postevent(MBTEVT_GAP_INQUIRY_FAIL, 0);
					break;
			}
		}
			break;
	}
}

void mbt_gap_ev_sd_discoveryResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_bd_addr_type addr;
   MBT_PI(__func__"RM Inquiry Response ", 0, 0, 0);
  memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	if(gDeviceRecordsIdx < MBT_MAXNUM_SEARCH_DEV)
	{
		MBT_INT nSearchIdx, nPairedIdx;
		bt_device_type  stDevice;
		bt_cmd_status_type  stat;
		uint8 i,j,cNumUUIDs = 0;
		uint8 bEirSupport = FALSE;
		T_MBT_SEARCHED_DEV_LIST* btSearchList = (T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);
		T_MBT_PAIRED_DEV_LIST* btPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);


		//Duplicated device filtering
		for(nSearchIdx=0; nSearchIdx< btSearchList->SearchCount ; nSearchIdx++)
		{
			if(!bdcmp(btSearchList->SearchList[nSearchIdx].BdAddr, bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.bd_addr.bd_addr_bytes))
			{
				MBT_WARN("Duplicated device filtering : BD ADDR (%s)", bdAddrToString(btSearchList->SearchList[nSearchIdx].BdAddr), 0, 0);
				return;
			}
		}

		//Paired device verify
		for(nPairedIdx=0; nPairedIdx <btPairedList->PairedCount ; nPairedIdx++)
		{
			if(!bdcmp(btPairedList->PairedList[nPairedIdx].BdAddr, bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.bd_addr.bd_addr_bytes))
			{
				btSearchList->SearchList[nSearchIdx].bPaired = MBT_TRUE;
				break;
			}
		}

		// For EIR feature		
		bdcpy(stDevice.bd_addr.bd_addr_bytes, bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.bd_addr.bd_addr_bytes);
		if (mbt_gap_db_deviceread(mbt_rm_app_id, &stDevice) == MBT_TRUE)
       	{
			if (ISBITSET(stDevice.eir_data.eir_flag, BT_EIR_DATA_RCVD_B) != FALSE) {
				btSearchList->SearchList[btSearchList->SearchCount].bEirSupport = TRUE;
				MBT_WARN("EIR supported", 0,0,0);
			} 

			if (ISBITSET(stDevice.eir_data.eir_flag, BT_EIR_NAME_CMPLT_B) != FALSE) {
				strcpy(btSearchList->SearchList[btSearchList->SearchCount].Name, stDevice.name_str);
			} else {
				strcpy(btSearchList->SearchList[btSearchList->SearchCount].Name, (char *)"");
			}

			if (ISBITSET(stDevice.eir_data.eir_flag, BT_EIR_UUID16_LIST_CMPLT_B) != FALSE) {
				memset(UUIDs16, 0x00, sizeof(UUIDs16));
				stat = bt_cmd_rm_get_uuid_list( mbt_rm_app_id, (bt_bd_addr_type*)&bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.bd_addr,
                                  (bt_uuid_type)BT_UUID_16BIT_TYPE, 0, &cNumUUIDs, (uint16*)UUIDs16 );
				if (stat == BT_CS_GN_SUCCESS) {
					btSearchList->SearchList[btSearchList->SearchCount].ServiceList.nServiceCount = cNumUUIDs;
					for (i=0; i < cNumUUIDs && UUIDs16[i] != NULL; i++) {
						btSearchList->SearchList[btSearchList->SearchCount].ServiceList.Service[i] = UUIDs16[i];
						MBT_WARN("SVC UUID : 0x%x", btPairedList->PairedList[i].ServiceList.Service[i], 0, 0);
					}
				}
			}
			
		}  else {
			strcpy(btSearchList->SearchList[btSearchList->SearchCount].Name, (char *)"");
		}
		
		bdcpy(btSearchList->SearchList[btSearchList->SearchCount].BdAddr,bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.bd_addr.bd_addr_bytes);
		
		btSearchList->SearchList[btSearchList->SearchCount].ServiceClass = (MBT_SHORT)bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.service_class;
		btSearchList->SearchList[btSearchList->SearchCount].MajorClass = (MBT_SHORT)(bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.major_device_class)>>8;
		btSearchList->SearchList[btSearchList->SearchCount].MinorClass = (MBT_SHORT)bt_ev_msg_ptr->ev_msg.ev_sd_dev_discv_resp.minor_device_class;
		btSearchList->SearchCount++;
		gDeviceRecordsIdx = btSearchList->SearchCount;

		MBT_WARN("Search device count = %d", btSearchList->SearchCount, 0, 0);
		mbt_postevent(MBTEVT_GAP_INQUIRY_RES, 0);

	}
}

void mbt_gap_ev_sd_discoveryComplete(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_bd_addr_type addr;
	T_MBT_SEARCHED_DEV_LIST* btSearchList = (T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);

	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	if(sdStatus == BTSD_CANCEL)
	{
		sdStatus = BTSD_IDLE;
		mbt_postevent(MBTEVT_GAP_DEV_DISCOVERY_CANCEL_SUCCESS, 0);
	}
	else
	{
		sdStatus = BTSD_IDLE;
		if(gDeviceRecordsIdx == 0) // LEECHANGHOON 2008-1-14 ã�� ������ 0�� ���.
		{
			mbt_postevent(MBTEVT_GAP_INQUIRY_FAIL, 0);
		}
		else
		{
			mbt_postevent(MBTEVT_GAP_INQUIRY_SUCCESS, 0);
			memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btSearchList->SearchList[0].BdAddr, MBT_BDADDR_LEN);
			bt_cmd_sd_get_device_name(mbt_sd_app_id, &addr);
		}
	}

	*sdcGAPStatus = MBT_GAP_STATUS_IDLE;
}

void mbt_gap_ev_sd_nameResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_bd_addr_type addr;
	MBT_INT i;
	T_MBT_SEARCHED_DEV_LIST* btSearchList = (T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);

	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	for(i=0; i< btSearchList->SearchCount ; i++)
	{
		if(!bdcmp(btSearchList->SearchList[i].BdAddr, bt_ev_msg_ptr->ev_msg.ev_sd_dname.bd_addr.bd_addr_bytes))
		{
			strcpy(btSearchList->SearchList[i].Name, (char *)bt_ev_msg_ptr->ev_msg.ev_sd_dname.device_name_str);
			break;
		}
	}
	btNameRespIdx++;
	
//=====================================================
//sy_lee@lge.com  091001
//workaround btNameRespIdx���� ���� ��� index���� ������ �Ѵ�. 
//why was crached?   i don't know you don't know every don't know ~~ 
//=====================================================
	if(btNameRespIdx > MBT_MAXNUM_SEARCH_DEV || btNameRespIdx < 0)
	{
		btNameRespIdx = 0;
		sdStatus = BTSD_IDLE;
		bt_cmd_sd_stop_device_discovery(mbt_sd_app_id);
		return;
	}

	if(sdStatus == BTSD_CANCEL)
	{
		btNameRespIdx = 0;
		sdStatus = BTSD_IDLE;
		mbt_postevent(MBTEVT_GAP_DEV_DISCOVERY_CANCEL_SUCCESS, 0);
	}
	else if(btSearchList->SearchCount == btNameRespIdx)
	{
		btNameRespIdx = 0;
		mbt_postevent(MBTEVT_GAP_NAME_DISCOVERY_RES, 0);	//yucha 2007/12/16 added
		mbt_postevent(MBTEVT_GAP_NAME_DISCOVERY_SUCCESS, 0);
	}
	else
	{
		mbt_postevent(MBTEVT_GAP_NAME_DISCOVERY_RES, 0);
		memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btSearchList->SearchList[btNameRespIdx].BdAddr, MBT_BDADDR_LEN);
		bt_cmd_sd_get_device_name(mbt_sd_app_id, &addr);
	}
}

void mbt_gap_ev_sd_serviceSearchResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_bd_addr_type addr;
	int i, j, NumSvc = 0;
	uint8 numRecs;
	uint16 duplicate_flag = 0, sdservices;
	bt_sd_srv_rec_type* pRec;
	T_MBT_BDADDR svc_bd_addr;
	T_MBT_PAIRED_DEV_LIST* btPairedList = (T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
	MBT_SHORT	SvcUUID[MBT_MAXNUM_SVC_FIELD];	// SVC UUID ��
	
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memset((void*)&SvcUUID, 0x00, sizeof(SvcUUID));
	bdcpy(svc_bd_addr, bt_ev_msg_ptr->ev_msg.ev_sd_service_search_resp.bd_addr.bd_addr_bytes);
	
	// ã�� �����͸� �������� ���� rec�� �ʱ�ȭ ��Ŵ. 
	bt_sd_srv_rec_iter.init( BT_SD_DB_TYPE_SRV_SRCH_RESULT_DB, BT_SD_ITER_ALL);
	
	for(pRec = (bt_sd_srv_rec_type*)bt_sd_srv_rec_iter.first(), numRecs = 0;
		pRec != 0 && (numRecs < MBT_MAXNUM_SVC_FIELD);
		pRec = (bt_sd_srv_rec_type*)bt_sd_srv_rec_iter.next(), numRecs++ )
	{
		for(i=0; i<pRec->num_srv_attr; i++)
		{
			MBT_SDC("[mbt_gap_ev_sd_serviceSearchResp] attr_id:0x%04x",0,0,0);
			if(pRec->srv_attr[i].attr_id == BT_SD_ATTR_ID_SERVICE_CLASS_ID_LIST)
			{
				sdservices = bt_sd_extract_srvc_cls( &pRec->srv_attr[i] );
				duplicate_flag = MBT_FALSE;
				
				MBT_PI("SVC Searched service class 0x%x", sdservices,0,0);
				
				for(j=0; j<NumSvc; j++)
				{
					if(SvcUUID[j] == sdservices)
					{
						duplicate_flag = MBT_TRUE;
						break;
					}
				}
				
				if(duplicate_flag == MBT_FALSE)
				{
					if(sdservices != 0x0000 && sdservices != 0xFFFF)
					{
						SvcUUID[NumSvc++] = sdservices;
					}
				}
				else
				{
					MBT_PI(__func__" -> duplicated service class 0x%x", sdservices,0,0);
					duplicate_flag = MBT_FALSE;
				}
			}
		}
	}


	for(i=0; i < btPairedList->PairedCount; i++)
	{
		if(!bdcmp(btPairedList->PairedList[i].BdAddr, svc_bd_addr))
		{
			memset(&btPairedList->PairedList[i].ServiceList, 0x00, sizeof(T_MBT_SERVICE_LIST));

			memcpy((MBT_SHORT*)btPairedList->PairedList[i].ServiceList.Service, (MBT_SHORT*)SvcUUID, sizeof(SvcUUID));
			
			for(j=0; j<NumSvc; j++)
			{
				MBT_WARN("SVC UUID : 0x%x SVC num : %d", btPairedList->PairedList[i].ServiceList.Service[j], NumSvc, 0);
			}

			btPairedList->PairedList[i].ServiceList.nServiceCount = NumSvc;
			break;
		}
	}
	
	MBT_SDC("Svc Search OK. Please Paired list Nv update.",0,0,0);
	mbt_postevent(MBTEVT_GAP_SVC_DISCOVERY_SUCCESS, 0);
}

void mbt_gap_ev_sd_errorResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	/*	This event is generated in response to error conditions encountered 
				while executing bt_cmd_sd_search_service() or bt_cmd_sd_get_device_name() command */
	mbt_postevent(MBTEVT_GAP_SVC_DISCOVERY_FAIL, 0);
}

void mbt_gap_ev_sd_timeoutResp(bt_ev_msg_type* bt_ev_msg_ptr)
{
	/* 	This event is generated in response to a timeout in receiving a 
				reply to either bt_cmd_sd_send_service_search_req() or bt_cmd_sd_send_service_attribute_req()
				or bt_cmd_sd_search_service() or bt_cmd_sd_get_server_channel_number() */
	mbt_postevent(MBTEVT_GAP_SVC_DISCOVERY_FAIL, 0);
}

void mbt_gap_ev_sd_discoverableModeRes(bt_ev_msg_type* bt_ev_msg_ptr)
{
		bt_ev_sd_discoverable_mode_resp_type *pEvt = &bt_ev_msg_ptr->ev_msg.ev_sd_discv_mode_resp;
		switch(pEvt->discv_mode)
		{
			case BT_SD_SERVICE_DISCOVERABLE_MODE_NONE:
				//system_bt_var_set(BTVAR_VISIBLE, MBT_TRUE);
				break;
			case BT_SD_SERVICE_DISCOVERABLE_MODE_GENERAL:
				//system_bt_var_set(BTVAR_VISIBLE, MBT_FALSE);
				break;
			case BT_SD_SERVICE_DISCOVERABLE_MODE_LIMITED:
				break;
		}
}


/********************************************************************************
*	Prototype	: MBT_VOID mbt_gap_SD_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
*	Description	: EV Callback ó���� ����.
********************************************************************************/
MBT_VOID mbt_gap_SD_EventCallback(bt_ev_msg_type* bt_ev_msg_ptr)
{
	bt_bd_addr_type addr;
	MBT_WARN("SD_EventType : %x",(BT_CMD_EV_SD_BASE - bt_ev_msg_ptr->ev_hdr.ev_type),0,0);

	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);

	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
			mbt_gap_ev_sd_cmdDone(bt_ev_msg_ptr);
			break;

		case BT_EV_SD_DEVICE_DISCOVERY_RESP: //Inquiry response
			mbt_gap_ev_sd_discoveryResp(bt_ev_msg_ptr);
		  	break;
			
		case BT_EV_SD_DEVICE_DISCOVERY_COMPLETE: //Inquary complete.
			bt_cmd_hc_wr_scan_enable( BT_HC_INQ_EN_PAGE_EN );	// recover from scan disabled. let's correction visiblity setting on PhoneMngr. JG Kwon. 2010.01.25
			mbt_gap_ev_sd_discoveryComplete(bt_ev_msg_ptr);
			break;			
			
		case BT_EV_SD_DEVICE_NAME_RESP:
			mbt_gap_ev_sd_nameResp(bt_ev_msg_ptr);
			break;
		
		case BT_EV_SD_SERVICE_SEARCH_RESP:				
			mbt_gap_ev_sd_serviceSearchResp(bt_ev_msg_ptr);
			break;
		
		case BT_EV_SD_ERROR_RESP:
			mbt_gap_ev_sd_errorResp(bt_ev_msg_ptr);
			break;
		
		case BT_EV_SD_TIMEOUT_RESP:
			mbt_gap_ev_sd_timeoutResp(bt_ev_msg_ptr);
			break;
			
		case BT_EV_SD_DISCOVERABLE_MODE_RESP:
			mbt_gap_ev_sd_discoverableModeRes(bt_ev_msg_ptr);
			break;

		default:
		{
		 	 MBT_ERR( "SDEvCb - unexpect event %x", 
					 bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0 );
		  	break;
		}		
	}
}

/********************************************************************************
*	Prototype	: MBT_BOOL mbt_gap_btinitialize (MBT_VOID)
*	Description : 
********************************************************************************/
MBT_BOOL mbt_gap_btinitialize (MBT_VOID)
{
	if(mbt_rm_app_id == BT_APP_ID_NULL)
	{
		//GAP
		mbt_gap_init();

#if (MBT_AG == MBT_TRUE)
		//AG
		mbt_ag_init();
#endif

#if (MBT_OPP == MBT_TRUE)
		//OPP
		mbt_opp_init();
#endif

#if (MBT_FTP == MBT_TRUE)
		//FTP
		mbt_ftp_init();
#endif

#if (MBT_SPP == MBT_TRUE)
		//SPP
		mbt_spp_init();
#endif

#if (MBT_DUN == MBT_TRUE)
		//DUN
		mbt_dun_init();
#endif
		//A2DP
#if (MBT_A2DP == MBT_TRUE)
		mbt_a2dp_init();
#endif
		//AVRCP
#if (MBT_AVRCP == MBT_TRUE)
		mbt_avrcp_init();
#endif

#if (MBT_PBAP == MBT_TRUE)
		mbt_pbap_init();
#endif

		return MBT_TRUE;
	}
	else
	{
		return MBT_FALSE;
	}

}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_gap_init (MBT_VOID)
*	Description : 
********************************************************************************/
MBT_VOID mbt_gap_init (MBT_VOID)
{
	bt_service_id_type	id_type;
	bt_bd_addr_type 	addr;
	T_MBT_MYINFO* btMyInfo = (T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);
	MBT_CHAR  btName[MBT_MAX_NAME_LEN+1];
	bt_cod_type	myDevCod;
	if(mbt_rm_app_id == BT_APP_ID_NULL) //phone booting�� ���� 1ȸ�� �����ؾ� ��. 
	{
		// LEECHANGHOON 2007-11-16 Callback ���.	
		mbt_rm_app_id = bt_cmd_ec_get_app_id_and_register(mbt_gap_RM_EventCallback);
		mbt_sd_app_id = bt_cmd_ec_get_app_id_and_register(mbt_gap_SD_EventCallback);
		
		bt_cmd_rm_auto_service_search_disable( mbt_rm_app_id, MBT_TRUE );
		bt_cmd_rm_set_device_security( mbt_rm_app_id, MBT_NULL, BT_SEC_NONE);
		bt_cmd_rm_set_bondable( mbt_rm_app_id, MBT_TRUE );
		bt_cmd_rm_set_io_cap(mbt_rm_app_id, BT_RM_IOC_DISPLAY_YES_NO); // for numeric comparison.
		mbt_gap_register_ACL_ConStatus();

		if(mbt_rm_app_id == BT_APP_ID_NULL || mbt_sd_app_id == BT_APP_ID_NULL)
		{			
			MBT_ERR("ERROR bt_cmd_ec_get_app_id_and_register : MBT_NULL",0,0,0);
			return;
		}
		
		//Security, UUID ����	
#if (MBT_AG == MBT_TRUE)
        /* HEADSETs */
        id_type.service_id_method = BT_SIM_SDP_UUID;
        id_type.sdp_uuid = BT_SD_SERVICE_CLASS_HEADSET_AUDIO_GATEWAY;
        bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, TRUE, TRUE);

        id_type.service_id_method = BT_SIM_SDP_UUID;
        id_type.sdp_uuid = BT_SD_SERVICE_CLASS_HEADSET;
        bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, TRUE, TRUE);

        /* HANDSFREEs */
        id_type.service_id_method = BT_SIM_SDP_UUID;
        id_type.sdp_uuid = BT_SD_SERVICE_CLASS_HANDSFREE_AUDIO_GATEWAY;
        bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, TRUE, TRUE);

        id_type.service_id_method = BT_SIM_SDP_UUID;
        id_type.sdp_uuid = BT_SD_SERVICE_CLASS_HANDSFREE;
        bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, TRUE, TRUE);    
#endif

#if (MBT_OPP == MBT_TRUE)
		id_type.service_id_method = BT_SIM_SDP_UUID;
		id_type.sdp_uuid = MBT_SVCUUID_OBEX_OBJECT_PUSH;
		//bt_cmd_rm_set_service_security(mbt_rm_app_id, &id_type, BT_SEC_NONE, MBT_TRUE, MBT_FALSE); //RM���� AUTH REQ�ø��� ���� MBT_TRUE set.
		bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_SEC_NONE, MBT_TRUE, MBT_TRUE);
#endif

#if (MBT_FTP == MBT_TRUE)
		id_type.service_id_method = BT_SIM_SDP_UUID;
		id_type.sdp_uuid = MBT_SVCUUID_OBEX_FILE_TRANSFER;
		//bt_cmd_rm_set_service_security(mbt_rm_app_id, &id_type, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_TRUE, MBT_FALSE); //RM���� AUTH REQ�ø��� ���� MBT_TRUE set.
		//bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_TRUE, MBT_TRUE);
		bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, MBT_TRUE, MBT_TRUE);
#endif

#if (MBT_DUN == MBT_TRUE)
		id_type.service_id_method = BT_SIM_SDP_UUID;
		id_type.sdp_uuid = MBT_SVCUUID_DIALUP_NETWORKING;
		//bt_cmd_rm_set_service_security(mbt_rm_app_id, &id_type, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_TRUE, MBT_FALSE);
		//bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_TRUE, MBT_TRUE);
		bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, MBT_TRUE, MBT_TRUE);
#endif

#if (MBT_SPP == MBT_TRUE)
		id_type.service_id_method = BT_SIM_SDP_UUID;
		id_type.sdp_uuid = MBT_SVCUUID_SERIAL_PORT;
		//bt_cmd_rm_set_service_security(mbt_rm_app_id, &id_type, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_TRUE, MBT_FALSE);
		//bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_TRUE, MBT_TRUE);
		bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, MBT_TRUE, MBT_TRUE);
#endif

#if (MBT_A2DP == MBT_TRUE)
		id_type.service_id_method = BT_SIM_L2CAP_PSM;
		id_type.l2cap_psm = BT_SD_PROTOCOL_AVDTP;
		bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, MBT_TRUE, MBT_TRUE);
#endif

#if (MBT_AVRCP == MBT_TRUE)
		id_type.service_id_method = BT_SIM_SDP_UUID;
		id_type.sdp_uuid = BT_SD_SERVICE_CLASS_AV_REMOTE_CONTROL_TARGET;
		//bt_cmd_rm_set_service_security(mbt_rm_app_id, &id_type, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_FALSE, MBT_FALSE);
		//bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_SEC_AUTHENTICATE_AND_ENCRYPT, MBT_FALSE, MBT_FALSE);
		bt_cmd_rm_set_sm4(mbt_rm_app_id, &id_type, BT_RM_SL_2_MEDIUM, MBT_FALSE, MBT_FALSE);
#endif

		//My BD Addrs ������.
		bt_cmd_rm_get_local_info(mbt_rm_app_id, &addr, MBT_NULL, MBT_NULL, &myDevCod, btName, MBT_NULL);
		memcpy((MBT_BYTE*)btMyInfo->BdAddr, (MBT_BYTE*)&addr.bd_addr_bytes, MBT_BDADDR_LEN);
		memcpy((MBT_BYTE*)btMyInfo->Name, btName, sizeof(btMyInfo->Name));

		{
			MBT_BYTE* cod = &myDevCod.cod_bytes[0];
			COD_SERVICE_CLASS(btMyInfo->ServiceClass,cod);
			COD_MAJOR_CLASS(btMyInfo->MajorClass,cod);
			COD_MINOR_CLASS(btMyInfo->MinorClass,cod);
		}
	}
	else
	{
		MBT_FATAL("##GAP Initialize Over time Error. app_id ");
	}

	// LEECHANGHOON 2008-1-11 MBT���� Paired List �о��.
	mbt_gap_update_pairedList();

}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_gap_bluetoothon (MBT_VOID)
*	Description : 
********************************************************************************/
MBT_VOID mbt_gap_bluetoothon (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	bt_bd_addr_type 	addr;
	T_MBT_MYINFO* btMyInfo = (T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);

	btMyInfo->bOnOff = MBT_TRUE;
	
	//My BD Addrs ������.
	bt_cmd_rm_get_local_info(mbt_rm_app_id, &addr, MBT_NULL, MBT_NULL, MBT_NULL, MBT_NULL, MBT_NULL);
	memcpy((MBT_BYTE*)btMyInfo->BdAddr, (MBT_BYTE*)&addr.bd_addr_bytes, MBT_BDADDR_LEN);

	// LEECHANGHOON 2007-11-14 ���⼭ �ٷ� post_event ������. QBT�� BT ON�� ���� Cmd�� ����.
	mbt_postevent(MBTEVT_GAP_ON_SUCCESS, 0);

#endif
} 

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_bluetoothoff (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	T_MBT_MYINFO* btMyInfo = (T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);
	if(btMyInfo->bOnOff == MBT_TRUE)
	{
		btMyInfo->bOnOff = MBT_FALSE;
#if (MBT_A2DP == MBT_TRUE)
		mbt_a2dp_source_disable();
#endif
#if (MBT_AVRCP == MBT_TRUE)
		mbt_avrcp_disable();
#endif
#if (MBT_DUN == MBT_TRUE)
		mbt_dun_disable();
#endif
#if (MBT_SPP == MBT_TRUE)
		mbt_spp_disable();
#endif
#if (MBT_OPP == MBT_TRUE)
		mbt_opp_server_disable();
#endif
#if (MBT_OPP == MBT_TRUE)
		mbt_opp_client_disable();
#endif
#if (MBT_FTP == MBT_TRUE)
		mbt_ftp_server_disable();
#endif
#if (MBT_FTP == MBT_TRUE)
		mbt_ftp_client_disable();
#endif
#if (MBT_BPP == MBT_TRUE)
		mbt_bpp_disable();
#endif
#if (MBT_AG == MBT_TRUE)
		mbt_ag_disable();
#endif
#if (MBT_SAP == MBT_TRUE)
		mbt_sap_server_disable();
#endif
#if (MBT_BIP == MBT_TRUE)
		mbt_bip_initiator_disable();
#endif
#if (MBT_BIP == MBT_TRUE)
		mbt_bip_responder_disable();
#endif
#if (MBT_PBAP == MBT_TRUE)
		mbt_pbap_server_disable();
#endif
		mbt_gap_setvisible(MBT_FALSE);
		mbt_gap_setconnectable (MBT_FALSE);
		mbt_gap_setpairable(MBT_FALSE);

		bt_cmd_hc_wr_scan_enable(BT_HC_INQ_DIS_PAGE_DIS);
		
		mbt_postevent(MBTEVT_GAP_OFF_SUCCESS, 0);
	}
	else
	{
		// LEECHANGHOON 2007-11-14 ���⼭ �ٷ� post_event ������. QBT�� BT OFF�� ���� Cmd�� ����.
		MBT_WARN("MBT_GAP mbt_gap_bluetoothoff Already off", 0,0,0);
		mbt_postevent(MBTEVT_GAP_OFF_FAIL, 0);
	}
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_setmyname (MBT_CHAR* MyDevName)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type stat;
	char               bt_name[MBT_MAX_NAME_LEN+1];
	T_MBT_MYINFO* btMyInfo = (T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);
	if ( (MyDevName == MBT_NULL) || (strlen(MyDevName) > sizeof(bt_name) )) //  (WSTRLEN( pName ) > sizeof( bt_name )) )
	{
		return MBT_FALSE; //EBADPARM;
	}
	stat = bt_cmd_rm_set_local_info_ext( mbt_rm_app_id, MBT_NULL, MyDevName, MyDevName );
	rex_sleep(300);
	if ( mbt_gap_CheckCmdStatus( stat ))  //SUCCESS )
	{
		strcpy(btMyInfo->Name, MyDevName);
		return MBT_TRUE;
	}

	return MBT_FALSE;
#endif	
}
/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_setnickname(T_MBT_BDADDR PairedDevAddr, char* NickName)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type  stat;
	bt_device_type      device;

	memcpy((uint8*)device.bd_addr.bd_addr_bytes, (uint8*)PairedDevAddr, MBT_BDADDR_LEN);
	if ( BT_RM_DU_NICK_NAME_B & BT_RM_DU_SECURITY_B )
	{
		//device.security = 0;
	}
	memcpy((byte*)device.nick_name_str, (byte*)NickName, sizeof(device.nick_name_str));

	stat = bt_cmd_rm_device_update( mbt_rm_app_id, 
	                              (bt_rm_dev_update_ctrl_type) BT_RM_DU_NICK_NAME_B, 
	                              &device );
	rex_sleep(300);
	if ( mbt_gap_CheckCmdStatus( stat ))
	{
		return MBT_TRUE;
	}
	return MBT_FALSE;
  
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_setconnectable(MBT_BOOL bConnectable)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else	
	bt_cmd_status_type	stat;
	T_MBT_MYINFO* btMyInfo =(T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);
	
	btMyInfo->bConnectable = bConnectable;
	stat = bt_cmd_rm_set_connectable( mbt_rm_app_id, bConnectable, BT_RM_AVP_AUTOMATIC);

	//SDC�� nv ������Ʈ�� �ó����� ���� �ʿ���. ������ ��.

	MBT_SDC("Set connectable OK. Please MyInfo Nv update.",0,0,0); 

	//Need to update nv
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_setvisible(MBT_BOOL bVisible)
{
#ifdef MBT_EMULATOR 
	return MBT_FALSE;
#else
	bt_cmd_status_type	stat;
	bt_sd_service_discoverable_mode_type mode;
	T_MBT_MYINFO* btMyInfo =(T_MBT_MYINFO*)mbt_sdc_getrecord(MBTSDC_REC_GAP_MYINFO);

	// LEECHANGHOON 2008-3-13 �߰�
	TASKLOCK();
 	bt_cmd_rm_disable_discoverability(mbt_rm_app_id, !bVisible);
  	TASKFREE();

	mode = bVisible ? BT_SD_SERVICE_DISCOVERABLE_MODE_GENERAL : 
					BT_SD_SERVICE_DISCOVERABLE_MODE_NONE;

	stat = bt_cmd_sd_set_service_discoverable_mode(mbt_sd_app_id, mode);
	btMyInfo->bVisible = bVisible;
	MBT_SDC("Set visibility OK. Please MyInfo Nv update. btMyInfo->bVisible = %d",btMyInfo->bVisible,0,0);

	//Need to update nv
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_setpairable(MBT_BOOL bPairable)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type	stat;
	stat = bt_cmd_rm_set_bondable( mbt_rm_app_id, bPairable );

	return MBT_TRUE;	//winapi : �ʿ伺 ���� �ʿ�
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_iscmdacceptable(MBT_VOID)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	//Broadcom�� �׻� TRUE��. QBT��? Stack�� ���� üũ�� �ϴ� ����� �ճ�?
	return MBT_TRUE;
#endif	
}


/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_isdeviceconnected(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_INT i,k;
#if (MBT_DUN ==	MBT_TRUE)
	T_MBT_DUN_STATUS *stDun = (T_MBT_DUN_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_DUN_STATUS);
#endif
#if (MBT_AG 	== MBT_TRUE)
	T_MBT_AG_STATUS *stAg = (T_MBT_AG_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);	
#endif
#if (MBT_A2DP == MBT_TRUE)
	T_MBT_A2DP_STATUS *stA2dp = (T_MBT_A2DP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_A2DP_STATUS);
#endif
#if (MBT_AVRCP == MBT_TRUE)
	T_MBT_AVRCP_STATUS *stAvrcp = (T_MBT_AVRCP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_AVRCP_STATUS);
#endif
#if (MBT_OPP == MBT_TRUE)
	T_MBT_OPP_STATUS *stOpp = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);
#endif
#if (MBT_BPP == MBT_TRUE)
	T_MBT_BPP_STATUS *stBpp = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);
#endif
#if (MBT_BIP == MBT_TRUE)
	T_MBT_BIP_STATUS *stBip = (T_MBT_BIP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BIP_STATUS);
#endif
#if (MBT_FTP == MBT_TRUE)
	T_MBT_FTP_STATUS *stFtp = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);
#endif
#if (MBT_PBAP == MBT_TRUE)
	T_MBT_PBAP_STATUS *stPbap = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);
#endif
#if (MBT_HID_HOST == MBT_TRUE)
	T_MBT_HID_HOST_STATUS *stHidH = (T_MBT_HID_HOST_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_HID_HOST_STATUS);
#endif
#if (MBT_HID_DEVICE == MBT_TRUE)
	T_MBT_HID_DEVICE_STATUS *stHidD = (T_MBT_HID_DEVICE_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_HID_DEVICE_STATUS);
#endif
#if (MBT_JSR82 == MBT_TRUE)
	T_MBT_JSR82_STATUS *stJsr82 = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
#endif
#if (MBT_SAP == MBT_TRUE)
	T_MBT_SAP_STATUS *stSap = (T_MBT_SAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_SAP_STATUS);
#endif

#if (MBT_DUN ==	MBT_TRUE)
	if(stDun->State == MBT_DUN_CONNECTED)
	{
		if(!bdcmp(RemoteBDAddr, stDun->BdAddr))
			return MBT_TRUE;
	}
#endif	
#if (MBT_AG 	== MBT_TRUE)
	if(stAg->bConection == MBT_TRUE)
	{
		if(!bdcmp(RemoteBDAddr, stAg->BdAddr))
			return MBT_TRUE;
	}
#endif
#if (MBT_A2DP == MBT_TRUE)
	for(i=0;i<MBT_A2DP_MAX_CONN_NUM;i++)
	{
		if((stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_CONNECTED) ||
			(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_STARTING) ||
			(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_PLAY) ||
			(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_PAUSED) ||
			(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_STOPPING))
			{
					for(k=0;k<MBT_A2DP_MAX_CONN_NUM;k++)
					{
						if(!bdcmp(RemoteBDAddr,stA2dp->A2dpConn[k].BdAddr))
							return MBT_TRUE;
					}
			}
			
	}
#endif
#if (MBT_AVRCP == MBT_TRUE)
	for(i=0;i<MBT_AVRCP_MAX_CONN_NUM;i++)
	{
		if(stAvrcp->AvrcpConn[i].ConStatus == MBT_AVRCP_CONSTATUS_CONNECTED)
		{
			for(k=0;k<MBT_AVRCP_MAX_CONN_NUM;k++)
			{
				if(!bdcmp(RemoteBDAddr,stAvrcp->AvrcpConn[k].BdAddr))
					return MBT_TRUE;
			}
		}
			
	}
#endif
#if (MBT_OPP == MBT_TRUE)
	if((stOpp->OppState == MBT_OPP_STATE_CONNECTED) ||
		(stOpp->OppState == MBT_OPP_STATE_SENDING) ||
		(stOpp->OppState == MBT_OPP_STATE_PULLING) ||
		(stOpp->OppState == MBT_OPP_STATE_RECEIVING))
		
	{
		if(!bdcmp(RemoteBDAddr, stOpp->BDAddr))
			return MBT_TRUE;
	}
#endif
#if (MBT_BPP == MBT_TRUE)
	if((stBpp->State == MBT_BPP_STATE_CONNECTED) ||
		(stBpp->State == MBT_BPP_STATE_GETATTRIBUTE) ||
		(stBpp->State == MBT_BPP_STATE_PRINTING))
	{
		if(!bdcmp(RemoteBDAddr, stBpp->BDAddr))
			return MBT_TRUE;
	}
#endif
#if (MBT_BIP == MBT_TRUE)
	if((stBip->State == MBT_BIP_STATE_CONNECTED) ||
		(stBip->State == MBT_BIP_STATE_SENDING) ||
		(stBip->State == MBT_BIP_STATE_RECEIVING))
	{
		if(!bdcmp(RemoteBDAddr, stBip->BDAddr))
			return MBT_TRUE;
	}
#endif
#if (MBT_FTP == MBT_TRUE)
	if((stFtp->FtpState == MBT_FTP_STATE_CONNECTED) ||
		(stFtp->FtpState == MBT_FTP_STATE_SENDING) ||
		(stFtp->FtpState == MBT_FTP_STATE_RECEIVING))
	{
		if(!bdcmp(RemoteBDAddr, stFtp->BDAddr))
			return MBT_TRUE;
	}
#endif
#if (MBT_PBAP == MBT_TRUE)
	if((stPbap->State == MBT_PBAP_STATE_CONNECTED) ||
		(stPbap->State == MBT_PBAP_STATE_SENDING))
	{
		if(!bdcmp(RemoteBDAddr, stPbap->BDAddr))
			return MBT_TRUE;
	}
#endif
#if (MBT_HID_HOST == MBT_TRUE)
	if((stHidH->State == MBT_PBAP_STATE_CONNECTED) ||
		(stPbap->State == MBT_PBAP_STATE_SENDING))
	{
		if(!bdcmp(RemoteBDAddr, stPbap->BDAddr))
			return MBT_TRUE;
	}
#endif
#if (MBT_HID_DEVICE == MBT_TRUE)
	if(stHidD->State == MBT_HID_STATE_CONNECTED)
	{
		if(!bdcmp(RemoteBDAddr, stHidD->BDAddr))
			return MBT_TRUE;
	}
#endif
#if (MBT_SAP == MBT_TRUE)
	if((stSap->State == MBT_SAP_STATE_CONNECTED) ||
		(stSap->State == MBT_SAP_STATE_SENDING))
	{
		if(!bdcmp(RemoteBDAddr, stSap->BDAddr))
			return MBT_TRUE;
	}		
#endif
#if (MBT_JSR82 == MBT_TRUE)
	for(i=0;i<MBT_JSR82_MAX_EVENT_NUM;i++)
	{
		if(stJsr82->EvInfo[i].Used == MBT_TRUE)
		{
				for(k=0;k<MBT_JSR82_MAX_EVENT_NUM;k++)
				{
					if(!bdcmp(RemoteBDAddr,stJsr82->EvInfo[k].BDAddr))
						return MBT_TRUE;
				}
		}
			
	}
#endif
	return MBT_FALSE;
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_issvcconnected(MBT_SERVICE_ID MBTSvcID)
{
	MBT_INT i;
#if (MBT_DUN ==	MBT_TRUE)
	T_MBT_DUN_STATUS *stDun = (T_MBT_DUN_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_DUN_STATUS);
#endif
#if (MBT_AG 	== MBT_TRUE)
	T_MBT_AG_STATUS *stAg = (T_MBT_AG_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_AG_STATUS_TYPE);	
#endif
#if (MBT_A2DP == MBT_TRUE)
	T_MBT_A2DP_STATUS *stA2dp = (T_MBT_A2DP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_A2DP_STATUS);
#endif
#if (MBT_AVRCP == MBT_TRUE)
	T_MBT_AVRCP_STATUS *stAvrcp = (T_MBT_AVRCP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_AVRCP_STATUS);
#endif
#if (MBT_OPP == MBT_TRUE)
	T_MBT_OPP_STATUS *stOpp = (T_MBT_OPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OPP_STATUS);
#endif
#if (MBT_BPP == MBT_TRUE)
	T_MBT_BPP_STATUS *stBpp = (T_MBT_BPP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BPP_STATUS);
#endif
#if (MBT_BIP == MBT_TRUE)
	T_MBT_BIP_STATUS *stBip = (T_MBT_BIP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_BIP_STATUS);
#endif
#if (MBT_FTP == MBT_TRUE)
	T_MBT_FTP_STATUS *stFtp = (T_MBT_FTP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_FTP_STATUS);
#endif
#if (MBT_PBAP == MBT_TRUE)
	T_MBT_PBAP_STATUS *stPbap = (T_MBT_PBAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_PBAP_STATUS);
#endif
#if (MBT_HID_HOST == MBT_TRUE)
	T_MBT_HID_HOST_STATUS *stHidH = (T_MBT_HID_HOST_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_HID_HOST_STATUS);
#endif
#if (MBT_HID_DEVICE == MBT_TRUE)
	T_MBT_HID_DEVICE_STATUS *stHidD = (T_MBT_HID_DEVICE_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_HID_DEVICE_STATUS);
#endif
#if (MBT_JSR82 == MBT_TRUE)
	T_MBT_JSR82_STATUS *stJsr82 = (T_MBT_JSR82_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_JSR82_STATUS);
#endif
#if (MBT_SAP == MBT_TRUE)
	T_MBT_SAP_STATUS *stSap = (T_MBT_SAP_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_SAP_STATUS);
#endif

	if(MBTSvcID == 0)
	{
		//��� Connection�� üũ�ؼ� �ϳ��� Connect �Ǿ� ������ MBT_TRUE return
#if (MBT_JSR82 == MBT_TRUE)
		for(i=0;i<MBT_JSR82_MAX_EVENT_NUM;i++)
		{
			if(stJsr82->EvInfo[i].Used == MBT_TRUE)
			{
				return MBT_TRUE;
			}
		}
#endif
#if (MBT_DUN ==	MBT_TRUE)
		if(stDun->State == MBT_DUN_CONNECTED)
			return MBT_TRUE;
#endif
#if (MBT_AG 	== MBT_TRUE)
		if(stAg->bConection == MBT_TRUE)
			return MBT_TRUE;
#endif
#if (MBT_A2DP == MBT_TRUE)
		for(i=0;i<MBT_A2DP_MAX_CONN_NUM;i++)
		{
			if((stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_CONNECTED) ||
				(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_STARTING) ||
				(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_PLAY) ||
				(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_PAUSED) ||
				(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_STOPPING))
				{
					return MBT_TRUE;
				}
		}
#endif
#if (MBT_AVRCP == MBT_TRUE)
		for(i=0;i<MBT_AVRCP_MAX_CONN_NUM;i++)
		{
			if(stAvrcp->AvrcpConn[i].ConStatus == MBT_AVRCP_CONSTATUS_CONNECTED)
				return MBT_TRUE;
		}
#endif
#if (MBT_OPP == MBT_TRUE)
		if((stOpp->OppState == MBT_OPP_STATE_CONNECTED) ||
			(stOpp->OppState == MBT_OPP_STATE_SENDING) ||
			(stOpp->OppState == MBT_OPP_STATE_PULLING) ||
			(stOpp->OppState == MBT_OPP_STATE_RECEIVING))			
			return MBT_TRUE;	
#endif
#if (MBT_BPP == MBT_TRUE)
		if((stBpp->State == MBT_BPP_STATE_CONNECTED) ||
			(stBpp->State == MBT_BPP_STATE_GETATTRIBUTE) ||
			(stBpp->State == MBT_BPP_STATE_PRINTING))
			return MBT_TRUE;
#endif
#if (MBT_BIP == MBT_TRUE)
		if((stBip->State == MBT_BIP_STATE_CONNECTED) ||
			(stBip->State == MBT_BIP_STATE_SENDING) ||
			(stBip->State == MBT_BIP_STATE_RECEIVING))
			return MBT_TRUE;
#endif
#if (MBT_FTP == MBT_TRUE)
		if((stFtp->FtpState == MBT_FTP_STATE_CONNECTED) ||
			(stFtp->FtpState == MBT_FTP_STATE_SENDING) ||
			(stFtp->FtpState == MBT_FTP_STATE_RECEIVING))
			return MBT_TRUE;
#endif
#if (MBT_PBAP == MBT_TRUE)
		if((stPbap->State == MBT_PBAP_STATE_CONNECTED) ||
			(stPbap->State == MBT_PBAP_STATE_SENDING))
			return MBT_TRUE;
#endif
#if (MBT_HID_HOST == MBT_TRUE)
		if((stHidH->State == MBT_PBAP_STATE_CONNECTED) ||
			(stPbap->State == MBT_PBAP_STATE_SENDING))
			return MBT_TRUE;
#endif
#if (MBT_HID_DEVICE == MBT_TRUE)
		if(stHidD->State == MBT_HID_STATE_CONNECTED)
			return MBT_TRUE;
#endif
#if (MBT_SAP == MBT_TRUE)
			if((stSap->State == MBT_SAP_STATE_CONNECTED) ||
				(stSap->State == MBT_SAP_STATE_SENDING))
				return MBT_TRUE;
#endif
	}


	switch(MBTSvcID)
	{
#if (MBT_DUN ==	MBT_TRUE)
		case MBT_SVCUUID_DIALUP_NETWORKING :
		{
			if(stDun->State == MBT_DUN_CONNECTED)
				return MBT_TRUE;
		}
		break;
#endif	
#if (MBT_AG 	== MBT_TRUE)
		case MBT_SVCUUID_HEADSET:
		case MBT_SVCUUID_HF_HANDSFREE:
		{
			if(stAg->bConection == MBT_TRUE)
				return MBT_TRUE;
		}
		break;
#endif
#if (MBT_A2DP == MBT_TRUE)
		case MBT_SVCUUID_AUDIO_SINK:
		{
			for(i=0;i<MBT_A2DP_MAX_CONN_NUM;i++)
			{
				if((stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_CONNECTED) ||
					(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_STARTING) ||
					(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_PLAY) ||
					(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_PAUSED) ||
					(stA2dp->A2dpConn[i].ConStatus == MBT_A2DP_CONSTATUS_STOPPING))
					{
						return MBT_TRUE;
					}
			}
		}
		break;
#endif
#if (MBT_AVRCP == MBT_TRUE)
		case MBT_SVCUUID_AV_REMOTE_CONTROL_TARGET:
		case MBT_SVCUUID_AV_REMOTE_CONTROL:
		{
			for(i=0;i<MBT_AVRCP_MAX_CONN_NUM;i++)
			{
				if(stAvrcp->AvrcpConn[i].ConStatus == MBT_AVRCP_CONSTATUS_CONNECTED)
				{
					return MBT_TRUE;
				}
					
			}
		}
		break;
#endif
#if (MBT_OPP == MBT_TRUE)
		case MBT_SVCUUID_OBEX_OBJECT_PUSH:
		{
			if((stOpp->OppState == MBT_OPP_STATE_CONNECTED) ||
				(stOpp->OppState == MBT_OPP_STATE_SENDING) ||
				(stOpp->OppState == MBT_OPP_STATE_PULLING) ||
				(stOpp->OppState == MBT_OPP_STATE_RECEIVING))			
				return MBT_TRUE;
		}
		break;
#endif
#if (MBT_BPP == MBT_TRUE)
		case MBT_SVCUUID_DIRECT_PRINTING:
		{
			if((stBpp->State == MBT_BPP_STATE_CONNECTED) ||
				(stBpp->State == MBT_BPP_STATE_GETATTRIBUTE) ||
				(stBpp->State == MBT_BPP_STATE_PRINTING))
				return MBT_TRUE;
		}
		break;
#endif
#if (MBT_BIP == MBT_TRUE)
		case MBT_SVCUUID_IMAGING:
		case MBT_SVCUUID_IMAGING_RESPONDER:
		{
			if((stBip->State == MBT_BIP_STATE_CONNECTED) ||
				(stBip->State == MBT_BIP_STATE_SENDING) ||
				(stBip->State == MBT_BIP_STATE_RECEIVING))
				return MBT_TRUE;
		}
		break;
#endif
#if (MBT_FTP == MBT_TRUE)
		case MBT_SVCUUID_OBEX_FILE_TRANSFER:
		{
			if((stFtp->FtpState == MBT_FTP_STATE_CONNECTED) ||
				(stFtp->FtpState == MBT_FTP_STATE_SENDING) ||
				(stFtp->FtpState == MBT_FTP_STATE_RECEIVING))
				return MBT_TRUE;
		}
		break;
#endif
#if (MBT_PBAP == MBT_TRUE)
		case MBT_SVCUUID_PBAP_PSE:
		{
			if((stPbap->State == MBT_PBAP_STATE_CONNECTED) ||
				(stPbap->State == MBT_PBAP_STATE_SENDING))
				return MBT_TRUE;
		}
		break;
#endif
		case MBT_SVCUUID_HUMAN_INTERFACE:
#if (MBT_HID_HOST == MBT_TRUE)
		if((stHidH->State == MBT_PBAP_STATE_CONNECTED) ||
			(stPbap->State == MBT_PBAP_STATE_SENDING))
			return MBT_TRUE;
#endif
#if (MBT_HID_DEVICE == MBT_TRUE)
		if(stHidD->State == MBT_HID_STATE_CONNECTED)
			return MBT_TRUE;
#endif
		break;
#if (MBT_SAP == MBT_TRUE)
		case MBT_SVCUUID_SAP:
		{
			if((stSap->State == MBT_SAP_STATE_CONNECTED) ||
				(stSap->State == MBT_SAP_STATE_SENDING))
				return MBT_TRUE;
		}
		break;
		default :
			return MBT_FALSE;
		break;
#endif

	}
	return MBT_FALSE;
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_isauthorized(T_MBT_BDADDR RemoteBDAddr)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	MBT_INT i;
	T_MBT_PAIRED_DEV_LIST* btPairedList =(T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);

	for(i = 0 ; i < btPairedList->PairedCount ;i++)
	{
		if(!bdcmp(btPairedList->PairedList[i].BdAddr, RemoteBDAddr) )
		{
			return btPairedList->PairedList[i].bAuthorized;
		}
	}

	MBT_SDC("Not authorized device",0,0,0);
	return MBT_FALSE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_devdiscovery(MBT_SERVICE_ID MBTSvcID, MBT_INT nMaxCount)
{
#ifdef MBT_EMULATOR
#else

	bt_cmd_status_type			stat;
	bt_bd_addr_type 			addr;
	MBT_INT nSearchCount = 0;
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);

	if(nMaxCount == 0)
	{
		nSearchCount = MBT_MAXNUM_SEARCH_DEV;
	}
	else
	{
		if(nMaxCount > MBT_MAXNUM_SEARCH_DEV)
		{
			nSearchCount = MBT_MAXNUM_SEARCH_DEV; // LEECHANGHOON 2008-3-12 �⺻������ MBT_MAXNUM_SEARCH_DEV�� ����ؾ� �Ѵ�.
		}
		else
		{
			nSearchCount = nMaxCount;
		}
	}
	sdStatus = BTSD_SEARCHING;

	//QBT ��ġ �Լ� ȣ��
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	bt_cmd_hc_wr_scan_enable( BT_HC_INQ_DIS_PAGE_DIS );	// inquiry and page scan disable before searching. JG Kwon. 2010.01.25

	if(MBTSvcID == 0x0)	// 0�� ��� ��� ã����..BRCM�� ����..
	{
		stat = bt_cmd_sd_discover_devices( mbt_sd_app_id, 
											BT_SERVICE_CLASS_ALL,  
											&addr,		// Address field
											nSearchCount );
	}
	else
	{
		stat = bt_cmd_sd_discover_devices( mbt_sd_app_id, 
											MBTSvcID,
											&addr, 		// Address field
											nSearchCount );
	}

	*sdcGAPStatus = MBT_GAP_STATUS_DEVDISCOVERY;
	
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_devdiscoverycancel(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_status_type			stat;
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);

	sdStatus = BTSD_CANCEL;
	stat = bt_cmd_sd_stop_device_discovery(mbt_sd_app_id);
	*sdcGAPStatus = MBT_GAP_STATUS_DEVDISCOVERY_CANCEL;
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_namereq(T_MBT_BDADDR RemoteBDAddr)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_namereqcancel(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_svcdiscovery(T_MBT_BDADDR RemoteBDAddr)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_status_type	stat;
	bt_bd_addr_type addr;
	bt_sd_srch_pat_uuid_list_type	 uuid_list;
	bt_sd_srch_pat_attr_id_list_type attr_id_list;
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);
	
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);

	memset(&uuid_list, 0x00, sizeof(bt_sd_srch_pat_uuid_list_type));
	memset(&attr_id_list, 0x00, sizeof(bt_sd_srch_pat_attr_id_list_type));

	// LEECHANGHOON 2008-1-11 ����.
	//uuid_list.num_uuid  = 2;
	//uuid_list.uuid[0]   = MBT_SVCUUID_HEADSET;
	//uuid_list.uuid[1]   = MBT_SVCUUID_HF_HANDSFREE;
	
	uuid_list.num_uuid  = 1;
	uuid_list.uuid[0]   = BT_SD_PROTOCOL_L2CAP;
	
	attr_id_list.num_attr_id          = 1;
	attr_id_list.attr_id[0].is_range  = MBT_FALSE;
	attr_id_list.attr_id[0].value     = BT_SD_ATTR_ID_SERVICE_CLASS_ID_LIST;

	stat = bt_cmd_sd_search_service( mbt_sd_app_id, &addr, &uuid_list, &attr_id_list,
								 BT_SD_DEFAULT_MAX_ATTR_BYTE_COUNT );

	*sdcGAPStatus = MBT_GAP_STATUS_SVCDISCOVERY;
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_svcdiscoverycancel(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	//btapp_flag_service_search_canceled = MBT_TRUE;
	//���� �ʿ���. Broadcom�� ����ϸ� �׳� �ö���°� �����Ѵ�.QBT��?
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_pairreq(T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq, MBT_INT PinLength)
{
#ifdef MBT_EMULATOR
#else
	//BTA_DmBond(RemoteBDAddr);
	//�Ʒ��κ��� BT2.1�� �ʿ��ؼ� ������. QBT�� �ʿ������.
	//bt_app_cb.pin_from_user = MBT_TRUE;
	//strcpy((char *)bt_app_cb.pin_data_from_user, (const char *)PinReq);

	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);

	bt_pin_code_type pin;
	bt_cmd_status_type stat;
	bt_bd_addr_type addr;	
	bt_device_type stDevice;
	boolean bMITM = TRUE;
	
	// LEECHANGHOON 2007-11-16 QBT�� Role_sw_req�� ���� �׻� not accept �Ѵܴ�.
	// Pair req �̽��� ���� �ʿ��Ҷ��� accept�ϵ��� �ϰ� �ٽ� restore ��Ų��.
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);

	// LEECHANGHOON 2008-1-7 Pair_req ��Ҹ� ���� �ʿ�.
	memset((uint8*)pairreq_addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)pairreq_addr.bd_addr_bytes, (uint8*)addr.bd_addr_bytes, MBT_BDADDR_LEN);
	
	//mbt_gap_allow_role_switch(addr.bd_addr_bytes);

	*sdcGAPStatus = MBT_GAP_STATUS_PAIR_REQ;

	// Pairing request
	pin.length = PinLength;
	memcpy((uint8*)pin.pin_code, (uint8*)PinReq, MBT_PIN_LEN);

	stat = bt_cmd_rm_bond_ext( mbt_rm_app_id, &addr, &pin, bMITM );

#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_pairreqcancel(MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
	bt_cmd_status_type	stat;
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);

	*sdcGAPStatus = MBT_GAP_STATUS_PAIR_REQ_CANCEL;
	mbt_gap_restore_role_switch(pairreq_addr.bd_addr_bytes);

	//stat = bt_cmd_rm_bond_user_timeout(mbt_rm_app_id,  &pairreq_addr);

#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_pairres(MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_INT PinLength)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_pin_code_type	pin;
	bt_cmd_status_type	stat;
	bt_bd_addr_type addr;
	
	T_MBT_PINREPLY* btPinReply =(T_MBT_PINREPLY*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PINREPLY);
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);

	MBT_SDC("mbt_gap_pairres> bAcceps : %d,  pin length : %d ", bAccept, PinLength, 0);

	if(*sdcGAPStatus != MBT_GAP_STATUS_PAIR_REQ)
	{
		*sdcGAPStatus = MBT_GAP_STATUS_PAIR_RES;
	}
		
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btPinReply->BdAddr, MBT_BDADDR_LEN);
	
	pin.length = PinLength;
	
	memcpy((uint8*)pin.pin_code, (uint8*)PinRes, MBT_PIN_LEN);
	
	stat = bt_cmd_rm_pin_reply( mbt_rm_app_id, 
								&addr,
								bAccept, &pin );

	if(!bAccept)
	{ 
		T_MBT_PAIR_ERR_RSP* btPairError =(T_MBT_PAIR_ERR_RSP*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIRERROR);
		btPairError->ErrReason = MBT_GAP_PAIRERR_TIMEOUT;
		mbt_postevent(MBTEVT_GAP_PAIR_CANCEL_SUCCESS,NULL);
	}	// added to stop asking passcode again. JG Kwon. 2009.06.18

#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_sspres(MBT_BOOL bAccept)
{
	bt_pin_code_type	pin;
	bt_cmd_status_type	stat;
	bt_bd_addr_type addr;
	
	T_MBT_SSP* btSspRes =(T_MBT_SSP*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SSPINFO);
	T_MBT_GAP_STATUS *sdcGAPStatus = (T_MBT_GAP_STATUS *)mbt_sdc_getrecord(MBTSDC_REC_GAP_STATUS);

	MBT_SDC("mbt_gap_sspres> bAccept : %d ", bAccept, 0, 0);

	if(*sdcGAPStatus != MBT_GAP_STATUS_PAIR_REQ)
	{
		*sdcGAPStatus = MBT_GAP_STATUS_PAIR_RES;
	}

	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btSspRes->BdAddr, MBT_BDADDR_LEN);

	if(!bAccept)	// added to stop asking ssp popup again. JG Kwon. 2009.07.11
		mbt_postevent(MBTEVT_GAP_PAIR_CANCEL_SUCCESS,NULL);

	stat = bt_cmd_rm_user_confirmation_reply( mbt_rm_app_id, 
								&addr,
								bAccept);
	return;
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_ssppasskeycancel(MBT_VOID)
{
	bt_pin_code_type	pin;
	bt_cmd_status_type	stat;
	bt_bd_addr_type addr;
	
	T_MBT_SSP* btSspRes =(T_MBT_SSP*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SSPINFO);

	MBT_SDC("mbt_gap_sspres> bAccept : %d ", 0, 0, 0);
			
	memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
	memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btSspRes->BdAddr, MBT_BDADDR_LEN);
	
	stat = bt_cmd_rm_user_confirmation_reply( mbt_rm_app_id, 
								&addr,
								FALSE);
	return;	
}


/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_VOID mbt_gap_authorizationres(MBT_BYTE AuthMode, MBT_SERVICE_ID AuthSvc)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
 	bt_service_id_type  service_id;
	bt_bd_addr_type addr;
	T_MBT_AUTHREPLY* btAuthReply = (T_MBT_AUTHREPLY*)mbt_sdc_getrecord(MBTSDC_REC_GAP_AUTHREPLY);

	MBT_WARN(__func__"Service UUID: %x", auth_service_type,0,0);

/*** LEECHANGHOON 2007-12-1	 �������� OPP,FTP�� RM���� Authorize req�ø����� ������.
	if (auth_service_type == MBT_SVCUUID_OBEX_OBJECT_PUSH)
	{
		//OPP AUTH ó��
		mbt_opp_server_access_response(AuthMode);
	}
	else if(auth_service_type == MBT_SVCUUID_OBEX_FILE_TRANSFER)
	{
		//FTP AUTH ó��
		mbt_ftp_server_access_response(AuthMode);
	}
	else
***/
	{
		service_id.service_id_method = auth_service_id_method;
		switch(service_id.service_id_method) 
		{
			case BT_SIM_SDP_UUID:
				service_id.sdp_uuid = auth_service_type;
				break;
			case BT_SIM_RFCOMM_SCN:
				service_id.rfcomm_scn = auth_service_type;
				break;
			case BT_SIM_L2CAP_PSM:
				service_id.l2cap_psm = auth_service_type;
				break;
		}

      if (AuthMode == TRUE)
      {
        if ( (service_id.service_id_method == BT_SIM_L2CAP_PSM) && 
             (service_id.l2cap_psm == BT_SD_PROTOCOL_AVDTP) )
        {
          mbt_a2dp_set_authorized_channel(TRUE);
        }
      }
      
		
		memset((uint8*)addr.bd_addr_bytes, 0x00, MBT_BDADDR_LEN);
		memcpy((uint8*)addr.bd_addr_bytes, (uint8*)btAuthReply->BdAddr, MBT_BDADDR_LEN);
		if(authoReqJSR82)
		{
			bt_cmd_rm_authorize_reply(mbt_jsr82_app_id, &service_id, &addr, (boolean)AuthMode);
		}
		else
		{
			bt_cmd_rm_authorize_reply(mbt_rm_app_id, &service_id, &addr, (boolean)AuthMode);
		}
	}

#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_unpair(T_MBT_BDADDR RemoteBDAddr)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	bt_cmd_status_type          stat;
	bt_rm_dev_update_ctrl_type  update_bitmap;
	bt_device_type              device;
	if ( RemoteBDAddr == MBT_NULL )
	{
		return MBT_FALSE; //EBADPARM;
	}
	Unpair_cmd_flag = UNPAIR_CMD;
	update_bitmap  = BT_RM_DU_UNBOND_B;
	memcpy((uint8*)device.bd_addr.bd_addr_bytes, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);
	stat = bt_cmd_rm_device_update( mbt_rm_app_id, update_bitmap, &device );
	rex_sleep(300);
	if (mbt_gap_CheckCmdStatus(stat))
	{
		return MBT_TRUE;
	}
	return MBT_FALSE;
#endif
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_unpairall(MBT_VOID)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	MBT_INT i;
	T_MBT_PAIRED_DEV_LIST* btPairedList =(T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);
//	T_MBT_CONNECT_LIST* btConInfo =(T_MBT_CONNECT_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_CONNECTLIST);
//	T_MBT_SEARCHED_DEV_LIST* btSearchedList =(T_MBT_SEARCHED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_SEARCHLIST);
	bt_device_type	device;
	bt_cmd_status_type	stat;	
	bt_rm_dev_update_ctrl_type	update_bitmap;
	Unpair_cnt = 0;
	for(i = 0 ; i < btPairedList->PairedCount ;i++)
	{
		update_bitmap  = BT_RM_DU_UNBOND_B;
		memcpy((uint8*)device.bd_addr.bd_addr_bytes, (uint8*)btPairedList->PairedList[i].BdAddr, MBT_BDADDR_LEN);
		stat = bt_cmd_rm_device_update(mbt_rm_app_id, update_bitmap, &device );
		Unpair_cnt++;
		if(mbt_gap_CheckCmdStatus(stat))
		{
			MBT_WARN("UnPair All Count : [%d]",i,0,0);
		}
		else
		{
			//���� ����� ƨ��� SDC�� �г���. ���� �ʿ���
			MBT_ERR("UnPair All Err.couldn't remove at STACK!!",0,0,0);
			mbt_postevent(MBTEVT_GAP_UNPAIR_ALLDEV_FAIL, 0);
			return MBT_FALSE;
		}
	}
	Unpair_cmd_flag = UNPAIR_ALL_CMD;
	Unpaired_cnt = 0;
//ex_sleep(300);
	MBT_SDC("Unbond OK. Please Paired list Nv update.",0,0,0);
	//Need to Nv update	
	return MBT_TRUE;
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: 
********************************************************************************/
MBT_BOOL mbt_gap_setauthorize(T_MBT_BDADDR RemoteBDAddr, MBT_BOOL bAuthorize)
{
#ifdef MBT_EMULATOR
	return MBT_FALSE;
#else
	MBT_INT i;
	bt_cmd_status_type stat;
	bt_device_type      device;
	T_MBT_PAIRED_DEV_LIST* btPairedList =(T_MBT_PAIRED_DEV_LIST*)mbt_sdc_getrecord(MBTSDC_REC_GAP_PAIREDLIST);

	for(i = 0 ; i < btPairedList->PairedCount ;i++)
	{
		if(!bdcmp(btPairedList->PairedList[i].BdAddr, RemoteBDAddr) )
		{
			btPairedList->PairedList[i].bAuthorized = bAuthorize;
			device.bd_addr = *((bt_bd_addr_type*)&RemoteBDAddr);
			memcpy((uint8*)device.bd_addr.bd_addr_bytes, (uint8*)RemoteBDAddr, MBT_BDADDR_LEN);
			device.value_2 = bAuthorize;
			stat = bt_cmd_rm_device_update( mbt_rm_app_id, 
			              (bt_rm_dev_update_ctrl_type) BT_RM_DU_VALUE_2_B, 
			              &device );
			MBT_SDC("Device Authorize OK. Please Paired list Nv Update.",0,0,0);
			//Need to update Nv
			if(mbt_gap_CheckCmdStatus(stat))
				return MBT_TRUE;
			else
				return MBT_FALSE;
		}
	}
	MBT_ERR("Can't fine the device in the SDC(paired list) to authorize",0,0,0);
	return MBT_FALSE;	
#endif	
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� Role switch req�� �޴� ��� �⺻������ reject�� �Ѵ�.
*				 ��Ȥ Role switch req�� reject�� ��� �� ���� ������ �ȵǴ� Device�� �־
*				 Pair req �� ���� ���۽ÿ� �ӽ÷� accept�ߴٰ� �Ϸ��Ŀ� restore ���ش�.
********************************************************************************/
bt_cmd_status_type mbt_gap_allow_role_switch(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_BOOL bAllow;
	bt_cmd_status_type stat;

	stat = bt_cmd_rm_get_conn_role_sw_req_ok( mbt_rm_app_id, 
											  (bt_bd_addr_type*)NULL, 
											  (boolean*)&bAllow );
	if(bAllow == MBT_FALSE)
	{
		stat = bt_cmd_rm_set_conn_role_sw_req_ok( mbt_rm_app_id, 
												  (bt_bd_addr_type*)NULL, 
												  MBT_TRUE );
	}
	return stat;
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� Role switch req�� �޴� ��� �⺻������ reject�� �Ѵ�.
*				 ��Ȥ Role switch req�� reject�� ��� �� ���� ������ �ȵǴ� Device�� �־
*				 Pair req �� ���� ���۽ÿ� �ӽ÷� accept�ߴٰ� �Ϸ��Ŀ� restore ���ش�.
********************************************************************************/
bt_cmd_status_type mbt_gap_restore_role_switch(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_BOOL bAllow;
	bt_cmd_status_type stat;

	stat = bt_cmd_rm_get_conn_role_sw_req_ok( mbt_rm_app_id, 
											  (bt_bd_addr_type*)NULL, 
											  (boolean*)&bAllow );
	if(bAllow == MBT_TRUE)
	{
		stat = bt_cmd_rm_set_conn_role_sw_req_ok( mbt_rm_app_id, 
												 (bt_bd_addr_type*)NULL, 
												  MBT_FALSE );
	}
	
	return stat;
}

/********************************************************************************
*	Prototype	: 
*	Description	: QBT�� Remote Dev������ PIN REQ�� ���� Event �� remote ��ġ�� ������ address�ۿ� ����.
*				 �׷��� Name �� remote��ġ�� ���� ������ ���������� ���ļ� �򵵷��Ѵ�.
********************************************************************************/
static MBT_INT mbt_gap_db_deviceread(bt_app_id_type        bt_app_id, bt_device_type* pDevice)
{
	MBT_INT uNumSvcs = 0;
	bt_cmd_status_type  stat;
	bt_service_type     svcs[ BT_SD_MAX_NUM_OF_SRV_REC ];
	
	stat = bt_cmd_rm_device_read( bt_app_id, pDevice, (uint8*)&uNumSvcs, svcs );
	
	if ( stat == BT_CS_GN_SUCCESS )
	{
		return MBT_TRUE; //SUCCESS;
	}
	else
	{
		return MBT_FALSE; //EBADPARM;
	}
}

static MBT_INT mbt_gap_register_ACL_ConStatus(void)
{
	bt_app_id_type mbt_any_app_id;
	bt_cmd_status_type  stat = 0;

	mbt_any_app_id = bt_cmd_ec_get_application_id();

	if( mbt_any_app_id != BT_APP_ID_NULL )
	{
	  bt_cmd_ec_reg_event_set_any_app_id( mbt_any_app_id,
										  mbt_gap_RM_EventCallback,
										  BT_EC_ES_CUSTOM,
										  BT_EV_RM_CONNECTED_ACL,
										  BT_EV_RM_CONNECTED_ACL );
	  
	  stat = bt_cmd_ec_reg_event_set_any_app_id( mbt_any_app_id,
												 mbt_gap_RM_EventCallback,
												 BT_EC_ES_CUSTOM,
												 BT_EV_RM_DISCONNECTED_ACL,
												 BT_EV_RM_DISCONNECTED_ACL );
	}
	else
	{
	  return MBT_FALSE;
	}

	return (mbt_gap_CheckCmdStatus( stat ));
}

int mbt_gap_set_connection_role(const T_MBT_BDADDR*  pBDAddr, MBT_BOOL  bMaster)
{
  bt_cmd_status_type  stat;
#if 0
  if ( AEEHandle_From( &gOEMBTExtHandleList, pParent->m_hBT, 
                       (OEMINSTANCE*)&pMe ) != TRUE )
  {
    return EBADPARM;
  }
#endif   
  // NULL BD address is valid
  stat = bt_cmd_rm_set_connection_role( 
          mbt_rm_app_id, (bt_bd_addr_type*) pBDAddr,
           bMaster ? BT_ROLE_MASTER : BT_ROLE_SLAVE );

  return(mbt_gap_CheckCmdStatus( stat ) );
}

// [DKMOON_S] for dual profile
bt_role_type mbt_gap_get_connection_role(const T_MBT_BDADDR* pBDAddr)
{
  bt_cmd_status_type  stat;
  bt_bd_addr_type bd_addr;
  bt_role_type     curr_role;

  memcpy((uint8*)bd_addr.bd_addr_bytes, (uint8*)pBDAddr, sizeof(uint8)*6);

  stat = bt_cmd_rm_get_connection_role(mbt_rm_app_id, &bd_addr, &curr_role);
	 
  MBT_PI(" [System_BT_RM_GetConnectionRole] stat = (%x) Curr Role (%d) ", stat, curr_role, 0);

  if(stat == BT_CS_GN_SUCCESS)
  	 return curr_role;
  else
	return BT_ROLE_NONE;
}
// [DKMOON_E] for dual profile

MBT_BOOL mbt_gap_addblockdev(T_MBT_BDADDR BdAddr)
{
	return MBT_FALSE;
}


MBT_BOOL mbt_gap_removeblockdev(T_MBT_BDADDR BdAddr)
{
	return FALSE;
}

