/*-----------------------------------------------------------------------------
File qbt_obex.c

GENERAL DESCRIPTION
This file contains OBEX hooks to/from QBT Stack from/to MBT BT Layer.

Copyright (c) 2009 QUALCOMM Incorporated.
All Rights Reserved.
Qualcomm Confidential and Proprietary
-----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------

                        EDIT HISTORY FOR MODULE

  This section contains comments describing changes made to the module.
  Notice that changes are listed in reverse chronological order.

  $Header: None $
  $DateTime: None $
  $Author: ytkim $

  when        who  what, where, why
  ----------  ---  ------------------------------------------------------------
  2009-01-15   BK  Initial Revision

-----------------------------------------------------------------------------*/
#include "mbt_obex.h"
#include "btpfcmdi.h"
#include "btpf.h"
#include "oi_unicode.h"
#include "AEEstd.h"

#define QBT_OBEX_MAX_HEADERS  5

#if (MBT_OBEX == MBT_TRUE)
typedef struct {
	bt_app_id_type		          app_id;
	bt_pf_goep_srv_conn_id_type conn_id[MBT_OBEX_MAX_SERVER_NUM];
	uint8                       scn[MBT_OBEX_MAX_SERVER_NUM];
  boolean                     authenticate[MBT_OBEX_MAX_SERVER_NUM];
  boolean                     bAuthenticated[MBT_OBEX_MAX_SERVER_NUM];
  OI_REALM_INFO               realm[MBT_OBEX_MAX_SERVER_NUM];

  // buffer for storing rx obex header
  MBT_BYTE*                   obexHdrs[MBT_OBEX_MAX_SERVER_NUM];

  // buffer for storing tx obex header
  bt_pf_goep_obex_hdr_list_type headers_list[MBT_OBEX_MAX_SERVER_NUM];
} mbt_qbt_obex_object;

static mbt_qbt_obex_object qbt_obex_srv;

static MBT_BOOL mbt_obex_CheckCmdStatus( bt_cmd_status_type stat );
static MBT_VOID mbt_obex_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr );
static T_MBT_AUTHRES qbt_obex_MapCmdStatus(bt_cmd_status_type status);
static MBT_BOOL qbt_obex_srv_get_entry(T_MBT_OBEX_SERVICE_INFO* svc_info, uint8* index);
static MBT_BOOL qbt_obex_srv_get_entry_from_scn(uint8 scn, MBT_BYTE* index);
static MBT_BOOL qbt_obex_srv_get_entry_from_conn_id(uint16 conn_id, MBT_BYTE* index);
static MBT_VOID qbt_obex_srv_build_header(
  bt_pf_goep_obex_hdr_type* header, MBT_BYTE* bs, uint16* bs_pos);
static MBT_BOOL qbt_obex_srv_build_header_list(
  bt_pf_goep_obex_hdr_list_type* headers_list, MBT_BYTE* bs, MBT_SHORT bs_len);
static uint16 qbt_obex_srv_get_headers(
  uint8 hdrs_cnt, bt_pf_goep_obex_hdr_type* hdr_list_ptr, MBT_BYTE* dest_ptr);

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_server_enable (
    T_MBT_OBEX_SERVICE_INFO* SvcInfo, MBT_BYTE* target, MBT_BOOL Authc, 
    T_MBT_OBEX_CHARSET realm_charset, MBT_CHAR* realm, MBT_BYTE realm_len)
*	Description	: 
********************************************************************************/

MBT_VOID mbt_obex_server_enable(
  T_MBT_OBEX_SERVICE_INFO* SvcInfo, 
  MBT_BYTE* target, /* TODO: No length info, assume NULL terminated string */
  MBT_BOOL Authc, 
  T_MBT_OBEX_CHARSET realm_charset,
  MBT_CHAR* realm, 
  MBT_BYTE realm_len)
{
  bt_cmd_status_type cmd_status;
  bt_pf_byte_seq_type target_str;
  T_MBT_OBEX_STATUS *sdcObexStatus = 
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  MBT_BYTE srv_num = 0;

  if (!qbt_obex_srv_get_entry(SvcInfo, &srv_num))
  {
    // entry not found
    MBT_ERR("mbt_obex_server_enable> Enable failed. Could not find srv entry", 0,0,0);
    return;
  }

  if(sdcObexStatus->server_info[srv_num].bEnabled == MBT_TRUE)
  {
    MBT_WARN("mbt_obex_server_enable> OBEX is aleady enabled. Don't proceed & return",0,0,0);
    mbt_postevent(MBTEVT_OBEX_SERVER_ENABLE_FAIL, 0);
    return;
	}

  if (qbt_obex_srv.app_id == BT_APP_ID_NULL) 
  {
    /* get app_id */
    qbt_obex_srv.app_id = bt_cmd_ec_get_app_id_and_register(mbt_obex_EventCallback);
    if (qbt_obex_srv.app_id == BT_APP_ID_NULL) 
    {
      MBT_ERR("mbt_obex_server_enable> OBEX App id register error. app_id : NULL",0,0,0);
      mbt_postevent(MBTEVT_OBEX_SERVER_ENABLE_FAIL, 0);
      return;
    }
  }

  target_str.data = target;
  target_str.len = std_strlen((char*)target)+1;
  target_str.data[target_str.len] = 0;
  cmd_status = bt_cmd_pf_goep_srv_register( qbt_obex_srv.app_id,
                                            &target_str,
                                            BT_PF_GOEP_SRV_AUTH_NONE, // we will handle server auth here.
                                            (bt_sd_uuid_type)SvcInfo->svcUuid,
                                            BT_SEC_NONE,
                                            &sdcObexStatus->scn[srv_num]);
  if(!mbt_obex_CheckCmdStatus(cmd_status))
  {	
    MBT_ERR("mbt_obex_server_enable>Enable failed. Reason code : %x",cmd_status,0,0);
    mbt_postevent(MBTEVT_OBEX_SERVER_ENABLE_FAIL, 0); // TODO: is this the right event?
  }
  else
  {
    sdcObexStatus->server_info[srv_num].bEnabled = MBT_TRUE;
    sdcObexStatus->server_info[srv_num].ServerHandle = 0;
    sdcObexStatus->server_info[srv_num].ServerState = MBT_OBEX_SERVER_NO_CONNECTION;
    std_strlcpy(sdcObexStatus->server_info[srv_num].ServerService.svcName,
                SvcInfo->svcName, 
                ARR_SIZE(sdcObexStatus->server_info[srv_num].ServerService.svcName));
    sdcObexStatus->server_info[srv_num].ServerService.svcUuid = SvcInfo->svcUuid;

    qbt_obex_srv.conn_id[srv_num] = 0;

    // allocate buffer for storing rx and tx headers
    qbt_obex_srv.obexHdrs[srv_num] = malloc(MBT_OBEX_FILE_BUF_LEN); // TODO: check buf size

    qbt_obex_srv.headers_list[srv_num].list_ptr = 
      malloc(sizeof(bt_pf_goep_obex_hdr_type)*QBT_OBEX_MAX_HEADERS);

    // save auth and realm info
    qbt_obex_srv.bAuthenticated[srv_num] = FALSE;
    qbt_obex_srv.authenticate[srv_num] = (Authc)?TRUE:FALSE;
    qbt_obex_srv.realm[srv_num].realmLen = realm_len;
    qbt_obex_srv.realm[srv_num].realmStrType = (OI_UINT8) realm_charset;
    std_strlcpy((char*)qbt_obex_srv.realm[srv_num].realmStr, 
                realm, ARR_SIZE(qbt_obex_srv.realm[srv_num].realmStr));

    // not a q'ed command.. send success event.
    mbt_postevent(MBTEVT_OBEX_SERVER_ENABLE_SUCCESS, 0); // TODO: is this the right event?
  }

  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_server_disable (MBT_UINT ServerHandle)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_obex_server_disable (MBT_UINT ServerHandle)
{
	bt_cmd_status_type cmd_status;
  MBT_BYTE srv_num;
  MBT_BOOL bRegistered = MBT_FALSE;
	T_MBT_OBEX_STATUS *sdcObexStatus = 
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  uint16 i = 0;

  if (!qbt_obex_srv_get_entry_from_conn_id(ServerHandle, &srv_num))
  {
    // entry not found
    MBT_ERR("mbt_obex_server_disable> Disable failed. Could not find srv entry", 0,0,0);
    return;
  }

	if(sdcObexStatus->server_info[srv_num].bEnabled == MBT_TRUE && 
     sdcObexStatus->server_info[srv_num].ServerState == MBT_OBEX_SERVER_NO_CONNECTION)
	{
    cmd_status = bt_cmd_pf_goep_srv_deregister_server(qbt_obex_srv.app_id,
                                                      sdcObexStatus->scn[srv_num]);
    if(!mbt_obex_CheckCmdStatus(cmd_status))
    {
      MBT_ERR("mbt_obex_server_disable> deregister fail. Reason code : %x",cmd_status,0,0);
      mbt_postevent(MBTEVT_OBEX_SERVER_DISABLE_FAIL, 0);
    }
    else
    {
      sdcObexStatus->scn[srv_num] = 0;
      sdcObexStatus->server_info[srv_num].bEnabled = FALSE;
      sdcObexStatus->server_info[srv_num].ServerHandle = 0;
      sdcObexStatus->server_info[srv_num].ServerState = MBT_OBEX_SERVER_NO_CONNECTION;
      memset(sdcObexStatus->server_info[srv_num].ServerService.svcName, 0,
             sizeof(sdcObexStatus->server_info[srv_num].ServerService.svcName));
      sdcObexStatus->server_info[srv_num].ServerService.svcUuid = 0;

      // free buffer allocated for obex headers
      if (qbt_obex_srv.obexHdrs[srv_num] != NULL)
      {
        free (qbt_obex_srv.obexHdrs[srv_num]);
        qbt_obex_srv.obexHdrs[srv_num] = NULL;
      }

      if (qbt_obex_srv.headers_list[srv_num].list_ptr != NULL)
      {
        free (qbt_obex_srv.headers_list[srv_num].list_ptr);
        qbt_obex_srv.headers_list[srv_num].list_ptr = NULL;
      }

      // free app id if no server is registered
      for (i=0; i<MBT_OBEX_MAX_SERVER_NUM; i++) 
      {
        if (sdcObexStatus->server_info[i].bEnabled != MBT_FALSE) 
        {
          bRegistered = MBT_TRUE;
        }
      }

      if (bRegistered == MBT_FALSE) 
      {
        (void) bt_cmd_ec_free_application_id(qbt_obex_srv.app_id);
        qbt_obex_srv.app_id = BT_APP_ID_NULL;
      }

      // not a q'ed command.. notify app 
      mbt_postevent(MBTEVT_OBEX_SERVER_DISABLE_SUCCESS, 0);
    }
	}
	else
	{
		MBT_ERR("mbt_obex_server_disable> Cannot disable server. bEnabled=%d, state=%d",
            sdcObexStatus->server_info[srv_num].bEnabled,
            sdcObexStatus->server_info[srv_num].ServerState, 0);
		mbt_postevent(MBTEVT_OBEX_SERVER_DISABLE_FAIL, 0);
	}

  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_server_connect_res(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE connect_res)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_obex_server_connect_res(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE connect_res)
{
  T_MBT_OBEX_STATUS *sdcObexStatus = 
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  boolean accept = (connect_res.ResCode != MBT_OBEX_RES_OK)?FALSE:TRUE;
  bt_cmd_status_type status = 
    (connect_res.ResCode != MBT_OBEX_RES_OK)?MBT_OBEX_RES_FORBIDDEN:BT_CS_GN_SUCCESS;
  MBT_BYTE srv_num = 0;
  bt_cmd_status_type cmd_status;

  MBT_PI("mbt_obex_server_connect_res> handle:%x", ServerHandle, 0, 0);

  if (!qbt_obex_srv_get_entry_from_conn_id(ServerHandle, &srv_num))
  {
    // entry not found
    MBT_ERR("mbt_obex_server_connect_res> Connect Resp failed. Could not find srv entry", 0,0,0);
    return;
  }

  qbt_obex_srv_build_header_list(&qbt_obex_srv.headers_list[srv_num], 
                             connect_res.pObexHeader, 
                             connect_res.EvtLength);

  cmd_status = bt_cmd_pf_goep_srv_accept_connect(qbt_obex_srv.app_id, 
                                                 ServerHandle, 
                                                 accept,
                                                 qbt_obex_srv.headers_list[srv_num],
                                                 status);

  if (mbt_obex_CheckCmdStatus(cmd_status)) 
  {
    qbt_obex_srv.conn_id[srv_num] = ServerHandle;
    sdcObexStatus->server_info[srv_num].ServerState = MBT_OBEX_SERVER_CONNECTED;
    mbt_postevent(MBTEVT_OBEX_SERVER_CONNECT_SUCCESS, 0);
  }
  else
  {
    //mbt_postevent(MBTEVT_OBEX_SERVER_CONNECT_FAIL, 0);    
    MBT_ERR("mbt_obex_server_connect_res> Connect Resp failed. failed to accept connect", 0,0,0);
  }

  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_server_disconnect_res(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE disconnect_res)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_obex_server_disconnect_res(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE disconnect_res)
{
  MBT_BYTE srv_num;
  T_MBT_OBEX_STATUS *sdcObexStatus = 
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  bt_cmd_status_type status = 
    (disconnect_res.ResCode != MBT_OBEX_RES_OK)?MBT_OBEX_RES_FORBIDDEN:BT_CS_GN_SUCCESS;
  bt_cmd_status_type cmd_status;

  MBT_PI("mbt_obex_server_disconnect_res> handle:%x", ServerHandle, 0, 0);

  if (!qbt_obex_srv_get_entry_from_conn_id(ServerHandle, &srv_num))
  {
    // entry not found
    MBT_ERR("mbt_obex_server_disconnect_res> Disconnect Resp failed. Could not find srv entry", 0,0,0);
    return;
  }

  qbt_obex_srv_build_header_list(&qbt_obex_srv.headers_list[srv_num], 
                             disconnect_res.pObexHeader, 
                             disconnect_res.EvtLength);

  cmd_status = bt_cmd_pf_goep_srv_disconnect_response(qbt_obex_srv.app_id, 
                                                      ServerHandle, 
                                                      qbt_obex_srv.headers_list[srv_num],
                                                      status);

  if(mbt_obex_CheckCmdStatus(cmd_status))
  {
    qbt_obex_srv.conn_id[srv_num] = 0;
    qbt_obex_srv.bAuthenticated[srv_num] = FALSE;
    sdcObexStatus->server_info[srv_num].ServerState = MBT_OBEX_SERVER_NO_CONNECTION;
    mbt_postevent(MBTEVT_OBEX_SERVER_DISCONNECT_SUCCESS, 0);
  }  
  else
  {
    //mbt_postevent(MBTEVT_OBEX_SERVER_DISCONNECT_FAIL, 0);    
    MBT_ERR("mbt_obex_server_disconnect_res> Disconnect Resp failed. Failed to disconnect response", 0,0,0);
  }

  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_auth_response (
    MBT_UINT ServerHandle, MBT_CHAR* PassWD, MBT_BYTE PassLen, 
    MBT_CHAR* UserID, MBT_BYTE IDLen)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_obex_server_authenticate_res(
  MBT_UINT ServerHandle, MBT_CHAR* PassWD, MBT_BYTE PassLen, MBT_CHAR* UserID, MBT_BYTE IDLen)
{
  MBT_PI("mbt_obex_server_authenticate_res> handle:%x", ServerHandle, 0, 0);

  // make sure password is null terminated
  PassWD[PassLen] = 0;
  (void) bt_cmd_pf_goep_srv_auth_response(qbt_obex_srv.app_id,
                                          ServerHandle,
                                          PassWD, /* TODO: no provision for sending user-id */
                                          FALSE /* read_only */);
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_server_setpath_res (
    MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE setpath_res)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_obex_server_setpath_res(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE setpath_res)
{
  bt_cmd_status_type status = 
    (setpath_res.ResCode != MBT_OBEX_RES_OK)?MBT_OBEX_RES_FORBIDDEN:BT_CS_GN_SUCCESS;
  MBT_BYTE srv_num = 0;

  MBT_PI("mbt_obex_server_setpath_res> handle:%x", ServerHandle, 0, 0);

  if (!qbt_obex_srv_get_entry_from_conn_id(ServerHandle, &srv_num))
  {
    // entry not found
    MBT_ERR("mbt_obex_server_setpath_res> SetPathRsp failed. Could not find srv entry", 0,0,0);
    return;
  }

  qbt_obex_srv_build_header_list(&qbt_obex_srv.headers_list[srv_num], 
                             setpath_res.pObexHeader, 
                             setpath_res.EvtLength);

  (void) bt_cmd_pf_goep_srv_confirm_set_path(qbt_obex_srv.app_id,
                                             ServerHandle,
                                             qbt_obex_srv.headers_list[srv_num],
                                             status);
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_server_put_res (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE put_res)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_obex_server_put_res(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE put_res)
{
  bt_cmd_status_type status = 
    (put_res.ResCode != MBT_OBEX_RES_OK)?MBT_OBEX_RES_FORBIDDEN:BT_CS_GN_SUCCESS;
  MBT_BYTE srv_num = 0;

  MBT_PI("mbt_obex_server_put_res> handle:%x", ServerHandle, 0, 0);

  if (!qbt_obex_srv_get_entry_from_conn_id(ServerHandle, &srv_num))
  {
    // entry not found
    MBT_ERR("mbt_obex_server_put_res> PutRsp failed. Could not find srv entry", 0,0,0);
    return;
  }

  qbt_obex_srv_build_header_list(&qbt_obex_srv.headers_list[srv_num],
                             put_res.pObexHeader, 
                             put_res.EvtLength);

  (void) bt_cmd_pf_goep_srv_put_response(qbt_obex_srv.app_id,
                                         ServerHandle,
                                         qbt_obex_srv.headers_list[srv_num],
                                         status);
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_server_get_res (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE get_res)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_obex_server_get_res(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE get_res)
{
  bt_cmd_status_type status = 
    (get_res.ResCode != MBT_OBEX_RES_OK)?MBT_OBEX_RES_FORBIDDEN:BT_CS_GN_SUCCESS;
  MBT_BYTE srv_num = 0;

  MBT_PI("mbt_obex_server_get_res> handle:%x", ServerHandle, 0, 0);

  if (!qbt_obex_srv_get_entry_from_conn_id(ServerHandle, &srv_num))
  {
    // entry not found
    MBT_ERR("mbt_obex_server_get_res> GetRsp failed. Could not find srv entry", 0,0,0);
    return;
  }

  qbt_obex_srv_build_header_list(&qbt_obex_srv.headers_list[srv_num], 
                             get_res.pObexHeader, 
                             get_res.EvtLength);

  (void) bt_cmd_pf_goep_srv_get_response(qbt_obex_srv.app_id,
                                         ServerHandle,
                                         qbt_obex_srv.headers_list[srv_num],
                                         status);
  return;
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_server_abort_res (MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE abort_res)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_obex_server_abort_res(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE abort_res)
{
  bt_cmd_status_type status = 
    (abort_res.ResCode != MBT_OBEX_RES_OK)?MBT_OBEX_RES_FORBIDDEN:BT_CS_GN_SUCCESS;
  MBT_BYTE srv_num = 0;

  MBT_PI("mbt_obex_server_abort_res> handle:%x", ServerHandle, 0, 0);

  if (!qbt_obex_srv_get_entry_from_conn_id(ServerHandle, &srv_num))
  {
    // entry not found
    MBT_ERR("mbt_obex_server_abort_res> Connect Resp failed. Could not find srv entry", 0,0,0);
    return;
  }

  qbt_obex_srv_build_header_list(&qbt_obex_srv.headers_list[srv_num], 
                             abort_res.pObexHeader, 
                             abort_res.EvtLength);

  // TODO: No corresponding driver API for abort resp?!
  return;
}

/********************************************************************************
*	Prototype	: MBT_BYTE qbt_obex_srv_get_entry(T_MBT_OBEX_SERVER_INFO* svc_info)
*	Description	: 
********************************************************************************/
static MBT_BOOL qbt_obex_srv_get_entry(T_MBT_OBEX_SERVICE_INFO* svc_info, uint8* index)
{
  MBT_BOOL ret_val = MBT_FALSE;
  uint8 i = 0;
  T_MBT_OBEX_STATUS *sdcObexStatus = 
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);

  for (i=0; i<MBT_OBEX_MAX_SERVER_NUM; i++) 
  {
    if ((std_strcmp(sdcObexStatus->server_info[i].ServerService.svcName,
                   svc_info->svcName) == 0) &&
        (sdcObexStatus->server_info[i].ServerService.svcUuid == svc_info->svcUuid))
    {
      // server entry present
      *index = i;
      ret_val = MBT_TRUE;
      break;
    }
  }

  if (ret_val == MBT_FALSE) 
  {
    // find a unused entry
    for (i=0; i<MBT_OBEX_MAX_SERVER_NUM; i++) 
    {
      if (sdcObexStatus->server_info[i].bEnabled == MBT_FALSE) 
      {
        *index = i;
        ret_val = MBT_TRUE;
      }
    }
  }

  return ret_val;
}

/********************************************************************************
*	Prototype	: MBT_BOOL qbt_obex_srv_get_entry_from_scn(uint8 scn, MBT_BYTE* index)
*	Description	: 
********************************************************************************/
static MBT_BOOL qbt_obex_srv_get_entry_from_scn(uint8 scn, MBT_BYTE* index)
{
	T_MBT_OBEX_STATUS *sdcObexStatus =
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  uint16 i = 0;
  MBT_BOOL ret_val = MBT_FALSE;

  for (i=0; i<MBT_OBEX_MAX_SERVER_NUM; i++) 
  {
    if (sdcObexStatus->scn[i] == scn) 
    {
      *index = i;
      ret_val = MBT_TRUE;
      break;
    }
  }

  return ret_val;
}

/********************************************************************************
*	Prototype	: MBT_BOOL qbt_obex_srv_get_entry_from_conn_id(uint16 conn_id, MBT_BYTE* index)
*	Description	: 
********************************************************************************/
static MBT_BOOL qbt_obex_srv_get_entry_from_conn_id(uint16 conn_id, MBT_BYTE* index)
{
	T_MBT_OBEX_STATUS *sdcObexStatus =
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  uint16 i = 0;
  MBT_BOOL ret_val = MBT_FALSE;

  for (i=0; i<MBT_OBEX_MAX_SERVER_NUM; i++) 
  {
    if (sdcObexStatus->server_info[i].ServerHandle == conn_id) 
    {
      *index = i;
      ret_val = MBT_TRUE;
      break;
    }
  }

  return ret_val;
}

/********************************************************************************
*	Prototype	: MBT_BOOL qbt_obex_srv_build_header_list(
    bt_pf_goep_obex_hdr_list_type* headers_list, MBT_BYTE* hdrs_ptr, MBT_SHORT hdrs_len)
*	Description	: 
********************************************************************************/
static MBT_BOOL qbt_obex_srv_build_header_list(
  bt_pf_goep_obex_hdr_list_type* headers_list, MBT_BYTE* bs, MBT_SHORT bs_len)
{
  bt_pf_goep_obex_hdr_type* obex_hdr_ptr;
  uint16 bs_pos = 0;
  uint16 i, len = 0;

  /* first scan headers */
  headers_list->count = 0;
  while (bs_pos < bs_len) 
  {
    switch(OI_OBEX_HDR_KIND(bs[bs_pos]))
    {
    case OI_OBEX_HDR_ID_BYTESEQ:
    case OI_OBEX_HDR_ID_UNICODE:
      len = (uint16) ((uint16)bs[bs_pos+1] | (uint16)(bs[bs_pos] << 8)); /* assume big endian */
      if ((len < OI_OBEX_HEADER_PREFIX_LEN) || (len > len+OI_OBEX_HEADER_PREFIX_LEN))
      {
        /* error */
        MBT_ERR("qbt_obex_srv_build_header_list> bad length header %d", len, 0, 0);
        return MBT_FALSE;
      }
      bs_pos += len - OI_OBEX_HEADER_PREFIX_LEN;
      break;
    case OI_OBEX_HDR_ID_UINT8:
      bs_pos++;
      break;
    case OI_OBEX_HDR_ID_UINT32:
      bs_pos += sizeof(uint32);
      break;
    default:
      MBT_ERR("qbt_obex_srv_build_header_list> Error building header list, hdr_id %x", 
              bs[len], 0, 0);
      return MBT_FALSE;
    }
    headers_list->count++;
  }

  /* so far so good. now, build headers list */
  bs_pos = 0;
  for (i=0; i<headers_list->count; i++) 
  {
    obex_hdr_ptr = headers_list->list_ptr + i;
    qbt_obex_srv_build_header(obex_hdr_ptr, bs, &bs_pos);
  }

  return MBT_TRUE;
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_obex_srv_build_header(
    bt_pf_goep_obex_hdr_type* header, MBT_BYTE* bs, uint16* bs_pos)
*	Description	: 
********************************************************************************/
static MBT_VOID qbt_obex_srv_build_header(bt_pf_goep_obex_hdr_type* header, MBT_BYTE* bs, uint16* bs_pos)
{
  uint16 pos = *bs_pos;
  uint16 len = 0;

  header->id = bs[pos];  
  pos++;
  switch(OI_OBEX_HDR_KIND(header->id))
  {
  case OI_OBEX_HDR_ID_UNICODE:
    len = (uint16) ((uint16)(bs[pos+1]) | (uint16)(bs[pos] << 8));
    pos += sizeof(uint16);

    header->val.unicode.len = (len - OI_OBEX_HEADER_PREFIX_LEN)/sizeof(uint16);
    header->val.unicode.str = (uint16*) &bs[pos];  // TODO: we are referrencing 
                                                   // directly into source string.  is it okay?
    pos += (len - OI_OBEX_HEADER_PREFIX_LEN);
    break;
  case OI_OBEX_HDR_ID_BYTESEQ:
    len = (uint16) ((uint16)(bs[pos+1]) | (uint16)(bs[pos] << 8));
    pos += sizeof(uint16);

    header->val.byteseq.len = (len - OI_OBEX_HEADER_PREFIX_LEN);
    header->val.byteseq.data = (uint8*) &bs[pos];  // TODO: we are referrencing 
                                                   // directly into source string.  is it okay?
    pos += (len - OI_OBEX_HEADER_PREFIX_LEN);
    break;
  case OI_OBEX_HDR_ID_UINT8:
    header->val.u_int_8 = bs[pos];
    pos++;
    break;
  case OI_OBEX_HDR_ID_UINT32:
    header->val.u_int_32 = 
      (uint32) ((uint32)(bs[pos+3]) | 
                (uint32)(bs[pos+2] << 8) |
                (uint32)(bs[pos+1] << 16) | 
                (uint32)(bs[pos] << 24));
    pos += sizeof(uint32);
    break;
  default:
    /* should never get here */
    MBT_ERR("qbt_obex_srv_build_header> error, unexp header id %d", header->id, 0, 0);
  }

  /* update position in src byte stream */
  *bs_pos = pos;
}

/********************************************************************************
*	Prototype	: uint16 qbt_obex_srv_get_headers(
    uint8 hdrs_cnt, bt_pf_goep_obex_hdr_list_type* hdr_list_ptr, MBT_BYTE* dest_ptr)
*	Description	: 
********************************************************************************/
static uint16 qbt_obex_srv_get_headers(
  uint8 hdrs_cnt, bt_pf_goep_obex_hdr_type* hdr_list_ptr, MBT_BYTE* dest_ptr)
{
  uint8 i = 0;
  uint16 len = 0;
  uint16 hdr_len = 0;
  bt_pf_goep_obex_hdr_type* hdr_ptr;
  
  // clear dest buffer
  memset(dest_ptr, 0, MBT_OBEX_FILE_BUF_LEN);

  for (i=0; i<hdrs_cnt; i++) 
  {
    hdr_ptr = hdr_list_ptr + i;

    /* copy header id info */
    dest_ptr[len++] = hdr_ptr->id;

    switch(OI_OBEX_HDR_KIND(hdr_ptr->id))
    {
    case OI_OBEX_HDR_ID_BYTESEQ:
      /* copy length info */
      hdr_len = hdr_ptr->val.byteseq.len + OI_OBEX_HEADER_PREFIX_LEN;
      memcpy(&dest_ptr[len], &hdr_len, sizeof(uint16));
      len += sizeof(uint16);

      if (hdr_len > OI_OBEX_HEADER_PREFIX_LEN) 
      {
        /* copy data */
        memcpy(&dest_ptr[len], &hdr_ptr->val.byteseq.data, hdr_ptr->val.byteseq.len);
        len += hdr_ptr->val.byteseq.len;
      }
      break;
    case OI_OBEX_HDR_ID_UNICODE:
      /* copy length info */
      hdr_len = (hdr_ptr->val.unicode.len)*sizeof(uint16) + OI_OBEX_HEADER_PREFIX_LEN;
      memcpy(&dest_ptr[len], &hdr_len, sizeof(uint16));
      len += sizeof(uint16);

      if (hdr_len > OI_OBEX_HEADER_PREFIX_LEN) 
      {
        /* copy unicode string*/
        memcpy(&dest_ptr[len], &hdr_ptr->val.unicode.str, (hdr_ptr->val.unicode.len)*sizeof(uint16));
        len += (hdr_ptr->val.unicode.len)*sizeof(uint16);
      }
      break;
    case OI_OBEX_HDR_ID_UINT8:
      dest_ptr[len++] = hdr_ptr->val.u_int_8;
      break;
    case OI_OBEX_HDR_ID_UINT32:
      memcpy(&dest_ptr[len], &hdr_ptr->val.u_int_32, sizeof(uint32));
      len += sizeof(uint32);
      break;
    default: 
      /* should never get here since data is already validated in layer below */
      MBT_ERR("qbt_obex_srv_get_headers> invalid hdr id %d", hdr_ptr->id, 0, 0);
    }

    // free header (memory for which was allocated in layer below) 
    // now that it has been copied out
    bt_cmd_pf_goep_free_headers( qbt_obex_srv.app_id, hdr_ptr);
  }

  return len;
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_obex_srv_con_ind (bt_pf_ev_goep_srv_con_ind_type* bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_obex_srv_con_ind(bt_pf_ev_goep_srv_con_ind_type* bt_ev_msg_ptr)
{
	T_MBT_OBEX_STATUS *sdcObexStatus =
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  MBT_BYTE srv_num = 0; 
  bt_bd_addr_type bd_addr;

  MBT_PI("qbt_proc_evt_obex_srv_con_ind, target_id=%x, conn_id=%x",
         bt_ev_msg_ptr->target_id, bt_ev_msg_ptr->conn_id, 0);

  if (!qbt_obex_srv_get_entry_from_scn(bt_ev_msg_ptr->ch_num, &srv_num))
  {
    MBT_ERR("qbt_proc_evt_obex_srv_con_ind> unknown ch_num %x", bt_ev_msg_ptr->ch_num, 0, 0);
    return;
  }

  sdcObexStatus->server_info[srv_num].ServerState = MBT_OBEX_SERVER_CONNECTING;

  /* get bd address of remote device */
  bt_pf_goep_srv_get_client_addr(qbt_obex_srv.app_id, 
                                 bt_ev_msg_ptr->conn_id, 
                                 &bd_addr);

  if (qbt_obex_srv.authenticate[srv_num] == TRUE && 
      qbt_obex_srv.bAuthenticated[srv_num] == FALSE) 
  {
    // do server initiated authentication
    bt_cmd_pf_goep_srv_authenticate(bt_ev_msg_ptr->conn_id, 
                                    &bd_addr, 
                                    qbt_obex_srv.scn[srv_num],
                                    (bt_pf_realm_info_type*)qbt_obex_srv.realm,
                                    FALSE,  /* uid required */
                                    TRUE /* full access */);
    qbt_obex_srv.bAuthenticated[srv_num] = TRUE;
  } 
  else
  {
    sdcObexStatus->conn_req[srv_num].ServerHandle = bt_ev_msg_ptr->conn_id;
    sdcObexStatus->conn_req[srv_num].OpCode = MBT_OBEX_REQ_CONNECT;

    // assemble obex headers into a flat buffer
    sdcObexStatus->conn_req[srv_num].EvtLength = 
      qbt_obex_srv_get_headers(bt_ev_msg_ptr->cmd_headers_cnt, 
                               bt_ev_msg_ptr->cmd_headers_ptr, 
                               qbt_obex_srv.obexHdrs[srv_num]);

    /* save the hdr ptr */
    sdcObexStatus->conn_req[srv_num].pObexHeader = qbt_obex_srv.obexHdrs[srv_num];

    memcpy(sdcObexStatus->conn_req[srv_num].RemoteDevAddr, (void *)&bd_addr, sizeof(bt_bd_addr_type));

    if (bt_ev_msg_ptr->unauthorized == TRUE)
    {      
      mbt_postevent(MBTEVT_OBEX_SERVER_AUTHENTICATE_REQ, 0);
    }
    else
    {
      mbt_postevent(MBTEVT_OBEX_SERVER_CONNECT_REQ, 0);
    }
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_obex_srv_auth_ind (bt_pf_ev_goep_srv_auth_req_ind_type* bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_obex_srv_auth_ind(bt_pf_ev_goep_srv_auth_req_ind_type* bt_ev_msg_ptr)
{
	T_MBT_OBEX_STATUS *sdcObexStatus =
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  MBT_BYTE srv_num = 0;
  bt_bd_addr_type bd_addr;

  MBT_PI("qbt_proc_evt_obex_srv_con_ind, target_id=%x, conn_id=%x",
         bt_ev_msg_ptr->target_id, bt_ev_msg_ptr->conn_id, 0);

  if (!qbt_obex_srv_get_entry_from_scn(bt_ev_msg_ptr->ch_num, &srv_num))
  {
    MBT_ERR("qbt_proc_evt_obex_srv_auth_ind> unknown ch_num %x", bt_ev_msg_ptr->ch_num, 0, 0);
    return;
  }

  sdcObexStatus->server_info[srv_num].ServerState = MBT_OBEX_SERVER_CONNECTING;

  /* get bd address of remote device */
  bt_pf_goep_srv_get_client_addr(qbt_obex_srv.app_id, 
                                 bt_ev_msg_ptr->conn_id, 
                                 &bd_addr);

  if (qbt_obex_srv.authenticate[srv_num] == TRUE && 
      qbt_obex_srv.bAuthenticated[srv_num] == FALSE) 
  {
    // do server initiated authentication
    bt_cmd_pf_goep_srv_authenticate(bt_ev_msg_ptr->conn_id, 
                                    &bd_addr, 
                                    qbt_obex_srv.scn[srv_num],
                                    (bt_pf_realm_info_type*)qbt_obex_srv.realm,
                                    FALSE,  /* uid required */
                                    TRUE /* full access */);
    qbt_obex_srv.bAuthenticated[srv_num] = TRUE;
  } 
  else
  {
    sdcObexStatus->conn_req[srv_num].ServerHandle = bt_ev_msg_ptr->conn_id;
    sdcObexStatus->conn_req[srv_num].OpCode = MBT_OBEX_REQ_CONNECT; // TODO: no opcode for auth req?

    // assemble obex headers into a flat buffer
    /* TODO : no header in auth evt
    sdcObexStatus->conn_req[srv_num].EvtLength = 
      qbt_obex_srv_get_headers(bt_ev_msg_ptr->cmd_headers_cnt, 
                               bt_ev_msg_ptr->cmd_headers_ptr, 
                               qbt_obex_srv.obexHdrs[srv_num]);
                               */

    /* save the hdr ptr */
    // sdcObexStatus->conn_req[srv_num].pObexHeader = qbt_obex_srv.obexHdrs[srv_num];

    memcpy(sdcObexStatus->conn_req[srv_num].RemoteDevAddr, (void*) &bd_addr, sizeof(bt_bd_addr_type));

    mbt_postevent(MBTEVT_OBEX_SERVER_AUTHENTICATE_REQ, 0);
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_obex_srv_dcn_ind (bt_pf_ev_goep_srv_dcn_ind_type* bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_obex_srv_dcn_ind(bt_pf_ev_goep_srv_dcn_ind_type* bt_ev_msg_ptr)
{
	T_MBT_OBEX_STATUS *sdcObexStatus =
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  MBT_BYTE srv_num = 0;

  MBT_PI("qbt_proc_evt_obex_srv_dcn_ind, target_id=%x, conn_id=%x",
         bt_ev_msg_ptr->target_id, bt_ev_msg_ptr->conn_id, 0);

  if (!qbt_obex_srv_get_entry_from_scn(bt_ev_msg_ptr->ch_num, &srv_num))
  {
    MBT_ERR("qbt_proc_evt_obex_srv_dcn_ind> unknown ch_num %x", bt_ev_msg_ptr->ch_num, 0, 0);
    return;
  }

  sdcObexStatus->server_info[srv_num].ServerState = MBT_OBEX_SERVER_DISCONNECTING;
  sdcObexStatus->disc_req[srv_num].ServerHandle = bt_ev_msg_ptr->conn_id;
  sdcObexStatus->disc_req[srv_num].OpCode = MBT_OBEX_REQ_DISCONNECT;

  // assemble obex headers into a flat buffer
  sdcObexStatus->conn_req[srv_num].EvtLength = 
    qbt_obex_srv_get_headers(bt_ev_msg_ptr->cmd_headers_cnt, 
                             bt_ev_msg_ptr->cmd_headers_ptr, 
                             qbt_obex_srv.obexHdrs[srv_num]);

  /* save the hdr ptr */
  sdcObexStatus->disc_req[srv_num].pObexHeader = qbt_obex_srv.obexHdrs[srv_num];
 
  bt_pf_goep_srv_get_client_addr(qbt_obex_srv.app_id, 
                                 bt_ev_msg_ptr->conn_id, 
                                 (bt_bd_addr_type*)sdcObexStatus->disc_req[srv_num].RemoteDevAddr);

  mbt_postevent(MBTEVT_OBEX_SERVER_DISCONNECT_REQ, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_obex_srv_get_ind (bt_pf_ev_goep_srv_get_ind_type* bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_obex_srv_get_ind(bt_pf_ev_goep_srv_get_ind_type* bt_ev_msg_ptr)
{
	T_MBT_OBEX_STATUS *sdcObexStatus =
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  MBT_BYTE srv_num = 0;

  MBT_PI("qbt_proc_evt_obex_srv_get_ind, target_id=%x, conn_id=%x",
         bt_ev_msg_ptr->target_id, bt_ev_msg_ptr->conn_id, 0);

  if (!qbt_obex_srv_get_entry_from_scn(bt_ev_msg_ptr->ch_num, &srv_num))
  {
    MBT_ERR("qbt_proc_evt_obex_srv_get_ind> unknown ch_num %x", bt_ev_msg_ptr->ch_num, 0, 0);
    return;
  }

  sdcObexStatus->get_req[srv_num].ServerHandle = bt_ev_msg_ptr->conn_id;
  sdcObexStatus->get_req[srv_num].OpCode = 
    (bt_ev_msg_ptr->status==BT_CS_GN_SUCCESS)?MBT_OBEX_REQ_GET_FINAL:MBT_OBEX_REQ_GET;

  // assemble obex headers into a flat buffer
  sdcObexStatus->conn_req[srv_num].EvtLength = 
    qbt_obex_srv_get_headers(bt_ev_msg_ptr->cmd_headers_cnt, 
                             bt_ev_msg_ptr->cmd_headers_ptr, 
                             qbt_obex_srv.obexHdrs[srv_num]);

  /* save the hdr ptr */
  sdcObexStatus->get_req[srv_num].pObexHeader = qbt_obex_srv.obexHdrs[srv_num];

  mbt_postevent(MBTEVT_OBEX_SERVER_GET_REQ, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_obex_srv_put_ind (bt_pf_ev_goep_srv_put_ind_type* bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_obex_srv_put_ind(bt_pf_ev_goep_srv_put_ind_type* bt_ev_msg_ptr)
{
	T_MBT_OBEX_STATUS *sdcObexStatus =
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  MBT_BYTE srv_num = 0;

  MBT_PI("qbt_proc_evt_obex_srv_put_ind, target_id=%x, conn_id=%x",
         bt_ev_msg_ptr->target_id, bt_ev_msg_ptr->conn_id, 0);

  if (!qbt_obex_srv_get_entry_from_scn(bt_ev_msg_ptr->ch_num, &srv_num))
  {
    MBT_ERR("qbt_proc_evt_obex_srv_get_ind> unknown ch_num %x", bt_ev_msg_ptr->ch_num, 0, 0);
    return;
  }

  sdcObexStatus->put_req[srv_num].ServerHandle = bt_ev_msg_ptr->conn_id;
  sdcObexStatus->put_req[srv_num].OpCode = 
    (bt_ev_msg_ptr->status==BT_CS_GN_SUCCESS)?MBT_OBEX_REQ_PUT_FINAL:MBT_OBEX_REQ_PUT;

  // assemble obex headers into a flat buffer
  sdcObexStatus->put_req[srv_num].EvtLength = 
    qbt_obex_srv_get_headers(bt_ev_msg_ptr->cmd_headers_cnt, 
                             bt_ev_msg_ptr->cmd_headers_ptr, 
                             qbt_obex_srv.obexHdrs[srv_num]);

  /* save the hdr ptr */
  sdcObexStatus->put_req[srv_num].pObexHeader = qbt_obex_srv.obexHdrs[srv_num];

  mbt_postevent(MBTEVT_OBEX_SERVER_PUT_REQ, 0);
}

/********************************************************************************
*	Prototype	: MBT_VOID qbt_proc_evt_obex_srv_set_path_ind (bt_pf_ev_goep_srv_set_path_ind_type* bt_ev_msg_ptr)
*	Description	: 
********************************************************************************/
MBT_VOID qbt_proc_evt_obex_srv_set_path_ind(bt_pf_ev_goep_srv_set_path_ind_type* bt_ev_msg_ptr)
{
	T_MBT_OBEX_STATUS *sdcObexStatus =
    (T_MBT_OBEX_STATUS*)mbt_sdc_getrecord(MBTSDC_REC_OBEX_STATUS);
  MBT_BYTE srv_num = 0;

  MBT_PI("qbt_proc_evt_obex_srv_set_path_ind, target_id=%x, conn_id=%x",
         bt_ev_msg_ptr->target_id, bt_ev_msg_ptr->conn_id, 0);

  if (!qbt_obex_srv_get_entry_from_scn(bt_ev_msg_ptr->ch_num, &srv_num))
  {
    MBT_ERR("qbt_proc_evt_obex_srv_set_path_ind> unknown ch_num %x", bt_ev_msg_ptr->ch_num, 0, 0);
    return;
  }

  sdcObexStatus->setpath_req[srv_num].ServerHandle = bt_ev_msg_ptr->conn_id;
  sdcObexStatus->setpath_req[srv_num].OpCode = MBT_OBEX_REQ_SETPATH;
  sdcObexStatus->setpath_req[srv_num].Backup = bt_ev_msg_ptr->up_level;
  sdcObexStatus->setpath_req[srv_num].NoCreate = !(bt_ev_msg_ptr->create);

  // assemble obex headers into a flat buffer
  sdcObexStatus->setpath_req[srv_num].EvtLength = 
    qbt_obex_srv_get_headers(bt_ev_msg_ptr->cmd_headers_cnt, 
                             bt_ev_msg_ptr->cmd_headers_ptr, 
                             qbt_obex_srv.obexHdrs[srv_num]);

  /* save the hdr ptr */
  sdcObexStatus->setpath_req[srv_num].pObexHeader = qbt_obex_srv.obexHdrs[srv_num];
 
  bt_pf_goep_srv_get_client_addr(qbt_obex_srv.app_id, 
                                 bt_ev_msg_ptr->conn_id, 
                                 (bt_bd_addr_type*)sdcObexStatus->setpath_req[srv_num].RemoteDevAddr);

  mbt_postevent(MBTEVT_OBEX_SERVER_SETPATH_REQ, 0);
}

/********************************************************************************
*	Prototype	: char* qbt_obex_MapCmdStatus (bt_cmd_status_type status)
*	Description	: 
********************************************************************************/
static T_MBT_AUTHRES qbt_obex_MapCmdStatus(bt_cmd_status_type status)
{
  switch (status)
  {
  case BT_CS_PF_OBEX_ACCESS_DENIED:
    return MBT_FORBID_RES;
  case BT_CS_PF_OBEX_ERROR:
    return MBT_ERROR_RES;
  case BT_CS_PF_OBEX_UNAUTHORIZED:
    return MBT_UNAUTHORIZED_RES;
  case BT_CS_PF_OBEX_NOT_FOUND:
    return MBT_NOT_FOUND_RES;
  case BT_CS_PF_OBEX_UNSUPPORTED_MEDIA_TYPE:
    return MBT_UNSUPPORTED_MEDIA_TYPE_RES;
  case BT_CS_PF_OBEX_SERVICE_UNAVAILABLE:
    return MBT_SERVICE_UNAVAILABLE_RES;
  case BT_CS_PF_OBEX_DATABASE_FULL:
    return MBT_DATABASE_FULL_RES;
  case BT_CS_PF_OBEX_INTERNAL_SERVER_ERROR:
  default:
    return MBT_INTERNAL_SERVER_ERROR_RES;
  }
}

/********************************************************************************
*	Prototype	: MBT_BOOL mbt_obex_CheckCmdStatus (bt_cmd_status_type stat)
*	Description	: 
********************************************************************************/
static MBT_BOOL mbt_obex_CheckCmdStatus(bt_cmd_status_type stat)
{
	switch (stat)
	{
		case BT_CS_GN_SUCCESS:
		case BT_CS_GN_PENDING:
			return MBT_TRUE; //SUCCESS;

		case BT_CS_GN_CMD_Q_FULL:
			MBT_ERR("mbt_obex_CheckCmdStatus state:%d", stat,0,0);
			return MBT_FALSE; //ENOMEMORY;

		default:
			MBT_ERR("mbt_obex_CheckCmdStatus state:%d", stat,0,0);
			return MBT_FALSE; //EFAILED;
	}
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_HandleCmdDone( bt_ev_msg_type* bt_ev_msg_ptr )
*	Description :
********************************************************************************/
static MBT_VOID mbt_obex_HandleCmdDone( bt_ev_gn_cmd_done_type* pCmdDn )
{
  switch (pCmdDn->cmd_type)
  {
    case BT_PF_CMD_GOEP_SRV_ACCEPT:
    case BT_PF_CMD_GOEP_SRV_DCN_RSP:
    default:
    {
      MBT_PI("mbt_obex_HandleCmdDone, cmd=%x, status=%x", 
             pCmdDn->cmd_type, pCmdDn->cmd_status, 0);
    }
  }
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_obex_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
*	Description :
********************************************************************************/
static MBT_VOID mbt_obex_EventCallback( bt_ev_msg_type* bt_ev_msg_ptr )
{
	switch (bt_ev_msg_ptr->ev_hdr.ev_type)
	{
		case BT_EV_GN_CMD_DONE:
            MBT_PI("mbt_obex_cmd_done> cmd:%x status:%x", 
            bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_type, 
            bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done.cmd_status, 0);
            mbt_obex_HandleCmdDone(&bt_ev_msg_ptr->ev_msg.ev_gn_cmd_done);
	        break;

		case BT_EV_PF_GOEP_SRV_CON_IND:
			qbt_proc_evt_obex_srv_con_ind(&bt_ev_msg_ptr->ev_msg.ev_goep_srv_con_ind);
			break;

		case BT_EV_PF_GOEP_SRV_AUTH_IND:
			qbt_proc_evt_obex_srv_auth_ind(&bt_ev_msg_ptr->ev_msg.ev_goep_srv_auth_req_ind);
			break;

		case BT_EV_PF_GOEP_SRV_DCN_IND:
			qbt_proc_evt_obex_srv_dcn_ind(&bt_ev_msg_ptr->ev_msg.ev_goep_srv_dcn_ind);
			break;

        case BT_EV_PF_GOEP_SRV_GET_IND:
			qbt_proc_evt_obex_srv_get_ind(&bt_ev_msg_ptr->ev_msg.ev_goep_srv_get_ind);
			break;

        case BT_EV_PF_GOEP_SRV_PUT_IND:
			qbt_proc_evt_obex_srv_put_ind(&bt_ev_msg_ptr->ev_msg.ev_goep_srv_put_ind);
			break;

        case BT_EV_PF_GOEP_SRV_SET_PATH_IND:
			qbt_proc_evt_obex_srv_set_path_ind(&bt_ev_msg_ptr->ev_msg.ev_goep_srv_set_path_ind);
			break;

		default:
			MBT_ERR("mbt_obex_EventCallback> evt:%d", bt_ev_msg_ptr->ev_hdr.ev_type, 0, 0);
			break;
	}
}

#endif
