/********************************************************************************
*	File Name	: mbt_sap_brcm.c
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.12.03		Ahn, ChangSuk			Created
********************************************************************************/
#include "mbt_sap.h"

#if (MBT_SAP == MBT_TRUE)
/********************************************************************************
*	Prototype	: MBT_VOID mbt_sap_server_enable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_enable (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	: MBT_VOID mbt_sap_server_disable (MBT_VOID)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_disable (MBT_VOID)
{
#ifdef MBT_EMULATOR
#else
#endif
}


/********************************************************************************
*	Prototype	:  mbt_sap_server_respond_transferatr( T_MBT_SAP_RESULT_CODE    	ResultCode,
														 MBT_SHORT  			     			AtrResLength,
														 MBT_BYTE *                        			pAtrRes)
*	Description	: 
********************************************************************************/
 MBT_VOID mbt_sap_server_respond_transferatr( T_MBT_SAP_RESULT_CODE    	ResultCode,
														 MBT_SHORT  			     			AtrResLength,
														 MBT_BYTE *                        			pAtrRes)
{
#ifdef MBT_EMULATOR
#else


 #endif
}


/********************************************************************************
*	Prototype	:  mbt_sap_serverconnect_respond( T_MBT_BDADDR PeerBDAddr,
													     T_MBT_SAP_CONNECT_STATUS ConnStatus,
													     MBT_SHORT MaxMsgSize,
													     T_MBT_SAP_CARD_STATUS CardStatus)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_connect_respond( T_MBT_BDADDR PeerBDAddr,
													     T_MBT_SAP_CONNECT_STATUS ConnStatus,
													     MBT_SHORT MaxMsgSize,
													     T_MBT_SAP_CARD_STATUS CardStatus)
{
#ifdef MBT_EMULATOR
#else
#endif
}



/********************************************************************************
*	Prototype	:  MBT_VOID mbt_sap_server_respondtransferapdu(T_MBT_SAP_RESULT_CODE   	ResultCode,
														     MBT_SHORT  			ApduResLength,
														     MBT_BYTE *            		pApduRes)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_respondtransferapdu(T_MBT_SAP_RESULT_CODE   	ResultCode,
														     MBT_SHORT  			 		ApduResLength,
														     MBT_BYTE *               			pApduRes)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	:  MBT_VOID mbt_sap_server_respondpowersimoff(T_MBT_SAP_RESULT_CODE   ResultCode)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_respondpowersimoff(T_MBT_SAP_RESULT_CODE   ResultCode)
{
#ifdef MBT_EMULATOR
#else
#endif
}

/********************************************************************************
*	Prototype	:  MBT_VOID mbt_sap_server_respondpowersimon(T_MBT_SAP_RESULT_CODE   ResultCode)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_respondpowersimon(T_MBT_SAP_RESULT_CODE   ResultCode)
{
#ifdef MBT_EMULATOR
#else


 #endif

}

/********************************************************************************
*	Prototype	:  MBT_VOID mbt_sap_server_respond_resetsim(T_MBT_SAP_RESULT_CODE   ResultCode)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_respond_resetsim(T_MBT_SAP_RESULT_CODE   ResultCode)
{
#ifdef MBT_EMULATOR
#else


 #endif
}

/********************************************************************************
*	Prototype	:  MBT_VOID mbt_sap_server_respond_transfercardreaderstatus(T_MBT_SAP_RESULT_CODE          ResultCode,
																    T_MBT_SAP_CARD_READER_STATUS   CardReaderStatus)

*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_respond_transfercardreaderstatus(T_MBT_SAP_RESULT_CODE          ResultCode,
																    T_MBT_SAP_CARD_READER_STATUS   CardReaderStatus)
{
#ifdef MBT_EMULATOR
#else


 #endif

}

/********************************************************************************
*	Prototype	:  MBT_VOID mbt_sap_serverrespond_transportprotocol(T_MBT_SAP_RESULT_CODE   ResultCode)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_respond_transportprotocol(T_MBT_SAP_RESULT_CODE   ResultCode)
{
#ifdef MBT_EMULATOR
#else


 #endif

}

/********************************************************************************
*	Prototype	:  MBT_VOID mbt_sap_server_send_cardstatus(T_MBT_SAP_CARD_STATUS CardStatus)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_send_cardstatus(T_MBT_SAP_CARD_STATUS CardStatus)
{
#ifdef MBT_EMULATOR
#else


 #endif
}


/********************************************************************************
*	Prototype	:  MBT_VOID mbt_sap_server_request_disconnect (T_MBT_SAP_DISCONNECT DisconnType)
*	Description	: 
********************************************************************************/
MBT_VOID mbt_sap_server_request_disconnect (T_MBT_SAP_DISCONNECT DisconnType)
{
#ifdef MBT_EMULATOR
#else


 #endif
}
#endif //#if (MBT_SAP == MBT_TRUE)