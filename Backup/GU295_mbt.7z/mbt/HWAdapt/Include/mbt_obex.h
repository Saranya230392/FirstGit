#ifndef _MBT_OBEX_PI_H_
#define _MBT_OBEX_PI_H_

#include "MBTType.h"
#include "mbt_debugmsg.h"


#ifndef OBEX_ROOT_FOLDER
#define OBEX_ROOT_FOLDER                      "\\Projects\\bte\\samples\\pra\\test_files\\fts"
#endif

/* =========================================================== */
extern MBT_VOID mbt_obex_serverenable(T_MBT_OBEX_SERVICE_INFO* SvcInfo, MBT_BYTE* target, MBT_BOOL Authc, T_MBT_OBEX_CHARSET realm_charset, MBT_CHAR* realm, MBT_BYTE realm_len);
extern MBT_VOID mbt_obex_serverdisable(MBT_UINT ServerHandle);
extern MBT_VOID mbt_obex_serverconnectres(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE connect_res);
extern MBT_VOID mbt_obex_serverdisconnectres(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE disconnect_res);
extern MBT_VOID mbt_obex_serverauthenticateres(MBT_UINT ServerHandle, MBT_CHAR* PassWD, MBT_BYTE PassLen, MBT_CHAR* UserID, MBT_BYTE IDLen);
extern MBT_VOID mbt_obex_serversetpathres(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE setpath_res);
extern MBT_VOID mbt_obex_serverputres(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE put_res);
extern MBT_VOID mbt_obex_servergetres(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE get_res);
extern MBT_VOID mbt_obex_serverabortres(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE abort_res);

#endif//_MBT_OBEX_PI_H_
