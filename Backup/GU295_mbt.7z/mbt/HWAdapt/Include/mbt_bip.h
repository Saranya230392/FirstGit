#ifndef _MBT_BIP_PI_H_
#define _MBT_BIP_PI_H_

#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_bip_initiator_enable(MBT_VOID);
extern MBT_VOID mbt_bip_initiator_disable (MBT_VOID);
extern MBT_VOID mbt_bip_initiator_auth_response(T_MBT_OBEX_AUTH *auth_reply);
extern MBT_VOID mbt_bip_initiator_getcapability_request(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_bip_initiator_pushimage(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBTObject);
extern MBT_VOID mbt_bip_initiator_pushthumbnail(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBTObject);
extern MBT_VOID mbt_bip_initiator_disconnect(MBT_VOID);

extern MBT_VOID mbt_bip_responder_enable(MBT_VOID);
extern MBT_VOID mbt_bip_responder_disable (MBT_VOID);
extern MBT_VOID mbt_bip_responder_auth_response(T_MBT_OBEX_AUTH *auth_reply);
extern MBT_VOID mbt_bip_responder_access_response(T_MBT_AUTHRES Reply);
extern MBT_VOID mbt_bip_responder_getcapability_response(T_MBT_AUTHRES Reply, T_MBT_BIP_IMAGING_CAPABILITY *ImagingCapability);
extern MBT_VOID mbt_bip_responder_disconnect(MBT_VOID);
#endif//_MBT_BIP_PI_H_
