/*******************************************************************************
*	SPP�� MBT 1.0���� ���Ե��� ������ �׽�Ʈ ���� �ʾҽ��ϴ�.
********************************************************************************/
#ifndef _MBT_SPP_PI_H_
#define _MBT_SPP_PI_H_
/********************************************************************************
*	File Name	: mbt_spp.h
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.04.12		Kim,Hyunseok			Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_spp_enable(MBT_VOID);
extern MBT_VOID mbt_spp_listen (MBT_VOID);
extern MBT_VOID mbt_spp_disable(MBT_VOID);
extern MBT_VOID mbt_spp_listenstop(MBT_VOID);
extern MBT_VOID mbt_spp_connect(T_MBT_BDADDR remoteBdAddr);
extern MBT_VOID mbt_spp_disconnect(T_MBT_BDADDR remoteBdAddr);
extern MBT_VOID mbt_spp_senddata(T_MBT_SPP_DATA *txData);


#endif//_MBT_SPP_PI_H_
