/*******************************************************************************
*	DUN�� MBT 1.0���� ���Ե��� ������ �׽�Ʈ ���� �ʾҽ��ϴ�.
********************************************************************************/
#ifndef _MBT_DUN_PI_H_
#define _MBT_DUN_PI_H_
/********************************************************************************
*	File Name	: mbt_dun.h
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.04.12		Kim,Hyunseok			Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_dun_enable (MBT_VOID);
extern MBT_VOID mbt_dun_disable (MBT_VOID);
extern MBT_VOID mbt_dun_disconnect(T_MBT_BDADDR remoteBdAddr);
extern MBT_VOID mbt_dun_listen(MBT_VOID);
extern MBT_VOID mbt_dun_listenstop(MBT_VOID);

#endif//_MBT_DUN_PI_H_