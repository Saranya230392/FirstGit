#ifndef _MBT_AVRCP_PI_H_
#define _MBT_AVRCP_PI_H_

#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_avrcp_enable(MBT_VOID);
extern MBT_VOID mbt_avrcp_disable(MBT_VOID);
extern MBT_VOID mbt_avrcp_connect(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_avrcp_disconnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_avrcp_sendcmd(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_KEY KeyValue);
extern MBT_VOID mbt_avrcp_get_player_value_res(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_APP_ATTR* AttrValue);
extern MBT_VOID mbt_avrcp_get_media_attr_res(T_MBT_BDADDR BdAddr, MBT_BYTE AttrNum, T_MBT_AVRCP_MEDIA_ATTR* AttrData);
extern MBT_VOID mbt_avrcp_get_playstatus_res(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_GET_PLAYSTATUS PlayStatus);
extern MBT_VOID mbt_avrcp_register_noti_interim_res(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti);
extern MBT_VOID mbt_avrcp_register_noti_res(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti);
#endif//_MBT_AVRCP_PI_H_