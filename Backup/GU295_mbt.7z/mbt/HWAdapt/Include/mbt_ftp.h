#ifndef _MBT_FTP_PI_H_
#define _MBT_FTP_PI_H_

#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_ftp_server_enable (MBT_VOID);
extern MBT_VOID mbt_ftp_server_disable (MBT_VOID);
extern MBT_VOID mbt_ftp_server_access_response( T_MBT_AUTHRES Reply );
extern MBT_VOID mbt_ftp_server_auth_response( T_MBT_OBEX_AUTH *auth_reply );
extern MBT_BOOL mbt_ftp_server_setrootfolder(MBT_CHAR *RootFolder);

extern MBT_VOID mbt_ftp_client_enable(MBT_VOID);
extern MBT_VOID mbt_ftp_client_disable (MBT_VOID);
extern MBT_VOID mbt_ftp_client_open(T_MBT_BDADDR RemoteBDAddr);
extern MBT_VOID mbt_ftp_client_close(MBT_VOID);
extern MBT_VOID mbt_ftp_client_auth_response( T_MBT_OBEX_AUTH *auth_reply );
extern MBT_VOID mbt_ftp_client_putfile(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID mbt_ftp_client_getfile (T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID mbt_ftp_client_chdir(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID mbt_ftp_client_mkdir(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID mbt_ftp_client_listdir(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID mbt_ftp_client_deldir(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID mbt_ftp_client_delfile(T_MBT_FTP_OBJECT * MBTObject);
extern MBT_VOID mbt_ftp_client_abort(MBT_VOID);

#endif//_MBT_FTP_PI_H_
