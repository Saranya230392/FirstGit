/*******************************************************************************
*	PBAP�� MBT 1.0���� ���Ե��� ������ �׽�Ʈ ���� �ʾҽ��ϴ�.
********************************************************************************/
#ifndef _MBT_PBAP_PI_H_
#define _MBT_PBAP_PI_H_
/********************************************************************************
*	File Name	: mbt_spp.h
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.10.23		Lee,DongHyun			Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_pbap_server_enable(MBT_VOID);
extern MBT_VOID mbt_pbap_server_disable(MBT_VOID);
extern MBT_VOID mbt_pbap_server_accessresponse(MBT_BOOL b_allow);
extern MBT_VOID mbt_pbap_server_authenticate(MBT_CHAR *p_password, MBT_CHAR *p_userid);
extern MBT_VOID mbt_pbap_server_close(MBT_VOID);
extern MBT_VOID mbt_pbap_server_writedata(T_MBT_PBAP_OP Operation);

#endif//_MBT_PBAP_PI_H_
