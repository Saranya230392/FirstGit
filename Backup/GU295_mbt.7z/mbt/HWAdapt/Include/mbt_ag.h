#ifndef _MBT_AG_PI_H_
#define	_MBT_AG_PI_H_

#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID	mbt_ag_enable(MBT_VOID);
extern MBT_VOID	mbt_ag_disable(MBT_VOID);
extern MBT_VOID	mbt_ag_connect(T_MBT_BDADDR RemoteBDAddr,MBT_SERVICE_ID MBtSvc);
extern MBT_VOID	mbt_ag_disconnect(T_MBT_BDADDR RemoteBDAddr,MBT_SERVICE_ID MBtSvc);
extern MBT_VOID	mbt_ag_audioconnect(MBT_VOID);
extern MBT_VOID	mbt_ag_audiodisconnect(MBT_VOID);
extern MBT_BOOL	mbt_ag_getconstatus(MBT_VOID);
extern MBT_BOOL	mbt_ag_getaudiostatus(MBT_VOID);
extern MBT_VOID	mbt_ag_setconnectable(MBT_BOOL connectable);
extern MBT_VOID	mbt_ag_setaudiopath(MBT_BOOL audiopath);
extern MBT_VOID	mbt_ag_setspkvolume(MBT_BYTE Level);
extern MBT_VOID	mbt_ag_setmicvolume(MBT_BYTE Level);
extern MBT_VOID mbt_ag_callstatechange(T_MBT_AG_PHONE_CALLSTATE NewState);
extern MBT_VOID mbt_ag_setcallstatus(T_MBT_AG_CALLSTATUS CurrentStatus);
extern MBT_VOID mbt_ag_setcallsetup(T_MBT_AG_CALLSETUP CurrentCallSetup);
extern MBT_VOID	mbt_ag_setnetworkstatus(T_MBT_AG_NETSTATE	State);
extern MBT_VOID	mbt_ag_setcid(MBT_CHAR* Num, MBT_BYTE len);
extern MBT_BOOL mbt_ag_setsignalstrength(MBT_BYTE Level);
extern MBT_BOOL mbt_ag_setroamingstatus(MBT_BYTE Level);
extern MBT_BOOL mbt_ag_setbatterylevel(MBT_BYTE Level);
extern MBT_BOOL mbt_ag_setcallheldstatus(T_MBT_AG_CALL_HELD value);
extern MBT_BOOL mbt_ag_setoperatorselection(T_MBT_AG_NETMODE Netmode, MBT_BYTE* OpName);
extern MBT_BOOL mbt_ag_setextendederror(T_MBT_AG_CME_ERR ErrorCode);
extern MBT_BOOL mbt_ag_setsubscribernumber(MBT_CHAR* Num, MBT_BYTE NumType, MBT_BYTE Len, T_MBT_AG_SERVICE Service, MBT_BOOL FinalFlag);
extern MBT_BOOL mbt_ag_setcallwaiting(MBT_CHAR* Num, MBT_BYTE Len);
extern MBT_VOID	mbt_ag_sendresponse(MBT_BOOL Response);
extern MBT_BOOL mbt_ag_setcind(T_MBT_AG_NETSTATE Net, T_MBT_AG_CALLSTATUS CallState, T_MBT_AG_CALLSETUP SetupState, MBT_BYTE SignalLevel, MBT_BYTE RoamingStatus, MBT_BYTE BatteryLevel,T_MBT_AG_CALL_HELD value);
extern MBT_BOOL mbt_ag_setcurrentcalllist(MBT_BYTE Idx, T_MBT_AG_CL_DIR Dir, T_MBT_AG_CL_STATUS Status, T_MBT_AG_CL_MODE Mode, T_MBT_AG_CL_MPTY Mprty, MBT_CHAR* Num, MBT_BYTE NumType, MBT_BYTE Len, MBT_BOOL FinalFlag);
extern MBT_VOID	mbt_ag_startvr(MBT_VOID);
extern MBT_VOID	mbt_ag_stopvr(MBT_VOID);
extern MBT_VOID mbt_ag_sendsupportedpblist(T_MBT_AG_PB_CPBS supportedPbList);
extern MBT_VOID mbt_ag_sendselectedpbinfo(T_MBT_AG_PB_RETURN result, MBT_SHORT usedRecs, MBT_SHORT totalRecs);
extern MBT_VOID mbt_ag_sendpbselectresult(T_MBT_AG_PB_RETURN result);
extern MBT_VOID mbt_ag_sendpbentriesinfo(T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt);
extern MBT_VOID mbt_ag_sendpbreadresult(T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec,  MBT_BOOL finalEntry);
extern MBT_VOID mbt_ag_sendpbfindentriesinfo(T_MBT_AG_PB_RETURN result, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt);
extern MBT_VOID mbt_ag_sendpbfindresult(T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec, MBT_BOOL finalEntry);
extern MBT_VOID mbt_ag_sendpbwriteinfo(T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxlenNum, MBT_SHORT typeStart, MBT_SHORT typeEnd, MBT_SHORT maxlenTxt);
extern MBT_VOID mbt_ag_sendpbwriteresult( T_MBT_AG_PB_RETURN result );
extern MBT_VOID mbt_ag_setcgm(MBT_CHAR* manufacturerid, MBT_CHAR* modelid);
extern MBT_VOID mbt_ag_ringstart(MBT_VOID);
extern MBT_VOID mbt_ag_ringstop(MBT_VOID);
extern MBT_VOID mbt_ag_setcscs(T_MBT_AG_CSCS* AgCSList);
extern MBT_BOOL mbt_ag_CPBR_parser(MBT_CHAR* cmd);
extern MBT_BOOL mbt_ag_CPBS_parser(MBT_CHAR* cmd);
extern MBT_BOOL  mbt_ag_CPBF_parser(MBT_CHAR* cmd);
extern MBT_BOOL  mbt_ag_CPBW_parser(MBT_CHAR* cmd);
#endif//_MBT_AG_PI_H_
