/*******************************************************************************
*	JSR82�� MBT 1.0���� ���Ե��� ������ �׽�Ʈ ���� �ʾҽ��ϴ�.
********************************************************************************/
#ifndef _MBT_JSR82_PI_H_
#define _MBT_JSR82_PI_H_
/********************************************************************************
*	File Name		: mbt_jsr82.h
*	Description	:	
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.05.17		Hanseok Park			Created
*	07.06.22		Hanseok Park			Modified the JSR82 API names
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_jsr82_enable(MBT_VOID);
extern MBT_VOID mbt_jsr82_disable(MBT_VOID);
extern MBT_UINT mbt_jsr82_get_discoverable(MBT_VOID);
extern MBT_BOOL mbt_jsr82_set_discoverable(MBT_UINT Mode);
extern MBT_BOOL mbt_jsr82_set_security(MBT_UINT Handle,T_MBT_JSR82_SET_SECURITY* Security);
extern MBT_BOOL mbt_jsr82_set_myCoD(MBT_SHORT ServiceCalss, MBT_BYTE MajorClass, MBT_BYTE MinorClass);
extern MBT_BOOL mbt_jsr82_get_myCoD(MBT_VOID);


extern T_MBT_GAP_SECURITY mbt_jsr82_get_encrypted(T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL mbt_jsr82_get_authenticated(T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL mbt_jsr82_set_encrypted(T_MBT_BDADDR RemoteBDAddr,T_MBT_GAP_SECURITY Security);
extern MBT_BOOL mbt_jsr82_pair_req(MBT_UINT Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq, MBT_BYTE PinLength);
extern MBT_BOOL mbt_jsr82_pair_res(MBT_UINT Handle, MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_BYTE PinLength);

extern MBT_BOOL mbt_jsr82_name_req(MBT_UINT Handle,T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL mbt_jsr82_dev_discovery(MBT_UINT Handle,MBT_UINT AccessMode);
extern MBT_BOOL mbt_jsr82_dev_discovery_cancel(MBT_UINT Handle);
extern MBT_BOOL mbt_jsr82_svc_discovery(T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_SEARCH_SD* SearchInfo, MBT_UINT TransID);
extern MBT_BOOL mbt_jsr82_svc_discovery_cancel(MBT_UINT TransID);
extern MBT_BOOL mbt_jsr82_authorize(T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL mbt_jsr82_populate_record(MBT_UINT SvcHandle,T_MBT_BDADDR RemoteBDAddr,MBT_UINT *Attr,MBT_UINT AttrLength);
extern MBT_BOOL mbt_jsr82_read_record(MBT_UINT SvcHandle, MBT_BYTE* Data, MBT_UINT* DataLength);
extern MBT_BOOL mbt_jsr82_is_connected(T_MBT_BDADDR RemoteBDAddr);

extern MBT_BOOL mbt_jsr82_get_service_result(MBT_UINT TransID, MBT_INT ReadNum);
extern MBT_VOID mbt_jsr82_create_record(MBT_UINT SvcHandle,T_MBT_JSR82_SD_RECORD* CreateInfo);
extern MBT_INT mbt_jsr82_update_record(MBT_UINT SvcHandle, T_MBT_JSR82_SD_RECORD* UpdateInfo);
extern MBT_VOID mbt_jsr82_remove_record(MBT_UINT SvcHandle);
extern MBT_VOID mbt_jsr82_delete_attribute(MBT_UINT SvcHandle, MBT_SHORT AttrID);

extern MBT_INT mbt_jsr82_l2cap_open_server(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config);
extern MBT_INT mbt_jsr82_l2cap_close_server(MBT_BYTE Handle);
extern MBT_INT  mbt_jsr82_l2cap_get_svc_handle(MBT_VOID);
extern MBT_INT mbt_jsr82_l2cap_accept(MBT_BYTE Handle, MBT_BYTE PeerHandle);
extern MBT_BOOL mbt_jsr82_l2cap_open_client(MBT_BYTE Handle);
extern MBT_BOOL mbt_jsr82_l2cap_set_param(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config);
extern MBT_INT mbt_jsr82_l2cap_connect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, MBT_INT PSM);
extern MBT_INT mbt_jsr82_l2cap_disconnect(MBT_BYTE Handle);
extern MBT_INT mbt_jsr82_l2cap_write(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
extern MBT_INT mbt_jsr82_l2cap_read(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
extern MBT_BOOL mbt_jsr82_l2cap_get_ready(MBT_BYTE Handle,  MBT_UINT* DLENS);
extern MBT_VOID mbt_jsr82_l2cap_release(MBT_VOID);

extern MBT_INT mbt_jsr82_rfcomm_open_server(MBT_BYTE Handle, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config);
extern MBT_INT mbt_jsr82_rfcomm_close_server(MBT_BYTE Handle);
extern MBT_INT  mbt_jsr82_rfcomm_get_svc_handle(MBT_VOID);
extern MBT_INT mbt_jsr82_rfcomm_accept(MBT_BYTE Handle, MBT_BYTE PeerHandle);
extern MBT_BOOL mbt_jsr82_rfcomm_open_client(MBT_BYTE Handle);
extern MBT_INT mbt_jsr82_rfcomm_connect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config);
extern MBT_INT mbt_jsr82_rfcomm_disconnect(MBT_BYTE Handle);
extern MBT_INT mbt_jsr82_rfcomm_write(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
extern MBT_INT mbt_jsr82_rfcomm_read(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length);
extern MBT_BOOL mbt_jsr82_rfcomm_get_ready(MBT_BYTE Handle, MBT_UINT* DLENS);
extern MBT_VOID mbt_jsr82_rfcomm_release(MBT_VOID);

#endif	//_MBT_JSR82_PI_H_
