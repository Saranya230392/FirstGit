#ifndef _MBT_HID_PI_H_
#define _MBT_HID_PI_H_
/********************************************************************************
*	File Name	: mbt_hid.h
*	Description	: 
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.04.09		Kim,Hyunseok		Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_hid_host_enable(FP_MBT_HID_RX_REPORT_CO fpRxRptCO);
extern MBT_VOID mbt_hid_host_disable(MBT_VOID);
extern MBT_VOID mbt_hid_host_connect(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_hid_host_disconnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_hid_host_add_device(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_hid_host_remove_device(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_hid_host_get_descInfo(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_hid_host_set_led(T_MBT_BDADDR BdAddr, T_MBT_HID_LED_MASK led);
extern MBT_VOID mbt_hid_host_send_led(T_MBT_BDADDR BdAddr, T_MBT_HID_LED_MASK led);
extern MBT_VOID mbt_hid_host_send_control(T_MBT_BDADDR BdAddr, T_MBT_HID_CONTROL control);
extern MBT_VOID mbt_hid_host_send_report(T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
extern MBT_VOID mbt_hid_host_set_report(T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
extern MBT_VOID mbt_hid_host_get_report(T_MBT_BDADDR BdAddr, MBT_BYTE rpt_type, MBT_BYTE rpt_id);
extern MBT_VOID mbt_hid_host_get_idle(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_hid_host_set_idle(T_MBT_BDADDR BdAddr, MBT_BYTE idle);
extern MBT_VOID mbt_hid_host_get_protocol(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_hid_host_set_protocol(T_MBT_BDADDR BdAddr, MBT_BOOL boot_mode);

extern MBT_VOID mbt_hid_device_enable(MBT_VOID);
extern MBT_VOID mbt_hid_device_disable(MBT_VOID);
extern MBT_VOID mbt_hid_device_connect(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_hid_device_disconnect(MBT_VOID);
extern MBT_VOID mbt_hid_device_send_unplug(MBT_VOID);
extern MBT_VOID mbt_hid_device_send_report(T_MBT_HID_REPORT_TYPE rpt_type, MBT_BYTE *rpt_data, MBT_SHORT rpt_size);
extern MBT_VOID mbt_hid_device_send_keyboard_rpt(T_MBT_HID_MODIFIER_MASK modifier, T_MBT_HID_KEY_TYPE *keycodes, MBT_BYTE key_num);
extern MBT_VOID mbt_hid_device_send_mouse_rpt(T_MBT_HID_MOUSE_BUTTON_MASK button, MBT_BYTE move_x, MBT_BYTE move_y);
extern MBT_VOID mbt_hid_device_change_keyboard_role(MBT_VOID);
extern MBT_VOID mbt_hid_device_change_mouse_role(MBT_VOID);
extern MBT_VOID mbt_hid_device_change_phone_role(MBT_VOID);

#endif//_MBT_HID_PI_H_
