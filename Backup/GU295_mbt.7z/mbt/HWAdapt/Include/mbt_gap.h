#ifndef _MBT_GAP_PI_H_
#define	_MBT_GAP_PI_H_

#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_BOOL	mbt_gap_btinitialize(MBT_VOID);
extern MBT_VOID	mbt_gap_bluetoothon(MBT_VOID);
extern MBT_VOID	mbt_gap_bluetoothoff(MBT_VOID);
extern MBT_BOOL	mbt_gap_setmyname(MBT_CHAR* MyDevName);
extern MBT_BOOL	mbt_gap_setnickname(T_MBT_BDADDR PairedDevAddr, MBT_CHAR* NickName);
extern MBT_BOOL	mbt_gap_setconnectable(MBT_BOOL bConnectable);
extern MBT_BOOL	mbt_gap_setvisible(MBT_BOOL bVisibile);
extern MBT_BOOL	mbt_gap_setpairable(MBT_BOOL bPairabie);
extern MBT_BOOL	mbt_gap_iscmdacceptable(MBT_VOID);
extern MBT_BOOL	mbt_gap_isdeviceconnected(T_MBT_BDADDR RemoteBDAddr);
extern MBT_BOOL	mbt_gap_issvcconnected(MBT_SERVICE_ID MBtSvc);
extern MBT_BOOL	mbt_gap_isauthorized(T_MBT_BDADDR RemoteBDAddr);
extern MBT_VOID	mbt_gap_devdiscovery(MBT_SERVICE_ID MBTSvc, MBT_INT nMaxCount);
extern MBT_VOID	mbt_gap_devdiscoverycancel(MBT_VOID);
extern MBT_VOID	mbt_gap_namereq(T_MBT_BDADDR RemoteBdAddr);
extern MBT_VOID	mbt_gap_namereqcancel(MBT_VOID);
extern MBT_VOID	mbt_gap_svcdiscovery(T_MBT_BDADDR RemoteBdAddr);
extern MBT_VOID	mbt_gap_svcdiscoverycancel(MBT_VOID);
extern MBT_VOID	mbt_gap_pairreq(T_MBT_BDADDR RemoteBdAddr, T_MBT_PIN PinReq, MBT_INT PinLength);
extern MBT_VOID	mbt_gap_pairreqcancel(MBT_VOID);
extern MBT_VOID	mbt_gap_pairres(MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_INT PinLength);
extern MBT_VOID	mbt_gap_sspres(MBT_BOOL bAccept);
extern MBT_VOID	mbt_gap_ssppasskeycancel(MBT_VOID);
extern MBT_VOID	mbt_gap_authorizationres(MBT_BOOL AuthMode, MBT_SERVICE_ID AuthSvc);
extern MBT_BOOL	mbt_gap_unpair(T_MBT_BDADDR RemoteBdAddr);
extern MBT_BOOL	mbt_gap_unpairall(MBT_VOID);
extern MBT_BOOL	mbt_gap_setauthorize(T_MBT_BDADDR RemoteBdAddr, MBT_BOOL bAuthorize);
extern MBT_BOOL	mbt_gap_addblockdev(T_MBT_BDADDR BdAddr);
extern MBT_BOOL	mbt_gap_removeblockdev(T_MBT_BDADDR BdAddr);


extern MBT_BOOL	mbt_gap_is_bluetoothon(MBT_VOID);

#endif//_MBT_GAP_PI_H_
