#ifndef _MBT_A2DP_PI_H_
#define _MBT_A2DP_PI_H_
/********************************************************************************
*	File Name	: mbt_a2dp.h
*	Description	: 
*
*	when		who(fullname)		what,why
*	--------	----------------	--------------------------------------------
*	07.04.09		Kim,Hyunseok		Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_a2dp_source_enable(MBT_VOID);
extern MBT_VOID mbt_a2dp_source_disable(MBT_VOID);
extern MBT_VOID mbt_a2dp_source_connect(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_a2dp_source_disconnect(T_MBT_BDADDR BdAddr);
extern MBT_VOID mbt_a2dp_source_start(MBT_VOID);
extern MBT_VOID mbt_a2dp_source_stop(MBT_VOID);
extern MBT_VOID mbt_a2dp_source_pause(MBT_VOID);
extern MBT_VOID mbt_a2dp_source_resume(MBT_VOID);

#endif//_MBT_A2DP_PI_H_
