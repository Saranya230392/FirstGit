/*******************************************************************************
********************************************************************************/
#ifndef _MBT_MISC_PI_H_
#define _MBT_MISC_PI_H_
/********************************************************************************
*	File Name	: mbt_misc.h
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.12.10		So,SoonSang			Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_misc_dutenable(MBT_INT value);
extern MBT_VOID mbt_misc_dutdisable(MBT_VOID);
extern MBT_VOID mbt_misc_setfccmode(T_MBT_BDADDR testMyAddr, T_MBT_TEST_MODE mode);
extern MBT_BOOL mbt_misc_factorytestmode(T_MBT_BDADDR testMyAddr);
extern MBT_BOOL	mbt_misc_getversion(MBT_VOID);
extern MBT_BOOL mbt_misc_useMMC(MBT_BOOL use);
extern MBT_BOOL mbt_misc_clearpbapfiles(MBT_VOID);
extern MBT_BOOL	mbt_misc_getlocalinfo(MBT_VOID);
extern MBT_BOOL	mbt_misc_radioon(MBT_VOID);
extern MBT_BOOL	mbt_misc_radiooff(MBT_VOID);
extern MBT_BOOL mbt_misc_setsspdebugmode(MBT_BOOL bEnable);
#endif//_MBT_MISC_PI_H_
