#ifndef _MBT_OPP_PI_H_
#define	_MBT_OPP_PI_H_
/********************************************************************************
*	File Name	: mbt_opp.h
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.04.09		Kim,Hyunseok			Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_opp_server_enable(MBT_VOID);
extern MBT_VOID mbt_opp_server_disable(MBT_VOID);
extern MBT_VOID mbt_opp_server_disconnect(MBT_VOID);
extern MBT_VOID mbt_opp_server_access_response(T_MBT_AUTHRES Reply);
extern MBT_VOID mbt_opp_client_enable(MBT_VOID);
extern MBT_VOID mbt_opp_client_disable(MBT_VOID);
extern MBT_VOID mbt_opp_client_pushobject(T_MBT_BDADDR RemoteBDAddr,T_MBT_OPP_OBJECT * MBTObject);
extern MBT_VOID mbt_opp_client_pullobject(T_MBT_BDADDR RemoteBDAddr,T_MBT_OPP_OBJECT * MBTObject);
extern MBT_VOID mbt_opp_client_exchobject(T_MBT_BDADDR RemoteBDAddr,T_MBT_OPP_OBJECT * SendObject,T_MBT_OPP_OBJECT * RecvObject);
extern MBT_VOID mbt_opp_client_disconnect(MBT_VOID);

#endif//_MBT_OPP_PI_H_
