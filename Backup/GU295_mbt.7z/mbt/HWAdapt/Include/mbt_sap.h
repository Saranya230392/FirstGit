#ifndef _MBT_SAP_PI_H_
#define _MBT_SAP_PI_H_

/********************************************************************************
*	File Name	: mbt_sap.h
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.12.10		Ahn,ChangSuk			Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_sap_server_enable (MBT_VOID);
extern MBT_VOID mbt_sap_server_disable (MBT_VOID);
extern MBT_VOID mbt_sap_server_respond_transferatr(T_MBT_SAP_RESULT_CODE Result, MBT_SHORT Length, MBT_BYTE * pAtr);
extern MBT_VOID mbt_sap_server_connect_respond( T_MBT_BDADDR BDAddr,T_MBT_SAP_CONNECT_STATUS Stat, MBT_SHORT MaxMsgSize,T_MBT_SAP_CARD_STATUS Status);
extern MBT_VOID mbt_sap_server_respondtransferapdu(T_MBT_SAP_RESULT_CODE Result, MBT_SHORT Length,MBT_BYTE * pApdu);
extern MBT_VOID mbt_sap_server_respondpowersimoff(T_MBT_SAP_RESULT_CODE   ResultCode);
extern MBT_VOID mbt_sap_server_respondpowersimon(T_MBT_SAP_RESULT_CODE   Result);
extern MBT_VOID mbt_sap_server_respond_resetsim(T_MBT_SAP_RESULT_CODE   Result);
extern MBT_VOID mbt_sap_server_respond_transfercardreaderstatus(T_MBT_SAP_RESULT_CODE Result, T_MBT_SAP_CARD_READER_STATUS Status);
extern MBT_VOID mbt_sap_server_respond_transportprotocol(T_MBT_SAP_RESULT_CODE   Result);
extern MBT_VOID mbt_sap_server_send_cardstatus(T_MBT_SAP_CARD_STATUS Status);
extern MBT_VOID mbt_sap_server_request_disconnect (T_MBT_SAP_DISCONNECT DisconnType);


#endif//_MBT_SAP_PI_H_
