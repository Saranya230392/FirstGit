#ifndef _MBT_BPP_PI_H_
#define _MBT_BPP_PI_H_
/********************************************************************************
*	File Name	: mbt_bpp.h
*	Description	: 
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.04.12		Kim,Hyunseok			Created
********************************************************************************/
#include "MBTType.h"
#include "mbt_debugmsg.h"

extern MBT_VOID mbt_bpp_enable(MBT_VOID);
extern MBT_VOID mbt_bpp_disable(MBT_VOID);
extern MBT_VOID mbt_bpp_auth_response(T_MBT_OBEX_AUTH *auth_reply);
extern MBT_VOID mbt_bpp_getprinterattribute(T_MBT_BDADDR BdAddr, MBT_INT PrinterAttr);
extern MBT_VOID mbt_bpp_print(T_MBT_BDADDR BdAddr, T_MBT_BPP_OBJECT *MBTObject);
extern MBT_VOID mbt_bpp_disconnect(MBT_VOID);

#endif//_MBT_BPP_PI_H_
