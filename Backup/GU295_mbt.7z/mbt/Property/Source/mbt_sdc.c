#include "mbt_sdc.h"

/********************************************************************************
*	SDC (Static Data Container)
********************************************************************************/
/*------------ GAP ------------*/
#if (MBT_GAP == MBT_TRUE)
static	T_MBT_SEARCHED_DEV_LIST	sdcSearchList;
static	T_MBT_PAIRED_DEV_LIST		sdcPairedList;
static	T_MBT_MYINFO				sdcMyInfo;
static	T_MBT_NAME_RES				sdcNameRes;
static	T_MBT_SVC_RES				sdcSvcRes;
static	T_MBT_PINREPLY				sdcPINReply;
static	T_MBT_AUTHREPLY				sdcAuthReply;
static	T_MBT_SSP					sdcSspInfo;
static	T_MBT_GAP_STATUS			sdcGapStatus;
static	T_MBT_LINK_UPDOWN			sdcLinkUpdown;
static 	T_MBT_PAIR_ERR_RSP    		sdcPairErrReason;
static	T_MBT_BLOCKED_DEV_LIST		sdcBlockedList;
#endif

/*------------ SPP ------------*/
#if (MBT_SPP == MBT_TRUE)
static	T_MBT_SPP_DATA				sdcSPPTxData;
static	T_MBT_SPP_DATA				sdcSPPRxData;
static	T_MBT_SPP_STATUS			sdcSPPStatus;
#endif

/*------------ DUN ------------*/
#if (MBT_DUN == MBT_TRUE)
static	T_MBT_DUN_STATUS			sdcDUNStatus;
#endif

/*------------ AG -------------*/
#if (MBT_AG == MBT_TRUE)
static	T_MBT_AG_DIALINFO			sdcDialInfo;
static	T_MBT_AG_3WAY				sdc3WayType;
static	T_MBT_AG_DTMF				sdcDTMFType;
static	T_MBT_AG_SPKGAIN			sdcSPKGain;
static	T_MBT_AG_STATUS			sdcAGStatus;
static	T_MBT_AG_INDICATION		sdcAGIndication;
static	T_MBT_AG_PB_REC			sdcAGPBRec;
static	T_MBT_AG_PB_CPBS			sdcAGPBRXcpbs;
static	T_MBT_AG_PB_CPBR			sdcAGPBRXcpbr;
static	T_MBT_AG_PB_CPBF			sdcAGPBRXcpbf;
static	T_MBT_AG_PB_CPBW			sdcAGPBRXcpbw;
static	T_MBT_AG_CGM_ID			sdcAGcgm;
static	T_MBT_AG_CSCS				sdcAGcscs;
#endif

/*------------ A2DP-----------*/
#if (MBT_A2DP == MBT_TRUE)
static	T_MBT_A2DP_STATUS			sdcA2DPStatus;
#endif

/*------------ AVRCP----------*/
#if (MBT_AVRCP == MBT_TRUE)
static	T_MBT_AVRCP_STATUS			sdcAVRCPStatus;
#endif

/*------------ OPP ------------*/
#if (MBT_OPP == MBT_TRUE)
static	T_MBT_OPP_STATUS			sdcOPPStatus;
#endif

/*------------ BPP ------------*/
#if (MBT_BPP == MBT_TRUE)
static	T_MBT_BPP_STATUS			sdcBPPStatus;
#endif

/*------------ BIP ------------*/
#if (MBT_BIP == MBT_TRUE)
static	T_MBT_BIP_STATUS			sdcBIPStatus;
#endif

/*------------ FPP ------------*/
#if (MBT_FTP == MBT_TRUE)
static	T_MBT_FTP_STATUS			sdcFTPStatus;
#endif

/*------------ PBAP -----------*/
#if (MBT_PBAP==MBT_TRUE)
static	T_MBT_PBAP_STATUS			sdcPBAPStatus;
#endif

/*------------ HID Host -----------*/
#if (MBT_HID_HOST==MBT_TRUE)
static	T_MBT_HID_HOST_STATUS		sdcHIDHStatus;
#endif

/*------------ HID Device -----------*/
#if (MBT_HID_DEVICE==MBT_TRUE)
static	T_MBT_HID_DEVICE_STATUS	sdcHIDDStatus;
#endif

/*------------ JSR82 ----------*/
#if (MBT_JSR82==MBT_TRUE)
static T_MBT_JSR82_STATUS				sdcJSR82Status;
#endif

/*------------ SAP ----------*/
#if (MBT_SAP==MBT_TRUE)
static T_MBT_SAP_STATUS				sdcSAPStatus;
#endif

/*------------ MISC ----------*/
#if (MBT_MISC == MBT_TRUE)
static	T_MBT_MISC_VERSION			sdcVersion;
#endif


/*------------ OBEX Protocol ----------*/
#if (MBT_OBEX == MBT_TRUE)
static	T_MBT_OBEX_STATUS			sdcOBEXStatus;
#endif

/********************************************************************************
*	Description	: SDC Data Init. This function have to be called at BT On.
********************************************************************************/

MBT_VOID mbt_sdc_initdata(MBT_VOID)
{
	//���� On�Ǵ� ����, Ȥ�� ���� On�ǰ� ó�� BT�� On �Ǵ� ������ ȣ���ؾ��Ѵ�.
	//��� static �����͵��� �ʱ�ȭ�ϰ� NvDB�� ����� ���� �о�鿩�� ä���־�� �Ѵ�.(Setting��, Paired list)
	MBT_SDC("MBT Initialize",0,0,0);
	
	/*------------ GAP -----------*/
	memset(&sdcSearchList, 0x00, sizeof(sdcSearchList));
	memset(&sdcPairedList, 0x00, sizeof(sdcPairedList));

	memset(&sdcMyInfo, 0x00, sizeof(sdcMyInfo));
#ifdef MBT_TESTMODE_NONV
	//Nv�� �������� ���� ��츸 �ӽ� ����� ��!!
	sdcMyInfo.bConnectable  = MBT_TRUE;
	sdcMyInfo.bOnOff        = MBT_FALSE;
	sdcMyInfo.bVisible      = MBT_FALSE;
	strcpy( sdcMyInfo.Name, "AX300-Test");
	sdcMyInfo.BdAddr[0] = 0x00;
	sdcMyInfo.BdAddr[1] = 0x01;
	sdcMyInfo.BdAddr[2] = 0x02;
	sdcMyInfo.BdAddr[3] = 0x33;
	sdcMyInfo.BdAddr[4] = 0x44;
	sdcMyInfo.BdAddr[5] = 0xFA;
#endif
	memset(&sdcNameRes, 0x00, sizeof(sdcNameRes));
	memset(&sdcSvcRes,  0x00, sizeof(sdcSvcRes));
	memset(&sdcPINReply,    0x00, sizeof(sdcPINReply));
	memset(&sdcAuthReply,   0x00, sizeof(sdcAuthReply));
	memset(&sdcSspInfo, 0x00, sizeof(sdcSspInfo));
	memset(&sdcGapStatus, 0x00, sizeof(sdcGapStatus));
	memset(&sdcLinkUpdown, 0x00, sizeof(sdcLinkUpdown));
	memset(&sdcPairErrReason, 0x00, sizeof(sdcPairErrReason));
	memset(&sdcBlockedList, 0x00, sizeof(sdcBlockedList));

	/*------------ AG -----------*/
#if (MBT_AG == MBT_TRUE)		
	memset(&sdcDialInfo, 0x00, sizeof(sdcDialInfo));
	memset(&sdc3WayType, 0x00, sizeof(sdc3WayType));
	memset(&sdcDTMFType, 0x00, sizeof(sdcDTMFType));
	memset(&sdcSPKGain, 0x00, sizeof(sdcSPKGain));
	memset(&sdcAGStatus, 0x00, sizeof(sdcAGStatus));
	memset(&sdcAGIndication, 0x00, sizeof(sdcAGIndication));
	memset(&sdcAGPBRec, 0x00, sizeof(sdcAGPBRec));
	memset(&sdcAGPBRXcpbs, 0x00, sizeof(sdcAGPBRXcpbs));
	memset(&sdcAGPBRXcpbr, 0x00, sizeof(sdcAGPBRXcpbr));
	memset(&sdcAGPBRXcpbf, 0x00, sizeof(sdcAGPBRXcpbf));
	memset(&sdcAGPBRXcpbw, 0x00, sizeof(sdcAGPBRXcpbw));
	memset(&sdcAGcscs, 0x00, sizeof(sdcAGcscs));
#endif

	/*------------ DUN -----------*/
#if (MBT_DUN == MBT_TRUE)
	memset(&sdcDUNStatus, 0x00, sizeof(sdcDUNStatus));
#endif

	/*------------ SPP -----------*/
#if (MBT_SPP == MBT_TRUE)
	memset(&sdcSPPTxData, 0x00, sizeof(sdcSPPTxData));
	memset(&sdcSPPRxData, 0x00, sizeof(sdcSPPRxData));
	memset(&sdcSPPStatus, 0x00, sizeof(sdcSPPStatus));
#endif

	/*------------ A2DP-----------*/
#if (MBT_A2DP == MBT_TRUE)
	memset(&sdcA2DPStatus, 0x00, sizeof(sdcA2DPStatus));
#endif

	/*------------ AVRCP----------*/
#if (MBT_AVRCP == MBT_TRUE)
	memset(&sdcAVRCPStatus, 0x00, sizeof(sdcAVRCPStatus));
#endif

	/*------------ OPP ------------*/
#if (MBT_OPP == MBT_TRUE)
	memset(&sdcOPPStatus, 0x00, sizeof(sdcOPPStatus));
#endif

	/*------------ FPP ------------*/
#if (MBT_FTP == MBT_TRUE)
	memset(&sdcFTPStatus, 0x00, sizeof(sdcFTPStatus));
#endif

	/*------------ BPP ------------*/
#if (MBT_BPP == MBT_TRUE)
	memset(&sdcBPPStatus, 0x00, sizeof(sdcBPPStatus));
#endif

	/*------------ PBAP -----------*/
#if (MBT_PBAP == MBT_TRUE)
	memset(&sdcPBAPStatus, 0x00, sizeof(sdcPBAPStatus));
#endif

	/*------------ JSR82 -----------*/
#if (MBT_JSR82 == MBT_TRUE)
	memset(&sdcJSR82Status, 0x00, sizeof(sdcJSR82Status));
#endif

	/*------------ SAP ----------*/
#if (MBT_SAP==MBT_TRUE)
	memset(&sdcSAPStatus, 0x00, sizeof(sdcSAPStatus));
#endif

	/*------------ MISC -----------*/
#if (MBT_MISC==MBT_TRUE)
	memset(&sdcVersion, 0x00, sizeof(sdcVersion));
#endif

	/*------------ VDP-----------*/
#if (MBT_VDP == MBT_TRUE)
	memset(&sdcVDPStatus, 0x00, sizeof(sdcVDPStatus));
#endif

	/*------------ OBEX Protocol -----------*/
#if (MBT_OBEX == MBT_TRUE)
	memset(&sdcOBEXStatus, 0x00, sizeof(sdcOBEXStatus));
#endif


}

/********************************************************************************
*	Description	:
********************************************************************************/

MBT_VOID* mbt_sdc_getrecord(T_MBT_SDC_RECID MBTSDCRecID)
{
#ifdef MBT_EMULATOR
	unsigned short* T_MBT_SDC_RECID_tostring(T_MBT_SDC_RECID v);
	MBT_SDC("MBT Get Record : %s", T_MBT_SDC_RECID_tostring(MBTSDCRecID) , 0, 0);
#else
	MBT_SDC("MBT Get Record : %d", MBTSDCRecID , 0, 0);
#endif//MBT_EMULATOR
	switch(MBTSDCRecID)
	{
		/*------------ GAP -----------*/
#if (MBT_GAP == MBT_TRUE)
		case	MBTSDC_REC_GAP_SEARCHLIST :	return	&sdcSearchList;
		case	MBTSDC_REC_GAP_PAIREDLIST :
				{
					if(sdcPairedList.bLock == MBT_TRUE)
						MBT_WARN("Paird-list is now in Write-Protect Mode!", 0, 0, 0);

					return	&sdcPairedList;
				}
		case	MBTSDC_REC_GAP_MYINFO :		return	&sdcMyInfo;
		case	MBTSDC_REC_GAP_NAMERES :		return	&sdcNameRes;
		case	MBTSDC_REC_GAP_SVCRES :		return	&sdcSvcRes;
		case	MBTSDC_REC_GAP_PINREPLY :		return	&sdcPINReply;
		case	MBTSDC_REC_GAP_AUTHREPLY :		return	&sdcAuthReply;
		case	MBTSDC_REC_GAP_SSPINFO :		return 	&sdcSspInfo;
		case	MBTSDC_REC_GAP_STATUS :		return 	&sdcGapStatus;
		case	MBTSDC_REC_GAP_LINKINFO :		return	&sdcLinkUpdown;
		case 	MBTSDC_REC_GAP_PAIRERROR :	return	&sdcPairErrReason;
		case	MBTSDC_REC_GAP_BLOCKEDLIST :	return	&sdcBlockedList;
#endif

		/*------------ AG -----------*/
#if (MBT_AG == MBT_TRUE)
		case    MBTSDC_REC_AG_DIALINFO :			return	&sdcDialInfo;
		case    MBTSDC_REC_AG_3WAYCALL_TYPE :	return	&sdc3WayType;
		case    MBTSDC_REC_AG_DTMF_TYPE :		return	&sdcDTMFType;
		case    MBTSDC_REC_AG_SPKGAIN :			return	&sdcSPKGain;
		case    MBTSDC_REC_AG_STATUS_TYPE:		return	&sdcAGStatus;
		case    MBTSDC_REC_AG_INDICATION:		return	&sdcAGIndication;
		case    MBTSDC_REC_AG_TXPBRECORD:		return	&sdcAGPBRec;
		case    MBTSDC_REC_AG_RXCPBS:			return	&sdcAGPBRXcpbs;
		case    MBTSDC_REC_AG_RXCPBR:			return	&sdcAGPBRXcpbr;
		case    MBTSDC_REC_AG_RXCPBF:			return	&sdcAGPBRXcpbf;
		case    MBTSDC_REC_AG_RXCPBW:			return	&sdcAGPBRXcpbw;
		case    MBTSDC_REC_AG_CGM:				return	&sdcAGcgm;
		case    MBTSDC_REC_AG_CSCS:			return 	&sdcAGcscs;
#endif
		/*------------ DUN -----------*/
#if (MBT_DUN == MBT_TRUE)
		case    MBTSDC_REC_DUN_STATUS:			return 	&sdcDUNStatus;
#endif
		/*------------ SPP -----------*/
#if (MBT_SPP == MBT_TRUE)
		case    MBTSDC_REC_SPP_TXDATA:			return 	&sdcSPPTxData;
		case    MBTSDC_REC_SPP_RXDATA:			return 	&sdcSPPRxData;
		case    MBTSDC_REC_SPP_STATUS:			return 	&sdcSPPStatus;
#endif
		/*------------ FTP -----------*/
#if (MBT_FTP == MBT_TRUE)
		case	MBTSDC_REC_FTP_STATUS:			return	&sdcFTPStatus;
#endif
		
		/*------------ OPP -----------*/
#if (MBT_OPP == MBT_TRUE)
		case	MBTSDC_REC_OPP_STATUS:		return	&sdcOPPStatus;
#endif

		/*------------ BPP -----------*/
#if (MBT_BPP == MBT_TRUE)
		case	MBTSDC_REC_BPP_STATUS:		return	&sdcBPPStatus;
#endif

		/*------------ BIP -----------*/
#if (MBT_BIP == MBT_TRUE)
		case	MBTSDC_REC_BIP_STATUS:			return	&sdcBIPStatus;
#endif

		/*------------ A2DP -----------*/
#if (MBT_A2DP == MBT_TRUE)
		case	MBTSDC_REC_A2DP_STATUS:		return	&sdcA2DPStatus;
#endif
		/*------------ AVRCP -----------*/
#if (MBT_AVRCP == MBT_TRUE)
		case	MBTSDC_REC_AVRCP_STATUS:		return	&sdcAVRCPStatus;
#endif

		/*------------ PBAP -----------*/
#if (MBT_PBAP == MBT_TRUE)
		case	MBTSDC_REC_PBAP_STATUS:		return	&sdcPBAPStatus;
#endif

		/*------------ HID Host -----------*/
#if (MBT_HID_HOST == MBT_TRUE)
		case	MBTSDC_REC_HID_HOST_STATUS:	return	&sdcHIDHStatus;
#endif

		/*------------ HID Device -----------*/
#if (MBT_HID_DEVICE == MBT_TRUE)
		case	MBTSDC_REC_HID_DEVICE_STATUS:   return	&sdcHIDDStatus;
#endif

		/*------------ JSR82 -----------*/
#if (MBT_JSR82 == MBT_TRUE)
		case	MBTSDC_REC_JSR82_STATUS:		return	&sdcJSR82Status;
#endif
		/*------------ SAP ----------*/
#if (MBT_SAP==MBT_TRUE)
		case	MBTSDC_REC_SAP_STATUS:		return	&sdcSAPStatus;
#endif

		/*------------ MISC -----------*/
#if (MBT_MISC == MBT_TRUE)
		case	MBTSDC_REC_MISC_VERSION:		return	&sdcVersion;
#endif

		/*------------ VDP -----------*/
#if (MBT_VDP == MBT_TRUE)
		case	MBTSDC_REC_VDP_STATUS:		return	&sdcVDPStatus;
#endif

		/*------------ OBEX Protocol -----------*/
#if (MBT_OBEX == MBT_TRUE)
		case	MBTSDC_REC_OBEX_STATUS:		return	&sdcOBEXStatus;
#endif

		default :
		{
			//////////////////////////////////////////////////////
			// !!! CAUTION !!!
			// Record ID error occurred.
			// DO NOT RETURN ANY MEMORY ADDRES!
			//////////////////////////////////////////////////////
			MBT_ERR("!!!!!!!!!!!MBT Record Access Error!!!!!!!!!!!!!!!",0,0,0);
			return MBT_NULL;
		}
		break;
			return MBT_NULL;
	}

}

/********************************************************************************
*	Description	:
********************************************************************************/
MBT_INT mbt_sdc_getvalue(T_MBT_SDC_VALID MBTSDCValID)
{
	MBT_BOOL transfering = MBT_FALSE;
	switch(MBTSDCValID)
	{
#if (MBT_GAP == MBT_TRUE)
		case MBTSDC_VAL_GAP_ONOFF :				// Bluetooth On/Off ����
			MBT_SDC("SDC GetVal - GAP BT On/Off : %d", sdcMyInfo.bOnOff , 0, 0);
			return (MBT_INT)sdcMyInfo.bOnOff;
		case MBTSDC_VAL_GAP_VISIBLE :				// Visibility ����
			MBT_SDC("SDC GetVal - GAP Visibale : %d", sdcMyInfo.bVisible , 0, 0);
			return (MBT_INT)sdcMyInfo.bVisible;
		case MBTSDC_VAL_GAP_CONNECTABLE :			// Connectable ����
			MBT_SDC("SDC GetVal - GAP Connectable : %d", sdcMyInfo.bConnectable , 0, 0);
			return (MBT_INT)sdcMyInfo.bConnectable;
		case MBTSDC_VAL_GAP_STATUS :				//GAP Status
			MBT_SDC("SDC GetVal - GAP Status : %d", sdcGapStatus, 0, 0);
			return (MBT_INT)sdcGapStatus;
#endif

#if (MBT_AG == MBT_TRUE)
		case MBTSDC_VAL_AG_DEVCON :					// AG ���� ����
			//MBT_SDC("SDC GetVal - AG Connection : %d", returnVal , 0, 0);  //�ʹ� ���� �޽����� ���´�.
			return (MBT_INT)sdcAGStatus.bConection;
		case MBTSDC_VAL_AG_SCOOPEN :				// SCO Open ����
			MBT_SDC("SDC GetVal - SCO Connection : %d", sdcAGStatus.bAudioPath , 0, 0);
			return (MBT_INT)sdcAGStatus.bAudioPath;
		case MBTSDC_VAL_AG_ENABLE:
      			MBT_SDC("SDC GetVal - AG Enabled : %x", sdcAGStatus.bEnalbed, 0, 0);
      			return (MBT_INT)sdcAGStatus.bEnalbed;
        case MBTSDC_VAL_AG_SPKGAIN:
            MBT_SDC("SDC GetVal - AG sdcSPKGain : %x", sdcSPKGain.VolumeLevel, 0, 0);
            return sdcSPKGain.VolumeLevel;
		case MBTSDC_VAL_AG_VR_SUPPORT:
			MBT_SDC("SDC GetVal -HS Support BVRA : %x", sdcAGStatus.bSupportBVRA, 0, 0);
			return (MBT_INT)sdcAGStatus.bSupportBVRA;	
		case MBTSDC_VAL_AG_VOLUME_CTRL_SUPPORT:
			MBT_SDC("SDC GetVal - HS Support VolemeCtrl : %x", sdcAGStatus.bSupportRemoteVolCtrl, 0, 0);
			return (MBT_INT) sdcAGStatus.bSupportRemoteVolCtrl;
#endif
#if (MBT_A2DP == MBT_TRUE)
		case MBTSDC_VAL_A2DP_SOURCE_ENABLE: //A2DP�� Enable����(BOOL)
			MBT_SDC("SDC GetVal - A2DP Enable state : %x", sdcA2DPStatus.bEnabled, 0, 0);
			return (MBT_INT)sdcA2DPStatus.bEnabled;
		case MBTSDC_VAL_A2DP_DEVCON:
			MBT_SDC("SDC GetVal - A2DP Connectioin number : %d", sdcA2DPStatus.ConNum, 0, 0);
			return (MBT_INT)sdcA2DPStatus.ConNum;
		case MBTSDC_VAL_A2DP_PLAY:
		{
			MBT_BYTE idx;
			for(idx = 0; idx < MBT_A2DP_MAX_CONN_NUM; idx++)
			{
				if( (sdcA2DPStatus.A2dpConn[idx].ConStatus == MBT_A2DP_CONSTATUS_PLAY)
				|| (sdcA2DPStatus.A2dpConn[idx].ConStatus == MBT_A2DP_CONSTATUS_PAUSED))
					return MBT_TRUE;
			}
			return MBT_FALSE;
		}
#endif

#if (MBT_AVRCP == MBT_TRUE)
        	case MBTSDC_VAL_AVRCP_ENABLE:       //AVRCP�� Enable����(BOOL)
            		MBT_SDC("SDC GetVal - AVRCP Enable state : %x", sdcAVRCPStatus.bEnabled, 0, 0);
            		return (MBT_INT)sdcAVRCPStatus.bEnabled;
#endif

#if (MBT_PBAP == MBT_TRUE)
		case MBTSDC_VAL_PBAP_ENABLE:
			MBT_SDC("SDC GetVal - PBAP Enable state : %x", sdcPBAPStatus.bEnabled, 0, 0);
			return (MBT_INT)sdcPBAPStatus.bEnabled;
#endif

#if (MBT_HID_HOST == MBT_TRUE)
		case MBTSDC_VAL_HID_HOST_ENABLE:
			MBT_SDC("SDC GetVal - HID Host Enable state : %x", sdcHIDHStatus.bEnabled, 0, 0);
			return (MBT_INT)sdcHIDHStatus.bEnabled;
#endif
#if (MBT_HID_DEVICE == MBT_TRUE)
		case MBTSDC_VAL_HID_DEVICE_ENABLE:
			MBT_SDC("SDC GetVal - HID Device Enable state : %x", sdcHIDDStatus.bEnabled, 0, 0);
			return (MBT_INT)sdcHIDDStatus.bEnabled;
#endif

#if (MBT_JSR82 == MBT_TRUE)
        case MBTSDC_VAL_JSR82_ENABLE:
            MBT_SDC("SDC GetVal - JSR82 Enable state : %x", sdcJSR82Status.bEnabled, 0, 0);
            return (MBT_INT)sdcJSR82Status.bEnabled;
#endif

		case MBTSDC_VAL_DEV_CONN:
#if (MBT_AG == MBT_TRUE)
			if(sdcAGStatus.bConection)
				transfering = MBT_TRUE;
#endif
#if (MBT_A2DP == MBT_TRUE)
			//if(sdcA2DPStatus.ConNum)
			//	transfering = MBT_TRUE;

			if( (sdcA2DPStatus.A2dpConn[0].ConStatus == MBT_A2DP_CONSTATUS_PLAY)
				|| (sdcA2DPStatus.A2dpConn[0].ConStatus == MBT_A2DP_CONSTATUS_STARTING)
				|| (sdcA2DPStatus.A2dpConn[0].ConStatus == MBT_A2DP_CONSTATUS_PAUSED)
				)
				transfering = MBT_TRUE;
#endif
		case MBTSDC_VAL_FILE_TRANS_STATUS :	//���� ���� ����
		{
			
#if (MBT_OPP == MBT_TRUE)
			switch(sdcOPPStatus.OppState)
			{
				case MBT_OPP_STATE_RECEIVING:
				case MBT_OPP_STATE_SENDING:
				case MBT_OPP_STATE_PULLING:
				case MBT_OPP_STATE_CONNECTED:
					transfering = MBT_TRUE;
					break;
				default:
					break;
			}
#endif

#if (MBT_FTP == MBT_TRUE)
			switch(sdcFTPStatus.FtpState)
			{
				case MBT_FTP_STATE_SENDING:
				case MBT_FTP_STATE_RECEIVING:
				case MBT_FTP_STATE_CONNECTED:
					transfering = MBT_TRUE;
					break;
				default:
					break;
			}
#endif

#if (MBT_DUN == MBT_TRUE)
			switch(sdcDUNStatus.State)
			{
				case MBT_DUN_CONNECTED:
					transfering = MBT_TRUE;
					break;
				default:
					break;
			}
#endif

#if (MBT_SPP == MBT_TRUE)
			switch(sdcSPPStatus.bConection)
			{
				case MBT_TRUE:
					transfering = MBT_TRUE;
					break;
				default:
					break;
			}
#endif

#if (MBT_BPP == MBT_TRUE)
			switch(sdcBPPStatus.State)
			{
				case MBT_BPP_STATE_CONNECTED:
				case MBT_BPP_STATE_PRINTING:
					transfering = MBT_TRUE;
					break;
				default:
					break;
			}
#endif

#if (MBT_JSR82 == MBT_TRUE)
			if(sdcJSR82Status.bEnabled)
				transfering = MBT_TRUE;
#endif

			return transfering;
		}
#if (MBT_DUN == MBT_TRUE)
		case MBT_SDC_VAL_DUN_ENABLE:
			return sdcDUNStatus.bEnabled;
			break;
#endif
#if (MBT_SPP == MBT_TRUE)
		case MBT_SDC_VAL_SPP_ENABLE:
			return sdcSPPStatus.bEnabled;
			break;
#endif
#if (MBT_OPP == MBT_TRUE)
		case MBT_SDC_VAL_OPP_SERVER_ENABLE:
			return sdcOPPStatus.bServerEnabled;
			break;
#endif
#if (MBT_FTP == MBT_TRUE)
		case MBT_SDC_VAL_FTP_SERVER_ENABLE:
			return sdcFTPStatus.bServerEnabled;
			break;
#endif

#if (MBT_SAP == MBT_TRUE)
		case MBTSDC_VAL_SAP_SERVER_ENABLE:
			return sdcSAPStatus.bServerEnabled;
#endif
#if (MBT_VDP == MBT_TRUE)
		case MBTSDC_VAL_VDP_SOURCE_ENABLE: //VDP�� Enable����(BOOL)
			if(sdcVDPStatus.VdpRole == MBT_VDP_ROLE_SRC)
			{
				MBT_SDC("SDC GetVal - VDP Source Enable state : %x", sdcVDPStatus.bEnabled, 0, 0);
				return (MBT_INT)sdcVDPStatus.bEnabled;
			}
			else
			{
				MBT_SDC("SDC GetVal - VDP Source Enable state : %x", MBT_FALSE, 0, 0);
				return MBT_FALSE;
			}
		case MBTSDC_VAL_VDP_SINK_ENABLE:
			if(sdcVDPStatus.VdpRole == MBT_VDP_ROLE_SNK)
			{
				MBT_SDC("SDC GetVal - VDP Sink Enable state : %x", sdcVDPStatus.bEnabled, 0, 0);
				return (MBT_INT)sdcVDPStatus.bEnabled;
			}
			else
			{
				MBT_SDC("SDC GetVal - VDP Sink Enable state : %x", MBT_FALSE, 0, 0);
				return MBT_FALSE;
			}
		case MBTSDC_VAL_VDP_DEVCON:
			MBT_SDC("SDC GetVal - VDP Connectioin number : %d", sdcVDPStatus.ConNum, 0, 0);
			return (MBT_INT)sdcVDPStatus.ConNum;
		case MBTSDC_VAL_VDP_PLAY:
		{
			MBT_BYTE idx;
			for(idx = 0; idx < MBT_VDP_MAX_CONN_NUM; idx++)
			{
				if( (sdcVDPStatus.VdpConn[idx].ConStatus == MBT_VDP_CONSTATUS_PLAY)
				|| (sdcVDPStatus.VdpConn[idx].ConStatus == MBT_VDP_CONSTATUS_PAUSED))
					return MBT_TRUE;
			}
			return MBT_FALSE;
		}
#endif
		default :
		{
			//////////////////////////////////////////////////////
			// !!! CAUTION !!!
			// Value ID error occurred.
			// return MBT_FALSE
			//////////////////////////////////////////////////////
			MBT_ERR("!!!!!!!!!!!MBT Value Access Error!!!!!!!!!!!!!!!",0,0,0);
			return MBT_FALSE;
		}
	}
}
