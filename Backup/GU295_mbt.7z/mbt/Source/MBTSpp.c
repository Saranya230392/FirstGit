#include "MBTSpp.h"
#include "mbt_spp.h"
#include "mbt_debugmsg.h"

MBT_VOID MBT_SPP_Enable (MBT_VOID)
{
	MBT_API("### MBT_SPP_Enable ###");
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_enable();
#endif
}

MBT_VOID MBT_SPP_Listen (MBT_VOID)
{
	MBT_API("### MBT_SPP_Listen ###");
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_listen();
#endif
}

MBT_VOID MBT_SPP_ListenStop(MBT_VOID)
{
	MBT_API("MBT_SPP_ListenStop");
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_listenstop();
#endif
}

MBT_VOID MBT_SPP_Disable (MBT_VOID)
{
	MBT_API("### MBT_SPP_Disable ###");
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_disable();
#endif
}

MBT_VOID MBT_SPP_Connect(T_MBT_BDADDR BdAddr)
{
	MBT_API("### MBT_SPP_Connect ###");
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_connect(BdAddr);
#endif
}

MBT_VOID MBT_SPP_Disconnect(T_MBT_BDADDR BdAddr)
{	
	MBT_API("### MBT_SPP_Disconnect ###");
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_disconnect(BdAddr);
#endif
}

MBT_VOID MBT_SPP_SendData(T_MBT_SPP_DATA *txData)
{
	MBT_API("### MBT_SPP_SendData ###");
#if (MBT_SPP == MBT_TRUE)
	mbt_spp_senddata(txData);
#endif
}
