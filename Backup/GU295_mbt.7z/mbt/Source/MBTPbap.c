#include "MBTPbap.h"
#include "mbt_pbap.h"

MBT_VOID MBT_PBAP_ServerEnable (MBT_VOID)
{
	MBT_API("MBT_PBAP_ServerEnable");
#if (MBT_PBAP == MBT_TRUE)
	mbt_pbap_server_enable();
#endif
}

MBT_VOID MBT_PBAP_ServerDisable (MBT_VOID)
{
	MBT_API("MBT_PBAP_ServerDisable");
#if (MBT_PBAP == MBT_TRUE)
	mbt_pbap_server_disable();
#endif
}

MBT_VOID MBT_PBAP_ServerAccessResponse(MBT_BOOL b_allow)
{
	MBT_API("MBT_PBAP_ServerAccessResponse");
#if (MBT_PBAP == MBT_TRUE)
	mbt_pbap_server_accessresponse(b_allow);
#endif
}
MBT_VOID MBT_PBAP_ServerAuthenticate(MBT_CHAR *p_password, MBT_CHAR *p_userid)
{
	MBT_API("MBT_PBAP_ServerAuthenticate");
#if (MBT_PBAP == MBT_TRUE)
	mbt_pbap_server_authenticate(p_password, p_userid);
#endif
}

MBT_VOID MBT_PBAP_ServerClose(MBT_VOID)
{
	MBT_API("MBT_PBAP_ServerClose");
#if (MBT_PBAP == MBT_TRUE)
	mbt_pbap_server_close();
#endif
}

MBT_VOID MBT_PBAP_ServerWriteData(T_MBT_PBAP_OP Operation)
{
	MBT_API("MBT_PBAP_ServerWriteData");
#if (MBT_PBAP == MBT_TRUE)
	mbt_pbap_server_writedata(Operation);
#endif
}
