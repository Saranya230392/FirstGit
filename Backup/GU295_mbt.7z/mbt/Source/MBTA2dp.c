#include "MBTA2dp.h"
#include "mbt_a2dp.h"
#include "mbt_sdc.h"

MBT_VOID MBT_A2DP_SourceEnable(MBT_VOID)
{
	MBT_API("MBT_A2DP_SourceEnable");
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_enable();
#endif
}

MBT_VOID MBT_A2DP_SourceDisable(MBT_VOID)
{
	MBT_API("MBT_A2DP_SourceDisable");
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_disable();
#endif
}

MBT_VOID MBT_A2DP_SourceConnect(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_A2DP_SourceConnect");
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_connect(BdAddr);
#endif
}

MBT_VOID MBT_A2DP_SourceDisconnect (T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_A2DP_SourceDisconnect");
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_disconnect(BdAddr);
#endif
}

MBT_VOID MBT_A2DP_SourceStart(MBT_VOID)
{
	MBT_API("MBT_A2DP_SourceStart");
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_start();
#endif
}

MBT_VOID MBT_A2DP_SourceStop(MBT_VOID)
{
	MBT_API("MBT_A2DP_SourceStop");
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_stop();
#endif
}

MBT_VOID MBT_A2DP_SourcePause(MBT_VOID)
{
	MBT_API("MBT_A2DP_Pause");
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_pause();
#endif
}

MBT_VOID MBT_A2DP_SourceResume(MBT_VOID)
{
	MBT_API("MBT_A2DP_SourceResume");
#if (MBT_A2DP == MBT_TRUE)
	mbt_a2dp_source_resume();
#endif
}

