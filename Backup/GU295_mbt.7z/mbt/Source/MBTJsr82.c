#include "MBTJsr82.h"
#include "mbt_jsr82.h"


MBT_VOID MBT_JSR82_LDEnable(MBT_VOID)
{ 
	MBT_API("MBT_JSR82_LDEnable");
#if (MBT_JSR82 == MBT_TRUE)
	mbt_jsr82_enable();
#endif
}

MBT_VOID MBT_JSR82_LDDisable(MBT_VOID)
{
	MBT_API("MBT_JSR82_LDDisable");
#if (MBT_JSR82 == MBT_TRUE)
	mbt_jsr82_disable();
#endif
}

MBT_UINT MBT_JSR82_LDGetDiscoverable(MBT_VOID)
{ 
	MBT_API("MBT_JSR82_LDGetDiscoverable");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_get_discoverable();
#endif
}

MBT_BOOL MBT_JSR82_LDSetDiscoverable(MBT_UINT Mode)
{ 
	MBT_API("MBT_JSR82_LDSetDiscoverable");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_set_discoverable(Mode);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_LDSetSecurity(MBT_UINT Handle, T_MBT_JSR82_SET_SECURITY* Security)
{ 
	MBT_API("MBT_JSR82_LDSetSecurity");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_set_security(Handle,Security);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_LDGetMyCoD(MBT_VOID)
{ 
	MBT_API("MBT_JSR82_LDGetMyCoD");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_get_myCoD();
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_LDSetMyCoD(MBT_SHORT ServiceCalss, MBT_BYTE MajorClass, MBT_BYTE MinorClass)
{ 
	MBT_API("MBT_JSR82_LDSetMyCoD");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_set_myCoD(ServiceCalss, MajorClass, MinorClass);
#else
	return MBT_FALSE;
#endif
}

T_MBT_GAP_SECURITY MBT_JSR82_RDGetEncrypted(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_API("MBT_JSR82_RDGetEncrypted");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_get_encrypted(RemoteBDAddr);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_RDSetEncrypted(T_MBT_BDADDR RemoteBDAddr,T_MBT_GAP_SECURITY Security)
{ 
	MBT_API("MBT_JSR82_RDSetEncrypted");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_set_encrypted(RemoteBDAddr, Security);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_RDGetAuthenticated(T_MBT_BDADDR RemoteBDAddr)
{ 
	MBT_API("MBT_JSR82_RDGetAuthenticated");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_get_authenticated(RemoteBDAddr);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_RDPairReq(MBT_UINT Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq, MBT_BYTE PinLength)
{ 
	MBT_API("MBT_JSR82_RDPairReq");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_pair_req(Handle,RemoteBDAddr, PinReq, PinLength);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_RDPairRes(MBT_UINT Handle,MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_BYTE PinLength)
{ 
	MBT_API("MBT_JSR82_RDPairRes");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_pair_res(Handle,bAccept, PinRes, PinLength);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_RDNameReq(MBT_UINT Handle,T_MBT_BDADDR RemoteBDAddr)
{ 
	MBT_API("MBT_JSR82_RDNameReq");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_name_req(Handle,RemoteBDAddr);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_DevDiscovery(MBT_UINT Handle,MBT_UINT AccessMode)
{ 
	MBT_API("MBT_JSR82_DevDiscovery");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_dev_discovery(Handle,AccessMode);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_DevDiscoveryCancel(MBT_UINT Handle)
{ 
	MBT_API("MBT_JSR82_DevDiscoveryCancel");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_dev_discovery_cancel(Handle);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_PopulateRecord(MBT_UINT SvcHandle,T_MBT_BDADDR RemoteBDAddr,MBT_UINT *Attr,MBT_UINT AttrLength)
{ 
     MBT_API("MBT_JSR82_PopulateRecord");
#if (MBT_JSR82 == MBT_TRUE)
     return mbt_jsr82_populate_record(SvcHandle,RemoteBDAddr,Attr,AttrLength);
#else     
     return MBT_FALSE;
#endif
	
} 

MBT_BOOL MBT_JSR82_ReadRecord(MBT_UINT SvcHandle, MBT_BYTE* Data, MBT_UINT* DataLength)
{ 
    MBT_API("MBT_JSR82_ReadRecord");
#if (MBT_JSR82 == MBT_TRUE)
    return mbt_jsr82_read_record(SvcHandle, Data, DataLength);
#else
    return MBT_FALSE;
#endif
	
}

MBT_BOOL MBT_JSR82_LDIsConnected(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_API("MBT_JSR82_LDIsConnected");
	
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_is_connected(RemoteBDAddr);
#else
	return MBT_FALSE;
#endif

}

MBT_BOOL MBT_JSR82_SvcDiscovery(T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_SEARCH_SD* SearchInfo, MBT_UINT TransID)
{ 
	MBT_API("MBT_JSR82_SvcDiscovery");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_svc_discovery(RemoteBDAddr, SearchInfo, TransID);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_SvcDiscoveryCancel(MBT_UINT TransID)
{ 
	MBT_API("MBT_JSR82_SvcDiscoveryCancel");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_svc_discovery_cancel(TransID);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_GetServiceResult(MBT_UINT TransID, MBT_INT ReadNum)
{ 
	MBT_API("MBT_JSR82_GetServiceResult");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_get_service_result(TransID, ReadNum);
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_JSR82_CreateRecord(MBT_UINT Handle,T_MBT_JSR82_SD_RECORD* CreateInfo)
{ 
	MBT_API("MBT_JSR82_CreateRecord");
#if (MBT_JSR82 == MBT_TRUE)
	mbt_jsr82_create_record(Handle,CreateInfo);
#endif
}


MBT_INT MBT_JSR82_UpdateRecord(MBT_UINT SvcHandle, T_MBT_JSR82_SD_RECORD* UpdateInfo)
{ 
	MBT_API("MBT_JSR82_UpdateRecord");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_update_record(SvcHandle,UpdateInfo);
#else
	return MBT_FALSE;
#endif
}


MBT_VOID MBT_JSR82_RemoveRecord(MBT_UINT SvcHandle)
{
	MBT_API("MBT_JSR82_RemoveRecord");
#if (MBT_JSR82 == MBT_TRUE)
	mbt_jsr82_remove_record(SvcHandle);
#endif
}


MBT_VOID MBT_JSR82_DeleteAttribute(MBT_UINT SvcHandle, MBT_SHORT AttrID)
{
	MBT_API("MBT_JSR82_DeleteAttribute");
#if (MBT_JSR82 == MBT_TRUE)
	mbt_jsr82_delete_attribute(SvcHandle, AttrID);
#endif
}

MBT_INT MBT_JSR82_L2CAPOpenServer(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Confg)
{ 
	MBT_API("MBT_JSR82_L2CAPOpenServer");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_open_server(Handle, Confg);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_L2CAPCloseServer(MBT_BYTE Handle)
{ 
	MBT_API("MBT_JSR82_L2CAPCloseServer");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_close_server(Handle);
#else
	return MBT_FALSE;
#endif
}

MBT_INT  MBT_JSR82_L2CAPGetServiceHandle(MBT_VOID)
{ 
	MBT_API("MBT_JSR82_L2CAPGetServiceHandle");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_get_svc_handle();
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_L2CAPAccept(MBT_BYTE Handle, MBT_BYTE PeerHandle)
{ 
	MBT_API("MBT_JSR82_L2CAPAccept");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_accept(Handle, PeerHandle);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_L2CAPOpenClient(MBT_BYTE Handle)
{ 
	MBT_API("MBT_JSR82_L2CAPOpenClient");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_open_client(Handle);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_L2CAPSetParam(MBT_BYTE Handle, T_MBT_JSR82_L2CAP_CONFIG_INFO* Config)
{ 
	MBT_API("MBT_JSR82_L2CAPSetParam");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_set_param(Handle, Config);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_L2CAPConnect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, MBT_INT PSM)
{ 
	MBT_API("MBT_JSR82_L2CAPConnect");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_connect(Handle, RemoteBDAddr, PSM);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_L2CAPDisconnect(MBT_BYTE Handle)
{ 
	MBT_API("MBT_JSR82_L2CAPDisconnect");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_disconnect(Handle);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_L2CAPWrite(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
{
	MBT_API("MBT_JSR82_L2CAPSend");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_write(Handle, Buffer,Length);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_L2CAPRead(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
{ 
	MBT_API("MBT_JSR82_L2CAPReceive");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_read(Handle, Buffer,Length);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_L2CAPGetReady(MBT_BYTE Handle, MBT_UINT* Length)
{ 
	MBT_API("MBT_JSR82_L2CAPGetReady");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_l2cap_get_ready(Handle,Length);
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_JSR82_L2CAPRelease(MBT_VOID)
{ 
	MBT_API("MBT_JSR82_L2CAPRelease");
#if (MBT_JSR82 == MBT_TRUE)
	mbt_jsr82_l2cap_release();
#endif
}

MBT_INT MBT_JSR82_RFCOMMOpenServer(MBT_BYTE Handle, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config)
{ 
	MBT_API("MBT_JSR82_RFCOMMOpenServer");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_open_server(Handle, Config);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_RFCOMMCloseServer(MBT_BYTE Handle)
{ 
	MBT_API("MBT_JSR82_RFCOMMCloseServer");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_close_server(Handle);
#else
	return MBT_FALSE;
#endif
}

MBT_INT  MBT_JSR82_RFCOMMGetServiceHandle(MBT_VOID)
{ 
	MBT_API("MBT_JSR82_RFCOMMGetServiceHandle");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_get_svc_handle();
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_RFCOMMAccept(MBT_BYTE Handle, MBT_BYTE PeerHandle)
{
	MBT_API("MBT_JSR82_RFCOMMAccept");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_accept(Handle, PeerHandle);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_RFCOMMOpenClient(MBT_BYTE Handle)
{ 
	MBT_API("MBT_JSR82_RFCOMMOpenClient");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_open_client(Handle);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_RFCOMMConnect(MBT_BYTE Handle,T_MBT_BDADDR RemoteBDAddr, T_MBT_JSR82_RFCOMM_CONFIG_INFO* Config)
{ 
	MBT_API("MBT_JSR82_RFCOMMConnect");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_connect(Handle, RemoteBDAddr, Config);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_RFCOMMDisconnect(MBT_BYTE Handle)
{ 
	MBT_API("MBT_JSR82_RFCOMMDisconnect");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_disconnect(Handle);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_RFCOMMWrite(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
{ 
	MBT_API("MBT_JSR82_RFCOMMWrite");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_write(Handle, Buffer,Length);
#else
	return MBT_FALSE;
#endif
}

MBT_INT MBT_JSR82_RFCOMMRead(MBT_BYTE Handle, MBT_CHAR* Buffer, MBT_UINT Length)
{ 
	MBT_API("MBT_JSR82_RFCOMMRead");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_read(Handle, Buffer,Length);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_JSR82_RFCOMMGetReady(MBT_BYTE Handle, MBT_UINT* Length)
{ 
	MBT_API("MBT_JSR82_RFCOMMGetReady");
#if (MBT_JSR82 == MBT_TRUE)
	return mbt_jsr82_rfcomm_get_ready(Handle, Length);
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_JSR82_RFCOMMRelease(MBT_VOID)
{ 
	MBT_API("MBT_JSR82_RFCOMMRelease");
#if (MBT_JSR82 == MBT_TRUE)
	mbt_jsr82_rfcomm_release();
#endif
}
