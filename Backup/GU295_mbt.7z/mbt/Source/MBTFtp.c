#include "MBTFtp.h"
#include "mbt_ftp.h"

MBT_VOID MBT_FTP_ServerEnable (MBT_VOID)
{
	MBT_API("MBT_FTP_ServerEnable");
#if (MBT_FTP == MBT_TRUE)
 	mbt_ftp_server_enable();
#endif
}

MBT_VOID MBT_FTP_ServerDisable (MBT_VOID)
{
	MBT_API("MBT_FTP_ServerDisable");
#if (MBT_FTP == MBT_TRUE)
 	mbt_ftp_server_disable();
#endif
}

MBT_VOID MBT_FTP_ServerAccessRsp(T_MBT_AUTHRES Reply)
{
	MBT_API("MBT_FTP_ServerAccessRsp");
#if (MBT_FTP == MBT_TRUE)
 	mbt_ftp_server_access_response(Reply);
#endif
}

MBT_VOID MBT_FTP_ServerAuthRsp(T_MBT_OBEX_AUTH *auth_reply)
{
	MBT_API("MBT_FTP_ServerAuthRsp");
#if (MBT_FTP == MBT_TRUE)
 	mbt_ftp_server_auth_response(auth_reply);
#endif
}

MBT_BOOL MBT_FTP_ServerSetRootFolder(MBT_CHAR *RootFolder)
{
	MBT_API("MBT_FTP_ServerSetRootFolder");
#if (MBT_FTP == MBT_TRUE)
 	return mbt_ftp_server_setrootfolder(RootFolder);
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_FTP_ClientEnable (MBT_VOID)
{
	MBT_API("MBT_FTP_ClientEnable");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_enable();
#endif
}

MBT_VOID MBT_FTP_ClientDisable (MBT_VOID)
{
	MBT_API("MBT_FTP_ClientDisable");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_disable();
#endif
}

MBT_VOID MBT_FTP_ClientConnect(T_MBT_BDADDR remoteDev)
{
	MBT_API("MBT_FTP_ClientConnect");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_open(remoteDev);
#endif
}

MBT_VOID MBT_FTP_ClientDisconnect(MBT_VOID)
{
	MBT_API("MBT_FTP_ClientDisconnect");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_close();
#endif
}

MBT_VOID MBT_FTP_ClientAuthRsp(T_MBT_OBEX_AUTH *auth_reply)
{
	MBT_API("MBT_FTP_ClientAuthRsp");
#if (MBT_FTP == MBT_TRUE)
 	mbt_ftp_client_auth_response(auth_reply);
#endif
}

MBT_VOID MBT_FTP_ClientPutFile(T_MBT_FTP_OBJECT * MBTObject)
{
	MBT_API("MBT_FTP_ClientPutFile");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_putfile(MBTObject);
#endif
}

MBT_VOID MBT_FTP_ClientGetFile(T_MBT_FTP_OBJECT * MBTObject)
{
	MBT_API("MBT_FTP_ClientGetFile");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_getfile(MBTObject);
#endif
}

MBT_VOID MBT_FTP_ClientChDir(T_MBT_FTP_OBJECT * MBTObject)
{
	MBT_API("MBT_FTP_ClientChDir");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_chdir(MBTObject);
#endif
}

MBT_VOID MBT_FTP_ClientMkDir(T_MBT_FTP_OBJECT * MBTObject)
{
	MBT_API("MBT_FTP_ClientMkDir");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_mkdir(MBTObject);
#endif
}

MBT_VOID MBT_FTP_ClientListDir(T_MBT_FTP_OBJECT * MBTObject)
{
	MBT_API("MBT_FTP_ClientListDir");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_listdir(MBTObject);
#endif
}

MBT_VOID MBT_FTP_ClientDelDir(T_MBT_FTP_OBJECT * MBTObject)
{
	MBT_API("MBT_FTP_ClientDelDir");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_deldir(MBTObject);
#endif
}

MBT_VOID MBT_FTP_ClientDelFile(T_MBT_FTP_OBJECT * MBTObject)
{
	MBT_API("MBT_FTP_ClientDelFile");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_delfile(MBTObject);
#endif
}

MBT_VOID MBT_FTP_ClientAbort(MBT_VOID)
{
	MBT_API("MBT_FTP_ClientAbort");
#if (MBT_FTP == MBT_TRUE)
	mbt_ftp_client_abort();
#endif
}
