#include "MBTObex.h"
#include "mbt_obex.h"

MBT_VOID MBT_OBEX_ServerEnable(T_MBT_OBEX_SERVICE_INFO* SvcInfo, MBT_BYTE* target, MBT_BOOL Authc, T_MBT_OBEX_CHARSET realm_charset, MBT_CHAR* realm, MBT_BYTE realm_len)
{
	MBT_API("MBT_OBEX_ServerEnable");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_serverenable(SvcInfo, target, Authc, realm_charset, realm, realm_len);
#endif
}

MBT_VOID MBT_OBEX_ServerDisable(MBT_UINT ServerHandle)
{
	MBT_API("MBT_OBEX_ServerDisable");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_serverdisable(ServerHandle);
#endif
}

MBT_VOID MBT_OBEX_ServerConnectRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE connect_res)
{
	MBT_API("MBT_OBEX_ServerConnectRes");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_serverconnectres(ServerHandle, connect_res);
#endif
}
MBT_VOID MBT_OBEX_ServerDisconnectRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE disconnect_res)
{
	MBT_API("MBT_OBEX_ServerDisconnectRes");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_serverdisconnectres(ServerHandle, disconnect_res);
#endif
}

MBT_VOID MBT_OBEX_ServerAuthenticateRes(MBT_UINT ServerHandle, MBT_CHAR* PassWD, MBT_BYTE PassLen, MBT_CHAR* UserID, MBT_BYTE IDLen)
{
	MBT_API("MBT_OBEX_ServerAuthenticateRes");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_serverauthenticateres(ServerHandle, PassWD, PassLen, UserID, IDLen);
#endif
}

MBT_VOID MBT_OBEX_ServerSetPathRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE setpath_res)
{
	MBT_API("MBT_OBEX_ServerSetPathRes");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_serversetpathres(ServerHandle, setpath_res);
#endif
}

MBT_VOID MBT_OBEX_ServerPutRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE put_res)
{
	MBT_API("MBT_OBEX_ServerPutRes");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_serverputres(ServerHandle,put_res);
#endif
}

MBT_VOID MBT_OBEX_ServerGetRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE get_res)
{
	MBT_API("MBT_OBEX_ServerGetRes");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_servergetres(ServerHandle, get_res);
#endif
}

MBT_VOID MBT_OBEX_ServerAbortRes(MBT_UINT ServerHandle, T_MBT_OBEX_RESPONSE abort_res)
{
	MBT_API("MBT_OBEX_ServerAbortRes");
#if (MBT_OBEX == MBT_TRUE)
	mbt_obex_serverabortres(ServerHandle, abort_res);
#endif
}