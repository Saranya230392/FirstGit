#include "MBTGap.h"
#include "mbt_gap.h"

MBT_BOOL MBT_GAP_BTInitialize (MBT_VOID)
{
	MBT_API("MBT_GAP_BT_INITIALIZE");
#if (MBT_GAP == MBT_TRUE)	
	return mbt_gap_btinitialize();
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_GAP_BluetoothOn (MBT_VOID)
{
	MBT_API("MBT_GAP_BluetoothOn");
#if (MBT_GAP == MBT_TRUE)
	mbt_gap_bluetoothon();
#endif
}

MBT_VOID MBT_GAP_BluetoothOff (MBT_VOID)
{
	MBT_API("MBT_GAP_BluetoothOff");
#if (MBT_GAP == MBT_TRUE)
	mbt_gap_bluetoothoff();
#endif
}

MBT_BOOL MBT_GAP_SetMyName (MBT_CHAR* MyDevName)
{
	MBT_API("MBT_GAP_SetMyName");
#if (MBT_GAP == MBT_TRUE)
	return mbt_gap_setmyname(MyDevName);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_SetNickName(T_MBT_BDADDR PairedDevAddr, MBT_CHAR* NickName)
{
	MBT_API("MBT_GAP_SetNickName");
#if (MBT_GAP == MBT_TRUE)
	return mbt_gap_setnickname(PairedDevAddr, NickName);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_SetConnectable(MBT_BOOL bConnectable)
{
	MBT_API("MBT_GAP_SetConnectable");
#if (MBT_GAP == MBT_TRUE)
	return mbt_gap_setconnectable(bConnectable);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_SetVisible(MBT_BOOL bVisible)
{
	MBT_API("MBT_GAP_SetVisible");
#if (MBT_GAP == MBT_TRUE)
	return mbt_gap_setvisible(bVisible);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_SetPairable (MBT_BOOL bPairable)
{
	MBT_API("MBT_GAP_SetPairable");
#if (MBT_GAP == MBT_TRUE)
	return mbt_gap_setpairable(bPairable);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_IsCmdAcceptable(MBT_VOID)
{
	MBT_API("MBT_GAP_IsCmdAcceptable");
#if (MBT_GAP == MBT_TRUE)
	return mbt_gap_iscmdacceptable();
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_IsDeviceConnected(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_API("MBT_GAP_IsDeviceConnected");
#if (MBT_GAP == MBT_TRUE)
	return mbt_gap_isdeviceconnected(RemoteBDAddr);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_IsSvcConnected(MBT_SERVICE_ID MBtSvc)
{
	MBT_API("MBT_GAP_IsSvcConnected");
#if (MBT_GAP == MBT_TRUE)		
	return mbt_gap_issvcconnected(MBtSvc);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_IsAuthorized(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_API("MBT_GAP_IsAuthorized");
#if (MBT_GAP == MBT_TRUE)		
	return mbt_gap_isauthorized(RemoteBDAddr);
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_GAP_DevDiscovery(MBT_SERVICE_ID MBTSvc, MBT_INT nMaxCount)
{
	MBT_API("MBT_GAP_DevDiscovery");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_devdiscovery(MBTSvc,nMaxCount);
#endif
}

MBT_VOID MBT_GAP_DevDiscoveryCancel(MBT_VOID)
{
	MBT_API("MBT_GAP_DevDiscoveryCancel");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_devdiscoverycancel();
#endif
}

MBT_VOID MBT_GAP_NameReq(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_API("MBT_GAP_NameReq");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_namereq(RemoteBDAddr);
#endif
}

MBT_VOID MBT_GAP_NameReqCancel(MBT_VOID)
{
	MBT_API("MBT_GAP_NameReqCancel");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_namereqcancel();
#endif
}

MBT_VOID MBT_GAP_SvcDiscovery(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_API("MBT_GAP_SvcDiscovery");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_svcdiscovery(RemoteBDAddr);
#endif
}

MBT_VOID MBT_GAP_SvcDiscoveryCancel(MBT_VOID)
{
	MBT_API("MBT_GAP_SvcDiscoveryCancel");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_svcdiscoverycancel();
#endif
}

MBT_VOID MBT_GAP_PairReq(T_MBT_BDADDR RemoteBDAddr, T_MBT_PIN PinReq, MBT_INT PinLength)
{
	MBT_API("MBT_GAP_PairReq");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_pairreq(RemoteBDAddr,PinReq,PinLength);
#endif
}

MBT_VOID MBT_GAP_PairReqCancel(MBT_VOID)
{
	MBT_API("MBT_GAP_PairReqCancel");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_pairreqcancel();
#endif
}

MBT_VOID MBT_GAP_PairRes(MBT_BOOL bAccept, T_MBT_PIN PinRes, MBT_INT PinLength)
{
	MBT_API("MBT_GAP_PairRes");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_pairres(bAccept, PinRes, PinLength);
#endif
}
MBT_VOID MBT_GAP_SspRes(MBT_BOOL bAccept)
{
	MBT_API("MBT_GAP_SspRes");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_sspres(bAccept);
#endif
}

MBT_VOID MBT_GAP_SspPasskeyCancel(MBT_VOID)
{
	MBT_API("MBT_GAP_SspPasskeyCancel");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_ssppasskeycancel();
#endif
}

MBT_VOID MBT_GAP_AuthorizationRes(MBT_BOOL bAccept, MBT_SERVICE_ID AuthSvc)
{
	MBT_API("MBT_GAP_AuthorizationRes");
#if (MBT_GAP == MBT_TRUE)		
	mbt_gap_authorizationres(bAccept, AuthSvc);
#endif
}

MBT_BOOL MBT_GAP_UnPair(T_MBT_BDADDR RemoteBDAddr)
{
	MBT_API("MBT_GAP_UnPair");
#if (MBT_GAP == MBT_TRUE)		
	return mbt_gap_unpair(RemoteBDAddr);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_UnPairAll(MBT_VOID)
{
	MBT_API("MBT_GAP_UnPairAll");
#if (MBT_GAP == MBT_TRUE)		
	return mbt_gap_unpairall();
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_SetAuthorize(T_MBT_BDADDR RemoteBDAddr, MBT_BOOL bAuthorize)
{
	MBT_API("MBT_GAP_SetAuthorize");
#if (MBT_GAP == MBT_TRUE)		
	return mbt_gap_setauthorize(RemoteBDAddr,bAuthorize);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_AddBlockDev(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_GAP_AddBlockDev");
#if (MBT_GAP == MBT_TRUE)		
	return mbt_gap_addblockdev(BdAddr);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_GAP_RemoveBlockDev(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_GAP_RemoveBlockDev");
#if (MBT_GAP == MBT_TRUE)		
	return mbt_gap_removeblockdev(BdAddr);
#else
	return MBT_FALSE;
#endif
}
