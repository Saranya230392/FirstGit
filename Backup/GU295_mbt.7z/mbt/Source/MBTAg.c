#include "MBTAg.h"
#include "mbt_ag.h"

MBT_VOID MBT_AG_Enable(MBT_VOID)
{
	MBT_API("MBT_AG_Enable");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_enable();
#endif
}

MBT_VOID MBT_AG_Disable(MBT_VOID)
{
	MBT_API("MBT_AG_Disable");
#if (MBT_AG == MBT_TRUE)
	mbt_ag_disable();
#endif
}

MBT_VOID MBT_AG_Connect(T_MBT_BDADDR RemoteBDAddr, MBT_SERVICE_ID MBtSvc)
{
	MBT_API("MBT_AG_Connect");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_connect(RemoteBDAddr,MBtSvc);
#endif
}

MBT_VOID MBT_AG_Disconnect	(T_MBT_BDADDR RemoteBDAddr, MBT_SERVICE_ID MBtSvc)
{
	MBT_API("MBT_AG_Disconnect");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_disconnect(RemoteBDAddr,MBtSvc);
#endif
}

MBT_VOID MBT_AG_AudioConnect(MBT_VOID)
{
	MBT_API("MBT_AG_AudioConnect");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_audioconnect();
#endif
}

MBT_VOID MBT_AG_AudioDisconnect(MBT_VOID)
{
	MBT_API("MBT_AG_AudioDisconnect");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_audiodisconnect();
#endif
}

MBT_BOOL MBT_AG_GetConStatus(MBT_VOID)
{
// �ʹ� ���Ƽ�...�ӽ÷�...		MBT_API(__func__"");
#if (MBT_AG == MBT_TRUE)
	return mbt_ag_getconstatus();
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_GetAudioStatus(MBT_VOID)
{
	MBT_API("MBT_AG_GetAudioStatus");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_getaudiostatus();
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_AG_SetConnectable(MBT_BOOL connectable)
{
	MBT_API("MBT_AG_SetConnectable");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_setconnectable(connectable);
#endif
}

MBT_VOID MBT_AG_SetAudioPath(MBT_BOOL audiopath)
{
	MBT_API("MBT_AG_SetAudioPath");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_setaudiopath(audiopath);
#endif
}

MBT_VOID MBT_AG_SetSpkVolume(MBT_BYTE   	 Level)
{
	MBT_API("MBT_AG_SetSpkVolume");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_setspkvolume(Level);
#endif
}

MBT_VOID MBT_AG_SetMicVolume(MBT_BYTE   	 Level)
{
	MBT_API("MBT_AG_SetMicVolume");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_setmicvolume(Level);
#endif
}

MBT_VOID MBT_AG_CallStateChange(T_MBT_AG_PHONE_CALLSTATE NewState)
{
	MBT_API("MBT_AG_CallStateChange");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_callstatechange(NewState);
#endif
}

MBT_VOID MBT_AG_SetCallStatus(T_MBT_AG_CALLSTATUS CurrentStatus)
{
	MBT_API("MBT_AG_SetCallStatus");
	mbt_ag_setcallstatus(CurrentStatus);
}

MBT_VOID MBT_AG_SetCallSetup(T_MBT_AG_CALLSETUP CurrentCallSetup)
{
	MBT_API("MBT_AG_SetCallSetup");
	mbt_ag_setcallsetup(CurrentCallSetup);
}

MBT_VOID MBT_AG_SetNetworkStatus		(T_MBT_AG_NETSTATE	State)
{
	MBT_API("MBT_AG_SetNetworkStatus");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_setnetworkstatus(State);
#endif
}

MBT_VOID MBT_AG_SetCID(MBT_CHAR* Num, MBT_BYTE len)
{
	MBT_API("MBT_AG_SetCID");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_setcid(Num,len);
#endif
}

MBT_BOOL MBT_AG_SetSignalStrength(MBT_BYTE Level)
{
	MBT_API("MBT_AG_SetSignalStrength");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setsignalstrength(Level);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_SetRoamingStatus(MBT_BYTE Level)
{
	MBT_API("MBT_AG_SetRoamingStatus");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setroamingstatus(Level);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_SetBatteryLevel(MBT_BYTE Level)
{
	MBT_API("MBT_AG_SetBatteryLevel");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setbatterylevel(Level);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_SetCallHeldStatus(T_MBT_AG_CALL_HELD value)
{
	MBT_API("MBT_AG_SetCallHeldStatus");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setcallheldstatus(value);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_SetOperatorSelection(T_MBT_AG_NETMODE Netmode,MBT_BYTE* OpName)
{
	MBT_API("MBT_AG_SetOperatorSelection");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setoperatorselection(Netmode,OpName);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_SetExtendedError(T_MBT_AG_CME_ERR ErrorCode)
{
	MBT_API("MBT_AG_SetExtendedError");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setextendederror(ErrorCode);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_SetSubscriberNumber(MBT_CHAR* Num, MBT_BYTE NumType, MBT_BYTE Len, T_MBT_AG_SERVICE Service,MBT_BOOL FinalFlag)
{
	MBT_API("MBT_AG_SetSubscriberNumber");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setsubscribernumber(Num,NumType,Len,Service,FinalFlag);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_SetCallWaiting(MBT_CHAR* Num, MBT_BYTE Len)
{
	MBT_API("MBT_AG_SetCallWaiting");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setcallwaiting(Num,Len);
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_AG_SendResponse(MBT_BOOL Response)
{
	MBT_API("MBT_AG_SendResponse");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendresponse(Response);
#endif
}

MBT_BOOL MBT_AG_SetCIND(T_MBT_AG_NETSTATE Net, T_MBT_AG_CALLSTATUS CallState, T_MBT_AG_CALLSETUP SetupState, MBT_BYTE SignalLevel, MBT_BYTE RoamingStatus, MBT_BYTE BatteryLevel,T_MBT_AG_CALL_HELD value)
{
	MBT_API("MBT_AG_SetCIND");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setcind(Net,CallState,SetupState,SignalLevel,RoamingStatus,BatteryLevel,value);
#else
	return MBT_FALSE;
#endif
}

MBT_BOOL MBT_AG_SetCurrentCallList(MBT_BYTE Idx,
											T_MBT_AG_CL_DIR Dir, 
											T_MBT_AG_CL_STATUS Status,
											T_MBT_AG_CL_MODE Mode,
											T_MBT_AG_CL_MPTY Mprty,
											MBT_CHAR* Num, MBT_BYTE NumType,
											MBT_BYTE Len, MBT_BOOL FinalFlag)
{
	MBT_API("MBT_AG_SetCurrentCallList");
#if (MBT_AG == MBT_TRUE)	
	return mbt_ag_setcurrentcalllist(Idx,Dir,Status,Mode,Mprty,Num,NumType,Len,FinalFlag);
#else
	return MBT_FALSE;
#endif
}

MBT_VOID MBT_AG_StartVR(MBT_VOID)
{
	MBT_API("MBT_AG_StartVR");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_startvr();
#endif
}

MBT_VOID MBT_AG_StopVR(MBT_VOID)
{
	MBT_API("MBT_AG_StopVR");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_stopvr();
#endif
}

MBT_VOID MBT_AG_SendSupportedPBList(T_MBT_AG_PB_CPBS supportedPbList)
{
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendsupportedpblist(supportedPbList);
#endif
}

MBT_VOID MBT_AG_SendSelectedPBInfo(T_MBT_AG_PB_RETURN result, MBT_SHORT usedRecs, MBT_SHORT totalRecs)
{
#if (MBT_AG == MBT_TRUE)
	mbt_ag_sendselectedpbinfo(result, usedRecs, totalRecs);
#endif
}

MBT_VOID MBT_AG_SendPBSelectResult( T_MBT_AG_PB_RETURN result )
{
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendpbselectresult(result);
#endif
}


MBT_VOID MBT_AG_SendPBEntriesInfo(T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt)
{
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendpbentriesinfo(result, indexStart, indexEnd, maxLenNum, maxLenTxt);
#endif
}

MBT_VOID MBT_AG_SendPBReadResult(T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec, MBT_BOOL finalEntry)
{
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendpbreadresult(result, pbRec, finalEntry);
#endif
}

MBT_VOID MBT_AG_SendPBFindEntriesInfo(T_MBT_AG_PB_RETURN result, MBT_SHORT maxLenNum, MBT_SHORT maxLenTxt)
{
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendpbfindentriesinfo(result, maxLenNum, maxLenTxt);
#endif
}

MBT_VOID MBT_AG_SendPBFindResult(T_MBT_AG_PB_RETURN result, T_MBT_AG_PB_REC* pbRec, MBT_BOOL finalEntry)
{
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendpbfindresult(result, pbRec, finalEntry);
#endif
}

MBT_VOID MBT_AG_SendPBWriteInfo(T_MBT_AG_PB_RETURN result, MBT_SHORT indexStart, MBT_SHORT indexEnd, MBT_SHORT maxlenNum, MBT_SHORT typeStart, MBT_SHORT typeEnd, MBT_SHORT maxlenTxt)
{
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendpbwriteinfo(result, indexStart, indexEnd, maxlenNum, typeStart, typeEnd, maxlenTxt);
#endif
}

MBT_VOID MBT_AG_SendPBWriteResult( T_MBT_AG_PB_RETURN result )
{
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_sendpbwriteresult(result);
#endif
}

MBT_VOID MBT_AG_SetCGM(MBT_CHAR* manufacturerid, MBT_CHAR* modelid)
{
	MBT_API("MBT_AG_SetCGM");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_setcgm(manufacturerid, modelid);
#endif
}

MBT_VOID MBT_AG_RingStart(MBT_VOID)
{
	MBT_API("MBT_AG_RingStart");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_ringstart();
#endif	
}

MBT_VOID MBT_AG_RingStop(MBT_VOID)
{
	MBT_API("MBT_AG_RingStop");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_ringstop();
#endif		
}

MBT_VOID MBT_AG_SetCSCS(T_MBT_AG_CSCS* AgCSList)
{
	MBT_API("MBT_AG_SetCSCS");
#if (MBT_AG == MBT_TRUE)	
	mbt_ag_setcscs(AgCSList);
#endif
}

