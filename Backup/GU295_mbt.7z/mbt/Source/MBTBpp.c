#include "MBTBpp.h"
#include "mbt_bpp.h"

MBT_VOID MBT_BPP_Enable (MBT_VOID)
{
	MBT_API("MBT_BPP_Enable");
#if (MBT_BPP == MBT_TRUE)
 	mbt_bpp_enable();
#endif
}

MBT_VOID MBT_BPP_Disable (MBT_VOID)
{
	MBT_API("MBT_BPP_Disable");
#if (MBT_BPP == MBT_TRUE)
 	mbt_bpp_disable();
#endif
}

MBT_VOID MBT_BPP_AuthRes(T_MBT_OBEX_AUTH *auth_reply)
{
	MBT_API("MBT_BPP_AuthRes");
#if (MBT_BPP == MBT_TRUE)
 	mbt_bpp_auth_response(auth_reply);
#endif
}

MBT_VOID MBT_BPP_GetPrinterAttribute(T_MBT_BDADDR BdAddr, MBT_INT PrinterAttr)
{
	MBT_API("MBT_BPP_GetPrinterAttribute");
#if (MBT_BPP == MBT_TRUE)
 	mbt_bpp_getprinterattribute(BdAddr, PrinterAttr);
#endif
}

MBT_VOID MBT_BPP_Print(T_MBT_BDADDR BdAddr, T_MBT_BPP_OBJECT* MBTObject)
{
	MBT_API("MBT_BPP_Print");
#if (MBT_BPP == MBT_TRUE)
 	mbt_bpp_print(BdAddr, MBTObject);
#endif
}

MBT_VOID MBT_BPP_Disconnect(MBT_VOID)
{
	MBT_API("MBT_BPP_Disconnect");
#if (MBT_BPP == MBT_TRUE)
 	mbt_bpp_disconnect();
#endif
}

