#include "MBTAvrcp.h"
#include "mbt_avrcp.h"
#include "mbt_sdc.h"

MBT_VOID MBT_AVRCP_Enable(MBT_VOID)
{
	MBT_API("MBT_AVRCP_Enable");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_enable();
#endif
}

MBT_VOID MBT_AVRCP_Disable(MBT_VOID)
{
	MBT_API("MBT_AVRCP_Disable");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_disable();
#endif
}

MBT_VOID MBT_AVRCP_Connect(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_AVRCP_Connect");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_connect(BdAddr);
#endif
}

MBT_VOID MBT_AVRCP_Disconnect (T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_AVRCP_Disconnect");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_disconnect(BdAddr);
#endif
}

MBT_VOID MBT_AVRCP_SendCmd (T_MBT_BDADDR BdAddr, T_MBT_AVRCP_KEY KeyValue)
{
	MBT_API("MBT_AVRCP_SendCmd");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_sendcmd(BdAddr, KeyValue);
#endif
}

MBT_VOID MBT_AVRCP_GetPlayerValueRes(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_APP_ATTR* AttrValue)
{
	MBT_API("MBT_AVRCP_GetPlayerValueRes");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_get_player_value_res(BdAddr, AttrValue);
#endif
}

MBT_VOID MBT_AVRCP_GetMediaAttrRes(T_MBT_BDADDR BdAddr, MBT_BYTE AttrNum, T_MBT_AVRCP_MEDIA_ATTR* AttrData )
{
	MBT_API("MBT_AVRCP_GetMediaAttrRes");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_get_media_attr_res(BdAddr, AttrNum, AttrData);
#endif
}

MBT_VOID MBT_AVRCP_GetPlayStatusRes(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_GET_PLAYSTATUS PlayStatus)
{
	MBT_API("MBT_AVRCP_GetPlayStatusRes");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_get_playstatus_res(BdAddr, PlayStatus);
#endif
}

MBT_VOID MBT_AVRCP_RegisterNotiInterimRes(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti)
{
	MBT_API("MBT_AVRCP_RegisterNotiInterimRes");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_register_noti_interim_res(BdAddr, RegisterNoti);
#endif
}

MBT_VOID MBT_AVRCP_RegisterNotiRes(T_MBT_BDADDR BdAddr, T_MBT_AVRCP_REGISTER_NOTI* RegisterNoti)
{
	MBT_API("MBT_AVRCP_RegisterNotiRes");
#if (MBT_AVRCP == MBT_TRUE)
	mbt_avrcp_register_noti_res(BdAddr, RegisterNoti);
#endif
}