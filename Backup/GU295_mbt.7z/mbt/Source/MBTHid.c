#include "MBTHid.h"
#include "mbt_hid.h"
#include "mbt_sdc.h"

MBT_VOID MBT_HID_HostEnable(FP_MBT_HID_RX_REPORT_CO fpRxRptCO)
{
	MBT_API("MBT_HID_HostEnable");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_enable(fpRxRptCO);
#endif
}

MBT_VOID MBT_HID_HostDisable(MBT_VOID)
{
	MBT_API("MBT_HID_HostDisable");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_disable();
#endif
}

MBT_VOID MBT_HID_HostConnect(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_HID_HostConnect");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_connect(BdAddr);
#endif
}

MBT_VOID MBT_HID_HostDisconnect(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_HID_HostDisconnect");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_disconnect(BdAddr);
#endif
}

MBT_VOID MBT_HID_HostAddDevice(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_HID_HostAddDevice");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_add_device(BdAddr);
#endif
}

MBT_VOID MBT_HID_HostRemoveDevice(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_HID_HostRemoveDevice");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_remove_device(BdAddr);
#endif
}

MBT_VOID MBT_HID_HostGetDescInfo(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_HID_HostGetDescInfo");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_get_descInfo(BdAddr);
#endif
}

MBT_VOID MBT_HID_HostSetLED(T_MBT_BDADDR BdAddr, T_MBT_HID_LED_MASK led)
{
	MBT_API("MBT_HID_HostSetLED");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_set_led(BdAddr, led);
#endif
}

MBT_VOID MBT_HID_HostSendLED(T_MBT_BDADDR BdAddr, T_MBT_HID_LED_MASK led)
{
	MBT_API("MBT_HID_HostSendLED");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_send_led(BdAddr, led);
#endif
}

MBT_VOID MBT_HID_HostSendControl(T_MBT_BDADDR BdAddr, T_MBT_HID_CONTROL control)
{
	MBT_API("MBT_HID_HostSendControl");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_send_control(BdAddr, control);
#endif
}

MBT_VOID MBT_HID_HostSendReport(T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE RptType, MBT_BYTE *RptData, MBT_SHORT RptSize)
{
	MBT_API("MBT_HID_HostSendReport");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_send_report(BdAddr, RptType, RptData, RptSize);
#endif
}

MBT_VOID MBT_HID_HostSetReport(T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE RptType, MBT_BYTE *RptData, MBT_SHORT RptSize)
{
	MBT_API("MBT_HID_HostSetReport");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_set_report(BdAddr, RptType, RptData, RptSize);
#endif
}

MBT_VOID MBT_HID_HostGetReport(T_MBT_BDADDR BdAddr, T_MBT_HID_REPORT_TYPE RptType, MBT_BYTE RptId)
{
	MBT_API("MBT_HID_HostGetReport");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_get_report(BdAddr, RptType, RptId);
#endif
}

MBT_VOID MBT_HID_HostGetIdle(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_HID_HostGetIdle");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_get_idle(BdAddr);
#endif
}

MBT_VOID MBT_HID_HostSetIdle(T_MBT_BDADDR BdAddr, MBT_BYTE idle)
{
	MBT_API("MBT_HID_HostSetIdle");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_set_idle(BdAddr, idle);
#endif
}

MBT_VOID MBT_HID_HostGetProtocol(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_HID_HostGetProtocol");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_get_protocol(BdAddr);
#endif
}

MBT_VOID MBT_HID_HostSetProtocol(T_MBT_BDADDR BdAddr, MBT_BOOL BootMode)
{
	MBT_API("MBT_HID_HostSetProtocol");
#if (MBT_HID_HOST == MBT_TRUE)
 	mbt_hid_host_set_protocol(BdAddr, BootMode);
#endif
}

MBT_VOID MBT_HID_DeviceEnable(MBT_VOID)
{
	MBT_API("MBT_HID_DeviceEnable");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_enable();
#endif
}

MBT_VOID MBT_HID_DeviceDisable(MBT_VOID)
{
	MBT_API("MBT_HID_DeviceDisable");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_disable();
#endif
}

MBT_VOID MBT_HID_DeviceConnect(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_HID_DeviceConnect");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_connect(BdAddr);
#endif
}

MBT_VOID MBT_HID_DeviceDisconnect(MBT_VOID)
{
	MBT_API("MBT_HID_DeviceDisconnect");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_disconnect();
#endif
}

MBT_VOID MBT_HID_DeviceSendUnplug(MBT_VOID)
{
	MBT_API("MBT_HID_DeviceSendUnplug");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_send_unplug();
#endif
}

MBT_VOID MBT_HID_DeviceSendReport(T_MBT_HID_REPORT_TYPE RptType, MBT_BYTE *RptData, MBT_SHORT RptSize)
{
	MBT_API("MBT_HID_DeviceSendReport");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_send_report(RptType, RptData, RptSize);
#endif
}

MBT_VOID MBT_HID_DeviceSendKeyboardRpt(T_MBT_HID_MODIFIER_MASK modifier, T_MBT_HID_KEY_TYPE *keycodes, MBT_BYTE key_num)
{
	MBT_API("MBT_HID_DeviceSendKeyboardRpt");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_send_keyboard_rpt(modifier, keycodes, key_num);
#endif
}

MBT_VOID MBT_HID_DeviceSendMouseRpt(T_MBT_HID_MOUSE_BUTTON_MASK button, MBT_BYTE move_x, MBT_BYTE move_y)
{
	MBT_API("MBT_HID_DeviceSendMouseRpt");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_send_mouse_rpt(button, move_x, move_y);
#endif
}

MBT_VOID MBT_HID_DeviceChangeKeyboardRole(MBT_VOID)
{
	MBT_API("MBT_HID_DeviceChangeKeyboardRole");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_change_keyboard_role();
#endif
}

MBT_VOID MBT_HID_DeviceChangeMouseRole(MBT_VOID)
{
	MBT_API("MBT_HID_DeviceChangeMouseRole");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_change_mouse_role();
#endif
}

MBT_VOID MBT_HID_DeviceChangePhoneRole(MBT_VOID)
{
	MBT_API("MBT_HID_DeviceChangePhoneRole");
#if (MBT_HID_DEVICE==MBT_TRUE)
 	mbt_hid_device_change_phone_role();
#endif
}
