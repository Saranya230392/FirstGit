#include "MBTSdc.h"
#include "mbt_sdc.h"

MBT_VOID*	MBT_SDC_GetRecord(T_MBT_SDC_RECID MBTSDCRecID)
{
	return (MBT_VOID *)mbt_sdc_getrecord(MBTSDCRecID);
}
MBT_INT	MBT_SDC_GetValue(T_MBT_SDC_VALID MBTSDCValID)
{
	return mbt_sdc_getvalue(MBTSDCValID);
}


MBT_VOID	MBT_SDC_InitData()
{
	mbt_sdc_initdata();
}

