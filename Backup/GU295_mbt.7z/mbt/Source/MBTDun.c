#include "MBTDun.h"
#include "mbt_dun.h"

MBT_VOID MBT_DUN_Enable (MBT_VOID)
{
	MBT_API("MBT_DUN_Enable");
#if (MBT_DUN == MBT_TRUE)
 	mbt_dun_enable();
#endif
}

MBT_VOID MBT_DUN_Disable (MBT_VOID)
{
	MBT_API("MBT_DUN_Disable");
#if (MBT_DUN == MBT_TRUE)
 	mbt_dun_disable();
#endif
}

MBT_VOID MBT_DUN_Disconnect(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_DUN_Disconnect");
#if (MBT_DUN == MBT_TRUE)
 	mbt_dun_disconnect(BdAddr);
#endif
}

MBT_VOID MBT_DUN_Listen(MBT_VOID)
{
	MBT_API("MBT_DUN_Listen");
#if (MBT_DUN == MBT_TRUE)
	mbt_dun_listen();
#endif
}

MBT_VOID MBT_DUN_ListenStop(MBT_VOID)
{
	MBT_API("MBT_DUN_Shutdown");
#if (MBT_DUN == MBT_TRUE)
	mbt_dun_listenstop();
#endif
}
