#include "MBTSap.h"
#include "mbt_sap.h"


MBT_VOID MBT_SAP_ServerEnable (MBT_VOID)
{
	MBT_API("MBT_SAP_ServerEnable");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_enable();
#endif
}

MBT_VOID MBT_SAP_ServerDisable (MBT_VOID)
{
	MBT_API("MBT_SAP_ServerDisable");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_disable();
#endif
}


MBT_VOID MBT_SAP_ServerResAtr( T_MBT_SAP_RESULT_CODE  Result, MBT_SHORT Length, MBT_BYTE *  pAtr)
{
	MBT_API("MBT_SAP_ServerResAtr");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_respond_transferatr(Result,Length,pAtr);
#endif
}


MBT_VOID MBT_SAP_ServerConnRes( T_MBT_BDADDR PeerBDAddr,  T_MBT_SAP_CONNECT_STATUS ConnStatus,
									     MBT_SHORT MaxMsgSize, T_MBT_SAP_CARD_STATUS CardStatus)
{
	MBT_API("MBT_SAP_ServerConnRes");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_connect_respond(PeerBDAddr,ConnStatus,MaxMsgSize,CardStatus);
#endif
}

MBT_VOID MBT_SAP_ServerResApdu(T_MBT_SAP_RESULT_CODE 	Result, MBT_SHORT Length, MBT_BYTE *  pApdu)
{
	MBT_API("MBT_SAP_ServerResApdu");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_respondtransferapdu(Result,Length,pApdu);
#endif
}

MBT_VOID MBT_SAP_ServerResSimOff(T_MBT_SAP_RESULT_CODE   Result)
{
	MBT_API("MBT_SAP_ServerResSimOff");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_respondpowersimoff(Result);
#endif
}


MBT_VOID MBT_SAP_ServerResSimOn(T_MBT_SAP_RESULT_CODE   Result)
{
	MBT_API("MBT_SAP_ServerResSimOn");
#if (MBT_SAP == MBT_TRUE)
 	  mbt_sap_server_respondpowersimon(Result);
#endif
}

MBT_VOID MBT_SAP_ServerResResetSim(T_MBT_SAP_RESULT_CODE   Result)
{
	MBT_API("MBT_SAP_ServerResResetSim");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_respond_resetsim(Result);
#endif
}


MBT_VOID MBT_SAP_ServerResCardReaderStat(T_MBT_SAP_RESULT_CODE  Result, T_MBT_SAP_CARD_READER_STATUS  Status)
{
	MBT_API("MBT_SAP_ServerResCardReaderStat");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_respond_transfercardreaderstatus(Result, Status);
#endif
}


MBT_VOID MBT_SAP_ServerResPrtcl(T_MBT_SAP_RESULT_CODE   Result)
{
	MBT_API("MBT_SAP_ServerResPrtcl");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_respond_transportprotocol(Result);
#endif
}

MBT_VOID MBT_SAP_ServerSendCardStat (T_MBT_SAP_CARD_STATUS Status)
{
	MBT_API("MBT_SAP_ServerSendCardStat");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_send_cardstatus(Status);
#endif
}

MBT_VOID MBT_SAP_ServerDisconnect (T_MBT_SAP_DISCONNECT DisconnType)
{
	MBT_API("MBT_SAP_ServerDisconnect");
#if (MBT_SAP == MBT_TRUE)
 	mbt_sap_server_request_disconnect (DisconnType);
#endif
}



