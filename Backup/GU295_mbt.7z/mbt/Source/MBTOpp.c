/********************************************************************************
*	File Name	: MBtOpp.c
*	Description	: MBtOpp.c
*
*	when		who(fullname)			what,why
*	--------	----------------	--------------------------------------------
*	07.04.09		Kim,Hyunseok			Created
********************************************************************************/
#include "MBTOpp.h"
#include "mbt_opp.h"




MBT_VOID MBT_OPP_ServerEnable (MBT_VOID)
{
	MBT_API("MBT_OPP_ServerEnable");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_server_enable();
#endif
}




MBT_VOID MBT_OPP_ServerDisable (MBT_VOID)
{
	MBT_API("MBT_OPP_ServerDisable");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_server_disable();
#endif
}




MBT_VOID MBT_OPP_ServerDisconnect(MBT_VOID)
{
	MBT_API("MBT_OPP_ServerDisconnect");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_server_disconnect();
#endif
}




MBT_VOID MBT_OPP_ServerAccessRsp(T_MBT_AUTHRES Reply)
{
	MBT_API("MBT_OPP_ServerAccessRsp");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_server_access_response(Reply);
#endif
}






MBT_VOID MBT_OPP_ClientEnable (MBT_VOID)
{
	MBT_API("MBT_OPP_ClientEnable");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_client_enable();
#endif
}




MBT_VOID MBT_OPP_ClientDisable (MBT_VOID)
{
	MBT_API("MBT_OPP_ClientDisable");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_client_disable();
#endif
}





MBT_VOID MBT_OPP_ClientPushObject (T_MBT_BDADDR RemoteBDAddr,T_MBT_OPP_OBJECT *MBTObject)
{
	MBT_API("MBT_OPP_ClientPushObject");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_client_pushobject(RemoteBDAddr, MBTObject);
#endif
}




MBT_VOID MBT_OPP_ClientPullObject(T_MBT_BDADDR remoteDev,T_MBT_OPP_OBJECT * MBTObject)
{
	MBT_API("MBT_OPP_ClientPullObject");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_client_pullobject(remoteDev, MBTObject);
#endif
}




MBT_VOID MBT_OPP_ClientExchObject(T_MBT_BDADDR remoteDev,T_MBT_OPP_OBJECT * SendObject,T_MBT_OPP_OBJECT * RecvObject)
{
	MBT_API("MBT_OPP_ClientExchObject");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_client_exchobject(remoteDev, SendObject, RecvObject);
#endif
}




MBT_VOID MBT_OPP_ClientDisconnect(MBT_VOID)
{
	MBT_API("MBT_OPP_ClientDisconnect");
#if (MBT_OPP == MBT_TRUE)
	mbt_opp_client_disconnect();
#endif
}
