#include "MBTBip.h"
#include "mbt_bip.h"

MBT_VOID MBT_BIP_InitiatorEnable(MBT_VOID)
{
	MBT_API("MBT_BIP_InitiatorEnable");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_initiator_enable();
#endif
}

MBT_VOID MBT_BIP_InitiatorDisable(MBT_VOID)
{
	MBT_API("MBT_BIP_InitiatorDisable");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_initiator_disable();
#endif
}

MBT_VOID MBT_BIP_InitiatorAuthRsp(T_MBT_OBEX_AUTH *auth_reply)
{
	MBT_API("MBT_BIP_InitiatorAuthRsp");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_initiator_auth_response(auth_reply);
#endif
}

MBT_VOID MBT_BIP_InitiatorGetCapabilityReq(T_MBT_BDADDR BdAddr)
{
	MBT_API("MBT_BIP_InitiatorGetCapabilityReq");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_initiator_getcapability_request(BdAddr);
#endif
}

MBT_VOID MBT_BIP_InitiatorPushImage(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBTObject)
{
	MBT_API("MBT_BIP_InitiatorPushImage");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_initiator_pushimage(BdAddr, MBTObject);
#endif
}

MBT_VOID MBT_BIP_InitiatorPushThumbnail(T_MBT_BDADDR BdAddr, T_MBT_BIP_OBJECT *MBTObject)
{
	MBT_API("MBT_BIP_InitiatorPushThumbnail");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_initiator_pushthumbnail(BdAddr, MBTObject);
#endif
}

MBT_VOID MBT_BIP_InitiatorDisconnect(MBT_VOID)
{
	MBT_API("MBT_BIP_InitiatorDisconnect");
#if (MBT_BIP == MBT_TRUE)
	mbt_bip_initiator_disconnect();
#endif
}

MBT_VOID MBT_BIP_ResponderEnable(MBT_VOID)
{
	MBT_API("MBT_BIP_ResponderEnable");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_responder_enable();
#endif
}

MBT_VOID MBT_BIP_ResponderDisable(MBT_VOID)
{
	MBT_API("MBT_BIP_ResponderDisable");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_responder_disable();
#endif
}

MBT_VOID MBT_BIP_ResponderAuthRsp(T_MBT_OBEX_AUTH *auth_reply)
{
	MBT_API("MBT_BIP_ResponderAuthRsp");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_responder_auth_response(auth_reply);
#endif
}

MBT_VOID MBT_BIP_ResponderAccessRsp(T_MBT_AUTHRES Reply)
{
	MBT_API("MBT_BIP_ResponderAccessRsp");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_responder_access_response(Reply);
#endif
}

MBT_VOID MBT_BIP_ResponderGetCapabilityResp(T_MBT_AUTHRES Reply, T_MBT_BIP_IMAGING_CAPABILITY *ImagingCapability)
{
	MBT_API("MBT_BIP_ResponderGetCapabilityResp");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_responder_getcapability_response(Reply, ImagingCapability);
#endif
}

MBT_VOID MBT_BIP_ResponderDisconnect(MBT_VOID)
{
	MBT_API("MBT_BIP_ResponderDisconnect");
#if (MBT_BIP == MBT_TRUE)
 	mbt_bip_responder_disconnect();
#endif
}
