package com.ant.antplus;

import android.content.Context;
import android.graphics.Color;
import android.util.AttributeSet;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MenuButton extends ImageButton
{
   protected boolean isChecked = false;
   
   protected int layoutId;
   protected int imageOn;
   protected int imageOff;
   
   public MenuButton(Context context)
   {
      super(context);
   }
   
   public MenuButton(Context context, AttributeSet attrs)
   {
      super(context, attrs);
      setScaleType(ImageView.ScaleType.CENTER_INSIDE);
      setBackgroundColor(Color.TRANSPARENT);
   }
   
   public boolean isChecked()
   {
      return this.isChecked;
   }
   
   public void setLayoutId(int id)
   {
      layoutId = id;
   }
   
   public int getLayoutId()
   {
      return layoutId;
   }
   
   public void setImagePressed(int id)
   {
      imageOn = id;
   }
   
   public void setImageDefault(int id)
   {
      imageOff = id;
   }
   
   public void setState(boolean on)
   {
      isChecked = on;
      redrawButton();
   }
   
   public void toggleButton()
   {
      this.isChecked = !this.isChecked;
      redrawButton();
   }
   
   @Override
   public boolean performClick()
   {
      this.isChecked = !this.isChecked;
      redrawButton();
      return super.performClick();
   }
   
   private void redrawButton()
   {
      if(imageOn != 0 && imageOff != 0)
      {
         if(this.isChecked())
            this.setImageResource(this.imageOn);
         else
            this.setImageResource(this.imageOff);
      }
   }
      
}
