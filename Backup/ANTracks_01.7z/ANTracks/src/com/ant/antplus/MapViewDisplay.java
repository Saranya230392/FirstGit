
package com.ant.antplus;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import com.ant.antplus.R;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;

public class MapViewDisplay extends MapActivity{
	public String TAG = "MapViewDisplay";
    private MapView mapView;
    ListView list;    
    Intent intent;
    
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mapview_display);
        mapView = (MapView)findViewById(R.id.mapview);
    }
    public void myClickHandler(View target){
        switch(target.getId()){
            case R.id.zoomin:
                 mapView.getController().zoomIn();
                 break;
            case R.id.zoomout:
                 mapView.getController().zoomOut();
                 break;
            case R.id.sat:
                 mapView.setStreetView(true);
                 break;
            case R.id.street:
                Log.d(TAG, "switch:street");
                intent = new Intent(this, ListFromArray.class);                                                         
                startActivity(intent);
                break;
            case R.id.traffic:
        }
    }
    @Override
    protected boolean isLocationDisplayed(){
        return false;
    }
    @Override
    protected boolean isRouteDisplayed() {
        // TODO Auto-generated method stub
        return false;
    }     
}
