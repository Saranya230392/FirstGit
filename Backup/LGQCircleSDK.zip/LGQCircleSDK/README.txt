                                   README

                LG QCircle SDK, Android API Level 19, Revision 1

Contents

- Introduction
- Samples
- Documentation



Introduction
------------

     The LG QCircle SDK provides open APIs to developers so that their applications 
     can use QuickCircle UX features. Using these APIs, developers can create applications 
     that run in a window of the QuickCircle case.
     
     The LG QCircle SDK includes the following components:

      - Documentation: LG QCircle SDK developer guide. 
      - Samples: A sample application and its source codes. 
      - Emulator: Plug-in Android emulator for tests (To be added). 


Samples
------------

      This SDK includes sample codes that describe how to use QCircle APIs.

      Samples are located in <install_dir>/samples directory.

      


Documentation
-------------


     This SDK includes documentation that provides the LG QCircle API references and the 
     explanation for implementing an application with the QCircle SDK.

     Documentation is located in <install_dir>/doc directory. 




------------------------------------------------------------------------

LG Developer

http://developer.lge.com
