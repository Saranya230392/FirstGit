package com.sample.qcircle.qrcc;

import com.example.myqcirclesample.R;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

public class FullScreenActivity extends Activity{
	
	WebView browser;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_fullscreen);
		browser = (WebView) findViewById(R.id.lgdev_view);
		browser.loadUrl("http://developer.lge.com");
			
	}
}
