package com.lge.handwritingime;


import jp.co.omronsoft.iwnnime.ml.InputMethodBase;
import jp.co.omronsoft.iwnnime.ml.InputMethodSwitcher;
import android.inputmethodservice.InputMethodService;

public class KeyboardParent extends InputMethodBase {
    public KeyboardParent(InputMethodService ims) {
        super((InputMethodSwitcher)ims);
    }
    
    public KeyboardParent() {
        super(null);
    }
    
    public String getString(int resId) {
        return getResources().getString(resId);
    }
}
