package com.lge.sps;

import android.content.Intent;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.SwitchPreference;
import android.provider.Settings;

import android.util.*;

import com.lge.spsmainactivity.R;

public class PowerSaveSettingActivity extends PreferenceActivity implements Preference.OnPreferenceChangeListener, OnPreferenceClickListener{
	private static final String TAG = "PowerSaveSettingActivity";
	
    private static final String KEY_MODE_SETTING_BACKLIGHT_CATEGORY = "mode_setting_backlight_category";
    private static final String KEY_MODE_SETTING_SCREEN_CATEGORY = "mode_setting_screen_category";
    private static final String KEY_MODE_SETTING_NETWORK_CATEGORY = "mode_setting_network_category";
    private static final String KEY_MODE_SETTING_PERPORMANCE_CATEGORY = "mode_setting_performance_category";
    private static final String KEY_MODE_SETTING_DEPENDING_CATEGORY = "mode_setting_depending_category";
    private static final String KEY_MODE_BACKLIGHT_ADJUST = "mode_backlight_adjust";
    private static final String KEY_MODE_SETTING_LED_VIB_CATEGORY = "mode_setting_led_vib_category";
    
    private static final String KEY_SCREEN_TURNOFF_TIME = "mode_screen_turnoff_time";
    private static final String KEY_SCREEN_ROTATION = "mode_screen_rotation";
    private static final String KEY_SCREEN_ANIMATION = "mode_screen_animation";
    
    private static final String KEY_NETWORK_WIFI = "mode_network_wifi";
    private static final String KEY_NETWORK_BT = "mode_network_bt";
    private static final String KEY_NETWORK_GPS = "mode_network_gps";
    private static final String KEY_NETWORK_WIFI_TETHERING = "mode_network_wifi_tethering";
    private static final String KEY_NETWORK_DATA = "mode_network_data";
    
    private static final String KEY_PERFORMANCE_CPU = "mode_performance_cpu";
    private static final String KEY_PERFORMANCE_AUTO_SYNC = "mode_performance_auto_sync";

    private static final String KEY_LEDVIB_LED = "mode_led_vib_led";
    private static final String KEY_LEDVIB_VIB = "mode_led_vib_vib";
    
    private static final String KEY_DEPENDING_TIME = "mode_depending_time";
    private static final String KEY_MODE_ENABLE = "mode_enable";
    
    private SwitchPreference mModeEnable;

    private PreferenceCategory mBacklightCategory;
    private PreferenceCategory mScreenCategory;
    private PreferenceCategory mNetworkCategory;
    private PreferenceCategory mPerformanceCategory;
    private PreferenceCategory mLedVibCategory;
    private PreferenceCategory mDependingCategory;

    private ListPreference mBacklightAdjust;
    private ListPreference mScreenTimeout;
    
    private Preference mDependingTime;	

    private CheckBoxPreference mScreenRotation;
    private CheckBoxPreference mScreenAnimation;
    private CheckBoxPreference mNetworkWifi;
    private CheckBoxPreference mNetworkBt;
    private CheckBoxPreference mNetworkGps;
    private CheckBoxPreference mNetworkWifiTethering;
    private CheckBoxPreference mNetworkData;
    private CheckBoxPreference mPerformanceCpu;
    private CheckBoxPreference mPerformanceAutoSync;
    private CheckBoxPreference mLedVibLed;
    private CheckBoxPreference mLedVibVib;
	
    private final int mNormalIdBackLight = R.string.set_mode_backlight_adjust_dont_change;
    private final int mChangeIdBackLight = R.string.set_mode_backlight_adjust_summary;
    private final int mNormalIdScreen = R.string.set_mode_screen_turnoff_time_dont_change;
    private final int mChangeIdScreen = R.string.set_mode_screen_turnoff_time_summary;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initPreference();
    }

    @Override
    public void onResume() {
        super.onResume();
        checkPreference();
        summaryPreference();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void initPreference() {
        addPreferencesFromResource(R.layout.powersave_setting_mode);
        mModeEnable = (SwitchPreference)findPreference(KEY_MODE_ENABLE);
        mModeEnable.setOnPreferenceChangeListener(this);
        
        mBacklightCategory = (PreferenceCategory)findPreference(KEY_MODE_SETTING_BACKLIGHT_CATEGORY);
        mScreenCategory = (PreferenceCategory)findPreference(KEY_MODE_SETTING_SCREEN_CATEGORY);
        mNetworkCategory = (PreferenceCategory)findPreference(KEY_MODE_SETTING_NETWORK_CATEGORY);
        mPerformanceCategory = (PreferenceCategory)findPreference(KEY_MODE_SETTING_PERPORMANCE_CATEGORY);
        mLedVibCategory = (PreferenceCategory)findPreference(KEY_MODE_SETTING_LED_VIB_CATEGORY);
        mDependingCategory = (PreferenceCategory)findPreference(KEY_MODE_SETTING_DEPENDING_CATEGORY);

        mBacklightAdjust = (ListPreference)findPreference(KEY_MODE_BACKLIGHT_ADJUST);
        mBacklightAdjust.setOnPreferenceChangeListener(this);
        mScreenTimeout = (ListPreference)findPreference(KEY_SCREEN_TURNOFF_TIME);
        mScreenTimeout.setOnPreferenceChangeListener(this);
        mPerformanceCpu = (CheckBoxPreference)findPreference(KEY_PERFORMANCE_CPU);
        mPerformanceCpu.setOnPreferenceClickListener(this);
        mDependingTime = (Preference)findPreference(KEY_DEPENDING_TIME);
        mDependingTime.setOnPreferenceClickListener(this);

        mScreenRotation = (CheckBoxPreference)findPreference(KEY_SCREEN_ROTATION);
        mScreenRotation.setOnPreferenceClickListener(this);
        mScreenAnimation = (CheckBoxPreference)findPreference(KEY_SCREEN_ANIMATION);
        mScreenAnimation.setOnPreferenceClickListener(this);
        
        mNetworkWifi = (CheckBoxPreference)findPreference(KEY_NETWORK_WIFI);
        mNetworkWifi.setOnPreferenceClickListener(this);
        mNetworkBt = (CheckBoxPreference)findPreference(KEY_NETWORK_BT);
        mNetworkBt.setOnPreferenceClickListener(this);
        mNetworkGps = (CheckBoxPreference)findPreference(KEY_NETWORK_GPS);
        mNetworkGps.setOnPreferenceClickListener(this);
        mNetworkWifiTethering = (CheckBoxPreference)findPreference(KEY_NETWORK_WIFI_TETHERING);
        mNetworkWifiTethering.setOnPreferenceClickListener(this);
        mNetworkData = (CheckBoxPreference)findPreference(KEY_NETWORK_DATA);
        mNetworkData.setOnPreferenceClickListener(this);
        
        mPerformanceAutoSync = (CheckBoxPreference)findPreference(KEY_PERFORMANCE_AUTO_SYNC);
        mPerformanceAutoSync.setOnPreferenceClickListener(this);
        
        mLedVibLed = (CheckBoxPreference)findPreference(KEY_LEDVIB_LED);
        mLedVibLed.setOnPreferenceClickListener(this);
        mLedVibVib = (CheckBoxPreference)findPreference(KEY_LEDVIB_VIB);
        mLedVibVib.setOnPreferenceClickListener(this);
    }

    private void checkPreference() {
        mModeEnable.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_ON_MODE_ENABLE, 0) == 1);
        preferenceCategoryEnable(mModeEnable.isChecked());
        mScreenRotation.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_ROTATION, 0) == 1);
        mScreenAnimation.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_ANIMATION, 0) == 1);
        mNetworkWifi.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_WIFI, 0) == 1);
        mNetworkBt.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_BT, 0) == 1);
        mNetworkGps.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_GPS, 0) == 1);
        mNetworkWifiTethering.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_WIFI_TETHERING, 0) == 1);
        mNetworkData.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_DATA, 0) == 1);
        mPerformanceAutoSync.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_AUTO_SYNC, 0) == 1);
        mLedVibLed.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_LED, 0) == 1);
        mLedVibVib.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_OFF_VIBRATION, 0) == 1);

        if (Settings.System.getString(getContentResolver(), SpsmodeEx.OPERATION_DEPENDING_TIME) != null) {
            mDependingTime.setTitle(Settings.System.getString(getContentResolver(), SpsmodeEx.OPERATION_DEPENDING_TIME));
        } else {
            mDependingTime.setTitle(R.string.set_mode_depending_time_setting);
        }

        PreferenceDescription.updatePreference(getContentResolver(), mBacklightAdjust, SpsmodeEx.TURN_OFF_BRIGHTNESS,
                mNormalIdBackLight, mChangeIdBackLight);
        PreferenceDescription.updatePreference(getContentResolver(), mScreenTimeout, SpsmodeEx.TURN_OFF_SCREEN_TIMEOUT,
                mNormalIdScreen, mChangeIdScreen);
                
    }

    private void summaryPreference() {
    	android.util.Log.d(TAG, "### summaryPreference ###");
    	
        if (Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_ON_DATA_TOGGLE_ENABLE, 0) == 1) {
            mNetworkData.setSummary(R.string.set_mode_network_data_summary_lcd_off);
        } else {
            mNetworkData.setSummary(R.string.set_mode_network_data_summary_always);
        }

        if (Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_ON_WIFI_TOGGLE_ENABLE, 0) == 1) {
            mNetworkWifi.setSummary(R.string.set_mode_network_wifi_summary_lcd_off);
        } else {
            mNetworkWifi.setSummary(R.string.set_mode_network_wifi_summary_always);
        }

        if (Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_ON_AUTO_SYNC_TOGGLE_ENABLE, 0) == 1) {
            mPerformanceAutoSync.setSummary(R.string.set_mode_performance_auto_sync_summary_lcd_off);
        } else {
            mPerformanceAutoSync.setSummary(R.string.set_mode_performance_auto_sync_summary_always);
        }
    }

	@Override
	public boolean onPreferenceClick(Preference preference) {
		android.util.Log.d(TAG, "### preference : " + preference);
		if (preference.getKey().equals(KEY_PERFORMANCE_AUTO_SYNC)) {
            if (mPerformanceAutoSync.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_AUTO_SYNC, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_AUTO_SYNC, 0);
            }
		}		
        if (preference.getKey().equals(KEY_SCREEN_ROTATION)) {
            if (mScreenRotation.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_ROTATION, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_ROTATION, 0);
            }
        } else if (preference.getKey().equals(KEY_SCREEN_ANIMATION)) {
            if (mScreenAnimation.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_ANIMATION, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_ANIMATION, 0);
            }		 
        } else if (preference.getKey().equals(KEY_NETWORK_WIFI)) {
            if (mNetworkWifi.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_WIFI, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_WIFI, 0);
            }
        } else if (preference.getKey().equals(KEY_NETWORK_BT)) {
            if (mNetworkBt.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_BT, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_BT, 0);
            }
        } else if (preference.getKey().equals(KEY_NETWORK_GPS)) {
            if (mNetworkGps.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_GPS, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_GPS, 0);
            }         
        } else if (preference.getKey().equals(KEY_NETWORK_DATA)) {
            if (mNetworkData.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_DATA, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_DATA, 0);
            }			 
        } else if (preference.getKey().equals(KEY_NETWORK_WIFI_TETHERING)) {
            if (mNetworkWifiTethering.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_WIFI_TETHERING, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_WIFI_TETHERING, 0);
            }			 
        } else if (preference.getKey().equals(KEY_PERFORMANCE_AUTO_SYNC)) {
            if (mPerformanceAutoSync.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_AUTO_SYNC, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_AUTO_SYNC, 0);
            }			 
        } else if (preference.getKey().equals(KEY_LEDVIB_LED)) {
            if (mLedVibLed.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_LED, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_LED, 0);
            }
        } else if (preference.getKey().equals(KEY_LEDVIB_VIB)) {
            if (mLedVibVib.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_VIBRATION, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_VIBRATION, 0);
            }
        } else if (preference.getKey().equals(KEY_PERFORMANCE_CPU)) {
            if (mPerformanceCpu.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_ON_CONTROL_CPU, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_ON_CONTROL_CPU, 0);
            }
        } //else if (preference.getKey().equals(KEY_DEPENDING_TIME)) {
            //startActivity(new Intent(this, SpsmodeToolTimeResult.class));
        //}
        return true;
    }

    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        // TODO Auto-generated method stub
        final String key = preference.getKey();

        if (KEY_SCREEN_TURNOFF_TIME.equals(key)) {
            int value = Integer.parseInt((String) newValue);
            Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_SCREEN_TIMEOUT, value);
            PreferenceDescription.updatePreference(getContentResolver(), mScreenTimeout,
                    SpsmodeEx.TURN_OFF_SCREEN_TIMEOUT, mNormalIdScreen, mChangeIdScreen);
        } else if (KEY_MODE_BACKLIGHT_ADJUST.equals(key)) {
            int value = Integer.parseInt((String) newValue);
            Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_OFF_BRIGHTNESS, value);
            PreferenceDescription.updatePreference(getContentResolver(), mBacklightAdjust,
                    SpsmodeEx.TURN_OFF_BRIGHTNESS, mNormalIdBackLight, mChangeIdBackLight);
        } else if(KEY_MODE_ENABLE.equals(key)) {
            boolean enabled = (Boolean)newValue;
            Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_ON_MODE_ENABLE, enabled ? 1: 0);
            mModeEnable.setChecked(enabled);
            preferenceCategoryEnable(enabled);
        }		
        return true;
    }

    private void preferenceCategoryEnable(boolean enabled) {
        mBacklightCategory.setEnabled(!enabled);
        mScreenCategory.setEnabled(!enabled);
        mNetworkCategory.setEnabled(!enabled);
        mPerformanceCategory.setEnabled(!enabled);
        mLedVibCategory.setEnabled(!enabled);
        mDependingCategory.setEnabled(!enabled);
    }
}
