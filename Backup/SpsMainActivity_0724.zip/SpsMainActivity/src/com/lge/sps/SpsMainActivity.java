package com.lge.sps;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.lge.spsmainactivity.R;

public class SpsMainActivity extends Activity implements OnItemClickListener {

    private ArrayAdapter<String> mAdapter = null;
    private ArrayList<String> mArrayList = new ArrayList<String>();
    private ListView mList = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sps_main);

        mArrayList.add(getResources().getString(R.string.callandsms_mode));
        mArrayList.add(getResources().getString(R.string.powersave_mode));
        //mArrayList.add(getResources().getString(R.string.battery_info));
        //mArrayList.add(getResources().getString(R.string.detail_info));
        //mArrayList.add(getResources().getString(R.string.saving));
        //mArrayList.add(getResources().getString(R.string.tool));

        mAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mArrayList);
        mList = (ListView) findViewById(R.id.listView_main);
        mList.setAdapter(mAdapter);
        mList.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        mList.setOnItemClickListener(this);	
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.sps_main, menu);
		return true;
	}
	
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent mIntent = null;

        switch (position) {
            case 0:
                mIntent = new Intent(SpsMainActivity.this, CallandSmsSettingActivity.class);
                break;
            case 1:
                mIntent = new Intent(SpsMainActivity.this, PowerSaveSettingActivity.class);
                break;
            case 2:
                //mIntent = new Intent(SpsMainActivity.this, AnalysisActivity.class);
                break;
            case 3:
                //mIntent = new Intent(SpsMainActivity.this, OnekeyActivity.class);
                break;
            case 4:
                //mIntent = new Intent(SpsMainActivity.this, SpsmodeToolActivity.class);
                break;
            default:
                break;
        }

        if(mIntent != null) {
            startActivity(mIntent);
        }
    }	
}
