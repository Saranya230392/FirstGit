package com.lge.sps;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.preference.PreferenceManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class BatteryCheck extends Activity{
	  private static final int MENU_ID_MENU1 = 2;
	  private int BattLevel;
	  private String BattStatus;
	  private boolean IgnoreBatteryRemain;
	  private String TAG = "InActiveTestActivity";
	  private Button btnClearLog;
	  private Button btnStart;
	  private Button btnStop;
	  private Button btnUpdateLog;
	  private SharedPreferences.Editor editor;
	  private IntentFilter filter;
	  private Intent intent;
	  private boolean isTaskRunning;
	  private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver()
	  {
	    public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
	    {
	      String str;
	      if (paramAnonymousIntent.getAction().equals("android.intent.action.BATTERY_CHANGED"))
	      {
	        int i = paramAnonymousIntent.getIntExtra("status", 0);
	        int j = paramAnonymousIntent.getIntExtra("level", 0);
	        str = "";
	        switch (i)
	        {
	        default:
	          InActiveTestActivity.this.tvEnvBattRemain.setText(String.valueOf(j) + " %");
	          InActiveTestActivity.this.tvEnvBattStatus.setText(str);
	          if (j == InActiveTestActivity.this.BattLevel)
	            str.equals(InActiveTestActivity.this.BattStatus);
	          InActiveTestActivity.this.update();
	          InActiveTestActivity.this.BattLevel = j;
	          InActiveTestActivity.this.BattStatus = str;
	          if (!InActiveTestActivity.this.IgnoreBatteryRemain)
	          {
	            if ((InActiveTestActivity.this.BattLevel != 100) || (!InActiveTestActivity.this.BattStatus.equalsIgnoreCase("full")))
	              break label255;
	            InActiveTestActivity.this.btnStart.setEnabled(true);
	            InActiveTestActivity.this.notifyfullcharge = true;
	          }
	          break;
	        case 1:
	        case 2:
	        case 3:
	        case 4:
	        case 5:
	        }
	      }
	      label255: 
	      do
	      {
	        return;
	        str = "unknown";
	        break;
	        str = "charging";
	        break;
	        str = "discharging";
	        break;
	        str = "not charging";
	        break;
	        str = "full";
	        break;
	        InActiveTestActivity.this.btnStart.setEnabled(false);
	      }
	      while (InActiveTestActivity.this.notifyfullcharge);
	      AlertDialog.Builder localBuilder = new AlertDialog.Builder(InActiveTestActivity.this);
	      localBuilder.setIcon(17301543);
	      localBuilder.setTitle(2131230879);
	      localBuilder.setMessage(2131230880);
	      localBuilder.setCancelable(true);
	      localBuilder.setNeutralButton("OK", new DialogInterface.OnClickListener()
	      {
	        public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
	        {
	        }
	      });
	      localBuilder.show();
	      InActiveTestActivity.this.notifyfullcharge = true;
	    }
	  };
	  private ServiceConnection mConnection = new ServiceConnection()
	  {
	    public void onServiceConnected(ComponentName paramAnonymousComponentName, IBinder paramAnonymousIBinder)
	    {
	      DebugLog.v(InActiveTestActivity.this.TAG, "ServiceConnection-onServiceConnected()");
	      InActiveTestActivity.this.mService = IInActiveTestService.Stub.asInterface(paramAnonymousIBinder);
	      while (true)
	      {
	        try
	        {
	          InActiveTestActivity.this.isTaskRunning = InActiveTestActivity.this.mService.isTaskRunning();
	          if (InActiveTestActivity.this.isTaskRunning)
	          {
	            InActiveTestActivity.this.btnStart.setEnabled(false);
	            InActiveTestActivity.this.btnStop.setEnabled(true);
	            return;
	          }
	          if ((InActiveTestActivity.this.BattLevel == 100) && (InActiveTestActivity.this.BattStatus.equalsIgnoreCase("full")))
	          {
	            InActiveTestActivity.this.btnStart.setEnabled(true);
	            InActiveTestActivity.this.btnStop.setEnabled(false);
	            return;
	          }
	        }
	        catch (RemoteException localRemoteException)
	        {
	          localRemoteException.printStackTrace();
	          return;
	        }
	        InActiveTestActivity.this.btnStart.setEnabled(false);
	      }
	    }

	    public void onServiceDisconnected(ComponentName paramAnonymousComponentName)
	    {
	      DebugLog.v(InActiveTestActivity.this.TAG, "ServiceConnection-onServiceDisconnected()");
	      InActiveTestActivity.this.mService = null;
	    }
	  };
	  private IInActiveTestService mService;
	  private boolean notifyfullcharge;
	  private SharedPreferences sp;
	  private TextView tvEnvBattLog;
	  private TextView tvEnvBattRemain;
	  private TextView tvEnvBattStatus;

	  private void init()
	  {
	    setContentView(2130903050);
	    this.BattLevel = 0;
	    this.BattStatus = "";
	    this.notifyfullcharge = false;
	    this.intent = new Intent(this, InActiveTestService.class);
	    this.intent.putExtra("option", "from WakeupperActivity");
	    bindService(this.intent, this.mConnection, 1);
	    startService(this.intent);
	    this.btnStart = ((Button)findViewById(2131165263));
	    this.btnStop = ((Button)findViewById(2131165264));
	    this.btnUpdateLog = ((Button)findViewById(2131165265));
	    this.btnClearLog = ((Button)findViewById(2131165266));
	    this.tvEnvBattRemain = ((TextView)findViewById(2131165261));
	    this.tvEnvBattStatus = ((TextView)findViewById(2131165262));
	    this.tvEnvBattLog = ((TextView)findViewById(2131165267));
	    this.btnStart.setEnabled(false);
	    this.btnStop.setEnabled(false);
	    this.filter = new IntentFilter();
	    this.filter.addAction("android.intent.action.BATTERY_CHANGED");
	    this.sp = PreferenceManager.getDefaultSharedPreferences(this);
	    this.editor = this.sp.edit();
	    this.btnUpdateLog.setOnClickListener(new View.OnClickListener()
	    {
	      public void onClick(View paramAnonymousView)
	      {
	        InActiveTestActivity.this.update();
	      }
	    });
	    this.btnClearLog.setOnClickListener(new View.OnClickListener()
	    {
	      public void onClick(View paramAnonymousView)
	      {
	        AlertDialog.Builder localBuilder = new AlertDialog.Builder(InActiveTestActivity.this);
	        localBuilder.setIcon(17301543);
	        localBuilder.setTitle("Warning");
	        localBuilder.setMessage("Clear BatteryLog ?");
	        localBuilder.setCancelable(true);
	        localBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener()
	        {
	          public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
	          {
	            InActiveTestActivity.this.editor.putString("BatteryChanged", "");
	            InActiveTestActivity.this.editor.commit();
	            InActiveTestActivity.this.update();
	          }
	        });
	        localBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener()
	        {
	          public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
	          {
	          }
	        });
	        localBuilder.show();
	      }
	    });
	    this.btnStart.setOnClickListener(new View.OnClickListener()
	    {
	      public void onClick(View paramAnonymousView)
	      {
	        try
	        {
	          InActiveTestActivity.this.mService.start();
	        }
	        catch (RemoteException localRemoteException1)
	        {
	          try
	          {
	            while (true)
	            {
	              InActiveTestActivity.this.isTaskRunning = InActiveTestActivity.this.mService.isTaskRunning();
	              if (!InActiveTestActivity.this.isTaskRunning)
	                break;
	              InActiveTestActivity.this.btnStart.setEnabled(false);
	              InActiveTestActivity.this.btnStop.setEnabled(true);
	              AlertDialog.Builder localBuilder = new AlertDialog.Builder(InActiveTestActivity.this);
	              localBuilder.setIcon(17301543);
	              localBuilder.setTitle(2131230877);
	              localBuilder.setMessage(2131230878);
	              localBuilder.setCancelable(true);
	              localBuilder.setNeutralButton("OK", new DialogInterface.OnClickListener()
	              {
	                public void onClick(DialogInterface paramAnonymous2DialogInterface, int paramAnonymous2Int)
	                {
	                }
	              });
	              localBuilder.show();
	              return;
	              localRemoteException1 = localRemoteException1;
	              localRemoteException1.printStackTrace();
	            }
	          }
	          catch (RemoteException localRemoteException2)
	          {
	            while (true)
	              localRemoteException2.printStackTrace();
	            if (InActiveTestActivity.this.BattLevel != 100)
	              break label197;
	          }
	        }
	        if (InActiveTestActivity.this.BattStatus.equalsIgnoreCase("full"))
	          InActiveTestActivity.this.btnStart.setEnabled(true);
	        while (true)
	        {
	          InActiveTestActivity.this.btnStop.setEnabled(false);
	          return;
	          label197: InActiveTestActivity.this.btnStart.setEnabled(false);
	        }
	      }
	    });
	    this.btnStop.setOnClickListener(new View.OnClickListener()
	    {
	      public void onClick(View paramAnonymousView)
	      {
	        try
	        {
	          InActiveTestActivity.this.mService.stop();
	        }
	        catch (RemoteException localRemoteException1)
	        {
	          try
	          {
	            while (true)
	            {
	              InActiveTestActivity.this.isTaskRunning = InActiveTestActivity.this.mService.isTaskRunning();
	              if (!InActiveTestActivity.this.isTaskRunning)
	                break;
	              InActiveTestActivity.this.btnStart.setEnabled(false);
	              InActiveTestActivity.this.btnStop.setEnabled(true);
	              return;
	              localRemoteException1 = localRemoteException1;
	              localRemoteException1.printStackTrace();
	            }
	          }
	          catch (RemoteException localRemoteException2)
	          {
	            while (true)
	              localRemoteException2.printStackTrace();
	            if (InActiveTestActivity.this.BattLevel != 100)
	              break label131;
	          }
	        }
	        if (InActiveTestActivity.this.BattStatus.equalsIgnoreCase("full"))
	          InActiveTestActivity.this.btnStart.setEnabled(true);
	        while (true)
	        {
	          InActiveTestActivity.this.btnStop.setEnabled(false);
	          return;
	          label131: InActiveTestActivity.this.btnStart.setEnabled(false);
	        }
	      }
	    });
	  }

	  private void update()
	  {
	    String str = this.sp.getString("BatteryChanged", "");
	    this.tvEnvBattLog.setText(str);
	  }

	  public void onCreate(Bundle paramBundle)
	  {
	    super.onCreate(paramBundle);
	    DebugLog.v(this.TAG, "onCreate()");
	    init();
	  }

	  public boolean onCreateOptionsMenu(Menu paramMenu)
	  {
	    paramMenu.add(0, 2, 0, 2131230876);
	    return super.onCreateOptionsMenu(paramMenu);
	  }

	  protected void onDestroy()
	  {
	    super.onDestroy();
	    DebugLog.v(this.TAG, "onDestroy()");
	  }

	  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
	  {
	    switch (paramMenuItem.getItemId())
	    {
	    default:
	      return super.onOptionsItemSelected(paramMenuItem);
	    case 2:
	    }
	    this.btnStart.setEnabled(true);
	    return true;
	  }

	  protected void onPause()
	  {
	    super.onPause();
	    DebugLog.v(this.TAG, "onPause()");
	    unregisterReceiver(this.mBroadcastReceiver);
	  }

	  protected void onRestart()
	  {
	    super.onRestart();
	    DebugLog.v(this.TAG, "onRestart()");
	  }

	  protected void onResume()
	  {
	    super.onResume();
	    DebugLog.v(this.TAG, "onResume()");
	    CommonFunctions.setBrightness(this, 0.5F);
	    registerReceiver(this.mBroadcastReceiver, this.filter);
	  }

	  protected void onStart()
	  {
	    super.onStart();
	    DebugLog.v(this.TAG, "onStart()");
	  }

	  protected void onStop()
	  {
	    super.onStop();
	    DebugLog.v(this.TAG, "onStop()");
	  }
	}

