package com.lge.sps;

import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.preference.PreferenceCategory;
import android.preference.SwitchPreference;
import android.provider.Settings;

import com.lge.spsmainactivity.R;

public class CallandSmsSettingActivity extends PreferenceActivity implements Preference.OnPreferenceChangeListener, OnPreferenceClickListener{

    private static final String KEY_MODE_SETTING_PERPORMANCE_CATEGORY = "mode_setting_performance_category";
        
    private static final String KEY_PERFORMANCE_CPU = "mode_performance_cpu";
    private static final String KEY_MODE_ENABLE = "mode_enable";
    
    private SwitchPreference mModeEnable;
    private PreferenceCategory mPerformanceCategory;
    private CheckBoxPreference mPerformanceCpu;
    private CheckBoxPreference mPerformanceAutoSync;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initPreference();
    }

    @Override
    public void onResume() {
        super.onResume();
        //checkPreference();
        //summaryPreference();
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void initPreference() {
        addPreferencesFromResource(R.layout.callandsms_setting_mode);
        mModeEnable = (SwitchPreference)findPreference(KEY_MODE_ENABLE);
        mModeEnable.setOnPreferenceChangeListener(this);
        
        mPerformanceCpu = (CheckBoxPreference)findPreference(KEY_PERFORMANCE_CPU);
        mPerformanceCpu.setOnPreferenceClickListener(this);                        
    }

    private void checkPreference() {
        mModeEnable.setChecked(Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_ON_MODE_ENABLE, 0) == 1);
        preferenceCategoryEnable(mModeEnable.isChecked());
    }

    private void summaryPreference() {
        if (Settings.System.getInt(getContentResolver(), SpsmodeEx.TURN_ON_AUTO_SYNC_TOGGLE_ENABLE, 0) == 1) {
            mPerformanceAutoSync.setSummary(R.string.set_mode_performance_auto_sync_summary_lcd_off);
        } else {
            mPerformanceAutoSync.setSummary(R.string.set_mode_performance_auto_sync_summary_always);
        }
    }

	@Override
	public boolean onPreferenceClick(Preference preference) {		
		if (preference.getKey().equals(KEY_PERFORMANCE_CPU)) {
            if (mPerformanceCpu.isChecked()) {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_ON_CONTROL_CPU, 1);
            } else {
                Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_ON_CONTROL_CPU, 0);
            }
        } //else if (preference.getKey().equals(KEY_DEPENDING_TIME)) {
//            startActivity(new Intent(this, SpsmodeToolTimeResult.class));
  //      }
        return true;
    }

    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue) {
        // TODO Auto-generated method stub
        final String key = preference.getKey();

        if(KEY_MODE_ENABLE.equals(key)) {
            boolean enabled = (Boolean)newValue;
            Settings.System.putInt(getContentResolver(), SpsmodeEx.TURN_ON_MODE_ENABLE, enabled ? 1: 0);
            mModeEnable.setChecked(enabled);
            preferenceCategoryEnable(enabled);
        }		
        return true;
    }

    private void preferenceCategoryEnable(boolean enabled) {
        mPerformanceCategory.setEnabled(!enabled);
    }
}
