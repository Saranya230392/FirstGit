package com.lge.sps;

import android.content.ContentResolver;
import android.preference.ListPreference;
import android.provider.Settings;

public class PreferenceDescription {

    public static void updatePreference(ContentResolver resolver, ListPreference preference, String key, int normalId, int changeId) {
        int newValue = Settings.System.getInt(resolver, key, -2);
        if (newValue > -2) {
            preference.setValue(String.valueOf(newValue));
        } else {
            return;
        }
        updatePreferenceDescrioption(preference, key, normalId, changeId, newValue);
    }

    private static void updatePreferenceDescrioption(ListPreference preference, String key, int normalId, int changeId, int newValue) {
        String summary;
        if (newValue == -1){
            summary = preference.getContext().getString(normalId);
        } else {
            final CharSequence[] entries = preference.getEntries();
            final CharSequence[] values = preference.getEntryValues();
            if (entries == null || entries.length == 0) {
                summary = "";
            } else {
                int best = 0;
                for (int i = 0; i < values.length; i++) {
                    int timeout = Integer.parseInt(values[i].toString());
                    if (newValue >= timeout) {
                        best = i;
                    }
                }
                summary = preference.getContext().getString(changeId, entries[best]);
            }
        }
        preference.setSummary(summary);
    }
}
