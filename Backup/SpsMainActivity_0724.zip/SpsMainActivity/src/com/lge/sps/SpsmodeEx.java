package com.lge.sps;

public final class SpsmodeEx {

    public static final String TURN_ON_MODE_ENABLE = "turn_on_mode_enable";
    public static final String TURN_OFF_BRIGHTNESS = "turn_off_brightness";
    public static final String TURN_OFF_SCREEN_TIMEOUT = "turn_off_screen_timeout";
    public static final String TURN_OFF_ROTATION = "turn_off_rotation";
    public static final String TURN_OFF_ANIMATION = "turn_off_animation";
    public static final String TURN_OFF_WIFI = "turn_off_wifi";
    public static final String TURN_OFF_BT = "turn_off_bt";
    public static final String TURN_OFF_GPS = "turn_off_gps";
    public static final String TURN_OFF_WIFI_TETHERING = "turn_off_wifi_tethering";
    public static final String TURN_OFF_DATA = "turn_off_data";
    public static final String TURN_ON_CONTROL_CPU = "turn_on_control_cpu";
    public static final String TURN_OFF_AUTO_SYNC = "turn_off_auto_sync";
    public static final String TURN_OFF_LED = "turn_off_led";
    public static final String TURN_OFF_VIBRATION = "turn_off_vibration";
    public static final String OPERATION_DEPENDING_TIME = "operation_depending_time";

    public static final String TURN_ON_DATA_TOGGLE_ENABLE = "turn_on_data_toggle_enable";
    public static final String TURN_OFF_DATA_AFTER_TIME = "turn_off_data_after_time";
    public static final String TURN_ON_DATA_DOWNLOAD_PROTECT = "turn_on_data_download_protect";	

    public static final String TURN_ON_WIFI_TOGGLE_ENABLE = "turn_on_wifi_toggle_enable";
    public static final String TURN_OFF_WIFI_AFTER_TIME = "turn_off_wifi_after_time";
    public static final String TURN_ON_WIFI_DOWNLOAD_PROTECT = "turn_on_wifi_download_protect";

    public static final String TURN_ON_BT_TOGGLE_ENABLE = "turn_on_bt_toggle_enable";
    public static final String BT_CHECKING_INTERVAL = "bt_checking_interval";

    public static final String TURN_ON_BATTERY_CHECK = "turn_on_battery_check";
    public static final String TURN_ON_BATTERY_LEVEl = "turn_on_battery_level";

    public static final String TURN_ON_AUTO_SYNC_TOGGLE_ENABLE = "turn_on_auto_sync_toggle_enable";
    public static final String TURN_OFF_AUTO_SYNC_AFTER_TIME = "turn_off_auto_sync_after_time";
    public static final String AUTO_SYNC_PERIODICALLY = "auto_sync_periodically";

    public static final String KEY_WHITE_LIST = "whiteList";
    public static final String KEY_TIME_LIST = "timeList";
    public static final String SAVE_TIME_LIST = "save_time_list";
    public static final String SAVE_WHITE_LIST = "save_white_list";
}
