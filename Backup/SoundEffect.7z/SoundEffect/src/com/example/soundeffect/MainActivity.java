package com.example.soundeffect;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.support.v4.app.NavUtils;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends Activity {
/** Called when the activity is first created. */

SoundManager sManager;
EditText text;
	@Override
	 public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.main);

          sManager = SoundManager.getInstance();

          sManager.init(this);

          sManager.addSound(1, R.raw.delete);
          sManager.addSound(2, R.raw.keyreturn);
          sManager.addSound(3, R.raw.spacebar);
          sManager.addSound(4, R.raw.standard);
             
          text = (EditText)findViewById(R.id.editText);
             
     }
        

     public void play(View v){
     String msg = null;
     String totalMsg = null;

     switch(v.getId()){
     case R.id.delete : sManager.play(1); msg="1"; break;    
     case R.id.keyreturn : sManager.play(2); msg="2"; break;
     case R.id.spacebar : sManager.play(3); msg="3"; break;
     case R.id.standard : sManager.play(4); msg="4"; break;
     }
     
     text.setText(msg);
     
     }
}
