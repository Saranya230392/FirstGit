/*
 *   MAE Group, Software Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.util;

import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.StringTokenizer;

import android.content.Context;
import android.text.format.DateUtils;
import android.util.Log;

import com.lge.sns.Global;
import com.lge.launcher.R;

/**
 * Common utility class
 * @author mksong1
 *
 */
public class Util {	
	/**
	 * test the two objects are equal or not
	 * @param obj1 object 1
	 * @param obj2 object 2
	 * @return the two objects are equal or not
	 */
	public static boolean equals(Object obj1,Object obj2) {
		return (obj1==null)?(obj2==null):obj1.equals(obj2);
	}
	
	/**
	 * check the string is null or empty string
	 * @param str a string 
	 * @return the string is null or empty string
	 */
	public static boolean isEmpty(String str) {
		return str == null || str.trim().length()==0;
	}
	
	private static String[][] ESCAPE_CHAR = {
		{"&lt;","<"},
		{"&gt;",">"},
		{"&apos;","'"},
		{"&quot;","\""},
		{"&amp;","&"}
	};

	/**
	 * Make a HTTP (or XML) escaped string from a raw string
	 * @param str a raw string
	 * @return a HTTP (or XML) escaped string
	 */
	public static String escape(String str) {
		if (!isEmpty(str)) {
			for (int i=ESCAPE_CHAR.length;i>0;i--) {
				String[] e = ESCAPE_CHAR[i-1];
				str = str.replaceAll(e[1], e[0]);
			}
		}
		return str;
	}
	
	/**
	 * Make a raw string from a HTTP (or XML) escaped string
	 * @param str a HTTP (or XML) escaped string
	 * @return a raw string
	 */
	public static String unescape(String str) {
		if (!isEmpty(str)) {
			for (int i=0;i<ESCAPE_CHAR.length;i++) {
				String[] e = ESCAPE_CHAR[i];
				str = str.replaceAll(e[0], e[1]);
			}
		}
		return str;
	}

	/**
	 * make a empty string if the string is null
	 * @param value a string
	 * @return a empty string if the string is null, or the string if the string is not null
	 */
	public static String nvl(String value) {
		return (value==null)?"":value;
	}
	
	/**
	 * make a comma separated string from a string array
	 * @param strs a string array
	 * @return a comma separated string
	 */
	public static String toString(String[] strs) {
		if (strs!=null && strs.length>0) {
			StringBuffer sb = new StringBuffer(strs[0]);
			for (int i=1;i<strs.length;i++) {
				sb.append(",").append(strs[i]);
			}
			return sb.toString();
		}
		return null;
	}

	/**
	 * get the last segment separated by a separator from a string
	 * @param str a string 
	 * @param sep a separator
	 * @return the last segment separated by a separator
	 */
	public static String getLastSegment(String str, String sep) {
		int index = str.lastIndexOf(sep);		
		return (index!=-1)? str.substring(index+sep.length()):str;
	}
	
	/**
	 * remove a query string from a uri string
	 * @param uri a uri string
	 * @return a uri string without query string 
	 */
	public static String removeQuery(String uri) {
		if (uri!=null) {
			int index = uri.indexOf('?');
			if (index!=-1) {
				return uri.substring(0, index);
			}
		}
		return uri;
	}
	
	/**
	 * get a Relative Time Span String
	 * @param context Application or Activity context
	 * @param from base time
	 * @param to compare time
	 * @return a Relative Time Span String
	 */
	public static String getRelativeTimeSpanString(Context context, Date from, Date to)	{
		return getRelativeTimeSpanString(context, from, to, false);
	}
	
	/**
	 * get a Relative Time Span String
	 * Myspace ��� �ð��� �ʴ����� Just now �� �ϰ� ������
	 * @param context
	 * @param from
	 * @param to
	 * @param snsId
	 * @return
	 */
	public static String getRelativeTimeSpanString(Context context, Date from, Date to, String snsId)	{
		
			DateFormat dateFormatter = android.text.format.DateFormat.getDateFormat(context);
			
			long timeFrom = from.getTime();
			long timeTo = to.getTime();

			if ( timeFrom > timeTo ) {  //usage error
				timeFrom = timeTo;
			
				CharSequence elapsedTimeText = DateUtils.getRelativeTimeSpanString(timeFrom,
						timeTo, DateUtils.SECOND_IN_MILLIS);
			
				return elapsedTimeText.toString();
			}
			
			// seconds.
			long diff = (timeTo - timeFrom) / 1000;
			if (diff < 60) {
				CharSequence elapsedTimeText = DateUtils.getRelativeTimeSpanString(timeFrom,
						timeTo, DateUtils.SECOND_IN_MILLIS);
				 if(snsId != null && snsId.equals(Global.SNS_TWITTER)) {
					return "less than " + elapsedTimeText.toString();
				}  else if (snsId != null && snsId.equals(Global.SNS_MYSPACE)) {
					return "Just now";
				}		
				return elapsedTimeText.toString();
			}		
			
			// minutes.
			diff = diff / 60;
			if (diff < 60) {
				CharSequence elapsedTimeText = DateUtils.getRelativeTimeSpanString(timeFrom,
						timeTo, DateUtils.MINUTE_IN_MILLIS); 
				
				if (snsId != null && snsId.equals(Global.SNS_MYSPACE)) {
					return context.getString(R.string.posted) +" "+ elapsedTimeText.toString();
				}
				
				return elapsedTimeText.toString();
			}

			// hours
			diff = diff / 60;
			if (diff < 24) {
				
				CharSequence elapsedTimeText = DateUtils.getRelativeTimeSpanString(timeFrom,
						timeTo, DateUtils.HOUR_IN_MILLIS);
				
				if(snsId != null && snsId.equals(Global.SNS_TWITTER)) {
					return  context.getString(R.string.about)+ " " + elapsedTimeText.toString();
				}  else if (snsId != null && snsId.equals(Global.SNS_MYSPACE)) {
					return context.getString(R.string.posted) +" " + elapsedTimeText.toString();
				}
				return elapsedTimeText.toString();
			}

			
			return getFormattedTimeSpanStringForFB(from);
		}
			
		

	
	/**
	 * get a Relative Time Span String
	 * @param context Application or Activity context
	 * @param from base time
	 * @param to compare time
	 * @param displayTime display the time string or not
	 * @return a Relative Time Span String
	 */
	public static String getRelativeTimeSpanString(Context context, Date from, Date to, boolean displayTime)	{
		DateFormat dateFormatter = android.text.format.DateFormat.getDateFormat(context);
		DateFormat timeFormatter =	android.text.format.DateFormat.getTimeFormat(context);
		
		long timeFrom = from.getTime();
		long timeTo = to.getTime();

		if ( timeFrom > timeTo ) {  //usage error
			timeFrom = timeTo;
		
			CharSequence elapsedTimeText = DateUtils.getRelativeTimeSpanString(timeFrom,
					timeTo, DateUtils.SECOND_IN_MILLIS);
		
			return elapsedTimeText.toString();
		}
		
		// seconds.
		long diff = (timeTo - timeFrom) / 1000;
		if (diff < 60) {
			CharSequence elapsedTimeText = DateUtils.getRelativeTimeSpanString(timeFrom,
					timeTo, DateUtils.SECOND_IN_MILLIS);
			return elapsedTimeText.toString();
		}		
		
		// minutes.
		diff = diff / 60;
		if (diff < 60) {
			CharSequence elapsedTimeText = DateUtils.getRelativeTimeSpanString(timeFrom,
					timeTo, DateUtils.MINUTE_IN_MILLIS);
			return elapsedTimeText.toString();

		}

		// hours
		diff = diff / 60;
		if (diff < 24) {
			CharSequence elapsedTimeText = DateUtils.getRelativeTimeSpanString(timeFrom,
					timeTo, DateUtils.HOUR_IN_MILLIS);
			return elapsedTimeText.toString();
		}
		
		return (displayTime)? dateFormatter.format(from) + " " + timeFormatter.format(from) : dateFormatter.format(from);
	}
	
	public static String getFormattedTimeSpanString(Date unFormattedtime) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm aaa");
		return sdf.format(unFormattedtime); 
	}
	
	public static String getFormattedTimeSpanStringForFB(Date unFormattedtime) {
		SimpleDateFormat sdf = new SimpleDateFormat("MMM dd 'at' HH:mm aaa");
		return sdf.format(unFormattedtime); 
	}
	
	
	
	/**
	 * load a properties
	 * @param prop a Properties object
	 * @param resName properties file name 
	 */
	public static void loadProperties(Properties prop, String resName) {
		InputStream is = Util.class.getResourceAsStream(resName);
		if (is!=null) {
			try {
				try {
					Properties pp = new Properties();
					pp.load(is);
					prop.putAll(pp);
				} finally {
					is.close();
				}
			} catch (IOException e) {
				// never happen!
			}
		}
		
	}
	
	/**
	 * �Էµ� String�� Delimeter�� ��ũ����¡ �Ͽ� ��ũ����¡�� ��ū���� String
	 * �迭�� ��ȯ�Ѵ�.
	 * @param pm_sString
	 * @param pm_sDelimeter
	 * @return
	 */
	public static String[] getTokens(String pm_sString, String pm_sDelimeter) {
		StringTokenizer lm_oTokenizer = new StringTokenizer(pm_sString, pm_sDelimeter);
		String[] lm_sReturns = new String[lm_oTokenizer.countTokens()];
		for(int i=0; lm_oTokenizer.hasMoreTokens(); i++) {
			lm_sReturns[i] = lm_oTokenizer.nextToken().trim();	
		}
		return lm_sReturns;
	}
	
	
	
	
	
	static long oldTime = 0;
	static int count = 0;
	static long totalElapsedTime = 0;
	/**
	 * Timestamp Logging for performance test
	 * @param srcPosition �ҽ����� �̸��̳� ��ġ ( "���ϸ� �޼ҵ�� begin" �Ǵ� "���ϸ� �޼ҵ�� finish" ���·� space�� �����ڷ� �� )
	 * @param flag �ʱ�ȭ ����
	 * 
	 * ���� : Util.logTimeDifference(getClass().getSimpleName()+" getFeedList():run() begin", false);	
	 * 
	 */
	public static void logTimeDifference(String srcPosition) {
		long unitElapsedTime = 0;
			
		srcPosition = srcPosition.replaceAll(",", "").replaceAll("  ", " ").replaceAll("  ", " ").replaceAll("  ", " ").replaceAll(" ", ",");
		
		long nowTime = System.currentTimeMillis();
		if ( oldTime == 0){
			unitElapsedTime = 0;
		}else{
			unitElapsedTime = nowTime-oldTime;
		}
		//Log.d("Performance", "["+count+"],"+srcPosition+",now="+(new SimpleDateFormat("HH:mm:ss").format(new Date(nowTime)))+",diff="+ (unitElapsedTime/1000) + ",total="+(totalElapsedTime/1000));
		Log.d("Performance", "["+count+"],"+srcPosition+",now="+(new SimpleDateFormat("HH:mm:ss").format(new Date(nowTime)))+",diff="+ (unitElapsedTime) + ",total="+(totalElapsedTime));
		
		oldTime = nowTime;
		count++;
		totalElapsedTime+=unitElapsedTime;
		
	} 
	public static void resetLogTimeDifference() {
		oldTime = 0;
		count = 0;
		totalElapsedTime = 0;
	}
	
	/**
	 * html Ư�� ���ڸ� ��ȯ
	 * @param pm_sSrc
	 * @return
	 */
	public static String convertHtmlChar(String pm_sSrc) {
		if(pm_sSrc == null) return "";
		pm_sSrc = pm_sSrc.replaceAll("&lt;", "<");
		pm_sSrc = pm_sSrc.replaceAll("&gt;", ">");
		pm_sSrc = pm_sSrc.replaceAll("&amp;", "&");
		pm_sSrc = pm_sSrc.replaceAll("&nbsp;", " ");
		pm_sSrc = pm_sSrc.replaceAll("&apos;", "\'");
		pm_sSrc = pm_sSrc.replaceAll("&quot;", "\"");
        return pm_sSrc;
	}
	
	/**
	 * ���ڿ��� ���ڷ� �Ľ̰����� �������� �˻�.<br>
	 * @param iWantInt
	 * @return
	 */
	public static boolean availParseInt(String iWantInt) {
		try {
			if( iWantInt == null || iWantInt.equals("") ) throw new NumberFormatException();
			Integer.parseInt(iWantInt);
		} catch(NumberFormatException e) {
			return false;
		}
		return true;
	}	
	
	/**
	 * ���ڿ��� ���ڷ� �Ľ̰����� �������� �˻�.<br>
	 * @param iWantInt
	 * @return
	 */
	public static boolean availParseLong(String iWantInt) {
		try {
			if( iWantInt == null || iWantInt.equals("") ) throw new NumberFormatException();
			Long.parseLong(iWantInt);
		} catch(NumberFormatException e) {
			return false;
		}
		return true;
	}
	
	/**
	 * ���ڿ��� int �� ����
	 * @param pm_sStringNumber
	 * @return
	 */
	public static int parseInt(String pm_sStringNumber) {
		if (availParseInt(pm_sStringNumber))
			return Integer.parseInt(pm_sStringNumber);
		else
			return 0;
	}
	
	/**
	 * ���ڿ��� long �� ����
	 * @param pm_sStringNumber
	 * @return
	 */
	public static long parseLong(String pm_sStringNumber) {
		if (availParseLong(pm_sStringNumber))
			return Long.parseLong(pm_sStringNumber);
		else
			return 0;
	}
	

	/**
	 * dip ���� px�� ��ȯ
	 * @param dip 
	 * @param c 
	 * @return mConvertPx
	 */
	public static int convertToPixel(int dip, Context c) {
		// Convert the dips to pixels
		float scale = c.getResources().getDisplayMetrics().density;
		int mConvertPx = (int) (dip * scale + 0.5f); 
		return mConvertPx;
	}
	
	/**
	 * pixel ����  dip�� ��ȯ
	 * @param px 
	 * @param c 
	 * @return mConvertDip
	 */
	public static int convertToDip (int px, Context c) {
		// Convert the pixels to dips
		float scale = c.getResources().getDisplayMetrics().density;
		int mConvertDip = (int)(px/scale);// ((px -0.5f)/scale);
		return mConvertDip;
	}	
	
	/**
	 * density ��ȯ
	 * @param px 
	 * @param c 
	 * @return mConvertDip
	 */
	public static float getDensity (Context c) {
		float scale = c.getResources().getDisplayMetrics().density;
		return scale;
	}	
}
