/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.util;

/**
 * Constant
 * @author dohwaji
 *
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.01.13    dohwaji             Initial Release
 *   
 */
public class Constants {

	//snsId
	public static final String SNS_FACEBOOK = "fb";
	public static final String SNS_TWITTER  = "tw";
	public static final String SNS_MYSPACE  = "ms";
	public static final String SNS_ORKUT    = "ok";
}

