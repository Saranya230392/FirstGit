/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns;


public class Global {

    
	// =======================================
	// Common definitions
	// =======================================

	public static final String KEY_SNS_ID = "sns_id";	

	// SNS ������ ID
	public static final String SNS_FACEBOOK = "fb";
	public static final String SNS_TWITTER = "tw";
	public static final String SNS_MYSPACE = "ms";
	public static final String SNS_ORKUT = "ok";
	public static final String SNS_BEBO = "bb";


	// �б� �ִ밪 ����
	public static final int DEFAULT_MAX_FEED = 25;
	
	
}
