/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 *
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.04.02    jh83.kim            Feed Widget Initial Release
 *
 */
package com.lge.sns.client.widget.FeedWidget;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.RemoteException;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;

import com.lge.launcher.R;
import com.lge.sns.Global;
import com.lge.sns.agent.account.AccountInfo;
import com.lge.sns.agent.feed.Feed;
import com.lge.sns.agent.feed.FeedAttachment;
import com.lge.sns.agent.profile.Profile;
import com.lge.sns.client.UIConst;
import com.lge.sns.content.profile.ProfileContentAdapter;
import com.lge.sns.remoteservice.account.RemoteAccountService;
import com.lge.sns.remoteservice.feed.RemoteFeedService;
import com.lge.sns.remoteservice.profile.RemoteProfileService;
import com.lge.sns.service.account.IAccountService;
import com.lge.sns.service.account.IAccountServiceCallback;
import com.lge.sns.service.feed.IFeedService;
import com.lge.sns.service.feed.IFeedServiceCallback;
import com.lge.sns.service.profile.IProfileService;
import com.lge.sns.util.Util;

/**
 * Feed Widget ����
 * 
 * @author jh83.kim
 *  
 */
public class FeedWidget extends LinearLayout {	
	
    public static final int SNS_HOME_REQUEST = 1;
    
	//account service
	public RemoteAccountCallback accountCallback;
	
	//profile service
	public RemoteProfileCallback profileCallback;
	
	//profile service
	public RemoteFeedCallback feedCallback;
   
    final String  LIST_WIDGET_FEED_ID           = "list_widget_feed_id";
    final String  LIST_WIDGET_FRIENDS_AVATAR    = "list_widget_friends_avatar";
    final String  LIST_WIDGET_FRIENDS_NAME      = "list_widget_friends_name";
    final String  LIST_WIDGET_COMMENT           = "list_widget_comment";    
    final String  LIST_WIDGET_FRIENDS_MOOD      = "list_widget_friends_mood";    
    final String  LIST_WIDGET_FRIENDS_MOOD_ICON = "list_widget_friends_mood_icon";   
    final String  LIST_WIDGET_FRIENDS_ICON      = "list_widget_friends_icon";    
    final String  LIST_WIDGET_FRIENDS_PUBLISHED = "list_widget_friends_published";
    
    //JNR_SungHwa.Woo �� sns�� ListView
    private ListView fb_feed_list;
    private ListView tw_feed_list;
    private ListView ms_feed_list;
    
    private HashMap<String, Object> mAvatarList = new HashMap<String, Object>();
    
    FaceBookAdapter m_fbAdapter = null;
    TwitterAdapter  m_twAdapter = null;
    MySpaceAdapter  m_msAdapter = null;
    // ------------------------------------------------------
        
    private static final String TAG = "FeedWidget";

    private  List<Profile> m_profile = new ArrayList<Profile>();
    
    private  ArrayList<Feed> m_FBfeedList = new ArrayList<Feed>();
    private  ArrayList<Feed> m_TWfeedList = new ArrayList<Feed>();
    private  ArrayList<Feed> m_MSfeedList = new ArrayList<Feed>();
    
    private  List<AccountInfo> m_accountList;

    private Handler uiHandler = null;

    List<Feed> tempList = new ArrayList<Feed>();
    private List<String> userId = new ArrayList<String>();
    private List<String> snsId = new ArrayList<String>();
    private List<String> ownerId = new ArrayList<String>();
    List<FeedAttachment> attachList = new ArrayList<FeedAttachment>();
    static public boolean verify;
    AccountInfo account;

    /**
     * -1 : default. 
     * 0 : getting feed list
     * 1 : complete to get feed list
     * 2 : cannot get feed list because not login
     */
    private int[] tabInfo = {-1,-1,-1};
    private int tab_index = 0;
    
    private boolean isFirst = true;
    private boolean isRefresh = false;
    private String tabSnsId;
    private String currentUserId = "";
    private int refreshButtonView;

	private LinearLayout widget_service_btn;

	private LinearLayout widget_one_service_btn;

	private LinearLayout widget_no_service_btn;

	private LinearLayout widget_one_facebook_btn_p;

	private LinearLayout widget_one_twitter_btn_p;

	private LinearLayout widget_one_twitter_btn_n;

	private LinearLayout widget_one_facebook_btn_n;

	private LinearLayout widget_one_myspace_btn_n;

	private LinearLayout widget_one_myspace_btn_p;

	private LinearLayout widget_friends_body_fb;
	
	private LinearLayout widget_friends_body_tw;

	private LinearLayout widget_friends_body_ms;

	private LinearLayout widget_no_body;

	private LinearLayout widget_no_account;

	private LinearLayout widget_account_logout;

	private LinearLayout widget_wait_loading;

	private LinearLayout widget_refresh_view;

	private Button widget_bottom_view;

	private Button widget_bottom_no_account;

	private LinearLayout widget_bottom_loading;

	private ImageView widget_each_update;
	
	private ImageView widget_each_update_disable;

	private LinearLayout widget_facebook_btn_n;

	private LinearLayout widget_facebook_btn_p;

	private LinearLayout widget_twitter_btn_p;

	private LinearLayout widget_twitter_btn_n;

	private LinearLayout widget_myspace_btn_p;

	private LinearLayout widget_myspace_btn_n;
	
	private ProgressBar widget_progressbar;
	
	private TextView refreshed_time;

	private TextView refreshed_time_loading;
	
	private ImageView widget_home_icon;
	
	private Context ctx;
		
	private OnLongClickListener longToWidget = new OnLongClickListener() {
        
        public boolean onLongClick(View arg0) {
            FeedWidget.this.performLongClick();
            return false;
        }
    };
    
    
    
    private OnItemLongClickListener itemlongToWidget = new OnItemLongClickListener() {
        
        public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
            FeedWidget.this.performLongClick();
            return false;
        }
    };
    
	public FeedWidget(Context context) {
		super(context);
		ctx = getContext();
	}
	
	public FeedWidget(Context context, AttributeSet attrs) {
		super(context, attrs);
		ctx = getContext();
	}
	
    public void onFinishInflate() {
        super.onFinishInflate();
        Log.d(TAG, "onFinishInflate");
        
        
    }

    
    /**
     * tab �ʱ�ȭ �� tab click event ó��.
     */
    private void tabInit()
    {
    	createTap(tabSnsId);
        isRefresh = true;
        isFirst = false;
//        m_FBfeedList.clear();  
//        m_TWfeedList.clear();  
//        m_MSfeedList.clear();  
        
        
        // for Feed ListView -------------------------------
        prepareFeedsList(tabSnsId);
    	widgetInit();
    	waitLoadingWidget();
    }
    
    public void onAttachedToWindow() 
    {
        super.onAttachedToWindow();
        
        initViews();
        
        //feedService connect
        connectFeedService();
        
        //profileService connect
        connectProfileService();
        
        //accountService connect
        connectAccountService();
        
        if (uiHandler == null) {
            uiHandler = new Handler();
        }
        
        //FaceBook
        widget_one_facebook_btn_p.setOnClickListener(new OnClickListener() 
        {
            public void onClick(View arg0) {
            	tabSnsId = Global.SNS_FACEBOOK;
            	tabInit();
            }
        });
        widget_one_facebook_btn_p.setOnLongClickListener(longToWidget);
        
        widget_facebook_btn_p.setOnClickListener(new OnClickListener() 
        {
            public void onClick(View arg0) {
            	tabSnsId = Global.SNS_FACEBOOK;
            	tabInit();
            }
        }); 
        widget_one_facebook_btn_p.setOnLongClickListener(longToWidget);
                
        //Twitter
        widget_one_twitter_btn_p.setOnClickListener(new OnClickListener() 
        {
            public void onClick(View arg0) {
            	tabSnsId = Global.SNS_TWITTER;
            	tabInit();
            }
        });
        widget_one_twitter_btn_p.setOnLongClickListener(longToWidget);
        
        widget_one_twitter_btn_p.setOnLongClickListener(longToWidget);
        
        widget_twitter_btn_p.setOnClickListener(new OnClickListener() 
        {
            public void onClick(View arg0) {
            	tabSnsId = Global.SNS_TWITTER;
            	tabInit();
            }
        }); 
        widget_one_twitter_btn_p.setOnLongClickListener(longToWidget);
        
        //MySpace
        widget_one_myspace_btn_p.setOnClickListener(new OnClickListener() 
        {
            public void onClick(View arg0) {
            	tabSnsId = Global.SNS_MYSPACE;
            	tabInit();
            }
        });
        widget_one_myspace_btn_p.setOnLongClickListener(longToWidget);
        
        widget_myspace_btn_p.setOnClickListener(new OnClickListener() 
        {
            public void onClick(View arg0) {
            	tabSnsId = Global.SNS_MYSPACE;
            	tabInit();
            }
        });
        widget_myspace_btn_p.setOnLongClickListener(longToWidget);
    }

    
    public void onDetachedFromWindow() {
    	//Detach �ɶ��� Listener ��� ����. 
        if(accountCallback!=null)
            accountCallback.removeAccountUpdateListener();
        
        if(m_accountList != null)
        {
            for (int i = 0; i < m_accountList.size(); i++) {
                feedCallback.removeFeedUpdateListener(m_accountList.get(i).getSnsId());            
            }
        }
        
    }
    
    /**
     * View ���� ���� �ʱ�ȭ.
     */
    private void initViews() {

    	//List
    	fb_feed_list = (ListView)findViewById(R.id.fb_feed_list);
    	tw_feed_list = (ListView)findViewById(R.id.tw_feed_list);
    	ms_feed_list = (ListView)findViewById(R.id.ms_feed_list);
        
    	BitmapDrawable bd = (BitmapDrawable)getResources().getDrawable(R.drawable.homescreen_feed_list_line);
    	fb_feed_list.setDivider(bd);
    	tw_feed_list.setDivider(bd);
    	ms_feed_list.setDivider(bd);
    	
    	fb_feed_list.setCacheColorHint(0);
    	tw_feed_list.setCacheColorHint(0);
    	ms_feed_list.setCacheColorHint(0);

    	//button =========================================
        widget_service_btn = (LinearLayout) findViewById(R.id.widget_service_btn);
        widget_one_service_btn = (LinearLayout) findViewById(R.id.widget_one_service_btn);
        widget_no_service_btn = (LinearLayout) findViewById(R.id.widget_no_service_btn);

        widget_one_facebook_btn_p = (LinearLayout) findViewById(R.id.widget_one_facebook_btn_p);
        widget_one_twitter_btn_p = (LinearLayout) findViewById(R.id.widget_one_twitter_btn_p);
        widget_one_myspace_btn_p = (LinearLayout) findViewById(R.id.widget_one_myspace_btn_p);

        widget_one_facebook_btn_n = (LinearLayout) findViewById(R.id.widget_one_facebook_btn_n);
        widget_one_twitter_btn_n = (LinearLayout) findViewById(R.id.widget_one_twitter_btn_n);
        widget_one_myspace_btn_n = (LinearLayout) findViewById(R.id.widget_one_myspace_btn_n);
        
        //tab�� list ȭ��.
    	widget_friends_body_fb = (LinearLayout) findViewById(R.id.widget_friends_body_fb);
    	widget_friends_body_tw = (LinearLayout) findViewById(R.id.widget_friends_body_tw);
    	widget_friends_body_ms = (LinearLayout) findViewById(R.id.widget_friends_body_ms);
    	
    	widget_no_body = (LinearLayout) findViewById(R.id.widget_no_body);
    	widget_no_account = (LinearLayout) findViewById(R.id.widget_no_account);
    	
    	widget_account_logout = (LinearLayout) findViewById(R.id.widget_account_logout);
    	widget_wait_loading = (LinearLayout) findViewById(R.id.widget_wait_loading);
    	widget_refresh_view = (LinearLayout) findViewById(R.id.widget_refresh_view);
    	widget_bottom_view = (Button) findViewById(R.id.widget_bottom_view);
    	widget_bottom_no_account = (Button) findViewById(R.id.widget_bottom_no_account);
    	widget_bottom_loading = (LinearLayout) findViewById(R.id.widget_bottom_loading);   
    	    	
    	widget_each_update = (ImageView) findViewById(R.id.widget_each_update);  
    	widget_each_update_disable = (ImageView) findViewById(R.id.widget_each_update_disable);  
    	
    	widget_facebook_btn_n = (LinearLayout) findViewById(R.id.widget_facebook_btn_n);  
    	widget_facebook_btn_p = (LinearLayout) findViewById(R.id.widget_facebook_btn_p);  
    	widget_twitter_btn_p = (LinearLayout) findViewById(R.id.widget_twitter_btn_p);  
    	widget_twitter_btn_n = (LinearLayout) findViewById(R.id.widget_twitter_btn_n);  
    	widget_myspace_btn_p = (LinearLayout) findViewById(R.id.widget_myspace_btn_p);  
    	widget_myspace_btn_n = (LinearLayout) findViewById(R.id.widget_myspace_btn_n);  
    	
    	widget_progressbar  = (ProgressBar) findViewById(R.id.widget_progressbar);     	
    	refreshed_time = (TextView) findViewById(R.id.refreshed_time); 
    	refreshed_time_loading = (TextView) findViewById(R.id.refreshed_time_loading); 
    	
    	widget_home_icon = (ImageView) findViewById(R.id.widget_home_icon);
	}

	private void widgetInit() 
	{
        Log.d(TAG, "widgetInit");
        
        if (snsId.size() < 1) 
        {
            return;
        }
        else
        {
            if (isFirst) 
            {
                createTap(snsId.get(0));
                waitLoadingWidget();
                isFirst = false;    
            }
            
            int isLogin = 0;
            for (int inx = 0; inx < m_accountList.size(); inx++) 
            {
                account = m_accountList.get(inx);

                // �ʱ⿡ �Ѿ�� sns���̶� account sns�� ������
                if (tabSnsId.equals(account.getSnsId())) 
                {
                    if (account.isMain()) 
                    {
                        tab_index = inx;
                        
                        isLogin = accountCallback.checkLogin(account.getSnsId());
                        if (isLogin == 1) 
                        {
                            Log.d(TAG, "MAIN + LOGIN");
                            
                            
                            widgetStartInit(account.getSnsId());//data ������� 
                            
                            continue;
                        } 
                        else 
                        {
                            Log.d(TAG, "MAIN + LOGOUT");
                            
                            accountLogoutAppWidget();//account logout ȭ��
                            tabInfo[tab_index] = 2;
                            continue;
                        }
                    } 
                    else  continue;
                } 
                else continue;
            }
        }
    }
    
    private void cleanFeedList(String snsID) {

        if (snsID.equals(Global.SNS_FACEBOOK)) {
            m_FBfeedList.clear();
        }
        else if (snsID.equals(Global.SNS_TWITTER))
        {
            m_TWfeedList.clear();
        }
        else if(snsID.equals(Global.SNS_MYSPACE))
        {
            m_MSfeedList.clear();
        }
        
    }

    private synchronized void connectAccountService() {
    	
    	//TODO ���������� ������ �ʿ�����.
    	//AIDL ����.
    	RemoteAccountService rmAccountService = RemoteAccountService.getInstance(ctx);
    	accountCallback = new RemoteAccountCallback();
    	rmAccountService.executeService(accountCallback);

	}
    
    private synchronized void connectProfileService() {
    	//AIDL ����.
    	RemoteProfileService rmProfileService = RemoteProfileService.getInstance(ctx);
    	profileCallback = new RemoteProfileCallback();
        rmProfileService.executeService(profileCallback);
        
	}
    
    private synchronized void connectFeedService() {
    	//AIDL ����.
    	RemoteFeedService rmFeedService = RemoteFeedService.getInstance(ctx);
    	feedCallback = new RemoteFeedCallback();
    	rmFeedService.executeService(feedCallback);

	}
    

	/**
     * tab select status create
     * @param whichSns
     */
    public void createTap(String whichSns) {
        Log.d(TAG, "createTap");

        widget_service_btn.setVisibility(View.GONE);
        widget_one_service_btn.setVisibility(View.GONE);
        widget_no_service_btn.setVisibility(View.GONE);
        
        widget_one_facebook_btn_p.setVisibility(View.GONE);
        widget_one_twitter_btn_p.setVisibility(View.GONE);
        widget_one_myspace_btn_p.setVisibility(View.GONE);
        
        widget_one_facebook_btn_n.setVisibility(View.GONE);
        widget_one_twitter_btn_n.setVisibility(View.GONE);
        widget_one_myspace_btn_n.setVisibility(View.GONE);

        if (snsId.size() == 1) {//main account count sns = 1
            widget_one_service_btn.setVisibility(View.VISIBLE);
            if (whichSns.equals(Global.SNS_FACEBOOK)) {
            	widget_one_facebook_btn_n.setVisibility(View.VISIBLE);
            	widget_one_facebook_btn_p.setVisibility(View.GONE);
            } else if (whichSns.equals(Global.SNS_TWITTER)) {
            	widget_one_twitter_btn_n.setVisibility(View.VISIBLE);
            	widget_one_twitter_btn_p.setVisibility(View.GONE);
            } else if (whichSns.equals(Global.SNS_MYSPACE)) {
            	widget_one_myspace_btn_n.setVisibility(View.VISIBLE);
            	widget_one_myspace_btn_p.setVisibility(View.GONE);
            } 
            
        } else if (snsId.size() == 2) {//main account count sns = 2
        	widget_one_service_btn.setVisibility(View.VISIBLE);
            if (whichSns.equals(Global.SNS_FACEBOOK)) {
            	widget_one_facebook_btn_n.setVisibility(View.VISIBLE);
            	widget_one_facebook_btn_p.setVisibility(View.GONE);

                for (int inx = 0; inx < snsId.size(); inx++) {
                    if (snsId.get(inx).equals(Global.SNS_FACEBOOK)) {
                        continue;
                    } else if (snsId.get(inx).equals(Global.SNS_TWITTER)) {
                    	widget_one_twitter_btn_p.setVisibility(View.VISIBLE);
                    } else if (snsId.get(inx).equals(Global.SNS_MYSPACE)) {
                    	widget_one_myspace_btn_p.setVisibility(View.VISIBLE);
                    } 
                }
            } else if (whichSns.equals(Global.SNS_TWITTER)) {
            	widget_one_twitter_btn_n.setVisibility(View.VISIBLE);
            	widget_one_twitter_btn_p.setVisibility(View.GONE);

                for (int inx = 0; inx < snsId.size(); inx++) {
                    if (snsId.get(inx).equals(Global.SNS_FACEBOOK)) {
                    	widget_one_facebook_btn_p.setVisibility(View.VISIBLE);
                    } else if (snsId.get(inx).equals(Global.SNS_TWITTER)) {
                        continue;
                    } else if (snsId.get(inx).equals(Global.SNS_MYSPACE)) {
                    	widget_one_myspace_btn_p.setVisibility(View.VISIBLE);
                    } 
                }
            } else if (whichSns.equals(Global.SNS_MYSPACE)) {
            	widget_one_myspace_btn_n.setVisibility(View.VISIBLE);
            	widget_one_myspace_btn_p.setVisibility(View.GONE);
                for (int inx = 0; inx < snsId.size(); inx++) {
                    if (snsId.get(inx).equals(Global.SNS_FACEBOOK)) {
                    	widget_one_facebook_btn_p.setVisibility(View.VISIBLE);
                    } else if (snsId.get(inx).equals(Global.SNS_TWITTER)) {
                    	widget_one_twitter_btn_p.setVisibility(View.VISIBLE);
                    } else if (snsId.get(inx).equals(Global.SNS_MYSPACE)) {
                        continue;
                    } 
                }
            }
                
            
      } else if (snsId.size() > 2) {   //main account count sns > 2 //ms �߰� 
    	  widget_service_btn.setVisibility(View.VISIBLE);

         if (whichSns.equals(Global.SNS_FACEBOOK)) {
        	 widget_facebook_btn_n.setVisibility(View.VISIBLE);
        	 widget_facebook_btn_p.setVisibility(View.GONE);
                for (int inx = 0; inx < snsId.size(); inx++) {          
                    if (snsId.get(inx).equals(Global.SNS_FACEBOOK)) {
                        continue;
                    } else if (snsId.get(inx).equals(Global.SNS_TWITTER)) {
                    	widget_twitter_btn_p.setVisibility(View.VISIBLE);
                    	widget_twitter_btn_n.setVisibility(View.GONE);
                    } else if (snsId.get(inx).equals(Global.SNS_MYSPACE)) {
                    	widget_myspace_btn_p.setVisibility(View.VISIBLE);
                    	widget_myspace_btn_n.setVisibility(View.GONE);
                    } 
                }
            } else if (whichSns.equals(Global.SNS_TWITTER)) {
            	widget_twitter_btn_n.setVisibility(View.VISIBLE);
            	widget_twitter_btn_p.setVisibility(View.GONE);
                for (int inx = 0; inx < snsId.size(); inx++) {
                    if (snsId.get(inx).equals(Global.SNS_FACEBOOK)) {
                    	widget_facebook_btn_p.setVisibility(View.VISIBLE);
                    	widget_facebook_btn_n.setVisibility(View.GONE);
                    } else if (snsId.get(inx).equals(Global.SNS_TWITTER)) {
                        continue;
                    } else if (snsId.get(inx).equals(Global.SNS_MYSPACE)) {
                    	widget_myspace_btn_p.setVisibility(View.VISIBLE);
                    	widget_myspace_btn_n.setVisibility(View.GONE);
                    } 
                }
            } else if (whichSns.equals(Global.SNS_MYSPACE)) {
            	widget_myspace_btn_n.setVisibility(View.VISIBLE);
            	widget_myspace_btn_p.setVisibility(View.GONE);
                for (int inx = 0; inx < snsId.size(); inx++) {
                    if (snsId.get(inx).equals(Global.SNS_FACEBOOK)) {
                    	widget_facebook_btn_p.setVisibility(View.VISIBLE);
                    	widget_facebook_btn_n.setVisibility(View.GONE);
                    } else if (snsId.get(inx).equals(Global.SNS_TWITTER)) {
                    	widget_twitter_btn_p.setVisibility(View.VISIBLE);
                    	widget_twitter_btn_n.setVisibility(View.GONE);
                    } else if (snsId.get(inx).equals(Global.SNS_MYSPACE)) {
                        continue;
                    } 
                }
            }
            
            
        }
        
        
    }


    /**
     * mainAccount ���翩�� üũ
     */
    private List<String> mainAccountCheck() {
        Log.d(TAG, "mainAccountCheck");

        m_accountList = accountCallback.getAccountList();
        
        if(m_accountList==null)
            return snsId;

        userId.clear();
        snsId.clear();
        ownerId.clear();

        for (int inx = 0;inx < m_accountList.size(); inx++) {
            account = m_accountList.get(inx);
            Log.d(TAG, "account.isMain(" + inx + ") : "+ account.isMain());
            if (account.isMain()) {
                userId.add(account.getUserId());
                snsId.add(account.getSnsId());
                ownerId.add(account.getUserId());
            }
        }
        
        return snsId;
    }

    /*
     * widget start
     * */
    private void widgetStartInit(String snsID) {
        Log.d(TAG, "widgetStartInit");
        getProfileInfo();
                
        getFeedInfo(snsID,tab_index);

    }

    /*
     * Profile ����
     */
    private void getProfileInfo() {
        Log.d(TAG, "getProfileInfo");

        if (m_profile.size() != 0) {
            m_profile.clear();
        }
        for (int inx = 0; inx < snsId.size(); inx++) {
            try {
                m_profile.add(profileCallback.getProfile(snsId.get(inx), userId.get(inx), ownerId.get(inx)));
            } catch (Exception e) {
                
            }
        }
    }

    
    
    /**
     * feed ������
     */
    private synchronized void getFeedInfo(final String snsID, final int iTab_index) {
        Log.d(TAG, "getFeedInfo : " + snsID);

        if(tabInfo[iTab_index] == 0)
        {
            return;
        }
        else if(tabInfo[iTab_index] == 1)
        {
            checkTotalAppWidget(iTab_index);
            updateWidgetRefreshButtonView(iTab_index);
            return;
        }

        feedCallback.removeFeedUpdateListener(snsID);   
        feedCallback.addFeedUpdateListener(snsID);
        
        //mAvatarList.clear();

        Thread statusThread1 = new Thread(null, new Runnable() 
        {
            public void run() 
            {
                for (int inx = 0; inx < snsId.size(); inx++) 
                {
                    final int idx = inx;
                    final String currentSnsId = snsId.get(idx);
                    
                    try 
                    {
                        if(Util.isEmpty(currentSnsId)) return;
                        if (!currentSnsId.equals(snsID)) continue;
                        
                        Log.d(TAG,"tabInfo[" + iTab_index + "] = " + tabInfo[iTab_index]);
                        if ((currentSnsId.equals(Global.SNS_FACEBOOK) || currentSnsId.equals(Global.SNS_TWITTER) || currentSnsId.equals(Global.SNS_MYSPACE) || currentSnsId.equals(Global.SNS_ORKUT))) 
                        {
                            tabInfo[iTab_index] = 0;
                            
                            cleanFeedList(currentSnsId);
                            tempList = feedCallback.getFeedForWidgetList(currentSnsId, userId.get(idx)); 

                            for (int k = 0; k < tempList.size(); k++) 
                            {
                                final Feed tempFeed = tempList.get(k);
                                if(tempFeed.getSnsId()!=null)
                                {
                                    
                                    mAvatarList.put(tempFeed.getAvatarUrl(), BitmapFactory.decodeResource(getResources(), R.drawable.port_linkbook_noimage));
                                    getImage(tempFeed);
                                
                                    uiHandler.post(
                                            new Thread ()
                                            {
                                                public void run()
                                                {
                                                    if(tempFeed.getSnsId().equals(Global.SNS_FACEBOOK)){
                                                        
                                                        if(m_fbAdapter==null)
                                                            prepareFbFeed();
                                                        
                                                        m_FBfeedList.add(tempFeed);
                                                        m_fbAdapter.notifyDataSetChanged();
                                                    }
                                                    else if(tempFeed.getSnsId().equals(Global.SNS_TWITTER)){
                                                        if(m_twAdapter==null)
                                                            prepareTwFeed();
                                                        
                                                        m_TWfeedList.add(tempFeed);
                                                        m_twAdapter.notifyDataSetChanged();
                                                    }
                                                    else if(tempFeed.getSnsId().equals(Global.SNS_MYSPACE)){
                                                        if(m_msAdapter==null)
                                                            prepareMsFeed();
                                                        
                                                        m_MSfeedList.add(tempFeed);
                                                        m_msAdapter.notifyDataSetChanged();
                                                    }
                                                }
                                            }
                                    
                                    );
                                }
                                
                            }
                            tabInfo[iTab_index] = 1;
                            uiHandler.post(new Runnable() {
                                public void run() {
                                    checkTotalAppWidget(iTab_index);
                                    updateWidgetRefreshButtonView(iTab_index);
                                }
                            });
                        }
                    } 
                    catch (final Exception e) 
                    {
                    	e.printStackTrace();
                    	
                        uiHandler.post( new Runnable() {
                            public void run() {
                                Log.d(TAG, "doFeedInfoException");
                                refreshButtonView = 1;
                                tabInfo[iTab_index] = 1;
                                noFriendsDataAppWidget();
                                updateWidgetRefreshButtonView(iTab_index);
                            }
                        });
                    } 
                }
                
            }           
        });
        statusThread1.start();
        
    }
    
    /**
     * Appwidget update
     * @param profile
     */
    private void checkTotalAppWidget(int iTab_index) {
        Log.d(TAG, "checkTotalAppWidget");
        if (tabInfo[iTab_index]==1) {
            updateAppWidgetFriends();
        } else { // friend feed������
            noFriendsDataAppWidget();
        }

    }

    /**
     * account logout
     */
    private void accountLogoutAppWidget() {
        Log.d(TAG, "accountLogoutAppWidget");

//        m_profile.clear();
//        m_feedList.clear();
//        refreshButtonView = 0;// button �׸���

        widget_friends_body_fb.setVisibility(View.GONE);
        widget_friends_body_tw.setVisibility(View.GONE);
        widget_friends_body_ms.setVisibility(View.GONE);
        
        widget_wait_loading.setVisibility(View.GONE);
        widget_no_account.setVisibility(View.GONE);
        widget_no_body.setVisibility(View.GONE);
        widget_refresh_view.setVisibility(View.GONE);
        widget_bottom_no_account.setVisibility(View.GONE);
        
        widget_bottom_view.setVisibility(View.VISIBLE);
        widget_account_logout.setVisibility(View.VISIBLE);
        widget_bottom_loading.setVisibility(View.GONE);
        
        
        Intent loginIntent = new Intent(UIConst.getSnsLoginAction(tabSnsId));
        loginIntent.putExtra(UIConst.KEY_SNS_ID, tabSnsId);
        loginIntent.putExtra(UIConst.KEY_FROM_EXTERNAL, "external");
        loginIntent.putExtra("fromFeedWidget", true);
        
        //widget stack ���� �ױ�(6/1 ���� ) 
        final Intent intentBase = new Intent();
        intentBase.setAction(UIConst.INTENT_ACTION_WIDGETBASE);
        intentBase.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        intentBase.putExtra(UIConst.EXTRA_KEY_URI,loginIntent.toUri(0));

        widget_account_logout.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
            	ctx.startActivity(intentBase);
            	
            }
        } ); 
        widget_account_logout.setOnLongClickListener(longToWidget);
        
        widget_bottom_view.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
            	ctx.startActivity(intentBase);
            	
            }
        } ); 
        widget_bottom_view.setOnLongClickListener(longToWidget);
        
    }

    /**
     * no account
     */
    private void noAccountAppWidget() {
        Log.d(TAG, "noAccountAppWidget");

        m_profile.clear();
        m_FBfeedList.clear();
        m_TWfeedList.clear();
        m_MSfeedList.clear();

        widget_service_btn.setVisibility(View.GONE);
        widget_one_service_btn.setVisibility(View.GONE);
        widget_friends_body_fb.setVisibility(View.GONE);
        widget_friends_body_ms.setVisibility(View.GONE);
        widget_friends_body_tw.setVisibility(View.GONE);
                
        widget_account_logout.setVisibility(View.GONE);
        widget_wait_loading.setVisibility(View.GONE);
        widget_no_body.setVisibility(View.GONE);
        widget_refresh_view.setVisibility(View.GONE);
        widget_bottom_view.setVisibility(View.GONE);
        widget_bottom_loading.setVisibility(View.GONE);
                
        widget_no_service_btn.setVisibility(View.VISIBLE);
        widget_no_account.setVisibility(View.VISIBLE);
        widget_bottom_no_account.setVisibility(View.VISIBLE);
        

        // settingȭ������ ������
        Intent intentSettings = new Intent("android.settings.SYNC_SETTINGS");
        
        //widget stack ���� �ױ�(6/1 ���� ) 
        final Intent intentBase1 = new Intent();
        intentBase1.setAction(UIConst.INTENT_ACTION_WIDGETBASE);
        intentBase1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        intentBase1.putExtra(UIConst.EXTRA_KEY_URI,intentSettings.toUri(0));

        widget_no_account.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
            	ctx.startActivity(intentBase1);

            }
        } ); 
        widget_no_account.setOnLongClickListener(longToWidget);
        
        widget_bottom_no_account.setOnClickListener(new OnClickListener() {
            public void onClick(View arg0) {
            	ctx.startActivity(intentBase1);

            }
        } ); 
        widget_bottom_no_account.setOnLongClickListener(longToWidget);

    }

    /**
     * ģ�� FEED ������
     */
    private void noFriendsDataAppWidget() {
        Log.d(TAG, "noFriendsDataAppWidget");
        
        widget_friends_body_fb.setVisibility(View.GONE);
        widget_friends_body_ms.setVisibility(View.GONE);
        widget_friends_body_tw.setVisibility(View.GONE);
        widget_no_account.setVisibility(View.GONE);
        widget_account_logout.setVisibility(View.GONE);
        widget_wait_loading.setVisibility(View.GONE);
        widget_bottom_no_account.setVisibility(View.GONE);
        widget_no_body.setVisibility(View.VISIBLE);
        
    }

    /**
     * Click Refresh button, Loading view
     */
    private void waitLoadingWidget() {
        Log.d(TAG, "waitLoadingWidget = " + tabInfo[tab_index]);
        
        if(tabInfo[tab_index] > 0)
            return;
        
        widget_friends_body_fb.setVisibility(View.GONE);
        widget_friends_body_ms.setVisibility(View.GONE);
        widget_friends_body_tw.setVisibility(View.GONE);
        widget_no_account.setVisibility(View.GONE);
        widget_account_logout.setVisibility(View.GONE);
        widget_wait_loading.setVisibility(View.VISIBLE);
        widget_bottom_no_account.setVisibility(View.GONE);
        widget_no_body.setVisibility(View.GONE);
        
        //refresh button�������� Ÿ�� �Ϸ��� ////0511�߰�
        widget_refresh_view.setVisibility(View.VISIBLE);
        widget_bottom_view.setVisibility(View.GONE);
        widget_bottom_loading.setVisibility(View.GONE);
        widget_bottom_no_account.setVisibility(View.GONE);
        
        
        if(isRefresh){
            Log.d(TAG, "~~~~~~~~~~~~~~~~~~isRefresh = true~~~~~~~~~~~~~~~~~~");     
            widget_each_update.setVisibility(View.GONE);
            widget_each_update_disable.setVisibility(View.VISIBLE); 
            
            refreshed_time.setVisibility(View.GONE);
            refreshed_time_loading.setVisibility(View.VISIBLE);
        }
        

    }
    
    /*
     * 
     * ���� feed �׸���
     */
    private void updateAppWidgetFriends() {
        Log.d(TAG, "updateAppWidgetFriends");

        int i = 0;
        int line = 0;
        
        widget_friends_body_fb.setVisibility(View.GONE);
        widget_friends_body_ms.setVisibility(View.GONE);
        widget_friends_body_tw.setVisibility(View.GONE);
        widget_no_account.setVisibility(View.GONE);
        widget_no_body.setVisibility(View.GONE);
        widget_account_logout.setVisibility(View.GONE);
        widget_wait_loading.setVisibility(View.GONE);
        widget_bottom_no_account.setVisibility(View.GONE);
        

        //SNS���� xml�и� 
        if (tabSnsId.equals(Global.SNS_MYSPACE)) {
            Log.d(TAG, "updateAppWidgetFriends:::SNS_MYSPACE");
            widget_friends_body_ms.setVisibility(View.VISIBLE);

        } else if(tabSnsId.equals(Global.SNS_TWITTER)){ //orkut�� �켱 twitter bodyŸ���� 
            Log.d(TAG, "updateAppWidgetFriends:::SNS_TWITTER");
            widget_friends_body_tw.setVisibility(View.VISIBLE);
        } else {
            Log.d(TAG, "updateAppWidgetFriends:::SNS_OTHERS::FACEBOOK");
            // for listview
            widget_friends_body_fb.setVisibility(View.VISIBLE);
        }
        
    }


    

    /**
     * �ϴ� ��ư
     */
    private void updateWidgetRefreshButtonView(final int iTab_index) {
        Log.d(TAG, "updateWidgetRefreshButtonView");

        widget_refresh_view.setVisibility(View.VISIBLE);
        widget_bottom_view.setVisibility(View.GONE);
        widget_bottom_loading.setVisibility(View.GONE);
        widget_bottom_no_account.setVisibility(View.GONE);
        //refresh button control (refresh button������ ���� ��ư ��Ȱ��ȭ �ǵ���) 0511�߰� 
        widget_each_update.setVisibility(View.VISIBLE);
        widget_each_update_disable.setVisibility(View.GONE);
        
        //0513�߰� 
        refreshed_time.setVisibility(View.VISIBLE);
        refreshed_time_loading.setVisibility(View.GONE);
        
        if (tabInfo[iTab_index]==1) {

            String first = Util.getRelativeTimeSpanString(ctx, new Date(System.currentTimeMillis()),new Date(System.currentTimeMillis()), true);
            refreshed_time.setText(ctx.getString(R.string.refresh_updated_time, first));
            for (int inx = 0; inx < m_accountList.size(); inx++) {
                if (m_accountList.get(inx).getSnsId().equals(tabSnsId)) {
                    currentUserId = m_accountList.get(inx).getUserId();
                }
            }
            Long updatedTime = feedCallback.getFeedForWidgetListUpdatedTime(tabSnsId, currentUserId);
            SimpleDateFormat sdfCurrent = new SimpleDateFormat("MM/dd/yyyy hh:mm aaa");
            String time = sdfCurrent.format(updatedTime);
            refreshed_time.setText(ctx.getString(R.string.refresh_updated_time, time));

            widget_each_update.setOnClickListener(new OnClickListener() {
                public void onClick(View arg0) {
                    tabInfo[iTab_index] = -1;
                    waitLoadingWidget();
                    widgetInit();

                }
            } ); 
            widget_each_update.setOnLongClickListener(longToWidget);

            // home icon ������ home����
            if (tabSnsId.equals(Global.SNS_FACEBOOK)) {
                Intent intentFeed7 = new Intent(UIConst.INTENT_ACTION_VIEW_FACEBOOK_HOME);
                intentFeed7.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                intentFeed7.putExtra(UIConst.KEY_SNS_ID, tabSnsId);
                intentFeed7.putExtra(UIConst.KEY_USER_ID, currentUserId);

                //widget stack ���� �ױ�(6/1 ���� ) 
                final Intent intentBase12 = new Intent();
                intentBase12.setAction(UIConst.INTENT_ACTION_WIDGETBASE);
                intentBase12.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                intentBase12.putExtra(UIConst.EXTRA_KEY_URI,intentFeed7.toUri(0));

                widget_home_icon.setOnClickListener(new OnClickListener() {
                    public void onClick(View arg0) {
                        ((Activity)ctx).startActivityForResult(intentBase12,SNS_HOME_REQUEST);

                    }
                } ); 
                widget_home_icon.setOnLongClickListener(longToWidget);
                

            } else if (tabSnsId.equals(Global.SNS_TWITTER)) {
                Intent intentFeed2 = new Intent(UIConst.INTENT_ACTION_VIEW_TWITTER_HOME);
                intentFeed2.putExtra(UIConst.KEY_SNS_ID, tabSnsId);
                intentFeed2.putExtra(UIConst.KEY_USER_ID, currentUserId);

                //widget stack ���� �ױ�(6/1 ���� ) 
                final Intent intentBase13 = new Intent();
                intentBase13.setAction(UIConst.INTENT_ACTION_WIDGETBASE);
                intentBase13.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                intentBase13.putExtra(UIConst.EXTRA_KEY_URI,intentFeed2.toUri(0));

                widget_home_icon.setOnClickListener(new OnClickListener() {
                    public void onClick(View arg0) {
                        ((Activity)ctx).startActivityForResult(intentBase13,SNS_HOME_REQUEST);

                    }
                } ); 
                widget_home_icon.setOnLongClickListener(longToWidget);

            } else if (tabSnsId.equals(Global.SNS_MYSPACE)) {
                Intent intentFeed8 = new Intent(UIConst.INTENT_ACTION_VIEW_MYSPACE_HOME);
                intentFeed8.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP| Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
                intentFeed8.putExtra(UIConst.KEY_SNS_ID, tabSnsId);
                intentFeed8.putExtra(UIConst.KEY_USER_ID, currentUserId);
                
                //widget stack ���� �ױ�(6/1 ���� ) 
                final Intent intentBase14 = new Intent();
                intentBase14.setAction(UIConst.INTENT_ACTION_WIDGETBASE);
                intentBase14.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                intentBase14.putExtra(UIConst.EXTRA_KEY_URI,intentFeed8.toUri(0));
                
                widget_home_icon.setOnClickListener(new OnClickListener() {
                    public void onClick(View arg0) {
                    	((Activity)ctx).startActivityForResult(intentBase14,SNS_HOME_REQUEST);

                    }
                } ); 
                widget_home_icon.setOnLongClickListener(longToWidget);
                
            } 
        } 

    }
    
    void prepareFbFeed()
    {
        if(m_fbAdapter!=null) return;
        
        m_fbAdapter = new FaceBookAdapter((Activity)ctx,m_FBfeedList);
        
        fb_feed_list.setAdapter(m_fbAdapter);
        fb_feed_list.setOnItemClickListener(new OnItemClickListener() 
        {
        	public void onItemClick(AdapterView<?> parent, View view, int position,	long id) 
        	{
        		Feed feed = m_FBfeedList.get(position);
        		
        		// content-> comment&like
                Intent intentFeed4 = new Intent(UIConst.INTENT_ACTION_WRITE_FEED_COMMENT);
                intentFeed4.putExtra(UIConst.KEY_SNS_ID, feed.getSnsId());
                intentFeed4.putExtra(UIConst.KEY_USER_ID, feed.getUserId());
                intentFeed4.putExtra(UIConst.KEY_FEED_TYPES,feed.getFeedType());//live(home), wall(profile)

                //widget stack ���� �ױ�(6/1 ���� ) 
                Intent intentBase8 = new Intent();
                intentBase8.setAction(UIConst.INTENT_ACTION_WIDGETBASE);
                intentBase8.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                intentBase8.putExtra(UIConst.EXTRA_KEY_URI,intentFeed4.toUri(0));
                intentBase8.putExtra(UIConst.EXTRA_KEY_FEED, feed);//��ü 
                
                ctx.startActivity(intentBase8);            	
            }
        });
        fb_feed_list.setOnItemLongClickListener(itemlongToWidget);
        
    }
    
    void prepareTwFeed()
    {
        if(m_twAdapter!=null) return;
        
        m_twAdapter = new TwitterAdapter((Activity)ctx,m_TWfeedList);
        
        tw_feed_list.setAdapter(m_twAdapter);
        tw_feed_list.setOnItemClickListener(new OnItemClickListener() 
        {
        	public void onItemClick(AdapterView<?> parent, View view, int position, long id) 
        	{
        		Feed feed = m_TWfeedList.get(position);
        		
        		// content->detailed feed
                Intent intentFeed1 = new Intent(UIConst.getProfileAction(feed.getSnsId()));
                intentFeed1.putExtra(UIConst.KEY_SNS_ID, feed.getSnsId());
                intentFeed1.putExtra(UIConst.KEY_USER_ID, feed.getUserId());
                intentFeed1.putExtra(UIConst.EXTRA_KEY_FRIENDS_ID, feed.getAuthorId());

                //widget stack ���� �ױ�(6/1 ���� ) 
                Intent intentBase10 = new Intent();
                intentBase10.setAction(UIConst.INTENT_ACTION_WIDGETBASE);
                intentBase10.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                intentBase10.putExtra(UIConst.EXTRA_KEY_URI,intentFeed1.toUri(0));
                intentBase10.putExtra(UIConst.EXTRA_KEY_FEED , feed);
                
                ctx.startActivity(intentBase10);
            }
        });
        tw_feed_list.setOnItemLongClickListener(itemlongToWidget);
    }
    
    void prepareMsFeed()
    {
        if(m_msAdapter!=null) return;
        
        m_msAdapter = new MySpaceAdapter((Activity)ctx,m_MSfeedList);
        
        ms_feed_list.setAdapter(m_msAdapter);
        ms_feed_list.setOnItemClickListener(new OnItemClickListener() 
        {
        	public void onItemClick(AdapterView<?> parent, View view, int position, long id) 
        	{
        		Feed feed = m_MSfeedList.get(position);
        		
        		// content->detailed feed  
                Intent intentFeed9 = new Intent(UIConst.getProfileAction(feed.getSnsId()));
                intentFeed9.putExtra(UIConst.KEY_SNS_ID, feed.getSnsId());
                intentFeed9.putExtra(UIConst.KEY_USER_ID, feed.getUserId());
                intentFeed9.putExtra(UIConst.EXTRA_KEY_FRIENDS_ID, feed.getAuthorId());
                intentFeed9.putExtra(UIConst.EXTRA_KEY_ATTACH_LIST, feed.getFeedAttachment());
                
                //widget stack ���� �ױ�(6/1 ���� ) 
                Intent intentBase6 = new Intent();
                intentBase6.setAction(UIConst.INTENT_ACTION_WIDGETBASE);
                intentBase6.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
                intentBase6.putExtra(UIConst.EXTRA_KEY_URI,intentFeed9.toUri(0));
                intentBase6.putExtra(UIConst.EXTRA_KEY_FEED , feed);
                
                ctx.startActivity(intentBase6);
            }
        });
        ms_feed_list.setOnItemLongClickListener(itemlongToWidget);
    }
    
    private void prepareFeedsList(String snsID) 
    {
        if(snsID.equals(Global.SNS_FACEBOOK))     prepareFbFeed();
        else if(snsID.equals(Global.SNS_TWITTER)) prepareTwFeed();
        else prepareMsFeed();        
    }
    
    protected void getImage(final Feed feed) 
    {
        new Thread(new Runnable() 
        {
            public void run() 
            {
                Bitmap photo = null;
                
                try 
                {
                    photo = profileCallback.getProfileAvatar(feed.getSnsId(), feed.getUserId(), feed.getAuthorId(), null);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
                if (photo != null && mAvatarList != null ) 
                {   
                    mAvatarList.put(feed.getAvatarUrl(), (Object)photo);
                    
                    // Adapter Notify
                    if(feed.getSnsId().equals(Global.SNS_FACEBOOK))
                    {
                        post(new Runnable() 
                        {
                            public void run() {
                                if (m_fbAdapter != null) m_fbAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                    else if(feed.getSnsId().equals(Global.SNS_TWITTER))
                    {
                        post(new Runnable() 
                        {
                            public void run() {
                                if (m_twAdapter != null) m_twAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                    else if(feed.getSnsId().equals(Global.SNS_MYSPACE))
                    {
                        post(new Runnable() 
                        {
                            public void run() {
                                if (m_msAdapter != null) m_msAdapter.notifyDataSetChanged();
                            }
                        });
                    }
                }
            }
        }).start();
    }
    
    private int findFBPosition(Feed feed) 
    {
        if(m_FBfeedList==null)
            return -1;
        
        for (int i = 0; i < m_FBfeedList.size(); i++) 
        {
            if (m_FBfeedList.get(i).getFeedId().equals(feed.getFeedId())) return i;
        }
        
        return -1;
    }
    
    private int findTWPosition(Feed feed) 
    {
        if(m_TWfeedList==null)
            return -1;
        
        for (int i = 0; i < m_TWfeedList.size(); i++) 
        {
            if (m_TWfeedList.get(i).getFeedId().equals(feed.getFeedId())) return i;
        }
        
        return -1;
    }
    
    private int findMSPosition(Feed feed) 
    {
        if(m_MSfeedList==null)
            return -1;
        
        for (int i = 0; i < m_MSfeedList.size(); i++) 
        {
            if (m_MSfeedList.get(i).getFeedId().equals(feed.getFeedId())) return i;
        }
        
        return -1;
    }

    private IAccountService accountService;
    
    class RemoteAccountCallback implements RemoteAccountService.RemoteAccountCallback {

    	
    	private boolean isAccountServiceConnected = false;
    	
        public void onConnected(IAccountService remoteService) {      
        	accountService = remoteService;
        	isAccountServiceConnected = true;	

            //accountListener
        	addAccountUpdateListener();
            
            mainAccountCheck();//main account check 
            
            if (snsId.size() < 1) {
                noAccountAppWidget();
            } else {                
                tabSnsId = snsId.get(0);      
                tabInit();
                
                
            }
            
            
        }
        
        public boolean isConnected()
        {
        	return isAccountServiceConnected;        
        }
        
        public List<AccountInfo> getAccountList() {
        	List<AccountInfo> accountList = new ArrayList<AccountInfo>();
        	
        	try {
				accountList = accountService.getAccountList();
			} catch (Exception e) {
				e.printStackTrace();
			}

			return accountList;
		}

		public int checkLogin(String snsId)
        {
			int ret = 0;
        	try {
        		ret =  accountService.checkLogIn(snsId);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return ret;
			
        }
        
		public void addAccountUpdateListener() {
			try {
				accountService.registerCallback( mAccountCallback);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public void removeAccountUpdateListener() {
			try {
				accountService.unregisterCallback( mAccountCallback);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		

    }
    
    private IProfileService profileService;
    
    class RemoteProfileCallback implements RemoteProfileService.RemoteProfileCallback {
    	
    	
    	private boolean isProfileServiceConnected = false;
    	
        public void onConnected(IProfileService remoteService) {
        	
        	profileService = remoteService;
        	isProfileServiceConnected = true;     
        	Log.d(TAG, "IProfileService CONNECTED!");
        }

        public boolean isConnected()
        {
        	return isProfileServiceConnected;        
        }
        
		public Bitmap getProfileAvatar(String snsId, String userId,
				String authorId, Object object) {
			
			Profile profile = getProfile(snsId, userId, authorId);
			ProfileContentAdapter contentAdapter = new ProfileContentAdapter(ctx.getContentResolver());
			if(profile.getAvatarBitmapUri()!=null)
			    return contentAdapter.getAvatarBitmap(profile.getAvatarBitmapUri());
			else
			    return null;
		}

		public Profile getProfile(String snsId, String userId, String sOwnerId) {

			try {
				return profileService.getProfile(snsId, userId, sOwnerId);
			} catch (Exception e) {				
				e.printStackTrace();
			}
			
			return null;
		}

    }
    
    
    
    private IFeedService feedService;
    
    class RemoteFeedCallback implements RemoteFeedService.RemoteFeedCallback {

    	
    	private boolean isFeedServiceConnected = false;
    	
        public void onConnected(IFeedService remoteService) {
        	
        	feedService = remoteService;
        	isFeedServiceConnected = true;    
        	Log.d(TAG, "IFeedService CONNECTED!");
        	waitLoadingWidget();           
            widgetInit();
            
        }

        public boolean isConnected()
        {
        	return isFeedServiceConnected;        
        }
        
		public void addFeedUpdateListener(String snsId) {
			try {
				feedService.registerCallback(snsId, mFeedCallback);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public void removeFeedUpdateListener(String snsId) {
			try {
				feedService.unregisterCallback(snsId, mFeedCallback);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}

		public List<Feed> getFeedForWidgetList(String snsId,	String userId) {

			try {
				return feedService.getFeedList(snsId, userId, userId, getFeedType(snsId), Feed.CATEGORY_ALL, 1);
			} catch (RemoteException e) {
				return null;
			}
			
		}

		public List<Feed> refreshAllFeedForWidgetList(String snsId,	String userId) {
			try {
				return feedService.getFeedList(snsId, userId, userId, getFeedType(snsId), Feed.CATEGORY_ALL, 1);
			} catch (RemoteException e) {
				return null;
			}
		}

		private String getFeedType(String snsId) {
			if(snsId.equals(Global.SNS_FACEBOOK))
				return Feed.TYPE_FB_LIVE_FEED;
			else if(snsId.equals(Global.SNS_TWITTER))
				return Feed.TYPE_TW_HOME;
			else if(snsId.equals(Global.SNS_MYSPACE))
				return Feed.TYPE_MS_STREAM;
			else
				return Feed.TYPE_FB_LIVE_FEED;
		}

		public Long getFeedForWidgetListUpdatedTime(String tabSnsId, String currentUserId) {
			
			try {
				return feedService.getFeedAIDLWidgetListUpdatedTime(tabSnsId, currentUserId);
			} catch (RemoteException e) {
				return 0L;
			}
		}

    }

    private IAccountServiceCallback mAccountCallback = new IAccountServiceCallback.Stub() 
    {
        public void onAccountAdded(final AccountInfo account) throws RemoteException {

            mainAccountCheck();//tap ���� �����ֱ� ���� üũ 
            
            uiHandler.post(new Thread()
            {
                public void run() 
                {
                    if(snsId.size()>0){
                        createTap(account.getSnsId());

                        tabSnsId = account.getSnsId();
                        tabInfo[0] = -1;
                        tabInfo[1] = -1;
                        tabInfo[2] = -1;    
                        
                        widgetInit();
                        waitLoadingWidget();
                        
                    }
                }
            });
            
            
            
        }

    	public void onAccountRemoved(AccountInfo account) throws RemoteException 
    	{
            mainAccountCheck();//tap ���� �����ֱ� ���� üũ         
    
            uiHandler.post(new Thread()
            {
                public void run() 
                {
                    if (snsId.size() < 1) {                
                        noAccountAppWidget();
                    } else {
                        tabSnsId = snsId.get(0);
                        tabInfo[0] = -1;
                        tabInfo[1] = -1;
                        tabInfo[2] = -1;
                        tabInit();                
                        
                    }
                }
            });
            
    	}
    
    	public void onAccountUpdated(AccountInfo account) throws RemoteException 
    	{
            //refrehs control���ؼ� flag�߰� 0511
            isRefresh = true;
            
            mainAccountCheck();
            
            final String accountSnsId = account.getSnsId();
            uiHandler.postAtFrontOfQueue(new Runnable() 
            {
                public void run() 
                {    
                    String snsService = Global.SNS_FACEBOOK;
                    
                    if (accountSnsId.equals(Global.SNS_TWITTER))      snsService =Global.SNS_TWITTER;
                    else if (accountSnsId.equals(Global.SNS_MYSPACE)) snsService =Global.SNS_MYSPACE;
    
                    createTap(snsService);
                    isRefresh = true;
                    isFirst = false;
                    tabSnsId = snsService;
//                    m_feedList.clear();
    
                    waitLoadingWidget();
                    widgetInit();
                }
            });
    	}
    };
    
    
    private IFeedServiceCallback mFeedCallback = new IFeedServiceCallback.Stub() 
    {    
        public void onFeedUpdated(final Feed feed) throws RemoteException 
        {

            // Adapter Notify
            if(feed.getSnsId().equals(Global.SNS_FACEBOOK))
            {
                post(new Runnable() 
                {
                    public void run() {
                        int idx = findFBPosition(feed);
                        if (idx != -1) m_FBfeedList.set(idx, feed);
                        else m_FBfeedList.add(feed);
                        
                        if (m_fbAdapter != null) m_fbAdapter.notifyDataSetChanged();
                    }
                });
            }
            else if(feed.getSnsId().equals(Global.SNS_TWITTER))
            {
                post(new Runnable() 
                {
                    public void run() {
                        int idx = findTWPosition(feed);
                        if (idx != -1) m_TWfeedList.set(idx, feed);
                        else m_TWfeedList.add(feed);
                        
                        if (m_twAdapter != null) m_twAdapter.notifyDataSetChanged();
                    }
                });
            }
            else if(feed.getSnsId().equals(Global.SNS_MYSPACE))
            {
                post(new Runnable() 
                {
                    public void run() {
                        int idx = findMSPosition(feed);
                        if (idx != -1) m_MSfeedList.set(idx, feed);
                        else m_MSfeedList.add(feed);
                        
                        if (m_msAdapter != null) m_msAdapter.notifyDataSetChanged();
                    }
                });
            }
        }
        
        public void onFeedAdded(final Feed feed) throws RemoteException 
        {
	        if(userId.contains(feed.getUserId())==false) return;                    // �������� userId üũ
	        //if(Util.isEmpty(tabSnsId) || !tabSnsId.equals(feed.getSnsId())) return;  // �������� snsId üũ   
	        if(Util.isEmpty(feed.getTitle())) return;
	        if(feed.getTitle().equals("5")) return;
            
            if (feedDupl(feed))
                return; 
	            
            // Adapter Notify
            if(feed.getSnsId().equals(Global.SNS_FACEBOOK))
            {
                post(new Runnable() 
                {
                    public void run() {
                        int idx = findFBPosition(feed);
                        if (idx != -1) m_FBfeedList.set(idx, feed);
                        else m_FBfeedList.add(feed);
                        
                        getImage(feed);
                        
                        if (m_fbAdapter != null) m_fbAdapter.notifyDataSetChanged();
                    }
                });
            }
            else if(feed.getSnsId().equals(Global.SNS_TWITTER))
            {
                post(new Runnable() 
                {
                    public void run() {
                        int idx = findTWPosition(feed);
                        if (idx != -1) m_TWfeedList.set(idx, feed);
                        else m_TWfeedList.add(feed);
                        
                        getImage(feed);
                        
                        if (m_twAdapter != null) m_twAdapter.notifyDataSetChanged();
                    }
                });
            }
            else if(feed.getSnsId().equals(Global.SNS_MYSPACE))
            {
                post(new Runnable() 
                {
                    public void run() {
                        int idx = findMSPosition(feed);
                        if (idx != -1) m_MSfeedList.set(idx, feed);
                        else m_MSfeedList.add(feed);
                        
                        getImage(feed);
                        
                        if (m_msAdapter != null) m_msAdapter.notifyDataSetChanged();
                    }
                });
            }
           
        }
        
        private boolean feedDupl(Feed feed) {
            
            ArrayList<Feed> arrayTemp = null;
            
            
            if(feed.getSnsId().equals(Global.SNS_FACEBOOK))
            {
                arrayTemp = m_FBfeedList;
            } 
            else if(feed.getSnsId().equals(Global.SNS_TWITTER))
            {
                arrayTemp = m_TWfeedList;
            } 
            else if(feed.getSnsId().equals(Global.SNS_MYSPACE))
            {
                arrayTemp = m_MSfeedList;
            }
            
            if (arrayTemp != null) {
                
                int nSize = arrayTemp.size();
                for (int i = 0; i < nSize; i++) {
                    if (!Util.isEmpty(arrayTemp.get(i).getFeedId())) {                        
                        if (arrayTemp.get(i).getFeedId().equals(feed.getFeedId()))
                            return true;
                    } else {
                        if (String.valueOf(arrayTemp.get(i).get_Id()).equals(
                                feed.getFeedId()))
                            return true;
                    }
                }
            }
            return false;
        }
        
        public void onFeedRemoved(Feed feed) throws RemoteException {
            // DO Noting
            Log.d("RemoteTest", "onFeedRemoved:" + feed.getFeedId());
        }
        
        public void onFeedRefreshStarted() throws RemoteException {
        	// DO Noting
            Log.d("RemoteTest", "onFeedRefreshStarted:");
        }
        
        public void onFeedRefreshFinished() throws RemoteException {
        	// DO Noting
            Log.d("RemoteTest", "onFeedRefreshFinished:");
        }
        
        public void onFeedRefreshFail() throws RemoteException {
        	// DO Noting
            Log.d("RemoteTest", "onFeedRefreshFail:");
        }
        
        
    };
    
    // ������ ����(0�̸� ������ ����)
    private int getFriendsIcon(Feed feed)
    {
        String sCategory = feed.getCategory();
        
        if(sCategory==null) return 0;
        else if (sCategory.equals(Feed.CATEGORY_EVENT)) return R.drawable.facebook_icon_small_event;    // event
        else if (sCategory.equals(Feed.CATEGORY_LINK))  return R.drawable.facebook_icon_small_link;     // link
        else if (sCategory.equals(Feed.CATEGORY_NOTE))  return R.drawable.facebook_icon_small_memo;     // note
        else if (sCategory.equals(Feed.CATEGORY_PHOTO)) return R.drawable.facebook_icon_small_photo;    // photo
        else if (sCategory.equals(Feed.CATEGORY_VIDEO)) return R.drawable.facebook_icon_small_video;    // video
        else if (sCategory.equals(Feed.CATEGORY_PROFILE_STATUS)) return 0;  // status
        else return 0;
    }
    
    // Feed�� ����� ���̵�, ���� ����� ��� ������ ���·� �����Ͽ� ����.
    private SpannableStringBuilder buildContent(Feed feed)
    {
        // name+content
        String displayName = feed.getDisplayName();
        String content = feed.getContent();
        SpannableStringBuilder stringBuilder = new SpannableStringBuilder();   
        
        if(content==null)
            content = "";
        
        if (!Util.isEmpty(displayName)) {// != null) {
        } else {
            displayName = feed.getUserName();
        }   
        if (displayName == null){
            displayName = "";
        }
        
        stringBuilder.append(displayName + " ");
        
        //�̸� tw ���򵥷� �ϱ� 
        if ( Global.SNS_TWITTER.equals(feed.getSnsId()) ){
            stringBuilder.setSpan(new ForegroundColorSpan(Color.rgb(30, 168, 215)), 0, displayName.length(), Spanned.SPAN_COMPOSING);
        }else{
            stringBuilder.setSpan(new ForegroundColorSpan(Color.rgb(38, 82, 164)), 0, displayName.length(),Spanned.SPAN_COMPOSING);
        }
        stringBuilder.setSpan(new StyleSpan(Typeface.BOLD), 0, displayName.length(), Spanned.SPAN_COMPOSING);
        
        //create icon
        attachList = feed.getFeedAttachment();
        
        String sCategory = feed.getCategory();
        
        if(sCategory==null)
        {
            stringBuilder.append(content);
        } 
        else if (sCategory.equals(Feed.CATEGORY_EVENT)) 
        {   // event
            String eventTitle = "";
            if (attachList != null) {
                eventTitle = attachList.get(0).getAttachName();
            }
            stringBuilder.append(ctx.getString(R.string.widget_post_event)+ " " + eventTitle);
            String noteUpload = ctx.getString(R.string.widget_post_event)+ " ";

            int startPoint = displayName.length() + noteUpload.length()+ 1;
            int endPoint = displayName.length() + noteUpload.length()+ eventTitle.length() + 1;
            stringBuilder.setSpan(new ForegroundColorSpan(Color.rgb(59,89, 152)), startPoint, endPoint,Spanned.SPAN_COMPOSING);
        } 
        else if (sCategory.equals(Feed.CATEGORY_LINK)) 
        {   // link
            String linkTitle = "";
            if (attachList != null&& attachList.size()>0) {
                linkTitle = attachList.get(0).getAttachName();
                if(Util.isEmpty(linkTitle)) linkTitle = attachList.get(0).getDescript();
                if(Util.isEmpty(linkTitle)) linkTitle = feed.getCaption();
                if(linkTitle == null) linkTitle = "";
            }
            stringBuilder.append(ctx.getString(R.string.widget_post_link)+ " " + linkTitle);
            String linkUpload = ctx.getString(R.string.widget_post_link)+ " ";

            int startPoint = displayName.length() + linkUpload.length()+ 1;
            int endPoint = displayName.length() + linkUpload.length()+ linkTitle.length() + 1;
            stringBuilder.setSpan(new ForegroundColorSpan(Color.rgb(59,89, 152)), startPoint, endPoint,Spanned.SPAN_COMPOSING);
        } else if (sCategory.equals(Feed.CATEGORY_NOTE)) {// note
            String noteTitle = "";
            if (attachList != null) {
                noteTitle = attachList.get(0).getAttachName();
            }
            stringBuilder.append(ctx.getString(R.string.widget_post_note)+ " " + noteTitle);
            String postNote = ctx.getString(R.string.widget_post_note)+ " ";

            int startPoint = displayName.length() + postNote.length()+ 1;
            int endPoint = displayName.length() + postNote.length()+ noteTitle.length() + 1;
            stringBuilder.setSpan(new ForegroundColorSpan(Color.rgb(59,89, 152)), startPoint, endPoint,Spanned.SPAN_COMPOSING);
        } else if (sCategory.equals(Feed.CATEGORY_PHOTO)) {// photo
            String albumName = "";
            if (attachList != null) {
                albumName = attachList.get(0).getFolderName();
            }
            stringBuilder.append(ctx.getString(R.string.widget_upload_photo)+ " " + albumName);
            String uploadPhoto = ctx.getString(R.string.widget_upload_photo)+ " ";

            int startPoint = displayName.length()+ uploadPhoto.length() + 1;
            int endPoint = displayName.length() + uploadPhoto.length()+ albumName.length() + 1;
            stringBuilder.setSpan(new ForegroundColorSpan(Color.rgb(59,89, 152)), startPoint, endPoint,Spanned.SPAN_COMPOSING);
        } else if (sCategory.equals(Feed.CATEGORY_VIDEO)) {// video
            String videoName = "";
            if (attachList != null) {
                videoName = attachList.get(0).getAttachName();
            }
            stringBuilder.append(ctx.getString(R.string.widget_upload_video)+ " " + videoName);
            String uploadVideo = ctx.getString(R.string.widget_upload_video)+ " ";

            int startPoint = displayName.length()+ uploadVideo.length() + 1;
            int endPoint = displayName.length() + uploadVideo.length()+ videoName.length() + 1;
            stringBuilder.setSpan(new ForegroundColorSpan(Color.rgb(59,89, 152)), startPoint, endPoint,Spanned.SPAN_COMPOSING);
        } else if (sCategory.equals(Feed.CATEGORY_PROFILE_STATUS)) {// status
            stringBuilder.append(content);
        } else {
            stringBuilder.append(content);
        }
        
        //@�ڿ� �ٴ� �̸� tw ���򵥷� �ϱ� 
        if ( Global.SNS_TWITTER.equals(feed.getSnsId()) ){
            Pattern p = Pattern.compile("(@[\\w]+)|(@[\\w]+[\\s|:])");
            Matcher m = p.matcher(content);
            
            while (m.find()) {
                String replyTo = m.group();
                Log.d("TAG", "replyTo:"+replyTo+ ", (displayName.length()+2)="+ (displayName.length()+2)+", summary.indexOf(replyTo)="+content.indexOf(replyTo)); 
            
                int start = (displayName.length()+2)+content.indexOf(replyTo);
                
                final String tmpName = stringBuilder.toString().substring(start, start+(replyTo.length()-1));
                Log.d("TAG", "tmpName: "+tmpName);
                stringBuilder.setSpan(new ForegroundColorSpan(Color.rgb(30, 168, 215)), start, start+(replyTo.length()-1), Spanned.SPAN_COMPOSING);
                stringBuilder.setSpan(new StyleSpan(Typeface.BOLD), start,start+(replyTo.length()-1), Spanned.SPAN_COMPOSING);
            }
        }

        return stringBuilder;
    }
    
    private String getPublishedTime(Feed feed)
    {
        // time text(5/27����)                
        if(feed.getTextPublished() == null)
        {
            if (feed.getPublished() != null)
            {
                Date toTime;
                
                if(feed.get_Id()!=0) toTime = feed.getPublished();
                else toTime = new Date(System.currentTimeMillis());
                
                String published = Util.getRelativeTimeSpanString( ctx,feed.getPublished(), toTime,  feed.getSnsId());
                if(!Util.isEmpty(feed.getSource())) {
                    published = published + " via " + feed.getSource();
                }
                
                return published;
            }
            else
            {
                return "";
            }
        }
        else
        {
            // return feed.getTextPublished();
            return Util.getRelativeTimeSpanString(ctx , feed.getPublished(),new Date(System.currentTimeMillis()));
        }
        
    }
    
    // Facebook Adapter
    class FaceBookAdapter extends ArrayAdapter<Feed>
    {
        Activity context;
        ArrayList<Feed> m_Feeds;
          
        FaceBookAdapter(Activity context, ArrayList<Feed> feeds) 
        {
            super(context, R.layout.feed_list_item_fb, feeds);
           
            m_Feeds = feeds;
            this.context=context;
        }
        
        public View getView(int position, View convertView, ViewGroup parent) 
        {
            Feed feed = m_FBfeedList.get(position);
            
            LayoutInflater inflater=context.getLayoutInflater();
            
            View lrow=inflater.inflate(R.layout.feed_list_item_fb, null);
            
            // FB �ƹ�Ÿ �̹���
            ImageView iv_avatar = (ImageView)lrow.findViewById(R.id.list_widget_friends_avatar);
            
            Drawable drawable = new BitmapDrawable((Bitmap)mAvatarList.get(feed.getAvatarUrl()));
            iv_avatar.setBackgroundDrawable(drawable);
            
            // ����
            SpannableStringBuilder content = buildContent(feed);
            
            TextView tvFriends_name = (TextView)lrow.findViewById(R.id.list_widget_friends_name);
            tvFriends_name.setText(content);
            
            // Friends Icon...
            int icon = getFriendsIcon(feed);
            
            ImageView ivFriendsIcon = (ImageView)lrow.findViewById(R.id.list_widget_friends_icon);
            if(icon==0) ivFriendsIcon.setVisibility(View.GONE);
            else ivFriendsIcon.setBackgroundResource(icon);
            
            // ���&Like ����
            String comment;
            String like;
        
            int commentCnt = feed.getCommentCnt();
            int likeCnt = feed.getLikeCnt();

            //comment
            if (commentCnt <= 1) comment = ctx.getString(R.string.link_one_comment, commentCnt);
            else comment = ctx.getString(R.string.link_comments, commentCnt);
            
            TextView tvComments = (TextView)lrow.findViewById(R.id.list_widget_comment);
            ImageView ivComments = (ImageView)lrow.findViewById(R.id.widget_comment_img);
            
            tvComments.setText(comment);
            
            //commnet���� ���� visibility����
            if(commentCnt==0)
            {
                tvComments.setVisibility(View.GONE);
                ivComments.setVisibility(View.GONE);
            }
            
            //like ���� ���� person/people
            if (likeCnt <= 1) like = ctx.getString(R.string.like_one_person, likeCnt);
            else like = ctx.getString(R.string.like_people, likeCnt); 
            
            TextView tvLikes = (TextView)lrow.findViewById(R.id.list_widget_like);
            ImageView ivLikes = (ImageView)lrow.findViewById(R.id.widget_like_img);
            
            tvLikes.setText(like);
            
            //like ���� ���� visibility����
            if(likeCnt==0)
            {
                tvLikes.setVisibility(View.GONE);
                ivLikes.setVisibility(View.GONE);
            }
            
            // �ð�
            TextView tvPublished = (TextView)lrow.findViewById(R.id.list_widget_friends_published);
            tvPublished.setText(getPublishedTime(feed));
            
            return lrow;
        }
    }
    
    // Twitter Adapter
    class TwitterAdapter extends ArrayAdapter<Feed>
    {
        Activity context;
        ArrayList<Feed> m_Feeds;
          
        TwitterAdapter(Activity context, ArrayList<Feed> feeds) 
        {
            super(context, R.layout.feed_list_item_tw, feeds);
           
            m_Feeds = feeds;
            this.context=context;
        }
        
        public View getView(int position, View convertView, ViewGroup parent) 
        {
            Feed feed = m_TWfeedList.get(position);
            
            LayoutInflater inflater=context.getLayoutInflater();
            
            View lrow=inflater.inflate(R.layout.feed_list_item_tw, null);
            
            // TW �ƹ�Ÿ �̹���
            ImageView iv_avatar = (ImageView)lrow.findViewById(R.id.list_widget_friends_avatar);
            
            Drawable drawable = new BitmapDrawable((Bitmap)mAvatarList.get(feed.getAvatarUrl()));
            iv_avatar.setBackgroundDrawable(drawable);
            
            // ����
            SpannableStringBuilder content = buildContent(feed);
            
            TextView tvFriends_name = (TextView)lrow.findViewById(R.id.list_widget_friends_name);
            tvFriends_name.setLines(3);
            tvFriends_name.setText(content);
            
            // �ð�
            TextView tvPublished = (TextView)lrow.findViewById(R.id.list_widget_friends_published);
            tvPublished.setText(getPublishedTime(feed));
            
            return lrow;
        }
    }
    
    // MySpace Adapter
    class MySpaceAdapter extends ArrayAdapter<Feed>
    {
        Activity context;
        ArrayList<Feed> m_Feeds;
          
        MySpaceAdapter(Activity context, ArrayList<Feed> feeds) 
        {
            super(context, R.layout.feed_list_item_ms, feeds);
           
            m_Feeds = feeds;
            this.context=context;
        }
        
        public View getView(int position, View convertView, ViewGroup parent) 
        {
            Feed feed = m_MSfeedList.get(position);
            
            LayoutInflater inflater=context.getLayoutInflater();
            
            View lrow=inflater.inflate(R.layout.feed_list_item_ms, null);
            
            // MS �ƹ�Ÿ �̹���
            ImageView iv_avatar = (ImageView)lrow.findViewById(R.id.list_widget_friends_avatar);
            
            Drawable drawable = new BitmapDrawable((Bitmap)mAvatarList.get(feed.getAvatarUrl()));
            iv_avatar.setBackgroundDrawable(drawable);
            
            // ����
            SpannableStringBuilder content = buildContent(feed);
            
            TextView tvFriends_name = (TextView)lrow.findViewById(R.id.list_widget_friends_name);
            tvFriends_name.setText(content);
            
            // Mood + Icon...
            TextView tvMood = (TextView)lrow.findViewById(R.id.list_widget_friends_mood);
            ImageView iv_mood = (ImageView)lrow.findViewById(R.id.list_widget_friends_mood_icon);
            
            String moodText = feed.getMoodFieldText();
            if(!Util.isEmpty(moodText)) {//moodText
                  Log.d(TAG, "feed.getMoodFieldText()="+feed.getMoodFieldText()+", feed.getMoodEmoticon="+feed.getMoodEmoticon());
                     if(moodText.equals("(none)") && (feed.getMoodEmoticon() == 0 || feed.getMoodEmoticon() == 1)){
                         tvMood.setText("");     
                         iv_mood.setVisibility(View.GONE);    
                     }else{
                         tvMood.setText("Mood : " + moodText);                        
//                          stringBuilder.setSpan(new StyleSpan(Typeface.BOLD), 0, moodText.length(),Spanned.SPAN_COMPOSING);//displayName �۾�ü bold
                          if(feed.getMoodEmoticon() != 0){//emotion icon
                              iv_mood.setImageResource(Feed.emoticonSet[feed.getMoodEmoticon()-1]);    
                          }
                     }
            }
            
//            tvMood.setText("Mood : " + feed.getMoodFieldText());
//            if(feed.getMoodEmoticon() > 1){
//                
//                iv_mood.setBackgroundResource(Feed.emoticonSet[feed.getMoodEmoticon()-1]);
//            }
            
            // �ð�
            TextView tvPublished = (TextView)lrow.findViewById(R.id.list_widget_friends_published);
            tvPublished.setText(getPublishedTime(feed));
            
            return lrow;
        }
    }
    
}


