/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 *
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.06.01    SungHwa.Woo         Initial Release
 *
 */
package com.lge.sns.client.widget;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;

import com.lge.launcher.R;
import com.lge.sns.client.UIConst;


/**
 * to start activity from Widget.
 *
 *
 */
public final class WidgetBase extends Activity {

    private static final String TAG = "WidgetBase";

    
    private boolean redirectFinish = false;
    

    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        
    }    
    
    public void onResume() {
    	super.onResume();
    	
    	if(redirectFinish)
    	{
    		finish();
    	}
    	else
    	{
	        setContentView(R.layout.notification_blank);
	        
	        try
	        {
		        Intent iIntent = getIntent();
		        String uri = iIntent.getStringExtra(UIConst.EXTRA_KEY_URI);
		        //Parcelable �� �Ѱܾ��� extra �� ������ �߰�.
		        Parcelable tempParcelableExtra = iIntent.getParcelableExtra(UIConst.EXTRA_KEY_FEED);
		        
		        Intent redirectIntent = Intent.parseUri(uri,0);
		
		        if(tempParcelableExtra!=null)
		        	redirectIntent.putExtra(UIConst.EXTRA_KEY_FEED , tempParcelableExtra); 
		        	
		        Log.d(TAG,"Redirect to >>>> "+redirectIntent.getAction());
		        
		        startActivity(redirectIntent);
		        
		        redirectFinish = true;
		        
		        
	        }catch(Exception e)
	        {
	        	e.printStackTrace();
	        	finish(); //20100622 sunghwa.woo@lge.com ����ó��.
	        }
                
    	}
    }
    


}
