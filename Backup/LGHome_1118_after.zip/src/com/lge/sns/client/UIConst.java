/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 *
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.04.02    hjunseo             Initial Release
 *
 */
package com.lge.sns.client;

import com.lge.sns.Global;

/**
 * UI client constant variables
 *
 * @author Park Sung-Gu(sunggu.park@lge.com)
 * @version 1.0
 */
public class UIConst {

    // =======================================
    // Action name
    // =======================================
    // Home screen�� ���������κ���
    public static final String INTENT_ACTION_FACEBOOK_LOGIN = "com.lge.sns.client.account.intent.action.FACEBOOK_LOGIN";
    public static final String INTENT_ACTION_TWITTER_LOGIN = "com.lge.sns.client.account.intent.action.TWITTER_LOGIN";
    public static final String INTENT_ACTION_MYSPACE_LOGIN = "com.lge.sns.client.account.intent.action.MYSPACE_LOGIN";
    public static final String INTENT_ACTION_ORKUT_LOGIN = "com.lge.sns.client.account.intent.action.ORKUT_LOGIN";
    public static final String INTENT_ACTION_BEBO_LOGIN = "com.lge.sns.client.account.intent.action.BEBO_LOGIN";

    public static final String ACTION_VIEW_PROFILE = "com.lge.sns.profile.intent.action.VIEW_PROFILE";
    public static final String ACTION_VIEW_PROFILE_TWITTER = "com.lge.sns.profile.intent.action.VIEW_PROFILE_TWITTER";
    public static final String ACTION_VIEW_PROFILE_MYSPACE = "com.lge.sns.profile.intent.action.VIEW_PROFILE_MYSPACE";
    public static final String ACTION_VIEW_PROFILE_ORKUT = "com.lge.sns.profile.intent.action.VIEW_PROFILE_ORKUT";
    
    public static final String INTENT_ACTION_WIDGETBASE = "com.lge.sns.client.widget.intent.action.WIDGETBASE";
    
    // =======================================
    //  Common extra key definitions
    // =======================================

    public static final String KEY_SNS_ID = "sns_id";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_FROM_EXTERNAL = "from_module";
    public static final String KEY_LOGOUT = "logout";
    public static final String KEY_RELOGIN = "relogin";
    public static final String KEY_LOGIN_REQUIRED = "login_required";
    public static final String KEY_FEED_TYPES = "feed_type";

    // =======================================
    // (Old version compatible) sn manager menu
    // =======================================

    public static final String INTENT_ACTION_VIEW_FACEBOOK_HOME = "com.lge.sns.feed.intent.action.VIEW_FACEBOOK_HOME";
    public static final String INTENT_ACTION_VIEW_TWITTER_HOME = "com.lge.sns.feed.intent.action.VIEW_TWITTER_HOME";
    public static final String INTENT_ACTION_VIEW_MYSPACE_HOME = "com.lge.sns.feed.intent.action.VIEW_MYSPACE_HOME";
    public static final String INTENT_ACTION_VIEW_ORKUT_HOME = "com.lge.sns.feed.intent.action.VIEW_ORKUT_HOME";
    public static final String INTENT_ACTION_VIEW_BEBO_HOME = "com.lge.sns.feed.intent.action.VIEW_BEBO_HOME";
    public static final String INTENT_ACTION_WRITE_FEED_COMMENT = "com.lge.sns.feed.intent.action.WRITE_FEED_COMMENT";

    

    // Extra Key Valuse
    public static final String EXTRA_KEY_URI      = "person_uri";
    public static final String EXTRA_KEY_FEED_ID  = "feed_id";
    public static final String EXTRA_KEY_FEED  = "feed";
    public static final String EXTRA_KEY_FRIENDS_ID  = "friends_id";
    public static final String EXTRA_KEY_ATTACH_LIST = "attach_list"; 
    

    // SNS ID�� �ش��ϴ� �α��� ȭ�� INTENT ACTION �� ����
    public static String getSnsLoginAction(String snsId) {

        if (snsId.equals(Global.SNS_FACEBOOK))
            return UIConst.INTENT_ACTION_FACEBOOK_LOGIN;
        else if (snsId.equals(Global.SNS_TWITTER))
            return UIConst.INTENT_ACTION_TWITTER_LOGIN;
        else if (snsId.equals(Global.SNS_MYSPACE))
            return UIConst.INTENT_ACTION_MYSPACE_LOGIN;
        else if (snsId.equals(Global.SNS_ORKUT))
            return UIConst.INTENT_ACTION_ORKUT_LOGIN;

        // won't ever happen
        throw new RuntimeException(new Throwable("Required a reasonable SNS ID"));
    }

    
    /* �� SNS���� �������� action�� ��ȯ�մϴ�. */
    public static String getProfileAction(String snsId) {

            if (snsId.equals(Global.SNS_FACEBOOK))
                return UIConst.ACTION_VIEW_PROFILE;
            else if (snsId.equals(Global.SNS_TWITTER))
                return UIConst.ACTION_VIEW_PROFILE_TWITTER;
            else if(snsId.equals(Global.SNS_MYSPACE))
                return UIConst.ACTION_VIEW_PROFILE_MYSPACE;
            else if(snsId.equals(Global.SNS_ORKUT))
            	return UIConst.ACTION_VIEW_PROFILE_ORKUT;
            // won't ever happen
            throw new RuntimeException(new Throwable("Required a reasonable SNS ID"));
        }
    
}
