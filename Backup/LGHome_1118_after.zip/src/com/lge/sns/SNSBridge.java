/*
 *   MAE Group, Software Center, LG ELECTRONICS INC., SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns;

import android.view.View;
import android.view.ViewGroup;

import com.lge.launcher.CellLayout;
import com.lge.sns.client.widget.FeedWidget.FeedWidget;

public class SNSBridge {
    public static final String SNS_CLASSIC_FEED_PROVIDER = "com.lge.sns.client.widget.FeedWidget.FeedWidgetAggregatorProvider";
    public static final String SNS_FEED_CLASSNAME = "com.lge.sns.client.widget.FeedWidget.FeedWidget";
	public static final String SNS_FEED_WIDGET = "sns_feed_widget";
	public static final String TAG_SNS_FEED_WIDGET = "sns_feed_widget";
	public static final int ITEM_TYPE_SNS_FEED_WIDGET = 9999;
	public static final int SPAN_X = 4;
	public static final int SPAN_Y = 4;
	
	
	

    private static FeedWidget findSNSWidget(CellLayout screen) {
        final int count = screen.getChildCount();
        for (int i = 0; i < count; i++) {
            View v = screen.getChildAt(i);
            if (v instanceof FeedWidget) {
                return (FeedWidget) v;
            }
        }
        return null;
    }
    
    public static FeedWidget findSnsWidgetOnCurrentScreen(ViewGroup vg, int screenIndex) {
        CellLayout currentScreen = (CellLayout)vg.getChildAt(screenIndex);
        return findSNSWidget(currentScreen);
    }
    
}
