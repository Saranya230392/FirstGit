/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 *   
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.01.13    dohwaji             Initial Release
 *   
 */
package com.lge.sns.remoteservice.profile;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import com.lge.sns.service.profile.IProfileService;

public class RemoteProfileService {
	public static interface RemoteProfileCallback {
		void onConnected(IProfileService remoteService);
	}
	
	private RemoteProfileCallback rCallback = null;
	
	private IProfileService remoteService;
	private RemoteServiceConnection conn = null;
	
	static private RemoteProfileService instance;
	private Context ctx;
	
	static public RemoteProfileService getInstance(Context ctx) {
//		if(instance == null) {
//			instance = new RemoteProfileService(ctx);
//		}
		return new RemoteProfileService(ctx);
	}
	
	private RemoteProfileService(Context ctx) {
		this.ctx = ctx;

	}
    
	public void executeService(RemoteProfileCallback rCallback) {
		this.rCallback = rCallback;
		
		conn = new RemoteServiceConnection();
		Intent i = new Intent();
		i.setClassName("com.lge.sns", "com.lge.sns.service.profile.ProfileService");
		ctx.bindService(i, conn, Context.BIND_AUTO_CREATE);		
		Log.d( getClass().getSimpleName(), "bindService()" );
	} 
	  
	class RemoteServiceConnection implements ServiceConnection {
		public void onServiceConnected(ComponentName className, IBinder boundService ) {
			remoteService = IProfileService.Stub.asInterface((IBinder)boundService);
			rCallback.onConnected(remoteService);			
		}

		public void onServiceDisconnected(ComponentName className) {
			remoteService = null;
			Log.d( getClass().getSimpleName(), "onServiceDisconnected" );
		}
	};	
}
