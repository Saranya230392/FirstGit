/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 *   
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.01.13    dohwaji             Initial Release
 *   
 */
package com.lge.sns.remoteservice.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import com.lge.sns.service.media.IMediaService;

public class RemoteMediaService {
	public static interface RemoteMediaCallback {
		void onConnected(IMediaService remoteService);
	}
	
	private RemoteMediaCallback rCallback = null;
	
	private IMediaService remoteService;
	private RemoteServiceConnection conn = null;
	
	private static RemoteMediaService instance;
	private Context ctx;
	
	public static RemoteMediaService getInstance(Context ctx) {
		if(instance == null) {
			instance = new RemoteMediaService(ctx);
		}
		return instance;
	}
	
	private RemoteMediaService(Context ctx) {
		this.ctx = ctx; 
	}
    
    public void executeService(RemoteMediaCallback rCallback) {
    	this.rCallback = rCallback;
    	
        conn = new RemoteServiceConnection();
		Intent mediaIntent = new Intent();
		mediaIntent.setClassName("com.lge.sns", "com.lge.sns.service.media.MediaService");        
        ctx.bindService(mediaIntent, conn, Context.BIND_AUTO_CREATE);  
        Log.d( getClass().getSimpleName(), "bindService()" );
    }
    
    class RemoteServiceConnection implements ServiceConnection {
        public void onServiceConnected(ComponentName className, IBinder boundService ) {
        	remoteService = IMediaService.Stub.asInterface((IBinder)boundService);
        	rCallback.onConnected(remoteService);
        	Log.d( getClass().getSimpleName(), "onServiceConnected()" );
        }

        public void onServiceDisconnected(ComponentName className) {
        	remoteService = null;
        	Log.d( getClass().getSimpleName(), "onServiceDisconnected()" );
        }
    };
}
