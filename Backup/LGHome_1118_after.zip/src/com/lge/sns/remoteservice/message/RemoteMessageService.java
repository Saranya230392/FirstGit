/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 *   
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.03.09    eunhwa             Initial Release
 *   
 */
package com.lge.sns.remoteservice.message;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import com.lge.sns.service.message.IMessageService;

public class RemoteMessageService {
	public static interface RemoteMessageCallback {
		void onConnected(IMessageService remoteService);
	}
	
	private RemoteMessageCallback rCallback = null;
	
	private IMessageService remoteService;
	private RemoteServiceConnection conn = null;
	
	static private RemoteMessageService instance;
	private Context ctx;
	
	static public RemoteMessageService getInstance(Context ctx) {
		if(instance == null) {
			instance = new RemoteMessageService(ctx);
		}
		return instance;
	}
	
	private RemoteMessageService(Context ctx) {
		this.ctx = ctx;

	}
    
	public void executeService(RemoteMessageCallback rCallback) {
		this.rCallback = rCallback;
		
		conn = new RemoteServiceConnection();
		Intent i = new Intent();
		i.setClassName("com.lge.sns", "com.lge.sns.service.message.MessageService");
		ctx.bindService(i, conn, Context.BIND_AUTO_CREATE);		
		Log.d( getClass().getSimpleName(), "bindService()" );
	} 
	  
	class RemoteServiceConnection implements ServiceConnection {
		public void onServiceConnected(ComponentName className, IBinder boundService ) {
			remoteService = IMessageService.Stub.asInterface((IBinder)boundService);
			rCallback.onConnected(remoteService);			
		}

		public void onServiceDisconnected(ComponentName className) {
			remoteService = null;
			Log.d( getClass().getSimpleName(), "onServiceDisconnected" );
		}
	};	
}
