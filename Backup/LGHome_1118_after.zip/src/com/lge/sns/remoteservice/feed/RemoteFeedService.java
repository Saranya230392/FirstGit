/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 *   
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.01.13    dohwaji             Initial Release
 *   
 */
package com.lge.sns.remoteservice.feed;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

import com.lge.sns.service.feed.IFeedService;



public class RemoteFeedService {
	public static interface RemoteFeedCallback {
		void onConnected(IFeedService remoteService);
	}
	
	private RemoteFeedCallback rCallback = null;
	
	private IFeedService remoteService;
	private RemoteServiceConnection conn = null;
	
	private static RemoteFeedService instance;
	private Context ctx;
	
	public static RemoteFeedService getInstance(Context ctx) {
//		if(instance == null) {
//			instance = new RemoteFeedService(ctx);
//		}
		return new RemoteFeedService(ctx);
	}
	
	private RemoteFeedService(Context ctx) {
		this.ctx = ctx; 
	}
    
    public void executeService(RemoteFeedCallback rCallback) {
    	this.rCallback = rCallback;
    	
        conn = new RemoteServiceConnection();
		Intent feedIntent = new Intent();
		feedIntent.setClassName("com.lge.sns", "com.lge.sns.service.feed.FeedService");        
        ctx.bindService(feedIntent, conn, Context.BIND_AUTO_CREATE);  
        Log.d( getClass().getSimpleName(), "bindService()" );
    }
    
    class RemoteServiceConnection implements ServiceConnection {
        public void onServiceConnected(ComponentName className, IBinder boundService ) {
        	remoteService = IFeedService.Stub.asInterface((IBinder)boundService);
        	rCallback.onConnected(remoteService);
        	Log.d( getClass().getSimpleName(), "onServiceConnected()" );
        }

        public void onServiceDisconnected(ComponentName className) {
        	remoteService = null;
        	Log.d( getClass().getSimpleName(), "onServiceDisconnected()" );
        }
    };
}
