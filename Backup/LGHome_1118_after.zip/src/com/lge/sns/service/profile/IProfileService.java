/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\DROIDDEV\\workspace\\HEAVEN_SNS\\src\\com\\lge\\sns\\service\\profile\\IProfileService.aidl
 */
package com.lge.sns.service.profile;
public interface IProfileService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.lge.sns.service.profile.IProfileService
{
private static final java.lang.String DESCRIPTOR = "com.lge.sns.service.profile.IProfileService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.lge.sns.service.profile.IProfileService interface,
 * generating a proxy if needed.
 */
public static com.lge.sns.service.profile.IProfileService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.lge.sns.service.profile.IProfileService))) {
return ((com.lge.sns.service.profile.IProfileService)iin);
}
return new com.lge.sns.service.profile.IProfileService.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getProfile:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
com.lge.sns.agent.profile.Profile _result = this.getProfile(_arg0, _arg1, _arg2);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_getFriendUriList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.util.List<android.net.Uri> _result = this.getFriendUriList(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getPeopleUriList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _arg3;
_arg3 = data.readInt();
int _arg4;
_arg4 = data.readInt();
java.util.List<android.net.Uri> _result = this.getPeopleUriList(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_importFriendToContacts:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _result = this.importFriendToContacts(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_importFriendsToContacts:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.util.List<java.lang.String> _arg2;
_arg2 = data.createStringArrayList();
int _result = this.importFriendsToContacts(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_updateProfileSyncState:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _arg3;
_arg3 = data.readInt();
int _result = this.updateProfileSyncState(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_updateProfilesSyncState:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.util.List<java.lang.String> _arg2;
_arg2 = data.createStringArrayList();
int _arg3;
_arg3 = data.readInt();
int _result = this.updateProfilesSyncState(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.lge.sns.service.profile.IProfileService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/** <pre>
     * Get user profile for a specified user in SNS DB.
     * If there is no data in SNS DB, get profile from SNS, insert it to SNS DB and return it
     * </pre>
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login userId
     * @param ownerId user id to get profile information
     * @return Profile data
     */
public com.lge.sns.agent.profile.Profile getProfile(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.lge.sns.agent.profile.Profile _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(ownerId);
mRemote.transact(Stub.TRANSACTION_getProfile, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = com.lge.sns.agent.profile.Profile.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get my friend list in SNS DB
     *
     * @param snsId sns id( 'fb','tw','ms' )
     * @param userId login id
     * @param keyword search keyword
     * @return URI indicating a friend (See also : getFriend API)
     */
public java.util.List<android.net.Uri> getFriendUriList(java.lang.String snsId, java.lang.String userId, java.lang.String keyword) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.net.Uri> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(keyword);
mRemote.transact(Stub.TRANSACTION_getFriendUriList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.net.Uri.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get keyword matched people list from SNS
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param keyword search keyword
     * @return URI indicating a people
     */
public java.util.List<android.net.Uri> getPeopleUriList(java.lang.String snsId, java.lang.String userId, java.lang.String keyword, int pageNum, int pageSize) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.net.Uri> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(keyword);
_data.writeInt(pageNum);
_data.writeInt(pageSize);
mRemote.transact(Stub.TRANSACTION_getPeopleUriList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.net.Uri.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Import a specified user's profile into Contacts DB  (For Contact Synchronization)
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param ownerId Owner id of profile to import into Contacts
     * @return result ( 1 : Success, 0 : Fail )
     */
public int importFriendToContacts(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(ownerId);
mRemote.transact(Stub.TRANSACTION_importFriendToContacts, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Import specified users' profiles into Contact DB (For Contact Synchronization)
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param ownerIds several owner IDs of profile to import into Contacts
     * @return result ( 1 : Success, 0 : Fail )
     */
public int importFriendsToContacts(java.lang.String snsId, java.lang.String userId, java.util.List<java.lang.String> ownerIds) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeStringList(ownerIds);
mRemote.transact(Stub.TRANSACTION_importFriendsToContacts, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Update a specified user profile's synchronization state  (For Contact Synchronization)
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param ownerId Owner ID to update synchronization state
     * @param state Synchronization State (0: No, 1 : Imported, 2 : scheduled)
     * @return result ( 1 : Success, 0 : Fail )
     */
public int updateProfileSyncState(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId, int state) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(ownerId);
_data.writeInt(state);
mRemote.transact(Stub.TRANSACTION_updateProfileSyncState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Update specified users' synchronization states  (For Contact Synchronization)
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param ownerIds several owner IDs to update synchronization states
     * @param state Sync State (0: No, 1 : Imported, 2 : scheduled)
     * @return result ( 1 : Success, 0 : Fail )
     */
public int updateProfilesSyncState(java.lang.String snsId, java.lang.String userId, java.util.List<java.lang.String> ownerIds, int state) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeStringList(ownerIds);
_data.writeInt(state);
mRemote.transact(Stub.TRANSACTION_updateProfilesSyncState, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getProfile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getFriendUriList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getPeopleUriList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_importFriendToContacts = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_importFriendsToContacts = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_updateProfileSyncState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_updateProfilesSyncState = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
}
/** <pre>
     * Get user profile for a specified user in SNS DB.
     * If there is no data in SNS DB, get profile from SNS, insert it to SNS DB and return it
     * </pre>
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login userId
     * @param ownerId user id to get profile information
     * @return Profile data
     */
public com.lge.sns.agent.profile.Profile getProfile(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId) throws android.os.RemoteException;
/**
     * Get my friend list in SNS DB
     *
     * @param snsId sns id( 'fb','tw','ms' )
     * @param userId login id
     * @param keyword search keyword
     * @return URI indicating a friend (See also : getFriend API)
     */
public java.util.List<android.net.Uri> getFriendUriList(java.lang.String snsId, java.lang.String userId, java.lang.String keyword) throws android.os.RemoteException;
/**
     * Get keyword matched people list from SNS
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param keyword search keyword
     * @return URI indicating a people
     */
public java.util.List<android.net.Uri> getPeopleUriList(java.lang.String snsId, java.lang.String userId, java.lang.String keyword, int pageNum, int pageSize) throws android.os.RemoteException;
/**
     * Import a specified user's profile into Contacts DB  (For Contact Synchronization)
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param ownerId Owner id of profile to import into Contacts
     * @return result ( 1 : Success, 0 : Fail )
     */
public int importFriendToContacts(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId) throws android.os.RemoteException;
/**
     * Import specified users' profiles into Contact DB (For Contact Synchronization)
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param ownerIds several owner IDs of profile to import into Contacts
     * @return result ( 1 : Success, 0 : Fail )
     */
public int importFriendsToContacts(java.lang.String snsId, java.lang.String userId, java.util.List<java.lang.String> ownerIds) throws android.os.RemoteException;
/**
     * Update a specified user profile's synchronization state  (For Contact Synchronization)
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param ownerId Owner ID to update synchronization state
     * @param state Synchronization State (0: No, 1 : Imported, 2 : scheduled)
     * @return result ( 1 : Success, 0 : Fail )
     */
public int updateProfileSyncState(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId, int state) throws android.os.RemoteException;
/**
     * Update specified users' synchronization states  (For Contact Synchronization)
     *
     * @param snsId SNS id ( 'fb','tw','ms' )
     * @param userId login id
     * @param ownerIds several owner IDs to update synchronization states
     * @param state Sync State (0: No, 1 : Imported, 2 : scheduled)
     * @return result ( 1 : Success, 0 : Fail )
     */
public int updateProfilesSyncState(java.lang.String snsId, java.lang.String userId, java.util.List<java.lang.String> ownerIds, int state) throws android.os.RemoteException;
}
