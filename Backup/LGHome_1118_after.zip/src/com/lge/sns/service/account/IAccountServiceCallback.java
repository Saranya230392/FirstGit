/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\DROIDDEV\\workspace\\HEAVEN_SNS\\src\\com\\lge\\sns\\service\\account\\IAccountServiceCallback.aidl
 */
package com.lge.sns.service.account;
public interface IAccountServiceCallback extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.lge.sns.service.account.IAccountServiceCallback
{
private static final java.lang.String DESCRIPTOR = "com.lge.sns.service.account.IAccountServiceCallback";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.lge.sns.service.account.IAccountServiceCallback interface,
 * generating a proxy if needed.
 */
public static com.lge.sns.service.account.IAccountServiceCallback asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.lge.sns.service.account.IAccountServiceCallback))) {
return ((com.lge.sns.service.account.IAccountServiceCallback)iin);
}
return new com.lge.sns.service.account.IAccountServiceCallback.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onAccountAdded:
{
data.enforceInterface(DESCRIPTOR);
com.lge.sns.agent.account.AccountInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.lge.sns.agent.account.AccountInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.onAccountAdded(_arg0);
return true;
}
case TRANSACTION_onAccountUpdated:
{
data.enforceInterface(DESCRIPTOR);
com.lge.sns.agent.account.AccountInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.lge.sns.agent.account.AccountInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.onAccountUpdated(_arg0);
return true;
}
case TRANSACTION_onAccountRemoved:
{
data.enforceInterface(DESCRIPTOR);
com.lge.sns.agent.account.AccountInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.lge.sns.agent.account.AccountInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.onAccountRemoved(_arg0);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.lge.sns.service.account.IAccountServiceCallback
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
public void onAccountAdded(com.lge.sns.agent.account.AccountInfo account) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((account!=null)) {
_data.writeInt(1);
account.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onAccountAdded, _data, null, android.os.IBinder.FLAG_ONEWAY);
}
finally {
_data.recycle();
}
}
public void onAccountUpdated(com.lge.sns.agent.account.AccountInfo account) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((account!=null)) {
_data.writeInt(1);
account.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onAccountUpdated, _data, null, android.os.IBinder.FLAG_ONEWAY);
}
finally {
_data.recycle();
}
}
public void onAccountRemoved(com.lge.sns.agent.account.AccountInfo account) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((account!=null)) {
_data.writeInt(1);
account.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onAccountRemoved, _data, null, android.os.IBinder.FLAG_ONEWAY);
}
finally {
_data.recycle();
}
}
}
static final int TRANSACTION_onAccountAdded = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onAccountUpdated = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onAccountRemoved = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
}
public void onAccountAdded(com.lge.sns.agent.account.AccountInfo account) throws android.os.RemoteException;
public void onAccountUpdated(com.lge.sns.agent.account.AccountInfo account) throws android.os.RemoteException;
public void onAccountRemoved(com.lge.sns.agent.account.AccountInfo account) throws android.os.RemoteException;
}
