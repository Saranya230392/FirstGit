/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\DROIDDEV\\workspace\\HEAVEN_SNS\\src\\com\\lge\\sns\\service\\media\\IMediaService.aidl
 */
package com.lge.sns.service.media;
public interface IMediaService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.lge.sns.service.media.IMediaService
{
private static final java.lang.String DESCRIPTOR = "com.lge.sns.service.media.IMediaService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.lge.sns.service.media.IMediaService interface,
 * generating a proxy if needed.
 */
public static com.lge.sns.service.media.IMediaService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.lge.sns.service.media.IMediaService))) {
return ((com.lge.sns.service.media.IMediaService)iin);
}
return new com.lge.sns.service.media.IMediaService.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_getMediaFileFromServer:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
com.lge.sns.agent.media.MediaFile _result = this.getMediaFileFromServer(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_getMediaFolderTitleImage:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
com.lge.sns.agent.media.MediaFile _result = this.getMediaFolderTitleImage(_arg0, _arg1, _arg2);
reply.writeNoException();
if ((_result!=null)) {
reply.writeInt(1);
_result.writeToParcel(reply, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
}
else {
reply.writeInt(0);
}
return true;
}
case TRANSACTION_getMediaFileCount:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _result = this.getMediaFileCount(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getMediaFolderUriList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.util.List<android.net.Uri> _result = this.getMediaFolderUriList(_arg0, _arg1);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getAlbumUriList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.util.List<android.net.Uri> _result = this.getAlbumUriList(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_uploadMediaFile:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
android.net.Uri _arg2;
if ((0!=data.readInt())) {
_arg2 = android.net.Uri.CREATOR.createFromParcel(data);
}
else {
_arg2 = null;
}
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
android.content.Intent _arg5;
if ((0!=data.readInt())) {
_arg5 = android.content.Intent.CREATOR.createFromParcel(data);
}
else {
_arg5 = null;
}
int _result = this.uploadMediaFile(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.lge.sns.service.media.IMediaService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
/**
     * <pre>
     * Get media file from SNS.
     * For your guidance, this media file has picUrl(aka. Original Image URL ). 
     * As this media file has not thumbnailUrl, you have to use for picUrl only. 
     * </pre>
     * @param snsId  SNS id ( 'fb','ms' )
     * @param userId login id
     * @param ownerId user id to get image information
     * @param folderId folder(aka. album) id
     * @param mediaId media(aka. file) id
     * @return Media File
     */
public com.lge.sns.agent.media.MediaFile getMediaFileFromServer(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId, java.lang.String folderId, java.lang.String mediaId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.lge.sns.agent.media.MediaFile _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(ownerId);
_data.writeString(folderId);
_data.writeString(mediaId);
mRemote.transact(Stub.TRANSACTION_getMediaFileFromServer, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = com.lge.sns.agent.media.MediaFile.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get title image of a specific media folder from SNS DB.
     *
     * @param snsId  SNS id ( 'fb','ms' )
     * @param ownerId user id to get image information
     * @param folderId folder(aka. album) id
     * @return Title Image
     */
public com.lge.sns.agent.media.MediaFile getMediaFolderTitleImage(java.lang.String snsId, java.lang.String ownerId, java.lang.String folderId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
com.lge.sns.agent.media.MediaFile _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(ownerId);
_data.writeString(folderId);
mRemote.transact(Stub.TRANSACTION_getMediaFolderTitleImage, _data, _reply, 0);
_reply.readException();
if ((0!=_reply.readInt())) {
_result = com.lge.sns.agent.media.MediaFile.CREATOR.createFromParcel(_reply);
}
else {
_result = null;
}
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get total number of media file for a specific media folder from SNS DB.
     *
     * @param snsId SNS id ( 'fb','ms' )
     * @param userId login id
     * @param folderId if specifies ID, the number of media file for a specified folder id
     *                 if not specifies, the number of media file for all media files
     * @return MediaFile data
     */
public int getMediaFileCount(java.lang.String snsId, java.lang.String userId, java.lang.String folderId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(folderId);
mRemote.transact(Stub.TRANSACTION_getMediaFileCount, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * Get URI of media folder(aka. album) from SNS DB.
     * If there is no data in SNS DB, get media folder from SNS, insert them into SNS DB and return them
     *
     * @param snsId SNS id ( 'fb', 'ms' )
     * @param userId login id
     * @return URI
     */
public java.util.List<android.net.Uri> getMediaFolderUriList(java.lang.String snsId, java.lang.String userId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.net.Uri> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
mRemote.transact(Stub.TRANSACTION_getMediaFolderUriList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.net.Uri.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * <pre>
     * Get URI of media folder(aka. album) for a specified ownerID from SNS DB.
     * If there is no data in SNS DB, get media folder from SNS, insert them into SNS DB and return them
     * </pre>
     * @param snsId SNS id ( 'fb', 'ms' )
     * @param userId login id
     * @param ownerId user id to get information
     * @return URI
     */
public java.util.List<android.net.Uri> getAlbumUriList(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.net.Uri> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(ownerId);
mRemote.transact(Stub.TRANSACTION_getAlbumUriList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.net.Uri.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
/**
     * <pre>
     * Facebook, MySpace : Uploads a media file(aka. image) to a default folder('LG Phone Photos')
     * Twitter           : Uploads a media file to TwitGoo and post a tweet a image url.
     * </pre>
     * @param snsId snsId ( 'fb','tw','ms' )
     * @param userId login id
     * @param uri local path of the photo file
     * @param caption  description of the photo
     * @param extraId Message to get through Broadcasting
     * @param failIntent Intent to move when "upload fail" notification is clicked.
     * @return result ( 1 : Success, 0 : Fail )
     * @throws ServerConnectFail
     * @throws InvalidResponseException
     */
public int uploadMediaFile(java.lang.String snsId, java.lang.String userId, android.net.Uri uri, java.lang.String caption, java.lang.String extraId, android.content.Intent failIntent) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
if ((uri!=null)) {
_data.writeInt(1);
uri.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeString(caption);
_data.writeString(extraId);
if ((failIntent!=null)) {
_data.writeInt(1);
failIntent.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_uploadMediaFile, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_getMediaFileFromServer = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getMediaFolderTitleImage = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getMediaFileCount = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getMediaFolderUriList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getAlbumUriList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_uploadMediaFile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
}
/**
     * <pre>
     * Get media file from SNS.
     * For your guidance, this media file has picUrl(aka. Original Image URL ). 
     * As this media file has not thumbnailUrl, you have to use for picUrl only. 
     * </pre>
     * @param snsId  SNS id ( 'fb','ms' )
     * @param userId login id
     * @param ownerId user id to get image information
     * @param folderId folder(aka. album) id
     * @param mediaId media(aka. file) id
     * @return Media File
     */
public com.lge.sns.agent.media.MediaFile getMediaFileFromServer(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId, java.lang.String folderId, java.lang.String mediaId) throws android.os.RemoteException;
/**
     * Get title image of a specific media folder from SNS DB.
     *
     * @param snsId  SNS id ( 'fb','ms' )
     * @param ownerId user id to get image information
     * @param folderId folder(aka. album) id
     * @return Title Image
     */
public com.lge.sns.agent.media.MediaFile getMediaFolderTitleImage(java.lang.String snsId, java.lang.String ownerId, java.lang.String folderId) throws android.os.RemoteException;
/**
     * Get total number of media file for a specific media folder from SNS DB.
     *
     * @param snsId SNS id ( 'fb','ms' )
     * @param userId login id
     * @param folderId if specifies ID, the number of media file for a specified folder id
     *                 if not specifies, the number of media file for all media files
     * @return MediaFile data
     */
public int getMediaFileCount(java.lang.String snsId, java.lang.String userId, java.lang.String folderId) throws android.os.RemoteException;
/**
     * Get URI of media folder(aka. album) from SNS DB.
     * If there is no data in SNS DB, get media folder from SNS, insert them into SNS DB and return them
     *
     * @param snsId SNS id ( 'fb', 'ms' )
     * @param userId login id
     * @return URI
     */
public java.util.List<android.net.Uri> getMediaFolderUriList(java.lang.String snsId, java.lang.String userId) throws android.os.RemoteException;
/**
     * <pre>
     * Get URI of media folder(aka. album) for a specified ownerID from SNS DB.
     * If there is no data in SNS DB, get media folder from SNS, insert them into SNS DB and return them
     * </pre>
     * @param snsId SNS id ( 'fb', 'ms' )
     * @param userId login id
     * @param ownerId user id to get information
     * @return URI
     */
public java.util.List<android.net.Uri> getAlbumUriList(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId) throws android.os.RemoteException;
/**
     * <pre>
     * Facebook, MySpace : Uploads a media file(aka. image) to a default folder('LG Phone Photos')
     * Twitter           : Uploads a media file to TwitGoo and post a tweet a image url.
     * </pre>
     * @param snsId snsId ( 'fb','tw','ms' )
     * @param userId login id
     * @param uri local path of the photo file
     * @param caption  description of the photo
     * @param extraId Message to get through Broadcasting
     * @param failIntent Intent to move when "upload fail" notification is clicked.
     * @return result ( 1 : Success, 0 : Fail )
     * @throws ServerConnectFail
     * @throws InvalidResponseException
     */
public int uploadMediaFile(java.lang.String snsId, java.lang.String userId, android.net.Uri uri, java.lang.String caption, java.lang.String extraId, android.content.Intent failIntent) throws android.os.RemoteException;
}
