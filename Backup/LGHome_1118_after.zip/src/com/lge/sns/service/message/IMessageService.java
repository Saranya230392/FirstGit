/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\DROIDDEV\\workspace\\HEAVEN_SNS\\src\\com\\lge\\sns\\service\\message\\IMessageService.aidl
 */
package com.lge.sns.service.message;
public interface IMessageService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.lge.sns.service.message.IMessageService
{
private static final java.lang.String DESCRIPTOR = "com.lge.sns.service.message.IMessageService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.lge.sns.service.message.IMessageService interface,
 * generating a proxy if needed.
 */
public static com.lge.sns.service.message.IMessageService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.lge.sns.service.message.IMessageService))) {
return ((com.lge.sns.service.message.IMessageService)iin);
}
return new com.lge.sns.service.message.IMessageService.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_postMessage:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
int _result = this.postMessage(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getThreadUriList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _arg3;
_arg3 = data.readInt();
java.util.List<android.net.Uri> _result = this.getThreadUriList(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getMessageUriList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.util.List<android.net.Uri> _result = this.getMessageUriList(_arg0, _arg1, _arg2, _arg3);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_deleteThread:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _result = this.deleteThread(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_setReadThread:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
int _result = this.setReadThread(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_refreshNewThreadUriList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.util.List<android.net.Uri> _result = this.refreshNewThreadUriList(_arg0, _arg1);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_refreshAllThreadUriList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.util.List<android.net.Uri> _result = this.refreshAllThreadUriList(_arg0, _arg1, _arg2);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.lge.sns.service.message.IMessageService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
public int postMessage(java.lang.String snsId, java.lang.String userId, java.lang.String recipientId, java.lang.String threadId, java.lang.String message, java.lang.String title) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(recipientId);
_data.writeString(threadId);
_data.writeString(message);
_data.writeString(title);
mRemote.transact(Stub.TRANSACTION_postMessage, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public java.util.List<android.net.Uri> getThreadUriList(java.lang.String snsId, java.lang.String userId, java.lang.String mode, int pageNum) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.net.Uri> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(mode);
_data.writeInt(pageNum);
mRemote.transact(Stub.TRANSACTION_getThreadUriList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.net.Uri.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public java.util.List<android.net.Uri> getMessageUriList(java.lang.String snsId, java.lang.String userId, java.lang.String threadId, java.lang.String mode) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.net.Uri> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(threadId);
_data.writeString(mode);
mRemote.transact(Stub.TRANSACTION_getMessageUriList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.net.Uri.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int deleteThread(java.lang.String snsId, java.lang.String userId, java.lang.String threadId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(threadId);
mRemote.transact(Stub.TRANSACTION_deleteThread, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int setReadThread(java.lang.String snsId, java.lang.String userId, java.lang.String threadId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(threadId);
mRemote.transact(Stub.TRANSACTION_setReadThread, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public java.util.List<android.net.Uri> refreshNewThreadUriList(java.lang.String snsId, java.lang.String userId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.net.Uri> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
mRemote.transact(Stub.TRANSACTION_refreshNewThreadUriList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.net.Uri.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public java.util.List<android.net.Uri> refreshAllThreadUriList(java.lang.String snsId, java.lang.String userId, java.lang.String mode) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<android.net.Uri> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(mode);
mRemote.transact(Stub.TRANSACTION_refreshAllThreadUriList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(android.net.Uri.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
}
static final int TRANSACTION_postMessage = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_getThreadUriList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getMessageUriList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_deleteThread = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_setReadThread = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_refreshNewThreadUriList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_refreshAllThreadUriList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
}
public int postMessage(java.lang.String snsId, java.lang.String userId, java.lang.String recipientId, java.lang.String threadId, java.lang.String message, java.lang.String title) throws android.os.RemoteException;
public java.util.List<android.net.Uri> getThreadUriList(java.lang.String snsId, java.lang.String userId, java.lang.String mode, int pageNum) throws android.os.RemoteException;
public java.util.List<android.net.Uri> getMessageUriList(java.lang.String snsId, java.lang.String userId, java.lang.String threadId, java.lang.String mode) throws android.os.RemoteException;
public int deleteThread(java.lang.String snsId, java.lang.String userId, java.lang.String threadId) throws android.os.RemoteException;
public int setReadThread(java.lang.String snsId, java.lang.String userId, java.lang.String threadId) throws android.os.RemoteException;
public java.util.List<android.net.Uri> refreshNewThreadUriList(java.lang.String snsId, java.lang.String userId) throws android.os.RemoteException;
public java.util.List<android.net.Uri> refreshAllThreadUriList(java.lang.String snsId, java.lang.String userId, java.lang.String mode) throws android.os.RemoteException;
}
