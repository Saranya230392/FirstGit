/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\DROIDDEV\\workspace\\HEAVEN_SNS\\src\\com\\lge\\sns\\service\\feed\\IFeedService.aidl
 */
package com.lge.sns.service.feed;
public interface IFeedService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.lge.sns.service.feed.IFeedService
{
private static final java.lang.String DESCRIPTOR = "com.lge.sns.service.feed.IFeedService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.lge.sns.service.feed.IFeedService interface,
 * generating a proxy if needed.
 */
public static com.lge.sns.service.feed.IFeedService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.lge.sns.service.feed.IFeedService))) {
return ((com.lge.sns.service.feed.IFeedService)iin);
}
return new com.lge.sns.service.feed.IFeedService.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_postFeed:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
int _result = this.postFeed(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_postFeedMS:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
java.lang.String _arg5;
_arg5 = data.readString();
java.lang.String _arg6;
_arg6 = data.readString();
int _result = this.postFeedMS(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6);
reply.writeNoException();
reply.writeInt(_result);
return true;
}
case TRANSACTION_getFeedList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
java.lang.String _arg4;
_arg4 = data.readString();
int _arg5;
_arg5 = data.readInt();
java.util.List<com.lge.sns.agent.feed.Feed> _result = this.getFeedList(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getWallToWallFeedList:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
java.lang.String _arg2;
_arg2 = data.readString();
java.lang.String _arg3;
_arg3 = data.readString();
int _arg4;
_arg4 = data.readInt();
java.util.List<com.lge.sns.agent.feed.Feed> _result = this.getWallToWallFeedList(_arg0, _arg1, _arg2, _arg3, _arg4);
reply.writeNoException();
reply.writeTypedList(_result);
return true;
}
case TRANSACTION_getFeedAIDLWidgetListUpdatedTime:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
java.lang.String _arg1;
_arg1 = data.readString();
long _result = this.getFeedAIDLWidgetListUpdatedTime(_arg0, _arg1);
reply.writeNoException();
reply.writeLong(_result);
return true;
}
case TRANSACTION_registerCallback:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
com.lge.sns.service.feed.IFeedServiceCallback _arg1;
_arg1 = com.lge.sns.service.feed.IFeedServiceCallback.Stub.asInterface(data.readStrongBinder());
this.registerCallback(_arg0, _arg1);
reply.writeNoException();
return true;
}
case TRANSACTION_unregisterCallback:
{
data.enforceInterface(DESCRIPTOR);
java.lang.String _arg0;
_arg0 = data.readString();
com.lge.sns.service.feed.IFeedServiceCallback _arg1;
_arg1 = com.lge.sns.service.feed.IFeedServiceCallback.Stub.asInterface(data.readStrongBinder());
this.unregisterCallback(_arg0, _arg1);
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.lge.sns.service.feed.IFeedService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
public int postFeed(java.lang.String snsId, java.lang.String userId, java.lang.String recipientId, java.lang.String feedType, java.lang.String comment) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(recipientId);
_data.writeString(feedType);
_data.writeString(comment);
mRemote.transact(Stub.TRANSACTION_postFeed, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public int postFeedMS(java.lang.String snsId, java.lang.String userId, java.lang.String recipientId, java.lang.String feedType, java.lang.String comment, java.lang.String sMoodFieldText, java.lang.String sMoodEmoticon) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
int _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(recipientId);
_data.writeString(feedType);
_data.writeString(comment);
_data.writeString(sMoodFieldText);
_data.writeString(sMoodEmoticon);
mRemote.transact(Stub.TRANSACTION_postFeedMS, _data, _reply, 0);
_reply.readException();
_result = _reply.readInt();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public java.util.List<com.lge.sns.agent.feed.Feed> getFeedList(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId, java.lang.String feedType, java.lang.String eCategory, int pageNum) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.lge.sns.agent.feed.Feed> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(ownerId);
_data.writeString(feedType);
_data.writeString(eCategory);
_data.writeInt(pageNum);
mRemote.transact(Stub.TRANSACTION_getFeedList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.lge.sns.agent.feed.Feed.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public java.util.List<com.lge.sns.agent.feed.Feed> getWallToWallFeedList(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId, java.lang.String friendId, int pageNum) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
java.util.List<com.lge.sns.agent.feed.Feed> _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
_data.writeString(ownerId);
_data.writeString(friendId);
_data.writeInt(pageNum);
mRemote.transact(Stub.TRANSACTION_getWallToWallFeedList, _data, _reply, 0);
_reply.readException();
_result = _reply.createTypedArrayList(com.lge.sns.agent.feed.Feed.CREATOR);
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public long getFeedAIDLWidgetListUpdatedTime(java.lang.String snsId, java.lang.String userId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
long _result;
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeString(userId);
mRemote.transact(Stub.TRANSACTION_getFeedAIDLWidgetListUpdatedTime, _data, _reply, 0);
_reply.readException();
_result = _reply.readLong();
}
finally {
_reply.recycle();
_data.recycle();
}
return _result;
}
public void registerCallback(java.lang.String snsId, com.lge.sns.service.feed.IFeedServiceCallback cb) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeStrongBinder((((cb!=null))?(cb.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_registerCallback, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
public void unregisterCallback(java.lang.String snsId, com.lge.sns.service.feed.IFeedServiceCallback cb) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeString(snsId);
_data.writeStrongBinder((((cb!=null))?(cb.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_unregisterCallback, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_postFeed = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_postFeedMS = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_getFeedList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_getWallToWallFeedList = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_getFeedAIDLWidgetListUpdatedTime = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_registerCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
static final int TRANSACTION_unregisterCallback = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
}
public int postFeed(java.lang.String snsId, java.lang.String userId, java.lang.String recipientId, java.lang.String feedType, java.lang.String comment) throws android.os.RemoteException;
public int postFeedMS(java.lang.String snsId, java.lang.String userId, java.lang.String recipientId, java.lang.String feedType, java.lang.String comment, java.lang.String sMoodFieldText, java.lang.String sMoodEmoticon) throws android.os.RemoteException;
public java.util.List<com.lge.sns.agent.feed.Feed> getFeedList(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId, java.lang.String feedType, java.lang.String eCategory, int pageNum) throws android.os.RemoteException;
public java.util.List<com.lge.sns.agent.feed.Feed> getWallToWallFeedList(java.lang.String snsId, java.lang.String userId, java.lang.String ownerId, java.lang.String friendId, int pageNum) throws android.os.RemoteException;
public long getFeedAIDLWidgetListUpdatedTime(java.lang.String snsId, java.lang.String userId) throws android.os.RemoteException;
public void registerCallback(java.lang.String snsId, com.lge.sns.service.feed.IFeedServiceCallback cb) throws android.os.RemoteException;
public void unregisterCallback(java.lang.String snsId, com.lge.sns.service.feed.IFeedServiceCallback cb) throws android.os.RemoteException;
}
