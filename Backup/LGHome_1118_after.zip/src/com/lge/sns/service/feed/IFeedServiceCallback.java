/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: C:\\DROIDDEV\\workspace\\HEAVEN_SNS\\src\\com\\lge\\sns\\service\\feed\\IFeedServiceCallback.aidl
 */
package com.lge.sns.service.feed;
public interface IFeedServiceCallback extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.lge.sns.service.feed.IFeedServiceCallback
{
private static final java.lang.String DESCRIPTOR = "com.lge.sns.service.feed.IFeedServiceCallback";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.lge.sns.service.feed.IFeedServiceCallback interface,
 * generating a proxy if needed.
 */
public static com.lge.sns.service.feed.IFeedServiceCallback asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.lge.sns.service.feed.IFeedServiceCallback))) {
return ((com.lge.sns.service.feed.IFeedServiceCallback)iin);
}
return new com.lge.sns.service.feed.IFeedServiceCallback.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_onFeedAdded:
{
data.enforceInterface(DESCRIPTOR);
com.lge.sns.agent.feed.Feed _arg0;
if ((0!=data.readInt())) {
_arg0 = com.lge.sns.agent.feed.Feed.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.onFeedAdded(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onFeedUpdated:
{
data.enforceInterface(DESCRIPTOR);
com.lge.sns.agent.feed.Feed _arg0;
if ((0!=data.readInt())) {
_arg0 = com.lge.sns.agent.feed.Feed.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.onFeedUpdated(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onFeedRemoved:
{
data.enforceInterface(DESCRIPTOR);
com.lge.sns.agent.feed.Feed _arg0;
if ((0!=data.readInt())) {
_arg0 = com.lge.sns.agent.feed.Feed.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
this.onFeedRemoved(_arg0);
reply.writeNoException();
return true;
}
case TRANSACTION_onFeedRefreshStarted:
{
data.enforceInterface(DESCRIPTOR);
this.onFeedRefreshStarted();
reply.writeNoException();
return true;
}
case TRANSACTION_onFeedRefreshFinished:
{
data.enforceInterface(DESCRIPTOR);
this.onFeedRefreshFinished();
reply.writeNoException();
return true;
}
case TRANSACTION_onFeedRefreshFail:
{
data.enforceInterface(DESCRIPTOR);
this.onFeedRefreshFail();
reply.writeNoException();
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.lge.sns.service.feed.IFeedServiceCallback
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
public void onFeedAdded(com.lge.sns.agent.feed.Feed feed) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((feed!=null)) {
_data.writeInt(1);
feed.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onFeedAdded, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
public void onFeedUpdated(com.lge.sns.agent.feed.Feed feed) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((feed!=null)) {
_data.writeInt(1);
feed.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onFeedUpdated, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
public void onFeedRemoved(com.lge.sns.agent.feed.Feed feed) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((feed!=null)) {
_data.writeInt(1);
feed.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
mRemote.transact(Stub.TRANSACTION_onFeedRemoved, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
// Callback�� ���� ��� ���..

public void onFeedRefreshStarted() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onFeedRefreshStarted, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
public void onFeedRefreshFinished() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onFeedRefreshFinished, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
public void onFeedRefreshFail() throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
android.os.Parcel _reply = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
mRemote.transact(Stub.TRANSACTION_onFeedRefreshFail, _data, _reply, 0);
_reply.readException();
}
finally {
_reply.recycle();
_data.recycle();
}
}
}
static final int TRANSACTION_onFeedAdded = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_onFeedUpdated = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_onFeedRemoved = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_onFeedRefreshStarted = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_onFeedRefreshFinished = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
static final int TRANSACTION_onFeedRefreshFail = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
}
public void onFeedAdded(com.lge.sns.agent.feed.Feed feed) throws android.os.RemoteException;
public void onFeedUpdated(com.lge.sns.agent.feed.Feed feed) throws android.os.RemoteException;
public void onFeedRemoved(com.lge.sns.agent.feed.Feed feed) throws android.os.RemoteException;
// Callback�� ���� ��� ���..

public void onFeedRefreshStarted() throws android.os.RemoteException;
public void onFeedRefreshFinished() throws android.os.RemoteException;
public void onFeedRefreshFail() throws android.os.RemoteException;
}
