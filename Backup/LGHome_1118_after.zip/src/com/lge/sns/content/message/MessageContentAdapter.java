/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 *   
 *   Date          Author              Description
 *   ----------    ----------------    ---------------------------------------------------
 *   2010.03.18    eunhwa.shin         Initial Release
 *   2010.03.18    eunhwa.shin         Add getThread() Library
 *   2010.03.18    eunhwa.shin         Add getMessage() Library
 *   
 */
package com.lge.sns.content.message;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

import com.lge.sns.agent.message.Message;
import com.lge.sns.agent.message.MessageThread;
import com.lge.sns.agent.profile.Recipient;
import com.lge.sns.content.message.MessageContent.MessageColumns;
import com.lge.sns.content.message.MessageContent.MessageRecipientColumns;
import com.lge.sns.content.message.MessageContent.ThreadColumns;
import com.lge.sns.content.message.MessageContent.ThreadRecipientColumns;

public class MessageContentAdapter {
	private ContentResolver cr;

	public MessageContentAdapter(ContentResolver cr) {
		this.cr = cr;		
	}	
	final static String TAG = "MessageContentAdapter";
	
	public static ContentValues convertThreadToContent( MessageThread messageThread ) {
		ContentValues contentValues = new ContentValues();
		
		contentValues.put(MessageContent.ThreadColumns.SNS_ID, messageThread.getSnsId());
		contentValues.put(MessageContent.ThreadColumns.USER_ID, messageThread.getUserId());
		contentValues.put(MessageContent.ThreadColumns.THREAD_ID, messageThread.getThreadId());
		contentValues.put(MessageContent.ThreadColumns.THREAD_TYPE, messageThread.getThreadType());
		contentValues.put(MessageContent.ThreadColumns.AUTHOR_ID, messageThread.getAuthorId());
		contentValues.put(MessageContent.ThreadColumns.TITLE, messageThread.getTitle());
		contentValues.put(MessageContent.ThreadColumns.CONTENT, messageThread.getContent());
		contentValues.put(MessageContent.ThreadColumns.MESSAGE_CNT, messageThread.getMessageCnt());
		if(messageThread.getPublishedDate() != null){
			contentValues.put(MessageContent.ThreadColumns.PUBLISHED, messageThread.getPublishedDate().getTime());
		} else {
			contentValues.putNull(MessageContent.ThreadColumns.PUBLISHED);
		}		
		contentValues.put(MessageContent.ThreadColumns.IS_READ, messageThread.getUnread());

		return contentValues; 
	}
	
	public static ContentValues convertMessageToContent( Message message ) {
		ContentValues contentValues = new ContentValues();
		
		contentValues.put(MessageContent.MessageColumns._THREAD_ID, message.get_threadId());
		contentValues.put(MessageContent.MessageColumns.MESSAGE_ID, message.getMessageId());
		contentValues.put(MessageContent.MessageColumns.AUTHOR_ID, message.getAuthorId());
		contentValues.put(MessageContent.MessageColumns.CONTENT, message.getBody());
		contentValues.put(MessageContent.MessageColumns.IS_READ, message.getUnread());
		if(message.getPublishedDate() != null) {
			contentValues.put(MessageContent.MessageColumns.PUBLISHED, message.getPublishedDate().getTime());
		} else {
			contentValues.putNull(MessageContent.MessageColumns.PUBLISHED);
		}
		
		return contentValues;
	}
	
	public static ContentValues convertRecipientToContent( Recipient recipient, long _THREAD_ID ) {
		ContentValues contentValues = new ContentValues();
		
		contentValues.put(MessageContent.ThreadRecipientColumns._THREAD_ID, _THREAD_ID);
		contentValues.put(MessageContent.ThreadRecipientColumns.RECIPIENT_ID, recipient.getRecipientId());
		
		return contentValues;
	}	
	
	public static ContentValues convertMessageRecipientToContent( Recipient recipient, long _MESSAGE_ID ) {
		ContentValues contentValues = new ContentValues();
		
		contentValues.put(MessageContent.MessageRecipientColumns._MESSAGE_ID, _MESSAGE_ID);
		contentValues.put(MessageContent.MessageRecipientColumns.RECIPIENT_ID, recipient.getRecipientId());
		
		return contentValues;
	}
	
	public static MessageThread convertCursorToMessageThread(Cursor c) {
		MessageThread messagethread = new MessageThread();
		
		messagethread.set_id(c.getLong(MessageContent.ThreadColumns.INDEX_ID));
		messagethread.setSnsId(c.getString(MessageContent.ThreadColumns.INDEX_SNS_ID));
		messagethread.setUserId(c.getString(MessageContent.ThreadColumns.INDEX_USER_ID));
		messagethread.setThreadId(c.getString(MessageContent.ThreadColumns.INDEX_THREAD_ID));
		messagethread.setThreadType(c.getString(MessageContent.ThreadColumns.INDEX_THREAD_TYPE));
		messagethread.setAuthorId(c.getString(MessageContent.ThreadColumns.INDEX_AUTHOR_ID));	
		messagethread.setTitle(c.getString(MessageContent.ThreadColumns.INDEX_TITLE));
		messagethread.setContent(c.getString(MessageContent.ThreadColumns.INDEX_CONTENT));
		messagethread.setPublishedDate(c.getLong(MessageContent.ThreadColumns.INDEX_PUBLISHED) > 0 ? new Date(c.getLong(MessageContent.ThreadColumns.INDEX_PUBLISHED)) : null);
		//messagethread.setUnread(c.getInt(MessageContent.ThreadColumns.INDEX_IS_READ) == MessageThread.READ ? true : false);		
		messagethread.setUnread(c.getInt(MessageContent.ThreadColumns.INDEX_IS_READ));
		messagethread.setMessageCnt(c.getInt(MessageContent.ThreadColumns.INDEX_MESSAGE_CNT));
		messagethread.setDisplayName(c.getString(MessageContent.ThreadColumns.INDEX_DISPLAY_NAME));
		messagethread.setAvatarFile(c.getString(MessageContent.ThreadColumns.INDEX_AVATAR_FILE));
		messagethread.setAvatarUrl(c.getString(MessageContent.ThreadColumns.INDEX_AVATAR_URL));
		messagethread.setAuthorName(c.getString(MessageContent.ThreadColumns.INDEX_DISPLAY_NAME));
		messagethread.setOwnerId(c.getString(MessageContent.ThreadColumns.INDEX_AUTHOR_ID));;

		return messagethread;
	}
	
	public static Message convertCursorToMessage(Cursor c) {
		Message message = new Message();
		
		message.set_id(c.getLong(MessageContent.MessageColumns.INDEX_ID));
		message.set_threadId(c.getLong(MessageContent.MessageColumns.INDEX__THREAD_ID));
		message.setMessageId(c.getString(MessageContent.MessageColumns.INDEX_MESSAGE_ID));
		message.setAuthorId(c.getString(MessageContent.MessageColumns.INDEX_AUTHOR_ID));
		message.setBody(c.getString(MessageContent.MessageColumns.INDEX_CONTENT));
		message.setUnread(c.getInt(MessageContent.MessageColumns.INDEX_IS_READ) );
		message.setPublishedDate(c.getLong(MessageContent.MessageColumns.INDEX_PUBLISHED) > 0 ? new Date(c.getLong(MessageContent.MessageColumns.INDEX_PUBLISHED)) : null);
		message.setTitle(c.getString(MessageContent.MessageColumns.INDEX_TITLE));
		message.setDisplayName(c.getString(MessageContent.MessageColumns.INDEX_DISPLAY_NAME));
		message.setAvatarUrl(c.getString(MessageContent.MessageColumns.INDEX_AVATAR_URL));
		message.setUserName(c.getString(MessageContent.MessageColumns.INDEX_OWNER_NAME));
		message.setAuthorName(c.getString(MessageContent.MessageColumns.INDEX_DISPLAY_NAME));
		message.setThreadId(c.getString(MessageContent.MessageColumns.INDEX_THREAD_ID));
		message.setOwnerId(c.getString(MessageContent.MessageColumns.INDEX_AUTHOR_ID));
		message.setAvatarFile(c.getString(MessageContent.MessageColumns.INDEX_AVATAR_FILE));
		message.setSnsId(c.getString(MessageContent.MessageColumns.INDEX_SNS_ID));
		message.setUserId(c.getString(MessageContent.MessageColumns.INDEX_USER_ID));
		
		return message;
	}	
	
	public static Message convertCursorToMessageOrg(Cursor c) {
		Message message = new Message();
		
		message.set_id(c.getLong(MessageContent.MessageColumns.INDEX_ID));
		message.set_threadId(c.getLong(MessageContent.MessageColumns.INDEX__THREAD_ID));
		message.setMessageId(c.getString(MessageContent.MessageColumns.INDEX_MESSAGE_ID));
		message.setAuthorId(c.getString(MessageContent.MessageColumns.INDEX_AUTHOR_ID));
		message.setBody(c.getString(MessageContent.MessageColumns.INDEX_CONTENT));
		message.setUnread(c.getInt(MessageContent.MessageColumns.INDEX_IS_READ) );
		message.setPublishedDate(c.getLong(MessageContent.MessageColumns.INDEX_PUBLISHED) > 0 ? new Date(c.getLong(MessageContent.MessageColumns.INDEX_PUBLISHED)) : null);
		
		message.setTitle(c.getString(MessageContent.MessageColumns.INDEX_TITLE) );
		message.setDisplayName(c.getString(MessageContent.MessageColumns.INDEX_DISPLAY_NAME) );
		message.setAvatarUrl(c.getString(MessageContent.MessageColumns.INDEX_AVATAR_URL) );
		message.setSnsId(c.getString(MessageContent.MessageColumns.INDEX_SNS_ID) );
		message.setUserId(c.getString(MessageContent.MessageColumns.INDEX_USER_ID) );
		message.setThreadId(c.getString(MessageContent.MessageColumns.INDEX_THREAD_ID) );

		return message;
	}		
	
	public static Recipient convertCursorToRecipient(Cursor c) {
		Recipient recipient = new Recipient();
		
		recipient.set_id(c.getLong(MessageContent.ThreadRecipientColumns.INDEX_ID));
		recipient.set_threadId(c.getLong(MessageContent.ThreadRecipientColumns.INDEX__THREAD_ID));
		recipient.setRecipientId(c.getString(MessageContent.ThreadRecipientColumns.INDEX_RECIPIENT_ID));
		recipient.setRecipientName(c.getString(MessageContent.ThreadRecipientColumns.INDEX_RECIPIENT_NAME));

		return recipient;
	}
	
	
	/**
	 * Get a specific thread information (since 2010.03.22)
	 * 
	 * <p> | </p>
	 * <p> +- Thread </p>
	 * <p> |   +- Message </p>
	 * <p> |   +- Message </p>
	 * <p> |   +- Message </p>
	 * <p> +- Thread </p>
	 * <p>     +- Message </p>
	 * <p>     +- Message </p>
	 * <p>     +- Message </p>
	 * 
	 * @param uri Result of 'List<Uri> getThreadUriList( String snsId, String userId, String mode, int pageNum )' AIDL
	 * @return MessageThread object
	 */
	public MessageThread getThread(Uri uri) {
		if (uri == null) {
			return null;
		}
		
		MessageThread messageThread = null;
		
		Cursor cursor = cr.query(uri, null, null, null, null);
		
		if(cursor != null) {
			try {
				if (cursor.moveToNext()) {
					messageThread = MessageContentAdapter.convertCursorToMessageThread(cursor);
				}
			} finally {
				cursor.close();
			}	
		}
		
		return messageThread;
	}
	
	/**
	 * Get a specific message information (since 2010.03.22)
	 * 
	 * <p> | </p>
	 * <p> +- Thread </p>
	 * <p> |   +- Message </p>
	 * <p> |   +- Message </p>
	 * <p> |   +- Message </p>
	 * <p> +- Thread </p>
	 * <p>     +- Message </p>
	 * <p>     +- Message </p>
	 * <p>     +- Message </p>
	 * 
	 * @param uri Result of 'List<Uri> getMessageUriList( String snsId, String userId, String threadId, String mode)' AIDL
	 * @return Message object
	 */
	public Message getMessage(Uri uri) {
		if (uri == null) {
			return null;
		}
		
		Message message = null;
		Cursor cursor = cr.query(uri, null, null, null, null);
		    
		if(cursor != null) {
			try {
				if (cursor.moveToNext()) {
					message = MessageContentAdapter.convertCursorToMessageOrg(cursor);
				}
			} finally {
				cursor.close();
			}	
		}
		
		return message;
	}
}
