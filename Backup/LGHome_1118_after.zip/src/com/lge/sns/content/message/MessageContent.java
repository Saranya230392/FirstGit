/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.content.message;

import android.provider.BaseColumns;

/**
 * Constants for Message Content Provider
 * @author hjunseo
 *
 */
public final class MessageContent {

	private MessageContent() {		
	}
	
	public static final String THREAD_TABLE_NAME = "thread";
	public static final String MESSAGE_TABLE_NAME = "message";	
	public static final String THREAD_RECIPIENT_TABLE_NAME = "thread_recipient";	
	public static final String MESSAGE_RECIPIENT_TABLE_NAME = "message_recipient";

	public static final class ThreadColumns implements BaseColumns {
		private ThreadColumns() {
		}
		public static final String CONTENT_PATH = "thread";
		public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";
		public static final String CONTENT_THREAD_ALL_PATH = CONTENT_PATH+"/thread_allList";
		public static final String CONTENT_THREAD_PAGE_PATH = CONTENT_PATH+"/thread_pageList";
		public static final String CONTENT_THREAD_INOUTBOX_PATH = CONTENT_PATH+"/thread_InOutList";
		public static final String CONTENT_THREAD_MAX_PUBLISHED_PATH = CONTENT_PATH+"/max_published";

		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.thread";
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.thread";

		/**
		 * The default sort order for this table
		 */
		public static final String DEFAULT_SORT_ORDER = "published DESC";

		public static final int INDEX_ID = 0;   

		// SNS ID. "fb" = FaceBook, "ms" = MySpace, "tw" = twitter
		public static final String SNS_ID = "sns_id";
		public static final int INDEX_SNS_ID = 1;

		public static final String USER_ID = "user_id";
		public static final int INDEX_USER_ID = 2;

		public static final String THREAD_ID = "thread_id";
		public static final int INDEX_THREAD_ID = 3;

		public static final String THREAD_TYPE = "thread_type";
		public static final int INDEX_THREAD_TYPE = 4;

		public static final String AUTHOR_ID = "author_id";
		public static final int INDEX_AUTHOR_ID = 5;

		public static final String TITLE = "title";
		public static final int INDEX_TITLE = 6;

		public static final String CONTENT = "content";
		public static final int INDEX_CONTENT = 7;

		public static final String PUBLISHED = "published";
		public static final int INDEX_PUBLISHED = 8;

		public static final String IS_READ = "is_read";
		public static final int INDEX_IS_READ = 9;
		
		public static final String MESSAGE_CNT = "message_cnt";
		public static final int INDEX_MESSAGE_CNT = 10;

		public static final String DISPLAY_NAME = "display_name";
		public static final int INDEX_DISPLAY_NAME = 11;
		
		public static final String AVATAR_FILE = "avatar_file";
		public static final int INDEX_AVATAR_FILE = 12;
		
		public static final String AVATAR_URL = "avatar_url";
		public static final int INDEX_AVATAR_URL = 13;
		
//		public static final String RECIPIENT_ID = "recipient_id";
//		public static final int INDEX_RECIPIENT_ID = 13;
//		
//		public static final String RECIPIENT_NAME = "recipient_name";
//		public static final int INDEX_RECIPIENT_NAME = 14;
		
		
		public static final String[] COLUMNS = { _ID, SNS_ID, USER_ID,
			THREAD_ID, THREAD_TYPE, AUTHOR_ID, TITLE, CONTENT, PUBLISHED, IS_READ, MESSAGE_CNT
		};
		
		public static final String[] THREADALLCOLUMNS = { _ID, SNS_ID, USER_ID,
			THREAD_ID, THREAD_TYPE, AUTHOR_ID, TITLE, CONTENT, PUBLISHED, IS_READ, MESSAGE_CNT, DISPLAY_NAME, AVATAR_FILE, AVATAR_URL 
			//, RECIPIENT_ID, RECIPIENT_NAME
		};
	}



	public static final class MessageColumns implements BaseColumns {
		private MessageColumns() {
		}
		public static final String CONTENT_PATH = "message";
		public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";
		public static final String CONTENT_MESSAGE_INOUTBOX_PATH = CONTENT_PATH+"/message_inbox_outboxList";
		public static final String CONTENT_MESSAGE_All_PATH = CONTENT_PATH+"/message_AllList";

		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.message";
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.message";

		public static final String DEFAULT_SORT_ORDER = "_id DESC";

		public static final int INDEX_ID = 0;   	

		public static final String _THREAD_ID = "_thread_id";
		public static final int INDEX__THREAD_ID = 1;   

		public static final String MESSAGE_ID = "message_id";
		public static final int INDEX_MESSAGE_ID = 2;        

		public static final String AUTHOR_ID = "author_id";
		public static final int INDEX_AUTHOR_ID = 3;

		public static final String CONTENT = "content";
		public static final int INDEX_CONTENT = 4;

		public static final String IS_READ = "is_read";
		public static final int INDEX_IS_READ = 5;

		public static final String PUBLISHED = "published";
		public static final int INDEX_PUBLISHED = 6;
		
		public static final String TITLE = "title";
		public static final int INDEX_TITLE = 7;
		
		public static final String DISPLAY_NAME = "display_name";
		public static final int INDEX_DISPLAY_NAME = 8;
		
		public static final String AVATAR_URL = "avatar_url";
		public static final int INDEX_AVATAR_URL = 9;
		
		public static final String OWNER_NAME = "owner_name";
		public static final int INDEX_OWNER_NAME = 10;
		
		public static final String AVATAR_FILE = "avatar_file";
		public static final int INDEX_AVATAR_FILE = 11;
		
		public static final String SNS_ID = "sns_id";
		public static final int INDEX_SNS_ID = 12;
		
		public static final String USER_ID = "user_id";
		public static final int INDEX_USER_ID = 13;
		
		public static final String THREAD_ID = "thread_id";
		public static final int INDEX_THREAD_ID = 14;
				

		public static final String[] COLUMNS = { _ID, _THREAD_ID, MESSAGE_ID,
			AUTHOR_ID, CONTENT, IS_READ, PUBLISHED
		};
		
		public static final String[] MESSAGE_AND_THREAD_COLUMNS = { _ID, _THREAD_ID, MESSAGE_ID,
			AUTHOR_ID, CONTENT, IS_READ, PUBLISHED, TITLE, DISPLAY_NAME, AVATAR_URL, OWNER_NAME, AVATAR_FILE, SNS_ID, USER_ID
		};
		
	}



	public static final class ThreadRecipientColumns implements BaseColumns {
		private ThreadRecipientColumns() {
		}
		public static final String CONTENT_PATH = "thread_recipient";
		public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";
		public static final String CONTENT_THREAD_RECIPIENT_PATH = CONTENT_PATH+"/thread_recipient_list";

		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.threadrecipient";
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.threadrecipient";

		public static final String DEFAULT_SORT_ORDER = "_id DESC";

		public static final int INDEX_ID = 0;  	

		public static final String _THREAD_ID = "_thread_id";
		public static final int INDEX__THREAD_ID = 1;   

		public static final String RECIPIENT_ID = "recipient_id";
		public static final int INDEX_RECIPIENT_ID = 2;  
		
		public static final String RECIPIENT_NAME = "recipient_name";
		public static final int INDEX_RECIPIENT_NAME = 3;   

		
		
		public static final String[] COLUMNS = { _ID, _THREAD_ID, RECIPIENT_ID };
		
		public static final String[] RECIPIENTCOLUMNS = {  _ID, _THREAD_ID,RECIPIENT_ID, RECIPIENT_NAME };
	}
	
	
	public static final class MessageRecipientColumns implements BaseColumns {
		private MessageRecipientColumns() {
		}
		public static final String CONTENT_PATH = "message_recipient";
		public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";
		public static final String CONTENT_MESSAGE_RECIPIENT_PATH = CONTENT_PATH+"/message_recipient_list";

		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.messagerecipient";
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.messagerecipient";

		public static final String DEFAULT_SORT_ORDER = "_id DESC";

		public static final int INDEX_ID = 0;  	

		public static final String _MESSAGE_ID = "_message_id";
		public static final int INDEX__THREAD_ID = 1;   

		public static final String RECIPIENT_ID = "recipient_id";
		public static final int INDEX_RECIPIENT_ID = 2;  
		
		public static final String RECIPIENT_NAME = "recipient_name";
		public static final int INDEX_RECIPIENT_NAME = 3;   

		
		
		public static final String[] COLUMNS = { _ID, _MESSAGE_ID, RECIPIENT_ID };
		
		public static final String[] RECIPIENTCOLUMNS = {  _ID, _MESSAGE_ID,RECIPIENT_ID, RECIPIENT_NAME };
	}

}
