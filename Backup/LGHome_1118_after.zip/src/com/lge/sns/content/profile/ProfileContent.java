/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.content.profile;

import android.provider.BaseColumns;

/**
 * Constants for Profile Content Provider
 * @author yumin
 *
 */
public final class ProfileContent {

	public static final String PROFILE_TABLE_NAME = "profile";
	public static final String PROFILE_INFO_TABLE_NAME = "profile_info";
	public static final String PROFILE_AVATAR_TABLE_NAME = "profile_avatar";
	public static final String FRIEND_REQUEST_TABLE_NAME = "friend_request";
	
	/**
	 * This class cannot be instantiated
	 */
	private ProfileContent() {		
	}
	
	/**
	 * Main table for Profile
	 * @author yumin
	 *
	 */
	public static final class ProfileColumns implements BaseColumns {
        public static final String CONTENT_PATH = "profile";
        public static final String CONTENT_WITH_AVATAR_PATH = CONTENT_PATH + "/withAvatar"; // searchFriend �� ����...�̸��� ����..
        public static final String CONTENT_SEARCH_FRIEND_PATH = CONTENT_PATH + "/searchFriend"; // searchFriend
        public static final String CONTENT_SEARCH_FRIEND_STATUS4_PATH = CONTENT_PATH + "/searchFriendStatus4"; // search friend_status
        public static final String CONTENT_SEARCH_ALL_PATH = CONTENT_PATH + "/searchAll";                
        public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";
        public static final String CONTENT_SEARCH_ITEM_PATH = CONTENT_PATH+"/searchAll/#";
		public static final String CONTENT_COUNT_PATH = CONTENT_PATH+"/count";
		public static final String CONTENT_COLUMNS_PATH = CONTENT_PATH+"/columns";

		/**
		 * The MIME type of {@link #CONTENT_URI} providing a directory of profiles.
		 */
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.profile";

		/**
		 * The MIME type of a {@link #CONTENT_URI} sub-directory of a single profile.
		 */
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.profile";

		/**
		 * The default sort order for this table
		 */
		public static final String DEFAULT_SORT_ORDER = "display_name COLLATE NOCASE ";
		
		public static final int INDEX_ID = 0;
		
		public static final String SNS_ID = "sns_id";
		public static final int INDEX_SNS_ID = 1;
		
		public static final String USER_ID = "user_id";
		public static final int INDEX_USER_ID = 2;
		
		public static final String OWNER_ID = "owner_id";
		public static final int INDEX_OWNER_ID = 3;		
		
		public static final String OWNER_NAME = "owner_name";
		public static final int INDEX_OWNER_NAME = 4;
		
		public static final String DISPLAY_NAME = "display_name";
		public static final int INDEX_DISPLAY_NAME = 5;
		
		public static final String EMAIL = "email";
		public static final int INDEX_EMAIL = 6;
		
		public static final String PHONE_NUMBER = "phone_number";
		public static final int INDEX_PHONE_NUMBER = 7;
		
		public static final String OTHER_PHONE_NUMBER = "other_phone_number";
		public static final int INDEX_OTHER_PHONE_NUMBER = 8;
		
		public static final String GENDER = "gender";
		public static final int INDEX_GENDER = 9;
		
		public static final String STATUS = "status";
		public static final int INDEX_STATUS = 10;
		
		public static final String BIRTHDAY = "birthday";
		public static final int INDEX_BIRTHDAY = 11;
		
		public static final String PUBLISHED = "published";
		public static final int INDEX_PUBLISHED = 12;		
		
		public static final String WORK = "work";
		public static final int INDEX_WORK = 13;
		
		public static final String LOCATION = "location";
		public static final int INDEX_LOCATION = 14;
		
		public static final String FRIEND_STATUS = "friend_status";
		public static final int INDEX_FRIEND_STATUS = 15;
		
		public static final String FOLLOWER_CNT = "follower_cnt";
		public static final int INDEX_FOLLOWER_CNT = 16;
		
		public static final String FOLLOWING_CNT = "following_cnt";
		public static final int INDEX_FOLLOWING_CNT = 17;
		
		public static final String IS_PROTECTED = "is_protected";
		public static final int INDEX_IS_PROTECTED = 18;
		
		public static final String IS_FAVORITE = "is_favorite";
		public static final int INDEX_IS_FAVORITE = 19;		
		
		public static final String SYNC_TO_CONTACTS = "sync_to_contacts";
		public static final int INDEX_SYNC_TO_CONTACTS = 20;		
		
		public static final String EXTENSION = "extension";
		public static final int INDEX_EXTENSION = 21;
		
		// �߰����� �ʵ�..avatar�� join �� �����.
		public static final String AVATAR_FILE = "avatar_file";
		public static final int INDEX_AVATAR_FILE = 22;		

		public static final String AVATAR_URL = "avatar_url";
		public static final int INDEX_AVATAR_URL = 23;
		
		public static String[] COLUMNS = { 
				_ID                
			  , SNS_ID             
			  , USER_ID      
			  , OWNER_ID 
			  , OWNER_NAME          
			  , DISPLAY_NAME       
			  , EMAIL              
			  , PHONE_NUMBER       
			  , OTHER_PHONE_NUMBER 
			  , GENDER             
			  , STATUS             
			  , BIRTHDAY           
			  , PUBLISHED          
			  , WORK       
			  , LOCATION 
			  , FRIEND_STATUS      
			  , FOLLOWER_CNT       
			  , FOLLOWING_CNT 
			  , IS_PROTECTED       
			  , IS_FAVORITE
			  , SYNC_TO_CONTACTS
			  , EXTENSION
		};
		
		public static String[] AVATAR_COLUMNS = { 
				_ID                
			  , SNS_ID             
			  , USER_ID      
			  , OWNER_ID 
			  , OWNER_NAME          
			  , DISPLAY_NAME       
			  , EMAIL              
			  , PHONE_NUMBER       
			  , OTHER_PHONE_NUMBER 
			  , GENDER             
			  , STATUS             
			  , BIRTHDAY           
			  , PUBLISHED          
			  , WORK               
			  , FRIEND_STATUS      
			  , FOLLOWER_CNT       
			  , FOLLOWING_CNT      
			  , IS_PROTECTED       
			  , AVATAR_FILE
			  , AVATAR_URL
		};		

		// This class cannot be instantiated
		private ProfileColumns() {
		}
	}	
	
	/**
	 * Main table for ProfileaAvatar
	 * @author yumin
	 *
	 */
	public static final class ProfileInfoColumns implements BaseColumns {
        public static final String CONTENT_PATH = "profileinfo";
        public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";

		/**
		 * The MIME type of {@link #CONTENT_URI} providing a directory of profiles.
		 */
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.profile";

		/**
		 * The MIME type of a {@link #CONTENT_URI} sub-directory of a single profile.
		 */
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.profile";

		/**
		 * The default sort order for this table
		 */
		public static final String DEFAULT_SORT_ORDER = "_id";
		
		public static final int INDEX_ID = 0;
		
		public static final String _PROFILE_ID = "_profile_id";
		public static final int INDEX__PROFILE_ID = 1;
		
		public static final String NAME = "name";
		public static final int INDEX_NAME = 2;
		
		public static final String VALUE = "value";
		public static final int INDEX_VALUE = 3;
		
		public static String[] COLUMNS = {
			    _ID          
			  , _PROFILE_ID  
			  , NAME         
			  , VALUE        
 
		};

		// This class cannot be instantiated
		private ProfileInfoColumns() {
		}
	}		
	
	/**
	 * Main table for ProfileaAvatar
	 * @author yumin
	 *
	 */
	public static final class ProfileAvatarColumns implements BaseColumns {
        public static final String CONTENT_PATH = "profileavatar";
        public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";

		/**
		 * The MIME type of {@link #CONTENT_URI} providing a directory of profiles.
		 */
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.profile";

		/**
		 * The MIME type of a {@link #CONTENT_URI} sub-directory of a single profile.
		 */
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.profile";

		/**
		 * The default sort order for this table
		 */
		public static final String DEFAULT_SORT_ORDER = "display_name COLLATE NOCASE ";
		
		public static final int INDEX_ID = 0;
		
		public static final String _PROFILE_ID = "_profile_id";
		public static final int INDEX__PROFILE_ID = 1;
		
		public static final String SNS_ID = "sns_id";
		public static final int INDEX_SNS_ID = 2;
		
		public static final String USER_ID = "user_id";
		public static final int INDEX_USER_ID = 3;
		
		public static final String OWNER_ID = "owner_id";
		public static final int INDEX_OWNER_ID = 4;		
		
		public static final String DISPLAY_NAME = "display_name";
		public static final int INDEX_DISPLAY_NAME = 5;
		
		public static final String AVATAR_URL = "avatar_url";
		public static final int INDEX_AVATAR_URL = 6;
		
		public static final String AVATAR_FILE = "avatar_file";
		public static final int INDEX_AVATAR_FILE = 7;
		
		public static String[] COLUMNS = {
			  _ID        
			, _PROFILE_ID
			, SNS_ID     
			, USER_ID  
			, OWNER_ID  
			, DISPLAY_NAME  
			, AVATAR_URL 
			, AVATAR_FILE     
		};

		// This class cannot be instantiated
		private ProfileAvatarColumns() {
		}
	}		
	
	/**
	 * Main table for Friend Request
	 * @author dohwaji
	 *
	 */
	public static final class FriendRequestColumns implements BaseColumns {
        public static final String CONTENT_PATH = "friendrequest";
        public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";

		/**
		 * The MIME type of {@link #CONTENT_URI} providing a directory of profiles.
		 */
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.profile";

		/**
		 * The MIME type of a {@link #CONTENT_URI} sub-directory of a single profile.
		 */
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.profile";

		/**
		 * The default sort order for this table
		 */
		public static final String DEFAULT_SORT_ORDER = "display_name";
		
		public static final int INDEX_ID = 0;
		
		public static final String SNS_ID = "sns_id";
		public static final int INDEX_SNS_ID = 1;
		
		public static final String USER_ID = "user_id";
		public static final int INDEX_USER_ID = 2;
		
		public static final String REQUESTER_ID = "requester_id";
		public static final int INDEX_REQUESTER_ID = 3;		
		
		public static final String STATUS = "status";
		public static final int INDEX_STATUS = 4;
		
		public static final String REQUEST_ID = "request_id";
		public static final int INDEX_REQUEST_ID = 5;
		
		public static final String REQUEST_MESSAGE = "request_message";
		public static final int INDEX_REQUEST_MESSAGE = 6;
		
        public static final String PUBLISHED = "published";
        public static final int INDEX_PUBLISHED = 7;

        public static final String IS_NOTIFIED = "is_notified";
        public static final int INDEX_IS_NOTIFIED = 8;
        
		// �߰����� �ʵ�..avatar�� join �� �����.
		public static final String AVATAR_FILE = "avatar_file";
		public static final int INDEX_AVATAR_FILE = 9;		

		public static final String DISPLAY_NAME = "display_name";
		public static final int INDEX_DISPLAY_NAME = 10;		

		public static String[] COLUMNS = {
			  _ID        
			, SNS_ID     
			, USER_ID  
			, REQUESTER_ID  
			, STATUS  
			, REQUEST_ID 
			, REQUEST_MESSAGE
			, PUBLISHED
			, IS_NOTIFIED
		};

		// This class cannot be instantiated
		private FriendRequestColumns() {
		}
	}			
}
