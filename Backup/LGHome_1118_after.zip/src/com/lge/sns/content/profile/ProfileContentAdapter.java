/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.content.profile;

import java.io.FileNotFoundException;
import java.util.Date;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.lge.sns.agent.profile.FriendEntry;
import com.lge.sns.agent.profile.Profile;
import com.lge.sns.content.profile.ProfileContent.ProfileAvatarColumns;
import com.lge.sns.content.profile.ProfileContent.ProfileColumns;

/**
 * ProfileContentAdapter for Profile and Friend
 * @author yumin
 *
 */
public class ProfileContentAdapter {
	
	private final ContentResolver cr;
	
	public ProfileContentAdapter(ContentResolver cr) {
		this.cr = cr;
	}	
	
	/**
	 * Convert Profile DTO to {@link ContentValues}.
	 * @param profile
	 * @return
	 */
	public static ContentValues parseProfile( Profile profile ){
		ContentValues contentValues = new ContentValues();
		
		contentValues.put(ProfileContent.ProfileColumns.SNS_ID, profile.getSnsId());
		contentValues.put(ProfileContent.ProfileColumns.USER_ID, profile.getUserId());
		contentValues.put(ProfileContent.ProfileColumns.OWNER_ID, profile.getOwnerId());
		contentValues.put(ProfileContent.ProfileColumns.OWNER_NAME, profile.getUserName());
		contentValues.put(ProfileContent.ProfileColumns.DISPLAY_NAME, profile.getDisplayName());
		contentValues.put(ProfileContent.ProfileColumns.EMAIL, profile.getEmail());
		contentValues.put(ProfileContent.ProfileColumns.PHONE_NUMBER, profile.getPhoneNumber());
		contentValues.put(ProfileContent.ProfileColumns.OTHER_PHONE_NUMBER, profile.getOtherPhoneNumber());
		contentValues.put(ProfileContent.ProfileColumns.GENDER, profile.getGender());
		contentValues.put(ProfileContent.ProfileColumns.STATUS, profile.getStatus());
		contentValues.put(ProfileContent.ProfileColumns.BIRTHDAY, profile.getBirthday());
		
		if(profile.getProfileUpdated()!= null) {
			contentValues.put(ProfileContent.ProfileColumns.PUBLISHED, profile.getProfileUpdated().getTime());
		} else {
			contentValues.putNull(ProfileContent.ProfileColumns.PUBLISHED);
		}
		
		contentValues.put(ProfileContent.ProfileColumns.WORK, profile.getWork());
		contentValues.put(ProfileContent.ProfileColumns.FRIEND_STATUS, profile.getFriendStatus());
		
		if (profile.getFollowerCount() >= 0)
			contentValues.put(ProfileContent.ProfileColumns.FOLLOWER_CNT, profile.getFollowerCount());
		if (profile.getFollowingCount() >= 0)
			contentValues.put(ProfileContent.ProfileColumns.FOLLOWING_CNT, profile.getFollowingCount());
		contentValues.put(ProfileContent.ProfileColumns.IS_PROTECTED, profile.getIsProtected());
		
		if (profile.isFavorite() == false) {
			contentValues.put(ProfileContent.ProfileColumns.IS_FAVORITE, 0);
		}
		
		return contentValues;
	}
	
	public static ContentValues parseProfileAvatar( Profile profile ){
		ContentValues contentValues = new ContentValues();
		
		contentValues.put(ProfileContent.ProfileAvatarColumns._PROFILE_ID, profile.getProfileId());
		contentValues.put(ProfileContent.ProfileAvatarColumns.SNS_ID, profile.getSnsId());
		contentValues.put(ProfileContent.ProfileAvatarColumns.USER_ID, profile.getUserId());
		contentValues.put(ProfileContent.ProfileAvatarColumns.OWNER_ID, profile.getOwnerId());
		contentValues.put(ProfileContent.ProfileAvatarColumns.DISPLAY_NAME, profile.getDisplayName());
		contentValues.put(ProfileContent.ProfileAvatarColumns.AVATAR_URL, profile.getAvatarUrl());
		contentValues.put(ProfileContent.ProfileAvatarColumns.AVATAR_FILE, profile.getAvatarFile());

		return contentValues;
	}
	
	public static ContentValues parseProfileInfo( long _profile_id , String name, String value ){
		ContentValues contentValues = new ContentValues();
		
		contentValues.put(ProfileContent.ProfileInfoColumns._PROFILE_ID, _profile_id);
		contentValues.put(ProfileContent.ProfileInfoColumns.NAME, name);
		contentValues.put(ProfileContent.ProfileInfoColumns.VALUE, value);

		return contentValues;
	}

	public static Profile convertCursorToProfile(Cursor c) {
		Profile profile = new Profile();
		profile.set_id             (c.getLong  (ProfileColumns.INDEX_ID                 ));
		profile.setSnsId           (c.getString(ProfileColumns.INDEX_SNS_ID             ));
		profile.setUserId          (c.getString(ProfileColumns.INDEX_USER_ID            ));
		profile.setOwnerId         (c.getString(ProfileColumns.INDEX_OWNER_ID           ));
		profile.setUserName        (c.getString(ProfileColumns.INDEX_OWNER_NAME         ));
		profile.setDisplayName     (c.getString(ProfileColumns.INDEX_DISPLAY_NAME       ));
		profile.setEmail           (c.getString(ProfileColumns.INDEX_EMAIL              ));
		profile.setPhoneNumber     (c.getString(ProfileColumns.INDEX_PHONE_NUMBER       ));
		profile.setOtherPhoneNumber(c.getString(ProfileColumns.INDEX_OTHER_PHONE_NUMBER ));
		profile.setGender          (c.getString(ProfileColumns.INDEX_GENDER             ));
		profile.setStatus          (c.getString(ProfileColumns.INDEX_STATUS             ));
		profile.setBirthday        (c.getString(ProfileColumns.INDEX_BIRTHDAY           ));
		profile.setProfileUpdated  (c.getLong  (ProfileColumns.INDEX_PUBLISHED) > 0 
				? new Date(c.getLong(ProfileColumns.INDEX_PUBLISHED)) : null);
		profile.setWork            (c.getString(ProfileColumns.INDEX_WORK               ));
		profile.setFriendStatus    (c.getString(ProfileColumns.INDEX_FRIEND_STATUS      ));
		profile.setFollowerCount   (c.getInt(ProfileColumns.INDEX_FOLLOWER_CNT          ));
		profile.setFollowingCount  (c.getInt(ProfileColumns.INDEX_FOLLOWING_CNT         ));
		profile.setIsProtected     (c.getInt(ProfileColumns.INDEX_IS_PROTECTED          ));
		profile.setSyncToContacts  (c.getInt(ProfileColumns.INDEX_SYNC_TO_CONTACTS      ));
		
		profile.setAvatarFile	   (c.getString(ProfileColumns.INDEX_AVATAR_FILE));
		profile.setAvatarUrl	   (c.getString(ProfileColumns.INDEX_AVATAR_URL));
		
		return profile;
	} 
	
	public static FriendEntry convertCursorToFriendEntry(Cursor c) {
		FriendEntry profile = new FriendEntry();
		profile.setSnsId           (c.getString(ProfileColumns.INDEX_SNS_ID             ));
		profile.setUserId          (c.getString(ProfileColumns.INDEX_USER_ID            ));
		profile.setOwnerId          (c.getString(ProfileColumns.INDEX_OWNER_ID          ));
		profile.setUserName        (c.getString(ProfileColumns.INDEX_OWNER_NAME         ));
		profile.setDisplayName     (c.getString(ProfileColumns.INDEX_DISPLAY_NAME       ));
		profile.setStatus          (c.getString(ProfileColumns.INDEX_STATUS             ));
		profile.setProfileUpdated  (c.getLong  (ProfileColumns.INDEX_PUBLISHED) > 0 
				? new Date(c.getLong(ProfileColumns.INDEX_PUBLISHED)) : null);

		profile.setAvatarFile(c.getString(ProfileColumns.INDEX_AVATAR_FILE));
		
		return profile;
	} 
	
	public static FriendEntry convertCursorToProfileAvatar(Cursor c) {
		FriendEntry profile = new FriendEntry();
		profile.setProfileId       (c.getLong  (ProfileAvatarColumns.INDEX__PROFILE_ID  ));
		profile.set_avatarId       (c.getLong  (ProfileAvatarColumns.INDEX_ID           ));
		profile.setSnsId           (c.getString(ProfileAvatarColumns.INDEX_SNS_ID       ));
		profile.setUserId          (c.getString(ProfileAvatarColumns.INDEX_USER_ID      ));
		profile.setOwnerId         (c.getString(ProfileAvatarColumns.INDEX_OWNER_ID     ));
		profile.setDisplayName     (c.getString(ProfileAvatarColumns.INDEX_DISPLAY_NAME ));
		profile.setAvatarFile      (c.getString(ProfileAvatarColumns.INDEX_AVATAR_FILE  ));
		profile.setAvatarUrl       (c.getString(ProfileAvatarColumns.INDEX_AVATAR_URL   ));
		return profile;
	} 

	/**
	 * Get a specific friend information 
	 * @param uri Result of getFriendUriList(snsId, userId, keyword ) AIDL
	 * @return one Profile object
	 */
    public Profile getFriend(Uri uri) {
		Cursor cursor = cr.query(
				uri,
				null,
				null, 
				null, 
				null
				);
		
		if (cursor != null) {
			try {
				if (cursor.moveToNext()) {
					return ProfileContentAdapter.convertCursorToProfile(cursor);
				}
			} finally {
				cursor.close();
			}
		}
		
		return null;    	
    }
    
    /**
     * Get a specific person information (A person is not my friend, but a member on a SNS)
     * This does not include a profile image. To get it, use getAvatarBitmap().
     * 
     * @param uri Result of getPeopleUriList(snsId, userId, keyword, page, sizePerPage) AIDL
     * @return one FriendEntry object
     */
    public FriendEntry getPeople(Uri uri) {
		Cursor cursor = cr.query(
				uri,
				ProfileAvatarColumns.COLUMNS,
				null, 
				null, 
				null);
		
		if (cursor != null) {
			try {
				if (cursor.moveToNext()) {
					return ProfileContentAdapter.convertCursorToProfileAvatar(cursor);
				}
			} finally {
				cursor.close();
			}	
		}
    	
    	return null;    	
    }    

    /**
     * Get a specific person's profile image (A person is not my friend, but a member on a SNS)
     * This might take some time because an image should be retrieved on a SNS site.
     * 
     * @param uri Result of getPeopleUriList(snsId, userId, keyword, page, sizePerPage) AIDL
     * @return avatar bitmap object
     */
    public Bitmap getAvatarBitmap(Uri uri) {
    	try {
			return BitmapFactory.decodeStream(cr.openInputStream(uri));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
    	return null;
    }
}
