/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.content.media;

import java.io.FileNotFoundException;
import java.util.Date;

import android.content.ContentResolver;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.lge.sns.agent.media.MediaFolder;
import com.lge.sns.content.media.MediaContent.MediaFolderColumns;

/**
 * CPAdapter for Media
 * @author yumin
 *
 */
public class MediaContentAdapter {
	
	private final ContentResolver cr;
	
	public MediaContentAdapter(ContentResolver cr) {
		this.cr = cr;
	}
	
	/**
	 * Get a specific media folder information
	 * @param uri Result of getMediaFolderUriList(snsId, userId) AIDL
	 * @return MediaFolder object
	 */
    public MediaFolder getMediaFolder(Uri uri){
		Cursor cursor = cr.query(
				uri,
				MediaFolderColumns.COLUMNS,
				null, 
				null, 
				null
				);

		if (cursor != null) {
			try {
				if (cursor.moveToNext()) {
					return MediaContentAdapter.convertCursorToMediaFolder(cursor);
				}
			} finally {
				cursor.close();
			}
		}
		
		return null;
    }
    
	public static MediaFolder convertCursorToMediaFolder(Cursor c) {
		MediaFolder mediaFolder = new MediaFolder();
		mediaFolder.set_id             (c.getLong  (MediaFolderColumns.INDEX_ID                 ));
		mediaFolder.setSnsId           (c.getString(MediaFolderColumns.INDEX_SNS_ID             ));
		mediaFolder.setUserId          (c.getString(MediaFolderColumns.INDEX_USER_ID            ));
		mediaFolder.setOwnerId         (c.getString(MediaFolderColumns.INDEX_OWNER_ID           ));
		mediaFolder.setFolderKind      (c.getInt   (MediaFolderColumns.INDEX_FOLDER_KIND        ));
		mediaFolder.setFolderId        (c.getString(MediaFolderColumns.INDEX_FOLDER_ID          ));
		mediaFolder.setFolderName      (c.getString(MediaFolderColumns.INDEX_FOLDER_NAME        ));
		mediaFolder.setCoverFileId     (c.getString(MediaFolderColumns.INDEX_COVER_FILE_ID      ));
		mediaFolder.setCoverFileUrl    (c.getString(MediaFolderColumns.INDEX_COVER_FILE_URL     ));
		mediaFolder.setFileCnt         (c.getInt   (MediaFolderColumns.INDEX_FILE_CNT           ));
		mediaFolder.setPublished       (c.getLong  (MediaFolderColumns.INDEX_PUBLISHED) > 0 
				? new Date(c.getLong(MediaFolderColumns.INDEX_PUBLISHED)) : null);
		
		return mediaFolder;
	} 
	
    public Bitmap getThumbnailBitmap(Uri uri) {
    	try {
			return BitmapFactory.decodeStream(cr.openInputStream(uri));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
    	return null;
    }	

}
