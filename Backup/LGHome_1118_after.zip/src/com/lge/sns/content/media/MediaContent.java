/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.content.media;

import android.provider.BaseColumns;

/**
 * Constants for Media Content Provider
 * @author hjunseo, yumin
 *
 */
public final class MediaContent {
	
	public static final String MEDIA_FOLDER_TABLE_NAME = "media_folder";
	public static final String MEDIA_FILE_TABLE_NAME = "media_file";
	public static final String MEDIA_FILE_TAG_TABLE_NAME = "media_file_tag";	
	public static final String MEDIA_COMMENT_TABLE_NAME = "media_comment";	
	
	/**
	 * This class cannot be instantiated
	 */
	private MediaContent() {		
	}
	
	public final static class MediaFolderColumns implements BaseColumns {
		public static final String CONTENT_PATH = "mediafolder";
		public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";
		public static final String CONTENT_FILE_COUNT_PATH = CONTENT_PATH+"/countfile";
		public static final String CONTENT_FOLDER_COUNT_PATH = CONTENT_PATH+"/countfolder";
		
        /**
         * The MIME type of {@link #CONTENT_URI} providing a directory of photos.
         */
        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.media.folder";

        /**
         * The MIME type of a {@link #CONTENT_URI} sub-directory of a single photo.
         */
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.media.folder";		
		
        public static final String DEFAULT_SORT_ORDER = "published";
		
        public static final int INDEX_ID = 0;
        
		public static final String SNS_ID = "sns_id";
		public static final int INDEX_SNS_ID = 1;
		
		public static final String USER_ID = "user_id";
		public static final int INDEX_USER_ID = 2;
		
		public static final String OWNER_ID = "owner_id";
		public static final int INDEX_OWNER_ID = 3;		
				
        public static final String FOLDER_KIND = "folder_kind";
        public static final int INDEX_FOLDER_KIND = 4;
        
        public static final String FOLDER_ID = "folder_id";
        public static final int INDEX_FOLDER_ID = 5;        
              
        public static final String FOLDER_NAME = "folder_name";
        public static final int INDEX_FOLDER_NAME = 6;
        
        public static final String COVER_FILE_ID = "cover_file_id";
        public static final int INDEX_COVER_FILE_ID = 7;
        
        public static final String COVER_FILE_URL = "cover_file_url";
        public static final int INDEX_COVER_FILE_URL = 8;     
        
        public static final String FILE_CNT = "file_cnt";
        public static final int INDEX_FILE_CNT = 9;           
        
        public static final String PUBLISHED = "published";
        public static final int INDEX_PUBLISHED = 10;        
        
		public static String[] COLUMNS = { _ID, SNS_ID, USER_ID, OWNER_ID, FOLDER_KIND, FOLDER_ID,
			FOLDER_NAME, COVER_FILE_ID, COVER_FILE_URL, FILE_CNT, PUBLISHED};
//		public static String[] COLUMNS = { _ID, SNS_ID, USER_ID, FOLDER_ID,
//			FOLDER_NAME, PUBLISHED}; // old columns
	}
	
	public final static class MediaFileColumns implements BaseColumns {
        public static final String CONTENT_PATH = "mediafile";
        public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";
        public static final String CONTENT_ITEM_PATH_WITH_PROFILE = CONTENT_PATH+"/with_profile";
        public static final String CONTENT_COUNT_PATH = CONTENT_PATH+"/count";
        public static final String CONTENT_TITLE_IMAGE_PATH = CONTENT_PATH+"/title_image";
        public static final String CONTENT_URI_PATH = CONTENT_PATH+"/uri";
        public static final String CONTENT_THUMBNAILS_PATH = CONTENT_PATH+"/thumbnails";

        /**
         * The MIME type of {@link #CONTENT_URI} providing a directory of photos.
         */
        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.media.file";

        /**
         * The MIME type of a {@link #CONTENT_URI} sub-directory of a single photo.
         */
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.media.file";

        /**
         * The default sort order for this table
         */
        public static final String DEFAULT_SORT_ORDER = "published DESC";
		
        public static final int INDEX_ID = 0;
        
		public static final String _FOLDER_ID = "_folder_id";
		public static final int INDEX__FOLDER_ID = 1;
		
		public static final String FILE_ID = "file_id";
		public static final int INDEX_FILE_ID = 2;
		
		public static final String TITLE = "title";
		public static final int INDEX_TITLE = 3;
		
		public static final String MIME_TYPE = "mime_type";
		public static final int INDEX_MIME_TYPE = 4;
		
        public static final String PIC_URL = "pic_url";
        public static final int INDEX_PIC_URL = 5;
        
        public static final String THUMBNAIL_FILE = "thumbnail_file";
        public static final int INDEX_THUMBNAIL_FILE = 6;
        
        public static final String THUMBNAIL_URL = "thumbnail_url";
        public static final int INDEX_THUMBNAIL_URL = 7;
        
        /**
         * The timestamp for when the media File was created
         * <P>Type: INTEGER (long from System.curentTimeMillis())</P>
         */        
        public static final String PUBLISHED = "published";
        public static final int INDEX_PUBLISHED = 8;
        
        public static final String COMMENT_CNT = "comment_cnt";
        public static final int INDEX_COMMENT_CNT = 9;
        
        
		public static String[] COLUMNS = {_ID          
										, _FOLDER_ID   
										, FILE_ID      
										, TITLE        
										, MIME_TYPE    
										, PIC_URL      
										, THUMBNAIL_FILE    
										, THUMBNAIL_URL
										, PUBLISHED    
										, COMMENT_CNT  };
		
		// This class cannot be instantiated
		private MediaFileColumns() {
		}
	}	

	public static final class MediaCommentColumns implements BaseColumns {
        public static final String CONTENT_PATH = "mediacomment";
        public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";

		/**
		 * The MIME type of {@link #CONTENT_URI} providing a directory of photo comments.
		 */
		public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.media.comment";

		/**
		 * The MIME type of a {@link #CONTENT_URI} sub-directory of a single photo comment.
		 */
		public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.media.comment";

		/**
		 * The default sort order for this table
		 */
		public static final String DEFAULT_SORT_ORDER = "published DESC";

		public static final int INDEX_ID = 0;
		
		/**
         * sns id
         * <P>Type: TEXT</P>
         */
		public static final String _FILE_ID = "_file_id";
		public static final int INDEX__FILE_ID = 1;
		
		/**
         * user id
         * <P>Type: TEXT</P>
         */
		public static final String COMMENT_ID = "comment_id";
		public static final int INDEX_COMMENT_ID = 2;
		
		/**
         * user name
         * <P>Type: TEXT</P>
         */
		public static final String OWNER_USER_ID = "owner_user_id";
		public static final int INDEX_OWNER_USER_ID = 3;
		
		/**
         * display name
         * <P>Type: TEXT</P>
         */
		public static final String COMMENT_USER_ID = "comment_user_id";
		public static final int INDEX_COMMENT_USER_ID = 4;
		
		/**
         * media comment id on newbay server
         * <P>Type: INTEGER</P>
         */
		public static final String COMMENT = "comment";
		public static final int INDEX_COMMENT = 5;
		
		/**
         * The timestamp for when the media comment was created
         * <P>Type: INTEGER (long from System.curentTimeMillis())</P>
         */
		public static final String PUBLISHED = "published";
		public static final int INDEX_PUBLISHED = 6;
		
		
		public static String[] COLUMNS = {_ID            
										, _FILE_ID       
										, COMMENT_ID     
										, OWNER_USER_ID  
										, COMMENT_USER_ID
										, COMMENT        
										, PUBLISHED };
		
		// This class cannot be instantiated
		private MediaCommentColumns() {
		}
	}

	public final static class MediaFileTagColumns implements BaseColumns {
        public static final String CONTENT_PATH = "mediafiletag";
        public static final String CONTENT_ITEM_PATH = CONTENT_PATH+"/#";
        public static final String CONTENT_COUNT_PATH = CONTENT_PATH+"/count";

        /**
         * The MIME type of {@link #CONTENT_URI} providing a directory of photos.
         */
        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/vnd.lge.sns.media.tag";

        /**
         * The MIME type of a {@link #CONTENT_URI} sub-directory of a single photo.
         */
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/vnd.lge.sns.media.tag";

        /**
         * The default sort order for this table
         */
        public static final String DEFAULT_SORT_ORDER = "published DESC";
		
        public static final int INDEX_ID = 0;
        
		public static final String _FILE_ID = "_file_id";
		public static final int INDEX__FILE_ID = 1;
		
		public static final String OWNER_USER_ID = "owner_user_id";
		public static final int INDEX_OWNER_USER_ID = 2;
		
		public static final String TAG_ID = "tag_id";
		public static final int INDEX_TAG_ID = 3;
		
		public static final String POSX1 = "posx1";
		public static final int INDEX_POSX1 = 4;
		
        public static final String POSX2 = "posx2";
        public static final int INDEX_POSX2 = 5;
        
        public static final String POSY1 = "posy1";
        public static final int INDEX_POSY1 = 6;
        
        public static final String POSY2 = "posy2";
        public static final int INDEX_POSY2 = 7;
        
        public static final String TAG_USER_ID = "tag_user_id";
        public static final int INDEX_TAG_USER_ID = 8;
        
        public static final String TAG_TEXT = "tag_TEXT";
        public static final int INDEX_TAG_TEXT = 9;        
        
        /**
         * The timestamp for when the media File was created
         * <P>Type: INTEGER (long from System.curentTimeMillis())</P>
         */        
        public static final String PUBLISHED = "published";
        public static final int INDEX_PUBLISHED = 10;
        
        
        
		public static String[] COLUMNS = {_ID          
										, _FILE_ID     
										, OWNER_USER_ID
										, TAG_ID       
										, POSX1        
										, POSX2        
										, POSY1        
										, POSY2        
										, TAG_USER_ID  
										, TAG_TEXT     
										, PUBLISHED    
							  			};
		
		// This class cannot be instantiated
		private MediaFileTagColumns() {
		}
	}	
}
