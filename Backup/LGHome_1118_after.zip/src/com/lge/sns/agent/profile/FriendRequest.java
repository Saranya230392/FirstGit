/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.profile;

import java.util.Date;


public class FriendRequest extends SnsAuthorInfo {	
	//private long   _id;            //NO DB stored
	private Date   published;      //NO DB stored
	//private String requestId;      //NO DB stored
	//private String requestMessage; //NO DB  stored
	private String requsterId;     //NO DB stored  (must check what it means)
	private String status;         //NO DB stored
	private String _avatarId;      //PROFILE_AVATAR._ID
	
//	public long get_id() {
//		return _id;
//	}
//	public void set_id(long _id) {
//		this._id = _id;
//	}
	public Date getPublished() {
		return published;
	}
	public void setPublished(Date published) {
		this.published = published;
	}
//	public String getRequestId() {
//		return requestId;
//	}
//	public void setRequestId(String requestId) {
//		this.requestId = requestId;
//	}
//	public String getRequestMessage() {
//		return requestMessage;
//	}
//	public void setRequestMessage(String requestMessage) {
//		this.requestMessage = requestMessage;
//	}
	public String getRequsterId() {
		return requsterId;
	}
	public void setRequsterId(String requsterId) {
		this.requsterId = requsterId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String get_avatarId() {
		return _avatarId;
	}
	public void set_avatarId(String _avatarId) {
		this._avatarId = _avatarId;
	}
	
	
}
