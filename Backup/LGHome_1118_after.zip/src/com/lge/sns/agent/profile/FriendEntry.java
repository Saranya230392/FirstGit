/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.profile;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.json.JSONObject;

import android.content.ContentUris;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;


public class FriendEntry extends SnsAuthorInfo implements Parcelable {
	private long    _avatarId;         //PROFILE_AVATAR._ID
	private long    profileId;         //PROFILE_AVATAR.PROFILE_ID
	private String  avatarLink;        //PROFILE_AVATAR.AVATAR_URL	
	private String  status;            //PROFILE.STATUS   
	private Date    profileUpdated;    //PROFILE.PUBLISHED
	private boolean isFavorite;        //PROFILE.ISFAVORITE�� ������
	private int     syncToContacts;
	private String  extension;			// PROFILE.EXTENSION(profile_info)
	private String location;
	private String mood;			
	private int moodIcon;
	private String friendType;        // mutualFriend, people ����..
	private int mutualFriendCnt;       // mutualFriend �Ѱ���
	
	
	/*
     *  <p> Facebook : </p>
     *                <p> NotFriend, me : 0 </p>
     *                <p> Friend        : 1 </p>
     *  <p> Twitter   : </p> 
     *                <p> NotFriend, me : 0 </p>
     *                <p> Friend        : 1 </p>
     *  <p> MySpace   : </p>  ��û��..
     *                <p> NotFriend, me : 0 </p>
     *                <p> Friend        : 1 </p>     *  
     *  <p> Orkut     : </p>  ��û��..
     *                <p> NotFriend, me : 0 </p>
     *                <p> Friend        : 1 </p>     *	 * 
     *  0�ϰ�� ���� ģ���ƴ����� �������µ� ������ �ʿ��� ���(UI���� ó���Ұ��) => userId=getOwnerId() ��ġ�ϸ� �ڽ��̰�, ����ġ�ϸ� ģ���ƴ����� ó���Ѵ�.           
	 */	
	private int isFriend;

	/**
	 * PROFILE_INFO ���̺� ��ü
	 */
	private Map<String, String>  profileInfo;
	
	public FriendEntry(Parcel in) {
		readFromParcel(in);
	}
	
	public FriendEntry() {
	}

	@SuppressWarnings("unchecked")
    public Map<String, String>  getProfileInfo() {
		if (profileInfo == null && extension != null) {
			try {
				JSONObject jsonObj = new JSONObject(extension);
				profileInfo = new HashMap<String, String>();
				for (Iterator<String> itr = jsonObj.keys(); itr.hasNext(); ) {
					String key = itr.next();
					String value = jsonObj.getString(key);
					profileInfo.put(key, value);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return profileInfo;
	}
	public void setProfileInfo(Map<String, String>  profileInfo) {
		this.profileInfo = profileInfo;
	}
	
	public String getExtension() {
		if (extension == null && profileInfo != null) {
			extension = new JSONObject(profileInfo).toString();
		}
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public boolean isFavorite() {
		return isFavorite;
	}
	public void setFavorite(boolean isFavorite) {
		this.isFavorite = isFavorite;
	}
	public long get_avatarId() {
		return _avatarId;
	}
	public void set_avatarId(long _avatarId) {
		this._avatarId = _avatarId;
	}
	public long getProfileId() {
		return profileId;
	}
	public void setProfileId(long profileId) {
		this.profileId = profileId;
	}
	public String getAvatarLink() {
		return avatarLink;
	}
	public void setAvatarLink(String avatarLink) {
		this.avatarLink = avatarLink;
	}	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public void setMood(String mood) {
		this.mood = mood;
	}
	public void setMoodIcon(int moodIcon) {
		this.moodIcon = moodIcon;
	}
	public Date getProfileUpdated() {
		return profileUpdated;
	}
	public void setProfileUpdated(Date profileUpdated) {
		this.profileUpdated = profileUpdated;
	}	

	public int getIsFriend() {
		return isFriend;
	}	
	public void setIsFriend(int isFriend) {
		this.isFriend = isFriend;
	}
	public int getSyncToContacts() {
		return syncToContacts;
	}

	public void setSyncToContacts(int syncToContacts) {
		this.syncToContacts = syncToContacts;
	}
	
	public String getLocation() {
		return location;
	}
	public String getMood() {
		return mood; 
	}		
	public int getMoodIcon() {
		return moodIcon;
	}	
	
    public String getFriendType() {
        return friendType; 
    }       
    public void setFriendType(String friendType) {
        this.friendType = friendType;
    }
    public int getMutualFriendCnt() {
        return mutualFriendCnt;
    }   
    public void setMutualFriendCnt(int mutualFriendCnt) {
        this.mutualFriendCnt = mutualFriendCnt;
    }    
    
    
	/*
	private long    _avatarId;         //PROFILE_AVATAR._ID
	private long    profileId;         //PROFILE_AVATAR.PROFILE_ID
	private String  avatarLink;        //PROFILE_AVATAR.AVATAR_URL	
	private String  status;            //PROFILE.STATUS   
	private Date    profileUpdated;    //PROFILE.PUBLISHED
	private int isFriend;          // NotFriend(0), Friend(1), NotFan(2), Fan(4)
	private boolean isFavorite;        //PROFILE.ISFAVORITE�� ������
	*/
	public void readFromParcel(Parcel in) {
		long value;
		setDisplayName(in.readString());
		_avatarId=in.readLong();	
		setAvatarFile(in.readString());
		setAvatarUrl(in.readString());
		setAvatarLink(in.readString());
		setSnsId(in.readString());
		setUserId(in.readString());		
		setStatus(in.readString());
		setIsFriend(in.readInt());		
		setFavorite(in.readInt()==1);
		value = in.readLong();
		setProfileUpdated((value!=-1L)?new Date(value):null);	
		setLocation(in.readString());
		setFriendType(in.readString());
		setMutualFriendCnt(in.readInt());    
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(getDisplayName());
		dest.writeLong(get_avatarId());
		dest.writeString(getAvatarFile());	
		dest.writeString(getAvatarUrl());
		dest.writeString(getAvatarLink());
		dest.writeString(getSnsId());
		dest.writeString(getUserId());
		dest.writeString(getStatus());
		dest.writeInt(getIsFriend());		
		dest.writeInt(isFavorite()?1:0);
		dest.writeLong((getProfileUpdated()!=null)?getProfileUpdated().getTime():-1L);		
		dest.writeString(getLocation());
		dest.writeString(getFriendType());
		dest.writeInt(getMutualFriendCnt());
	}
	
    public static final Parcelable.Creator<FriendEntry> CREATOR = new Parcelable.Creator<FriendEntry>() {
        public FriendEntry createFromParcel(Parcel in) {
            return new FriendEntry(in);
        }

        public FriendEntry[] newArray(int size) {
            return new FriendEntry[size];
        }
    };

	public int describeContents() {
		return 0;
	}	
	
	/**
	 * ContentProvider�� Uri.<br>
	 * AIDL�� ���Ͽ� ������ �޼ҵ��̹Ƿ� IProfileFacade�� ����� �̿����� �ʰ�, �ϵ��ڵ�����.
	 * @return _id �� ������ null�� ����
	 */
	public Uri getAvatarUri() {
		if (_avatarId == 0) return null;
		return ContentUris.withAppendedId(Uri.parse("content://com.lge.sns.content.profile.provider/profileavatar"), _avatarId);
	}
	
}
