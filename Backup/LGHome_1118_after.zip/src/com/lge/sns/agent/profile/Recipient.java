/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.profile;

public class Recipient  extends SnsAuthorInfo  {
	private long   _id;            //THREAD_RECIPIENT._ID
	private long   _threadId;      //THREAD._ID
	private String recipientId;    //THREAD_RECIPIENT.RECIPIENT_ID
	private String recipientName;  //Calculation or PROFILE.USER_NAME or PROFILE_AVATAR.USER_NAME
	
	public long get_id() {
		return _id;
	}
	public void set_id(long _id) {
		this._id = _id;
	}
	public long get_threadId() {
		return _threadId;
	}
	public void set_threadId(long _threadId) {
		this._threadId = _threadId;
	}
	public String getRecipientId() {
		return recipientId;
	}
	public void setRecipientId(String recipientId) {
		this.recipientId = recipientId;
	}
	public String getRecipientName() {
		return recipientName;
	}
	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

	
}
