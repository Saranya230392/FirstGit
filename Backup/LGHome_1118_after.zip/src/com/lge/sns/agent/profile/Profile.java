/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.profile;

import java.util.Date;

import android.content.ContentUris;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
 
public class Profile extends FriendEntry implements Parcelable {		
	private long    _id;               //PROFILE._ID
	private String  email;	          //PROFILE.EMAIL
	private String  phoneNumber;       //PROFILE.PHONE_NUMBER
	private String  otherPhoneNumber;  //PROFILE.OTHER_PHONE_NUMBER
	private String  gender;            //PROFILE.GENDER
	private String  birthday;          //PROFILE.BIRTHDAY
	private String  work;              //PROFILE.WORK

	//0 : no relation
	//1 : friend
	//2 : follower
	//3 : following
	//4 : follower and following
	private String  friendStatus;      //PROFILE.FRIEND_STATUS
	private int     followerCount = -1;     //PROFILE.FOLLOWER_CNT
	private int     followingCount = -1;    //PROFILE.FOLLOWING_CNT
	
//	private String  education;         //PROFILE_INFO.EDUCATION
	
	private boolean online;			  //
	private int     isProtected;		  //PROFILE.ISPROTECTED
	private boolean isChangedAvatarUrl; // true if avatarUrl was changed.
	
//	public static final int FRIENDREQ_YES = 1;	// ģ����û�ϰ�� -> ���� 
//    public static final int FRIENDREQ_FRD = 2;	// ģ����û�ϰ�� -> ģ���ε� ��û�� ���
//    public static final int FRIENDREQ_OVER = 3;	// ģ����û�ϰ�� -> ��û�� �ٽ� �Ͼ ���(�ߺ���û)
	
	public Profile() {
		super();
	}

	public Profile(Parcel in) {
		readFromParcel(in);
	}
	
	public long get_id() {
		return _id;
	}
	public void set_id(long _id) {
		this._id = _id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getOtherPhoneNumber() {
		return otherPhoneNumber;
	}
	public void setOtherPhoneNumber(String otherPhoneNumber) {
		this.otherPhoneNumber = otherPhoneNumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getWork() {
		return work;
	}
	public void setWork(String work) {
		this.work = work;
	}
	public String getFriendStatus() {
		return friendStatus;
	}
	public void setFriendStatus(String friendStatus) {
		this.friendStatus = friendStatus;
	}
	public int getFollowerCount() {
		return followerCount;
	}
	public void setFollowerCount(int followerCount) {
		this.followerCount = followerCount;
	}
	public int getFollowingCount() {
		return followingCount;
	}
	public void setFollowingCount(int followingCount) {
		this.followingCount = followingCount;
	}
//	public String getEducation() {
//		return education;
//	}
//	public void setEducation(String education) {
//		this.education = education;
//	}
	public void setOnline(boolean online) {
		this.online = online;
	}
	public boolean getOnline() {
		return online;
	}
	public void setIsProtected(int isProtected) {
		this.isProtected = isProtected;
	}
	public int getIsProtected() {
		return isProtected;
	}
	
	public int describeContents() {
		return 0;
	}
/*
	private long    _id;               //PROFILE._ID
	private String  email;	          //PROFILE.EMAIL
	private String  phoneNumber;       //PROFILE.PHONE_NUMBER
	private String  otherPhoneNumber;  //PROFILE.OTHER_PHONE_NUMBER
	private String  gender;            //PROFILE.GENDER
	private String  birthday;          //PROFILE.BIRTHDAY
	private String  work;              //PROFILE.WORK
	//0 : no relation
	//1 : friend
	//2 : follower
	//3 : following
	//4 : follower and following
	private String  friendStatus;      //PROFILE.FRIEND_STATUS
	private int     followerCount = -1;     //PROFILE.FOLLOWER_CNT
	private int     followingCount = -1;    //PROFILE.FOLLOWING_CNT
//	private String  education;         //PROFILE_INFO.EDUCATION
	private boolean online;			  //
	private int     isProtected;		  //PROFILE.ISPROTECTED
	private int     syncToContacts; // PROFILE.SYNC_TO_CONTACTS
*/	
	public void readFromParcel(Parcel in) {
		long value;
		_id=in.readLong();		
		setSnsId(in.readString());
		setUserId(in.readString());
		setUserName(in.readString());	
		setAvatarUrl(in.readString());
		setEmail(in.readString());
		setPhoneNumber(in.readString());
		setOtherPhoneNumber(in.readString());
		setGender(in.readString());
		setBirthday(in.readString());
		setWork(in.readString());
		setFriendStatus(in.readString());
		setFollowerCount(in.readInt());
		setFollowingCount(in.readInt());
		setSyncToContacts(in.readInt());
		value = in.readLong();
		setProfileUpdated((value!=-1L)?new Date(value):null);									
		
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeLong(get_id());
		dest.writeString(getSnsId());
		dest.writeString(getUserId());
		dest.writeString(getUserName());
		dest.writeString(getAvatarUrl());
		dest.writeString(getEmail());
		dest.writeString(getPhoneNumber());
		dest.writeString(getOtherPhoneNumber());
		dest.writeString(getGender());
		dest.writeString(getBirthday());
		dest.writeString(getWork());
		dest.writeString(getFriendStatus());
		dest.writeInt(getFollowerCount());
		dest.writeInt(getFollowingCount());
		dest.writeInt(getSyncToContacts());
		dest.writeLong((getProfileUpdated()!=null)?getProfileUpdated().getTime():-1L);			
	}
	
    public static final Parcelable.Creator<Profile> CREATOR = new Parcelable.Creator<Profile>() {
        public Profile createFromParcel(Parcel in) {
            return new Profile(in);
        }

        public Profile[] newArray(int size) {
            return new Profile[size];
        }
    };	
    
	/**
	 * ContentProvider�� Uri.<br>
	 * AIDL�� ���Ͽ� ������ �޼ҵ��̹Ƿ� IProfileFacade�� ����� �̿����� �ʰ�, �ϵ��ڵ�����.
	 * @return _id �� ������ null�� ����
	 */
	public Uri getUri() {
		if (_id == 0) return null;
		return ContentUris.withAppendedId(Uri.parse("content://com.lge.sns.content.profile.provider/profile"), _id);
	}
	
	public boolean equals(Object obj) {
		if (obj instanceof Profile) {
			Profile profile = (Profile)obj;
			return (profile.getOwnerId().equals(getOwnerId()) && profile.getUserId().equals(getUserId()));
		}
		return super.equals(obj);
	}

	/**
	 * @param isChangedAvatarUrl the isChangedAvatarUrl to set
	 */
	public void setChangedAvatarUrl(boolean isChangedAvatarUrl) {
		this.isChangedAvatarUrl = isChangedAvatarUrl;
	}

	/**
	 * @return true if avatarUrl was changed.
	 */
	public boolean isChangedAvatarUrl() {
		return isChangedAvatarUrl;
	}
}
