/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.profile;

import android.net.Uri;

/**
 * User �⺻ ����
 * @author yumin.yang
 *
 */
public class SnsAuthorInfo {
	
	/**
	 * SNS Id
	 *        <p>Facebook : fb </p>
	 *        <p>Twitter  : tw </p>
	 *        <p>MySpace  : ms </p>
	 *        <p>Orkut    : ok </p>
	 *        
	 */
	private String snsId = "";
	
	/**
	 * �α��� id
	 */
	private String userId;
	
	/**
	 * ��ȸ ����� user�� id
	 *       <p> Feed�� ��ȸ�ϴ� ��� : ������ wall�ΰ�? </p>
	 *       
	 * * ���� : userId, authorId, ownerId �� �ٸ� �뵵�� ���ǹǷ� ��Ȯ�� �����ϰ� ����� �� 
	 */
	private String ownerId;
	
	/**
	 * 
	 */
	private String userName;
	
	/**
	 * 
	 */
	private String displayName;
	
	/**
	 * 
	 */
	private String avatarFile;      //PROFILE_AVATAR.AVATAR  ( Stored file path of an avatar image)
	
	/**
	 * 
	 */
	private String avatarUrl;
	
	private Uri    avatarBitmapUri;      // content://com.lge.sns.content.profile.provider/?avatarUri=###
	
	
	public SnsAuthorInfo() {
	}

	public SnsAuthorInfo(String snsId, String userId, String ownerId, String userName, String displayName, String avatarFile, String avatarUrl) {
		this.snsId = snsId;
		this.userId = userId;
		this.ownerId = ownerId;
		this.userName = userName;
		this.displayName = displayName;
		this.avatarFile = avatarFile;
		this.avatarUrl = avatarUrl;
	}	
	
	

	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public String getSnsId() {
		return snsId;
	}
	public void setSnsId(String snsId) {
		this.snsId = snsId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getAvatarFile() {
		if (avatarUrl != null && avatarFile == null) {
			avatarFile = String.valueOf(avatarUrl.hashCode());
		}
		return avatarFile;
	}
	public void setAvatarFile(String avatarFile) {
		this.avatarFile = avatarFile;
	}
	public void setAvatarUrl(String avatarUrl) {
		this.avatarUrl = avatarUrl;
	}
	public String getAvatarUrl() {
		return avatarUrl;
	}
    public Uri getAvatarBitmapUri() {
        if (avatarBitmapUri == null && avatarUrl != null) {
            avatarBitmapUri = Uri.parse("content://com.lge.sns.content.profile.provider/?avatarUrl=" + avatarUrl);
        }
        return avatarBitmapUri;
    }
	
}
