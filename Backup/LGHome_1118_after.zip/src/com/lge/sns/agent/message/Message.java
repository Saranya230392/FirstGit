/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.message;

import java.util.Date;
import java.util.List;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

import com.lge.sns.agent.profile.Recipient;
import com.lge.sns.agent.profile.SnsAuthorInfo;

/**
 * Message (Facebook, MySpace, Orkut)
 * @author hjunseo
 *
 */
public class Message  extends SnsAuthorInfo implements Parcelable {
	
	//unread ����
	public static final int UNREAD       = 1; //������
	public static final int READ      = 0; //����
	

	
	private long    _id;                  //MESSAGE._ID
	private long    _threadId;            //THREAD._ID
	
	/**
	 * thread�� id (�θ�)
	 */
	private String  threadId;             //THREAD.THREAD_ID
	
	/**
	 * message id (�ڽ�)
	 */
	private String  messageId;            //MESSAGE.MESSAGE_ID
	
	/**
	 * message �ۼ��� id
	 */
	private String  authorId;             //MESSAGE.AUTHOR_ID
	
	/**
	 * message �ۼ��� �̸�
	 */
	private String  authorName;           //Calculation or PROFILE.USER_NAME
	
	/**
	 * message�� ���� (�θ��� thread�� ����� ����)
	 */
	private String  title;				  //THREAD.TITLE
	
	/**
	 * message�� ����
	 */
	private String  body;                 //MESSAGE.CONTENT
	
	/**
	 * message ����Ͻ�
	 */
	private Date    publishedDate;        //MESSAGE.PUBLISHED
	
	/**
	 * message �о����� ����
	 */
	private int unread;               //MESSAGE.IS_READ
	
	/**
	 * message�� recipients (ms only)
	 */
	private List<Recipient> messageRecipients;		//MESSAGE_RECIPIENT.RECIPIENT_ID
	
	/**
	 * �ƹ�Ÿ �̹��� Bitmap
	 */
	private Bitmap avatarImage;
	
    public Message() {
        super();
    }
    
	public Message(Parcel in) {
		readFromParcel(in);
	}
	
	public long get_id() {
		return _id;
	}
	public void set_id(long _id) {
		this._id = _id;
	}
	public long get_threadId() {
		return _threadId;
	}
	public void set_threadId(long _threadId) {
		this._threadId = _threadId;
	}
	public String getThreadId() {
		return threadId;
	}
	public void setThreadId(String threadId) {
		this.threadId = threadId;
	}
	public String getMessageId() {
		return messageId;
	}
	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}
	public String getAuthorId() {
		return authorId;
	}
	public void setAuthorId(String authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}
	public int getUnread() {
		return unread;
	}
	public void setUnread(int unread) {
		this.unread = unread;
	}
	public List<Recipient> getMessageRecipients() {
		return messageRecipients;
	}
	public void setMessageRecipients(List<Recipient> recipients) {
		this.messageRecipients = recipients;
	}

	public Bitmap getAvatarImage() {
		return this.avatarImage;
	}
	public void setAvartarImage(Bitmap pm_oAvatarImage) {
		this.avatarImage = pm_oAvatarImage;
	}
	
	public int describeContents() {
		return 0;
	}

	
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeLong(get_id());
		dest.writeLong(get_threadId());
		dest.writeString(getThreadId());
		dest.writeString(getMessageId());
		dest.writeString(getAuthorId());
		dest.writeString(getAuthorName());
		dest.writeString(getBody());
		dest.writeString(getTitle());
		dest.writeLong(this.getPublishedDate()!= null? this.getPublishedDate().getTime() : -1L);
		dest.writeInt(getUnread());
		
		// SnsAuthorInfo
    	dest.writeString(getOwnerId());
    	dest.writeString(getSnsId());
    	dest.writeString(getUserId());
    	dest.writeString(getUserName());
    	dest.writeString(getDisplayName());
    	
    	dest.writeString(getAvatarFile());
    	dest.writeString(getAvatarUrl());
	}
	
	
	private void readFromParcel(Parcel in) {
		long value;
		_id=in.readLong();		
		set_threadId(in.readLong());
		setThreadId(in.readString());
		setMessageId(in.readString());
		setAuthorId(in.readString());	
		setAuthorName(in.readString());
		setBody(in.readString());
		setTitle(in.readString());
		value = in.readLong();
		setPublishedDate((value!=-1L)?new Date(value):null);
		setUnread(in.readInt());
		
		// SnsAuthorInfo
        setOwnerId(in.readString());
        setSnsId(in.readString());
        setUserId(in.readString());
        setUserName(in.readString());
        setDisplayName(in.readString());
        
        setAvatarFile(in.readString());
        setAvatarUrl(in.readString());
	}

    public static final Parcelable.Creator<Message> CREATOR = new Parcelable.Creator<Message>() {
        public Message createFromParcel(Parcel in) {
            return new Message(in);
        }

        public Message[] newArray(int size) {
            return new Message[size];
        }
    };
    
	
}