/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.message;

import java.util.Date;
import java.util.List;

import android.os.Parcel;
import android.os.Parcelable;

import com.lge.sns.agent.profile.Profile;
import com.lge.sns.agent.profile.Recipient;
import com.lge.sns.agent.profile.SnsAuthorInfo;
/**
 * Thread
 * @author hjunseo
 *
 */
public class MessageThread extends SnsAuthorInfo implements Parcelable{
	public static interface MessageThreadCallback {
		void onAdded(MessageThread thread);
		void onUpdated(MessageThread thread);
	}
	
	//unread ����
	public static final int UNREAD      = 1; // ������
	public static final int READ           = 0; //����


	//threadType ����
	public static final String MODE_INBOX_THREAD  = "Inbox";	
	public static final String MODE_OUTBOX_THREAD = "Outbox";
	public static final String MODE_ALL_THREAD    = "All";	
	
	
	private long    _id;           //THREAD._ID
	
	/**
	 * thread id (�ڽ�)
	 */
	private String  threadId;      //THREAD.THREAD_ID
	
	/**
	 * thread�� Inbox/Outbox ����
	 */
	private String  threadType;    //THREAD.THREAD_TYPE  (in,out)
	
	/**
	 * thread�� �ۼ��� ����� id
	 */
	private String  authorId;      //THREAD.AUTHOR_ID
	
	/**
	 * thread�� �ۼ��� ����� �̸�
	 */
	private String  authorName;    //Calculation or PROFILE.USER_NAME
	
	/**
	 * thread ����
	 */
	private String  title;         //THREAD.TITLE
	
	/**
	 * thread ����
	 */
	private String  content;       //THREAD.CONTENT
	
	/**
	 * thread ����Ͻ�
	 */
	private Date    publishedDate; //THREAD.PUBLISHED
	
	/**
	 * thread �о��� �� ����
	 */
	private int unread;        //THREAD.IS_READ 
	
	/**
	 * thread�� �޴� ��� (���� �� ����)
	 */
	private List<Recipient> recipients;  //THREAD_RECIPIENT object
	
	/**
	 * thread�� ������ message ����
	 */
	private int     messageCnt;    //THREAD.MESSAGE_CNT
	

    public MessageThread() {
        super();
    }
    
	public MessageThread(Parcel in) {
		readFromParcel(in);
	}
	

	public long get_id() {
		return _id;
	}
	public void set_id(long _id) {
		this._id = _id;
	}
	public String getThreadId() {
		return threadId;
	}
	public void setThreadId(String threadId) {
		this.threadId = threadId;
	}
	public String getThreadType() {
		return threadType;
	}
	public void setThreadType(String threadType) {
		this.threadType = threadType;
	}
	public String getAuthorId() {
		return authorId;
	}
	public void setAuthorId(String authorId) {
		this.authorId = authorId;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}
	public int getUnread() {
		return unread;
	}
	public void setUnread(int unread) {
		this.unread = unread;
	}
	public List<Recipient> getRecipients() {
		return recipients;
	}
	public void setRecipients(List<Recipient> recipients) {
		this.recipients = recipients;
	}
	public int getMessageCnt() {
		return messageCnt;
	}
	public void setMessageCnt(int messageCnt) {
		this.messageCnt = messageCnt;
	}

	
	
	public int describeContents() {
		return 0;
	}

	public void writeToParcel(Parcel dest, int flags) {
		dest.writeLong(get_id());
		dest.writeString(getThreadId());
		dest.writeString(getThreadType());
		dest.writeString(getAuthorId());
		dest.writeString(getAuthorName());
		dest.writeString(getTitle());
		dest.writeString(getContent());
		dest.writeLong(this.getPublishedDate()!= null? this.getPublishedDate().getTime() : -1L);
		dest.writeInt(getUnread());
		dest.writeInt(getMessageCnt());
		
		// SnsAuthorInfo
    	dest.writeString(getOwnerId());
    	dest.writeString(getSnsId());
    	dest.writeString(getUserId());
    	dest.writeString(getUserName());
    	dest.writeString(getDisplayName());
    	
    	dest.writeString(getAvatarFile());
    	dest.writeString(getAvatarUrl());
	}
	
	
	private void readFromParcel(Parcel in) {
		long value;
		_id=in.readLong();		
		setThreadId(in.readString());
		setThreadType(in.readString());
		setAuthorId(in.readString());	
		setAuthorName(in.readString());
		setTitle(in.readString());
		setContent(in.readString());
		value = in.readLong();
		setPublishedDate((value!=-1L)?new Date(value):null);
		setUnread(in.readInt());
		setMessageCnt(in.readInt());
		
		// SnsAuthorInfo
        setOwnerId(in.readString());
        setSnsId(in.readString());
        setUserId(in.readString());
        setUserName(in.readString());
        setDisplayName(in.readString());
        
        setAvatarFile(in.readString());
        setAvatarUrl(in.readString());
	}

    public static final Parcelable.Creator<MessageThread> CREATOR = new Parcelable.Creator<MessageThread>() {
        public MessageThread createFromParcel(Parcel in) {
            return new MessageThread(in);
        }

        public MessageThread[] newArray(int size) {
            return new MessageThread[size];
        }
    };	
	
}