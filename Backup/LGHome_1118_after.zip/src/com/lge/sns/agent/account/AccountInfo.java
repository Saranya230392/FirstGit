/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.account;

import java.lang.ref.SoftReference;
import java.util.Date;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Parcel;
import android.os.Parcelable;


public class AccountInfo  implements Parcelable {

	public static int NOT_ASSIGNED = -1;
	private long _id = NOT_ASSIGNED;
	private String snsId;
	private String userId;      //SnsAuth.java : newbay�� uid
	private String loginId;	
	private String sessionKey;  //SnsAuth.java : newbay�� token
	private int initStatus;
	private boolean isMain;
	private boolean isNotify;
	private boolean isLogin;
	private byte[] iconImage;
	 							//SnsAuth.java : newbay�� tokenValidationTime �� intercasting�� ����
	
	private Date sync_time;    //  Friend�� ���������� ����ȭ�� �ð��� millisecond�� ����
	
	private SoftReference<Bitmap> bitmapRef;
	
	public AccountInfo() {
	}

	public AccountInfo(Parcel in) {
        readFromParcel(in);
    }

	public AccountInfo(long _id, String snsId, String userId,
			String loginId, int initStatus, boolean isMain,  
			boolean isNotify, byte[] iconImage) {
		this._id = _id;
		this.snsId = snsId;
		this.userId = userId;
		this.loginId = loginId;
		this.initStatus = initStatus;
		this.isMain = isMain;
		this.isNotify = isNotify;
		this.iconImage = iconImage;
	}

    public AccountInfo(long _id, String snsId, String userId,
            String loginId, int initStatus, boolean isMain,  
            boolean isNotify, byte[] iconImage, Date syncTime) {
        this._id = _id;
        this.snsId = snsId;
        this.userId = userId;
        this.loginId = loginId;
        this.initStatus = initStatus;
        this.isMain = isMain;
        this.isNotify = isNotify;
        this.iconImage = iconImage;
        this.sync_time = syncTime;
    }

	public String getSnsId() {
		return this.snsId;
	}
	
	public void setSnsId(String snsId) {
		this.snsId = snsId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserId() {
		return userId;
	}

	public void setSessionKey(String sessionKey) {
		this.sessionKey = sessionKey;
	}

	public String getSessionKey() {
		return sessionKey;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getLoginId() {
		return loginId;
	}

	public void set_id(long _id) {
		this._id = _id;
	}

	public long get_id() {
		return _id;
	}

	public int getInitStatus() {
		return initStatus;
	}
	
	public void setInitStatus(int initStatus) {
		this.initStatus = initStatus;
	}
	
	public boolean isInitilaized() {
		return initStatus == 2;
	}
	
	public void setMain(boolean isMain) {
		this.isMain = isMain;
	}

	public boolean isMain() {
		return isMain;
	}

	public void setNotify(boolean isNotify) {
		this.isNotify = isNotify;
	}

	public boolean isNotify() {
		return isNotify;
	}

	public void setIconImage(byte[] iconImage) {
		this.iconImage = iconImage;
	}

	public byte[] getIconImage() {
		return iconImage;
	}
    
    public Date getSyncTime() {
        return sync_time;
    }

    public void setSyncTime(Date syncTime) {
        sync_time = syncTime;
    }

	public void setBitmapRef(SoftReference<Bitmap> bitmapRef) {
		this.bitmapRef = bitmapRef;
	}

	public SoftReference<Bitmap> getBitmapRef() {
		return bitmapRef;
	}

	public Bitmap getBitmap() {
		Bitmap bitmap = null;
		if (iconImage!=null) {
			if (bitmapRef!=null) {
				bitmap = bitmapRef.get();
			}
			if (bitmap == null) {
				bitmap = BitmapFactory.decodeByteArray(iconImage, 0, iconImage.length);
				bitmapRef = new SoftReference<Bitmap>(bitmap);
			}
		}
		return bitmap;
	}

	public void setLogin(boolean isLogin) {
		this.isLogin = isLogin;
	}

	public boolean isLogin() {
		return isLogin;
	}


    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(_id);
        dest.writeString(getSnsId());
        dest.writeString(getUserId());
        dest.writeString(getLoginId());
        dest.writeValue(new Boolean(this.isMain()));
    }

    public void readFromParcel(Parcel in) {
        _id=in.readLong();
        setSnsId(in.readString());
        setUserId(in.readString());
        setLoginId(in.readString());
        setMain((Boolean)in.readValue(Boolean.class.getClassLoader()));
    }
    
    public static final Parcelable.Creator<AccountInfo> CREATOR = new Parcelable.Creator<AccountInfo>() {
        public AccountInfo createFromParcel(Parcel in) {
            return new AccountInfo(in);
        }

        public AccountInfo[] newArray(int size) {
            return new AccountInfo[size];
        }
    };
    
}
