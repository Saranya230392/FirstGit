/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.feed;

import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;


public class FeedAttachment implements Parcelable {

    private long   _id;           //FEED_ATTACHMENT._ID
    private String feedId;       // ���������ִ� feedId   => feed.getFeedId �� ����.
    
    /**
     * Attachment�� type
     *     <p> Facebook : photo, link, video, others </p>
     *     <p> MySpace  : </p>
     *     <p> Orkut    : </p>
     */
    private String mediaType;     //FEED_ATTACHMENT.MEDIA_TYPE
    
    /**
     * Attachment�� type�� photo�� ���, �ٹ��� id (�θ��� id)
     */
    private String folderId;      //FEED_ATTACHMENT.FOLDER_ID
    
    /**
     * Attachment�� type�� photo�� ���, �ٹ��� �̸� (�θ��� �̸�)
     */
    private String folderName;
    
    /**
     * ���� ������ �� URL
     *      <p> Facebook : mediaType�� photo�� ���  - ������ URL </p>
     *      <p>            mediaType�� video�� ���  - Video ���������� URL </p>
     *      <p>            mediaType�� link�� ���    - Link ������ URL </p>
     *      <p> MySpace  : </p>
     *      <p> Orkut    : </p>          
     *      
     */
    private String thumbnailUrl;  //FEED_ATTACHMANT.THUMBNAIL_URL
    
    /**
     * ���� ������ URL�� local file�� ������ ���
     */
    private String thumbnailFile;     //FEED_ATTACHMANT.THUMBNAIL (Stored file path)
    
    /**
     * ū ������ �� url (db�� �������� ����)
     */
    private String attachmentUrl; //FEED_ATTACHMANT.ATTACHMENT_URL (WEB page URL including photo or video)
    
    private String feedType;    // feedType���� attachment�� �����ϱ� ����..(03/04 �߰� *** db ������ ����..)
    
    private String attachName;      // (03/08 �߰�, link, video)
    
    private String descript;        // (03/08 �߰�, link, video)
    
    private Date eventTime;     // (03/19 �߰�)
    
    private String eventLoc;        // (03/19 �߰�)
    
    private String pictureId;      // (04/14 �߰�)
    
    
    public FeedAttachment() {
        super();
    }

    public FeedAttachment(Parcel in) {
        readFromParcel(in);
    }
    
    public long get_id() {
        return _id;
    }
    public void set_id(long _id) {
        this._id = _id;
    }
    public String getFeedId() {
        return feedId;
    }
    public void setFeedId(String feedId) {
        this.feedId = feedId;
    }
    public String getMediaType() {
        return mediaType;
    }
    public void setMediaType(String mediaType) {
        this.mediaType = mediaType;
    }
    public String getFolderId() {
        return folderId;
    }
    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }
    public String getThumbnailUrl() {
        return thumbnailUrl;
    }
    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }
    public String getThumbnailFile() {
        return thumbnailFile;
    }
    public void setThumbnailFile(String thumbnailFile) {
        this.thumbnailFile = thumbnailFile;
    }
    public String getAttachmentUrl() {
        return attachmentUrl;
    }
    public void setAttachmentUrl(String attachmentUrl) {
        this.attachmentUrl = attachmentUrl;
    }
    public String getFolderName() {
        return folderName;
    }       
    public void setFolderName(String folderName) {
        this.folderName = folderName;
    }
    
    public String getFeedType() {
        return feedType;
    }       
    public void setFeedType(String feedType) {
        this.feedType = feedType;
    }   
    public String getAttachName() {
        return attachName;
    }       
    public void setAttachName(String attachName) {
        this.attachName = attachName;
    }   
    public String getDescript() {
        return descript;
    }       
    public void setDescript(String descript) {
        this.descript = descript;
    }   
    
    public Date getEventTime() {
        return eventTime;
    }       
    public void setEventTime(Date eventTime) {
        this.eventTime = eventTime;
    }   
    
    public String getEventLoc() {
        return eventLoc;
    }       
    public void setEventLoc(String eventLoc) {
        this.eventLoc = eventLoc;
    }       
    
    public String getPictureId() {
        return pictureId;
    }       
    public void setPictureId(String pictureId) {
        this.pictureId = pictureId;
    }   
    
    
    public int describeContents() {
        // TODO Auto-generated method stub
        return 0;
    }
    
    public void readFromParcel(Parcel in) {
        set_id(in.readLong());
        setFeedId(in.readString());
        setMediaType(in.readString());
        setFolderId(in.readString());
        setThumbnailUrl(in.readString());
        setThumbnailFile(in.readString());
        setAttachmentUrl(in.readString());
        setFolderName(in.readString());
        setFeedType(in.readString());
        setAttachName(in.readString());
        setDescript(in.readString());
    }

    
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(get_id());
        dest.writeString(getFeedId());
        dest.writeString(getMediaType());
        dest.writeString(getFolderId());
        dest.writeString(getThumbnailUrl());
        dest.writeString(getThumbnailFile());
        dest.writeString(getAttachmentUrl());
        dest.writeString(getFolderName());
        dest.writeString(getFeedType());
        dest.writeString(getAttachName());
        dest.writeString(getDescript());
    }
    
    public static final Parcelable.Creator<FeedAttachment> CREATOR = new Parcelable.Creator<FeedAttachment>() {
        public FeedAttachment createFromParcel(Parcel in) {
            return new FeedAttachment(in);
        }

        public FeedAttachment[] newArray(int size) {
            return new FeedAttachment[size];
        }
    };
    
}