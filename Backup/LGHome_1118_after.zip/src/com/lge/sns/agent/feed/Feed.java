/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.feed;

import java.util.ArrayList;
import java.util.Date;

import android.os.Parcel;
import android.os.Parcelable;

import com.lge.sns.agent.profile.SnsAuthorInfo;

import com.lge.launcher.R;

/**
 * Feed
 * @author hjunseo
 *
 */
public class Feed extends SnsAuthorInfo implements Parcelable {
    public static interface FeedCallback {
        void onEntry(Feed feed);
    }

    //feedType ����
    public static final String TYPE_FB_LIVE_FEED        = "livefeed";       // Home        
    public static final String TYPE_FB_WALL             = "wall";           // wall : profile
    public static final String TYPE_FB_WALLTOWALL       = "walltowall";     // walltowall
    public static final String TYPE_FB_NOTI             = "noti";           // Notification (�߰�����)

    public static final String TYPE_TW_HOME             = "home";           // all tweets
    public static final String TYPE_TW_FAVORITE         = "favorite";       // yellow star *
    public static final String TYPE_TW_MENTION          = "mention";        // @me, �ٸ� ����� ���� ����� �� 
    public static final String TYPE_TW_PROFILE_TWEETS   = "profileTweets";  // Profileȭ���� tweets (���� �ۼ��� Ʈ�� + ���� retweet�� tweets)

    public static final String TYPE_MS_STREAM           = "stream";         // home�� ����..
    public static final String TYPE_MS_COMMENTS         = "comments";       // wall

    public static final String TYPE_OK_UPDATES          = "updates";        // home
    public static final String TYPE_OK_SCRAP            = "scrap";          // wall �� ����..

    public static final String[] feedTypeList = {
        TYPE_FB_WALL,                           // FB : Profile > Wall
        TYPE_FB_LIVE_FEED,                      // FB : Home - LiveFeed
        TYPE_TW_HOME,                           // TW
        TYPE_TW_FAVORITE,                       // TW
        TYPE_TW_MENTION,                        // TW
        TYPE_TW_PROFILE_TWEETS,                 // TW
        TYPE_MS_STREAM,                         // MS
        TYPE_MS_COMMENTS,                       // MS
        TYPE_OK_UPDATES,                        // OK
        TYPE_OK_SCRAP                           // OK
    };

    //category ����
    public static final String CATEGORY_ALL            = "all";                      // Facebook, MySpace, Orkut
    public static final String CATEGORY_PROFILE_STATUS = "profileStatus";            // Facebook
    public static final String CATEGORY_PHOTOANDVIDEO  = "photoAndVideo";            // Facebook, Orkut
    public static final String CATEGORY_PHOTO          = "photo";                    // Facebook
    public static final String CATEGORY_VIDEO          = "video";                    // Facebook
    public static final String CATEGORY_LINK           = "link";                     // Facebook
    public static final String CATEGORY_OTHERS         = "others";                   // Facebook
    public static final String CATEGORY_NOTE           = "note";                     // Facebook
    public static final String CATEGORY_EVENT          = "event";                    // Facebook
    public static final String CATEGORY_NOTI           = "noti";                     // Facebook notification

    public static final String CATEGORY_FRIENDSTATUSANDMOOD  = "friendStatusAndMood";            // Myspace     // stream
    public static final String CATEGORY_STATUSANDMOOD  = "statusAndMood";            // Myspace     // stream
    public static final String CATEGORY_ACTIVITIES     = "friendsActivities";        // Myspace     // stream
    public static final String CATEGORY_PROFILE        = "Profile";                     // Myspace      // comments
    
    public static final String CATEGORY_STATUS_MSG     = "status_msg";               // Orkut   updates
    public static final String CATEGORY_TEXT           = "text";                     // Orkut   scrap
    


    public static final String[] categoryList = {
        CATEGORY_ALL,
        CATEGORY_PROFILE_STATUS,
        CATEGORY_PHOTOANDVIDEO,
        CATEGORY_PHOTO,
        CATEGORY_VIDEO,
        CATEGORY_LINK,
        CATEGORY_OTHERS,
        CATEGORY_NOTE,
        CATEGORY_FRIENDSTATUSANDMOOD,
        CATEGORY_STATUSANDMOOD,
        CATEGORY_ACTIVITIES,
        CATEGORY_PROFILE
    };



    // Like/Unlike�� ����
    public static final String LIKE_YES = "1";           // fB:  like        TW: favorite �Է�
    public static final String LIKE_NO  = "0";           //      Unlike          favorite ����


    private long    _id;          //FEED._ID

    /**
     * Feed�� ����(������ Homeȭ������, ����ں� Feed ȭ������)
     *          <p> Facebook : wall     - Profile > Wall  </p>
     *          <p>            newsfeed - Home > NewsFeed </p>
     *          <p>            livefeed - Home > LiveFeed </p>
     *          <p> Twitter  : �̻��. ""�� ���� </p>
     *          <p> MySpace  : To be defined </p>
     *          <p> Orkut    : To be defined </p>
     */
    private String  feedType;     //FEED.FEED_TYPE

    /**
     * Feed�� ��ϵ� �Ͻ�. �и��� ����
     */
    private Date    published;    //FEED.PUBLISHED

    /**
     * ����ڰ� Feed�� �о����� ����(SNS�� �ƴ� �޴��� �������� ���) - �̻��
     *          <p> ����      : 1 </p>
     *          <p> ���� ���� : 0 </p>
     */
    private Date    opened;       //FEED.OPENDED

    /**
     * Feed�� �����ϰ� �ĺ��ϴ� ��ȣ(SNS���� �ο���)
     */
    private String  feedId;       //FEED.FEED_ID

    /**
     * Feed �� ���� �ۼ��� ����� UserId
     *
     *   <p>���� </p>
     *   <p>   1. Facebook���� feedType='wall'�� ���  </p>
     *   <p>      - userId   : �α����� ����ڴ� �����ΰ� </p>
     *   <p>      - ownerId  : ������ Wall�� ������ �ϴ°� </p>
     *   <p>      - authorId : wall���� �������� feed �� ���� �ۼ��� ���ΰ� </p>
     *   <p>   2. Facebook���� feedType='livefeed'�� ���  </p>
     *   <p>      - userId   : �α����� ����ڴ� �����ΰ� </p>
     *   <p>      - ownerId  : userId�� ���� ��(livefeed�� �α����� �ڽ��� �͸� �� �� �����Ƿ�) </p>
     *   <p>      - authorId : livefeed�� �������� feed �� ���� �ۼ��� ���ΰ� </p>
     *
     */
    private String  authorId;     //FEED.AUTHOR_ID

    /**
     * Feed ����
     */
    private String  content;      //FEED.CONTENT

    /**
     * Feed�� ��, ����, �������ϻ���, ��ũ, ���� ���� ����
     *   <p>�� ���� Facebook : link, profileStatus, photo, video, event, others</p>
     *   <p>        Twitter  : �̻��</p>
     *   <p>        MySpace  : </p>
     *   <p>        Orkut    : </p>
     *   <p>          all </p>
     *
     */
    private String  category;     //FEED.CATEGORY

    /**
     * Facebook : Feed�� Like�� ����� ����� ��
     * Twitter  : favorite this tweet�� Ŭ���� ��� 1, ���� ���� ��� 0
     * MySpace  : �̻��
     * Orkut    : �̻��
     */
    private int     likeCnt;      //FEED.LIKE_CNT

    /**
     * Feed�� Comment�� ����� ����
     */
    private int     commentCnt;   //FEED.COMMENT_CNT

    /**
     * Title
     *     <p> Facebook : ""�� ����. UI���� �ӽú����� ��� </p>
     *     <p> Twitter  : </p>
     *     <p> MySpace  : </p>
     *     <p> Orkut    : </p>
     */
    private String  title;        //FEED.TITLE

    /**
     * Feed�� Comment�� ����� �� �ִ� �� ����
     *     <p> Facebook : �׻� true. Facebook������ Comment�� blocking�ϴ� ����� ���� </p>
     *     <p> Twitter  : </p>
     *     <p> MySpace  : </p>
     *     <p> Orkut    : </p>
     */
    private String  allowComment; //FEED.ALLOW_COMMENT

    /**
     * Facebook ����
     *
     * Wall To Wall�� ������ Feed���� ����
     *
     *   1) null�̸� Wall to wall�� ���� �ʴ� Feed
     *   2) ���� �����ϸ� Wall to wall�� ������ Feed
     *
     */
    private String  wallToWallId; //FEED.WallToWallId

    /**
     * Feed�� authorId�� �� ģ������ ����
     *  
     *  <p> Facebook : </p>
     *                <p> NotFriend, me : 0 </p>
     *                <p> Friend        : 1 </p>
     *                <p> Fan           : 3 </p>     *
     *                               <p> Fan�� ��� wall���� profile �̵��� �ȵ� </p>     *
     *  <p> Twitter   : </p> 
     *                profile �̵��� ��� feed���� �����ϹǷ� ģ�������� �ʿ����. �� getFeedlist(home)�ϰ�� ���� ģ���϶��� profile������ ������Ʈ�ϵ��� �Ѵ�.
     *                <p> me                 : 0 </p>
     *                <p> Friend(Following)  : 1 </p>     *
     *                <p> NotFriend          : 2 </p>       
     *                <p> Following ������ �˼� ���� authorId, ownerId �� �ٸ����� ģ���� �ƴҰ��� ����.           
     *  <p> MySpace   : </p>
     *                <p> NotFriend, me : 0 </p>
     *                <p> Friend        : 1 </p>     *  
     *  <p> Orkut     : </p>
     *                <p> NotFriend, me : 0 </p>
     *                <p> Friend        : 1 </p>     *
     *                
     *     ***** 0�ϰ�� ���� ģ���ƴ����� �������µ� ������ �ʿ��� ���(UI���� ó���Ұ��) => userId=getAuthorId() ��ġ�ϸ� �ڽ��̰�, ����ġ�ϸ� ģ���ƴ����� ó���Ѵ�
     */
    private int isFriend;     //FEED.IS_FRIEND

    /**
     * Feed�� ���� Attachment�� ����
     */
    private int feedAttachmentCnt;
    
    /**
     * only Facebook
     * Category: photo => 4 new photos
     * Category: link => Harry is looking for the following ~~~
     */
    private String caption;


    /**
     * owner name (=author�� nickname)
     */
    private String ownerNickName;

    /**
     * only twitter -> RepliedTweetId
     */
    private String repliedTweetId;

    /**
     * only twitter -> repliedTweetUserId
     */
    private String repliedTweetUserId;

    /**
     * only twitter -> repliedTweetUserName
     */
    private String repliedTweetUserName;

    /**
     * only twitter -> ��ó(tweet�� ����� device)
     * ��: web - ��������
     *     API - LG��
     */
    private String source;

    /**
     * only twitter -> ���� retweet�ߴ��� ����(1:retweet�� ����, 0:retweet �� �� �ִ� ����)
     */
    private int retweet;

    /**
     * only myspace
     */
    private String moodFieldText;

    /**
     * only myspace
     *                                  <p> 0  - Not Available     </p>
     *
     *                                  <p> 1  - spacer.gif        </p>
     *                                  <p> 2  - chipper.gif       </p>
     *                                  <p> 3  - adored.gif        </p>
     *                                  <p> 4  - aggravated.gif    </p>
     *                                  <p> 5  - kiss.gif          </p>
     *                                  <p> 6  - amused.gif        </p>
     *                                  <p> 7  - angry.gif         </p>
     *                                  <p> 8  - artistic.gif      </p>
     *                                  <p> 9  - annoyed.gif       </p>
     *                                  <p> 10 - scared.gif        </p>
     *                                  <p> 11 - apathetic.gif     </p>
     *                                  <p> 12 - cold.gif          </p>
     *                                  <p> 13 - awake.gif         </p>
     *                                  <p> 14 - bitchy.gif        </p>
     *                                  <p> 15 - blah.gif          </p>
     *                                  <p> 16 - happy.gif         </p>
     *                                  <p> 17 - anxious.gif       </p>
     *                                  <p> 18 - bored.gif         </p>
     *                                  <p> 19 - bouncey.gif       </p>
     *                                  <p> 20 - busy.gif          </p>
     *                                  <p> 21 - tired.gif         </p>
     *                                  <p> 22 - confused.gif      </p>
     *                                  <p> 23 - contemplative.gif </p>
     *                                  <p> 24 - cooky.gif         </p>
     *                                  <p> 25 - crappy.gif        </p>
     *                                  <p> 26 - crazy.gif         </p>
     *                                  <p> 27 - curious.gif       </p>
     *                                  <p> 28 - devious.gif       </p>
     *                                  <p> 29 - drained.gif       </p>
     *                                  <p> 30 - electric.gif      </p>
     *                                  <p> 31 - moody.gif         </p>
     *                                  <p> 32 - examimate.gif     </p>
     *                                  <p> 33 - flirty.gif        </p>
     *                                  <p> 34 - focused.gif       </p>
     *                                  <p> 35 - weird.gif         </p>
     *                                  <p> 36 - geeky.gif         </p>
     *                                  <p> 37 - gloomy.gif        </p>
     *                                  <p> 38 - horny.gif         </p>
     *                                  <p> 39 - hungry.gif        </p>
     *                                  <p> 40 - indescribable.gif </p>
     *                                  <p> 41 - lazy.gif          </p>
     *                                  <p> 42 - love.gif          </p>
     *                                  <p> 43 - unhappy.gif       </p>
     *                                  <p> 44 - sleepy.gif        </p>
     *                                  <p> 45 - headphones.gif    </p>
     *                                  <p> 46 - vital.gif         </p>
     *
     */
    private int moodEmoticon;

    /**
     * �ڽ��� like ����  yes:1 no:0
     */
    private int myLike;
    
    /**
     * FB comment, like post ����  ����=1, �Ұ���=0
     */    
    private int canPostComment;

    /**
     * Published data string for display
     */
    private String textPublished;

    /**
     * like count string for display
     */
    private String textLike;

    /**
     * comment count string for display
     */
    private String textComment;
    
    private String noti_href;                   // Notification URL
    private String noti_type;                   // Notification Type(comment, picture, album, wall)
    private String noti_id;                     // Notification Ÿ�Կ� ���� ID(comment->feedId, picture->pictureId, album->albumId, wall->ownerId)


    public Feed() {
        super();
    }

    public Feed(Parcel in) {
        readFromParcel(in);
    }

    private ArrayList<FeedAttachment> feedAttachment = new ArrayList<FeedAttachment>();

    public long get_Id() {
        return _id;
    }
    public void set_Id(long _id) {
        this._id = _id;
    }
    public String getFeedType() {
        return feedType;
    }
    public void setFeedType(String feedType) {
        this.feedType = feedType;
    }
    public Date getPublished() {
        return published;
    }
    public void setPublished(Date published) {
        this.published = published;
    }
    public Date getOpened() {
        return opened;
    }
    public void setOpened(Date opened) {
        this.opened = opened;
    }
    public String getFeedId() {
        return feedId;
    }
    public void setFeedId(String feedId) {
        this.feedId = feedId;
    }
    public String getAuthorId() {
        return authorId;
    }
    public void setAuthorId(String authorId) {
        this.authorId = authorId;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public String getCategory() {
        return category;
    }
    public void setCategory(String category) {
        this.category = category;
    }
    public int getLikeCnt() {
        return likeCnt;
    }
    public void setLikeCnt(int likeCnt) {
        this.likeCnt = likeCnt;
    }
    public int getCommentCnt() {
        return commentCnt;
    }
    public void setCommentCnt(int commentCnt) {
        this.commentCnt = commentCnt;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getAllowComment() {
        return allowComment;
    }
    public void setAllowComment(String allowComment) {
        this.allowComment = allowComment;
    }
    public void setFeedAttachment(ArrayList<FeedAttachment> feedAttachment) {
        this.feedAttachment = feedAttachment;
    }
    public ArrayList<FeedAttachment> getFeedAttachment() {
        return feedAttachment;
    }
    public void setIsFriend(int isFriend) {
        this.isFriend = isFriend;
    }
    public int getIsFriend() {
        return isFriend;
    }
    public void setFeedAttachmentCnt(int feedAttachmentCnt) {
        this.feedAttachmentCnt = feedAttachmentCnt;
    }
    public int getFeedAttachmentCnt() {
        return feedAttachmentCnt;
    }

    public int describeContents() {
        return 0;
    }
    public String getWallToWallId() {
        return wallToWallId;
    }
    public void setWallToWallId(String wallToWallId) {
        this.wallToWallId = wallToWallId;
    }
    public String getCaption() {
        return caption;
    }
    public void setCaption(String caption) {
        this.caption = caption;
    }   
    public String getOwnerNickName() {
        return ownerNickName;
    }
    public void setOwnerNickName(String ownerNickName) {
        this.ownerNickName = ownerNickName;
    }
    public int getMyLike() {
        return myLike;
    }
    public void setMyLike(int myLike) {
        this.myLike = myLike;
    }
    public void setCanPostComment(int canPostComment) {
        this.canPostComment = canPostComment;
    }
    public int getCanPostComment() {
        return canPostComment;
    }    


    // twitter
    public String getRepliedTweetId() {
        return repliedTweetId;
    }
    public void setRepliedTweetId(String repliedTweetId) {
        this.repliedTweetId = repliedTweetId;
    }
    public String getRepliedTweetUserId() {
        return repliedTweetUserId;
    }
    public void setRepliedTweetUserId(String repliedTweetUserId) {
        this.repliedTweetUserId = repliedTweetUserId;
    }
    public String getRepliedTweetUserName() {
        return repliedTweetUserName;
    }
    public void setRepliedTweetUserName(String repliedTweetUserName) {
        this.repliedTweetUserName = repliedTweetUserName;
    }
    public String getSource() {
        return source;
    }
    public void setSource(String source) {
        this.source = source;
    }
    public int getRetweet() {
        return retweet;
    }
    public void setRetweet(int retweet) {
        this.retweet = retweet;
    }


    // myspace


    //mood
    public static final String MOOD_NONE = "(none)";  //�Ʒ� �ش������ ���� ���

    public static final String MOOD_SPACER = "(none)";
    public static final String MOOD_CHIPPER = "chipper";
    public static final String MOOD_ADORED = "adored";
    public static final String MOOD_AGGRAVATED = "aggravated";
    public static final String MOOD_KISS = "kiss";
    public static final String MOOD_AMUSED = "amused";
    public static final String MOOD_ANGRY = "angry";
    public static final String MOOD_ARTISTIC = "artistic";
    public static final String MOOD_ANNOYED = "annoyed";
    public static final String MOOD_SCARED = "scared";
    public static final String MOOD_APATHETIC = "apathetic";
    public static final String MOOD_COLD = "cold";
    public static final String MOOD_AWAKE = "awake";
    public static final String MOOD_BITCHY = "bitchy";
    public static final String MOOD_BLAH = "blah";
    public static final String MOOD_HAPPY = "happy";
    public static final String MOOD_ANXIOUS = "anxious";
    public static final String MOOD_BORED = "bored";
    public static final String MOOD_BOUNCEY = "bouncey";
    public static final String MOOD_BUSY = "busy";
    public static final String MOOD_TIRED = "tired";
    public static final String MOOD_CONFUSED = "confused";
    public static final String MOOD_CONTEMPLATIVE = "contemplative";
    public static final String MOOD_COOKY = "cooky";
    public static final String MOOD_CRAPPY = "crappy";
    public static final String MOOD_CRAZY = "crazy";
    public static final String MOOD_CURIOUS = "curious";
    public static final String MOOD_DEVIOUS = "devious";
    public static final String MOOD_DRAINED = "drained";
    public static final String MOOD_ELECTRIC = "electric";
    public static final String MOOD_MOODY = "moody";
    public static final String MOOD_EXAMIMATE = "examimate";
    public static final String MOOD_FLIRTY = "flirty";
    public static final String MOOD_FOCUSED = "focused";
    public static final String MOOD_WEIRD = "weird";
    public static final String MOOD_GEEKY = "geeky";
    public static final String MOOD_GLOOMY = "gloomy";
    public static final String MOOD_HORNY = "horny";
    public static final String MOOD_HUNGRY = "hungry";
    public static final String MOOD_INDESCRIBABLE = "indescribable";
    public static final String MOOD_LAZY = "lazy";
    public static final String MOOD_LOVE = "love";
    public static final String MOOD_UNHAPPY = "unhappy";
    public static final String MOOD_SLEEPY = "sleepy";
    public static final String MOOD_HEADPHONES = "headphones";
    public static final String MOOD_VITAL = "vital";


    public static final String[] moodFieldTextList  = {
        MOOD_SPACER, MOOD_CHIPPER, MOOD_ADORED, MOOD_AGGRAVATED, MOOD_KISS, MOOD_AMUSED, MOOD_ANGRY, MOOD_ARTISTIC, MOOD_ANNOYED, MOOD_SCARED,
        MOOD_APATHETIC, MOOD_COLD, MOOD_AWAKE, MOOD_BITCHY, MOOD_BLAH, MOOD_HAPPY, MOOD_ANXIOUS, MOOD_BORED, MOOD_BOUNCEY, MOOD_BUSY,
        MOOD_TIRED, MOOD_CONFUSED, MOOD_CONTEMPLATIVE, MOOD_COOKY, MOOD_CRAPPY, MOOD_CRAZY, MOOD_CURIOUS, MOOD_DEVIOUS, MOOD_DRAINED, MOOD_ELECTRIC,
        MOOD_MOODY, MOOD_EXAMIMATE, MOOD_FLIRTY, MOOD_FOCUSED, MOOD_WEIRD, MOOD_GEEKY, MOOD_GLOOMY, MOOD_HORNY, MOOD_HUNGRY, MOOD_INDESCRIBABLE,
        MOOD_LAZY, MOOD_LOVE, MOOD_UNHAPPY, MOOD_SLEEPY, MOOD_HEADPHONES, MOOD_VITAL
    };

 
    public static int emoticonSet[] = {
        R.drawable.myspace_emoticon_00
       ,R.drawable.myspace_emoticon_01
       ,R.drawable.myspace_emoticon_02
       ,R.drawable.myspace_emoticon_03
       ,R.drawable.myspace_emoticon_04
       ,R.drawable.myspace_emoticon_05
       ,R.drawable.myspace_emoticon_06
       ,R.drawable.myspace_emoticon_07
       ,R.drawable.myspace_emoticon_08
       ,R.drawable.myspace_emoticon_09
       ,R.drawable.myspace_emoticon_10
       ,R.drawable.myspace_emoticon_11
       ,R.drawable.myspace_emoticon_12
       ,R.drawable.myspace_emoticon_13
       ,R.drawable.myspace_emoticon_14
       ,R.drawable.myspace_emoticon_15
       ,R.drawable.myspace_emoticon_16
       ,R.drawable.myspace_emoticon_17
       ,R.drawable.myspace_emoticon_18
       ,R.drawable.myspace_emoticon_19
       ,R.drawable.myspace_emoticon_20
       ,R.drawable.myspace_emoticon_21
       ,R.drawable.myspace_emoticon_22
       ,R.drawable.myspace_emoticon_23
       ,R.drawable.myspace_emoticon_24
       ,R.drawable.myspace_emoticon_25
       ,R.drawable.myspace_emoticon_26
       ,R.drawable.myspace_emoticon_27
       ,R.drawable.myspace_emoticon_28
       ,R.drawable.myspace_emoticon_29
       ,R.drawable.myspace_emoticon_30
       ,R.drawable.myspace_emoticon_31
       ,R.drawable.myspace_emoticon_32
       ,R.drawable.myspace_emoticon_33
       ,R.drawable.myspace_emoticon_34
       ,R.drawable.myspace_emoticon_35
       ,R.drawable.myspace_emoticon_36
       ,R.drawable.myspace_emoticon_37
       ,R.drawable.myspace_emoticon_38
       ,R.drawable.myspace_emoticon_39
       ,R.drawable.myspace_emoticon_40
       ,R.drawable.myspace_emoticon_41
       ,R.drawable.myspace_emoticon_42
       ,R.drawable.myspace_emoticon_43
       ,R.drawable.myspace_emoticon_44
       ,R.drawable.myspace_emoticon_45
  };
    

    public String getMoodFieldText() {
        return moodFieldText;
    }
    public void setMoodFieldText(String moodFieldText) {
        this.moodFieldText = moodFieldText;
    }

    public void setMoodEmoticon(int moodEmoticon) {
        this.moodEmoticon = moodEmoticon;
    }
    public int getMoodEmoticon() {
        return moodEmoticon;
    }

    public String getTextPublished() {
        return textPublished;
    }

    public void setTextPublished(String textPublished) {
        this.textPublished = textPublished;
    }

    public String getTextLike() {
        return textLike;
    }

    public void setTextLike(String textLike) {
        this.textLike = textLike;
    }

    public String getTextComment() {
        return textComment;
    }

    public void setTextComment(String textComment) {
        this.textComment = textComment;
    }
    
    public String getNoti_href() {
        return noti_href;
    }

    public void setNoti_href(String noti_href) {
        this.noti_href = noti_href;
    }    
    
    public String getNoti_type() {
        return noti_type;
    }

    public void setNoti_type(String noti_type) {
        this.noti_type = noti_type;
    }   
    
    public String getNoti_id() {
        return noti_id;
    }

    public void setNoti_id(String noti_id) {
        this.noti_id = noti_id;
    }       

    public void readFromParcel(Parcel in) {
        long value;
        _id=in.readLong();
        setFeedType(in.readString());
        value = in.readLong(); published = (value!=-1L)?new Date(value):null;
        value = in.readLong(); opened = (value!=-1L)?new Date(value):null;
        setFeedId(in.readString());

        setAuthorId(in.readString());
        setContent(in.readString());
        setCategory(in.readString());
        setLikeCnt(in.readInt());
        setCommentCnt(in.readInt());

        setTitle(in.readString());
        setAllowComment(in.readString());
        setIsFriend(in.readInt());
        setFeedAttachmentCnt(in.readInt());
        setWallToWallId(in.readString());
        setCaption(in.readString());
        setOwnerNickName(in.readString());
        setMyLike(in.readInt());
        setCanPostComment(in.readInt());

        // twitter only
        setRepliedTweetId(in.readString());
        setRepliedTweetUserId(in.readString());
        setRepliedTweetUserName(in.readString());
        setSource(in.readString());
        setRetweet(in.readInt());

        // myspace only
        setMoodFieldText(in.readString());
        setMoodEmoticon(in.readInt());

        setTextPublished(in.readString());
        setTextLike(in.readString());
        setTextComment(in.readString());

        // SnsAuthorInfo
        setOwnerId(in.readString());
        setSnsId(in.readString());
        setUserId(in.readString());
        setUserName(in.readString());
        setDisplayName(in.readString());

        setAvatarFile(in.readString());
        setAvatarUrl(in.readString());
        
        in.readTypedList(feedAttachment, FeedAttachment.CREATOR);
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(_id);
        dest.writeString(getFeedType());
        dest.writeLong((published!=null)?published.getTime():-1L);
        dest.writeLong((opened!=null)?opened.getTime():-1L);
        dest.writeString(getFeedId());

        dest.writeString(getAuthorId());
        dest.writeString(getContent());
        dest.writeString(getCategory());
        dest.writeInt(getLikeCnt());
        dest.writeInt(getCommentCnt());

        dest.writeString(getTitle());
        dest.writeString(getAllowComment());
        dest.writeInt(getIsFriend());
        dest.writeInt(getFeedAttachmentCnt());
        dest.writeString(getWallToWallId());
        dest.writeString(getCaption());
        dest.writeString(getOwnerNickName());
        dest.writeInt(getMyLike());
        dest.writeInt(getCanPostComment());

        // twitter only
        dest.writeString(getRepliedTweetId());
        dest.writeString(getRepliedTweetUserId());
        dest.writeString(getRepliedTweetUserName());
        dest.writeString(getSource());
        dest.writeInt(getRetweet());

        // myspace only
        dest.writeString(getMoodFieldText());
        dest.writeInt(getMoodEmoticon());

        dest.writeString(getTextPublished());
        dest.writeString(getTextLike());
        dest.writeString(getTextComment());

        // SnsAuthorInfo
        dest.writeString(getOwnerId());
        dest.writeString(getSnsId());
        dest.writeString(getUserId());
        dest.writeString(getUserName());
        dest.writeString(getDisplayName());

        dest.writeString(getAvatarFile());
        dest.writeString(getAvatarUrl());
        
        dest.writeTypedList(getFeedAttachment());
    }

    public static final Parcelable.Creator<Feed> CREATOR = new Parcelable.Creator<Feed>() {
        public Feed createFromParcel(Parcel in) {
            return new Feed(in);
        }

        public Feed[] newArray(int size) {
            return new Feed[size];
        }
    };



}
