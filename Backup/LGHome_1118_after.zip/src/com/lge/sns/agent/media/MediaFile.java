/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.media;

import java.util.Date;
import java.util.List;

import android.content.ContentUris;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import com.lge.sns.agent.profile.SnsAuthorInfo;

/**
 * ����
 * @author yumin.yang
 *
 */
public class MediaFile extends SnsAuthorInfo implements Parcelable {
    private long   _id;           //MEDIA_FILE._ID  
    private long   _folderId;     //MEDIA_FOLDER._ID
    
    /**
     * �ٹ� id (������ �θ�)
     */
    private String folderId;      //MEDIA_FOLDER.FOLDER_ID
    
    /**
     * Media ����.
     * @see MediaFolder
     */
    private int folderKind;       //MEDIA_FOLDER.FOLDER_KIND
    
    /**
     * ���� id (�ڽ�)
     */
    private String fileId;        //MEDIA_FILE.FILE_ID
    
    /**
     * ������ ����
     */
    private String title;         //MEDIA_FILE.TITLE
    
    /**
     * 
     */
    private String mimeType;      //MEDIA_FILE.MIME_TYPE
    
    /**
     * ū ���� URL
     */
    private String picUrl;        //MEDIA_FILE.PIC_URL        (URL of big image on the web)
    
    /**
     * ���� ���� URL
     */
    private String thumbnailUrl;  //MEDIA_FILE.THUMBNAIL_URL; (URL of small image on the web)
    
    /**
     * ���� ������ ����� local file name
     */
    private String thumbnailFile; //MEDIA_FILE.THUMNBAIL_FILE (Stored file path)
    
    /**
     * ���� �����
     */
    private Date   published;     //MEDIA_FILE.PUBLISHED
    
    /**
     * Ŀ��Ʈ ����
     */
    private int    commentCnt;    //MEDIA_FILE.COMMENT_CNT
    
    /**
     * �±׵� ����
     */
    private boolean    isTaggedMe;   // video of me ����

    /**
     * �±� ���� ����
     */
    private int existTag = 0;  //0: unknown, 1: no tag, 2: exist
    
    public MediaFile() {
        super();
    }
    public MediaFile(String folderId, String fileId) {
        this();
        this.folderId = folderId;
        this.fileId = fileId;
    }
    private List<MediaFileTag> mediaFileTag;
    
    public long get_id() {
        return _id;
    }
    public void set_id(long _id) {
        this._id = _id;
    }
    public long get_folderId() {
        return _folderId;
    }
    public void set_folderId(long _folderId) {
        this._folderId = _folderId;
    }
    public String getFolderId() {
        return folderId;
    }
    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }
    public int getFolderKind() {
        return folderKind;
    }
    public void setFolderKind(int folderKind) {
        this.folderKind = folderKind;
    }
    public String getFileId() {
        return fileId;
    }
    public void setFileId(String fileId) {
        this.fileId = fileId;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getMimeType() {
        return mimeType;
    }
    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }
    public String getPicUrl() {
        return picUrl;
    }
    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }
    public String getThumbnailUrl() {
        return thumbnailUrl;
    }
    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }
    public String getThumbnailFile() {
        return thumbnailFile;
    }
    public void setThumbnailFile(String thumbnailFile) {
        this.thumbnailFile = thumbnailFile;
    }
    public Date getPublished() {
        return published;
    }
    public void setPublished(Date published) {
        this.published = published;
    }
    public int getCommentCnt() {
        return commentCnt;
    }
    public void setCommentCnt(int commentCnt) {
        this.commentCnt = commentCnt;
    }
    public List<MediaFileTag> getMediaFileTag() {
        return mediaFileTag;
    }
    public void setMediaFileTag(List<MediaFileTag> mediaFileTag) {
        this.mediaFileTag = mediaFileTag;
    }
    
    
    // ------------------------------------------------------- additonal methods
    
//  public Uri getUri() {
//      return ContentUris.withAppendedId(MediaFacade.MEDIA_FILE_CONTENT_URI, _id);
//  }
//  
//  public Uri getFolderUri() {
//      return ContentUris.withAppendedId(MediaFacade.MEDIA_FOLDER_CONTENT_URI, _folderId);
//  }
    
    public boolean isTaggedMe() {
        return isTaggedMe;
    }
    public void setTaggedMe(boolean isTaggedMe) {
        this.isTaggedMe = isTaggedMe;
    }
    /**
     * ContentProvider�� Uri
     * @return _id �� ������ null�� ����
     */
    public Uri getUri() {
        if (_id == 0) return null;
        return ContentUris.withAppendedId(Uri.parse("content://com.lge.sns.content.media.provider/mediafile"), _id);
    }
    
    /**
     * ContentProvider�� Uri
     * @return _id �� ������ null�� ����
     */
    public Uri getFolderUri() {
        if (_id == 0) return null;
        return ContentUris.withAppendedId(Uri.parse("content://com.lge.sns.content.media.provider/mediafolder"), _folderId);
    }
    
    // ----------------------------------------------------- Parcelable ���� �߰�
    
    public MediaFile(Parcel in) {
        readFromParcel(in);
    }
    
    private void readFromParcel(Parcel in) {
//      this.setUserName(in.readString());
        this.set_id(in.readLong());
        this.set_folderId(in.readLong());
        this.setFolderId(in.readString());
        this.setFileId(in.readString());
        this.setTitle(in.readString());
        this.setMimeType(in.readString());
        this.setThumbnailFile(in.readString());
        this.setThumbnailUrl(in.readString());
        this.setCommentCnt(in.readInt());
        this.setPicUrl(in.readString());
        this.setOwnerId(in.readString());
        
        long value = in.readLong();
        this.setPublished((value!=-1L)?new Date(value):null);
        
    }
    
    public int describeContents() {
        return 0;
    }
    
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.get_id());
        dest.writeLong(this.get_folderId());
        dest.writeString(this.getFolderId());
        dest.writeString(this.getFileId());
        dest.writeString(this.getTitle());
        dest.writeString(this.getMimeType());
        dest.writeString(this.getThumbnailFile());
        dest.writeString(this.getThumbnailUrl());
        dest.writeInt(this.getCommentCnt());
        dest.writeString(this.getPicUrl());
        dest.writeString(this.getOwnerId());
        
        dest.writeLong(this.getPublished()!= null? this.getPublished().getTime() : -1L);
    }   
    
    public static final Parcelable.Creator<MediaFile> CREATOR = new Parcelable.Creator<MediaFile>() {
        public MediaFile createFromParcel(Parcel in) {
            return new MediaFile(in);
        }

        public MediaFile[] newArray(int size) {
            return new MediaFile[size];
        }
    };
    
    /**
     * ���� ID�� ������ MediaFile ��ü���� Ȯ��(_id, folderId, fileId �� ����)
     */
    public boolean equals(Object o) {
        if (o instanceof MediaFile) {
            MediaFile f = (MediaFile)o;
            return utilEquals(f.folderId, folderId)&& utilEquals(f.fileId, fileId);
        }
        return super.equals(o);
    }
    
    public int hashCode() {
          return 1234567891;  
    }

    public void setExistTag(int existTag) {
        this.existTag = existTag;
    }
    
    public int getExistTag() {
        return existTag;
    }
    
    /**
     * test the two objects are equal or not
     * @param obj1 object 1
     * @param obj2 object 2
     * @return the two objects are equal or not
     */
    public boolean utilEquals(Object obj1,Object obj2) {
        return (obj1==null)?(obj2==null):obj1.equals(obj2);
    }
}
