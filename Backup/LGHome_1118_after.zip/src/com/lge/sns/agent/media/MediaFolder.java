/**
 *   Embedded System Team, LG CNS, SEOUL, KOREA
 *   Copyright(c) by LG Electronics Inc.
 *
 *   All rights reserved. No part of this work may be reproduced, stored in a
 *   retrieval system, or transmitted by any means without prior written
 *   Permission of LG Electronics Inc.
 */
package com.lge.sns.agent.media;

import java.util.Date;

import android.content.ContentUris;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;

import com.lge.sns.agent.profile.SnsAuthorInfo;

/**
 * �ٹ�
 * @author yumin.yang
 *
 */
public class MediaFolder extends SnsAuthorInfo implements Parcelable {
	private long   _id;          //MEDIA_FOLDER._ID
	
	/**
	 * ��������. Default:4
	 * photos of me(0), videos of me(1), videos(2), profile(3), mobile(4), etc(5).
	 */
	private int folderKind = 5;		//MEDIA_FOLDER.FOLDER_KIND
	
	/**
	 * �ٹ� id
	 */
	private String folderId;     //MEDIA_FOLDER.FOLDER_ID
	
	/**
	 * �ٹ� �̸�
	 */
	private String folderName;   //MEDIA_FOLDER.FOLDER_NAME
	
	/**
	 * ��ǥ ���� id
	 */
	private String coverFileId;  //MEDIA_FILE.FILE_ID   (must check what it reference)
	

	/**
	 * ��ǥ ���� url
	 */
	private String coverFileUrl; //MEDIA_FOLDER.COVER_FILE_URL
	
	/**
	 * �ٹ� �� ���� ����
	 */
	private int    fileCnt;      //MEDIA_FOLDER.FILE_CNT
	
	/**
	 * �ٹ� ������
	 */
	private Date   published;    //MEDIA_FOLDER.PUBLISHED   
	
    /**
     * Published data string for display
     */
    private String textPublished; // requested by mmd777 2010.7.23.
    
    private Uri    coverFileUri;      // content://com.lge.sns.content.media.provider/?thumbnailUrl=###
	
    public MediaFolder() {
		super();
	}
	
	public MediaFolder(String snsId, String userId, String ownerId, String folderId) {
		this();
		super.setSnsId(snsId);
		super.setUserId(userId);
		super.setOwnerId(ownerId);
		this.setFolderId(folderId);
	}

	public long get_id() {
		return _id;
	}
	public void set_id(long _id) {
		this._id = _id;
	}
	public String getFolderId() {
		return folderId;
	}
	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}
	public String getFolderName() {
		return folderName;
	}
	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}
	public String getCoverFileId() {
		return coverFileId;
	}
	public void setCoverFileId(String coverFileId) {
		this.coverFileId = coverFileId;
	}
	public int getFileCnt() {
		return fileCnt;
	}
	public void setFileCnt(int fileCnt) {
		this.fileCnt = fileCnt;
	}
	public Date getPublished() {
		return published;
	}
	public void setPublished(Date published) {
		this.published = published;
	}
	public String getCoverFileUrl() {
		return coverFileUrl;
	}
	public void setCoverFileUrl(String coverFileUrl) {
		this.coverFileUrl = coverFileUrl;
	}
	public int getFolderKind() {
		return folderKind;
	}
	public void setFolderKind(int folderKind) {
		this.folderKind = folderKind;
	}
	
    public String getTextPublished() {
        return textPublished;
    }

    public void setTextPublished(String textPublished) {
        this.textPublished = textPublished;
    }

	public boolean equals(Object obj) {
		if (folderId == null) return false;
		
		if (obj instanceof MediaFolder) {
			MediaFolder mediaFolder = (MediaFolder)obj;
			return (mediaFolder.getFolderId().equals(folderId));
		}
		return super.equals(obj);
	}

	/**
	 * ContentProvider�� Uri
	 * @return _id �� ������ null�� ����
	 */
	public Uri getUri() {
		if (_id == 0) return null;
		return ContentUris.withAppendedId(Uri.parse("content://com.lge.sns.content.media.provider/mediafolder"), _id);
	}
	
    public Uri getCoverFileUri() {
        if (coverFileUri == null && coverFileUrl != null) {
        	coverFileUri = Uri.parse("content://com.lge.sns.content.media.provider/?thumbnailUrl=" + coverFileUrl);
        }
        return coverFileUri;
    }
	
	// ----------------------------------------------------- Parcelable ���� �߰�
	
	public int describeContents() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(this.getSnsId());
		dest.writeString(this.getUserId());
		dest.writeString(this.getFolderId());
		dest.writeString(this.getFolderName());
		dest.writeString(this.getCoverFileId());
		dest.writeString(this.getCoverFileUrl());
		dest.writeInt(this.getFileCnt());
		
		dest.writeLong(this.getPublished()!= null? this.getPublished().getTime() : -1L);
		dest.writeLong(this.get_id());
	}
	
	public MediaFolder(Parcel in) {
		readFromParcel(in);
	}
	
	private void readFromParcel(Parcel in) {
		this.setSnsId(in.readString());
		this.setUserId(in.readString());
		this.setFolderId(in.readString());
		this.setFolderName(in.readString());
		this.setCoverFileId(in.readString());
		this.setCoverFileUrl(in.readString());
		this.setFileCnt(in.readInt());
		
		long value = in.readLong();
		this.setPublished((value!=-1L)?new Date(value):null);	
		
		this.set_id(in.readLong());
	}
	
    public static final Parcelable.Creator<MediaFolder> CREATOR = new Parcelable.Creator<MediaFolder>() {
        public MediaFolder createFromParcel(Parcel in) {
            return new MediaFolder(in);
        }

        public MediaFolder[] newArray(int size) {
            return new MediaFolder[size];
        }
    };
}
