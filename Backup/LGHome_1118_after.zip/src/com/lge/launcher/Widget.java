/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;


/**
 * Represents one instance of a Launcher widget, such as search.
 */
class Widget extends ItemInfo {
    
    int layoutResource;

    //2010.10.01 sunghwa.woo@lge.com SNS widget start
    static Widget makeSNS() {
        Widget w = new Widget();
        w.itemType = com.lge.sns.SNSBridge.ITEM_TYPE_SNS_FEED_WIDGET;
        w.spanX = com.lge.sns.SNSBridge.SPAN_X;
        w.spanY = com.lge.sns.SNSBridge.SPAN_Y;
        w.cellX = 0;
        w.cellY = 0;
        w.layoutResource = R.layout.sns_feed_widget;
        return w;
    }    
    //2010.10.01 sunghwa.woo@lge.com SNS widget start
}
