package com.lge.launcher;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;


//START yoori.yoo 20100902 
public class TestShortcut extends Activity {
	private String[] mListString = new String[] { " A", " B" };
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		
		requestWindowFeature(Window.FEATURE_LEFT_ICON);
		setContentView(R.layout.test_shortcut_background);
		getWindow().setFeatureDrawableResource(Window.FEATURE_LEFT_ICON,
				R.drawable.ic_dialog_menu_generic);
		setTitleColor(Color.WHITE);
		
		final ListView mList = (ListView) findViewById(android.R.id.list);		
		setTitle(getString(R.string.home_settings_menu_home_number));
		mList.setAdapter(new ArrayAdapter<String>(this,
					android.R.layout.simple_list_item_single_choice, mListString));
		mList.setItemChecked(0, true);	
		/* mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				if (position == 0) {
					mList.setItemChecked(0, true);
				} else if (position == 1) {
					mList.setItemChecked(0, true);
				}
			}
		}); */
	}
}
//END yoori.yoo 20100902