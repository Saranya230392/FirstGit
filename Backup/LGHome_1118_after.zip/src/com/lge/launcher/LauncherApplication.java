/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import android.app.Application;
import dalvik.system.VMRuntime;

// START yoori.yoo 20100916 : VS660 Merge for SD Card Issue
import android.content.ContentResolver;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.ContentObserver;
import android.os.Handler;
import android.util.*;
// END yoori.yoo 20100916

public class LauncherApplication extends Application {
// START yoori.yoo 20100916 : VS660 Merge for SD Card Issue
	public LauncherModel mModel;
    public Launcher mLauncher;
// END yoori.yoo 20100916

    @Override
    public void onCreate() {
        VMRuntime.getRuntime().setMinimumHeapSize(4 * 1024 * 1024);

        super.onCreate();

// START yoori.yoo 20100916 : VS660 Merge for SD Card Issue
        mModel = new LauncherModel();

        IntentFilter filter = new IntentFilter(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addAction(Intent.ACTION_PACKAGE_CHANGED);
        filter.addDataScheme("package");
        registerReceiver(mModel, filter);
        filter = new IntentFilter();
        filter.addAction(Intent.ACTION_EXTERNAL_APPLICATIONS_AVAILABLE);
        filter.addAction(Intent.ACTION_EXTERNAL_APPLICATIONS_UNAVAILABLE);
        registerReceiver(mModel, filter);

        ContentResolver resolver = getContentResolver();
        resolver.registerContentObserver(LauncherSettings.Favorites.CONTENT_URI, true, mFavoritesObserver);
// END yoori.yoo 20100916
    }

// START yoori.yoo 20100916 : VS660 Merge for SD Card Issue
    @Override
    public void onTerminate() {
        super.onTerminate();

        //unregisterReceiver(mModel);

        ContentResolver resolver = getContentResolver();
        resolver.unregisterContentObserver(mFavoritesObserver);
    }

    private final ContentObserver mFavoritesObserver = new ContentObserver(new Handler()) {
        @Override
        public void onChange(boolean selfChange) {

        }
    };

    LauncherModel setLauncher(Launcher launcher) {
    	mLauncher = launcher;
        return mModel;
    }
    
    Launcher getLauncher() {
    	return mLauncher;
    }
// END yoori.yoo 20100916
}
