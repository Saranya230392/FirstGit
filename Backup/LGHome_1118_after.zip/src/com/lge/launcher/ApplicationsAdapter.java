/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import java.util.ArrayList;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * GridView adapter to show the list of applications and shortcuts
 */
public class ApplicationsAdapter extends ArrayAdapter<ApplicationInfo> {
    private final LayoutInflater mInflater;
    
// START yoori.yoo 20100909 : VS660 Merge for VVM Icon Update 
    private final String VVM_CLASSNAME = "com.lge.vvm.authmanager.VvmAuthManagerActivity";
// END yoori.yoo 20100909 

    public ApplicationsAdapter(Context context, ArrayList<ApplicationInfo> apps) {
        super(context, 0, apps);
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final ApplicationInfo info = getItem(position);
        
        // BEGIN: 0002231 deukmo@lge.com 2009-12-23
	    // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        if(parent instanceof AllAppsGridView) {
    		convertView = mInflater.inflate(R.layout.application_boxed_for_allapps, parent, false);
    		convertView.setOnTouchListener((View.OnTouchListener) parent);
// START yoori.yoo 20100909 : VS660 Merge for VVM Icon Update 
    		if(info.intent.getComponent().getClassName().equalsIgnoreCase(VVM_CLASSNAME)) {
    			((MenuTextView) convertView).setAppClassName(info.intent.getComponent().getClassName());
    		}
// END yoori.yoo 20100909 
    		((MenuTextView) convertView).setSystemApp(info.isSystemApplication);
    	} else {
    		convertView = mInflater.inflate(R.layout.application_boxed, parent, false);
    	}
    	// END: 0002231 deukmo@lge.com 2009-12-23

        if (!info.filtered) {
            info.icon = Utilities.createIconThumbnail(info.icon, getContext());
            info.filtered = true;
        }

        final TextView textView = (TextView) convertView;
        textView.setCompoundDrawablesWithIntrinsicBounds(null, info.icon, null, null);
        textView.setText(info.title);

        return convertView;
    }
}
