/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import java.net.URISyntaxException;
// import java.util.Iterator;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
// import android.os.Bundle;
// import android.provider.ContactsContract.Contacts;
import android.widget.Toast;

public class UninstallShortcutReceiver extends BroadcastReceiver {
/*
// START LG_UI_HOME yoori.yoo 20100815
// update shortcuts
	private static final String ACTION_UNINSTALL_SHORTCUT =
            "com.android.launcher.action.UNINSTALL_SHORTCUT";
	private static final String ACTION_UNINSTALL_SHORTCUT_MULTI =
			"com.android.launcher.action.UNINSTALL_SHORTCUT_MULTI";
	private static String receivedAction;
	
	public void onReceive(final Context context, final Intent data) {
		receivedAction = data.getAction();
		
		if (!ACTION_UNINSTALL_SHORTCUT.equals(receivedAction)
			&& !ACTION_UNINSTALL_SHORTCUT_MULTI.equals(receivedAction)) { 
			return;
		}
		
		Thread t = new Thread() {
			public void run() {
				uninstallShortcut(context, data);
            }
		 };
		 t.start();
	}
	
	private String findContactIdFromLauncherIntent(String launcherIntent, boolean isContactShortcut) {
		int idStartPos = 0, idEndPos = 0;
		
		if(isContactShortcut) {
			for(int i = 0; i < 6; i++) {
				idStartPos = launcherIntent.indexOf('/', idStartPos);
				idStartPos++;
			}
			idEndPos = launcherIntent.indexOf('#');
			if(idStartPos == -1 || idEndPos == -1)
				return null;
		} /* in case of direct dial or direct message */
/*		else {
			idStartPos = launcherIntent.indexOf("_id=");
			idEndPos = launcherIntent.indexOf(";end");
			
			if(idStartPos != -1 && idEndPos != -1)
				idStartPos += 4;
			else 
				return null;
		}

		if(idStartPos <= idEndPos) {
			return launcherIntent.substring(idStartPos, idEndPos);
		} else
			return null;
	}

	private boolean compareContactIdAndDeleteFromDB(Context context, 
		String launcherId, String launcherIntent, String contactId) {
		String idOfIntentColumn = null;
		
		/* in case of contact shortcut */
/*		if(launcherIntent.indexOf(Contacts.CONTENT_URI.toString()) != -1) {
			idOfIntentColumn = findContactIdFromLauncherIntent(launcherIntent, true);
		} /* in case of direct dial or direct message */
/*		else if((launcherIntent.indexOf("tel") != -1
				&& launcherIntent.indexOf(Intent.ACTION_CALL) != -1) || 
				(launcherIntent.indexOf("smsto") != -1
						&& launcherIntent.indexOf(Intent.ACTION_SENDTO) != -1)) {
			idOfIntentColumn = findContactIdFromLauncherIntent(launcherIntent, false);
		}

		if(idOfIntentColumn != null && idOfIntentColumn.equals(contactId)) {
			String updateWhere = LauncherSettings.Favorites._ID + "=" + launcherId;
			context.getContentResolver().delete(LauncherSettings.Favorites.CONTENT_URI, updateWhere, null);
			return true;
		}
		return false;
	}
		
	private boolean uninstallShortcut(Context context, Intent data) {
		String contactId = null;
		boolean deleteCompleted = false;
		
		if(ACTION_UNINSTALL_SHORTCUT.equals(receivedAction)) {
			contactId = data.getStringExtra("Contact_ID");
			if(contactId == null || contactId.length() <= 0)
					return deleteCompleted;
		}
						
		Cursor launcherCursor = context.getContentResolver().query(LauncherSettings.Favorites.CONTENT_URI,
				new String[]{LauncherSettings.BaseLauncherColumns.INTENT,
				LauncherSettings.Favorites._ID,
				LauncherSettings.Favorites.TITLE}, null, null, null);
		int launcherIntentIndex = launcherCursor.getColumnIndexOrThrow(LauncherSettings.BaseLauncherColumns.INTENT);
		int launcherIdIndex = launcherCursor.getColumnIndexOrThrow(LauncherSettings.Favorites._ID);
		// int launcherTitleIndex = launcherCursor.getColumnIndexOrThrow(LauncherSettings.Favorites.TITLE);
		
		if(launcherCursor == null || launcherIntentIndex == -1
			|| launcherIdIndex == -1) {
			if(launcherCursor != null)
				launcherCursor.close();
			return deleteCompleted;
		}
		
		if(launcherCursor.moveToFirst()) {
			do {
				String launcherIntent = launcherCursor.getString(launcherIntentIndex);
				String launcherId = launcherCursor.getString(launcherIdIndex);

				if(launcherId != null && launcherIntent != null) {
					if(ACTION_UNINSTALL_SHORTCUT.equals(receivedAction)) {					
						deleteCompleted = compareContactIdAndDeleteFromDB(context,
											launcherId, launcherIntent, contactId);
					} else {/* ACTION_UNINSTALL_SHORTCUT_MULTI */
/*						Bundle contactIdData = data.getBundleExtra("Contact_ID");

						if(contactIdData != null && !contactIdData.isEmpty()) {
							Iterator<String> it = contactIdData.keySet().iterator();
                        
							while (it.hasNext()) {
                            	String key = it.next();
                            	contactId = contactIdData.getString(key);
								if(contactId != null && contactId.length() > 0) {
									deleteCompleted = compareContactIdAndDeleteFromDB(context,
														launcherId, launcherIntent, contactId);
								}
                       		}
						}
					}
				}				
			} while (launcherCursor.moveToNext());
		}

		launcherCursor.close();
		return deleteCompleted;
	} 
// END LG_UI_HOME yoori.yoo 20100815 
*/
    // BEGIN: 0002723 taesu84.kim@lge.com 2009-12-22
    // MOD 0002723: [Swift][Launcher] Add bookmark as shortcut to HomeScreen from Browser
    private static final String ACTION_UNINSTALL_SHORTCUT =
            "com.android.launcher.action.UNINSTALL_SHORTCUT";
    // END: 0002723 taesu84.kim@lge.com 2009-12-22        

    public void onReceive(Context context, Intent data) {
        if (!ACTION_UNINSTALL_SHORTCUT.equals(data.getAction())) {
            return;
        }

        Intent intent = data.getParcelableExtra(Intent.EXTRA_SHORTCUT_INTENT);
        String name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME);
        boolean duplicate = data.getBooleanExtra(Launcher.EXTRA_SHORTCUT_DUPLICATE, true);

        if (intent != null && name != null) {
            final ContentResolver cr = context.getContentResolver();
            Cursor c = cr.query(LauncherSettings.Favorites.CONTENT_URI,
                new String[] { LauncherSettings.Favorites._ID, LauncherSettings.Favorites.INTENT },
                LauncherSettings.Favorites.TITLE + "=?", new String[] { name }, null);

            final int intentIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites.INTENT);
            final int idIndex = c.getColumnIndexOrThrow(LauncherSettings.Favorites._ID);

            boolean changed = false;

            try {
            	if(c != null) {
            		while (c.moveToNext()) {
            			try {
            				if (intent.filterEquals(Intent.parseUri(c.getString(intentIndex), 0))) {
            					final long id = c.getLong(idIndex);
            					final Uri uri = LauncherSettings.Favorites.getContentUri(id, false);
            					cr.delete(uri, null, null);
            					changed = true;
            					if (!duplicate) {
            						break;
            					}
            				}
            			} catch (URISyntaxException e) {
            				// Ignore
            			}
            		}
            	}
            } finally {
            	if(c != null) {
            		c.close();
            	}
            }

            if (changed) {
                cr.notifyChange(LauncherSettings.Favorites.CONTENT_URI, null);
                Toast.makeText(context, context.getString(R.string.shortcut_uninstalled, name),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}
