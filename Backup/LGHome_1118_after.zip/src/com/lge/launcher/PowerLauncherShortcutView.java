/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import android.content.Context;
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
import android.graphics.Bitmap;				// added
import android.graphics.Canvas;
import android.graphics.PixelFormat;			// added
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;	// added
import android.graphics.drawable.PaintDrawable;		// added
// END LG_UI_HOME yoori.yoo 20100530 

// START yoori.yoo 20100830 : VVM Icon Update 
import android.graphics.drawable.Drawable;
// END yoori.yoo 20100830 

import android.util.AttributeSet;
// START yoori.yoo 20100922 : Internal Idle Focus
import android.view.KeyEvent;
// END yoori.yoo 20100922
import android.view.View;
import android.widget.ImageView;
import android.util.Log;

public class PowerLauncherShortcutView extends ImageView implements View.OnClickListener, DropTarget {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
	// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
	private static final int SHORTCUT_SIZE_X = 72;
	private static final int SHORTCUT_SIZE_Y = 72;
	// END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
	
// START yoori.yoo 20100922 : Internal Idle Focus
	private static final int ORIENTATION_HORIZONTAL = 1;
	private int mOrientation = ORIENTATION_HORIZONTAL;
// END yoori.yoo 20100922
	
	private Launcher mLauncher;
	private ApplicationInfo mApplicationInfo;
	
// START yoori.yoo 20100830 : VVM Icon Update 
	private String mPackageName ;	
    private String mClassName ;	
    private String mNumtoString ;
    private final String VVM_CLASSNAME = "com.lge.vvm.authmanager.VvmAuthManagerActivity";
// END yoori.yoo 20100830 
		
    public PowerLauncherShortcutView(Context context) {
        super(context);
        init(context);
    }

    public PowerLauncherShortcutView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public PowerLauncherShortcutView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }
    
    private void init(Context context) {
    	if(context instanceof Launcher) {
    		mLauncher = (Launcher) context;
    	}
    	
    	setOnClickListener(this);
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
// START yoori.yoo 20100830 : VVM Icon Update 
        if (mApplicationInfo == null || mApplicationInfo.intent.getComponent() == null)
 			return;

		int numinfo=0;
		String className = mApplicationInfo.intent.getComponent().getClassName();
		
		if(className.equals(VVM_CLASSNAME)) {
			numinfo = mLauncher.getVvmUpdateNum();
		}
			
		DrawAllInfo(canvas ,numinfo , mScrollX , mScrollX);
// END yoori.yoo 20100830 
    }

	public void onClick(View v) {
		final ApplicationInfo info = mApplicationInfo;
		Log.d("test","PowerLauncher click!!!");
		if(mLauncher!=null && info!=null) {
			mLauncher.startActivitySafely(info.intent);
		}
	}
	
	ApplicationInfo getApplicationInfo() {
		return mApplicationInfo;
	}
	
	void setApplicationInfo(ApplicationInfo info) {
		mApplicationInfo = info;
		if(info!=null) {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
			// setImageDrawable(info.icon);
			// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
			// MOD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
			Bitmap result;
			if(info.icon instanceof BitmapDrawable) {
				result = Bitmap.createScaledBitmap(((BitmapDrawable) info.icon).getBitmap(), SHORTCUT_SIZE_X, SHORTCUT_SIZE_Y, true);
			} else {
				final Bitmap.Config c = info.icon.getOpacity() != PixelFormat.OPAQUE ?
	                    Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565;
				final Bitmap thumb = Bitmap.createBitmap(info.icon.getIntrinsicWidth(), info.icon.getIntrinsicHeight(), c);
				final Canvas canvas = new Canvas(thumb);
				info.icon.draw(canvas);
				result = Bitmap.createScaledBitmap(thumb, SHORTCUT_SIZE_X, SHORTCUT_SIZE_Y, true);
			}
            setImageDrawable(new FastBitmapDrawable(result));
            // END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
		} else {
			setImageDrawable(null);
		}
	}

	public boolean acceptDrop(DragSource source, int x, int y, int xOffset,
			int yOffset, Object dragInfo) {
		return true;
	}

	public Rect estimateDropLocation(DragSource source, int x, int y,
			int xOffset, int yOffset, Object dragInfo, Rect recycle) {
		return null;
	}

	public void onDragEnter(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
	}

	public void onDragExit(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// setBackgroundColor(0xFF);//added by hwang072 for Vs740 2010-02-02
// END LG_UI_HOME yoori.yoo 20100530 
	}

	public void onDragOver(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// setBackgroundDrawable(getResources().getDrawable(R.drawable.selector));//added by hwang072 for Vs740 2010-02-02
// END LG_UI_HOME yoori.yoo 20100530 
	}

	public void onDrop(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
		final Launcher launcher = mLauncher;
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// Log.d("test","onDrop");
		
		if(launcher!=null && mLauncher.isInstaceOfTopmenu) {	//modfied by kumjoo.hwang for C710 2010-06-03
			// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
			// MOD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
			if(dragInfo instanceof ApplicationInfo) {
				// mApplicationInfo = (ApplicationInfo) dragInfo;
				// setImageDrawable(((ApplicationInfo) dragInfo).icon);
				setApplicationInfo((ApplicationInfo) dragInfo);
			} else if(dragInfo instanceof View) {
				final View dropSource = (View) dragInfo;
				final AllAppsGridView sourceGridView = (AllAppsGridView) dropSource.getParent();
				final ApplicationsAdapter sourceAdapter = (ApplicationsAdapter) sourceGridView.getAdapter();
				final ApplicationInfo applicationInfo = (ApplicationInfo) sourceAdapter.getItem(sourceGridView.getPositionForView(dropSource));
				
				// mApplicationInfo = (ApplicationInfo) applicationInfo;
				// setImageDrawable(applicationInfo.icon);
				setApplicationInfo(applicationInfo);
			}
			// END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
			
			launcher.savePowerLauncherShortcut();
		}
	}
	
// START yoori.yoo 20100830 : VVM Icon Update 
	public void DrawAllInfo (Canvas canvas, int numinfo , int scrollX , int scrollY) {
		if ( numinfo == 0 )
 			return;

// START yoori.yoo 20100930
		final int scrollX_BG;
				
		if(mLauncher.getOrientationstate()) {
			scrollX_BG = numinfo < 100 ? 60: 45;
		} else {
			scrollX_BG = numinfo < 100 ? 68: 53;
		}
// END yoori.yoo 20100930

		final int scrollX_num1of1 = scrollX_BG + 9;
		final int scrollX_num1of2 = scrollX_BG + 5;
		final int scrollX_num2of2 = scrollX_BG + 13;
		final int scrollX_num1of3 = scrollX_BG + 7;
		final int scrollX_num2of3 = scrollX_BG + 17;
		final int scrollX_num3of3 = scrollX_BG + 27;
		final int scrollY_BG = 0;
		final int scrollY_num = getPaddingTop() + 5;

    	Drawable NumCountBG = null;
    	Drawable Num1st = null;
    	Drawable Num2nd = null;
    	Drawable Num3rd = null;

		if (numinfo > 999)
			numinfo = 999;

		if (numinfo > 0 && numinfo < 100) {
	        NumCountBG = getContext().getResources().getDrawable(R.drawable.count_info_bg);//count_info_bg
		} else {
			NumCountBG = getContext().getResources().getDrawable(R.drawable.count_info_bg_w);//count_info_bg_w
		}

		//NumCountBG.setCallback(this);
		canvas.translate(scrollX+scrollX_BG ,getPaddingTop()+scrollY_BG);
		NumCountBG.setBounds(0, 0, NumCountBG.getIntrinsicWidth(), NumCountBG.getIntrinsicHeight()); 
		NumCountBG.draw(canvas); 
		canvas.translate(-(scrollX+scrollX_BG), -(getPaddingTop()+scrollY_BG));
		
		mNumtoString = String.valueOf(numinfo);

		if ( numinfo > 0 && numinfo < 10) // 1
		{
			DrawNumber(	canvas , Num1st , 0 , scrollX , scrollY , scrollX_num1of1 , scrollY_num);		
		} 
		else if ( numinfo >=10 && numinfo<100 )// 2 
		{
			DrawNumber(	canvas , Num1st , 0 , scrollX , scrollY , scrollX_num1of2 , scrollY_num);		
			DrawNumber(	canvas , Num2nd , 1 , scrollX , scrollY , scrollX_num2of2 , scrollY_num);		
		}
		else // 3
		{
			DrawNumber(	canvas , Num1st , 0, scrollX , scrollY , scrollX_num1of3 , scrollY_num);		
			DrawNumber(	canvas , Num2nd , 1, scrollX , scrollY , scrollX_num2of3 , scrollY_num);		
			DrawNumber(	canvas , Num3rd , 2, scrollX , scrollY , scrollX_num3of3 , scrollY_num);		
		}
	}

	public void DrawNumber(Canvas canvas, Drawable Num ,int loc, int scrollX , int scrollY ,int Xoffset , int Yoffset) {
		char str = mNumtoString.charAt(loc);
	
		switch (str) {
			case '0':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num0);
				break;
			case '1':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num1);
				break;
			case '2':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num2);
				break;
			case '3':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num3);
				break;
			case '4':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num4);
				break;
			case '5':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num5);
				break;
			case '6':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num6);
				break;
			case '7':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num7);
				break;
			case '8':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num8);
				break;
			case '9':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num9);
				break;
			default :	
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num0);
				break;
		}
		canvas.translate(scrollX+Xoffset ,scrollY+Yoffset);
		Num.setBounds(0, 0, Num.getIntrinsicWidth(), Num.getIntrinsicHeight()); 
		Num.draw(canvas); 
		canvas.translate(-(scrollX+Xoffset), -(scrollY+Yoffset));	
	}
// END LG_UI_HOME yoori.yoo 20100530 
	
// START yoori.yoo 20100922 : Internal Idle Focus
	@Override
    public View focusSearch(int direction) {
        View newFocus = super.focusSearch(direction);
        if (newFocus == null && mLauncher.isDrawerDown()) {
            final Workspace workspace = mLauncher.getWorkspace();
            workspace.dispatchUnhandledMove(null, direction);
            return (mOrientation == ORIENTATION_HORIZONTAL && direction == FOCUS_DOWN) ?
                    this : workspace;
        }
        return newFocus;
    }

    @Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
    	 final boolean handled = super.onKeyDown(keyCode, event);

         if (!handled && !isDirectionKey(keyCode)) {
             return mLauncher.onKeyDown(keyCode, event);
         }
 			
         return handled;
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		final boolean handled = super.onKeyUp(keyCode, event);

        if (!handled && !isDirectionKey(keyCode)) {
            return mLauncher.onKeyUp(keyCode, event);
        }

        return handled;
	}
    
    private static boolean isDirectionKey(int keyCode) {
        return keyCode == KeyEvent.KEYCODE_DPAD_DOWN || keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
                keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || keyCode == KeyEvent.KEYCODE_DPAD_UP;
    }
// END yoori.yoo 20100922
}
