package com.lge.launcher;

// START LG_UI_HOME yoori.yoo 20100802 VS660(0802) merge
// import java.io.IOException;
// import java.io.InputStream;

import android.app.Activity;
// import android.content.Context;
// import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
// import android.provider.Settings;
// import android.view.LayoutInflater;
import android.view.View;
// import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
// import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
// import android.widget.TextView;
// END LG_UI_HOME yoori.yoo 20100802

public class Andy_RadioImageListDialog_Activity extends Activity {
// START LG_UI_HOME yoori.yoo 20100802 VS660(0802) merge
	// private static String ACTION_THEME_CHANGED = "com.lge.action.ThemeChanged";
	// private static String EXTRA_THEME_TYPE = "ThemeType";
	// BEGIN: 0003287 taesu84.kim@lge.com 2010-01-14
	// ADD 0003287: [Swift][Launcher] change theme information
	// private static String EXTRA_PRE_THEME_TYPE = "PreThemeType";
	// END: 0003287 taesu84.kim@lge.com 2010-01-14
	// BEGIN: 0004467 deukmo.koo@lge.com 2010-02-27
	// MOD 0004467: [Swift][LGHome] Change the algorithm of selecting home number in LG Home
	private static String[] mHomeNumberString = new String[] { " 5", " 7" };
	// END: 0004467 deukmo.koo@lge.com 2010-02-27
	
	// BEGIN: 0002960 taesu84.kim@lge.com 2010-01-02
	// MOD 0002960: [Swift][Launcher] modify the number of default screen & theme title
	// BEGIN: 0004707 deukmo.koo@lge.com 2010-03-08
	// MOD 0004707: [Swift][LGHome] Set default theme for operator
	/* private static String[] mHomeThemeList = new String[] {
			"default", "black", "pink",
			"silver", "white", "appet"
	};
	private static int[] mHomeThemeName = new int[] {
			R.string.theme_default,
			R.string.theme_black,  
			R.string.theme_pink,
			R.string.theme_silver,
			R.string.theme_white,
			R.string.theme_appet
	};
	private static int[] mHomeThemeIcons = {
			R.drawable.ic_launcher_gallery,
			R.drawable.ic_launcher_gallery,
			R.drawable.ic_launcher_gallery,
			R.drawable.ic_launcher_gallery,
			R.drawable.ic_launcher_gallery,
			R.drawable.ic_launcher_gallery
	};
	private static int[] mHomeThemeWallpaper = new int[] {
			R.drawable.wallpaper_lg_sunrise,
			R.drawable.black_background,
			R.drawable.pink_background,
			R.drawable.silver_background,
			R.drawable.white_background,
			R.drawable.wallpaper_star
	}; */
	static String[] mHomeThemeList;
	/* private static int[] mHomeThemeName;
	private static int[] mHomeThemeIcons;
	private static int[] mHomeThemeWallpaper; */
// END LG_UI_HOME yoori.yoo 20100802 
		
	static {
	/*	final String opCode = Settings.FlexInfo_Operator.getOperatorCode();
    	if(opCode.equals("TSR")) {
    		mHomeThemeList = new String[] {
    				"com.lge.launcher.Default",
					"com.lge.launcher.Black", "com.lge.launcher.Pink",
					"com.lge.launcher.Rainy", "com.lge.launcher.White"	};
			mHomeThemeName = new int[] {
					R.string.theme_tsr,
					R.string.theme_black,  
					R.string.theme_pink,
					R.string.theme_silver,
					R.string.theme_white
			};
			// BEGIN: 0003320 taesu84.kim@lge.com 2010-01-15
			// MOD 0003320: [Swift][Launcher] add homeTheme icon images
			mHomeThemeIcons = new int[] {
					R.drawable.ic_theme_tsr,
					R.drawable.blackcoffee,
					R.drawable.pinkcoco,
					R.drawable.rainyday,
					R.drawable.whitewave
			};
			// END: 0003320 taesu84.kim@lge.com 2010-01-15
			mHomeThemeWallpaper = new int[] {
					R.drawable.default_wallpaper,
					R.drawable.black_background,
					R.drawable.pink_background,
					R.drawable.silver_background,
					R.drawable.white_background
			};
    	} else {*/
// START LG_UI_HOME yoori.yoo 20100802 VS660(0802) merge
			/* mHomeThemeList = new String[] {
					"com.lge.launcher.Black", "com.lge.launcher.Pink",
					"com.lge.launcher.Rainy", "com.lge.launcher.White"	};
			mHomeThemeName = new int[] {
					R.string.theme_black,  
					R.string.theme_pink,
					R.string.theme_silver,
					R.string.theme_white
			};
			// BEGIN: 0003320 taesu84.kim@lge.com 2010-01-15
			// MOD 0003320: [Swift][Launcher] add homeTheme icon images
			mHomeThemeIcons = new int[] {
					R.drawable.blackcoffee,
					R.drawable.pinkcoco,
					R.drawable.rainyday,
					R.drawable.whitewave
			};
			// END: 0003320 taesu84.kim@lge.com 2010-01-15
			mHomeThemeWallpaper = new int[] {
					R.drawable.black_background,
					R.drawable.pink_background,
					R.drawable.silver_background,
					R.drawable.white_background
			}; */
// END LG_UI_HOME yoori.yoo 20100802 
	//	}
	}
	// END: 0004707 deukmo.koo@lge.com 2010-03-08
	
// START LG_UI_HOME yoori.yoo 20100802 VS660(0802) merge
	// private LayoutInflater mInflater;
	
	// private boolean[] checked = new boolean[mHomeThemeList.length];
// END LG_UI_HOME yoori.yoo 20100802 
	// END: 0002960 taesu84.kim@lge.com 2010-01-02
	
	// BEGIN: 0002822 taesu84.kim@lge.com 2009-12-28
	// MOD 0002822: [Swift][Launcher] home indicator bar is synchronized with home screen when it is rebooted & dialog errors in home settings
	private int mHomeNumber;
	// END: 0002822 taesu84.kim@lge.com 2009-12-28
	
	// BEGIN: 0002909 taesu84.kim@lge.com 2009-12-31
	// ADD 0002909: [Swift][Launcher] add theme title & Wallpaper change as change theme
// START LG_UI_HOME yoori.yoo 20100802 VS660(0802) merge
	// private static String mHomeTheme;
	// private static String mPreHomeTheme;
// END LG_UI_HOME yoori.yoo 20100802 
	// END: 0002909 taesu84.kim@lge.com 2009-12-31
	
// START LG_UI_HOME yoori.yoo 20100804
// maintain insertImage when folder opened
	private Integer insertImageNum;
	private Integer restore_insertImageNum;
// END LG_UI_HOME yoori.yoo 20100804
	
	@Override   
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
// START LG_UI_HOME yoori.yoo 20100804
// maintain insertImage when folder opened
		if(getLastNonConfigurationInstance() != null){
        	restore_insertImageNum = (Integer)getLastNonConfigurationInstance();
        }
// END LG_UI_HOME yoori.yoo 20100804
		
		requestWindowFeature(Window.FEATURE_LEFT_ICON);
		setContentView(R.layout.andy_radioimagelistdialog_activity_background);
		getWindow().setFeatureDrawableResource(Window.FEATURE_LEFT_ICON,
				R.drawable.ic_dialog_menu_generic);
		setTitleColor(Color.WHITE);
		
		final ListView mList = (ListView) findViewById(android.R.id.list);		
		final Button okBtn = (Button) findViewById(R.id.Button01);
		final Button cancelBtn = (Button) findViewById(R.id.Button02);
		final ImageView listInsertImage = (ImageView) findViewById(R.id.ImageView01);
// START LG_UI_HOME yoori.yoo 20100802 VS660(0802) merge
		// final ImageView imageDivider = (ImageView) findViewById(R.id.ImageView02);
		// final Intent mIntent = getIntent();
		
		SharedPreferences nXmlSaveStr = getSharedPreferences(Andy_NewPreference_Activity.HOME_SETTING, 0);	
		// String selectedMenu = mIntent.getStringExtra(Andy_NewPreference_Activity.HOME_SETTING);
		String selectedMenu = Andy_NewPreference_Activity.SET_HOME_NUMBER;
// END LG_UI_HOME yoori.yoo 20100802 
		
		if(selectedMenu.equals(Andy_NewPreference_Activity.SET_HOME_NUMBER)) {
			setTitle(getString(R.string.home_settings_menu_home_number));
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
			// BEGIN: 0004467 deukmo.koo@lge.com 2010-02-27
			// MOD 0004467: [Swift][LGHome] Change the algorithm of selecting home number in LG Home
			mList.setAdapter(new ArrayAdapter<String>(this,
					// android.R.layout.simple_list_item_single_choice, mnHomeNum));
					android.R.layout.simple_list_item_single_choice, mHomeNumberString));
			
			// BEGIN: 0003138 deukmo.koo@lge.com 2010-02-26
			// MOD 0003138: [Swift][LGHome/Launcher] default home screen
			mHomeNumber = nXmlSaveStr.getInt(Andy_NewPreference_Activity.SET_HOME_NUMBER, Launcher.getDefaultHomeNumber() /* 5 */);
	        // END: 0003138 deukmo.koo@lge.com 2010-02-26
// END LG_UI_HOME yoori.yoo 20100530 
	        
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
			/* if (mHomeNumber==3) {
				listInsertImage.setImageResource(R.drawable.popup_3);
				mList.setItemChecked(0, true);
			} else if (mHomeNumber==5) {
				listInsertImage.setImageResource(R.drawable.popup_5);
				mList.setItemChecked(1, true);
			} else if (mHomeNumber==7) {
				listInsertImage.setImageResource(R.drawable.popup_7);
				mList.setItemChecked(2, true);
			}
			Launcher.setHomeNumber(mHomeNumber);
			
			okBtn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					Launcher.setHomeNumber(mHomeNumber);
					Launcher.mScreen = true; */
	        if( mHomeNumber!=5 && mHomeNumber!=7) {
	        	mHomeNumber = Launcher.getDefaultHomeNumber();
	        }
			
			 if (mHomeNumber==5) {
// START LG_UI_HOME yoori.yoo 20100804
// maintain insertImage when folder opened
				 if(restore_insertImageNum != null && restore_insertImageNum.equals(new Integer(7))) {
					 listInsertImage.setImageResource(R.drawable.popup_7);
					 mHomeNumber = 7;
				 }
				 else
					 listInsertImage.setImageResource(R.drawable.popup_5);
			} else if (mHomeNumber==7) {
				if(restore_insertImageNum != null && restore_insertImageNum.equals(new Integer(5))) {
					listInsertImage.setImageResource(R.drawable.popup_5);
					mHomeNumber = 5;
				}
				else
					listInsertImage.setImageResource(R.drawable.popup_7);
			}
			 
			if(mHomeNumber == 5)
				mList.setItemChecked(0, true);
			else if(mHomeNumber == 7)
				mList.setItemChecked(1, true);
// END LG_UI_HOME yoori.yoo 20100804
			//Launcher.setHomeNumber(mHomeNumber);
			
			okBtn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					//Launcher.setHomeNumber(mHomeNumber);
					Launcher.mIsHomeNumberChanged = true;
// END LG_UI_HOME yoori.yoo 20100530 
					
					SharedPreferences nXmlSaveStr = getSharedPreferences(Andy_NewPreference_Activity.HOME_SETTING, 0);
					SharedPreferences.Editor editor = nXmlSaveStr.edit();
					editor.putInt(Andy_NewPreference_Activity.SET_HOME_NUMBER, mHomeNumber);
					editor.commit();
					
					finish();
				}
			});
			
			mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
				// public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					// int position = mList.getCheckedItemPosition();
// END LG_UI_HOME yoori.yoo 20100530 
					// BEGIN: 0002960 taesu84.kim@lge.com 2010-01-02
					// MOD 0002960: [Swift][Launcher] modify the number of default screen & theme title
					if (position == 0) {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
						listInsertImage.setImageResource(R.drawable.popup_5 /* R.drawable.popup_3 */);
						mHomeNumber = 5 /* 3 */;
// START LG_UI_HOME yoori.yoo 20100804
// maintain insertImage when folder opened
						insertImageNum = 5;
// END LG_UI_HOME yoori.yoo 20100804
					} else if (position == 1) {
						listInsertImage.setImageResource(R.drawable.popup_7 /* R.drawable.popup_5 */);
						mHomeNumber = 7 /* 5 */;
// START LG_UI_HOME yoori.yoo 20100804
// maintain insertImage when folder opened
						insertImageNum = 7;
// END LG_UI_HOME yoori.yoo 20100804
					} /* else if (position == 2) {
						listInsertImage.setImageResource(R.drawable.popup_7);
						mHomeNumber = 7;
					} */
// END LG_UI_HOME yoori.yoo 20100530 
					// END: 0002960 taesu84.kim@lge.com 2010-01-02
				}
			});
// START LG_UI_HOME yoori.yoo 20100802 VS660(0802) merge
		}
		/* else if(selectedMenu.equals(Andy_NewPreference_Activity.SET_HOME_THEME)) {
			setTitle(Andy_NewPreference_Activity.SET_HOME_THEME);
			ThemeListAdapter themeAdapter = new ThemeListAdapter(this);
			mList.setAdapter(themeAdapter);
			listInsertImage.setVisibility(View.GONE);
			imageDivider.setVisibility(View.GONE);
	
			// BEGIN: 0004707 deukmo.koo@lge.com 2010-03-06
			// MOD 0004707: [Swift][LGHome] Set default theme for operator
			// mHomeTheme = nXmlSaveStr.getString(Andy_NewPreference_Activity.SET_HOME_THEME, mHomeThemeList[0]);
			mHomeTheme = nXmlSaveStr.getString(Andy_NewPreference_Activity.SET_HOME_THEME, Launcher.getDefaultTheme());
			// END: 0004707 deukmo.koo@lge.com 2010-03-06
			// BEGIN: 0003287 taesu84.kim@lge.com 2010-01-14
			// ADD 0003287: [Swift][Launcher] change theme information
			mPreHomeTheme = mHomeTheme;
			// END: 0003287 taesu84.kim@lge.com 2010-01-14
			for(int i=0; i<mHomeThemeList.length; i++) {
				if (mHomeTheme.equals(mHomeThemeList[i])) {
					mList.setItemChecked(i, true);
					break;
				}
			}
			
			okBtn.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) {
					int i;
					
					for(i=0; i<mHomeThemeList.length; i++) {
						if (mHomeTheme.equals(mHomeThemeList[i])) {
			            	try {
				            	InputStream stream = getResources().openRawResource(mHomeThemeWallpaper[i]);
								setWallpaper(stream);
								setResult(RESULT_OK);
								Intent intent =new Intent();
								intent.setAction(ACTION_THEME_CHANGED);
								intent.putExtra(EXTRA_THEME_TYPE, mHomeThemeList[i]);
								// BEGIN: 0003287 taesu84.kim@lge.com 2010-01-14
								// ADD 0003287: [Swift][Launcher] change theme information
								intent.putExtra(EXTRA_PRE_THEME_TYPE, mPreHomeTheme);
								// END: 0003287 taesu84.kim@lge.com 2010-01-14
								sendBroadcast(intent);
			            	}
			            	catch (IOException e) {
								e.printStackTrace();
			            	}
			            	
			            	break;
					    }
					}
					
					if(i<mHomeThemeList.length) {
						SharedPreferences nXmlSaveStr = getSharedPreferences(Andy_NewPreference_Activity.HOME_SETTING, 0);
						SharedPreferences.Editor editor = nXmlSaveStr.edit();
						editor.putString(Andy_NewPreference_Activity.SET_HOME_THEME, mHomeTheme);
						editor.commit();
					}
					
					finish();
				}
			});
			
			mList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
				public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
					int position = mList.getCheckedItemPosition();
					checked[position] = !checked[position];
					mHomeTheme = mHomeThemeList[position];
				}
			});
		} */
// END LG_UI_HOME yoori.yoo 20100802 
		
		cancelBtn.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				finish();
			}
		});
	}
	
// START LG_UI_HOME yoori.yoo 20100804
// maintain insertImage when folder opened
	@Override
	public Object onRetainNonConfigurationInstance() {
		return insertImageNum;
	}

	@Override
	protected void onPause() {
		insertImageNum = mHomeNumber;
		super.onPause();
	};
// END LG_UI_HOME yoori.yoo 20100804
	
// START LG_UI_HOME yoori.yoo 20100802 VS660(0802) merge
	/* class ThemeListAdapter extends BaseAdapter {
		public ThemeListAdapter(Context context) {
			mContext = context;
			mInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE); 
		}
		
		public int getCount() { 
			return mHomeThemeList.length; 
		} 
		
		public Object getItem(int position) {
			return position;
		}
		
		public long getItemId(int position) { 
			return 0; 
		}
		
		public View getView(int position, View convertView, ViewGroup parent) { 
		    TextView themeTitle;
		    
		    if (convertView == null) { 
		    	themeTitle = (TextView) mInflater.inflate(android.R.layout.simple_list_item_single_choice, parent, false); 
		    } else { 
		    	themeTitle = (TextView)convertView; 
		    }
		    
		    themeTitle.setText(mContext.getResources().getString(mHomeThemeName[position])); 
		    themeTitle.setSelected(checked[position]); 
		    themeTitle.setCompoundDrawablesWithIntrinsicBounds(mHomeThemeIcons[position], 0, 0, 0);
		    
		    return themeTitle;
		}
		
		private Context mContext;
	} */
// END LG_UI_HOME yoori.yoo 20100802 
}