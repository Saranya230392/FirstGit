/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import java.net.URISyntaxException;

import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract.Contacts;
import android.widget.Toast;

public class UpdateShortcutReceiver extends BroadcastReceiver {
// START LG_UI_HOME yoori.yoo 20100815
// update shortcuts
	private static final String ACTION_UPDATE_SHORTCUT =
            "com.android.launcher.action.UPDATE_SHORTCUT";

    public void onReceive(Context context, Intent data) {
/*        if (!ACTION_UPDATE_SHORTCUT.equals(data.getAction())) {
            return;
        }
        
        updateShortcut(context, data);
*/
    }

/*    private boolean updateShortcut(Context context, Intent data) {
    	String contactId, contactLookup, contactPhoneNum, contactName;
		boolean deleteCompleted = false;
		
		contactId = data.getStringExtra("Contact_ID");
		contactLookup = data.getStringExtra("Lookup");
		contactPhoneNum = data.getStringExtra("PhoneNum");
		contactName = data.getStringExtra("Display_Name");
		
		if(contactId == null || contactId.length() <= 0)
			return deleteCompleted;
				
		Cursor launcherCursor = context.getContentResolver().query(LauncherSettings.Favorites.CONTENT_URI,
				new String[]{LauncherSettings.BaseLauncherColumns.INTENT,
				LauncherSettings.Favorites._ID,
				LauncherSettings.Favorites.TITLE}, null, null, null);
		int launcherIntentIndex = launcherCursor.getColumnIndexOrThrow(LauncherSettings.BaseLauncherColumns.INTENT);
		int launcherIdIndex = launcherCursor.getColumnIndexOrThrow(LauncherSettings.Favorites._ID);
		int launcherTitleIndex = launcherCursor.getColumnIndexOrThrow(LauncherSettings.Favorites.TITLE);
		
		if(launcherCursor == null || launcherIntentIndex == -1
				|| launcherIdIndex == -1 || launcherTitleIndex == -1) {
			if(launcherCursor != null)
				launcherCursor.close();
			return deleteCompleted;
		}
		
		if(launcherCursor.moveToFirst()) {
			do {
				int idStartPos, idEndPos; 
				String launcherIntent = launcherCursor.getString(launcherIntentIndex);
				String launcherId = launcherCursor.getString(launcherIdIndex);
				String launcherTitle = launcherCursor.getString(launcherTitleIndex);
				
				if(launcherId != null && launcherIntent != null) {
					String idOfIntentColumn, numOfIntentColumn, lookupOfIntentColumn;
					String updateWhere;
					ContentValues values = new ContentValues();
					updateWhere = LauncherSettings.Favorites._ID + "=" + launcherId;
					
					/* in case of contact shortcut */
/*					if(launcherIntent.indexOf(Contacts.CONTENT_URI.toString()) != -1) {
						int lookupStartPos = 0, lookupEndPos = 0;
						idStartPos = idEndPos = 0;
						for(int i = 0; i < 6; i++) {
							idStartPos = launcherIntent.indexOf('/', idStartPos);
							idStartPos++;
							if(i == 4) lookupStartPos = idStartPos;
							if(i == 5) lookupEndPos = idStartPos - 1;
						}
						idEndPos = launcherIntent.indexOf('#');
						
						if(idEndPos != -1 && (idStartPos <= idEndPos)) {
							idOfIntentColumn = launcherIntent.substring(idStartPos, idEndPos);
							lookupOfIntentColumn = launcherIntent.substring(lookupStartPos, lookupEndPos);

							if(idOfIntentColumn.equals(contactId)) {
								values.clear();
								if(lookupOfIntentColumn.equals(contactLookup) != true) {
									launcherIntent = launcherIntent.replace(lookupOfIntentColumn, contactLookup);
									values.put(LauncherSettings.Favorites.INTENT, launcherIntent);
								} else if(launcherTitle.equals(contactName) != true) {
									launcherTitle = contactName;
									values.put(LauncherSettings.Favorites.TITLE, launcherTitle);
								}
							}
						}
					} /* in case of direct dial or direct message */
/*					else if((launcherIntent.indexOf("tel") != -1
							&& launcherIntent.indexOf(Intent.ACTION_CALL) != -1) || 
							(launcherIntent.indexOf("smsto") != -1
									&& launcherIntent.indexOf(Intent.ACTION_SENDTO) != -1)) {
						int numStartPos, numEndPos;
						idStartPos = launcherIntent.indexOf("_id=");
						idEndPos = launcherIntent.indexOf(";end");
						numStartPos = launcherIntent.indexOf(':');
						numEndPos = launcherIntent.indexOf('#');
						if(idStartPos != -1 && idEndPos != -1 && numStartPos != -1 && numEndPos != -1) {
							idStartPos += 4;
							numStartPos += 1;
							
							idOfIntentColumn = launcherIntent.substring(idStartPos, idEndPos);
							numOfIntentColumn = launcherIntent.substring(numStartPos, numEndPos);
							
							if(idOfIntentColumn.equals(contactId)) {
								values.clear();
								if(numOfIntentColumn.equals(contactPhoneNum) != true) {
									launcherIntent = launcherIntent.replaceFirst(numOfIntentColumn, contactPhoneNum);
									values.put(LauncherSettings.Favorites.INTENT, launcherIntent);
								} else if(launcherTitle.equals(contactName) != true) {
									launcherTitle = contactName;
									values.put(LauncherSettings.Favorites.TITLE, launcherTitle);
								}
							}
						}
					}
					
					if(values.size() >= 1) {
						context.getContentResolver().update(LauncherSettings.Favorites.CONTENT_URI, values, updateWhere, null);
						deleteCompleted = true;
						break;
					}
				}
			} while (launcherCursor.moveToNext());
		}

		if(launcherCursor != null)
			launcherCursor.close();
		return deleteCompleted;
    }
*/
}
