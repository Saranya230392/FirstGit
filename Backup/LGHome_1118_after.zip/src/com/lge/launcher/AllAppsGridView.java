/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import android.widget.GridView;
import android.widget.AdapterView;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.Log;
import android.view.MotionEvent;
// START yoori.yoo 20100926 : Patch for Top Menu Focus 
import android.view.KeyEvent;
import android.widget.ScrollView;
import android.graphics.Rect;
// END yoori.yoo 20100926 

// BEGIN: 0002231 deukmo@lge.com 2009-12-23
// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
public class AllAppsGridView extends GridView implements AdapterView.OnItemClickListener,
        AdapterView.OnItemLongClickListener, DragSource, DropTarget, View.OnTouchListener {
// END: 0002231 deukmo@lge.com 2009-12-23
// START yoori.yoo 20100926 : Patch for Top Menu Focus 
    private static final boolean DEBUG = false;
// END yoori.yoo 20100926 
    
    private static final int ALLAPPS_DRAG_DELAY_TIME = 200; //modified by hwang072 for Vs740 2010-02-24
    
    private DragController mDragger;
    private Launcher mLauncher;

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
//Blocked by hwang072 for perfomance 2010-03-31
    private Bitmap mTexture;
    private Paint mPaint;
    private int mTextureWidth;
    private int mTextureHeight;
// END LG_UI_HOME yoori.yoo 20100530 
    
    private View mSelectedView = null;
    private StartDrag mStartDrag = new StartDrag();
    
// START yoori.yoo 20100926 : Patch for Top Menu Focus 
	private ScrollView mScrollView;
	private final Rect mVisibleRect = new Rect();
	private final Rect mFocusedRect = new Rect();
	private int CELL_HEIGHT = 135;
	private int mOffset = 0;
	private int mCatagoryTop = 0;
	private int mCatagoryBottom = 0;
// END yoori.yoo 20100926 
	
    public AllAppsGridView(Context context) {
        super(context);
    }

    public AllAppsGridView(Context context, AttributeSet attrs) {
        this(context, attrs, com.android.internal.R.attr.gridViewStyle);
    }

    public AllAppsGridView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
//Blocked by hwang072 for perfomance 2010-03-31		
/* */
        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.AllAppsGridView, defStyle, 0);
        final int textureId = a.getResourceId(R.styleable.AllAppsGridView_texture, 0);
        if (textureId != 0) {
            mTexture = BitmapFactory.decodeResource(getResources(), textureId);
            mTextureWidth = mTexture.getWidth();
            mTextureHeight = mTexture.getHeight();

            mPaint = new Paint();
            mPaint.setDither(false);
        }
        a.recycle(); /* */
// END LG_UI_HOME yoori.yoo 20100530 
    }

  /*  @Override
    public boolean isOpaque() {
        return !mTexture.hasAlpha();
    }
*/
    @Override
    protected void onFinishInflate() {
        setOnItemClickListener(this);
        setOnItemLongClickListener(this);
    }

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
//Blocked by hwang072 for perfomance 2010-03-31
/* */   @Override
    public void draw(Canvas canvas) {
        final Bitmap texture = mTexture;
	    // BEGIN: 0002231 deukmo@lge.com 2009-12-02
	    // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        if(texture!=null) {
	        final Paint paint = mPaint;
	
	        final int width = getWidth();
	        final int height = getHeight();
	
	        final int textureWidth = mTextureWidth;
	        final int textureHeight = mTextureHeight;
	
	        int x = 0;
	        int y;
	
	        while (x < width) {
	            y = 0;
	            while (y < height) {
	                canvas.drawBitmap(texture, x, y, paint);
	                y += textureHeight;
	            }
	            x += textureWidth;
	        }
        }
        // END: 0002231 deukmo@lge.com 2009-12-02

        super.draw(canvas);
    } /* */
// END LG_UI_HOME yoori.yoo 20100530 

    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
    	// BEGIN: 0002231 deukmo@lge.com 2009-12-02
		// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    	final int allAppsMode = mLauncher.getAllAppsMode();
        switch(allAppsMode) {
        	case Launcher.ALLAPPS_MODE_GRID:
        	{
        		final ApplicationInfo app = (ApplicationInfo) parent.getItemAtPosition(position);
    			mLauncher.startActivitySafely(app.intent);
    			break;
        	}
        	case Launcher.ALLAPPS_MODE_DELETE:
        	{
        		final ApplicationInfo app = (ApplicationInfo) parent.getItemAtPosition(position);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
			//modified by hwang072 for Vs740 2010-01-09
 			// if(!app.isSystemApplication){
        		mLauncher.showUninstallDialog(app);
			// }
// END LG_UI_HOME yoori.yoo 20100530 
        		break;
        	}
        }
        // END: 0002231 deukmo@lge.com 2009-12-02
    }

    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        if (!view.isInTouchMode()) {
            return false;
        }
        
        // BEGIN: 0002231 deukmo@lge.com 2009-12-02
		// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    	final int allAppsMode = mLauncher.getAllAppsMode();
        switch(allAppsMode) {
        	case Launcher.ALLAPPS_MODE_GRID:
        		ApplicationInfo app = (ApplicationInfo) parent.getItemAtPosition(position);
                app = new ApplicationInfo(app);
                
                mDragger.startDrag(view, this, app, DragController.DRAG_ACTION_MOVE);
                mLauncher.closeAllApplications();
                
                return true;
        }
        
        return false;
        // END: 0002231 deukmo@lge.com 2009-12-02
    }

    public void setDragger(DragController dragger) {
        mDragger = dragger;
    }

    public void onDropCompleted(View target, boolean success) {
    }

// START yoori.yoo 20100926 : Patch for Top Menu Focus 
// scrollView added
    void setLauncher(Launcher launcher, ScrollView scrollView) {
        mLauncher = launcher;
		mScrollView = scrollView;
    }
// END yoori.yoo 20100926 
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    public boolean acceptDrop(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
		return true;
	}

	public Rect estimateDropLocation(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo, Rect recycle) {
		return null;
	}

	public void onDragEnter(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
	}

	public void onDragExit(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
	}

	public void onDragOver(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
	}

	public void onDrop(DragSource source, int x, int y, int xOffset, int yOffset, Object dragInfo) {
		if(!(dragInfo instanceof View)) {
			return;
		}
		
		final View dropSource = (View) dragInfo;
		final View dropTarget = findViewByPoint(x, y);
		
		if(dropSource==null || dropSource==dropTarget) return;
		
		final AllAppsGridView sourceGridView = (AllAppsGridView) dropSource.getParent();
		final ApplicationsAdapter sourceAdapter = (ApplicationsAdapter) sourceGridView.getAdapter();
		final ApplicationsAdapter targetAdapter = (ApplicationsAdapter) getAdapter();
		final ApplicationInfo applicationInfo = (ApplicationInfo) sourceAdapter.getItem(sourceGridView.getPositionForView(dropSource));
		
		sourceAdapter.remove(applicationInfo);
		if(dropTarget==null) {
			targetAdapter.add(applicationInfo);
		} else {
			targetAdapter.insert(applicationInfo, getPositionForView(dropTarget));
		}
		
		mLauncher.resizeAllAppsGridHeight();
	}
	
	private View findViewByPoint(int x, int y) {
		final int count = getChildCount();
		
		View v;
		for(int i=0; i<count; i++) {
			v = getChildAt(i);
			if(x>=v.getLeft() && x<v.getRight() && y>=v.getTop() && y<v.getBottom()) return v;
		}
		
		return null;
	}
	
	public boolean onTouch(View v, MotionEvent event) {
		if(mLauncher.getAllAppsMode()==Launcher.ALLAPPS_MODE_EDIT) {
			switch(event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					mSelectedView = v;
					postDelayed(mStartDrag, ALLAPPS_DRAG_DELAY_TIME);
					return true;
				case MotionEvent.ACTION_UP:
				case MotionEvent.ACTION_CANCEL:
				case MotionEvent.ACTION_OUTSIDE:
					removeCallbacks(mStartDrag);
					break;
				default:
					if(mSelectedView!=null && mSelectedView!=v) {
						mSelectedView = null;
						removeCallbacks(mStartDrag);
					}
					break;
			}
		}
		
		return false;
	}
	
	private class StartDrag implements Runnable {
		public void run() {
			final View selectedView = mSelectedView;
            mDragger.startDrag(selectedView, AllAppsGridView.this, selectedView, DragController.DRAG_ACTION_MOVE);
		}
	}
	// END: 0002231 deukmo@lge.com 2009-12-23

// START yoori.yoo 20100926 : Patch for Top Menu Focus 
	@Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
		boolean handled = true;
		int top, bottom;

		if (DEBUG) Log.v("AllAppsGridView", "onKeyDown...keyCode : " + keyCode + ", event : " + event);

      	handled = super.onKeyDown(keyCode, event);
		
		super.getGlobalVisibleRect(mVisibleRect);
		if (DEBUG) Log.v("AllAppsGridView", "mVisibleRect - top : " + mVisibleRect.top + ", bottom : " + mVisibleRect.bottom);		
		super.getFocusedRect(mFocusedRect);
		if (DEBUG) Log.v("AllAppsGridView", "mFocusedRect...top : " + mFocusedRect.top + ", bottom : " + mFocusedRect.bottom);

		if (mFocusedRect.top == 0) {
			mOffset = 0;
		}
		
		switch (event.getKeyCode()) {
			case KeyEvent.KEYCODE_DPAD_UP:
				if (DEBUG) Log.v("AllAppsGridView", "onKeyDown...KEYCODE_DPAD_UP");
				top = mFocusedRect.top;
				if (mOffset > 0) {
					top -= (CELL_HEIGHT * (mOffset - 1));
				} else {
					top -= (CELL_HEIGHT * mOffset);
				}
				if (DEBUG) Log.v("AllAppsGridView", "top : " + top + ", mVisibleRect.top : " + mVisibleRect.top);
				if (top < mVisibleRect.top) {
					if (DEBUG) Log.v("AllAppsGridView", "View.FOCUS_UP");
					handled = mScrollView.customArrowScroll(View.FOCUS_UP, CELL_HEIGHT);
					if (handled) {
						mOffset--;
					}
					mOffset = mOffset > 0 ? mOffset : 0;
				}
				if (DEBUG) Log.v("AllAppsGridView", "onKeyDown...top : " + top + ", mOffset : " + mOffset);
				break;
			case KeyEvent.KEYCODE_DPAD_DOWN:
				if (DEBUG) Log.v("AllAppsGridView", "onKeyDown...KEYCODE_DPAD_DOWN");
				bottom = mFocusedRect.bottom - (CELL_HEIGHT * mOffset);
				if (DEBUG) Log.v("AllAppsGridView", "bottom : " + bottom + ", mVisibleRect.bottom : " + mVisibleRect.bottom);
				if (bottom > mVisibleRect.bottom) {
					if (DEBUG) Log.v("AllAppsGridView", "View.FOCUS_DOWN");
					handled = mScrollView.customArrowScroll(View.FOCUS_DOWN, CELL_HEIGHT);
					if (handled) {
						mOffset++;
					}
				}
				if (DEBUG) Log.v("AllAppsGridView", "onKeyDown...bottom : " + bottom + ", mOffset : " + mOffset);
				break;
		}
		if (DEBUG) Log.v("AllAppsGridView", "handled : " + handled);				
		return handled;
    }
// END yoori.yoo 20100926 
}
