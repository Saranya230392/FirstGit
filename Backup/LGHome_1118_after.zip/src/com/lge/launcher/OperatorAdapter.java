/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;


/**
 * Adapter showing the types of items that can be added to a {@link Workspace}.
 */
public class OperatorAdapter extends BaseAdapter { 

	private Launcher mLauncher;
    private final LayoutInflater mInflater;
    
    private final ArrayList<ListItem> mItems = new ArrayList<ListItem>();
    
    /**
     * Specific item in our list.
     */
    public class ListItem {
        CharSequence label;
        Drawable icon;
        String packageName;
        String className;
        
        public ListItem(Context context, PackageManager pm, ResolveInfo resolveInfo) {
        	label = resolveInfo.loadLabel(pm);
            if (label == null && resolveInfo.activityInfo != null) {
                label = resolveInfo.activityInfo.name;
            }
            
            icon = Utilities.createIconThumbnail(resolveInfo.loadIcon(pm), mLauncher);
            packageName = resolveInfo.activityInfo.applicationInfo.packageName;
            className = resolveInfo.activityInfo.name;
        }
    }
    
    public OperatorAdapter(Launcher launcher) {
        super();
        
        mLauncher = launcher;
        mInflater = (LayoutInflater) launcher.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        
        final PackageManager packageManager = launcher.getPackageManager();
        Intent getIntent;
        Intent intent = new Intent();
        ResolveInfo info;
        
        // TSR - Start
      /*  final String opCode = Settings.FlexInfo_Operator.getOperatorCode();
        if(opCode.equals("TSR")) {
	        intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.BigPond");
	        info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
	        intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.BigPondTV");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.CitySearch");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.CurrencyConverter");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.Downloads");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.Finance");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.telstra.products.foxtel.rmc", "com.streamezzo.browser.android.RichMedia");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.garmin.android.obn.client", "com.garmin.android.obn.client.GarminMobileActivity");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.Movies");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.Music");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.MyAccount");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.MyEmail");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
	        intent.setClassName("com.telstra.mysync", "com.voxmobili.stub.Stub");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.News");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
	        intent.setClassName("com.telstra.products.mobilecodes", "com.telstra.products.mobilecodes.client");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.SensisSearch");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.SocialWeb");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.Sport");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.TradingPost");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.Travel");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.Weather");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.Web");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.WhitePages");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.WorldNews");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
			intent.setClassName("com.lge.tsrurl", "com.lge.tsrurl.YellowPages");
			info = packageManager.resolveActivity(intent, 0);
	        if(info!=null) mItems.add(new ListItem(launcher, packageManager, info));
		}*/
        // TSR - End

    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ListItem item = (ListItem) getItem(position);
        
        if (convertView == null) {
            convertView = mInflater.inflate(R.layout.add_list_item, parent, false);
        }
        
        TextView textView = (TextView) convertView;
        textView.setTag(item);
        textView.setText(item.label);
        textView.setCompoundDrawablesWithIntrinsicBounds(item.icon, null, null, null);
        
        return convertView;
    }

    public int getCount() {
        return mItems.size();
    }

    public Object getItem(int position) {
        return mItems.get(position);
    }

    public long getItemId(int position) {
        return position;
    }
    
}
