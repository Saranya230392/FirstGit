/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.util.AttributeSet;
// START yoori.yoo 20100823 : VVM Icon Update
import android.util.Log;
// END yoori.yoo 20100823    
import android.widget.TextView;

/**
 * TextView that draws a bubble behind the text. We cannot use a LineBackgroundSpan
 * because we want to make the bubble taller than the text and TextView's clip is
 * too aggressive.
 */
public class BubbleTextView extends TextView {
    private static final float CORNER_RADIUS = 8.0f;
    private static final float PADDING_H = 5.0f;
    private static final float PADDING_V = 1.0f;

    private final RectF mRect = new RectF();
    private Paint mPaint;

    private boolean mBackgroundSizeChanged;
    private Drawable mBackground;
    private float mCornerRadius;
    private float mPaddingH;
    private float mPaddingV;

// START yoori.yoo 20100823 : VVM Icon Update
    private Launcher mLauncher;
    private String mClassName;	
    private String mNumtoString;
    private int mNumInfo0;	
    private int mNumInfo1;	
    private int mNumInfo2;	
    private int mNumInfo3;	
    private int mNumInfo4;	
    private int mNumInfo5;	
    private int mNumInfo6;
    
    private final String VVM_CLASSNAME = "com.lge.vvm.authmanager.VvmAuthManagerActivity";
    // private final String VVM_CLASSNAME = "com.lge.vvm";
// END yoori.yoo 20100823    
    
    public BubbleTextView(Context context) {
        super(context);
// START yoori.yoo 20100823 : VVM Icon Update
// parameter added
        init(context);
// END yoori.yoo 20100823    
    }

    public BubbleTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
// START yoori.yoo 20100823 : VVM Icon Update
// parameter added
        init(context);
// END yoori.yoo 20100823    
    }

    public BubbleTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
// START yoori.yoo 20100823 : VVM Icon Update
// parameter added
        init(context);
// END yoori.yoo 20100823    
    }

// START yoori.yoo 20100823 : VVM Icon Update    	
// parameter added
    private void init(Context context) {
    	if(context instanceof Launcher) 
    		mLauncher = (Launcher) context;
// END yoori.yoo 20100823     
    	
        setFocusable(true);
        mBackground = getBackground();
        setBackgroundDrawable(null);
        mBackground.setCallback(this);

        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setColor(getContext().getResources().getColor(R.color.bubble_dark_background));

        final float scale = getContext().getResources().getDisplayMetrics().density;
        mCornerRadius = CORNER_RADIUS * scale;
        mPaddingH = PADDING_H * scale;
        //noinspection PointlessArithmeticExpression
        mPaddingV = PADDING_V * scale;
    }

    @Override
    protected boolean setFrame(int left, int top, int right, int bottom) {
        if (mLeft != left || mRight != right || mTop != top || mBottom != bottom) {
            mBackgroundSizeChanged = true;
        }
        return super.setFrame(left, top, right, bottom);
    }

    @Override
    protected boolean verifyDrawable(Drawable who) {
        return who == mBackground || super.verifyDrawable(who);
    }

    @Override
    protected void drawableStateChanged() {
        Drawable d = mBackground;
        if (d != null && d.isStateful()) {
            d.setState(getDrawableState());
        }
        super.drawableStateChanged();
    }

    @Override
    public void draw(Canvas canvas) {
// START yoori.yoo 20100823 : VVM Icon Update   
    	final int scrollX = mScrollX;
        final int scrollY = mScrollY;
// END yoori.yoo 20100823 
        final Drawable background = mBackground;
        if (background != null) {
// START yoori.yoo 20100823 : VVM Icon Update       	
            /* final int scrollX = mScrollX;
            final int scrollY = mScrollY; */
// END yoori.yoo 20100823 
            if (mBackgroundSizeChanged) {
                background.setBounds(0, 0,  mRight - mLeft, mBottom - mTop);
                mBackgroundSizeChanged = false;
            }

            if ((scrollX | scrollY) == 0) {
                background.draw(canvas);
            } else {
                canvas.translate(scrollX, scrollY);
                background.draw(canvas);
                canvas.translate(-scrollX, -scrollY);
            }
        }

        final Layout layout = getLayout();
        final RectF rect = mRect;
        final int left = getCompoundPaddingLeft();
        final int top = getExtendedPaddingTop();

        rect.set(left + layout.getLineLeft(0) - mPaddingH,
                top + layout.getLineTop(0) -  mPaddingV,
                Math.min(left + layout.getLineRight(0) + mPaddingH, mScrollX + mRight - mLeft),
                top + layout.getLineBottom(0) + mPaddingV);
        canvas.drawRoundRect(rect, mCornerRadius, mCornerRadius, mPaint);

        super.draw(canvas);
// START yoori.yoo 20100823 : VVM Icon Update
        if (getAppClassName() == null)
 			return;

		int numinfo=0;
		String className = getAppClassName();	

		if (className.startsWith(VVM_CLASSNAME))
 			numinfo = mLauncher.getVvmUpdateNum();
		

		DrawAllInfo(canvas ,numinfo , scrollX , scrollY);

		destroyDrawingImageCache(numinfo);
// END yoori.yoo 20100823 
    }
    
// START yoori.yoo 20100823 : VVM Icon Update
    public void DrawNumber(Canvas canvas, Drawable Num ,int loc, int scrollX , int scrollY ,int Xoffset , int Yoffset) {
		char str = mNumtoString.charAt(loc);
	
		switch (str) {
			case '0':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num0);
				break;
			case '1':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num1);
				break;
			case '2':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num2);
				break;
			case '3':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num3);
				break;
			case '4':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num4);
				break;
			case '5':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num5);
				break;
			case '6':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num6);
				break;
			case '7':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num7);
				break;
			case '8':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num8);
				break;
			case '9':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num9);
				break;
			default :	
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num0);
				break;
		}
		//Num.setCallback(this);
		canvas.translate(scrollX+Xoffset ,scrollY+Yoffset);
		Num.setBounds(0, 0, Num.getIntrinsicWidth(), Num.getIntrinsicHeight()); 
		Num.draw(canvas); 
		canvas.translate(-(scrollX+Xoffset), -(scrollY+Yoffset));	
	}
    
    public void DrawAllInfo (Canvas canvas, int numinfo , int scrollX , int scrollY) {
		if ( numinfo == 0 )
 			return;

		Log.i("Launcher" , "DrawAllInfo=" + getAppClassName());

// START yoori.yoo 20100930
		final int scrollX_BG;
		
		if(mLauncher.getOrientationstate()) {
			scrollX_BG = numinfo < 100 ? 65: 55;
		} else {
			scrollX_BG = numinfo < 100 ? 75: 63;
		}
// END yoori.yoo 20100930

		final int scrollX_num1of1 = scrollX_BG + 9;
		final int scrollX_num1of2 = scrollX_BG + 5;
		final int scrollX_num2of2 = scrollX_BG + 13;
		final int scrollX_num1of3 = scrollX_BG + 7;
		final int scrollX_num2of3 = scrollX_BG + 17;
		final int scrollX_num3of3 = scrollX_BG + 27;
		final int scrollY_BG = 0;
		final int scrollY_num = scrollY_BG + 5;

    	Drawable NumCountBG = null;
    	Drawable Num1st = null;
    	Drawable Num2nd = null;
    	Drawable Num3rd = null;

		if (numinfo > 999)
			numinfo = 999;

		if (numinfo > 0 && numinfo < 100) {
	        NumCountBG = getContext().getResources().getDrawable(R.drawable.count_info_bg);//count_info_bg
		} else {
			NumCountBG = getContext().getResources().getDrawable(R.drawable.count_info_bg_w);//count_info_bg_w
		}

		//NumCountBG.setCallback(this);
		canvas.translate(scrollX+scrollX_BG ,scrollY+scrollY_BG);
		NumCountBG.setBounds(0, 0, NumCountBG.getIntrinsicWidth(), NumCountBG.getIntrinsicHeight()); 
		NumCountBG.draw(canvas); 
		canvas.translate(-(scrollX+scrollX_BG), -(scrollY+scrollY_BG));
		
		mNumtoString = String.valueOf(numinfo);

		if ( numinfo > 0 && numinfo < 10) // 1
		{
			DrawNumber(	canvas , Num1st , 0 , scrollX , scrollY , scrollX_num1of1 , scrollY_num);		
		} 
		else if ( numinfo >=10 && numinfo<100 )// 2 
		{
			DrawNumber(	canvas , Num1st , 0 , scrollX , scrollY , scrollX_num1of2 , scrollY_num);		
			DrawNumber(	canvas , Num2nd , 1 , scrollX , scrollY , scrollX_num2of2 , scrollY_num);		
		}
		else // 3
		{
			DrawNumber(	canvas , Num1st , 0, scrollX , scrollY , scrollX_num1of3 , scrollY_num);		
			DrawNumber(	canvas , Num2nd , 1, scrollX , scrollY , scrollX_num2of3 , scrollY_num);		
			DrawNumber(	canvas , Num3rd , 2, scrollX , scrollY , scrollX_num3of3 , scrollY_num);		
		}
	}
    
    public void  destroyDrawingImageCache(int numinfo) {
		int num = mLauncher.getWorkspace().getCurrentScreen();

		switch (num) {
			case 0:
				if (mNumInfo0 != numinfo) {
					mNumInfo0 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 1:
				if (mNumInfo1 != numinfo) {
					mNumInfo1 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 2:
				if (mNumInfo2 != numinfo) {
					mNumInfo2 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 3:
				if (mNumInfo3 != numinfo) {
					mNumInfo3 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 4:
				if (mNumInfo4 != numinfo) {
					mNumInfo4 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 5:
				if (mNumInfo5 != numinfo) {
					mNumInfo5 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 6:
				if (mNumInfo6 != numinfo) {
					mNumInfo6 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			default :	
				if (mNumInfo0 != numinfo) {
					mNumInfo0 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
		}
	}

    public String getAppClassName(){
		return mClassName ;
	}
    public void setAppClassName(String name){
		 mClassName = name;
	}	
// END yoori.yoo 20100823     
}
