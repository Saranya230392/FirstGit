/* Copyright (C) 2010 LG Electronics.
 * IMPLEMENTATION TITLE: SET DEFAULT HOMESCREEN
 * 
 * 
 * Author: by.kong@lge.com
 */

package com.lge.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.content.IntentFilter;

public class DefaultHome extends Activity{
	private static final boolean LGHOME = true; 
	private static final boolean LAUNCHER = false;
	private PackageManager mPm;
	
	@Override
	protected void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		mPm = getPackageManager(); 
		setDefaultHome(LGHOME);
		removeActivity();
	}

	public void removeActivity()
	{
		// remove this activity from the package manager.
		ComponentName name = new ComponentName(this, DefaultHome.class);
		mPm.setComponentEnabledSetting(name, PackageManager.COMPONENT_ENABLED_STATE_DISABLED, 0);
		// terminate the activity.
		finish();
	} 
	
	public void setDefaultHome(boolean which)
	{ 
		IntentFilter filter = new IntentFilter();

		filter.addAction(Intent.ACTION_MAIN);
		filter.addCategory(Intent.CATEGORY_HOME);
		filter.addCategory(Intent.CATEGORY_DEFAULT);

		ComponentName[] set = new ComponentName[2];
		set[0] = new ComponentName("com.lge.launcher", "com.lge.launcher.Launcher");
		set[1] = new ComponentName("com.android.launcher2", "com.android.launcher2.Launcher");
        	//set default homescreen
		mPm.addPreferredActivity(filter, 1081344 , set, set[0]);
	}
}

