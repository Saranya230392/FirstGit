/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.TextView;

public class MenuTextView extends TextView {
	private static final int UNINSTALL_ICON_POSITION_X = 78 - 18;
	private static final int UNINSTALL_ICON_POSITION_Y = 0;
	
	private Launcher mLauncher;
	
	private Drawable mUninstallDrawable;
	private boolean mIsSystemApp = true;
	
// START yoori.yoo 20100909 : VS660 Merge for VVM Icon Update 
	private String mPackageName ;	
    private String mClassName ;
    private String mNumtoString ;
    private int mNumInfo0 ;	
    private int mNumInfo1 ;	
    private int mNumInfo2 ;	
    private int mNumInfo3 ;	
    private int mNumInfo4 ;	
    private int mNumInfo5 ;	
    private int mNumInfo6 ;
    private final String VVM_CLASSNAME = "com.lge.vvm.authmanager.VvmAuthManagerActivity";
// END yoori.yoo 20100909 
	
    public MenuTextView(Context context) {
        super(context);
        init(context);
    }

    public MenuTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public MenuTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(context);
    }
    
    private void init(Context context) {
    	if(context instanceof Launcher) mLauncher = (Launcher) context;
    	mUninstallDrawable = context.getResources().getDrawable(R.drawable.uninstall_icon);
    	mUninstallDrawable.setBounds(UNINSTALL_ICON_POSITION_X,
    			UNINSTALL_ICON_POSITION_Y,
    			UNINSTALL_ICON_POSITION_X + mUninstallDrawable.getIntrinsicWidth(),
    			UNINSTALL_ICON_POSITION_Y + mUninstallDrawable.getIntrinsicHeight());
    }

    @Override
    public void draw(Canvas canvas) {
    	int mode = Launcher.ALLAPPS_MODE_GRID;
//    	final float mCenterX = getWidth() / 2f;
//    	final float mCenterY = getHeight() / 2f;
    	
    	if(mLauncher!=null) {
    		mode = mLauncher.getAllAppsMode();
    	}
    //	if(mode==Launcher.ALLAPPS_MODE_EDIT) {//modified by hwang072 for Vs740 2010-01-09
    	//	canvas.save();
    	//	canvas.rotate(7f, mCenterX, mCenterY);
    //	}
        super.draw(canvas);
 //       if(mode==Launcher.ALLAPPS_MODE_EDIT) {//modified by hwang072 for Vs740 2010-01-09
 //       	canvas.restore();
  //  	}
        if(mode==Launcher.ALLAPPS_MODE_DELETE && !mIsSystemApp) {
        	mUninstallDrawable.draw(canvas);
        }
// START yoori.yoo 20100909 : VS660 Merge for VVM Icon Update 
        if (getAppClassName() == null)
 			return;
		
		int numinfo=0;
		String className = getAppClassName();
		if(className.equals(VVM_CLASSNAME)) {
			numinfo = mLauncher.getVvmUpdateNum();
		}
		
		DrawAllInfo(canvas ,numinfo , mScrollX , mScrollY);
		destroyDrawingImageCache(numinfo);
// END yoori.yoo 20100909 
    }
    
    void setSystemApp(boolean isSystemApp) {
    	mIsSystemApp = isSystemApp;
    }
    
// START yoori.yoo 20100909 : VS660 Merge for VVM Icon Update 
    public void destroyDrawingImageCache(int numinfo) {
		int num = mLauncher.getWorkspace().getCurrentScreen();

		switch (num) {
			case 0:
				if (mNumInfo0 != numinfo) {
					mNumInfo0 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 1:
				if (mNumInfo1 != numinfo) {
					mNumInfo1 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 2:
				if (mNumInfo2 != numinfo) {
					mNumInfo2 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 3:
				if (mNumInfo3 != numinfo) {
					mNumInfo3 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 4:
				if (mNumInfo4 != numinfo) {
					mNumInfo4 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 5:
				if (mNumInfo5 != numinfo) {
					mNumInfo5 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			case 6:
				if (mNumInfo6 != numinfo) {
					mNumInfo6 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
			default :	
				if (mNumInfo0 != numinfo) {
					mNumInfo0 = numinfo ;
					destroyDrawingCache(); // For re-caching image
				}
				break;
		}
	}
    
    public void DrawAllInfo (Canvas canvas, int numinfo , int scrollX , int scrollY) {
		if ( numinfo == 0 )
 			return;

// START yoori.yoo 20100930
		final int scrollX_BG;
		
		if(mLauncher.getOrientationstate()) {
			scrollX_BG = numinfo < 100 ? 70: 55;
		} else {
			scrollX_BG = numinfo < 100 ? 78: 65;
		}
// END yoori.yoo 20100930

		final int scrollX_num1of1 = scrollX_BG + 9;
		final int scrollX_num1of2 = scrollX_BG + 5;
		final int scrollX_num2of2 = scrollX_BG + 13;
		final int scrollX_num1of3 = scrollX_BG + 7;
		final int scrollX_num2of3 = scrollX_BG + 17;
		final int scrollX_num3of3 = scrollX_BG + 27;
		final int scrollY_BG = 0;
		final int scrollY_num = scrollY_BG + 5;

    	Drawable NumCountBG = null;
    	Drawable Num1st = null;
    	Drawable Num2nd = null;
    	Drawable Num3rd = null;

		if (numinfo > 999)
			numinfo = 999;

		if (numinfo > 0 && numinfo < 100) {
	        NumCountBG = getContext().getResources().getDrawable(R.drawable.count_info_bg);//count_info_bg
		} else {
			NumCountBG = getContext().getResources().getDrawable(R.drawable.count_info_bg_w);//count_info_bg_w
		}

		//NumCountBG.setCallback(this);
		canvas.translate(scrollX+scrollX_BG ,scrollY+scrollY_BG);
		NumCountBG.setBounds(0, 0, NumCountBG.getIntrinsicWidth(), NumCountBG.getIntrinsicHeight()); 
		NumCountBG.draw(canvas); 
		canvas.translate(-(scrollX+scrollX_BG), -(scrollY+scrollY_BG));
		
		mNumtoString = String.valueOf(numinfo);

		if ( numinfo > 0 && numinfo < 10) // 1
		{
			DrawNumber(	canvas , Num1st , 0 , scrollX , scrollY , scrollX_num1of1 , scrollY_num);		
		} 
		else if ( numinfo >=10 && numinfo<100 )// 2 
		{
			DrawNumber(	canvas , Num1st , 0 , scrollX , scrollY , scrollX_num1of2 , scrollY_num);		
			DrawNumber(	canvas , Num2nd , 1 , scrollX , scrollY , scrollX_num2of2 , scrollY_num);		
		}
		else // 3
		{
			DrawNumber(	canvas , Num1st , 0, scrollX , scrollY , scrollX_num1of3 , scrollY_num);		
			DrawNumber(	canvas , Num2nd , 1, scrollX , scrollY , scrollX_num2of3 , scrollY_num);		
			DrawNumber(	canvas , Num3rd , 2, scrollX , scrollY , scrollX_num3of3 , scrollY_num);		
		}
	}

	public void DrawNumber(Canvas canvas, Drawable Num ,int loc, int scrollX , int scrollY ,int Xoffset , int Yoffset) {
		char str = mNumtoString.charAt(loc);
	
		switch (str) {
			case '0':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num0);
				break;
			case '1':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num1);
				break;
			case '2':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num2);
				break;
			case '3':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num3);
				break;
			case '4':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num4);
				break;
			case '5':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num5);
				break;
			case '6':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num6);
				break;
			case '7':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num7);
				break;
			case '8':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num8);
				break;
			case '9':
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num9);
				break;
			default :	
				Num = getContext().getResources().getDrawable(R.drawable.count_info_num0);
				break;
		}
		canvas.translate(scrollX+Xoffset ,scrollY+Yoffset);
		Num.setBounds(0, 0, Num.getIntrinsicWidth(), Num.getIntrinsicHeight()); 
		Num.draw(canvas); 
		canvas.translate(-(scrollX+Xoffset), -(scrollY+Yoffset));	
	}
	
	public void setAppPackageName(String name){
		mPackageName = name;
	}	
	public void setAppClassName(String name){
		mClassName = name;
	}	
	public String getAppPackageName(){
		return mPackageName ;
	}	
	public String getAppClassName(){
		return mClassName ;
	}
// END yoori.yoo 20100909 
}
