/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
import com.android.common.Search;
// END LG_UI_HOME yoori.yoo 20100727 

import static android.util.Log.d;
import static android.util.Log.e;
import static android.util.Log.w;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import com.android.internal.util.XmlUtils;
import android.graphics.Rect;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Application;
import android.app.Dialog;
// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
// import android.app.ISearchManager;
// END LG_UI_HOME yoori.yoo 20100727 
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.app.StatusBarManager;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProviderInfo;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.Intent.ShortcutIconResource;
import android.content.pm.ActivityInfo;
import android.content.pm.IPackageDeleteObserver;
import android.content.pm.IPackageStatsObserver;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageStats;
import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.database.ContentObserver;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.MessageQueue;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.ServiceManager;
import android.provider.ContactsContract.Contacts;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Intents.UI;
import android.provider.ContactsContract;
import android.provider.LiveFolders;
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
import android.provider.Settings;
// END LG_UI_HOME yoori.yoo 20100530 
import android.text.Selection;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.format.Formatter;
import android.text.method.TextKeyListener;
import android.util.AttributeSet;
import android.util.Xml;
import android.util.SparseArray;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.View.OnLongClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SlidingDrawer;
import android.widget.TextView;
import android.widget.Toast;
import android.app.WallpaperInfo;
import android.app.WallpaperManager;
import android.content.pm.LabeledIntent;
import android.widget.LinearLayout;
import android.util.Log;
import android.view.HapticFeedbackConstants;

// START yoori.yoo 20100829 ; Animation Patch
import android.os.ServiceManager;
import android.view.IWindowManager;
// END yoori.yoo 20100829 

// START yoori.yoo 20100907 : Default Manner - Silent
import android.media.AudioManager;
import android.text.method.MetaKeyKeyListener;
import android.util.Log;
import android.os.SystemClock;
import android.view.ViewConfiguration;
// END yoori.yoo 20100907
//phone call
import com.android.internal.telephony.ITelephony;
//2010.10.01 sunghwa.woo@lge.com SNS widget
import com.lge.sns.SNSBridge;

import android.os.RemoteException;
import android.os.ServiceManager;
//phone call

/**
 * Default launcher application.
 */
public final class Launcher extends Activity implements View.OnClickListener, OnLongClickListener {
    static final String LOG_TAG = "Launcher";
    static final boolean LOGD = false;
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
    // BEGIN: 0002816 taesu84.kim@lge.com 2009-12-28
    // ADD 0002816: [Swift][Launcher] indication bar is sychronized with home screen
    // static boolean homePressed = false;
    // END: 0002816 taesu84.kim@lge.com 2009-12-28
// END LG_UI_HOME yoori.yoo 20100530 

    private static final boolean PROFILE_STARTUP = false;
    private static final boolean PROFILE_DRAWER = false;
    private static final boolean PROFILE_ROTATE = false;
    private static final boolean DEBUG_USER_INTERFACE = false;
	private static final int WALLPAPER_SCREENS_SPAN = 2;

	private static final int MENU_GROUP_ADD = 1;
	// BEGIN: 0002231 deukmo@lge.com 2009-12-03
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	private static final int MENU_GROUP_IDLE = MENU_GROUP_ADD + 1;
    private static final int MENU_GROUP_ALLAPPS = MENU_GROUP_IDLE + 1;
    private static final int MENU_GROUP_ALLAPPS_EDIT = MENU_GROUP_ALLAPPS + 1;
    // END: 0002231 deukmo@lge.com 2009-12-03
    
	private static final int MENU_ADD = Menu.FIRST + 1;
	private static final int MENU_WALLPAPER_SETTINGS = MENU_ADD + 1;
	private static final int MENU_HOME_SETTINGS = MENU_WALLPAPER_SETTINGS + 1;
	private static final int MENU_SEARCH = MENU_HOME_SETTINGS + 1;
	private static final int MENU_NOTIFICATIONS = MENU_SEARCH + 1;
	private static final int MENU_SETTINGS = MENU_NOTIFICATIONS + 1;
	// BEGIN: 0002231 deukmo@lge.com 2009-12-03
	// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	private static final int MENU_ALLAPPS_ADD_GROUP = MENU_SETTINGS + 1;
	private static final int MENU_ALLAPPS_DELETE_GROUP = MENU_ALLAPPS_ADD_GROUP + 1;
	private static final int MENU_ALLAPPS_RENAME_GROUP = MENU_ALLAPPS_DELETE_GROUP + 1;
	private static final int MENU_ALLAPPS_EDIT = MENU_ALLAPPS_RENAME_GROUP + 1;
	private static final int MENU_ALLAPPS_DELETE = MENU_ALLAPPS_EDIT + 1;
	private static final int MENU_ALLAPPS_RESET_GROUP = MENU_ALLAPPS_DELETE + 1;
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	private static final int MENU_ALLAPPS_EDIT_DONE = MENU_ALLAPPS_RESET_GROUP + 1;
	private static final int MENU_ALLAPPS_EDIT_REVERT = MENU_ALLAPPS_EDIT_DONE + 1;
// END LG_UI_HOME yoori.yoo 20100530 
    // END: 0002231 deukmo@lge.com 2009-12-03

    private static final int REQUEST_CREATE_SHORTCUT = 1;
    private static final int REQUEST_CREATE_LIVE_FOLDER = 4;
    private static final int REQUEST_CREATE_APPWIDGET = 5;
    private static final int REQUEST_PICK_APPLICATION = 6;
    private static final int REQUEST_PICK_SHORTCUT = 7;
    private static final int REQUEST_PICK_LIVE_FOLDER = 8;
    private static final int REQUEST_PICK_APPWIDGET = 9;

    static final String EXTRA_SHORTCUT_DUPLICATE = "duplicate";
    
    //2010.10.01 sunghwa.woo@lge.com SNS widget
    static final String EXTRA_CUSTOM_WIDGET = "custom_widget";

// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
    /* static final String EXTRA_CUSTOM_WIDGET = "custom_widget";
    static final String SEARCH_WIDGET = "search_widget"; */
// END LG_UI_HOME yoori.yoo 20100727 

    static final int SCREEN_COUNT = 3;
    static final int DEFAULT_SCREN = 1;
    static final int NUMBER_CELLS_X = 4;
    static final int NUMBER_CELLS_Y = 4;
	
	// BEGIN: 0004467 deukmo.koo@lge.com 2010-02-27
	// MOD 0004467: [Swift][LGHome] Change the algorithm of selecting home number in LG Home
    // private static int mHomeNumber = 5;
	private int mHomeNumber;
	// END: 0004467 deukmo.koo@lge.com 2010-02-27
    
// START yoori.yoo 20100823 : VVM Icon Update	
	private int mUnreadVvms = 0;
// END yoori.yoo 20100823 	
 
    private static final int DIALOG_CREATE_SHORTCUT = 1;
    static final int DIALOG_RENAME_FOLDER = 2;
	// BEGIN: 0002231 deukmo@lge.com 2009-12-03
	// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	private static final int DIALOG_ALLAPPS_ADD_GROUP = DIALOG_RENAME_FOLDER + 1;
	private static final int DIALOG_ALLAPPS_RENAME_GROUP = DIALOG_ALLAPPS_ADD_GROUP + 1;
	private static final int DIALOG_ALLAPPS_DELETE_GROUP = DIALOG_ALLAPPS_RENAME_GROUP + 1;
	private static final int DIALOG_ALLAPPS_RESET_GROUP = DIALOG_ALLAPPS_DELETE_GROUP + 1;
	private static final int DIALOG_ALLAPPS_UNINSTALL_APP = DIALOG_ALLAPPS_RESET_GROUP + 1;
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	// BEGIN: 0004063 deukmo.koo@lge.com 2010-02-25
	// ADD 0004063: [Swift][LGHome] Add Lockscreen Image setting menu
	private static final int DIALOG_SELECT_WALLPAPER_TO = DIALOG_ALLAPPS_UNINSTALL_APP + 1;
	// END: 0004063 deukmo.koo@lge.com 2010-02-25
	// END: 0002231 deukmo@lge.com 2009-12-03
	// BEGIN: 0004773 deukmo.koo@lge.com 2010-03-08
	// ADD 0004773: [Swift][LGHome] Add a menu for operator
	private static final int DIALOG_SELECT_OPERATOR_APP = DIALOG_SELECT_WALLPAPER_TO + 1;
	// END: 0004773 deukmo.koo@lge.com 2010-03-08
// END LG_UI_HOME yoori.yoo 20100530 

    private static final String PREFERENCES = "launcher.preferences";

    // Type: int
    private static final String RUNTIME_STATE_CURRENT_SCREEN = "launcher.current_screen";
    // Type: boolean
    private static final String RUNTIME_STATE_ALL_APPS_FOLDER = "launcher.all_apps_folder";
    // Type: long
    private static final String RUNTIME_STATE_USER_FOLDERS = "launcher.user_folder";
    // Type: int
    private static final String RUNTIME_STATE_PENDING_ADD_SCREEN = "launcher.add_screen";
    // Type: int
    private static final String RUNTIME_STATE_PENDING_ADD_CELL_X = "launcher.add_cellX";
    // Type: int
    private static final String RUNTIME_STATE_PENDING_ADD_CELL_Y = "launcher.add_cellY";
    // Type: int
    private static final String RUNTIME_STATE_PENDING_ADD_SPAN_X = "launcher.add_spanX";
    // Type: int
    private static final String RUNTIME_STATE_PENDING_ADD_SPAN_Y = "launcher.add_spanY";
    // Type: int
    private static final String RUNTIME_STATE_PENDING_ADD_COUNT_X = "launcher.add_countX";
    // Type: int
    private static final String RUNTIME_STATE_PENDING_ADD_COUNT_Y = "launcher.add_countY";
    // Type: int[]
    private static final String RUNTIME_STATE_PENDING_ADD_OCCUPIED_CELLS = "launcher.add_occupied_cells";
    // Type: boolean
    private static final String RUNTIME_STATE_PENDING_FOLDER_RENAME = "launcher.rename_folder";
    // Type: long
    private static final String RUNTIME_STATE_PENDING_FOLDER_RENAME_ID = "launcher.rename_folder_id";
//added by hwang072 for Vs740 2010-01-08
    // Type: int
    private static final String RUNTIME_STATE_ALLAPPS_CATEGORY_RENAME_ID = "launcher.rename_category_id";
//added by hwang072 for Vs740 2010-01-09
	// Type: parcelable
    private static final String RUNTIME_STATE_UNINSTALL_APP_INFO = "launcher.uninstall_app_info";
//added by hwang072 for Vs740 2010-01-13
	// Type: boolean[]
    private static final String RUNTIME_STATE_DELETE_CHECKED_ID= "launcher.delete_checked_id";
//Added by hwang072 for bug fix 2010-03-18
// Type: boolean[]
   private static final String RUNTIME_STATE_ALL_APPS_ISOPENED= "launcher.all_apps_isopened";

// START yoori.yoo 20100916 : VS660 Merge for SD Card Issue
    // private static final LauncherModel sModel = new LauncherModel();
    private static LauncherModel sModel = new LauncherModel();
// END yoori.yoo 20100916

    private static final Object sLock = new Object();
    private static int sScreen = DEFAULT_SCREN;

// START yoori.yoo 20100922 : back to previous screen
    private static int screenAtOnPause = DEFAULT_SCREN;
    private static boolean backToPreviousScreen = false;
// END yoori.yoo 20100922
    
    private final BroadcastReceiver mApplicationsReceiver = new ApplicationsIntentReceiver();
    private final BroadcastReceiver mCloseSystemDialogsReceiver = new CloseSystemDialogsIntentReceiver();
// START yoori.yoo 20100823 : VVM Icon Update
    private final BroadcastReceiver mNewVvmIntentReceiver = new NewVvmIntentReceiver();
// END yoori.yoo 20100823 
// START yoori.yoo 20100906 : Top Menu - End Key - Idle
	private final BroadcastReceiver mEndKeyEventReceiver = new EndKeyEventReceiver();
// END yoori.yoo 20100906 

    private final ContentObserver mObserver = new FavoritesChangeObserver();
    private final ContentObserver mWidgetObserver = new AppWidgetResetObserver();

    private LayoutInflater mInflater;

    private DragLayer mDragLayer;
    private Workspace mWorkspace;

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	// Added by deukmo@lge.com, 2009-05-06
    //	BEGIN: bykong : 2010-01-11
    //  DEL : [VS740] remove launcher button 
    /*	private ImageView mBottomButton1;
	private ImageView mBottomButton2;
	private ImageView mBottomButton3;
	private ImageView mBottomButton4;*/
    // public LinearLayout mLauncherLayout;
    //	END: bykong : 2010-01-11
// START yoori.yoo 20100820 : VS740 idle navi issue merge
	// private ImageView mBottomButton4;
	public HandleLayout mBottomButton4;
// END yoori.yoo 20100820 
	public RelativeLayout mLauncherLayout;
// END LG_UI_HOME yoori.yoo 20100530 
	private AppWidgetManager mAppWidgetManager;
	private LauncherAppWidgetHost mAppWidgetHost;

	static final int APPWIDGET_HOST_ID = 1025;

    private CellLayout.CellInfo mAddItemCellInfo;
    private CellLayout.CellInfo mMenuAddInfo;
    private final int[] mCellCoordinates = new int[2];
    private FolderInfo mFolderInfo;

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	// private AlohaSlidingDrawer mDrawer;
	private SlidingDrawer mDrawer;
// END LG_UI_HOME yoori.yoo 20100530 
	// BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	private View mHandleView;
	// END: 0002231 deukmo@lge.com 2009-12-23

    private boolean mDesktopLocked = true;
    private Bundle mSavedState;

    private SpannableStringBuilder mDefaultKeySsb = null;

    private boolean mDestroyed;
    
    private boolean mIsNewIntent;

    private boolean mRestoring;
    private boolean mWaitingForResult;
    private boolean mLocaleChanged;
  //added by hwang072 for Vs740 2010-01-19
    private boolean mIsPortrait;

    private Bundle mSavedInstanceState;

    private DesktopBinder mBinder;
    
    public boolean isInstaceOfTopmenu = false;	//added by kumjoo.hwang for C710 2010-06-03

	// BEGIN: 0002231 deukmo@lge.com 2009-12-03
	// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
      private static final int ALLAPPS_DEFAULT_VISIBLE_GROUPNUM = 0;
	private static final int INITIAL_ALLAPPS_CACHE_CAPACITY = 10;
	private static final int PORT_ALLAPPS_NUM_OF_COLUMNS = 4;
	private static final int LAND_ALLAPPS_NUM_OF_COLUMNS = 5;//added by hwang072 for Vs740 2010-01-03
	private static final int ALLAPPS_DEFAULT_HEIGHT = 136; //modified by hwang072 for Vs740 2010-01-07
	
	private static final String ALLAPPS_GRID_PREFS_NAME = "AllAppsGridData";
	private static final String ALLAPPS_PREFS_NAME = "AllAppsData";
	private static final String TAG_VISIBLE_GROUPNUM = "groupnum";
	private static final String TAG_GROUP_TITLE = "grouptitle";
	private static final String TAG_SHORTCUT_PACKAGENAME = "shortcut_package";
	private static final String TAG_SHORTCUT_CLASSNAME = "shortcut_class";
	private static final String TAG_FAVORITES = "favorites";
	
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
	// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
	static final int ALLAPPS_TOTAL_GROUPNUM = 11 /* 10 */;
	static final int ALLAPPS_EDITABLE_GROUPNUM = 8;
	static final int ALLAPPS_SYSTEMAPP_GROUPID = 8;
	static final int ALLAPPS_DOWNLOAD_GROUPID = 9;
	static final int ALLAPPS_OPERATOR1_GROUPID = 10;	// added
// END LG_UI_HOME yoori.yoo 20100530 
	static final int DEFAULT_GROUPID_MULTIPLIER = 1000;
	static final int ALLAPPS_NEW_ADDED_ITEM_POSITION = DEFAULT_GROUPID_MULTIPLIER - 1;
	
	static final int ALLAPPS_MODE_GRID = 1;
	static final int ALLAPPS_MODE_EDIT = ALLAPPS_MODE_GRID + 1;
	static final int ALLAPPS_MODE_DELETE = ALLAPPS_MODE_EDIT + 1;
	
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge	; R.id.allappstitle10 added
	private static final int[] mAllAppsTitleId = { 
			R.id.allappstitle0, R.id.allappstitle1, R.id.allappstitle2, R.id.allappstitle3,
			R.id.allappstitle4, R.id.allappstitle5, R.id.allappstitle6, R.id.allappstitle7,
			R.id.allappstitle8, R.id.allappstitle9, R.id.allappstitle10 };
// END LG_UI_HOME yoori.yoo 20100530 
	
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	/* private static final int[] mAllAppsDefaultTitleStringId = { R.string.allapps_title0,
			R.string.allapps_title1, R.string.allapps_title2, R.string.allapps_title3, 
			R.string.allapps_title4, R.string.allapps_title5, R.string.allapps_title6, 
			R.string.allapps_title7, R.string.allapps_title8, R.string.allapps_title9 }; */
	
	private static int[] mAllAppsDefaultTitleStringId;
	static {
			mAllAppsDefaultTitleStringId = new int[] {
				R.string.allapps_title0, R.string.allapps_title1, R.string.allapps_title2, R.string.allapps_title3, 
				R.string.allapps_title4, R.string.allapps_title5, R.string.allapps_title6, R.string.allapps_title7,
				R.string.allapps_title8, R.string.allapps_title9, R.string.allspps_new_group_name };
	}
// END LG_UI_HOME yoori.yoo 20100530 
	
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge	; R.id.allappstitle10 added
	private static final int[] mAllAppsGridId = { 
			R.id.allappsgrid0, R.id.allappsgrid1, R.id.allappsgrid2, R.id.allappsgrid3,
			R.id.allappsgrid4, R.id.allappsgrid5, R.id.allappsgrid6, R.id.allappsgrid7,
			R.id.allappsgrid8, R.id.allappsgrid9, R.id.allappsgrid10 };
	private static final boolean[] ALLAPPS_IS_DEFAULT_GROUP = {
		false, false, false, false, false, false, false, false, /* true, true */
		true, false, false	// added
	};
// END LG_UI_HOME yoori.yoo 20100530 
	
	private TextView[] mAllAppsTitleArray = new TextView[ALLAPPS_TOTAL_GROUPNUM];
	private AllAppsGridView[] mAllAppsGridArray = new AllAppsGridView[ALLAPPS_TOTAL_GROUPNUM];
	private String[] mDefaultAllAppsTitleArray = new String[ALLAPPS_TOTAL_GROUPNUM];
	
	private String[] mLoadedAllAppsTitleArray = new String[ALLAPPS_TOTAL_GROUPNUM];
	private HashMap<String, Integer> mUserAllAppsInfo = new HashMap<String, Integer>(INITIAL_ALLAPPS_CACHE_CAPACITY);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	// BEGIN: 0003843 deukmo.koo@lge.com 2010-02-04
	// ADD 0003843: [Swift][LGHome] Add operator category in Top Menu
	private HashMap<String, Integer> mDefaultAllAppsInfo = new HashMap<String, Integer>(INITIAL_ALLAPPS_CACHE_CAPACITY);
	// END: 0003843 deukmo.koo@lge.com 2010-02-04
// END LG_UI_HOME yoori.yoo 20100530 
	
	private int mVisibleGroupNum = ALLAPPS_DEFAULT_VISIBLE_GROUPNUM;
	private int mAllAppsMode = ALLAPPS_MODE_GRID;
	private int mSelectedGroupId;
	private ApplicationInfo mUninstallApplicationInfo;
	
	private ScrollView mScrollView;

// START yoori.yoo 20100829 ; Animation Patch
	private IWindowManager wm ;
    private float savedTransitionAnimationScale ;
// END yoori.yoo 20100829 

	private String[] mCurrentAllAppsGroups;
	private boolean[] mCheckedAllAppsGroups;
	
	private TextView mTotalSize;
	private TextView mApplicationSize;
	private TextView mDataSize;
	private PkgSizeObserver mSizeObserver = new PkgSizeObserver();
	
	private PackageDeleteObserver mPackageDeleteObserver = new PackageDeleteObserver();
    private ProgressDialog mProgressDialog;
    
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
    // BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
	// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
	private static final int POWER_LAUNCHER_SHORTCUT_NUM = 4; //modified by hwang072 2010-05-02 for change UI
	
    private String[] mDefaultPowerLauncherShortcutPackageName = new String[POWER_LAUNCHER_SHORTCUT_NUM /* 4 */];
    private String[] mDefaultPowerLauncherShortcutClassName = new String[POWER_LAUNCHER_SHORTCUT_NUM /* 4 */];
	// private ComponentName[] mPowerLauncherShortcutName = new ComponentName[4];
	private ComponentName[] mPowerLauncherShortcutName = new ComponentName[POWER_LAUNCHER_SHORTCUT_NUM];
    private PowerLauncherShortcutView[] mPowerLauncherShortcutView = new PowerLauncherShortcutView[POWER_LAUNCHER_SHORTCUT_NUM /* 4 */];
    // END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
    private TextView mModeMessage;
    // END: 0002231 deukmo@lge.com 2009-12-03

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
   /* //added by hwang072 for Vs740 2010-02-01
    private LinearLayout mEditeMode_Area;
    private TextView mDoneButton;
    private TextView mRevertButton ;
    private LinearLayout mDeleteMode_Area;
    private TextView mDelete_done_button;
    
    public static boolean mScreen = false; */
    
    // BEGIN: 0004467 deukmo.koo@lge.com 2010-02-27
	// MOD 0004467: [Swift][LGHome] Change the algorithm of selecting home number in LG Home
	static boolean mIsHomeNumberChanged = false;
	// END: 0004467 deukmo.koo@lge.com 2010-02-27
// END LG_UI_HOME yoori.yoo 20100530 
    
    // BEGIN: 0003028 deukmo@lge.com 2010-01-05
    // ADD 0003028: [Swift][LGHome] Modify indicator bar in LGHome
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
    // private int mPreHomeNumber = -1;
    // private ImageView mIndicatorBar;
// END LG_UI_HOME yoori.yoo 20100530 
    // END: 0003028 deukmo@lge.com 2010-01-05
    
    // BEGIN: 0003209 deukmo@lge.com 2010-01-12
    // ADD 0003209: [Swift][LGHome/Launcher] bug fix - AppWidget leakage
    private int mCreateAppWidgetId = -1;
    // END: 0003209 deukmo@lge.com 2010-01-12

// START yoori.yoo 20100907 : Default Manner - Silent
    private AudioManager mAudioManager;
// END yoori.yoo 20100907 

    // BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
	// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm 
	private ImageView[] mIndicator = new ImageView[7];
	// END: 0004008 deukmo.koo@lge.com 2010-02-12

    private boolean isAllAppOpened=false; //Added by hwang072 for bug fix 2010-03-18

    static final String ADD_CALL_PREVIOUS_DIAL = "add_previous_dial";

// START yoori.yoo 20100909 : VS660 Merge for Tom Menu Uninstall
	private int[] isAllAppVisibility = new int[11];
// END yoori.yoo 20100909

	// [eunjeong.lee@lge.com] 2010. 9. 9 directly move to ContactSearch
	private final static String CONTACT_INTENT ="com.android.contacts.action.FILTER_CONTACTS";
	// [eunjeong.lee@lge.com] 2010. 9. 9 End
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
// START yoori.yoo 20100916 : VS660 Merge for SD Card Issue
		LauncherApplication app = ((LauncherApplication)getApplication());
        sModel = app.setLauncher(this);
// END yoori.yoo 20100916
		// BEGIN: 0004467 deukmo.koo@lge.com 2010-03-04
		// MOD 0004467: [Swift][LGHome] Change the algorithm of selecting home number in LG Home
		SharedPreferences nXmlSaveStr = getSharedPreferences(Andy_NewPreference_Activity.HOME_SETTING, 0);
        mHomeNumber = nXmlSaveStr.getInt(Andy_NewPreference_Activity.SET_HOME_NUMBER, getDefaultHomeNumber());
		// END: 0004467 deukmo.koo@lge.com 2010-03-04
// END LG_UI_HOME yoori.yoo 20100530 
        mInflater = getLayoutInflater();

        mAppWidgetManager = AppWidgetManager.getInstance(this);

        mAppWidgetHost = new LauncherAppWidgetHost(this, APPWIDGET_HOST_ID);
        mAppWidgetHost.startListening();

        if (PROFILE_STARTUP) {
            android.os.Debug.startMethodTracing("/sdcard/launcher");
        }
        
        checkForLocaleChange();
        setWallpaperDimension();

        setContentView(R.layout.launcher);
        setupViews();
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	    /* setIndication(mWorkspace.getCurrentScreen());//added by hwang072 for bug fix 2010-02-27
		
        // BEGIN: 0002822 taesu84.kim@lge.com 2009-12-28
		// ADD 0002822: [Swift][Launcher] home indicator bar is synchronized with home screen when it is rebooted & dialog errors in home settings
		SharedPreferences nXmlSaveStr = getSharedPreferences(Andy_NewPreference_Activity.HOME_SETTING, 0);
        // BEGIN: 0002960 taesu84.kim@lge.com 2010-01-02
        // MOD 0002960: [Swift][Launcher] modify the number of default screen & theme title
        int homeNumber = nXmlSaveStr.getInt(Andy_NewPreference_Activity.SET_HOME_NUMBER, 5);
        // END: 0002960 taesu84.kim@lge.com 2010-01-02
        setHomeNumber(homeNumber);
        // END: 0002822 taesu84.kim@lge.com 2009-12-28 */

		// BEGIN: 0003843 deukmo.koo@lge.com 2010-02-04
		// ADD 0003843: [Swift][LGHome] Add operator category in Top Menu
		loadDefaultAllAppsInfo();
		// END: 0003843 deukmo.koo@lge.com 2010-02-04
// END LG_UI_HOME yoori.yoo 20100530 
		
		
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        loadAllAppsData();
        setupAllAppsViews();
        setupPowerLauncherView();
        // END: 0002231 deukmo@lge.com 2009-12-03
        registerIntentReceivers();
        registerContentObservers();

        mSavedState = savedInstanceState;
        restoreState(mSavedState);
        
// START yoori.yoo 20101025 Idle Focus Issue(navi key)        
        setAllAppsGridFocus();
// END yoori.yoo 20101025         

        if (PROFILE_STARTUP) {
            android.os.Debug.stopMethodTracing();
        }

        if (!mRestoring) {
            startLoaders();
        }

        // For handling default keys
        mDefaultKeySsb = new SpannableStringBuilder();
        Selection.setSelection(mDefaultKeySsb, 0);
    }
    
// START yoori.yoo 20101025 Idle Focus Issue(navi key)      
    private void setAllAppsGridFocus() {
    	for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
    		if(isAllAppOpened)
    			mAllAppsGridArray[i].setFocusable(true);
    		else
    			mAllAppsGridArray[i].setFocusable(false);
    	}
    }
// END yoori.yoo 20101025
    	
    private void checkForLocaleChange() {
        final LocaleConfiguration localeConfiguration = new LocaleConfiguration();
        readConfiguration(this, localeConfiguration);
        
        final Configuration configuration = getResources().getConfiguration();

        final String previousLocale = localeConfiguration.locale;
        final String locale = configuration.locale.toString();

        final int previousMcc = localeConfiguration.mcc;
        final int mcc = configuration.mcc;

        final int previousMnc = localeConfiguration.mnc;
        final int mnc = configuration.mnc;

        mLocaleChanged = !locale.equals(previousLocale) || mcc != previousMcc || mnc != previousMnc;

        if (mLocaleChanged) {
            localeConfiguration.locale = locale;
            localeConfiguration.mcc = mcc;
            localeConfiguration.mnc = mnc;

            writeConfiguration(this, localeConfiguration);
        }
    }

    private static class LocaleConfiguration {
        public String locale;
        public int mcc = -1;
        public int mnc = -1;
    }
    
    private static void readConfiguration(Context context, LocaleConfiguration configuration) {
        DataInputStream in = null;
        try {
            in = new DataInputStream(context.openFileInput(PREFERENCES));
            configuration.locale = in.readUTF();
            configuration.mcc = in.readInt();
            configuration.mnc = in.readInt();
        } catch (FileNotFoundException e) {
            // Ignore
        } catch (IOException e) {
            // Ignore
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    // Ignore
                }
            }
        }
    }

    private static void writeConfiguration(Context context, LocaleConfiguration configuration) {
        DataOutputStream out = null;
        try {
            out = new DataOutputStream(context.openFileOutput(PREFERENCES, MODE_PRIVATE));
            out.writeUTF(configuration.locale);
            out.writeInt(configuration.mcc);
            out.writeInt(configuration.mnc);
            out.flush();
        } catch (FileNotFoundException e) {
            // Ignore
        } catch (IOException e) {
            //noinspection ResultOfMethodCallIgnored
            context.getFileStreamPath(PREFERENCES).delete();
        } finally {
            if (out != null) {
                try {
                    out.close();
                } catch (IOException e) {
                    // Ignore
                }
            }
        }
    }

    static int getScreen() {
        synchronized (sLock) {
            return sScreen;
        }
    }

    static void setScreen(int screen) {
        synchronized (sLock) {
            sScreen = screen;
        }
    }

// START yoori.yoo 20100916 : VS660 Merge for SD Card Issue
    /* private */ public void startLoaders() {
// END yoori.yoo 20100916
        boolean loadApplications = sModel.loadApplications(true, this, mLocaleChanged);
        sModel.loadUserItems(!mLocaleChanged, this, mLocaleChanged, loadApplications);
        
        // BEGIN: 0002231 deukmo@lge.com 2010-01-08
	    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        if(!loadApplications) {
        	checkDownloadCategory();
        }
        // END: 0002231 deukmo@lge.com 2010-01-08

        mRestoring = false;
    }

    private void setWallpaperDimension() {
        WallpaperManager wpm = (WallpaperManager)getSystemService(WALLPAPER_SERVICE);

        Display display = getWindowManager().getDefaultDisplay();
        boolean isPortrait = display.getWidth() < display.getHeight();

        final int width = isPortrait ? display.getWidth() : display.getHeight();
        final int height = isPortrait ? display.getHeight() : display.getWidth();
        wpm.suggestDesiredDimensions(width * WALLPAPER_SCREENS_SPAN, height);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        mWaitingForResult = false;

        // The pattern used here is that a user PICKs a specific application,
        // which, depending on the target, might need to CREATE the actual target.

        // For example, the user would PICK_SHORTCUT for "Music playlist", and we
        // launch over to the Music app to actually CREATE_SHORTCUT.

        if (resultCode == RESULT_OK && mAddItemCellInfo != null) {
            switch (requestCode) {
                case REQUEST_PICK_APPLICATION:
                    completeAddApplication(this, data, mAddItemCellInfo, !mDesktopLocked);
                    break;
                case REQUEST_PICK_SHORTCUT:
                    processShortcut(data, REQUEST_PICK_APPLICATION, REQUEST_CREATE_SHORTCUT);
                    break;
                case REQUEST_CREATE_SHORTCUT:
                    completeAddShortcut(data, mAddItemCellInfo, !mDesktopLocked);
                    break;
                case REQUEST_PICK_LIVE_FOLDER:
                    addLiveFolder(data);
                    break;
                case REQUEST_CREATE_LIVE_FOLDER:
                    completeAddLiveFolder(data, mAddItemCellInfo, !mDesktopLocked);
                    break;
                case REQUEST_PICK_APPWIDGET:
                    addAppWidget(data);
                    break;
                case REQUEST_CREATE_APPWIDGET:
                    completeAddAppWidget(data, mAddItemCellInfo, !mDesktopLocked);
                    break;
            }
        } else if ((requestCode == REQUEST_PICK_APPWIDGET ||
                requestCode == REQUEST_CREATE_APPWIDGET) && resultCode == RESULT_CANCELED &&
                data != null) {
            // Clean up the appWidgetId if we canceled
            int appWidgetId = data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);
            if (appWidgetId != -1) {
                mAppWidgetHost.deleteAppWidgetId(appWidgetId);
            }
        }
    }

	
	
    @Override
    protected void onResume() {
        super.onResume();
/* 20101117 framework not merged yet
// 20101027 roy.roh@lge.com to avoid rotating when org.jraf.android.nolock.apk is being executed [START]
		final Configuration configuration = getResources().getConfiguration();
		if (configuration.hardKeyboardHidden == Configuration.HARDKEYBOARDHIDDEN_YES) {
			if (configuration.orientation == configuration.ORIENTATION_LANDSCAPE) {
				wm = IWindowManager.Stub.asInterface(ServiceManager.getService("window"));
				try {
					 wm.setRequestOrientation();
					 wm.setRotation(0, true, 0);					 
				 } catch (SecurityException e) {
				 } catch (RemoteException e) {
				 }
			}
		}
// 20101027 roy.roh@lge.com to avoid rotating when org.jraf.android.nolock.apk is being executed [END]
*/
//block db err		
// START yoori.yoo 20100829 ; Animation Patch
/*		wm = IWindowManager.Stub.asInterface(ServiceManager.getService("window"));
		try {
			savedTransitionAnimationScale = wm.getAnimationScale(1) ;
			wm.setAnimationScale(1, 0.0f);
		} catch(Exception e){
			e.printStackTrace() ;
		}
*/		
// END yoori.yoo 20100829 
//block db err		

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	/* // BEGIN: 0002816 taesu84.kim@lge.com 2009-12-28
	// MOD 0002816: [Swift][Launcher] indication bar is sychronized with home screen

	//blocked by hwang072 for bug fix 2010-02-27
	/*if((homePressed && this.hasWindowFocus()))
		setIndication(3); 
	    else
		setIndication(mWorkspace.getCurrentScreen());*/
	// END: 0002816 taesu84.kim@lge.com 2009-12-28
		/* setWorkspaceNum(mHomeNumber, true);
		
		if(mScreen){
			mWorkspace.setCurrentScreen(3);
			mScreen=false;
		} */
		// BEGIN: 0004467 deukmo.koo@lge.com 2010-02-27
		// MOD 0004467: [Swift][LGHome] Change the algorithm of selecting home number in LG Home
		SharedPreferences nXmlSaveStr = getSharedPreferences(Andy_NewPreference_Activity.HOME_SETTING, 0);
        mHomeNumber = nXmlSaveStr.getInt(Andy_NewPreference_Activity.SET_HOME_NUMBER, getDefaultHomeNumber());
        
        initWorkspace();
		
		if(mIsHomeNumberChanged){
			mWorkspace.setCurrentScreen(3);
			mIsHomeNumberChanged = false;
		}
		// END: 0004467 deukmo.koo@lge.com 2010-02-27
		
		// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
		// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
		setIndicatorPosition(mWorkspace.getCurrentScreen());
		// END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
			
        if (mRestoring) {
            startLoaders();
        }
        
// START yoori.yoo 20100922 : back to previous screen
        setScreenAtOnPause(mWorkspace.getCurrentScreen());
// END yoori.yoo 20100922
        
// START LG_UI_HOME yoori.yoo 20100722 FROYO merge
        /* // If this was a new intent (i.e., the mIsNewIntent flag got set to true by
        // onNewIntent), then close the search dialog if needed, because it probably
        // came from the user pressing 'home' (rather than, for example, pressing 'back').
        if (mIsNewIntent) {
            // Post to a handler so that this happens after the search dialog tries to open
            // itself again.
            mWorkspace.post(new Runnable() {
                public void run() {
                    ISearchManager searchManagerService = ISearchManager.Stub.asInterface(
                            ServiceManager.getService(Context.SEARCH_SERVICE));
                    try {
                        searchManagerService.stopSearch();
                    } catch (RemoteException e) {
                        e(LOG_TAG, "error stopping search", e);
                    }    
                }
            });
        }
        
        mIsNewIntent = false;
// START LG_UI_HOME yoori.yoo 20100702 C710(0628) merge
        //modfied by shinbae.lee for bug fix 2010-06-16
        stopSearch();
// END LG_UI_HOME yoori.yoo 20100702 */
// END LG_UI_HOME yoori.yoo 20100722 
        
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		/* // BEGIN: 0002816 taesu84.kim@lge.com 2009-12-28
		// ADD 0002816: [Swift][Launcher] indication bar is sychronized with home screen
		homePressed = false;
		// END: 0002816 taesu84.kim@lge.com 2009-12-28 */
// END LG_UI_HOME yoori.yoo 20100530 
	}

	@Override
	protected void onPause() {
		super.onPause();
//block db err		
// START yoori.yoo 20100829 ; Animation Patch
/*
		wm = IWindowManager.Stub.asInterface(ServiceManager.getService("window"));
		try {
			wm.setAnimationScale(1, savedTransitionAnimationScale);
		} catch(Exception e) {
			e.printStackTrace() ;
		}
*/		
// END yoori.yoo 20100829 
//block db err		

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		/* // BEGIN: 0002816 taesu84.kim@lge.com 2009-12-28
		// ADD 0002816: [Swift][Launcher] indication bar is sychronized with home screen
		homePressed = true;
		// END: 0002816 taesu84.kim@lge.com 2009-12-28 */
// END LG_UI_HOME yoori.yoo 20100530 
		
		// BEGIN: 0002517 deukmo@lge.com 2009-12-14
        // DEL 0002517: [Swift][TopMenu] Menu close issue when an application is launched
		//closeDrawer(false);
		// END: 0002517 deukmo@lge.com 2009-12-14
		mDragLayer.cancelDrag(); //added by hwang072 for bug fix 2010-03-16
// START yoori.yoo 20100922 : back to previous screen
		setScreenAtOnPause(mWorkspace.getCurrentScreen());
// END yoori.yoo 20100922
	}
	
// START yoori.yoo 20100922 : back to previous screen
	public int getScreenAtOnPause() {
		return screenAtOnPause;
	}
	
	public void setScreenAtOnPause(int screen) {
		screenAtOnPause = screen;
	}
// END yoori.yoo 20100922
	
    @Override
    public Object onRetainNonConfigurationInstance() {
        // Flag any binder to stop early before switching
        if (mBinder != null) {
            mBinder.mTerminate = true;
        }

        if (PROFILE_ROTATE) {
            android.os.Debug.startMethodTracing("/sdcard/launcher-rotate");
        }
        return null;
    }

    private boolean acceptFilter() {
        final InputMethodManager inputManager = (InputMethodManager)
                getSystemService(Context.INPUT_METHOD_SERVICE);
        return !inputManager.isFullscreenMode();
    }


	public void releaseTextKeyListener()
	{
		TextKeyListener.getInstance().clear(mDefaultKeySsb);
		MetaKeyKeyListener.resetMetaState(mDefaultKeySsb); 
		clearTypedText();
	}

	public boolean gotoDial(int keyCode, KeyEvent event )
	{
		if ((keyCode >= KeyEvent.KEYCODE_0 && keyCode <= KeyEvent.KEYCODE_9)
			|| (keyCode >= KeyEvent.KEYCODE_A && keyCode <= KeyEvent.KEYCODE_Z))
		{
			String initialQuery = getTypedText();
			
			if (keyCode >= KeyEvent.KEYCODE_0 && keyCode <= KeyEvent.KEYCODE_9)
			{
				if(Settings.System.getInt(getContentResolver(), Settings.System.NUMBER_KEYS_DIAL_A_NUMBER, 1) == 1) {
				
                        if(phoneIsInUse()) {                        
                            Intent intent = new Intent("android.intent.action.MAIN");
                            intent.setPackage("com.android.phone");
                            intent.setClassName("com.android.phone", "com.android.phone.InCallScreen");
                            releaseTextKeyListener();     
                            gotoInCallScreenWithDial(intent, "" + (keyCode - KeyEvent.KEYCODE_0));
                        } else {
                            Intent intent = new Intent("android.intent.action.MAIN");
                            intent.setPackage("com.android.contacts");
                            intent.setClassName("com.android.contacts", "com.android.contacts.DialtactsActivity");
                            intent.putExtra(ADD_CALL_PREVIOUS_DIAL, "" + (keyCode - KeyEvent.KEYCODE_0));
                            releaseTextKeyListener();
                            startActivitySafely(intent);
                        }
                        return true;
                    }
			}	
			else if((keyCode >= KeyEvent.KEYCODE_A && keyCode <= KeyEvent.KEYCODE_Z)){
				if(Settings.System.getInt(getContentResolver(), Settings.System.QWERTY_KEYS_SEARCH_CONTACTS, 1) == 1)
	    			{
				Intent contactSearch = new Intent();
				contactSearch.setData(Uri.withAppendedPath(Uri.parse("content://com.android.contacts"),"contacts"));
				contactSearch.setAction(CONTACT_INTENT);
				contactSearch.putExtra("com.android.contacts.extra.FILTER_TEXT", initialQuery);
				releaseTextKeyListener();
				startActivity(contactSearch);
				return true;
					}
			}		
		}
		
		return false;
	}

	
	public boolean gotoDialUpDownKey(int keyCode, KeyEvent event , boolean isKeyDown)
	{

		if(isKeyDown == true)
		{
		
			if(keyCode == KeyEvent.KEYCODE_Z) 
			{
				return true;
			}
			return gotoDial(keyCode,event);
		}
		else
		{
			if(keyCode == KeyEvent.KEYCODE_Z )
			{
				return gotoDial(keyCode,event);
			}
			else
			{
				releaseTextKeyListener();
				return true;
			}
		}

	}

	public boolean gotoMannerMode(int keyCode, KeyEvent event)
	{
		if((keyCode == KeyEvent.KEYCODE_Z) && event.isLongPress())
		{
			releaseTextKeyListener();
			mAudioManager = (AudioManager)this.getSystemService(Context.AUDIO_SERVICE);
			boolean mannerMode = mAudioManager.setMannerRingerMode(getContentResolver());
			return true;
		}
		
		if((keyCode == KeyEvent.KEYCODE_Z) && event.getRepeatCount()> 1)
		{
			releaseTextKeyListener();
			return true;
		}

		return false; 

	}

    @Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		boolean handled = super.onKeyUp(keyCode, event);

		if (!handled && acceptFilter() && keyCode == KeyEvent.KEYCODE_Z) 
		{
			if (mDefaultKeySsb != null && mDefaultKeySsb.length() > 0  && !(getTypedText().equals(""))) 
			{
				if(gotoDialUpDownKey(keyCode,event , false) == false) 
				{
					return onSearchRequested();
				}
			}

			return true;
		}

		return handled;

	}



    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
// START yoori.yoo 20100915 : release focus on item when folder opened/closed
    	mWorkspace.setFocusable(false);
// END yoori.yoo 20100915	

		int ret = 0;
		boolean handled = super.onKeyDown(keyCode, event);

		if(gotoMannerMode(keyCode,event))
		{
			return true;
		}
		
		if (!handled && acceptFilter() && keyCode != KeyEvent.KEYCODE_ENTER)
		{
			boolean gotKey = TextKeyListener.getInstance().onKeyDown(mWorkspace, mDefaultKeySsb,keyCode, event);
			if (gotKey && mDefaultKeySsb != null && mDefaultKeySsb.length() > 0)
			{
				if(gotoDialUpDownKey(keyCode,event , true)== false)
				{
					return onSearchRequested();
				}
			}
		}

//[10/06/04 LG_UI_AVR dongsoojang VS760] voicecommand button
//start
/*[LG_UI_AVR dongsoo.jang 100819 removed since it's not intuitive to user after talked with UIP]
		if (keyCode == KeyEvent.KEYCODE_BACK&& event.isLongPress()) {	          
			Configuration config = getResources().getConfiguration();
			if (config.hardKeyboardHidden == 2){	//external
				// Launch voice dialer
				Intent intent = new Intent(Intent.ACTION_VOICE_COMMAND);
				intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				
				try {
						d(LOG_TAG, "Launcher.java in LGHome_KEYCODE_BACK");
						startActivity(intent);
				} catch (ActivityNotFoundException e) {
					d(LOG_TAG, "Launcher.java in LGHome_KEYCODE_BACK", e);
				}
			}
			return true;         
		}    
*/		
//end LG_UI_AVR 		


        return handled;
    }


    private String getTypedText() {
        return mDefaultKeySsb.toString();
    }

    private void clearTypedText() {
        mDefaultKeySsb.clear();
        mDefaultKeySsb.clearSpans();
        Selection.setSelection(mDefaultKeySsb, 0);
    }

    /**
     * Restores the previous state, if it exists.
     *
     * @param savedState The previous state.
     */
    private void restoreState(Bundle savedState) {
        if (savedState == null) {
            return;
        }

        final int currentScreen = savedState.getInt(RUNTIME_STATE_CURRENT_SCREEN, -1);
        if (currentScreen > -1) {
            mWorkspace.setCurrentScreen(currentScreen);
        }

        final int addScreen = savedState.getInt(RUNTIME_STATE_PENDING_ADD_SCREEN, -1);
        if (addScreen > -1) {
            mAddItemCellInfo = new CellLayout.CellInfo();
            final CellLayout.CellInfo addItemCellInfo = mAddItemCellInfo;
            addItemCellInfo.valid = true;
            addItemCellInfo.screen = addScreen;
            addItemCellInfo.cellX = savedState.getInt(RUNTIME_STATE_PENDING_ADD_CELL_X);
            addItemCellInfo.cellY = savedState.getInt(RUNTIME_STATE_PENDING_ADD_CELL_Y);
            addItemCellInfo.spanX = savedState.getInt(RUNTIME_STATE_PENDING_ADD_SPAN_X);
            addItemCellInfo.spanY = savedState.getInt(RUNTIME_STATE_PENDING_ADD_SPAN_Y);
            addItemCellInfo.findVacantCellsFromOccupied(
                    savedState.getBooleanArray(RUNTIME_STATE_PENDING_ADD_OCCUPIED_CELLS),
                    savedState.getInt(RUNTIME_STATE_PENDING_ADD_COUNT_X),
                    savedState.getInt(RUNTIME_STATE_PENDING_ADD_COUNT_Y));
            mRestoring = true;
        }

        boolean renameFolder = savedState.getBoolean(RUNTIME_STATE_PENDING_FOLDER_RENAME, false);
        if (renameFolder) {
            long id = savedState.getLong(RUNTIME_STATE_PENDING_FOLDER_RENAME_ID);
            mFolderInfo = sModel.getFolderById(this, id);
            mRestoring = true;
        }

      //added by hwang072 for Vs740 2010-01-08
	  final int reameCategory = savedState.getInt(RUNTIME_STATE_ALLAPPS_CATEGORY_RENAME_ID, -1);
	 if(reameCategory>0){
	 	mSelectedGroupId=reameCategory;
	 	}

	 //added by hwang072 for Vs740 2010-01-09
	 final ApplicationInfo uninstallApplicationInfo= savedState.getParcelable(RUNTIME_STATE_UNINSTALL_APP_INFO);
	 if(uninstallApplicationInfo!=null){
	 	mUninstallApplicationInfo=uninstallApplicationInfo;
	 	}

	 //added by hwang072 for Vs740 2010-01-13
	 final boolean[] checkedAllAppsGroups= savedState.getBooleanArray(RUNTIME_STATE_DELETE_CHECKED_ID);
	 if(checkedAllAppsGroups!=null){
	 	mCheckedAllAppsGroups=checkedAllAppsGroups;
	 	}

	//Added by hwang072 for bug fix 2010-03-18
	 final boolean isopened= savedState.getBoolean(RUNTIME_STATE_ALL_APPS_ISOPENED);	
	 	isAllAppOpened=isopened;
	 
// START yoori.yoo 20100830 : VVM Icon Update 
		mUnreadVvms = savedState.getInt("mUnreadVvms", 0);
// END yoori.yoo 20100830    

// START yoori.yoo 20100910 : Tom Menu Uninstall
		isAllAppVisibility = savedState.getIntArray("isAllAppVisibility");
		mAllAppsMode = savedState.getInt("mAllAppsMode");
// END yoori.yoo 20100910 
	}
	
	
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
    // BEGIN: 0003843 deukmo.koo@lge.com 2010-02-04
	// ADD 0003843: [Swift][LGHome] Add operator category in Top Menu
    private void loadDefaultAllAppsInfo() {
		try {
            XmlResourceParser parser = getResources().getXml(R.xml.default_allapps);
            AttributeSet attrs = Xml.asAttributeSet(parser);
            XmlUtils.beginDocument(parser, TAG_FAVORITES);

            final int depth = parser.getDepth();

            int type;
            while (((type = parser.next()) != XmlPullParser.END_TAG ||
                    parser.getDepth() > depth) && type != XmlPullParser.END_DOCUMENT) {

                if (type != XmlPullParser.START_TAG) {
                    continue;
                }
                
                TypedArray a = obtainStyledAttributes(attrs, R.styleable.Favorite);
                final int grid = a.getInt(R.styleable.Favorite_grid, -1);
                final int position = a.getInt(R.styleable.Favorite_position, ALLAPPS_NEW_ADDED_ITEM_POSITION);
                
                if(grid>=0 && grid<ALLAPPS_TOTAL_GROUPNUM) {
                	mDefaultAllAppsInfo.put(
                			a.getString(R.styleable.Favorite_packageName) + "/" + a.getString(R.styleable.Favorite_className),
                			grid*DEFAULT_GROUPID_MULTIPLIER + position);
                }
                
                a.recycle();
            }
        } catch (XmlPullParserException e) {
            w(LOG_TAG, "Got exception parsing launcher shortcuts.", e);
        } catch (IOException e) {
            w(LOG_TAG, "Got exception parsing launcher shortcuts.", e);
        }
	}
	
	HashMap<String, Integer> getDefaultAllAppsInfo() {
		return mDefaultAllAppsInfo;
	}
	// END: 0003843 deukmo.koo@lge.com 2010-02-04
// END LG_UI_HOME yoori.yoo 20100530 
    
	// BEGIN: 0002231 deukmo@lge.com 2009-12-03
	// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	private void loadAllAppsData() {
	    final SharedPreferences userAllAppsInfo = getSharedPreferences(ALLAPPS_GRID_PREFS_NAME, MODE_PRIVATE);
	    mUserAllAppsInfo.putAll((Map<String, Integer>) userAllAppsInfo.getAll());
    }
	
	HashMap<String, Integer> getUserAllAppsInfo() {
		return mUserAllAppsInfo;
	}
	
	private void setupAllAppsViews() {
		final TextView[] allAppsTitleArray = mAllAppsTitleArray;
	    final AllAppsGridView[] allAppsGridArray = mAllAppsGridArray;
	    final String[] defaultAllAppsTitleArray = mDefaultAllAppsTitleArray;
	    final String[] loadedAllAppsTitleArray = mLoadedAllAppsTitleArray;
	    final int[] allAppsDefaultTitleStringId = mAllAppsDefaultTitleStringId;
	    
	    final SharedPreferences userAllAppsTitleInfo = getSharedPreferences(ALLAPPS_PREFS_NAME, MODE_PRIVATE);
	    final SharedPreferences.Editor userAllAppsTitleInfoEditor = userAllAppsTitleInfo.edit();
	    
	    int visibleGroupNum = userAllAppsTitleInfo.getInt(TAG_VISIBLE_GROUPNUM, -1);
	    if(visibleGroupNum<0) {
	    	userAllAppsTitleInfoEditor.putInt(TAG_VISIBLE_GROUPNUM, ALLAPPS_DEFAULT_VISIBLE_GROUPNUM);
	    	visibleGroupNum = ALLAPPS_DEFAULT_VISIBLE_GROUPNUM;
	    }
	    mVisibleGroupNum = visibleGroupNum; 
	    
	    String groupTitle;
	    for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
	    	defaultAllAppsTitleArray[i] = getResources().getString(allAppsDefaultTitleStringId[i]);
	    	
	    	groupTitle = userAllAppsTitleInfo.getString(TAG_GROUP_TITLE+i, mDefaultAllAppsTitleArray[i]);
	    	loadedAllAppsTitleArray[i] = groupTitle;
	    	allAppsTitleArray[i].setText(groupTitle);
	    	
	    	// BEGIN: 0003247 deukmo@lge.com 2010-01-13
	    	// MOD 0003247: [Swift][TopMenu] Change new category order
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	    	// BEGIN: 0004128 deukmo.koo@lge.com 2010-02-16
			// MOD 0004128: [Swift][TopMenu] Change initial visibility in Top Menu
	    	// if(i>=(ALLAPPS_EDITABLE_GROUPNUM-visibleGroupNum)) {
	    	if((i<ALLAPPS_EDITABLE_GROUPNUM && i>=(ALLAPPS_EDITABLE_GROUPNUM-visibleGroupNum)) || ALLAPPS_IS_DEFAULT_GROUP[i]) {
// END LG_UI_HOME yoori.yoo 20100530 
	    		allAppsTitleArray[i].setVisibility(View.VISIBLE);
	    		allAppsGridArray[i].setVisibility(View.VISIBLE);
	    	} else {
	    		allAppsTitleArray[i].setVisibility(View.GONE);
	    		allAppsGridArray[i].setVisibility(View.GONE);
	    	}
	    	// END: 0004128 deukmo.koo@lge.com 2010-02-16
	    	// END: 0003247 deukmo@lge.com 2010-01-13
	    }
	    
	    userAllAppsTitleInfoEditor.commit();
	}
	
	private void setupPowerLauncherView() {
		final SharedPreferences userAllAppsInfo = getSharedPreferences(ALLAPPS_PREFS_NAME, MODE_PRIVATE);
		final ComponentName[] powerLauncherShortcutName = mPowerLauncherShortcutName;
		final PackageManager manager = getPackageManager();
		
		ApplicationInfo info;
		Intent intent;
		ResolveInfo resolveInfo;
		
		try {
            XmlResourceParser parser = getResources().getXml(R.xml.default_powerlauncher);
            AttributeSet attrs = Xml.asAttributeSet(parser);
            XmlUtils.beginDocument(parser, TAG_FAVORITES);

            final int depth = parser.getDepth();

            int type;
            while (((type = parser.next()) != XmlPullParser.END_TAG ||
                    parser.getDepth() > depth) && type != XmlPullParser.END_DOCUMENT) {

                if (type != XmlPullParser.START_TAG) {
                    continue;
                }
                
                TypedArray a = obtainStyledAttributes(attrs, R.styleable.Favorite);
                final int x = a.getInt(R.styleable.Favorite_x, -1);
                
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
                // BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
				// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm 
                // if(x>=0 && x<4) {
                if(x>=0 && x<POWER_LAUNCHER_SHORTCUT_NUM) {
                // END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
                	mDefaultPowerLauncherShortcutPackageName[x] = a.getString(R.styleable.Favorite_packageName);
                	mDefaultPowerLauncherShortcutClassName[x] = a.getString(R.styleable.Favorite_className);
                }
                
                a.recycle();
            }
        } catch (XmlPullParserException e) {
            w(LOG_TAG, "Got exception parsing launcher shortcuts.", e);
        } catch (IOException e) {
            w(LOG_TAG, "Got exception parsing launcher shortcuts.", e);
        }
		
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
		// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm 
		// for(int i=0; i<4; i++) {
		for(int i=0; i<POWER_LAUNCHER_SHORTCUT_NUM; i++) {
		// END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
			final String packageName = userAllAppsInfo.getString(TAG_SHORTCUT_PACKAGENAME+i, mDefaultPowerLauncherShortcutPackageName[i]);
			final String className = userAllAppsInfo.getString(TAG_SHORTCUT_CLASSNAME+i, mDefaultPowerLauncherShortcutClassName[i]);
			powerLauncherShortcutName[i] = new ComponentName(packageName, className);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
			// CurrentpowerLauncherShortcutName[i]=powerLauncherShortcutName[i];//added by hwang072 for Vs740 2010-02-10
// END LG_UI_HOME yoori.yoo 20100530 
			
			info = new ApplicationInfo();
			intent = new Intent();
			intent.setComponent(powerLauncherShortcutName[i]);
			resolveInfo = manager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
			if(resolveInfo==null) {
				powerLauncherShortcutName[i] = new ComponentName(mDefaultPowerLauncherShortcutPackageName[i], mDefaultPowerLauncherShortcutClassName[i]);
				intent.setComponent(powerLauncherShortcutName[i]);
				resolveInfo = manager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
			}
			
			if(resolveInfo!=null) {
				info.icon = Utilities.createIconThumbnail(resolveInfo.activityInfo.loadIcon(manager), this);
				info.setActivity(powerLauncherShortcutName[i],
						Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
				mPowerLauncherShortcutView[i].setApplicationInfo(info);
			}
		}
		sModel.setLauncher(this);	//added by hwang072 for Vs740 2010-02-10
	}
	
	void checkPowerLauncherView() {
		final ComponentName[] powerLauncherShortcutName = mPowerLauncherShortcutName;
		final PackageManager manager = getPackageManager();
		
		ApplicationInfo info;
		Intent intent;
		ResolveInfo resolveInfo;
		
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
		// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm 
		// for(int i=0; i<4; i++) {
		for(int i=0; i<POWER_LAUNCHER_SHORTCUT_NUM; i++) {
		// END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
			info = new ApplicationInfo();
			intent = new Intent();
			intent.setComponent(powerLauncherShortcutName[i]);
			resolveInfo = manager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);

			
			
			if(resolveInfo==null) {
				powerLauncherShortcutName[i] = new ComponentName(mDefaultPowerLauncherShortcutPackageName[i], mDefaultPowerLauncherShortcutClassName[i]);
				intent.setComponent(powerLauncherShortcutName[i]);
				resolveInfo = manager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
			}
			
			if(resolveInfo!=null) {
				info.icon = Utilities.createIconThumbnail(resolveInfo.activityInfo.loadIcon(manager), this);
				info.setActivity(powerLauncherShortcutName[i],
						Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
			//added by hwang072 for Vs740 2010-02-10		
			// if(remvedPackageComponentname.equals(CurrentpowerLauncherShortcutName[i])){
				mPowerLauncherShortcutView[i].setApplicationInfo(info);
			// }
// END LG_UI_HOME yoori.yoo 20100530 

			} else {
				mPowerLauncherShortcutView[i].setApplicationInfo(null);
			}
		}

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// savePowerLauncherShortcut();//added by hwang072 for Vs740 2010-02-10	
// END LG_UI_HOME yoori.yoo 20100530 
	}
	
	void checkDownloadCategory() {
		final ApplicationsAdapter adapter = sModel.getApplicationsAdapter();
		final int count = adapter.getCount();
		
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
		// MOD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm 
		// BEGIN: 0003843 deukmo.koo@lge.com 2010-02-04
		// MOD 0003843: [Swift][LGHome] Add operator category in Top Menu
		ApplicationInfo info;
		Integer position;		// added
		boolean isDownloaded = false;
		boolean isOperator1 = false;	// added
		
		for(int i=0; i<count; i++) {
			info = adapter.getItem(i);
			if(info!=null) {
				/* if(!info.isSystemApplication) {
					isDownloaded = true;
					break;
				} */
				position = mDefaultAllAppsInfo.get(info.intent.getComponent().getPackageName()+"/"+info.intent.getComponent().getClassName());
				if(position==null) {
					position = -1;
				} else {
					position = position / DEFAULT_GROUPID_MULTIPLIER;
				}
				if(!info.isSystemApplication || position==ALLAPPS_DOWNLOAD_GROUPID) {
					isDownloaded = true;
				}
				if(position==ALLAPPS_OPERATOR1_GROUPID) {
					isOperator1 = true;
				}
// END LG_UI_HOME yoori.yoo 20100530 
			}
		}
		
		// END: 0003843 deukmo.koo@lge.com 2010-02-04
		
		if(isDownloaded) {
			mAllAppsTitleArray[ALLAPPS_DOWNLOAD_GROUPID].setVisibility(View.VISIBLE);
			mAllAppsGridArray[ALLAPPS_DOWNLOAD_GROUPID].setVisibility(View.VISIBLE);
		} else {
			mAllAppsTitleArray[ALLAPPS_DOWNLOAD_GROUPID].setVisibility(View.GONE);
			mAllAppsGridArray[ALLAPPS_DOWNLOAD_GROUPID].setVisibility(View.GONE);
		}
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		if(isOperator1) {
			mAllAppsTitleArray[ALLAPPS_OPERATOR1_GROUPID].setVisibility(View.VISIBLE);
			mAllAppsGridArray[ALLAPPS_OPERATOR1_GROUPID].setVisibility(View.VISIBLE);
		} else {
			mAllAppsTitleArray[ALLAPPS_OPERATOR1_GROUPID].setVisibility(View.GONE);
			mAllAppsGridArray[ALLAPPS_OPERATOR1_GROUPID].setVisibility(View.GONE);
		}
		// END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
	}
	
	void resizeAllAppsGridHeight() {
		final AllAppsGridView[] allAppsGridArray = mAllAppsGridArray;
		final Display display = getWindowManager().getDefaultDisplay();
		final boolean isPortrait = display.getWidth() < display.getHeight();
		
		for(int i=0; i<allAppsGridArray.length; i++) {
			final AllAppsGridView allAppsGridView = allAppsGridArray[i];
			final ApplicationsAdapter applicationsAdapter = (ApplicationsAdapter) allAppsGridView.getAdapter();
			
			int height = 0;
			if(applicationsAdapter!=null) {
				final int count = applicationsAdapter.getCount();
				if(isPortrait){
				height = (int) (Math.ceil(count / (double)PORT_ALLAPPS_NUM_OF_COLUMNS)) * ALLAPPS_DEFAULT_HEIGHT;
					}
				else{
				height = (int) (Math.ceil(count /  (double)LAND_ALLAPPS_NUM_OF_COLUMNS)) * ALLAPPS_DEFAULT_HEIGHT;
					}
				
			}
			if(height<ALLAPPS_DEFAULT_HEIGHT) height = ALLAPPS_DEFAULT_HEIGHT;
			
			final ViewGroup.LayoutParams params = allAppsGridView.getLayoutParams();
			if(params!=null) {
				params.height = height;
				allAppsGridView.setLayoutParams(params);
			}
		}
	}
	
	int getAllAppsMode() {
		return mAllAppsMode;
	}
	
	private void setAllAppsMode(int allAppsMode) {
		final int oldAllAppsMode = mAllAppsMode;
		if(allAppsMode==oldAllAppsMode) return;
		
		final AllAppsGridView[] allAppsGridArray = mAllAppsGridArray;
		mAllAppsMode = allAppsMode;
		
		PowerLauncherShortcutView[] powerLauncherShortcutView = mPowerLauncherShortcutView;
		switch(allAppsMode) {
			case ALLAPPS_MODE_GRID:
				mModeMessage.setVisibility(View.GONE);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
				// mEditeMode_Area.setVisibility(View.GONE);//added by hwang072 for Vs740 2010-02-01
				// mDeleteMode_Area.setVisibility(View.GONE);//added by hwang072 for Vs740 2010-02-01
// END LG_UI_HOME yoori.yoo 20100530 
				
				if(oldAllAppsMode==ALLAPPS_MODE_EDIT) {
					doAllAppsDataSave();
					for(int i=0; i<allAppsGridArray.length; i++) {
						allAppsGridArray[i].setOnItemClickListener(allAppsGridArray[i]);
					}
				}
				
				for(int i=0; i<powerLauncherShortcutView.length; i++) {
					powerLauncherShortcutView[i].setOnClickListener(powerLauncherShortcutView[i]);
				}
				
// START yoori.yoo 20100909 : VS660 Merge for Tom Menu Uninstall
				if(oldAllAppsMode == ALLAPPS_MODE_DELETE) {
					sModel.startApplicationsLoaderLocked(Launcher.this, false);
					final ApplicationsAdapter drawerAdapter = sModel.getApplicationsAdapter();
			        final ApplicationsAdapter[] drawerAdapterArray = sModel.getApplicationsAdapterArray();
					deleteBindDrawer(Launcher.this, drawerAdapter, drawerAdapterArray);
					
					for(int i=0; i<drawerAdapterArray.length; i++){
						mAllAppsTitleArray[i].setVisibility(isAllAppVisibility[i]);
						mAllAppsGridArray[i].setVisibility(isAllAppVisibility[i]);
					}
				}
// END yoori.yoo 20100909 
				
				mScrollView.invalidate();
				break;
				
			case ALLAPPS_MODE_EDIT:
				mModeMessage.setText(R.string.allapps_edit_mode_message);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
				// mModeMessage.setTextColor(0xff0000ff);
				mModeMessage.setTextColor(0xff00e4ff);
				mModeMessage.setVisibility(View.VISIBLE);
				// mEditeMode_Area.setVisibility(View.VISIBLE);//added by hwang072 for Vs740 2010-02-01
// END LG_UI_HOME yoori.yoo 20100530 
				
				for(int i=0; i<allAppsGridArray.length; i++) {
					allAppsGridArray[i].setOnItemClickListener(null);
				}
				
				if(oldAllAppsMode==ALLAPPS_MODE_GRID) {
					for(int i=0; i<powerLauncherShortcutView.length; i++) {
						powerLauncherShortcutView[i].setOnClickListener(null);
					}
				}
				
				mScrollView.invalidate();
				break;
				
			case ALLAPPS_MODE_DELETE:
				mModeMessage.setText(R.string.allapps_delete_mode_message);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
				// mModeMessage.setTextColor(0xffff0000);
				mModeMessage.setTextColor(0xffff5555);
				mModeMessage.setVisibility(View.VISIBLE);
				// mDeleteMode_Area.setVisibility(View.VISIBLE);//added by hwang072 for Vs740 2010-02-01
// END LG_UI_HOME yoori.yoo 20100530 
				
				if(oldAllAppsMode==ALLAPPS_MODE_EDIT) {
					doAllAppsDataSave();
					for(int i=0; i<allAppsGridArray.length; i++) {
						allAppsGridArray[i].setOnItemClickListener(allAppsGridArray[i]);
					}
				}
				
				if(oldAllAppsMode==ALLAPPS_MODE_GRID) {
					for(int i=0; i<powerLauncherShortcutView.length; i++) {
						powerLauncherShortcutView[i].setOnClickListener(null);
					}
				}
				
// START yoori.yoo 20100909 : VS660 Merge for Tom Menu Uninstall
				final ApplicationsAdapter drawerAdapter = sModel.getApplicationsAdapter();
		        final ApplicationsAdapter[] drawerAdapterArray = sModel.getApplicationsAdapterArray();
				
				for(int i=0; i<drawerAdapterArray.length; i++) {
					isAllAppVisibility[i] = mAllAppsGridArray[i].getVisibility();
					if(drawerAdapterArray[i].getCount() != 0) {
						int cnt = drawerAdapterArray[i].getCount() -1;
						for(int j=cnt; j>=0; j--) {
							if(drawerAdapterArray[i].getItem(j).isSystemApplication) {
								drawerAdapterArray[i].remove(drawerAdapterArray[i].getItem(j));
							}
						}
 					}
					if(drawerAdapterArray[i].getCount() == 0) {
						mAllAppsTitleArray[i].setVisibility(View.GONE);
	                	mAllAppsGridArray[i].setVisibility(View.GONE);
					}
				}				
				
				deleteBindDrawer(Launcher.this, drawerAdapter, drawerAdapterArray);
				resizeAllAppsGridHeight();
// END yoori.yoo 20100909 
				
				mScrollView.invalidate();
				break;
		}
	}
				
// START yoori.yoo 20100909 : VS660 Merge for Tom Menu Uninstall
	private void deleteBindDrawer(Launcher launcher, ApplicationsAdapter drawerAdapter, ApplicationsAdapter[] drawerAdapterArray) {
		for(int i=0; i<drawerAdapterArray.length; i++) {
        	mAllAppsGridArray[i].setAdapter(drawerAdapterArray[i]);
        }
	}
// END yoori.yoo 20100909 
	
	private void doAllAppsDataSave() {
		final AllAppsGridView[] allAppsGridArray = mAllAppsGridArray;
		
		final SharedPreferences userAllAppsInfo = getSharedPreferences(ALLAPPS_GRID_PREFS_NAME, MODE_PRIVATE);
		final SharedPreferences.Editor editor = userAllAppsInfo.edit();
	    
		editor.clear();
		
		for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
			final int count = allAppsGridArray[i].getCount();
			for(int j=0; j<count; j++) {
				final ApplicationInfo applicationInfo = (ApplicationInfo) allAppsGridArray[i].getItemAtPosition(j);
				applicationInfo.groupid = i;
				applicationInfo.position = j;
			
		//editor.putInt(applicationInfo.intent.getComponent().getClassName(), i*DEFAULT_GROUPID_MULTIPLIER+j);
   	      //mUserAllAppsInfo.put(applicationInfo.intent.getComponent().getClassName(), i*DEFAULT_GROUPID_MULTIPLIER+j);
	        editor.putInt(applicationInfo.intent.getComponent().getPackageName()+"/"+applicationInfo.intent.getComponent().getClassName(), i*DEFAULT_GROUPID_MULTIPLIER+j);
		mUserAllAppsInfo.put(applicationInfo.intent.getComponent().getPackageName()+"/"+applicationInfo.intent.getComponent().getClassName(), i*DEFAULT_GROUPID_MULTIPLIER+j);

			}
		}
		
		editor.commit();
	}
	
	// BEGIN: 0003270 deukmo.koo@lge.com 2010-01-14
    // ADD 0003270: [Swift][TopMenu] Add revert function in Edit mode
	private void revertAllAppsData() {
		final AllAppsGridView[] allAppsGridArray = mAllAppsGridArray;
		
		for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
			int count = allAppsGridArray[i].getCount();
			for(int j=0; j<count; j++) {
				final ApplicationInfo applicationInfo = (ApplicationInfo) allAppsGridArray[i].getItemAtPosition(j);
				if(i!=applicationInfo.groupid) {
					final ApplicationsAdapter sourceAdapter = (ApplicationsAdapter) allAppsGridArray[i].getAdapter();
					final ApplicationsAdapter targetAdapter = (ApplicationsAdapter) allAppsGridArray[applicationInfo.groupid].getAdapter();
					sourceAdapter.remove(applicationInfo);
					targetAdapter.add(applicationInfo);
					
					count--;
					j--;
				}
			}
		}
		
		for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
			ApplicationsAdapter adapter = (ApplicationsAdapter) allAppsGridArray[i].getAdapter();
			//modified by for moyamoya.wonje Vs740 2010-03-03
			adapter.sort(new LauncherModel.ApplicationInfoComparatorForAllApps());
		}
	}
	// END: 0003270 deukmo.koo@lge.com 2010-01-14
	
	void savePowerLauncherShortcut() {
		final PowerLauncherShortcutView[] powerLauncherShortcutView = mPowerLauncherShortcutView;
		ApplicationInfo info;
		String packageName;
		String className;
		
		final SharedPreferences userAllAppsInfo = getSharedPreferences(ALLAPPS_PREFS_NAME, MODE_PRIVATE);
    	final SharedPreferences.Editor userAllAppsInfoEditor = userAllAppsInfo.edit();
		
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
		// ADD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
		// for(int i=0; i<4; i++) {
		for(int i=0; i<powerLauncherShortcutView.length; i++) {
		// END: 0004008 deukmo.koo@lge.com 2010-02-12
// END LG_UI_HOME yoori.yoo 20100530 
			info = powerLauncherShortcutView[i].getApplicationInfo();
			if(info!=null) {
				packageName = info.intent.getComponent().getPackageName();
				className = info.intent.getComponent().getClassName();

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
				//added by hwang072 for Vs740 2010-02-10
				// CurrentpowerLauncherShortcutName[i]=new ComponentName(packageName,className);
// END LG_UI_HOME yoori.yoo 20100530 
			} else {
				packageName = "";
				className = "";
			}
			
			userAllAppsInfoEditor.putString(TAG_SHORTCUT_PACKAGENAME+i, packageName);
			userAllAppsInfoEditor.putString(TAG_SHORTCUT_CLASSNAME+i, className);
		}
		
		userAllAppsInfoEditor.commit();
	}
	// END: 0002231 deukmo@lge.com 2009-12-03

// START yoori.yoo 20100909 : VS660 Merge for Top Menu Home Button
	private void changeMenuHomeButton() {
		if(isAllAppOpened) { 
			// mBottomButton4.setImageDrawable(getResources().getDrawable(R.drawable.home_button));
			mBottomButton4.setBackgroundDrawable(getResources().getDrawable(R.drawable.home_button));
		} else {
			// mBottomButton4.setImageDrawable(getResources().getDrawable(R.drawable.menu_button));
			mBottomButton4.setBackgroundDrawable(getResources().getDrawable(R.drawable.menu_button));
		}
	}
// END yoori.yoo 20100909 

    /**
     * Finds all the views we need and configure them properly.
     */
    private void setupViews() {
        mDragLayer = (DragLayer) findViewById(R.id.drag_layer);
        final DragLayer dragLayer = mDragLayer;
		mWorkspace = (Workspace) dragLayer.findViewById(R.id.workspace);
		final Workspace workspace = mWorkspace;
		
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// mLauncherLayout = (LinearLayout) dragLayer.findViewById(R.id.all_apps);
		mLauncherLayout = (RelativeLayout) dragLayer.findViewById(R.id.bbtn_layout);
		final RelativeLayout launcherLayout = mLauncherLayout;	// added

		// BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
		// MOD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
		final PowerLauncherShortcutView[] powerLauncherShortcutView = mPowerLauncherShortcutView;
		/* powerLauncherShortcutView[0] = (PowerLauncherShortcutView) dragLayer.findViewById(R.id.power_shortcut1);
		powerLauncherShortcutView[1] = (PowerLauncherShortcutView) dragLayer.findViewById(R.id.power_shortcut2);
		powerLauncherShortcutView[2] = (PowerLauncherShortcutView) dragLayer.findViewById(R.id.power_shortcut3);
		powerLauncherShortcutView[3] = (PowerLauncherShortcutView) dragLayer.findViewById(R.id.power_shortcut4); */
		powerLauncherShortcutView[0] = (PowerLauncherShortcutView) launcherLayout.findViewById(R.id.power_shortcut0);
		powerLauncherShortcutView[1] = (PowerLauncherShortcutView) launcherLayout.findViewById(R.id.power_shortcut1);
		powerLauncherShortcutView[2] = (PowerLauncherShortcutView) launcherLayout.findViewById(R.id.power_shortcut2); //added by hwang072 2010-05-02 for change UI
		powerLauncherShortcutView[3] = (PowerLauncherShortcutView) launcherLayout.findViewById(R.id.power_shortcut3);

		/* // 2010-01-22 added by bykong for Indicator - START
		imageViewGroup = new ImageView[]{(ImageView) dragLayer.findViewById(R.id.ImageView01),
		  		  (ImageView) dragLayer.findViewById(R.id.ImageView02),
		  		  (ImageView) dragLayer.findViewById(R.id.ImageView03),
		  		  (ImageView) dragLayer.findViewById(R.id.ImageView04),
		  		  (ImageView) dragLayer.findViewById(R.id.ImageView05)};
		// 2010-01-22 added by bykong for Indicator - END */
/*		mBottomButton4 = (ImageView) dragLayer.findViewById(R.id.allapps_button);
		mBottomButton4.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
			    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
                // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
				switch(mAllAppsMode) {
					case ALLAPPS_MODE_EDIT:
						setAllAppsMode(ALLAPPS_MODE_GRID);
						break;
					case ALLAPPS_MODE_DELETE:
						setAllAppsMode(ALLAPPS_MODE_GRID);
						break;
				}
				mScrollY = mScrollView.getScrollY();
				mDrawer.animateToggle();
				// END: 0002231 deukmo@lge.com 2009-12-23
			}
		});*/ //[VS740] removed by bykong
		
// START yoori.yoo 20100820 : VS740 idle navi issue merge
		// mBottomButton4 = (ImageView) launcherLayout.findViewById(R.id.allapps_button);
		mBottomButton4 = (HandleLayout) dragLayer.findViewById(R.id.allapps_button);
		mBottomButton4.setLauncher(this);
// END yoori.yoo 20100820 
		
// START yoori.yoo 20100909 : VS660 Merge for Top Menu Home Button
		changeMenuHomeButton();
// END yoori.yoo 20100909 
		mBottomButton4.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
			    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
                // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
				setAllAppsMode(ALLAPPS_MODE_GRID);
				mDrawer.animateToggle();
				// END: 0002231 deukmo@lge.com 2009-12-23
// START yoori.yoo 20101025 Idle Focus Issue
				if(isAllAppOpened) {
					for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
						mAllAppsGridArray[i].setFocusable(true);
					}
				} else {
					for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
						mAllAppsGridArray[i].setFocusable(false);
					}
				}
// END yoori.yoo 20101025 
			}
		});
		
	  mIndicator[0] = (ImageView) dragLayer.findViewById(R.id.indicator_dot1);
        mIndicator[1] = (ImageView) dragLayer.findViewById(R.id.indicator_dot2);
        mIndicator[2] = (ImageView) dragLayer.findViewById(R.id.indicator_dot3);
        mIndicator[3] = (ImageView) dragLayer.findViewById(R.id.indicator_dot4);
        mIndicator[4] = (ImageView) dragLayer.findViewById(R.id.indicator_dot5);
        mIndicator[5] = (ImageView) dragLayer.findViewById(R.id.indicator_dot6);
        mIndicator[6] = (ImageView) dragLayer.findViewById(R.id.indicator_dot7);
		// END: 0004008 deukmo.koo@lge.com 2010-02-12
		
	
		// mDrawer = (AlohaSlidingDrawer) dragLayer.findViewById(R.id.drawer);
		mDrawer = (SlidingDrawer) dragLayer.findViewById(R.id.drawer);
		// final AlohaSlidingDrawer drawer = mDrawer;
		final SlidingDrawer drawer = mDrawer;
		
		// mDrawer.setLauncher(this);
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        mScrollView = (ScrollView) drawer.findViewById(R.id.allapps_scrollview);
        final ScrollView allAppsScrollView = mScrollView;
        
        mModeMessage = (TextView) drawer.findViewById(R.id.allapps_mode_message);
        // END: 0002231 deukmo@lge.com 2009-12-03
// END LG_UI_HOME yoori.yoo 20100530 
		
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
        	// mAllAppsTitleArray[i] = (TextView) drawer.findViewById(mAllAppsTitleId[i]);
        	mAllAppsTitleArray[i] = (TextView) allAppsScrollView.findViewById(mAllAppsTitleId[i]);
        	// mAllAppsGridArray[i] = (AllAppsGridView) drawer.findViewById(mAllAppsGridId[i]);
        	mAllAppsGridArray[i] = (AllAppsGridView) allAppsScrollView.findViewById(mAllAppsGridId[i]);
// END LG_UI_HOME yoori.yoo 20100530 
        	final AllAppsGridView allAppsGrid = mAllAppsGridArray[i];
        	allAppsGrid.setFocusable(false);
		
        	allAppsGrid.setDragger(dragLayer);
// START yoori.yoo 20100926 : Patch for Top Menu Focus 
        	allAppsGrid.setLauncher(this, mScrollView);			
// END yoori.yoo 20100926 
        }
        // END: 0002231 deukmo@lge.com 2009-12-03
		
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		/* // BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        mScrollView = (ScrollView) drawer.findViewById(R.id.allapps_scrollview);
        final ScrollView allAppsScrollView = mScrollView;
        
        mModeMessage = (TextView) drawer.findViewById(R.id.allapps_mode_message);
        // END: 0002231 deukmo@lge.com 2009-12-03
        
        //added by hwang072 for Vs740 2010-02-01---------------------
	 mEditeMode_Area = (LinearLayout) drawer.findViewById(R.id.edit_mode_button_area);
	 mDoneButton = (TextView) drawer.findViewById(R.id.done_button);
	 mRevertButton = (TextView) drawer.findViewById(R.id.revert_button);

		mDoneButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				doAllAppsDataSave();
				setAllAppsMode(ALLAPPS_MODE_GRID);	
				}
			});
	
		mRevertButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				revertAllAppsData();
				resizeAllAppsGridHeight();
				setAllAppsMode(ALLAPPS_MODE_GRID);	
				}
			});

	 mDeleteMode_Area = (LinearLayout) drawer.findViewById(R.id.delete_mode_button_area);
	 mDelete_done_button= (TextView) drawer.findViewById(R.id.delete_done_button);
	 
	 mDelete_done_button.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				setAllAppsMode(ALLAPPS_MODE_GRID);	
				}
			});
	//------------------------------------------------------------ */
// END LG_UI_HOME yoori.yoo 20100530 
        final DeleteZone deleteZone = (DeleteZone) dragLayer.findViewById(R.id.delete_zone);
        
        // BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        mHandleView = (View) drawer.findViewById(R.id.all_apps);
        // END: 0002231 deukmo@lge.com 2009-12-23

        drawer.lock();
		final DrawerManager drawerManager = new DrawerManager();
		drawer.setOnDrawerOpenListener(drawerManager);
		drawer.setOnDrawerCloseListener(drawerManager);
		drawer.setOnDrawerScrollListener(drawerManager);
        
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		workspace.setLauncher(this);
		workspace.setOnLongClickListener(this);
		workspace.setDragger(dragLayer);
		// workspace.setLauncher(this);
// END LG_UI_HOME yoori.yoo 20100530 
//		loadWallpaper();

		deleteZone.setLauncher(this);
		deleteZone.setDragController(dragLayer);
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		// deleteZone.setHandle(mLauncherLayout);
		deleteZone.setHandle(launcherLayout);
// END LG_UI_HOME yoori.yoo 20100530 
		// END: 0002231 deukmo@lge.com 2009-12-03
        
        // BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // DEL 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		//dragLayer.setIgnoredDropTarget(grid);
		// END: 0002231 deukmo@lge.com 2009-12-23
		dragLayer.setDragScoller(workspace);
		dragLayer.setDragListener(deleteZone);
		// BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        dragLayer.setLauncher(this);
		dragLayer.setAllAppsScrollView(allAppsScrollView);
        // END: 0002231 deukmo@lge.com 2009-12-23
	}

    /**
     * Creates a view representing a shortcut.
     *
     * @param info The data structure describing the shortcut.
     *
     * @return A View inflated from R.layout.application.
     */
    View createShortcut(ApplicationInfo info) {
        return createShortcut(R.layout.application,
                (ViewGroup) mWorkspace.getChildAt(mWorkspace.getCurrentScreen()), info);
    }

    /**
     * Creates a view representing a shortcut inflated from the specified resource.
     *
     * @param layoutResId The id of the XML layout used to create the shortcut.
     * @param parent The group the shortcut belongs to.
     * @param info The data structure describing the shortcut.
     *
     * @return A View inflated from layoutResId.
     */
    View createShortcut(int layoutResId, ViewGroup parent, ApplicationInfo info) {
        TextView favorite = (TextView) mInflater.inflate(layoutResId, parent, false);
// START yoori.yoo 20100823 : VVM Icon Update
        if ( info != null && info.intent.getComponent() != null && info.intent.getComponent().getClassName() != null)
			((BubbleTextView) favorite).setAppClassName(info.intent.getComponent().getClassName());
// END yoori.yoo 20100823       
        
        if (!info.filtered) {
            info.icon = Utilities.createIconThumbnail(info.icon, this);
            info.filtered = true;
        }

        favorite.setCompoundDrawablesWithIntrinsicBounds(null, info.icon, null, null);
        favorite.setText(info.title);
        favorite.setTag(info);
        favorite.setOnClickListener(this);

        return favorite;
    }

    /**
     * Add an application shortcut to the workspace.
     *
     * @param data The intent describing the application.
     * @param cellInfo The position on screen where to create the shortcut.
     */
    void completeAddApplication(Context context, Intent data, CellLayout.CellInfo cellInfo,
            boolean insertAtFirst) {

	//added by hwang072 for bug fix (dupilicate widget) 2010-03-10
		 if( cellInfo.screen != mWorkspace.getCurrentScreen()){
			 cellInfo = mWorkspace.findAllVacantCellsFromModel();	
		}  
		 
        cellInfo.screen = mWorkspace.getCurrentScreen();
        if (!findSingleSlot(cellInfo)) return;

        final ApplicationInfo info = infoFromApplicationIntent(context, data);
        if (info != null) {
            mWorkspace.addApplicationShortcut(info, cellInfo, insertAtFirst);
        }
    }

    private static ApplicationInfo infoFromApplicationIntent(Context context, Intent data) {
        ComponentName component = data.getComponent();
        PackageManager packageManager = context.getPackageManager();
        ActivityInfo activityInfo = null;
        try {
            activityInfo = packageManager.getActivityInfo(component, 0 /* no flags */);
        } catch (NameNotFoundException e) {
            e(LOG_TAG, "Couldn't find ActivityInfo for selected application", e);
        }

        if (activityInfo != null) {
            ApplicationInfo itemInfo = new ApplicationInfo();

            itemInfo.title = activityInfo.loadLabel(packageManager);
            if (itemInfo.title == null) {
                itemInfo.title = activityInfo.name;
            }

            itemInfo.setActivity(component, Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            itemInfo.icon = activityInfo.loadIcon(packageManager);
            itemInfo.container = ItemInfo.NO_ID;

            return itemInfo;
        }

        return null;
    }

    /**
     * Add a shortcut to the workspace.
     *
     * @param data The intent describing the shortcut.
     * @param cellInfo The position on screen where to create the shortcut.
     * @param insertAtFirst
     */
    private void completeAddShortcut(Intent data, CellLayout.CellInfo cellInfo,
            boolean insertAtFirst) {

	//added by hwang072 for bug fix (dupilicate widget) 2010-03-10
		 if( cellInfo.screen != mWorkspace.getCurrentScreen()){
			 cellInfo = mWorkspace.findAllVacantCellsFromModel();	
		}  

        cellInfo.screen = mWorkspace.getCurrentScreen();
        if (!findSingleSlot(cellInfo)) return;

        final ApplicationInfo info = addShortcut(this, data, cellInfo, false);

        if (!mRestoring) {
            sModel.addDesktopItem(info);

            final View view = createShortcut(info);
            mWorkspace.addInCurrentScreen(view, cellInfo.cellX, cellInfo.cellY, 1, 1, insertAtFirst);
        } else if (sModel.isDesktopLoaded()) {
            sModel.addDesktopItem(info);
        }
    }


    /**
     * Add a widget to the workspace.
     *
     * @param data The intent describing the appWidgetId.
     * @param cellInfo The position on screen where to create the widget.
     */
    private void completeAddAppWidget(Intent data, CellLayout.CellInfo cellInfo,
            boolean insertAtFirst) {

        Bundle extras = data.getExtras();
        int appWidgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);

        if (LOGD) d(LOG_TAG, "dumping extras content="+extras.toString());

        AppWidgetProviderInfo appWidgetInfo = mAppWidgetManager.getAppWidgetInfo(appWidgetId);

        // Calculate the grid spans needed to fit this widget

		//added by hwang072 for bug fix (dupilicate widget) 2010-03-10
		 if( cellInfo.screen != mWorkspace.getCurrentScreen()){
			 cellInfo = mWorkspace.findAllVacantCellsFromModel();	
		}  		
	
        CellLayout layout = (CellLayout) mWorkspace.getChildAt(cellInfo.screen);	
        int[] spans = layout.rectToCell(appWidgetInfo.minWidth, appWidgetInfo.minHeight);

        // Try finding open space on Launcher screen
        final int[] xy = mCellCoordinates;
        if (!findSlot(cellInfo, xy, spans[0], spans[1])) {
            if (appWidgetId != -1) mAppWidgetHost.deleteAppWidgetId(appWidgetId);
            return;
        }

        // Build Launcher-specific widget info and save to database
        LauncherAppWidgetInfo launcherInfo = new LauncherAppWidgetInfo(appWidgetId);
        launcherInfo.spanX = spans[0];
        launcherInfo.spanY = spans[1];

        LauncherModel.addItemToDatabase(this, launcherInfo,
                LauncherSettings.Favorites.CONTAINER_DESKTOP,
                mWorkspace.getCurrentScreen(), xy[0], xy[1], false);

        if (!mRestoring) {
            sModel.addDesktopAppWidget(launcherInfo);

            // Perform actual inflation because we're live
            launcherInfo.hostView = mAppWidgetHost.createView(this, appWidgetId, appWidgetInfo);

            launcherInfo.hostView.setAppWidget(appWidgetId, appWidgetInfo);
            launcherInfo.hostView.setTag(launcherInfo);

            mWorkspace.addInCurrentScreen(launcherInfo.hostView, xy[0], xy[1],
                    launcherInfo.spanX, launcherInfo.spanY, insertAtFirst);
        } else if (sModel.isDesktopLoaded()) {
            sModel.addDesktopAppWidget(launcherInfo);
        }
    }

    public LauncherAppWidgetHost getAppWidgetHost() {
        return mAppWidgetHost;
    }

    static ApplicationInfo addShortcut(Context context, Intent data,
            CellLayout.CellInfo cellInfo, boolean notify) {

        final ApplicationInfo info = infoFromShortcutIntent(context, data);
        LauncherModel.addItemToDatabase(context, info, LauncherSettings.Favorites.CONTAINER_DESKTOP,
                cellInfo.screen, cellInfo.cellX, cellInfo.cellY, notify);

        return info;
    }

    private static ApplicationInfo infoFromShortcutIntent(Context context, Intent data) {
        Intent intent = data.getParcelableExtra(Intent.EXTRA_SHORTCUT_INTENT);
        String name = data.getStringExtra(Intent.EXTRA_SHORTCUT_NAME);
        Bitmap bitmap = data.getParcelableExtra(Intent.EXTRA_SHORTCUT_ICON);

        Drawable icon = null;
        boolean filtered = false;
        boolean customIcon = false;
        ShortcutIconResource iconResource = null;

        if (bitmap != null) {
            icon = new FastBitmapDrawable(Utilities.createBitmapThumbnail(bitmap, context));
            filtered = true;
            customIcon = true;
        } else {
            Parcelable extra = data.getParcelableExtra(Intent.EXTRA_SHORTCUT_ICON_RESOURCE);
            if (extra != null && extra instanceof ShortcutIconResource) {
                try {
                    iconResource = (ShortcutIconResource) extra;
                    final PackageManager packageManager = context.getPackageManager();
                    Resources resources = packageManager.getResourcesForApplication(
                            iconResource.packageName);
                    final int id = resources.getIdentifier(iconResource.resourceName, null, null);
                    icon = resources.getDrawable(id);
                } catch (Exception e) {
                    w(LOG_TAG, "Could not load shortcut icon: " + extra);
                }
            }
        }

        if (icon == null) {
            icon = context.getPackageManager().getDefaultActivityIcon();
        }

        final ApplicationInfo info = new ApplicationInfo();
        info.icon = icon;
        info.filtered = filtered;
        info.title = name;
        info.intent = intent;
        info.customIcon = customIcon;
        info.iconResource = iconResource;

        return info;
    }

    void closeSystemDialogs() {
        getWindow().closeAllPanels();
        
        try {
            dismissDialog(DIALOG_CREATE_SHORTCUT);
            // Unlock the workspace if the dialog was showing
            mWorkspace.unlock();
        } catch (Exception e) {
            // An exception is thrown if the dialog is not visible, which is fine
        }

        try {
            dismissDialog(DIALOG_RENAME_FOLDER);
            // Unlock the workspace if the dialog was showing
            mWorkspace.unlock();
        } catch (Exception e) {
            // An exception is thrown if the dialog is not visible, which is fine
        }
            try {
				dismissDialog(DIALOG_ALLAPPS_ADD_GROUP);
			} catch (Exception e) {
            }
			
			try {
				dismissDialog(DIALOG_ALLAPPS_RENAME_GROUP);
			} catch (Exception e) {
            }
			
			try {
				dismissDialog(DIALOG_ALLAPPS_DELETE_GROUP);
			} catch (Exception e) {
            }
			
			try {
				dismissDialog(DIALOG_ALLAPPS_RESET_GROUP);
			} catch (Exception e) {
            }
			
			try {
				dismissDialog(DIALOG_ALLAPPS_UNINSTALL_APP);
			} catch (Exception e) {
            }
    }
    
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        // Close the menu
        if (Intent.ACTION_MAIN.equals(intent.getAction())) {
            closeSystemDialogs();
            
            // Set this flag so that onResume knows to close the search dialog if it's open,
            // because this was a new intent (thus a press of 'home' or some such) rather than
            // for example onResume being called when the user pressed the 'back' button.
            mIsNewIntent = true;

             //blocked by hwang72 for bug fix 2010-03-15
		 //added by hwang072 for bug fix 2010-02-27
		/* if (!mWorkspace.isDefaultScreenShowing()) {
				 mWorkspace.moveToDefaultScreen();
		}*/

           if ((intent.getFlags() & Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT) !=
                   Intent.FLAG_ACTIVITY_BROUGHT_TO_FRONT) {

                if (!mWorkspace.isDefaultScreenShowing()) {
                    mWorkspace.moveToDefaultScreen();
                }

                closeDrawer();

                final View v = getWindow().peekDecorView();
                if (v != null && v.getWindowToken() != null) {
                    InputMethodManager imm = (InputMethodManager)getSystemService(
                            INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
                }
            } else {
                closeDrawer(false);
            }
        }
    }

// START yoori.yoo 20100922 : back to previous screen
    public boolean getBackToPreviousScreen() {
		return backToPreviousScreen;
	}
	
	public void setBackToPreviousScreen(boolean isBackToPreviousScreen) {
		backToPreviousScreen = isBackToPreviousScreen;
	}
// END yoori.yoo 20100922
	
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        // NOTE: Do NOT do this. Ever. This is a terrible and horrifying hack.
        //
        // Home loads the content of the workspace on a background thread. This means that
        // a previously focused view will be, after orientation change, added to the view
        // hierarchy at an undeterminate time in the future. If we were to invoke
        // super.onRestoreInstanceState() here, the focus restoration would fail because the
        // view to focus does not exist yet.
        //
        // However, not invoking super.onRestoreInstanceState() is equally bad. In such a case,
        // panels would not be restored properly. For instance, if the menu is open then the
        // user changes the orientation, the menu would not be opened in the new orientation.
        //
        // To solve both issues Home messes up with the internal state of the bundle to remove
        // the properties it does not want to see restored at this moment. After invoking
        // super.onRestoreInstanceState(), it removes the panels state.
        //
        // Later, when the workspace is done loading, Home calls super.onRestoreInstanceState()
        // again to restore focus and other view properties. It will not, however, restore
        // the panels since at this point the panels' state has been removed from the bundle.
        //
        // This is a bad example, do not do this.
        //
        // If you are curious on how this code was put together, take a look at the following
        // in Android's source code:
        // - Activity.onRestoreInstanceState()
        // - PhoneWindow.restoreHierarchyState()
        // - PhoneWindow.DecorView.onAttachedToWindow()
        //
        // The source code of these various methods shows what states should be kept to
        // achieve what we want here.

        Bundle windowState = savedInstanceState.getBundle("android:viewHierarchyState");
        SparseArray<Parcelable> savedStates = null;
        int focusedViewId = View.NO_ID;

        if (windowState != null) {
            savedStates = windowState.getSparseParcelableArray("android:views");
            windowState.remove("android:views");
            focusedViewId = windowState.getInt("android:focusedViewId", View.NO_ID);
            windowState.remove("android:focusedViewId");
        }

        super.onRestoreInstanceState(savedInstanceState);

        if (windowState != null) {
            windowState.putSparseParcelableArray("android:views", savedStates);
            windowState.putInt("android:focusedViewId", focusedViewId);
            windowState.remove("android:Panels");
        }

        mSavedInstanceState = savedInstanceState;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putInt(RUNTIME_STATE_CURRENT_SCREEN, mWorkspace.getCurrentScreen());

        final ArrayList<Folder> folders = mWorkspace.getOpenFolders();
        if (folders.size() > 0) {
            final int count = folders.size();
            long[] ids = new long[count];
            for (int i = 0; i < count; i++) {
                final FolderInfo info = folders.get(i).getInfo();
                ids[i] = info.id;
            }
            outState.putLongArray(RUNTIME_STATE_USER_FOLDERS, ids);
        }

        final boolean isConfigurationChange = getChangingConfigurations() != 0;

        // When the drawer is opened and we are saving the state because of a
        // configuration change
        if (mDrawer.isOpened() && isConfigurationChange) {
            outState.putBoolean(RUNTIME_STATE_ALL_APPS_FOLDER, true);
        }

        if (mAddItemCellInfo != null && mAddItemCellInfo.valid && mWaitingForResult) {
            final CellLayout.CellInfo addItemCellInfo = mAddItemCellInfo;
            final CellLayout layout = (CellLayout) mWorkspace.getChildAt(addItemCellInfo.screen);

            outState.putInt(RUNTIME_STATE_PENDING_ADD_SCREEN, addItemCellInfo.screen);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_CELL_X, addItemCellInfo.cellX);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_CELL_Y, addItemCellInfo.cellY);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_SPAN_X, addItemCellInfo.spanX);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_SPAN_Y, addItemCellInfo.spanY);
            outState.putInt(RUNTIME_STATE_PENDING_ADD_COUNT_X, layout.getCountX());
            outState.putInt(RUNTIME_STATE_PENDING_ADD_COUNT_Y, layout.getCountY());
            outState.putBooleanArray(RUNTIME_STATE_PENDING_ADD_OCCUPIED_CELLS,
                   layout.getOccupiedCells());
        }

        if (mFolderInfo != null && mWaitingForResult) {
            outState.putBoolean(RUNTIME_STATE_PENDING_FOLDER_RENAME, true);
            outState.putLong(RUNTIME_STATE_PENDING_FOLDER_RENAME_ID, mFolderInfo.id);
        }

	//added by hwang072 for Vs740 2010-01-08
	if(mSelectedGroupId >0 && mDrawer.isOpened()) {
		 outState.putInt(RUNTIME_STATE_ALLAPPS_CATEGORY_RENAME_ID, mSelectedGroupId);
		}

	//added by hwang072 for Vs740 2010-01-09
	if(mUninstallApplicationInfo != null) {
		outState.putParcelable(RUNTIME_STATE_UNINSTALL_APP_INFO, mUninstallApplicationInfo);
		}
	
	//added by hwang072 for Vs740 2010-01-13
		if(mCheckedAllAppsGroups != null) {
			outState.putBooleanArray(RUNTIME_STATE_DELETE_CHECKED_ID, mCheckedAllAppsGroups);
			}
		
	//Added by hwang072 for bug fix 2010-03-18
	    outState.putBoolean(RUNTIME_STATE_ALL_APPS_ISOPENED, isAllAppOpened);

// START yoori.yoo 20100830 : VVM Icon Update
		outState.putInt("mUnreadVvms", mUnreadVvms);
// END yoori.yoo 20100830

// START yoori.yoo 20100910 : Tom Menu Uninstall
		outState.putIntArray("isAllAppVisibility", isAllAppVisibility);
		outState.putInt("mAllAppsMode", mAllAppsMode);
// END yoori.yoo 20100910
    }

    @Override
    public void onDestroy() {
        mDestroyed = true;

        super.onDestroy();

        try {
            mAppWidgetHost.stopListening();
        } catch (NullPointerException ex) {
            w(LOG_TAG, "problem while stopping AppWidgetHost during Launcher destruction", ex);
        }

		TextKeyListener.getInstance().release();
        
        // BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // DEL 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		//mAllAppsGrid.clearTextFilter();
		//mAllAppsGrid.setAdapter(null);
		// END: 0002231 deukmo@lge.com 2009-12-23
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		for(int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
        	mAllAppsGridArray[i].setAdapter(null);
        }
		// END: 0002231 deukmo@lge.com 2009-12-03
		sModel.unbind();
		sModel.abortLoaders();

        getContentResolver().unregisterContentObserver(mObserver);
        getContentResolver().unregisterContentObserver(mWidgetObserver);
        unregisterReceiver(mApplicationsReceiver);
        unregisterReceiver(mCloseSystemDialogsReceiver);
// START yoori.yoo 20100823 : VVM Icon Update
        unregisterReceiver(mNewVvmIntentReceiver);
// END yoori.yoo 20100823 
// START yoori.yoo 20100906 : Top Menu - End Key - Idle
		unregisterReceiver(mEndKeyEventReceiver);
// END yoori.yoo 20100906 
    }

    @Override
    public void startActivityForResult(Intent intent, int requestCode) {
        if (requestCode >= 0) mWaitingForResult = true;
        super.startActivityForResult(intent, requestCode);
    }

    @Override
    public void startSearch(String initialQuery, boolean selectInitialQuery,
            Bundle appSearchData, boolean globalSearch) {

        closeDrawer(false);

// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
        /* // Slide the search widget to the top, if it's on the current screen,
        // otherwise show the search dialog immediately.
        Search searchWidget = mWorkspace.findSearchWidgetOnCurrentScreen();
        if (searchWidget == null) {
            showSearchDialog(initialQuery, selectInitialQuery, appSearchData, globalSearch);
        } else {
            searchWidget.startSearch(initialQuery, selectInitialQuery, appSearchData, globalSearch);
            // show the currently typed text in the search widget while sliding
            searchWidget.setQuery(getTypedText());
        } */

        if (initialQuery == null) {
            // Use any text typed in the launcher as the initial query
            initialQuery = getTypedText();
            clearTypedText();
        }
        if (appSearchData == null) {
            appSearchData = new Bundle();
            appSearchData.putString(Search.SOURCE, "launcher-search");
        }

        final SearchManager searchManager =
                (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchManager.startSearch(initialQuery, selectInitialQuery, getComponentName(),
            appSearchData, globalSearch);
// END LG_UI_HOME yoori.yoo 20100727 
    }

    /**
     * Show the search dialog immediately, without changing the search widget.
     *
     * @see Activity#startSearch(String, boolean, android.os.Bundle, boolean)
     */
// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
    /* void showSearchDialog(String initialQuery, boolean selectInitialQuery,
            Bundle appSearchData, boolean globalSearch) {

        if (initialQuery == null) {
            // Use any text typed in the launcher as the initial query
            initialQuery = getTypedText();
            clearTypedText();
        }
        if (appSearchData == null) {
            appSearchData = new Bundle();
            appSearchData.putString(SearchManager.SOURCE, "launcher-search");
        }

        final SearchManager searchManager =
                (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        final Search searchWidget = mWorkspace.findSearchWidgetOnCurrentScreen();
        if (searchWidget != null) {
            // This gets called when the user leaves the search dialog to go back to
            // the Launcher.
            searchManager.setOnCancelListener(new SearchManager.OnCancelListener() {
                public void onCancel() {
                    searchManager.setOnCancelListener(null);
                    stopSearch();
                }
            });
        }

        searchManager.startSearch(initialQuery, selectInitialQuery, getComponentName(),
            appSearchData, globalSearch);
    } */
// END LG_UI_HOME yoori.yoo 20100727 

    /**
     * Cancel search dialog if it is open.
     */
// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
    /* void stopSearch() {
        // Close search dialog
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchManager.stopSearch();
        // Restore search widget to its normal position
        Search searchWidget = mWorkspace.findSearchWidgetOnCurrentScreen();
        if (searchWidget != null) {
            searchWidget.stopSearch(false);
        }
    } */
// END LG_UI_HOME yoori.yoo 20100727 

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if (mDesktopLocked && mSavedInstanceState == null) return false;

        super.onCreateOptionsMenu(menu);
        menu.add(MENU_GROUP_ADD, MENU_ADD, 0, R.string.menu_add)
                .setIcon(android.R.drawable.ic_menu_add)
                .setAlphabeticShortcut('A');
        // BEGIN: 0002231 deukmo@lge.com 2009-12-03
        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        menu.add(MENU_GROUP_IDLE, MENU_WALLPAPER_SETTINGS, 0, R.string.menu_wallpaper)
                 .setIcon(R.drawable.ic_menu_picture)
                 .setAlphabeticShortcut('W');
		//ohjisoo@lge.com
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
        // final Intent homeselector = new Intent();
        final Intent homeSettings = new Intent();
// START LG_UI_HOME yoori.yoo 20100708 C710(0705) merge
        // BEGIN: kumjoo.hwang@lge.com 2010-06-14
        // Home screen scenario update 
        homeSettings.putExtra("Home Settings", "Set the number of screens");
        homeSettings.setClass(Launcher.this, Andy_RadioImageListDialog_Activity.class);
// END LG_UI_HOME yoori.yoo 20100708 
        // homeSettings.setClass(Launcher.this, Andy_NewPreference_Activity.class);
        // homeselector.setClassName("com.lge.homeselector", "com.lge.homeselector.HomeSelectorActivity");
        /* menu.add(MENU_GROUP_IDLE, MENU_HOME_SETTINGS, 0, R.string.home_settings_menu_home_select).setIcon(
				R.drawable.ic_menu_homeselector)
				.setIntent(homeselector); */
        menu.add(MENU_GROUP_IDLE, MENU_HOME_SETTINGS, 0, R.string.home_settings).setIcon(
				R.drawable.ic_menu_homesetting)
				.setIntent(homeSettings);
// END LG_UI_HOME yoori.yoo 20100530 
        menu.add(MENU_GROUP_IDLE, MENU_SEARCH, 0, R.string.menu_search)
                .setIcon(R.drawable.ic_menu_search)
                .setAlphabeticShortcut(SearchManager.MENU_KEY);
        menu.add(MENU_GROUP_IDLE, MENU_NOTIFICATIONS, 0, R.string.menu_notifications)
                .setIcon(R.drawable.ic_menu_notifications)
                .setAlphabeticShortcut('N');

        final Intent settings = new Intent(android.provider.Settings.ACTION_SETTINGS);
        settings.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);

        menu.add(MENU_GROUP_IDLE, MENU_SETTINGS, 0, R.string.menu_settings)
                .setIcon(android.R.drawable.ic_menu_preferences).setAlphabeticShortcut('P')
                .setIntent(settings);
        // END: 0002231 deukmo@lge.com 2009-12-03
        
        // BEGIN: 0002231 deukmo@lge.com 2009-12-03
        // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        menu.add(MENU_GROUP_ALLAPPS, MENU_ALLAPPS_ADD_GROUP, 0, R.string.menu_allapps_add_group)
				.setIcon(R.drawable.ic_menu_add_category);
        menu.add(MENU_GROUP_ALLAPPS, MENU_ALLAPPS_DELETE_GROUP, 0, R.string.menu_allapps_delete_group)
				.setIcon(R.drawable.ic_menu_delete_category);
        menu.add(MENU_GROUP_ALLAPPS, MENU_ALLAPPS_RENAME_GROUP, 0, R.string.menu_allapps_rename_group)
				.setIcon(R.drawable.ic_menu_rename_category);
        menu.add(MENU_GROUP_ALLAPPS, MENU_ALLAPPS_EDIT, 0, R.string.menu_allapps_edit)
				.setIcon(R.drawable.ic_menu_move);
	  menu.add(MENU_GROUP_ALLAPPS, MENU_ALLAPPS_DELETE, 0, R.string.menu_allapps_delete)
				.setIcon(R.drawable.ic_menu_uninstall);
        menu.add(MENU_GROUP_ALLAPPS, MENU_ALLAPPS_RESET_GROUP, 0, R.string.menu_allapps_reset_group)
				.setIcon(R.drawable.ic_menu_reset_category);
	    
	    // BEGIN: 0003270 deukmo.koo@lge.com 2010-01-14
        // ADD 0003270: [Swift][TopMenu] Add revert function in Edit mode
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	/* */   menu.add(MENU_GROUP_ALLAPPS_EDIT, MENU_ALLAPPS_EDIT_DONE, 0, R.string.allapps_menu_done)
			.setIcon(R.drawable.ic_menu_edit_done);
        menu.add(MENU_GROUP_ALLAPPS_EDIT, MENU_ALLAPPS_EDIT_REVERT, 0, R.string.allapps_menu_revert)
			// .setIcon(R.drawable.ic_menu_edit_revert); /* */
			.setIcon(R.drawable.ic_menu_uninstall);
// END LG_UI_HOME yoori.yoo 20100530 
		// END: 0003270 deukmo.koo@lge.com 2010-01-14
        // END: 0002231 deukmo@lge.com 2009-12-03
        
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        // BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome

	//modified by hwang072 for bug fix 2010-03-18		
     //   if(isDrawerUp()) {
       if(isAllAppOpened) {		
        	final int allAppsMode = getAllAppsMode();
        	
        	menu.setGroupVisible(MENU_GROUP_ADD, false);
        	menu.setGroupVisible(MENU_GROUP_IDLE, false);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge	; added below
        	if(getAllAppsMode()==ALLAPPS_MODE_EDIT) {
        		menu.setGroupVisible(MENU_GROUP_ALLAPPS, false);
            	menu.setGroupVisible(MENU_GROUP_ALLAPPS_EDIT, true);
        	} else if(getAllAppsMode()==ALLAPPS_MODE_DELETE) {
        		menu.setGroupVisible(MENU_GROUP_ALLAPPS, false);
            	menu.setGroupVisible(MENU_GROUP_ALLAPPS_EDIT, false);
        	} else {
// END LG_UI_HOME yoori.yoo 20100530 
        		menu.setGroupVisible(MENU_GROUP_ALLAPPS, true);
	        	menu.setGroupVisible(MENU_GROUP_ALLAPPS_EDIT, false);
	        	
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
				// if(mVisibleGroupNum<(ALLAPPS_TOTAL_GROUPNUM-2)) {
				if(mVisibleGroupNum<ALLAPPS_EDITABLE_GROUPNUM) {
// END LG_UI_HOME yoori.yoo 20100530 
	        		menu.findItem(MENU_ALLAPPS_ADD_GROUP).setEnabled(true);
	        	} else {
	        		menu.findItem(MENU_ALLAPPS_ADD_GROUP).setEnabled(false);
	        	}
				if(mVisibleGroupNum<=0) {
					menu.findItem(MENU_ALLAPPS_DELETE_GROUP).setEnabled(false);
	        	} else {
	        		menu.findItem(MENU_ALLAPPS_DELETE_GROUP).setEnabled(true);
        	}  
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		/* //added by hwang072 for Vs740 2010-01-04
			if(mVisibleGroupNum<=0) {
				menu.findItem(MENU_ALLAPPS_RENAME_GROUP).setEnabled(false);
        	} else {
        		menu.findItem(MENU_ALLAPPS_RENAME_GROUP).setEnabled(true);
        	} */
// END LG_UI_HOME yoori.yoo 20100530 
			
			if(allAppsMode==ALLAPPS_MODE_EDIT) {
				menu.findItem(MENU_ALLAPPS_EDIT).setEnabled(false);
        	} else {
        		menu.findItem(MENU_ALLAPPS_EDIT).setEnabled(true);
        	}
			if(allAppsMode==ALLAPPS_MODE_DELETE) {
				menu.findItem(MENU_ALLAPPS_DELETE).setEnabled(false);
        	} else {
        		menu.findItem(MENU_ALLAPPS_DELETE).setEnabled(true);
        	}
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
        /* } else {
        		menu.setGroupVisible(MENU_GROUP_ALLAPPS, false);
            	menu.setGroupVisible(MENU_GROUP_ALLAPPS_EDIT, true); */
// END LG_UI_HOME yoori.yoo 20100530 
        	}
        } else {
        mMenuAddInfo = mWorkspace.findAllVacantCellsFromModel();
        menu.setGroupEnabled(MENU_GROUP_ADD, mMenuAddInfo != null && mMenuAddInfo.valid);
        	menu.setGroupVisible(MENU_GROUP_ADD, true);
        	menu.setGroupVisible(MENU_GROUP_IDLE, true);
        	menu.setGroupVisible(MENU_GROUP_ALLAPPS, false);
        	menu.setGroupVisible(MENU_GROUP_ALLAPPS_EDIT, false);
        }
     	// END: 0002231 deukmo@lge.com 2009-12-23
        return true;
    }

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case MENU_ADD:
			addItems();
			return true;
		case MENU_WALLPAPER_SETTINGS:
			startWallpaper();
			return true;
		case MENU_SEARCH:
			onSearchRequested();
			return true;
		case MENU_NOTIFICATIONS:
			showNotifications();
			return true;
		// BEGIN: 0002231 deukmo@lge.com 2009-12-04
		// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		case MENU_ALLAPPS_ADD_GROUP:
			showAddGroupDialog();
			return true;
		case MENU_ALLAPPS_DELETE_GROUP:
			showSelectDeleteGroupDialog();
			return true;
		case MENU_ALLAPPS_RENAME_GROUP:
			showSelectRenameGroupDialog();
			return true;
		case MENU_ALLAPPS_EDIT:
			setAllAppsMode(ALLAPPS_MODE_EDIT);
			return true;
		case MENU_ALLAPPS_DELETE:
			setAllAppsMode(ALLAPPS_MODE_DELETE);
			return true;
		case MENU_ALLAPPS_RESET_GROUP:
			showResetGroupDialog();
			return true;
	    // BEGIN: 0003270 deukmo.koo@lge.com 2010-01-14
        // ADD 0003270: [Swift][TopMenu] Add revert function in Edit mode
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	 /* */   case MENU_ALLAPPS_EDIT_DONE:
			doAllAppsDataSave();
			setAllAppsMode(ALLAPPS_MODE_GRID);
			return true;
		case MENU_ALLAPPS_EDIT_REVERT:
			revertAllAppsData();
			resizeAllAppsGridHeight();
			setAllAppsMode(ALLAPPS_MODE_GRID);
			return true; /* */
// END LG_UI_HOME yoori.yoo 20100530 
	    // END: 0003270 deukmo.koo@lge.com 2010-01-14
		// END: 0002231 deukmo@lge.com 2009-12-04
		}

        return super.onOptionsItemSelected(item);
    }

    /**
     * Indicates that we want global search for this activity by setting the globalSearch
     * argument for {@link #startSearch} to true.
     */

	//LGE_SEARCH. infoyoung.choi 20100802 added bingSearch.
	private final static String BING_INTENT="com.microsoft.mobileexperience.bing.SEARCH";

    @Override
    public boolean onSearchRequested() {
//LGE_SEARCH_S #Start infoyoung.choi ����ġ �׽�Ʈ�� ����.
	// SearchManager startSearch�� �̰����� �����Ѵ�.
	//���ο�� ��ó���� ���� ������ ��ġŰ ������ �� ������ ����.
	//�׷��Ƿ� �� ������ ������ �Ѵ�.
	//������ ���� ��ƼŰ�� ������ ��쿡 ���� ������ �̷�������Ѵ�.
	Intent bingSearch=new Intent(BING_INTENT);

	String initialQuery;
        // ���� Ÿ���� �� ���� �����´�,
        initialQuery = getTypedText();

	//�׸��� �����.
        clearTypedText(); 

	//bing�� ���� ���� �־� ��� �ϴ� �ǰ�.
	//���ۿ� �°� �켱 �س���.

	//���� �켱 ������ ���Ƴ��´�.
	//20101116. MS���� ���� �ڵ尡 �Դ�
	bingSearch.putExtra(SearchManager.QUERY, initialQuery);
	bingSearch.putExtra("setSearchBoxText", true);

	startActivity(bingSearch);
//LGE_SEARCH_E
        //startSearch(null, false, null, true);
        return true;
    }

    private void addItems() {
        showAddDialog(mMenuAddInfo);
    }

    private void removeShortcutsForPackage(String packageName) {
        if (packageName != null && packageName.length() > 0) {
            mWorkspace.removeShortcutsForPackage(packageName);
        }
    }

    private void updateShortcutsForPackage(String packageName) {
        if (packageName != null && packageName.length() > 0) {
            mWorkspace.updateShortcutsForPackage(packageName);
        }
    }

    void addAppWidget(Intent data) {
        // TODO: catch bad widget exception when sent
        int appWidgetId = data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1);

// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
        /* String customWidget = data.getStringExtra(EXTRA_CUSTOM_WIDGET);
        if (SEARCH_WIDGET.equals(customWidget)) {
            // We don't need this any more, since this isn't a real app widget.
            mAppWidgetHost.deleteAppWidgetId(appWidgetId);
            // add the search widget
            addSearch();
        } else { */
// END LG_UI_HOME yoori.yoo 20100727 
        AppWidgetProviderInfo appWidget = mAppWidgetManager.getAppWidgetInfo(appWidgetId);

        if (appWidget.configure != null) {
            // Launch over to configure widget, if needed
            Intent intent = new Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE);
            intent.setComponent(appWidget.configure);
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);

// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
            // startActivityForResult(intent, REQUEST_CREATE_APPWIDGET);
            startActivityForResultSafely(intent, REQUEST_CREATE_APPWIDGET);
// END LG_UI_HOME yoori.yoo 20100727 
        } else {
                //2010.10.01 sunghwa.woo@lge.com SNS widget start
                if(appWidget.provider != null && appWidget.provider.getClassName().equals(SNSBridge.SNS_CLASSIC_FEED_PROVIDER))
                {
                    mAppWidgetHost.deleteAppWidgetId(appWidgetId);
                    addSNS();
                }
                else
                {
                    // Otherwise just add it
                    onActivityResult(REQUEST_CREATE_APPWIDGET, Activity.RESULT_OK, data);
                }
                //2010.10.01 sunghwa.woo@lge.com SNS widget end
            }
    }
    
    //2010.10.01 sunghwa.woo@lge.com SNS widget start
    void addSNS(CellLayout.CellInfo cellInfo) {
        final Widget info = Widget.makeSNS();

        final int[] xy = mCellCoordinates;
        final int spanX = info.spanX;
        final int spanY = info.spanY;
        
        if (!findSlot(cellInfo, xy, spanX, spanY)) {
            return;
        }
        
        sModel.addDesktopItem(info);
        LauncherModel.addItemToDatabase(this, info, LauncherSettings.Favorites.CONTAINER_DESKTOP,
                cellInfo.screen, xy[0], xy[1], false);

        final View view = mInflater.inflate(info.layoutResource, (ViewGroup) mWorkspace.getChildAt(cellInfo.screen),false);
        view.setTag(info);
        mWorkspace.addInScreen(view,cellInfo.screen, xy[0], xy[1], spanX, spanY);
    }
    
    void addSNS() {
        addSNS(mAddItemCellInfo);
    }   
    //2010.10.01 sunghwa.woo@lge.com SNS widget end

// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
    /* void addSearch() {
        final Widget info = Widget.makeSearch();
        final CellLayout.CellInfo cellInfo = mAddItemCellInfo;

        final int[] xy = mCellCoordinates;
        final int spanX = info.spanX;
        final int spanY = info.spanY;

        if (!findSlot(cellInfo, xy, spanX, spanY)) return;

        sModel.addDesktopItem(info);
        LauncherModel.addItemToDatabase(this, info, LauncherSettings.Favorites.CONTAINER_DESKTOP,
        mWorkspace.getCurrentScreen(), xy[0], xy[1], false);

        final View view = mInflater.inflate(info.layoutResource, null);
        view.setTag(info);
        Search search = (Search) view.findViewById(R.id.widget_search);
        search.setLauncher(this);

        mWorkspace.addInCurrentScreen(view, xy[0], xy[1], info.spanX, spanY);
    } */
// END LG_UI_HOME yoori.yoo 20100727 

    void processShortcut(Intent intent, int requestCodeApplication, int requestCodeShortcut) {
        // Handle case where user selected "Applications"
        String applicationName = getResources().getString(R.string.group_applications);
        String shortcutName = intent.getStringExtra(Intent.EXTRA_SHORTCUT_NAME);

        if (applicationName != null && applicationName.equals(shortcutName)) {
            Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
            mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);

            Intent pickIntent = new Intent(Intent.ACTION_PICK_ACTIVITY);
            pickIntent.putExtra(Intent.EXTRA_INTENT, mainIntent);
            startActivityForResult(pickIntent, requestCodeApplication);
        } else {
            startActivityForResult(intent, requestCodeShortcut);
        }
    }

    void addLiveFolder(Intent intent) {
        // Handle case where user selected "Folder"
        String folderName = getResources().getString(R.string.group_folder);
        String shortcutName = intent.getStringExtra(Intent.EXTRA_SHORTCUT_NAME);

        if (folderName != null && folderName.equals(shortcutName)) {
            addFolder(!mDesktopLocked);
        } else {
            startActivityForResult(intent, REQUEST_CREATE_LIVE_FOLDER);
        }
    }

    void addFolder(boolean insertAtFirst) {
        UserFolderInfo folderInfo = new UserFolderInfo();
        folderInfo.title = getText(R.string.folder_name);

        CellLayout.CellInfo cellInfo = mAddItemCellInfo;
		
	//added by hwang072 for bug fix (dupilicate widget) 2010-03-10
	 if( cellInfo.screen != mWorkspace.getCurrentScreen()){
		 cellInfo = mWorkspace.findAllVacantCellsFromModel();	
	}  
	 
        cellInfo.screen = mWorkspace.getCurrentScreen();
        if (!findSingleSlot(cellInfo)) return;

        // Update the model
        LauncherModel.addItemToDatabase(this, folderInfo, LauncherSettings.Favorites.CONTAINER_DESKTOP,
                mWorkspace.getCurrentScreen(), cellInfo.cellX, cellInfo.cellY, false);
        sModel.addDesktopItem(folderInfo);
        sModel.addFolder(folderInfo);

        // Create the view
        FolderIcon newFolder = FolderIcon.fromXml(R.layout.folder_icon, this,
                (ViewGroup) mWorkspace.getChildAt(mWorkspace.getCurrentScreen()), folderInfo);
        mWorkspace.addInCurrentScreen(newFolder,
                cellInfo.cellX, cellInfo.cellY, 1, 1, insertAtFirst);
    }

    private void completeAddLiveFolder(Intent data, CellLayout.CellInfo cellInfo,
            boolean insertAtFirst) {

	//added by hwang072 for bug fix (dupilicate widget) 2010-03-10
		 if( cellInfo.screen != mWorkspace.getCurrentScreen()){
			 cellInfo = mWorkspace.findAllVacantCellsFromModel();	
		}  
		 
        cellInfo.screen = mWorkspace.getCurrentScreen();
        if (!findSingleSlot(cellInfo)) return;

        final LiveFolderInfo info = addLiveFolder(this, data, cellInfo, false);

        if (!mRestoring) {
            sModel.addDesktopItem(info);

            final View view = LiveFolderIcon.fromXml(R.layout.live_folder_icon, this,
                (ViewGroup) mWorkspace.getChildAt(mWorkspace.getCurrentScreen()), info);
            mWorkspace.addInCurrentScreen(view, cellInfo.cellX, cellInfo.cellY, 1, 1, insertAtFirst);
        } else if (sModel.isDesktopLoaded()) {
            sModel.addDesktopItem(info);
        }
    }

    static LiveFolderInfo addLiveFolder(Context context, Intent data,
            CellLayout.CellInfo cellInfo, boolean notify) {

        Intent baseIntent = data.getParcelableExtra(LiveFolders.EXTRA_LIVE_FOLDER_BASE_INTENT);
        String name = data.getStringExtra(LiveFolders.EXTRA_LIVE_FOLDER_NAME);

        Drawable icon = null;
        boolean filtered = false;
        Intent.ShortcutIconResource iconResource = null;

        Parcelable extra = data.getParcelableExtra(LiveFolders.EXTRA_LIVE_FOLDER_ICON);
        if (extra != null && extra instanceof Intent.ShortcutIconResource) {
            try {
                iconResource = (Intent.ShortcutIconResource) extra;
                final PackageManager packageManager = context.getPackageManager();
                Resources resources = packageManager.getResourcesForApplication(
                        iconResource.packageName);
                final int id = resources.getIdentifier(iconResource.resourceName, null, null);
                icon = resources.getDrawable(id);
            } catch (Exception e) {
                w(LOG_TAG, "Could not load live folder icon: " + extra);
            }
        }

        if (icon == null) {
            icon = context.getResources().getDrawable(R.drawable.ic_launcher_folder);
        }

        final LiveFolderInfo info = new LiveFolderInfo();
        info.icon = icon;
        info.filtered = filtered;
        info.title = name;
        info.iconResource = iconResource;
        info.uri = data.getData();
        info.baseIntent = baseIntent;
        info.displayMode = data.getIntExtra(LiveFolders.EXTRA_LIVE_FOLDER_DISPLAY_MODE,
                LiveFolders.DISPLAY_MODE_GRID);

        LauncherModel.addItemToDatabase(context, info, LauncherSettings.Favorites.CONTAINER_DESKTOP,
                cellInfo.screen, cellInfo.cellX, cellInfo.cellY, notify);
        sModel.addFolder(info);

        return info;
    }

    private boolean findSingleSlot(CellLayout.CellInfo cellInfo) {
        final int[] xy = new int[2];
        if (findSlot(cellInfo, xy, 1, 1)) {
            cellInfo.cellX = xy[0];
            cellInfo.cellY = xy[1];
            return true;
        }
        return false;
    }

    private boolean findSlot(CellLayout.CellInfo cellInfo, int[] xy, int spanX, int spanY) {
        if (!cellInfo.findCellForSpan(xy, spanX, spanY)) {
            boolean[] occupied = mSavedState != null ?
                    mSavedState.getBooleanArray(RUNTIME_STATE_PENDING_ADD_OCCUPIED_CELLS) : null;
            cellInfo = mWorkspace.findAllVacantCells(occupied);
            if (!cellInfo.findCellForSpan(xy, spanX, spanY)) {
                Toast.makeText(this, getString(R.string.out_of_space), Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    private void showNotifications() {
        final StatusBarManager statusBar = (StatusBarManager) getSystemService(STATUS_BAR_SERVICE);
        if (statusBar != null) {
            statusBar.expand();
        }
    }

    private void startWallpaper() {
        final Intent pickWallpaper = new Intent(Intent.ACTION_SET_WALLPAPER);
        Intent chooser = Intent.createChooser(pickWallpaper,
                getText(R.string.chooser_wallpaper));
                // NOTE: Adds a configure option to the chooser if the wallpaper supports it
        //       Removed in Eclair MR1
//        WallpaperManager wm = (WallpaperManager)
//                getSystemService(Context.WALLPAPER_SERVICE);
//        WallpaperInfo wi = wm.getWallpaperInfo();
//        if (wi != null && wi.getSettingsActivity() != null) {
//            LabeledIntent li = new LabeledIntent(getPackageName(),
//                    R.string.configure_wallpaper, 0);
//            li.setClassName(wi.getPackageName(), wi.getSettingsActivity());
//            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[] { li });
//        }
        startActivity(chooser);
    }

    /**
     * Registers various intent receivers. The current implementation registers
     * only a wallpaper intent receiver to let other applications change the
     * wallpaper.
     */
    private void registerIntentReceivers() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_PACKAGE_ADDED);
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED);
        filter.addAction(Intent.ACTION_PACKAGE_CHANGED);
        filter.addDataScheme("package");
        registerReceiver(mApplicationsReceiver, filter);
        filter = new IntentFilter(Intent.ACTION_CLOSE_SYSTEM_DIALOGS);
        registerReceiver(mCloseSystemDialogsReceiver, filter);
// START yoori.yoo 20100823 : VVM Icon Update
        filter = new IntentFilter();
        filter.addAction("com.lge.vvm.NEW_VVM_NOTIFICATION_RECEIVED");
        registerReceiver(mNewVvmIntentReceiver, filter);
// END yoori.yoo 20100823
// START yoori.yoo 20100906 : Top Menu - End Key - Idle        
        filter = new IntentFilter();
        filter.addAction("android.intent.action.LAUNCHER_END_KEY_PRESSED");
        registerReceiver(mEndKeyEventReceiver, filter);        
// END yoori.yoo 20100906         
    }

    /**
     * Registers various content observers. The current implementation registers
     * only a favorites observer to keep track of the favorites applications.
     */
    private void registerContentObservers() {
        ContentResolver resolver = getContentResolver();
        resolver.registerContentObserver(LauncherSettings.Favorites.CONTENT_URI, true, mObserver);
        resolver.registerContentObserver(LauncherProvider.CONTENT_APPWIDGET_RESET_URI,
                true, mWidgetObserver);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            switch (event.getKeyCode()) {
              //  case KeyEvent.KEYCODE_BACK: //blocked by hwang072 for bug fix 2010-03-10
              //      return true;
                case KeyEvent.KEYCODE_HOME:
                    return true;
            }
        } else if (event.getAction() == KeyEvent.ACTION_UP) {
            switch (event.getKeyCode()) {
	//blocked by hwang072 for bug fix 2010-03-10
           /*     case KeyEvent.KEYCODE_BACK:
                    if (!event.isCanceled()) {
                        mWorkspace.dispatchKeyEvent(event);
                        if (mDrawer.isOpened()) {
					// BEGIN: 0002231 deukmo@lge.com 2009-12-04
					// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
					switch(mAllAppsMode) {
						case ALLAPPS_MODE_GRID:
							closeDrawer();
							Log.d("test","ALLAPPS_MODE_GRID   : closeDrawer!!!!");
							break;
						case ALLAPPS_MODE_EDIT:
							setAllAppsMode(ALLAPPS_MODE_GRID);
							break;
						case ALLAPPS_MODE_DELETE:
							setAllAppsMode(ALLAPPS_MODE_GRID);
							break;
					}
					// END: 0002231 deukmo@lge.com 2009-12-04
                        } else {
                            closeFolder();
                        }
                    }
                    return true;*/
                case KeyEvent.KEYCODE_HOME:
                    return true;
            }
        }
		
        return super.dispatchKeyEvent(event);
    }


//added by hwang072 for bug fix 2010-03-10
    @Override
    public void onBackPressed() {
	if (mDrawer.isOpened()) {
		  switch(mAllAppsMode) {
			  case ALLAPPS_MODE_GRID:
				  closeDrawer();
				  break;
			  case ALLAPPS_MODE_EDIT:
				  setAllAppsMode(ALLAPPS_MODE_GRID);
				  break;
			  case ALLAPPS_MODE_DELETE:
				  setAllAppsMode(ALLAPPS_MODE_GRID);
				  break;
			  }
	  } else {
		  closeFolder();
	  }

    }

    private void closeDrawer() {		
        closeDrawer(true);
	 setAllAppsMode(ALLAPPS_MODE_GRID); //added by hwang072 for Vs740 2010-01-29
	 
    }

    private void closeDrawer(boolean animated) {
        if (mDrawer.isOpened()) {
            if (animated) {
                mDrawer.animateClose();
            } else {
                mDrawer.close();
            }
            if (mDrawer.hasFocus()) {
                mWorkspace.getChildAt(mWorkspace.getCurrentScreen()).requestFocus();
            }
        }
		isAllAppOpened=false;//Added by hwang072 for bug fix 2010-03-18
    }

    private void closeFolder() {
        Folder folder = mWorkspace.getOpenFolder();
        if (folder != null) {
            closeFolder(folder);
        }
    }

    void closeFolder(Folder folder) {
        folder.getInfo().opened = false;
        ViewGroup parent = (ViewGroup) folder.getParent();
        if (parent != null) {
            parent.removeView(folder);
        }
        folder.onClose();
    }

// START yoori.yoo 20100922 : VS660 Merge for OpenFolder
    protected void swapDepthFolder() {
    	Folder folder = mWorkspace.getOpenFolder();
    	if(folder != null) {
    		folder.bringToFront();
    	}
    }
// END yoori.yoo 20100922	

    /**
     * When the notification that favorites have changed is received, requests
     * a favorites list refresh.
     */
    private void onFavoritesChanged() {
        mDesktopLocked = true;
        mDrawer.lock();
        sModel.loadUserItems(false, this, false, false);
    }

    /**
     * Re-listen when widgets are reset.
     */
    private void onAppWidgetReset() {
        mAppWidgetHost.startListening();
    }

    void onDesktopItemsLoaded(ArrayList<ItemInfo> shortcuts,
            ArrayList<LauncherAppWidgetInfo> appWidgets) {
        if (mDestroyed) {
            if (LauncherModel.DEBUG_LOADERS) {
                d(LauncherModel.LOG_TAG, "  ------> destroyed, ignoring desktop items");
            }
            return;
        }
        bindDesktopItems(shortcuts, appWidgets);
    }

    /**
     * Refreshes the shortcuts shown on the workspace.
     */
    private void bindDesktopItems(ArrayList<ItemInfo> shortcuts,
            ArrayList<LauncherAppWidgetInfo> appWidgets) {

        final ApplicationsAdapter drawerAdapter = sModel.getApplicationsAdapter();
        // BEGIN: 0002231 deukmo@lge.com 2009-12-03
        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        final ApplicationsAdapter[] drawerAdapterArray = sModel.getApplicationsAdapterArray();
        if (shortcuts == null || appWidgets == null || drawerAdapter == null || drawerAdapterArray == null) {
        // END: 0002231 deukmo@lge.com 2009-12-03
            if (LauncherModel.DEBUG_LOADERS) d(LauncherModel.LOG_TAG, "  ------> a source is null");            
            return;
        }

        final Workspace workspace = mWorkspace;
        int count = workspace.getChildCount();
        for (int i = 0; i < count; i++) {
            ((ViewGroup) workspace.getChildAt(i)).removeAllViewsInLayout();
        }

        if (DEBUG_USER_INTERFACE) {
            android.widget.Button finishButton = new android.widget.Button(this);
            finishButton.setText("Finish");
            workspace.addInScreen(finishButton, 1, 0, 0, 1, 1);

            finishButton.setOnClickListener(new android.widget.Button.OnClickListener() {
                public void onClick(View v) {
                    finish();
                }
            });
        }

        // Flag any old binder to terminate early
        if (mBinder != null) {
			mBinder.mTerminate = true;
		}
        
        // BEGIN: 0002231 deukmo@lge.com 2009-12-03
        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		mBinder = new DesktopBinder(this, shortcuts, appWidgets, drawerAdapter, drawerAdapterArray);
		// END: 0002231 deukmo@lge.com 2009-12-03
		mBinder.startBindingItems();
	}

    private void bindItems(Launcher.DesktopBinder binder,
            ArrayList<ItemInfo> shortcuts, int start, int count) {

        final Workspace workspace = mWorkspace;
        final boolean desktopLocked = mDesktopLocked;

        final int end = Math.min(start + DesktopBinder.ITEMS_COUNT, count);
        int i = start;

        for ( ; i < end; i++) {
            final ItemInfo item = shortcuts.get(i);
            switch (item.itemType) {
                case LauncherSettings.Favorites.ITEM_TYPE_APPLICATION:
                case LauncherSettings.Favorites.ITEM_TYPE_SHORTCUT:
                    final View shortcut = createShortcut((ApplicationInfo) item);
                    workspace.addInScreen(shortcut, item.screen, item.cellX, item.cellY, 1, 1,
                            !desktopLocked);
                    break;
                case LauncherSettings.Favorites.ITEM_TYPE_USER_FOLDER:
                    final FolderIcon newFolder = FolderIcon.fromXml(R.layout.folder_icon, this,
                            (ViewGroup) workspace.getChildAt(workspace.getCurrentScreen()),
                            (UserFolderInfo) item);
                    workspace.addInScreen(newFolder, item.screen, item.cellX, item.cellY, 1, 1,
                            !desktopLocked);
                    break;
                case LauncherSettings.Favorites.ITEM_TYPE_LIVE_FOLDER:
                    final FolderIcon newLiveFolder = LiveFolderIcon.fromXml(
                            R.layout.live_folder_icon, this,
                            (ViewGroup) workspace.getChildAt(workspace.getCurrentScreen()),
                            (LiveFolderInfo) item);
                    workspace.addInScreen(newLiveFolder, item.screen, item.cellX, item.cellY, 1, 1,
                            !desktopLocked);
                    break;
// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
                /* case LauncherSettings.Favorites.ITEM_TYPE_WIDGET_SEARCH:
                    final int screen = workspace.getCurrentScreen();
                    final View view = mInflater.inflate(R.layout.widget_search,
                            (ViewGroup) workspace.getChildAt(screen), false);

                    Search search = (Search) view.findViewById(R.id.widget_search);
                    search.setLauncher(this);

                    final Widget widget = (Widget) item;
                    view.setTag(widget);

                    workspace.addWidget(view, widget, !desktopLocked);
                    break; */
// END LG_UI_HOME yoori.yoo 20100727 
                //2010.10.01 sunghwa.woo@lge.com SNS widget start
                case com.lge.sns.SNSBridge.ITEM_TYPE_SNS_FEED_WIDGET:
                    final int snsScreen = workspace.getCurrentScreen();
                    final View snsView = mInflater.inflate(R.layout.sns_feed_widget,
                            (ViewGroup) workspace.getChildAt(snsScreen), false);
                    final Widget snsWidget = (Widget) item;
                    snsView.setTag(snsWidget);
                    workspace.addInScreen(snsView, snsWidget.screen, snsWidget.cellX, snsWidget.cellY, snsWidget.spanX,
                            snsWidget.spanY, false);
                    break;
                //2010.10.01 sunghwa.woo@lge.com SNS widget end
                    
            }
        }

        workspace.requestLayout();

        if (end >= count) {
            finishBindDesktopItems();
            binder.startBindingDrawer();
        } else {
            binder.obtainMessage(DesktopBinder.MESSAGE_BIND_ITEMS, i, count).sendToTarget();
        }
    }

    private void finishBindDesktopItems() {
// START yoori.yoo 20100913 : isFolderOpened added
    	boolean isFolderOpened  = false;
// END yoori.yoo 20100913 
    	
        if (mSavedState != null) {
            if (!mWorkspace.hasFocus()) {
                mWorkspace.getChildAt(mWorkspace.getCurrentScreen()).requestFocus();
            }
            
            final long[] userFolders = mSavedState.getLongArray(RUNTIME_STATE_USER_FOLDERS);
            if (userFolders != null) {
                for (long folderId : userFolders) {
                    final FolderInfo info = sModel.findFolderById(folderId);
                    if (info != null) {
                        openFolder(info);
// START yoori.yoo 20100913 : isFolderOpened added
                    	isFolderOpened = true;
// END yoori.yoo 20100913 
                    }
                }
                final Folder openFolder = mWorkspace.getOpenFolder();
                if (openFolder != null) {
                    openFolder.requestFocus();
                }
            }

            final boolean allApps = mSavedState.getBoolean(RUNTIME_STATE_ALL_APPS_FOLDER, false);
// START LG_UI_HOME yoori.yoo 20100804
// internal TD 22838 maintain menu list when folder opend/closed
            if (allApps || isAllAppOpened) {
// END LG_UI_HOME yoori.yoo 20100804
                mDrawer.open();
		   		isAllAppOpened=true;//Added by hwang072 for bug fix 2010-03-18
// START yoori.yoo 20100910 : Tom Menu Uninstall		   		
		   		setAllAppsMode(ALLAPPS_MODE_GRID);
// END yoori.yoo 20100910
            }

            mSavedState = null;
        }

// START yoori.yoo 20100913 : isFolderOpened added
        if (mSavedInstanceState != null && !isFolderOpened) {
// END yoori.yoo 20100913 
            super.onRestoreInstanceState(mSavedInstanceState);
            mSavedInstanceState = null;
        }

        if (mDrawer.isOpened() && !mDrawer.hasFocus()) {
            mDrawer.requestFocus();
        }

        mDesktopLocked = false;
        mDrawer.unlock();
        
// START yoori.yoo 20100915 : release focus on item when folder opened/closed
        mWorkspace.setFocusable(true);
        mWorkspace.requestFocus();
// END yoori.yoo 20100915	
    }

	// BEGIN: 0002231 deukmo@lge.com 2009-12-04
	// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	private void bindDrawer(Launcher.DesktopBinder binder,
			ApplicationsAdapter drawerAdapter,
			ApplicationsAdapter[] drawerAdapterArray) {
	    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        //mAllAppsGrid.setAdapter(drawerAdapter);
        // END: 0002231 deukmo@lge.com 2009-12-23
        
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		for(int i=0; i<drawerAdapterArray.length; i++) {
        	mAllAppsGridArray[i].setAdapter(drawerAdapterArray[i]);
        }
		// END: 0002231 deukmo@lge.com 2009-12-03
		binder.startBindingAppWidgetsWhenIdle();
		
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		resizeAllAppsGridHeight();
		// END: 0002231 deukmo@lge.com 2009-12-03
	}
	// END: 0002231 deukmo@lge.com 2009-12-04

    private void bindAppWidgets(Launcher.DesktopBinder binder,
            LinkedList<LauncherAppWidgetInfo> appWidgets) {

        final Workspace workspace = mWorkspace;
        final boolean desktopLocked = mDesktopLocked;

        if (!appWidgets.isEmpty()) {
            final LauncherAppWidgetInfo item = appWidgets.removeFirst();

            final int appWidgetId = item.appWidgetId;
            final AppWidgetProviderInfo appWidgetInfo = mAppWidgetManager.getAppWidgetInfo(appWidgetId);
            item.hostView = mAppWidgetHost.createView(this, appWidgetId, appWidgetInfo);

            if (LOGD) {
                d(LOG_TAG, String.format("about to setAppWidget for id=%d, info=%s",
                       appWidgetId, appWidgetInfo));
            }

            item.hostView.setAppWidget(appWidgetId, appWidgetInfo);
            item.hostView.setTag(item);

            workspace.addInScreen(item.hostView, item.screen, item.cellX,
                    item.cellY, item.spanX, item.spanY, !desktopLocked);

            workspace.requestLayout();
        }

        if (appWidgets.isEmpty()) {
            if (PROFILE_ROTATE) {
                android.os.Debug.stopMethodTracing();
            }
        } else {
            binder.obtainMessage(DesktopBinder.MESSAGE_BIND_APPWIDGETS).sendToTarget();
        }
    }

    /**
     * Launches the intent referred by the clicked shortcut.
     *
     * @param v The view representing the clicked shortcut.
     */
    public void onClick(View v) {
	    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	    if(!isDrawerUp()) {
			Object tag = v.getTag();
			if (tag instanceof ApplicationInfo) {
// START yoori.yoo 20100922 : back to previous screen
				setBackToPreviousScreen(true);
// END yoori.yoo 20100922
				// Open shortcut
                    final Intent intent = ((ApplicationInfo) tag).intent;
                    int[] pos = new int[2];
                    v.getLocationOnScreen(pos);
                    intent.setSourceBounds(new Rect(pos[0], pos[1], pos[0]+v.getWidth(), pos[1]+v.getHeight()));
                    startActivitySafely(intent);
                
        		} else if (tag instanceof FolderInfo) {
        			handleFolderClick((FolderInfo) tag);
        		}
		}
		// END: 0002231 deukmo@lge.com 2009-12-23
    }
    boolean gotoInCallScreen(Intent intent) {
//phone call
		ComponentName component = intent.getComponent();

		if(component != null)
		{
			if(component.getPackageName().equals("com.android.contacts")
				&& component.getClassName().equals("com.android.contacts.DialtactsActivity"))
			{
				if(phoneIsInUse())
				{
					returnToInCallScreen(false);
					return true;
				}

			}
		
		}
		return false;
//phone call
    }
    
    boolean gotoInCallScreenWithDial(Intent intent, String dialNum) {
//phone call
		ComponentName component = intent.getComponent();

		if(component != null)
		{
			if(component.getClassName().equals("com.android.phone.InCallScreen"))
			{
				if(phoneIsInUse())
				{
					returnToInCallScreenWithDial(dialNum);
					return true;
				}

			}
		
		}
		return false;
//phone call
    }
    
//phone call
    public void returnToInCallScreen(boolean showDialpad) {
        try {
            ITelephony phone = ITelephony.Stub.asInterface(ServiceManager.checkService("phone"));
            if (phone != null) phone.showCallScreenWithDialpad(showDialpad);
        } catch (RemoteException e) {
            Log.w(LOG_TAG, "phone.showCallScreenWithDialpad() failed", e);
        }

    }
    
    public void returnToInCallScreenWithDial(String dialNum) {
        try {
            ITelephony phone = ITelephony.Stub.asInterface(ServiceManager.checkService("phone"));
            if (phone != null) phone.showCallScreenWithDialNum(dialNum);
        } catch (RemoteException e) {
            Log.w(LOG_TAG, "phone.showCallScreenWithDialNum() failed", e);
        }
    }
    
    boolean phoneIsInUse() {
        boolean phoneInUse = false;
        try {
            ITelephony phone = ITelephony.Stub.asInterface(ServiceManager.checkService("phone"));
            if (phone != null) phoneInUse = !phone.isIdle();
        } catch (RemoteException e) {
            Log.w(LOG_TAG, "phone.isIdle() failed", e);
        }
        return phoneInUse;
    }

//phone call

    void startActivitySafely(Intent intent) {

        if(gotoInCallScreen(intent)) {
            return;
        }

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.activity_not_found, Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, R.string.activity_not_found, Toast.LENGTH_SHORT).show();
            e(LOG_TAG, "Launcher does not have the permission to launch " + intent +
                    ". Make sure to create a MAIN intent-filter for the corresponding activity " +
                    "or use the exported attribute for this activity.", e);
        }
    }

// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
    void startActivityForResultSafely(Intent intent, int requestCode) {
        try {
            startActivityForResult(intent, requestCode);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.activity_not_found, Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, R.string.activity_not_found, Toast.LENGTH_SHORT).show();
            Log.e(LOG_TAG, "Launcher does not have the permission to launch " + intent +
                    ". Make sure to create a MAIN intent-filter for the corresponding activity " +
                    "or use the exported attribute for this activity.", e);
        }
    }
// END LG_UI_HOME yoori.yoo 20100727 

    private void handleFolderClick(FolderInfo folderInfo) {
        if (!folderInfo.opened) {
            // Close any open folder
            closeFolder();
            // Open the requested folder
            openFolder(folderInfo);
        } else {
            // Find the open folder...
            Folder openFolder = mWorkspace.getFolderForTag(folderInfo);
            int folderScreen;
            if (openFolder != null) {
                folderScreen = mWorkspace.getScreenForView(openFolder);
                // .. and close it
                closeFolder(openFolder);
                if (folderScreen != mWorkspace.getCurrentScreen()) {
                    // Close any folder open on the current screen
                    closeFolder();
                    // Pull the folder onto this screen
                    openFolder(folderInfo);
                }
            }
        }
    }

    /**
     * Opens the user fodler described by the specified tag. The opening of the folder
     * is animated relative to the specified View. If the View is null, no animation
     * is played.
     *
     * @param folderInfo The FolderInfo describing the folder to open.
     */
    private void openFolder(FolderInfo folderInfo) {
        Folder openFolder;

        if (folderInfo instanceof UserFolderInfo) {
            openFolder = UserFolder.fromXml(this);
        } else if (folderInfo instanceof LiveFolderInfo) {
            openFolder = com.lge.launcher.LiveFolder.fromXml(this, folderInfo);
        } else {
            return;
        }

        openFolder.setDragger(mDragLayer);
        openFolder.setLauncher(this);

        openFolder.bind(folderInfo);
        folderInfo.opened = true;

        mWorkspace.addInScreen(openFolder, folderInfo.screen, 0, 0, 4, 4);
        openFolder.onOpen();
    }

    /**
     * Returns true if the workspace is being loaded. When the workspace is loading,
     * no user interaction should be allowed to avoid any conflict.
     *
     * @return True if the workspace is locked, false otherwise.
     */
    boolean isWorkspaceLocked() {
        return mDesktopLocked;
    }

    public boolean onLongClick(View v) {
        if (mDesktopLocked) {
            return false;
        }

        if (!(v instanceof CellLayout)) {
            v = (View) v.getParent();
        }

        CellLayout.CellInfo cellInfo = (CellLayout.CellInfo) v.getTag();

        // This happens when long clicking an item with the dpad/trackball
        if (cellInfo == null) {
            return true;
        }

        if (mWorkspace.allowLongPress()) {
            if (cellInfo.cell == null) {
                if (cellInfo.valid) {
                    // User long pressed on empty space
                    mWorkspace.setAllowLongPress(false);
                    showAddDialog(cellInfo);
                }
            } else {
                if (!(cellInfo.cell instanceof Folder)) {
                    // User long pressed on an item
                    mWorkspace.startDrag(cellInfo);
                }
            }
        }
        return true;
    }

    static LauncherModel getModel() {
        return sModel;
    }

	void closeAllApplications() {
	    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        mDrawer.animateClose();
	  isAllAppOpened=false; //Added by hwang072 for bug fix 2010-03-18
        // END: 0002231 deukmo@lge.com 2009-12-23
	}

    View getDrawerHandle() {
        return mHandleView;
    }

    boolean isDrawerDown() {
        return !mDrawer.isMoving() && !mDrawer.isOpened();
    }

    boolean isDrawerUp() {
        return mDrawer.isOpened() && !mDrawer.isMoving();
    }

    boolean isDrawerMoving() {
        return mDrawer.isMoving();
    }

    Workspace getWorkspace() {
        return mWorkspace;
    }

    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // DEL 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	//GridView getApplicationsGrid() {
	//	return mAllAppsGrid;
	//}
	// END: 0002231 deukmo@lge.com 2009-12-23

    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DIALOG_CREATE_SHORTCUT:
                return new CreateShortcut().createDialog();
            case DIALOG_RENAME_FOLDER:
                return new RenameFolder().createDialog();
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		case DIALOG_ALLAPPS_ADD_GROUP:
			return new AddGroup().createDialog();
		case DIALOG_ALLAPPS_RENAME_GROUP:
			return new RenameGroup().createDialog();
		case DIALOG_ALLAPPS_DELETE_GROUP:
			return new DeleteGroup().createDialog();
		case DIALOG_ALLAPPS_RESET_GROUP:
			return new ResetGroup().createDialog();
		case DIALOG_ALLAPPS_UNINSTALL_APP:
			return new UninstallApp().createDialog();
		// END: 0002231 deukmo@lge.com 2009-12-03
        }

        return super.onCreateDialog(id);
    }

    @Override
    protected void onPrepareDialog(int id, Dialog dialog) {
        switch (id) {
            case DIALOG_CREATE_SHORTCUT:
                break;
            case DIALOG_RENAME_FOLDER:
                if (mFolderInfo != null) {
                    EditText input = (EditText) dialog.findViewById(R.id.folder_name);
                    final CharSequence text = mFolderInfo.title;
                    input.setText(text);
                    input.setSelection(0, text.length());
                }
                break;
            // BEGIN: 0002231 deukmo@lge.com 2009-03-02
            // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
            case DIALOG_ALLAPPS_ADD_GROUP:
                {
                	final EditText input = (EditText) dialog.findViewById(R.id.group_name);
                	final CharSequence text = getString(R.string.allspps_new_group_name);
                	input.setText(text);
                	input.setSelection(0, text.length());
                }
    			break;
    		case DIALOG_ALLAPPS_RENAME_GROUP:
    			{
    				final EditText input = (EditText) dialog.findViewById(R.id.group_name);
	                final CharSequence text = mLoadedAllAppsTitleArray[mSelectedGroupId];
	                input.setText(text);
	                input.setSelection(0, text.length());
    			}
    			break;
    		case DIALOG_ALLAPPS_UNINSTALL_APP:
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	    		// BEGIN: 0005266 deukmo.koo@lge.com 2010-03-21
				// ADD 0005266: [Swift][LGHome] Fix an error when locale is changed (ocassionally)
	    		if(mUninstallApplicationInfo!=null) {
	    		// END: 0005266 deukmo.koo@lge.com 2010-03-21
	    			final TextView deleteTitle = (TextView) dialog.findViewById(R.id.delete_title);
	    			final TextView deleteMessage = (TextView) dialog.findViewById(R.id.delete_message);
// END LG_UI_HOME yoori.yoo 20100530 
	    			final ImageView appIcon = (ImageView) dialog.findViewById(R.id.app_icon);
	    			final TextView appName = (TextView) dialog.findViewById(R.id.app_name);
	    			final TextView appVersion = (TextView) dialog.findViewById(R.id.app_version);
	    			
	    			PackageManager packageManager = getPackageManager();
	    			PackageInfo pkgInfo;

	    			appIcon.setImageDrawable(mUninstallApplicationInfo.icon);
	    			appName.setText(mUninstallApplicationInfo.title);
	    	        try {
	    	            pkgInfo = packageManager.getPackageInfo(mUninstallApplicationInfo.intent.getComponent().getPackageName(), 0);
	    	            appVersion.setText(getString(R.string.version_text, String.valueOf(pkgInfo.versionCode)));
	    	        } catch (NameNotFoundException e) {
	    	        	appVersion.setText("");
	    	        }
	    	        
	    	        if(mUninstallApplicationInfo.isSystemApplication) {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	    	        	// dialog.findViewById(R.id.delete_message).setVisibility(View.GONE);
	    	        	// dialog.findViewById(R.id.delete_divider1).setVisibility(View.GONE);
	    	       		deleteTitle.setText(R.string.delete_systemapp_title);    	 
	    			deleteMessage.setText(R.string.delete_systemapp_message);
// END LG_UI_HOME yoori.yoo 20100530 
	    	        	dialog.findViewById(R.id.button_cancel).setVisibility(View.GONE);
	    	        } else {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	    	        	// dialog.findViewById(R.id.delete_message).setVisibility(View.VISIBLE);
	    	        	// dialog.findViewById(R.id.delete_divider1).setVisibility(View.VISIBLE);
	    	        	deleteTitle.setText(R.string.delete_userapp_title);
	    		        deleteMessage.setText(R.string.delete_userapp_message);
// END LG_UI_HOME yoori.yoo 20100530 
	    	        	dialog.findViewById(R.id.button_cancel).setVisibility(View.VISIBLE);
	    	        }
	    			
	    	        if(mTotalSize!=null) mTotalSize.setText("");
	    	        if(mApplicationSize!=null) mApplicationSize.setText("");
	    	        if(mDataSize!=null) mDataSize.setText("");
	    	        
	    	        packageManager.getPackageSizeInfo(mUninstallApplicationInfo.intent.getComponent().getPackageName(), mSizeObserver);
	    		}
	    		break;
    		// END: 0002231 deukmo@lge.com 2009-03-02
        }
    }
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    class PkgSizeObserver extends IPackageStatsObserver.Stub {
		public void onGetStatsCompleted(PackageStats pStats, boolean succeeded) {
	        long newTot = pStats.cacheSize+pStats.codeSize+pStats.dataSize;
            String str = getSizeStr(newTot);
            if(mTotalSize!=null) mTotalSize.setText(str);
            if(mApplicationSize!=null) mApplicationSize.setText(getSizeStr(pStats.codeSize));
            if(mDataSize!=null) mDataSize.setText(getSizeStr(pStats.dataSize));
		}
	}
	
	private String getSizeStr(long size) {
        if (size == -1) {
            return "";
        }
        return Formatter.formatFileSize(this, size);
    }
    // END: 0002231 deukmo@lge.com 2009-12-23

    void showRenameDialog(FolderInfo info) {
        mFolderInfo = info;
        mWaitingForResult = true;
        showDialog(DIALOG_RENAME_FOLDER);
    }

    private void showAddDialog(CellLayout.CellInfo cellInfo) {
        mAddItemCellInfo = cellInfo;
        mWaitingForResult = true;
        showDialog(DIALOG_CREATE_SHORTCUT);
    }
	// BEGIN: 0002231 deukmo@lge.com 2009-12-04
	// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
	private void showAddGroupDialog() {
		if (mVisibleGroupNum<(ALLAPPS_TOTAL_GROUPNUM-2)) {
			showDialog(DIALOG_ALLAPPS_ADD_GROUP);
		}
	}
	
	private void showSelectDeleteGroupDialog() {
		if(mVisibleGroupNum>0) {
			mCurrentAllAppsGroups = new String[mVisibleGroupNum];
		    mCheckedAllAppsGroups = new boolean[mVisibleGroupNum];
		    for(int i=0; i<mVisibleGroupNum; i++) {
		    	// BEGIN: 0003247 deukmo@lge.com 2010-01-13
		    	// ADD 0003247: [Swift][TopMenu] Change new category order
		    	mCurrentAllAppsGroups[i] = mLoadedAllAppsTitleArray[ALLAPPS_EDITABLE_GROUPNUM-mVisibleGroupNum+i];
		    	// END: 0003247 deukmo@lge.com 2010-01-13
		    	mCheckedAllAppsGroups[i] = false;
		    }
		    
		    new SelectDeleteGroup().createDialog().show();
		}
	}
	
	private void showDeleteGroupDialog() {
		final boolean[] checkedAllAppsGroups = mCheckedAllAppsGroups;
		if(checkedAllAppsGroups!=null) {
			boolean isSelected = false;
			final int count = checkedAllAppsGroups.length;
			for(int i=0; i<count; i++) {
				if(checkedAllAppsGroups[i]) {
					isSelected = true;
					break;
				}
			}
			if(isSelected) {
				showDialog(DIALOG_ALLAPPS_DELETE_GROUP);
			}
		}
	}
	
	private void showSelectRenameGroupDialog() {

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	//blocked by hwang072 for Vs740 2010-01-19
	/* */	if(mAllAppsGridArray[ALLAPPS_DOWNLOAD_GROUPID].getVisibility()==View.VISIBLE) {
			mCurrentAllAppsGroups = new String[mVisibleGroupNum+2];
		} else {
			mCurrentAllAppsGroups = new String[mVisibleGroupNum+1];
		} /* */

	    // mCurrentAllAppsGroups = new String[mVisibleGroupNum];
// END LG_UI_HOME yoori.yoo 20100530 
	    int i = 0;
	    for(; i<mVisibleGroupNum; i++) {
	    	// BEGIN: 0003247 deukmo@lge.com 2010-01-13
	    	// ADD 0003247: [Swift][TopMenu] Change new category order
	    	mCurrentAllAppsGroups[i] = mLoadedAllAppsTitleArray[ALLAPPS_EDITABLE_GROUPNUM-mVisibleGroupNum+i];
	    	// END: 0003247 deukmo@lge.com 2010-01-13
	    }
		
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	//blocked by hwang072 for Vs740 2010-01-19
	/* */    mCurrentAllAppsGroups[i++] = mLoadedAllAppsTitleArray[ALLAPPS_SYSTEMAPP_GROUPID];
	    if(mAllAppsGridArray[ALLAPPS_DOWNLOAD_GROUPID].getVisibility()==View.VISIBLE) {
	    	mCurrentAllAppsGroups[i] = mLoadedAllAppsTitleArray[ALLAPPS_DOWNLOAD_GROUPID];
		} /* */
// END LG_UI_HOME yoori.yoo 20100530 
	    
	    new SelectRenameGroup().createDialog().show();
	}
	
	private void showRenameGroupDialog(int selectedGroupId) {
		if (selectedGroupId>=0 && selectedGroupId<(mVisibleGroupNum+2)) {
			if(selectedGroupId<mVisibleGroupNum) {
				// BEGIN: 0003247 deukmo@lge.com 2010-01-13
		    	// ADD 0003247: [Swift][TopMenu] Change new category order
				mSelectedGroupId = ALLAPPS_EDITABLE_GROUPNUM-mVisibleGroupNum+selectedGroupId;
				// END: 0003247 deukmo@lge.com 2010-01-13
			} else if(selectedGroupId==mVisibleGroupNum) {
				mSelectedGroupId = ALLAPPS_SYSTEMAPP_GROUPID;
			} else {
				mSelectedGroupId = ALLAPPS_DOWNLOAD_GROUPID;
			}
			showDialog(DIALOG_ALLAPPS_RENAME_GROUP);
		}
	}
	
	void showUninstallDialog(ApplicationInfo app) {
		mUninstallApplicationInfo = app;
		showDialog(DIALOG_ALLAPPS_UNINSTALL_APP);
	}
	
	private void showResetGroupDialog() {
		showDialog(DIALOG_ALLAPPS_RESET_GROUP);
	}
	// END: 0002231 deukmo@lge.com 2009-12-04

    private void pickShortcut(int requestCode, int title) {
        Bundle bundle = new Bundle();

        ArrayList<String> shortcutNames = new ArrayList<String>();
        shortcutNames.add(getString(R.string.group_applications));
        bundle.putStringArrayList(Intent.EXTRA_SHORTCUT_NAME, shortcutNames);

        ArrayList<ShortcutIconResource> shortcutIcons = new ArrayList<ShortcutIconResource>();
        shortcutIcons.add(ShortcutIconResource.fromContext(Launcher.this,
                        R.drawable.ic_launcher_application));
        bundle.putParcelableArrayList(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, shortcutIcons);

        Intent pickIntent = new Intent(Intent.ACTION_PICK_ACTIVITY);
        pickIntent.putExtra(Intent.EXTRA_INTENT, new Intent(Intent.ACTION_CREATE_SHORTCUT));
        pickIntent.putExtra(Intent.EXTRA_TITLE, getText(title));
        pickIntent.putExtras(bundle);

        startActivityForResult(pickIntent, requestCode);
    }

    private class RenameFolder {
        private EditText mInput;

        Dialog createDialog() {
            mWaitingForResult = true;
            final View layout = View.inflate(Launcher.this, R.layout.rename_folder, null);
            mInput = (EditText) layout.findViewById(R.id.folder_name);

            AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setIcon(0);
            builder.setTitle(getString(R.string.rename_folder_title));
            builder.setCancelable(true);
            builder.setOnCancelListener(new Dialog.OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cleanup();
				}
			});
			builder.setNegativeButton(getString(R.string.cancel_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							cleanup();
						}
					});
			builder.setPositiveButton(getString(R.string.rename_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							changeFolderName();
						}
					});
			builder.setView(layout);

            final AlertDialog dialog = builder.create();
            dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                public void onShow(DialogInterface dialog) {
                    mWorkspace.lock();
                }
            });

            return dialog;
        }

        private void changeFolderName() {
            final String name = mInput.getText().toString();
            if (!TextUtils.isEmpty(name)) {
                // Make sure we have the right folder info
                mFolderInfo = sModel.findFolderById(mFolderInfo.id);
                mFolderInfo.title = name;
                LauncherModel.updateItemInDatabase(Launcher.this, mFolderInfo);

                if (mDesktopLocked) {
                    mDrawer.lock();
                    sModel.loadUserItems(false, Launcher.this, false, false);
                } else {
                    final FolderIcon folderIcon = (FolderIcon)
                            mWorkspace.getViewForTag(mFolderInfo);
                    if (folderIcon != null) {
                        folderIcon.setText(name);
                        getWorkspace().requestLayout();
                    } else {
                        mDesktopLocked = true;
                        mDrawer.lock();
                        sModel.loadUserItems(false, Launcher.this, false, false);
                    }
                }
            }
            cleanup();
        }

        private void cleanup() {
            mWorkspace.unlock();
            dismissDialog(DIALOG_RENAME_FOLDER);
            mWaitingForResult = false;
            mFolderInfo = null;
        }
    }

    /**
     * Displays the shortcut creation dialog and launches, if necessary, the
     * appropriate activity.
     */
    private class CreateShortcut implements DialogInterface.OnClickListener,
            DialogInterface.OnCancelListener, DialogInterface.OnDismissListener,
            DialogInterface.OnShowListener {

        private AddAdapter mAdapter;

        Dialog createDialog() {
            mWaitingForResult = true;

            mAdapter = new AddAdapter(Launcher.this);

            final AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setTitle(getString(R.string.menu_item_add_item));
            builder.setAdapter(mAdapter, this);

            builder.setInverseBackgroundForced(true);

            AlertDialog dialog = builder.create();
            dialog.setOnCancelListener(this);
            dialog.setOnDismissListener(this);
            dialog.setOnShowListener(this);

            return dialog;
        }

        public void onCancel(DialogInterface dialog) {
            mWaitingForResult = false;
            cleanup();
        }

        public void onDismiss(DialogInterface dialog) {
            mWorkspace.unlock();
        }

        private void cleanup() {
            mWorkspace.unlock();
            dismissDialog(DIALOG_CREATE_SHORTCUT);
        }

        /**
         * Handle the action clicked in the "Add to home" dialog.
         */
        public void onClick(DialogInterface dialog, int which) {
            Resources res = getResources();
            cleanup();

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
            // switch (which) {
			// BEGIN: 0004773 deukmo.koo@lge.com 2010-03-08
			// MOD 0004773: [Swift][LGHome] Add a menu for operator
			switch (((AddAdapter.ListItem) mAdapter.getItem(which)).actionTag) {
			// END: 0004773 deukmo.koo@lge.com 2010-03-08
// END LG_UI_HOME yoori.yoo 20100530 
                case AddAdapter.ITEM_SHORTCUT: {
                    // Insert extra item to handle picking application
                    pickShortcut(REQUEST_PICK_SHORTCUT, R.string.title_select_shortcut);
                    break;
                }

                case AddAdapter.ITEM_APPWIDGET: {
                    int appWidgetId = Launcher.this.mAppWidgetHost.allocateAppWidgetId();

                    Intent pickIntent = new Intent(AppWidgetManager.ACTION_APPWIDGET_PICK);
                    pickIntent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
// START LG_UI_HOME yoori.yoo 20100727 FROYO merge
                    /* // add the search widget
                    ArrayList<AppWidgetProviderInfo> customInfo =
                            new ArrayList<AppWidgetProviderInfo>();
                    AppWidgetProviderInfo info = new AppWidgetProviderInfo();
                    info.provider = new ComponentName(getPackageName(), "XXX.YYY");
                    info.label = getString(R.string.group_search);
                    info.icon = R.drawable.ic_search_widget;
                    customInfo.add(info);
                    pickIntent.putParcelableArrayListExtra(
                            AppWidgetManager.EXTRA_CUSTOM_INFO, customInfo);
                    ArrayList<Bundle> customExtras = new ArrayList<Bundle>();
                    Bundle b = new Bundle();
                    b.putString(EXTRA_CUSTOM_WIDGET, SEARCH_WIDGET);
                    customExtras.add(b);
                    pickIntent.putParcelableArrayListExtra(
                            AppWidgetManager.EXTRA_CUSTOM_EXTRAS, customExtras); */
// END LG_UI_HOME yoori.yoo 20100727 
                    // start the pick activity
                    startActivityForResult(pickIntent, REQUEST_PICK_APPWIDGET);
                    break;
                }
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
				// BEGIN: 0004773 deukmo.koo@lge.com 2010-03-08
				// ADD 0004773: [Swift][LGHome] Add a menu for operator
				case AddAdapter.ITEM_OPERATOR: {
					showDialog(DIALOG_SELECT_OPERATOR_APP);
					break;
				}
				// END: 0004773 deukmo.koo@lge.com 2010-03-08
// END LG_UI_HOME yoori.yoo 20100530 

                case AddAdapter.ITEM_LIVE_FOLDER: {
                    // Insert extra item to handle inserting folder
                    Bundle bundle = new Bundle();

                    ArrayList<String> shortcutNames = new ArrayList<String>();
                    shortcutNames.add(res.getString(R.string.group_folder));
                    bundle.putStringArrayList(Intent.EXTRA_SHORTCUT_NAME, shortcutNames);

                    ArrayList<ShortcutIconResource> shortcutIcons =
                            new ArrayList<ShortcutIconResource>();
                    shortcutIcons.add(ShortcutIconResource.fromContext(Launcher.this,
                            R.drawable.ic_launcher_folder));
                    bundle.putParcelableArrayList(Intent.EXTRA_SHORTCUT_ICON_RESOURCE, shortcutIcons);

                    Intent pickIntent = new Intent(Intent.ACTION_PICK_ACTIVITY);
                    pickIntent.putExtra(Intent.EXTRA_INTENT,
                            new Intent(LiveFolders.ACTION_CREATE_LIVE_FOLDER));
                    pickIntent.putExtra(Intent.EXTRA_TITLE,
                            getText(R.string.title_select_live_folder));
                    pickIntent.putExtras(bundle);

                    startActivityForResult(pickIntent, REQUEST_PICK_LIVE_FOLDER);
                    break;
                }

                case AddAdapter.ITEM_WALLPAPER: {
                    startWallpaper();
                    break;
                }
            }
        }

        public void onShow(DialogInterface dialog) {
            mWorkspace.lock();
        }
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	// BEGIN: 0004773 deukmo.koo@lge.com 2010-03-08
	// ADD 0004773: [Swift][LGHome] Add a menu for operator
	private class OperatorShortcut implements DialogInterface.OnClickListener,
            DialogInterface.OnCancelListener {

        private OperatorAdapter mAdapter;

        Dialog createDialog() {
            mAdapter = new OperatorAdapter(Launcher.this);

            final AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setTitle(getString(R.string.group_tsr));
            builder.setAdapter(mAdapter, this);

            builder.setInverseBackgroundForced(true);

			AlertDialog dialog = builder.create();
			dialog.setOnCancelListener(this);

			return dialog;
		}

		public void onCancel(DialogInterface dialog) {
			cleanup();
		}

		private void cleanup() {
			dismissDialog(DIALOG_CREATE_SHORTCUT);
		}
		
		public void onClick(DialogInterface dialog, int which) {
			OperatorAdapter.ListItem item = (OperatorAdapter.ListItem) mAdapter.getItem(which);
			
			Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            
            if (item.packageName != null && item.className != null) {
                // Valid package and class, so fill details as normal intent
                intent.setClassName(item.packageName, item.className);
                completeAddApplication(Launcher.this, intent, mAddItemCellInfo, !mDesktopLocked);
            }
		}
	}
	// END: 0004773 deukmo.koo@lge.com 2010-03-08
// END LG_UI_HOME yoori.yoo 20100530 
    }
    // BEGIN: 0002231 deukmo@lge.com 2009-12-03
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private class AddGroup {
    	private EditText mInput;
    	
        Dialog createDialog() {
            final View layout = View.inflate(Launcher.this, R.layout.add_group, null);
            mInput = (EditText) layout.findViewById(R.id.group_name);

            AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setIcon(0);
            builder.setTitle(getString(R.string.add_group_title));
            builder.setCancelable(true);
            builder.setOnCancelListener(new Dialog.OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cleanup();
				}
			});
			builder.setNegativeButton(getString(R.string.cancel_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							cleanup();
						}
					});
			builder.setPositiveButton(getString(R.string.rename_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							addGroup();
						}
					});
			builder.setView(layout);

			final AlertDialog dialog = builder.create();
			
			return dialog;
		}
        
        private void addGroup() {
        	// BEGIN: 0003247 deukmo@lge.com 2010-01-13
        	// MOD 0003247: [Swift][TopMenu] Change new category order
        	final int newGroupId = ALLAPPS_EDITABLE_GROUPNUM - mVisibleGroupNum - 1;
        	// END: 0003247 deukmo@lge.com 2010-01-13
        	final String groupName = mInput.getText().toString().trim();
        	
        	if(groupName.equals("")) return;
        	// BEGIN: 0003247 deukmo@lge.com 2010-01-13
        	// MOD 0003247: [Swift][TopMenu] Change new category order
        	if(newGroupId<0) return;
        	// END: 0003247 deukmo@lge.com 2010-01-13
        	
        	final TextView selectedAllAppsTitle = mAllAppsTitleArray[newGroupId];
        	selectedAllAppsTitle.setText(groupName);
        	selectedAllAppsTitle.setVisibility(View.VISIBLE);
        	mAllAppsGridArray[newGroupId].setVisibility(View.VISIBLE);
        	
        	mLoadedAllAppsTitleArray[newGroupId] = groupName;
        	mVisibleGroupNum++;
        	
        	final SharedPreferences userAllAppsTitleInfo = getSharedPreferences(ALLAPPS_PREFS_NAME, MODE_PRIVATE);
        	final SharedPreferences.Editor userAllAppsTitleInfoEditor = userAllAppsTitleInfo.edit();
        	userAllAppsTitleInfoEditor.putInt(TAG_VISIBLE_GROUPNUM, mVisibleGroupNum);
        	userAllAppsTitleInfoEditor.putString(TAG_GROUP_TITLE+newGroupId, groupName);
        	userAllAppsTitleInfoEditor.commit();
        }

		private void cleanup() {
			dismissDialog(DIALOG_ALLAPPS_ADD_GROUP);
		}
	}
	// END: 0002231 deukmo@lge.com 2009-12-03
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-04
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private class RenameGroup {
    	private EditText mInput;
    	
        Dialog createDialog() {
            final View layout = View.inflate(Launcher.this, R.layout.rename_group, null);
            mInput = (EditText) layout.findViewById(R.id.group_name);

            AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setIcon(0);
            builder.setTitle(getString(R.string.rename_group_title));
            builder.setCancelable(true);
            builder.setOnCancelListener(new Dialog.OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cleanup();
				}
			});
			builder.setNegativeButton(getString(R.string.cancel_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							cleanup();
						}
					});
			builder.setPositiveButton(getString(R.string.rename_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							renameGroup();
						}
					});
			builder.setView(layout);

			final AlertDialog dialog = builder.create();

			return dialog;
		}
        
        private void renameGroup() {
        	final int selectedGroupId = mSelectedGroupId;
        	final String groupName = mInput.getText().toString().trim();
        	
        	if(groupName.equals("")) return;
        	if(selectedGroupId<0 || selectedGroupId>=ALLAPPS_TOTAL_GROUPNUM) return;
        	
        	final TextView selectedAllAppsTitle = mAllAppsTitleArray[selectedGroupId];
        	selectedAllAppsTitle.setText(groupName);
        	
        	mLoadedAllAppsTitleArray[selectedGroupId] = groupName;
        	
        	final SharedPreferences userAllAppsTitleInfo = getSharedPreferences(ALLAPPS_PREFS_NAME, MODE_PRIVATE);
        	final SharedPreferences.Editor userAllAppsTitleInfoEditor = userAllAppsTitleInfo.edit();
        	userAllAppsTitleInfoEditor.putString(TAG_GROUP_TITLE+selectedGroupId, groupName);
        	userAllAppsTitleInfoEditor.commit();
        }

		private void cleanup() {
			dismissDialog(DIALOG_ALLAPPS_RENAME_GROUP);
		}
	}
	// END: 0002231 deukmo@lge.com 2009-12-04
    
	// BEGIN: 0002231 deukmo@lge.com 2009-12-04
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private class DeleteGroup {
        Dialog createDialog() {
            AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setIcon(android.R.drawable.ic_dialog_alert);
            builder.setTitle(getString(R.string.delete_group_title));
            builder.setMessage(getString(R.string.delete_group_message));
            builder.setCancelable(true);
            builder.setOnCancelListener(new Dialog.OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cleanup();
				}
			});
			builder.setNegativeButton(getString(R.string.cancel_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							cleanup();
						}
					});
			builder.setPositiveButton(getString(R.string.rename_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							deleteGroup();
						}
					});

			final AlertDialog dialog = builder.create();

			return dialog;
		}
        
        private void deleteGroup() {
        	final boolean[] checkedAllAppsGroups = mCheckedAllAppsGroups;
        	if(checkedAllAppsGroups==null) return;
        	
        	final SharedPreferences userAllAppsTitleInfo = getSharedPreferences(ALLAPPS_PREFS_NAME, MODE_PRIVATE);
        	final SharedPreferences.Editor userAllAppsTitleInfoEditor = userAllAppsTitleInfo.edit();
        	
        	final int count = checkedAllAppsGroups.length;
        	int deletedItemCount = 0;
        	for(int i=0; i<count; i++) {
        		if(checkedAllAppsGroups[i]) {
        			// BEGIN: 0003247 deukmo@lge.com 2010-01-13
        			// ADD 0003247: [Swift][TopMenu] Change new category order
        			final int selectedGroupId = ALLAPPS_EDITABLE_GROUPNUM - count + i;
        			// END: 0003247 deukmo@lge.com 2010-01-13
                	final ApplicationsAdapter adapter = (ApplicationsAdapter) mAllAppsGridArray[selectedGroupId].getAdapter();
                	final int childCount = adapter.getCount();
                    for (int j=0; j < childCount; j++) {
                        final ApplicationInfo applicationInfo = adapter.getItem(j);
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
                        // BEGIN: 0003843 deukmo.koo@lge.com 2010-02-04
						// MOD 0003843: [Swift][LGHome] Add operator category in Top Menu
                        Integer position = mDefaultAllAppsInfo.get(applicationInfo.intent.getComponent().getPackageName()+"/"+applicationInfo.intent.getComponent().getClassName());	// added
                        if(position==null) {	// added
	                        if(applicationInfo.isSystemApplication) {
	                        	applicationInfo.groupid = Launcher.ALLAPPS_SYSTEMAPP_GROUPID;
	                        } else {
	                        	applicationInfo.groupid = Launcher.ALLAPPS_DOWNLOAD_GROUPID;
	                        }
                        } else {	// added
                        	applicationInfo.groupid = position / DEFAULT_GROUPID_MULTIPLIER;
                        }
                        // END: 0003843 deukmo.koo@lge.com 2010-02-04
// END LG_UI_HOME yoori.yoo 20100530 
                        applicationInfo.position = Launcher.ALLAPPS_NEW_ADDED_ITEM_POSITION;
                        ((ApplicationsAdapter) mAllAppsGridArray[applicationInfo.groupid].getAdapter()).add(applicationInfo);
                    }
                    adapter.clear();
                    
                    // BEGIN: 0003247 deukmo@lge.com 2010-01-13
        			// ADD 0003247: [Swift][TopMenu] Change new category order
                    for(int j=selectedGroupId-1; j>=(ALLAPPS_EDITABLE_GROUPNUM-count+deletedItemCount); j--) {
                    // END: 0003247 deukmo@lge.com 2010-01-13
                    	// BEGIN: 0003247 deukmo@lge.com 2010-01-13
            			// ADD 0003247: [Swift][TopMenu] Change new category order
                    	userAllAppsTitleInfoEditor.putString(TAG_GROUP_TITLE+(j+1), mLoadedAllAppsTitleArray[j]);
                    	mAllAppsTitleArray[j+1].setText(mLoadedAllAppsTitleArray[j]);
                    	mLoadedAllAppsTitleArray[j+1] = mLoadedAllAppsTitleArray[j];
                    	// END: 0003247 deukmo@lge.com 2010-01-13
                    	
                    	final ApplicationsAdapter sourceAdapter = (ApplicationsAdapter) mAllAppsGridArray[j].getAdapter();
                    	// BEGIN: 0003247 deukmo@lge.com 2010-01-13
            			// ADD 0003247: [Swift][TopMenu] Change new category order
                    	final ApplicationsAdapter targetAdapter = (ApplicationsAdapter) mAllAppsGridArray[j+1].getAdapter();
                    	// END: 0003247 deukmo@lge.com 2010-01-13
                    	final int sourceChildCount = sourceAdapter.getCount();
                    	targetAdapter.clear();
                    	for (int k=0; k<sourceChildCount; k++) {
                            final ApplicationInfo applicationInfo = sourceAdapter.getItem(k);
                            // BEGIN: 0003247 deukmo@lge.com 2010-01-13
                			// ADD 0003247: [Swift][TopMenu] Change new category order
                            applicationInfo.groupid = j+1;
                            // END: 0003247 deukmo@lge.com 2010-01-13
                            targetAdapter.add(applicationInfo);
                        }
                    	sourceAdapter.clear();
                    }
                    
                	// BEGIN: 0003247 deukmo@lge.com 2010-01-13
        			// ADD 0003247: [Swift][TopMenu] Change new category order
                    final int lastGroupId = ALLAPPS_EDITABLE_GROUPNUM - count + deletedItemCount;
                    // END: 0003247 deukmo@lge.com 2010-01-13
                	mAllAppsTitleArray[lastGroupId].setVisibility(View.GONE);
                	mAllAppsGridArray[lastGroupId].setVisibility(View.GONE);
                	mVisibleGroupNum--;
                	deletedItemCount++;
        		}
        	}
        	
        	userAllAppsTitleInfoEditor.putInt(TAG_VISIBLE_GROUPNUM, mVisibleGroupNum);
        	userAllAppsTitleInfoEditor.commit();
        	
        	resizeAllAppsGridHeight();
        	doAllAppsDataSave();
        }

		private void cleanup() {
			dismissDialog(DIALOG_ALLAPPS_DELETE_GROUP);
		}
	}
	// END: 0002231 deukmo@lge.com 2009-12-04
    
	// BEGIN: 0002231 deukmo@lge.com 2009-12-04
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private class ResetGroup {
        Dialog createDialog() {
            AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setIcon(0);
            builder.setTitle(getString(R.string.reset_group_title));
            builder.setMessage(R.string.reset_group_message);
            builder.setCancelable(true);
            builder.setOnCancelListener(new Dialog.OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cleanup();
				}
			});
			builder.setNegativeButton(getString(R.string.cancel_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							cleanup();
						}
					});
			builder.setPositiveButton(getString(R.string.rename_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							resetGroup();
						}
					});

			final AlertDialog dialog = builder.create();

			return dialog;
		}
        
        private void resetGroup() {
        	final SharedPreferences userAllAppsTitleInfo = getSharedPreferences(ALLAPPS_PREFS_NAME, MODE_PRIVATE);
        	final SharedPreferences.Editor userAllAppsTitleInfoEditor = userAllAppsTitleInfo.edit();
        	
        	final ComponentName[] powerLauncherShortcutName = mPowerLauncherShortcutName;
        	final PackageManager manager = getPackageManager();
        	
        	ApplicationInfo info;
        	Intent intent;
        	ResolveInfo resolveInfo;
        	
        	mVisibleGroupNum = ALLAPPS_DEFAULT_VISIBLE_GROUPNUM;
        	userAllAppsTitleInfoEditor.putInt(TAG_VISIBLE_GROUPNUM, ALLAPPS_DEFAULT_VISIBLE_GROUPNUM);
        	
        	for (int i=0; i<ALLAPPS_TOTAL_GROUPNUM; i++) {
        		mLoadedAllAppsTitleArray[i] = mDefaultAllAppsTitleArray[i];
        		userAllAppsTitleInfoEditor.remove(TAG_GROUP_TITLE+i);
        		
        		mAllAppsTitleArray[i].setText(mDefaultAllAppsTitleArray[i]);
        		if(ALLAPPS_IS_DEFAULT_GROUP[i]) {
        			mAllAppsTitleArray[i].setVisibility(View.VISIBLE);
        			mAllAppsGridArray[i].setVisibility(View.VISIBLE);
        		} else {
        			mAllAppsTitleArray[i].setVisibility(View.GONE);
        			mAllAppsGridArray[i].setVisibility(View.GONE);
        		}
        		
        		((ApplicationsAdapter) mAllAppsGridArray[i].getAdapter()).clear();
        	}
        	userAllAppsTitleInfoEditor.commit();
        	
        	final ApplicationsAdapter adapter = sModel.getApplicationsAdapter();
        	final int count = adapter.getCount();
        	for (int i=0; i<count; i++) {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
        		// BEGIN: 0003843 deukmo.koo@lge.com 2010-02-04
				// MOD 0003843: [Swift][LGHome] Add operator category in Top Menu
        		final ApplicationInfo applicationInfo = adapter.getItem(i);
                Integer position = mDefaultAllAppsInfo.get(applicationInfo.intent.getComponent().getPackageName()+"/"+applicationInfo.intent.getComponent().getClassName());	// added
                if(position==null) {	// added
                    if(applicationInfo.isSystemApplication) {
                    	applicationInfo.groupid = Launcher.ALLAPPS_SYSTEMAPP_GROUPID;
                    } else {
                    	applicationInfo.groupid = Launcher.ALLAPPS_DOWNLOAD_GROUPID;
                    }
                } else {	// added
                	applicationInfo.groupid = position / DEFAULT_GROUPID_MULTIPLIER;
                }
                // END: 0003843 deukmo.koo@lge.com 2010-02-04
// END LG_UI_HOME yoori.yoo 20100530 
                applicationInfo.position = Launcher.ALLAPPS_NEW_ADDED_ITEM_POSITION;
                ((ApplicationsAdapter) mAllAppsGridArray[applicationInfo.groupid].getAdapter()).add(applicationInfo);
        	}
        	
        	resizeAllAppsGridHeight();
        	doAllAppsDataSave();
        	
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
        	// for(int i=0; i<4; i++) {
        	for(int i=0; i<mPowerLauncherShortcutView.length; i++) {
// END LG_UI_HOME yoori.yoo 20100530 
    			final String packageName = mDefaultPowerLauncherShortcutPackageName[i];
    			final String className = mDefaultPowerLauncherShortcutClassName[i];
    			powerLauncherShortcutName[i] = new ComponentName(packageName, className);
    			
    			info = new ApplicationInfo();
    			intent = new Intent();
    			intent.setComponent(powerLauncherShortcutName[i]);
    			resolveInfo = manager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY);
    			
    			if(resolveInfo!=null) {
    				info.icon = Utilities.createIconThumbnail(resolveInfo.activityInfo.loadIcon(manager), Launcher.this);
    				info.setActivity(powerLauncherShortcutName[i],
    						Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
    				mPowerLauncherShortcutView[i].setApplicationInfo(info);
    			} else {
    				mPowerLauncherShortcutView[i].setApplicationInfo(null);
    			}
    		}
        	
        	savePowerLauncherShortcut();
        	checkDownloadCategory();
        	
        	setAllAppsMode(ALLAPPS_MODE_GRID);
        }

		private void cleanup() {
			dismissDialog(DIALOG_ALLAPPS_RESET_GROUP);
		}
	}
	// END: 0002231 deukmo@lge.com 2009-12-04
	
	// BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private class SelectRenameGroup {
    	AlertDialog mAlertDialog;
    	
    	Dialog createDialog() {
    		AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setTitle(getString(R.string.rename_group_title));
            builder.setItems(mCurrentAllAppsGroups, new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {
					cleanup();
					showRenameGroupDialog(which);
				}
			});
            builder.setCancelable(true);
            builder.setOnCancelListener(new Dialog.OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cleanup();
				}
			});

			final AlertDialog dialog = builder.create();
			mAlertDialog = dialog;
			
			return dialog;
		}
    	
		private void cleanup() {
			if(mAlertDialog!=null) {
				mAlertDialog.dismiss();
			}
		}
	}
    // END: 0002231 deukmo@lge.com 2009-12-23
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private class SelectDeleteGroup {
    	AlertDialog mAlertDialog;
    	
    	Dialog createDialog() {
            AlertDialog.Builder builder = new AlertDialog.Builder(Launcher.this);
            builder.setTitle(getString(R.string.delete_grouplist_title));
            builder.setMultiChoiceItems(mCurrentAllAppsGroups, mCheckedAllAppsGroups, new DialogInterface.OnMultiChoiceClickListener() {
				public void onClick(DialogInterface dialog, int which, boolean isChecked) {
				}
			});
            builder.setCancelable(true);
            builder.setOnCancelListener(new Dialog.OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cleanup();
				}
			});
			builder.setNegativeButton(getString(R.string.cancel_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							cleanup();
						}
					});
			builder.setPositiveButton(getString(R.string.delete_action),
					new Dialog.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {
							cleanup();
							showDeleteGroupDialog();
						}
					});

			final AlertDialog dialog = builder.create();
			mAlertDialog = dialog;
			
			return dialog;
		}
    	
    	private void cleanup() {
			if(mAlertDialog!=null) {
				mAlertDialog.dismiss();
			}
		}
	}
    // END: 0002231 deukmo@lge.com 2009-12-23
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private class UninstallApp implements View.OnClickListener {
    	private Button mOkButton;
    	private Button mCancelButton;
    	
        Dialog createDialog() {
        	final Dialog dialog = new Dialog(Launcher.this);
        	dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        	dialog.setCancelable(true);
        	dialog.setOnCancelListener(new Dialog.OnCancelListener() {
				public void onCancel(DialogInterface dialog) {
					cleanup();
				}
			});
        	dialog.setContentView(R.layout.delete_application);
        	
        	mOkButton = (Button) dialog.findViewById(R.id.button_ok);
        	mOkButton.setOnClickListener(this);
        	mCancelButton = (Button) dialog.findViewById(R.id.button_cancel);
        	mCancelButton.setOnClickListener(this);
        	
        	mTotalSize = (TextView) dialog.findViewById(R.id.total_size_text);
			mApplicationSize = (TextView) dialog.findViewById(R.id.application_size_text);
			mDataSize = (TextView) dialog.findViewById(R.id.data_size_text);
        	
			return dialog;
		}
        
        public void onClick(View v) {
			if(v==mOkButton) {
				if(mUninstallApplicationInfo!=null && !mUninstallApplicationInfo.isSystemApplication) {
					getPackageManager().deletePackage(mUninstallApplicationInfo.intent.getComponent().getPackageName(), mPackageDeleteObserver, 0);
					mProgressDialog = ProgressDialog.show(Launcher.this, "", getString(R.string.uninstall_progress_message), true);
				}
				cleanup();
			} else if(v==mCancelButton) {
				cleanup();
			}
		}

		private void cleanup() {
			dismissDialog(DIALOG_ALLAPPS_UNINSTALL_APP);
		}
	}
    // END: 0002231 deukmo@lge.com 2009-12-23
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    class PackageDeleteObserver extends IPackageDeleteObserver.Stub {
        public void packageDeleted(boolean succeeded) {
        	mProgressDialog.dismiss();
        }
    }
    // END: 0002231 deukmo@lge.com 2009-12-23
    /**
	 * Receives notifications when applications are added/removed.
	 */
    private class ApplicationsIntentReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            final String packageName = intent.getData().getSchemeSpecificPart();
            final boolean replacing = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false);

            if (LauncherModel.DEBUG_LOADERS) {
                d(LauncherModel.LOG_TAG, "application intent received: " + action +
                        ", replacing=" + replacing);
                d(LauncherModel.LOG_TAG, "  --> " + intent.getData());
            }

            if (!Intent.ACTION_PACKAGE_CHANGED.equals(action)) {
                if (Intent.ACTION_PACKAGE_REMOVED.equals(action)) {
                    if (!replacing) {
                        removeShortcutsForPackage(packageName);
                        if (LauncherModel.DEBUG_LOADERS) {
                            d(LauncherModel.LOG_TAG, "  --> remove package");
                        }
                        sModel.removePackage(Launcher.this, packageName);
                    }
                    // else, we are replacing the package, so a PACKAGE_ADDED will be sent
                    // later, we will update the package at this time
                } else {
                    if (!replacing) {
                        if (LauncherModel.DEBUG_LOADERS) {
                            d(LauncherModel.LOG_TAG, "  --> add package");
                        }
                        sModel.addPackage(Launcher.this, packageName);
                    } else {
                        if (LauncherModel.DEBUG_LOADERS) {
                            d(LauncherModel.LOG_TAG, "  --> update package " + packageName);
                        }
                        sModel.updatePackage(Launcher.this, packageName);
                        updateShortcutsForPackage(packageName);
                    }
                }
                removeDialog(DIALOG_CREATE_SHORTCUT);
            } else {
                if (LauncherModel.DEBUG_LOADERS) {
                    d(LauncherModel.LOG_TAG, "  --> sync package " + packageName);
                }
                sModel.syncPackage(Launcher.this, packageName);
            }
        }
    }

    /**
     * Receives notifications when applications are added/removed.
     */
    private class CloseSystemDialogsIntentReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            closeSystemDialogs();
        }
    }
    
// START yoori.yoo 20100823 : VVM Icon Update   
    /**
     * Receives notifications when VVMs are received.
     */
    private class NewVvmIntentReceiver extends BroadcastReceiver {
    	private static final String ACTION_NEW_VVM =
            "com.lge.vvm.NEW_VVM_NOTIFICATION_RECEIVED";
        @Override
        public void onReceive(Context context, Intent intent) {
        	if (!ACTION_NEW_VVM.equals(intent.getAction())) {
                return;
            }
        	
        	mUnreadVvms = intent.getIntExtra("vvm_unreadcount", 0);
			// Toast.makeText(Launcher.this, "Unread message count is " + mUnreadVvms, Toast.LENGTH_SHORT).show();
	    	mWorkspace.invalidate();
        }
    }
    public int getVvmUpdateNum(){
		return mUnreadVvms ;
	}
// END yoori.yoo 20100823     

// START yoori.yoo 20100906 : Top Menu - End Key - Idle
    private class EndKeyEventReceiver extends BroadcastReceiver {
    	private static final String ACTION_END_KEY_PRESSED =
            "android.intent.action.LAUNCHER_END_KEY_PRESSED";
        @Override
        public void onReceive(Context context, Intent intent) {
        	if (!ACTION_END_KEY_PRESSED.equals(intent.getAction())) {
                return;
            }
        	
        	if(isAllAppOpened) {
    			mDrawer.close();
    			isAllAppOpened = false;
        	}
        }
    }
// END yoori.yoo 20100906 

    /**
     * Receives notifications whenever the user favorites have changed.
     */
    private class FavoritesChangeObserver extends ContentObserver {
        public FavoritesChangeObserver() {
            super(new Handler());
        }

        @Override
        public void onChange(boolean selfChange) {
            onFavoritesChanged();
        }
    }

    /**
     * Receives notifications whenever the appwidgets are reset.
     */
    private class AppWidgetResetObserver extends ContentObserver {
        public AppWidgetResetObserver() {
            super(new Handler());
        }

        @Override
        public void onChange(boolean selfChange) {
            onAppWidgetReset();
        }
    }

    private class DrawerManager implements SlidingDrawer.OnDrawerOpenListener,
            SlidingDrawer.OnDrawerCloseListener, SlidingDrawer.OnDrawerScrollListener {
        private boolean mOpen;

		

		public void onDrawerOpened() {
			if (!mOpen) {
			    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
                // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
				//mBottomButton4.setBackgroundDrawable(getResources().getDrawable(R.drawable.allapps_button_down));

				//added by hwang072 for Vs740 2010-01-19
				// mMenu_handle_Layout.setBackgroundDrawable(getResources().getDrawable(R.drawable.handle_top));
	
				// END: 0002231 deukmo@lge.com 2009-12-23

				mOpen = true;
// START yoori.yoo 20100829 ; Qcom optimization for hide walllaper
				// mWorkspace.hideWallpaper(true); 20100830 yoori.yoo
// END yoori.yoo 20100829 
				isAllAppOpened=true;//Added by hwang072 for bug fix 2010-03-18
// START yoori.yoo 20100909 : VS660 Merge for Top Menu Home Button
				changeMenuHomeButton();
// END yoori.yoo 20100909 
			}
		}

		public void onDrawerClosed() {
			//added by yangkeunyong for Vs740 2010-03-02
			final int allAppsMode = getAllAppsMode();
			if (mOpen) {
			    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
                // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
				//mBottomButton4.setBackgroundDrawable(getResources().getDrawable(R.drawable.allapps_button_up));
				// BEGIN: 0003365 deukmo.koo@lge.com 2010-01-18
                // ADD 0003365: [Swift][TopMenu] Change menu position reset timing
                mScrollView.scrollTo(0, 0);
                // END: 0003365 deukmo.koo@lge.com 2010-01-18
				// END: 0002231 deukmo@lge.com 2009-12-23
				
                //added by yangkeunyong for Vs740 2010-03-02
                if(allAppsMode!=ALLAPPS_MODE_GRID){
                	doAllAppsDataSave();
                	setAllAppsMode(ALLAPPS_MODE_GRID);                	
                }
                
				//added by hwang072 for Vs740 2010-01-19
				// mMenu_handle_Layout.setBackgroundDrawable(getResources().getDrawable(R.drawable.handle_bottom));

				mOpen = false;
// START yoori.yoo 20100829 ; Qcom optimization for hide walllaper
				// mWorkspace.hideWallpaper(false); 20100830 yoori.yoo
// END yoori.yoo 20100829 
				isAllAppOpened=false;//Added by hwang072 for bug fix 2010-03-18
// START yoori.yoo 20100909 : VS660 Merge for Top Menu Home Button
				changeMenuHomeButton();
// END yoori.yoo 20100909 
			}
		}

		public void onScrollStarted() {
			if (PROFILE_DRAWER) {
				android.os.Debug.startMethodTracing("/sdcard/launcher-drawer");
			}
            
            // BEGIN: 0002231 deukmo@lge.com 2009-12-23
            // DEL 0002231: [Swift][TopMenu] Add Top Menu in LGHome
			//mWorkspace.mDrawerContentWidth = mAllAppsGrid.getWidth();
			//mWorkspace.mDrawerContentHeight = mAllAppsGrid.getHeight();
			// END: 0002231 deukmo@lge.com 2009-12-23
		}

        public void onScrollEnded() {
            if (PROFILE_DRAWER) {
                android.os.Debug.stopMethodTracing();
            }
        }
    }

    private static class DesktopBinder extends Handler implements MessageQueue.IdleHandler {
        static final int MESSAGE_BIND_ITEMS = 0x1;
        static final int MESSAGE_BIND_APPWIDGETS = 0x2;
        static final int MESSAGE_BIND_DRAWER = 0x3;

        // Number of items to bind in every pass
        static final int ITEMS_COUNT = 6;

		private final ArrayList<ItemInfo> mShortcuts;
		private final LinkedList<LauncherAppWidgetInfo> mAppWidgets;
		private final ApplicationsAdapter mDrawerAdapter;
		private final WeakReference<Launcher> mLauncher;
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		private final ApplicationsAdapter[] mDrawerAdapterArray;
		// END: 0002231 deukmo@lge.com 2009-12-03

		public boolean mTerminate = false;
		
		// BEGIN: 0002231 deukmo@lge.com 2009-12-03
		// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
		DesktopBinder(Launcher launcher, ArrayList<ItemInfo> shortcuts,
				ArrayList<LauncherAppWidgetInfo> appWidgets,
				ApplicationsAdapter drawerAdapter,
				ApplicationsAdapter[] drawerAdapterArray) {
		// END: 0002231 deukmo@lge.com 2009-12-03

			mLauncher = new WeakReference<Launcher>(launcher);
			mShortcuts = shortcuts;
			mDrawerAdapter = drawerAdapter;
			// BEGIN: 0002231 deukmo@lge.com 2009-12-03
			// ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
			mDrawerAdapterArray = drawerAdapterArray;
			// END: 0002231 deukmo@lge.com 2009-12-03

            // Sort widgets so active workspace is bound first
            final int currentScreen = launcher.mWorkspace.getCurrentScreen();
            final int size = appWidgets.size();
            mAppWidgets = new LinkedList<LauncherAppWidgetInfo>();

            for (int i = 0; i < size; i++) {
                LauncherAppWidgetInfo appWidgetInfo = appWidgets.get(i);
                if (appWidgetInfo.screen == currentScreen) {
                    mAppWidgets.addFirst(appWidgetInfo);
                } else {
                    mAppWidgets.addLast(appWidgetInfo);
                }
            }

            if (LauncherModel.DEBUG_LOADERS) {
                d(Launcher.LOG_TAG, "------> binding " + shortcuts.size() + " items");
                d(Launcher.LOG_TAG, "------> binding " + appWidgets.size() + " widgets");
            }
        }

        public void startBindingItems() {
            if (LauncherModel.DEBUG_LOADERS) d(Launcher.LOG_TAG, "------> start binding items");
            obtainMessage(MESSAGE_BIND_ITEMS, 0, mShortcuts.size()).sendToTarget();
        }

        public void startBindingDrawer() {
            obtainMessage(MESSAGE_BIND_DRAWER).sendToTarget();
        }

        public void startBindingAppWidgetsWhenIdle() {
            // Ask for notification when message queue becomes idle
            final MessageQueue messageQueue = Looper.myQueue();
            messageQueue.addIdleHandler(this);
        }

        public boolean queueIdle() {
            // Queue is idle, so start binding items
            startBindingAppWidgets();
            return false;
        }

        public void startBindingAppWidgets() {
            obtainMessage(MESSAGE_BIND_APPWIDGETS).sendToTarget();
        }

        @Override
        public void handleMessage(Message msg) {
            Launcher launcher = mLauncher.get();
            if (launcher == null || mTerminate) {
                return;
            }

			switch (msg.what) {
			case MESSAGE_BIND_ITEMS: {
				launcher.bindItems(this, mShortcuts, msg.arg1, msg.arg2);
				break;
			}
			case MESSAGE_BIND_DRAWER: {
				// BEGIN: 0002231 deukmo@lge.com 2009-12-03
				// MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
				launcher.bindDrawer(this, mDrawerAdapter, mDrawerAdapterArray);
				// END: 0002231 deukmo@lge.com 2009-12-03
				break;
			}
			case MESSAGE_BIND_APPWIDGETS: {
				launcher.bindAppWidgets(this, mAppWidgets);
				break;
			}
			}
		}
		
	} 
    
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	/* private void setWorkspaceNum(int homeNumber, boolean flag) {
		CellLayout cell1= (CellLayout) findViewById(R.id.cell1);
		CellLayout cell2= (CellLayout) findViewById(R.id.cell2);
		if(flag){  
			switch(homeNumber){
			case 7: 	
				cell1.setVisibility(View.VISIBLE);
				cell2.setVisibility(View.VISIBLE);
				mWorkspace.setSetting(0);
			break;
			case 5:
				cell1.setVisibility(View.GONE);
				cell2.setVisibility(View.VISIBLE);
				mWorkspace.setSetting(1);
				break;
			case 3:
				cell1.setVisibility(View.GONE);
				cell2.setVisibility(View.GONE);
				mWorkspace.setSetting(2);
				break;
			}
		}
	} */
	
    // BEGIN: 0004467 deukmo.koo@lge.com 2010-02-27
	// MOD 0004467: [Swift][LGHome] Change the algorithm of selecting home number in LG Home
    private void initWorkspace() {
		// BEGIN: 0004008 deukmo.koo@lge.com 2010-03-05
		// MOD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
		final ImageView[] indicator = mIndicator;
		final Workspace workspace = mWorkspace;
		final CellLayout cell1 = (CellLayout) workspace.getChildAt(0);
		final CellLayout cell2 = (CellLayout) workspace.getChildAt(1);
		final CellLayout cell6 = (CellLayout) workspace.getChildAt(5);
		final CellLayout cell7 = (CellLayout) workspace.getChildAt(6);
		
		switch(mHomeNumber) {
			case 5:
				cell1.setVisibility(View.GONE);
				cell2.setVisibility(View.VISIBLE);
				cell6.setVisibility(View.VISIBLE);
				cell7.setVisibility(View.GONE);
				indicator[0].setVisibility(View.GONE);
				indicator[1].setVisibility(View.VISIBLE);
				indicator[5].setVisibility(View.VISIBLE);
				indicator[6].setVisibility(View.GONE);
				break;
			case 7: 	
				cell1.setVisibility(View.VISIBLE);
				cell2.setVisibility(View.VISIBLE);
				cell6.setVisibility(View.VISIBLE);
				cell7.setVisibility(View.VISIBLE);
				indicator[0].setVisibility(View.VISIBLE);
				indicator[1].setVisibility(View.VISIBLE);
				indicator[5].setVisibility(View.VISIBLE);
				indicator[6].setVisibility(View.VISIBLE);
				break;
		}
		// END: 0004008 deukmo.koo@lge.com 2010-03-05
	}
	// END: 0004467 deukmo.koo@lge.com 2010-02-27
// END LG_UI_HOME yoori.yoo 20100530 
	
	// BEGIN: 0003028 deukmo@lge.com 2010-01-05
    // MOD 0003028: [Swift][LGHome] Modify indicator bar in LGHome
	int getHomeNumber(){
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		return mHomeNumber;
		// return 5;
// END LG_UI_HOME yoori.yoo 20100530 
	}
	
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	/* static void setHomeNumber(int homeNumber){
		//mHomeNumber = homeNumber;
		mHomeNumber = 5;
	} */
// END LG_UI_HOME yoori.yoo 20100530 
	// END: 0003028 deukmo@lge.com 2010-01-05
	
	// BEGIN: 0003028 deukmo@lge.com 2010-01-05
    // ADD 0003028: [Swift][LGHome] Modify indicator bar in LGHome
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
    // BEGIN: 0004008 deukmo.koo@lge.com 2010-02-12
	// MOD 0004008: [Swift][TopMenu] Change Launcher GUI & algorithm
	void setIndicatorPosition(int position) {
		/* final int homeNumber = Launcher.mHomeNumber;
		
		RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) mIndicatorBar.getLayoutParams();
		if(mPreHomeNumber!=homeNumber) {
			params.width = 306 / homeNumber;
			mPreHomeNumber = homeNumber;
		}
		params.leftMargin = 7 + (position * 307 / (homeNumber * 320));
		mIndicatorBar.setLayoutParams(params); */
		final ImageView[] indicator = mIndicator;
		
		for(int i=0; i<7; i++) {
			indicator[i].setImageResource(R.drawable.indicator_normal);
		}
		indicator[position].setImageResource(R.drawable.indicator_selected);
	}
	// END: 0004008 deukmo.koo@lge.com 2010-02-12
	// END: 0003028 deukmo@lge.com 2010-01-05
// END LG_UI_HOME yoori.yoo 20100530 

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	// BEGIN: 0004467 deukmo.koo@lge.com 2010-03-13
	// ADD 0004467: [Swift][LGHome] Change the algorithm of selecting home number in LG Home
	static int getDefaultHomeNumber() {
    /*	final String opCode = Settings.FlexInfo_Operator.getOperatorCode();
    	if(opCode.equals("CLR") || opCode.equals("TIM")) {
    		return 3;
    	} else if(opCode.equals("SFR") || opCode.equals("TSR") || opCode.equals("VIV")) {
        	return 7;
        */
        
    	return 5;
    }
    // END: 0004467 deukmo.koo@lge.com 2010-03-13
// END LG_UI_HOME yoori.yoo 20100530 
        
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
    // BEGIN: 0004707 deukmo.koo@lge.com 2010-03-10
	// ADD 0004707: [Swift][LGHome] Set default theme for operator
	public static String getDefaultTheme() {
    /*	final String opCode = Settings.FlexInfo_Operator.getOperatorCode();
    	if(opCode.equals("SFR")) {
        	return Andy_RadioImageListDialog_Activity.mHomeThemeList[3];
        } else if(opCode.equals("TSR")) {
        	return Andy_RadioImageListDialog_Activity.mHomeThemeList[0];
        } else if(opCode.equals("OPEN")) {
        	return Andy_RadioImageListDialog_Activity.mHomeThemeList[2];
        }*/
        
    	return Andy_RadioImageListDialog_Activity.mHomeThemeList[0];
    }
	// END: 0004707 deukmo.koo@lge.com 2010-03-10
// END LG_UI_HOME yoori.yoo 20100530 

//added by hwang072 for Vs740 2010-01-19
	boolean getOrientationstate(){

		final Display display = getWindowManager().getDefaultDisplay();
		 return mIsPortrait= display.getWidth() < display.getHeight();

		}
	 
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
	/* public void setIndication(int nextScreen){
		for(int i=0;i<imageViewGroup.length;i++)
			imageViewGroup[i].setImageResource(R.drawable.launcher_indi_off);
		imageViewGroup[nextScreen-1].setImageResource(R.drawable.launcher_indi_on);
	} */
// END LG_UI_HOME yoori.yoo 20100530 

	//added by hwang072 for Vs740 2010-02-22
	public void draweraction(){
		if (isDrawerDown()){
			 mDrawer.animateOpen();	
			 isAllAppOpened=true; //Added by hwang072 for bug fix 2010-03-18
		}
		else{
			 mDrawer.animateClose();   
			 isAllAppOpened=false;//Added by hwang072 for bug fix 2010-03-18
		 }		
		}
	
}
