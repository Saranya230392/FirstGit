/*
 * Copyright (C) 2007 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

import android.content.Intent;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.preference.PreferenceScreen;

// BEGIN: 0002822 taesu84.kim@lge.com 2009-12-28
// MOD 0002822: [Swift][Launcher] home indicator bar is synchronized with home screen when it is rebooted & dialog errors in home settings
public class Andy_NewPreference_Activity extends PreferenceActivity {
	static final String HOME_SETTING = "Home Settings";
	
	static final String SET_HOME_NUMBER = "Set the number of screens";
	static final String SET_HOME_THEME = "Set home theme";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle(R.string.home_settings);
		// Load the XML preferences file
		addPreferencesFromResource(R.xml.andy_newpreferences_activity);
	}

	@Override
	public boolean onPreferenceTreeClick(PreferenceScreen preferenceScreen,
			Preference preference) {
		if(preference instanceof Andy_NewPreference) {
			Intent mIntent = new Intent();
			Andy_NewPreference pref = (Andy_NewPreference) preference;
			if (pref.getKey() != null) {
				if (pref.getKey().equals(SET_HOME_NUMBER)) {
					mIntent.putExtra(HOME_SETTING, SET_HOME_NUMBER);
				} else if (pref.getKey().equals(SET_HOME_THEME)) {
					mIntent.putExtra(HOME_SETTING, SET_HOME_THEME);
				}
				mIntent.setClass(Andy_NewPreference_Activity.this,
						Andy_RadioImageListDialog_Activity.class);
				startActivity(mIntent);
				return true;
			}
			return false;
		} else {
			return super.onPreferenceTreeClick(preferenceScreen, preference);
		}
	}
// END: 0002822 taesu84.kim@lge.com 2009-12-28
}
