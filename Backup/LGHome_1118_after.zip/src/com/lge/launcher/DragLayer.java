/*
 * Copyright (C) 2008 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.lge.launcher;

//LG_VZW_LAUNCHING_KIT_DEMO
import android.content.ComponentName;
//LG_VZW_LAUNCHING_KIT_DEMO
import android.content.Context;
// START yoori.yoo 20100906 : Test Shortcut cannot be deleted
import android.content.Intent;
// END yoori.yoo 20100906 
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.util.Log;
import android.view.Display;
import android.view.Window;
import android.widget.Toast;




/**
 * A ViewGroup that coordinated dragging across its dscendants
 */
public class DragLayer extends FrameLayout implements DragController {
    private static final int SCROLL_DELAY = 600;
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
    private static final int SCROLL_ZONE = 40 /* 50 */;// [VS740] bykong 40 => 50
// END LG_UI_HOME yoori.yoo 20100530 
    private static final int VIBRATE_DURATION = 35;
    private static final int ANIMATION_SCALE_UP_DURATION = 110;

    private static final boolean PROFILE_DRAWING_DURING_DRAG = false;

    // Number of pixels to add to the dragged item for scaling
    private static final float DRAG_SCALE = 24.0f;
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
    private static final int SCROLL_ZONE_FOR_ALLAPPS = 40 /* 80 */; //20->50 ; modified by hwang072 for Vs740 2010-01-03
// START LG_UI_HOME yoori.yoo 20100810 VS660(0802) merge
    private static final int SCROLL_DELAY_FOR_ALLAPPS = 10; // 200;
    private static final int SCROLL_DISTANCE_FOR_ALLAPPS = 20; // 45 /* 50 */;
// END LG_UI_HOME yoori.yoo 20100810 
    private static final int POWER_LAUNCHER_ZONE = 113;
    private static final int TEXT_MESSAGE_ZONE = 60 /* 80 */; //added by hwang072 for Vs740 2010-01-19
// END LG_UI_HOME yoori.yoo 20100530 
    // END: 0002231 deukmo@lge.com 2009-12-23

    private boolean mDragging = false;
    private boolean mShouldDrop;
    private float mLastMotionX;
    private float mLastMotionY;

    /**
     * The bitmap that is currently being dragged
     */
    private Bitmap mDragBitmap = null;
    private View mOriginator;

    private int mBitmapOffsetX;
    private int mBitmapOffsetY;

    /**
     * X offset from where we touched on the cell to its upper-left corner
     */
    private float mTouchOffsetX;

    /**
     * Y offset from where we touched on the cell to its upper-left corner
     */
    private float mTouchOffsetY;

    /**
     * Utility rectangle
     */
    private Rect mDragRect = new Rect();

    /**
     * Where the drag originated
     */
    private DragSource mDragSource;

    /**
     * The data associated with the object being dragged
     */
    private Object mDragInfo;

    private final Rect mRect = new Rect();
    private final int[] mDropCoordinates = new int[2];

    private final Vibrator mVibrator = new Vibrator();

    private DragListener mListener;

    private DragScroller mDragScroller;

    private static final int SCROLL_OUTSIDE_ZONE = 0;
    private static final int SCROLL_WAITING_IN_ZONE = 1;

    private static final int SCROLL_LEFT = 0;
    private static final int SCROLL_RIGHT = 1;
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private static final int SCROLL_UP = 2;
    private static final int SCROLL_DOWN = 3;
    // END: 0002231 deukmo@lge.com 2009-12-23

    private int mScrollState = SCROLL_OUTSIDE_ZONE;

    private ScrollRunnable mScrollRunnable = new ScrollRunnable();
    private View mIgnoredDropTarget;

    private RectF mDragRegion;
    private boolean mEnteredRegion;
    private DropTarget mLastDropTarget;

    private final Paint mTrashPaint = new Paint();
    private Paint mDragPaint;

    private static final int ANIMATION_STATE_STARTING = 1;
    private static final int ANIMATION_STATE_RUNNING = 2;
    private static final int ANIMATION_STATE_DONE = 3;

    private static final int ANIMATION_TYPE_SCALE = 1;

    private float mAnimationFrom;
    private float mAnimationTo;
    private int mAnimationDuration;
    private long mAnimationStartTime;
    private int mAnimationType;
    private int mAnimationState = ANIMATION_STATE_DONE;

    private InputMethodManager mInputMethodManager;
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    private Launcher mLauncher;
    private ScrollView mAllAppsScrollView;
    
    private boolean mListenerStarted;
    // END: 0002231 deukmo@lge.com 2009-12-23

    /**
     * Used to create a new DragLayer from XML.
     *
     * @param context The application's context.
     * @param attrs The attribtues set containing the Workspace's customization values.
     */
    public DragLayer(Context context, AttributeSet attrs) {
        super(context, attrs);

        final int srcColor = context.getResources().getColor(R.color.delete_color_filter);
        mTrashPaint.setColorFilter(new PorterDuffColorFilter(srcColor, PorterDuff.Mode.SRC_ATOP));

        // Make estimated paint area in gray
        int snagColor = context.getResources().getColor(R.color.snag_callout_color);
        Paint estimatedPaint = new Paint();
        estimatedPaint.setColor(snagColor);
        estimatedPaint.setStrokeWidth(3);
        estimatedPaint.setAntiAlias(true);

    }

    public void startDrag(View v, DragSource source, Object dragInfo, int dragAction) {
        if (PROFILE_DRAWING_DURING_DRAG) {
            android.os.Debug.startMethodTracing("Launcher");
        }

        // Hide soft keyboard, if visible
        if (mInputMethodManager == null) {
            mInputMethodManager = (InputMethodManager)
                getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        }
        mInputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
        
        // BEGIN: 0002231 deukmo@lge.com 2009-12-23
        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
        mListenerStarted = false;
        mLauncher.isInstaceOfTopmenu = false;	//modfied by kumjoo.hwang for C710 2010-06-07
        if (mListener != null && !(source instanceof AllAppsGridView)) {
        	mListenerStarted = true;
        	mListener.onDragStart(v, source, dragInfo, dragAction);
        }

    	if(source instanceof AllAppsGridView) {	//modfied by kumjoo.hwang for C710 2010-06-07
    		mLauncher.isInstaceOfTopmenu=true; 
    	}
	
        // END: 0002231 deukmo@lge.com 2009-12-23

        Rect r = mDragRect;
        r.set(v.getScrollX(), v.getScrollY(), 0, 0);

        offsetDescendantRectToMyCoords(v, r);
        mTouchOffsetX = mLastMotionX - r.left;
        mTouchOffsetY = mLastMotionY - r.top;

        v.clearFocus();
        v.setPressed(false);

        boolean willNotCache = v.willNotCacheDrawing();
        v.setWillNotCacheDrawing(false);

        // Reset the drawing cache background color to fully transparent
        // for the duration of this operation
        int color = v.getDrawingCacheBackgroundColor();
        v.setDrawingCacheBackgroundColor(0);

        if (color != 0) {
            v.destroyDrawingCache();
        }
        v.buildDrawingCache();
        Bitmap viewBitmap = v.getDrawingCache();
        int width = viewBitmap.getWidth();
        int height = viewBitmap.getHeight();

        Matrix scale = new Matrix();
        float scaleFactor = v.getWidth();
        scaleFactor = (scaleFactor + DRAG_SCALE) /scaleFactor;
        scale.setScale(scaleFactor, scaleFactor);

        mAnimationTo = 1.0f;
        mAnimationFrom = 1.0f / scaleFactor;
        mAnimationDuration = ANIMATION_SCALE_UP_DURATION;
        mAnimationState = ANIMATION_STATE_STARTING;
        mAnimationType = ANIMATION_TYPE_SCALE;

        mDragBitmap = Bitmap.createBitmap(viewBitmap, 0, 0, width, height, scale, true);
        v.destroyDrawingCache();
        v.setWillNotCacheDrawing(willNotCache);
        v.setDrawingCacheBackgroundColor(color);

        final Bitmap dragBitmap = mDragBitmap;
        mBitmapOffsetX = (dragBitmap.getWidth() - width) / 2;
        mBitmapOffsetY = (dragBitmap.getHeight() - height) / 2;

        if (dragAction == DRAG_ACTION_MOVE) {
            v.setVisibility(GONE);
        }

        mDragPaint = null;
        mDragging = true;
        mShouldDrop = true;
        mOriginator = v;
        mDragSource = source;
        mDragInfo = dragInfo;

        mVibrator.vibrate(VIBRATE_DURATION);

        mEnteredRegion = false;

        invalidate();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        return mDragging || super.dispatchKeyEvent(event);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);

        if (mDragging && mDragBitmap != null) {
            if (mAnimationState == ANIMATION_STATE_STARTING) {
                mAnimationStartTime = SystemClock.uptimeMillis();
                mAnimationState = ANIMATION_STATE_RUNNING;
            }

            if (mAnimationState == ANIMATION_STATE_RUNNING) {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
                // BEGIN: 0003519 deukmo.koo@lge.com 2010-01-25
                // MOD 0003519: [Swift][TopMenu] Change drag animation timing
                // float normalized = (float) (SystemClock.uptimeMillis() - mAnimationStartTime) /
                float normalized = (float) (SystemClock.uptimeMillis() - mAnimationStartTime - 200) /
                        mAnimationDuration;
                if (normalized >= 1.0f) {
                    mAnimationState = ANIMATION_STATE_DONE;
                }
                // normalized = Math.min(normalized, 1.0f);
                normalized = Math.max(Math.min(normalized, 1.0f), 0.0f);
                // END: 0003519 deukmo.koo@lge.com 2010-01-25
// END LG_UI_HOME yoori.yoo 20100530 
                final float value = mAnimationFrom  + (mAnimationTo - mAnimationFrom) * normalized;

                switch (mAnimationType) {
                    case ANIMATION_TYPE_SCALE:
                        final Bitmap dragBitmap = mDragBitmap;
                        canvas.save();
                        canvas.translate(mScrollX + mLastMotionX - mTouchOffsetX - mBitmapOffsetX,
                                mScrollY + mLastMotionY - mTouchOffsetY - mBitmapOffsetY);
                        canvas.translate((dragBitmap.getWidth() * (1.0f - value)) / 2,
                                (dragBitmap.getHeight() * (1.0f - value)) / 2);
                        canvas.scale(value, value);
                        canvas.drawBitmap(dragBitmap, 0.0f, 0.0f, mDragPaint);
                        canvas.restore();
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
                        // BEGIN: 0003519 deukmo.koo@lge.com 2010-01-25
                        // ADD 0003519: [Swift][TopMenu] Change drag animation timing
                        invalidate();
                        // END: 0003519 deukmo.koo@lge.com 2010-01-25
// END LG_UI_HOME yoori.yoo 20100530 
                        break;
                }
            } else {
                // Draw actual icon being dragged
                canvas.drawBitmap(mDragBitmap,
                        mScrollX + mLastMotionX - mTouchOffsetX - mBitmapOffsetX,
                        mScrollY + mLastMotionY - mTouchOffsetY - mBitmapOffsetY, mDragPaint);
            }
        }
    }

//added by hwang072 for bug fix 2010-03-16 
	/**
	  * Stop dragging without dropping.
	  */
	 public void cancelDrag() {
		 endDrag();
	 }

    private void endDrag() {
        if (mDragging) {
            mDragging = false;
            if (mDragBitmap != null) {
                mDragBitmap.recycle();
            }
            if (mOriginator != null) {
                mOriginator.setVisibility(VISIBLE);
            }
            // BEGIN: 0002231 deukmo@lge.com 2009-12-23
            // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
            if (mListener != null && mListenerStarted) {
            // END: 0002231 deukmo@lge.com 2009-12-23
                mListener.onDragEnd();
            }
        }
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        final int action = ev.getAction();

        final float x = ev.getX();
        final float y = ev.getY();

        switch (action) {
            case MotionEvent.ACTION_MOVE:
                break;

            case MotionEvent.ACTION_DOWN:
                // Remember location of down touch
                mLastMotionX = x;
                mLastMotionY = y;
                mLastDropTarget = null;
                break;

            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
		 if (mDragging) { //modified by hwang072 for bug fix 2010-03-29 
                if (mShouldDrop && drop(x, y)) {
                    mShouldDrop = false;
                }
		 }
                endDrag();
                break;
        }

        return mDragging;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (!mDragging) {
            return false;
        }

        final int action = ev.getAction();
        final float x = ev.getX();
        final float y = ev.getY();

        switch (action) {
        case MotionEvent.ACTION_DOWN:

            // Remember where the motion event started
            mLastMotionX = x;
            mLastMotionY = y;
			
            if ((x < SCROLL_ZONE) || (x > getWidth() - SCROLL_ZONE)) {
                mScrollState = SCROLL_WAITING_IN_ZONE;
                postDelayed(mScrollRunnable, SCROLL_DELAY);
            } else {
                mScrollState = SCROLL_OUTSIDE_ZONE;
            }

            break;
        case MotionEvent.ACTION_MOVE:
            final int scrollX = mScrollX;
            final int scrollY = mScrollY;

            final float touchX = mTouchOffsetX;
            final float touchY = mTouchOffsetY;

            final int offsetX = mBitmapOffsetX;
            final int offsetY = mBitmapOffsetY;

            int left = (int) (scrollX + mLastMotionX - touchX - offsetX);
            int top = (int) (scrollY + mLastMotionY - touchY - offsetY);

            final Bitmap dragBitmap = mDragBitmap;
            final int width = dragBitmap.getWidth();
            final int height = dragBitmap.getHeight();

            final Rect rect = mRect;
            rect.set(left - 1, top - 1, left + width + 1, top + height + 1);

            mLastMotionX = x;
            mLastMotionY = y;

            left = (int) (scrollX + x - touchX - offsetX);
            top = (int) (scrollY + y - touchY - offsetY);

            // Invalidate current icon position
            rect.union(left - 1, top - 1, left + width + 1, top + height + 1);

            final int[] coordinates = mDropCoordinates;
            DropTarget dropTarget = findDropTarget((int) x, (int) y, coordinates);
            if (dropTarget != null) {
                if (mLastDropTarget == dropTarget) {
                    dropTarget.onDragOver(mDragSource, coordinates[0], coordinates[1],
                        (int) mTouchOffsetX, (int) mTouchOffsetY, mDragInfo);
                } else {
                    if (mLastDropTarget != null) {
                        mLastDropTarget.onDragExit(mDragSource, coordinates[0], coordinates[1],
                            (int) mTouchOffsetX, (int) mTouchOffsetY, mDragInfo);
                    }
                    dropTarget.onDragEnter(mDragSource, coordinates[0], coordinates[1],
                        (int) mTouchOffsetX, (int) mTouchOffsetY, mDragInfo);
                }
            } else {
                if (mLastDropTarget != null) {
                    mLastDropTarget.onDragExit(mDragSource, coordinates[0], coordinates[1],
                        (int) mTouchOffsetX, (int) mTouchOffsetY, mDragInfo);
                }
            }

            invalidate(rect);

            mLastDropTarget = dropTarget;

            boolean inDragRegion = false;
            if (mDragRegion != null) {
                final RectF region = mDragRegion;
                final boolean inRegion = region.contains(ev.getRawX(), ev.getRawY());
                if (!mEnteredRegion && inRegion) {
                    mDragPaint = mTrashPaint;
                    mEnteredRegion = true;
                    inDragRegion = true;
                } else if (mEnteredRegion && !inRegion) {
                    mDragPaint = null;
                    mEnteredRegion = false;
                }
            }
            
            // BEGIN: 0002231 deukmo@lge.com 2009-12-23
            // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
            boolean isDrawerUp = false;
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
            boolean isPortrait = true;		// added
            if(mLauncher!=null) {
            	isDrawerUp = mLauncher.isDrawerUp();
            	isPortrait =  mLauncher.getOrientationstate();	// added
            }
// END LG_UI_HOME yoori.yoo 20100530 
            else{	
            	Log.d("DragLayer","mLauncher is Null !!!"); //addeed by hwang072 forWBT 2010-01-29
            }
            // END: 0002231 deukmo@lge.com 2009-12-23

// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		//added by hwang072 for Vs740 2010-01-19
               // final boolean isPortrait =  mLauncher.getOrientationstate();
// END LG_UI_HOME yoori.yoo 20100530 
            
            // BEGIN: 0002231 deukmo@lge.com 2009-12-23
            // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
            if (!inDragRegion && x < SCROLL_ZONE && !isDrawerUp) {
                if (mScrollState == SCROLL_OUTSIDE_ZONE) {
                    mScrollState = SCROLL_WAITING_IN_ZONE;
                    mScrollRunnable.setDirection(SCROLL_LEFT);
                    postDelayed(mScrollRunnable, SCROLL_DELAY);
                }
            } else if (!inDragRegion && x > getWidth() - SCROLL_ZONE && !isDrawerUp) {
                if (mScrollState == SCROLL_OUTSIDE_ZONE) {
                    mScrollState = SCROLL_WAITING_IN_ZONE;
                    mScrollRunnable.setDirection(SCROLL_RIGHT);
                    postDelayed(mScrollRunnable, SCROLL_DELAY);
                }
		//modified by hwang072 for Vs740 2010-01-19
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
            } else if (y < SCROLL_ZONE_FOR_ALLAPPS+TEXT_MESSAGE_ZONE && isDrawerUp /* && !isPortrait */) {
                if (mScrollState == SCROLL_OUTSIDE_ZONE) {
                    mScrollState = SCROLL_WAITING_IN_ZONE;
                    mScrollRunnable.setDirection(SCROLL_UP);
					// Log.d("hwang072","SCROLL_UP!!!   :  " + y+"   :  drag");
// END LG_UI_HOME yoori.yoo 20100530 
					
                    postDelayed(mScrollRunnable, SCROLL_DELAY_FOR_ALLAPPS);			
                }
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
		/* }else if (POWER_LAUNCHER_ZONE+TEXT_MESSAGE_ZONE<y && 
		              y< (SCROLL_ZONE_FOR_ALLAPPS+POWER_LAUNCHER_ZONE+TEXT_MESSAGE_ZONE)
		              && isDrawerUp && isPortrait) { */
		} else if (y > (getHeight() - SCROLL_ZONE_FOR_ALLAPPS ) && y < (getHeight()) && isDrawerUp && !isPortrait) {           
                if (mScrollState == SCROLL_OUTSIDE_ZONE) {
                    mScrollState = SCROLL_WAITING_IN_ZONE;
                    mScrollRunnable.setDirection(SCROLL_DOWN /* SCROLL_UP */);

					// Log.d("hwang072","SCROLL_UP!!!   :  " + y+"   :  drag");
// END LG_UI_HOME yoori.yoo 20100530 
					
                    postDelayed(mScrollRunnable, SCROLL_DELAY_FOR_ALLAPPS);			
                }
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
 	  // } else if (y > (getHeight() - SCROLL_ZONE_FOR_ALLAPPS - POWER_LAUNCHER_ZONE) && y < (getHeight() - POWER_LAUNCHER_ZONE) && isDrawerUp) {
             // } else if (y > (getHeight() - SCROLL_ZONE_FOR_ALLAPPS ) && y < (getHeight()) && isDrawerUp) {
            } else if (y > (getHeight() - SCROLL_ZONE_FOR_ALLAPPS - POWER_LAUNCHER_ZONE) && y < (getHeight() - POWER_LAUNCHER_ZONE) && isDrawerUp && isPortrait) {           
// END LG_UI_HOME yoori.yoo 20100530 
                if (mScrollState == SCROLL_OUTSIDE_ZONE) {
                    mScrollState = SCROLL_WAITING_IN_ZONE;
                    mScrollRunnable.setDirection(SCROLL_DOWN);
                    postDelayed(mScrollRunnable, SCROLL_DELAY_FOR_ALLAPPS);
		}
            // END: 0002231 deukmo@lge.com 2009-12-23
            } 
		else {
                if (mScrollState == SCROLL_WAITING_IN_ZONE) {
                    mScrollState = SCROLL_OUTSIDE_ZONE;
                    mScrollRunnable.setDirection(SCROLL_RIGHT);
                    removeCallbacks(mScrollRunnable);
                }
            }

            break;
        case MotionEvent.ACTION_UP:
            removeCallbacks(mScrollRunnable);
            if (mShouldDrop) {
                drop(x, y);
                mShouldDrop = false;
            }
            endDrag();

            break;
        case MotionEvent.ACTION_CANCEL:
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
           // cancelDrag(); //modified by hwang072 2010-03-16
            endDrag();
// END LG_UI_HOME yoori.yoo 20100530 
        }

        return true;
    }

    private boolean drop(float x, float y) {
        invalidate();

        final int[] coordinates = mDropCoordinates;
        DropTarget dropTarget = findDropTarget((int) x, (int) y, coordinates);

        if (dropTarget != null) {
            dropTarget.onDragExit(mDragSource, coordinates[0], coordinates[1],
                    (int) mTouchOffsetX, (int) mTouchOffsetY, mDragInfo);
            if (dropTarget.acceptDrop(mDragSource, coordinates[0], coordinates[1],
                    (int) mTouchOffsetX, (int) mTouchOffsetY, mDragInfo)) {
		//LG_VZW_LAUNCHING_KIT_DEMO
		// aud.lee 2010.09.08 LaunchKit Shortcut cannot be deleted                    
		// START yoori.yoo 20100906 : Test Shortcut cannot be deleted
            	if (mDragInfo instanceof ApplicationInfo) {
            		final ApplicationInfo item = (ApplicationInfo) mDragInfo;
        			final Intent intent = item.intent;
					if(intent != null) {
						ComponentName componentName = intent.getComponent();
						if(componentName != null) {
							String className = componentName.getClassName();
							if(className != null && className.equals("com.lge.LgHiddenMenu.LaunchKit"))
								return true;
						}
					}
        		}
            	// END yoori.yoo 20100906                     
                dropTarget.onDrop(mDragSource, coordinates[0], coordinates[1],
                        (int) mTouchOffsetX, (int) mTouchOffsetY, mDragInfo);
                mDragSource.onDropCompleted((View) dropTarget, true);
// START yoori.yoo 20100922 : VS660 Merge for OpenFolder
                mLauncher.swapDepthFolder();
// END yoori.yoo 20100922	
                return true;
            } else {
                mDragSource.onDropCompleted((View) dropTarget, false);
                return true;
            }
        }
        
        // BEGIN: 0003827 deukmo.koo@lge.com 2010-02-04
		// ADD 0003827: [Swift][LGHome] Display out of space message when shortcut is dropped from Top Menu
        if(!mLauncher.isDrawerUp() && y>0){ //modified by shinbae.lee for bug fix 2010-06-24
		Toast.makeText(getContext(), R.string.out_of_space, Toast.LENGTH_SHORT).show();
	 	}
		// END: 0003827 deukmo.koo@lge.com 2010-02-04

        return false;
    }

    DropTarget findDropTarget(int x, int y, int[] dropCoordinates) {
        return findDropTarget(this, x, y, dropCoordinates);
    }

    private DropTarget findDropTarget(ViewGroup container, int x, int y, int[] dropCoordinates) {
        final Rect r = mDragRect;
        final int count = container.getChildCount();
        final int scrolledX = x + container.getScrollX();
        final int scrolledY = y + container.getScrollY();
        final View ignoredDropTarget = mIgnoredDropTarget;

        for (int i = count - 1; i >= 0; i--) {
            final View child = container.getChildAt(i);
            if (child.getVisibility() == VISIBLE && child != ignoredDropTarget) {
                child.getHitRect(r);
                if (r.contains(scrolledX, scrolledY)) {
                    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
                    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
                    boolean isDrawerUp = false;
                    if(mLauncher!=null) {
                    	isDrawerUp = mLauncher.isDrawerUp();
                    }
                    // END: 0002231 deukmo@lge.com 2009-12-23
                    
                    DropTarget target = null;
                    if (child instanceof ViewGroup) {
                        x = scrolledX - child.getLeft();
                        y = scrolledY - child.getTop();
                        target = findDropTarget((ViewGroup) child, x, y, dropCoordinates);
                    }
                    if (target == null) {
                        if (child instanceof DropTarget) {
                            // Only consider this child if they will accept
                            DropTarget childTarget = (DropTarget) child;
                            if (childTarget.acceptDrop(mDragSource, x, y, 0, 0, mDragInfo)) {
                                dropCoordinates[0] = x;
                                dropCoordinates[1] = y;
                                // BEGIN: 0002231 deukmo@lge.com 2009-12-23
                                // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
                                // if(!isDrawerUp || child instanceof AllAppsGridView || child instanceof PowerLauncherShortcutView) {
                                if((isDrawerUp && child instanceof AllAppsGridView) ||
                                	(!isDrawerUp && !(child instanceof AllAppsGridView)) || 
                                	child instanceof PowerLauncherShortcutView) {
// END LG_UI_HOME yoori.yoo 20100530 
                                	return (DropTarget) child;
                                } else {
                                	return null;
                                }
                                // END: 0002231 deukmo@lge.com 2009-12-23
                            } else {
                                return null;
                            }
                        }
                    } else {
// START LG_UI_HOME yoori.yoo 20100530 C710(0524) merge
                        // BEGIN: 0002231 deukmo@lge.com 2009-12-23
                        // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
                        // if(!isDrawerUp || target instanceof AllAppsGridView || target instanceof PowerLauncherShortcutView) {
                    		return target;
                    	/* } else {
                    		return null;
                    	}
                    	// END: 0002231 deukmo@lge.com 2009-12-23 */
// END LG_UI_HOME yoori.yoo 20100530 
                    }
                }
            }
        }

        return null;
    }

    public void setDragScoller(DragScroller scroller) {
        mDragScroller = scroller;
    }

    public void setDragListener(DragListener l) {
        mListener = l;
    }

    @SuppressWarnings({"UnusedDeclaration"})
    public void removeDragListener(DragListener l) {
        mListener = null;
    }

    /**
     * Specifies the view that must be ignored when looking for a drop target.
     *
     * @param view The view that will not be taken into account while looking
     *        for a drop target.
     */
    void setIgnoredDropTarget(View view) {
        mIgnoredDropTarget = view;
    }

    /**
     * Specifies the delete region.
     *
     * @param region The rectangle in screen coordinates of the delete region.
     */
    void setDeleteRegion(RectF region) {
        mDragRegion = region;
    }

    private class ScrollRunnable implements Runnable {
        private int mDirection;

        ScrollRunnable() {
        }

        public void run() {
            if (mDragScroller != null) {
                // BEGIN: 0002231 deukmo@lge.com 2009-12-23
                // MOD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
                if (mDirection == SCROLL_LEFT) {
                    mDragScroller.scrollLeft();
                    mScrollState = SCROLL_OUTSIDE_ZONE;
                } else if (mDirection == SCROLL_RIGHT) {
                    mDragScroller.scrollRight();
                    mScrollState = SCROLL_OUTSIDE_ZONE;
                } else if (mDirection == SCROLL_UP) {
                    if(mAllAppsScrollView!=null) mAllAppsScrollView.scrollBy(0, -SCROLL_DISTANCE_FOR_ALLAPPS);
// START LG_UI_HOME yoori.yoo 20100810 VS660(0802) merge
                    // postDelayed(mScrollRunnable, SCROLL_DELAY_FOR_ALLAPPS);
                } else if (mDirection == SCROLL_DOWN) {
                	if(mAllAppsScrollView!=null) mAllAppsScrollView.scrollBy(0, SCROLL_DISTANCE_FOR_ALLAPPS);
                	// postDelayed(mScrollRunnable, SCROLL_DELAY_FOR_ALLAPPS);
// END LG_UI_HOME yoori.yoo 20100810 
                }
                // END: 0002231 deukmo@lge.com 2009-12-23
                mScrollState = SCROLL_OUTSIDE_ZONE;
            }
        }

        void setDirection(int direction) {
            mDirection = direction;
        }
    }
    
    // BEGIN: 0002231 deukmo@lge.com 2009-12-23
    // ADD 0002231: [Swift][TopMenu] Add Top Menu in LGHome
    void setLauncher(Launcher l) {
    	mLauncher = l;
    }
    
    void setAllAppsScrollView(ScrollView s) {
    	mAllAppsScrollView = s;
    }
    // END: 0002231 deukmo@lge.com 2009-12-23
}
