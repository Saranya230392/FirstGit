package jp.co.omronsoft.mushroom.CommonPhrase;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * The activity of phrase selection list of fixed phrase input.
 *
 * @author OMRON SOFTWARE Co., Ltd.
 */
public class CommonPhraseList extends Activity {
    /** The maximum count of registered words */
    public static final int MAX_WORD_COUNT = 50;
    /** The listview of phrase list */
    public ListView mPhraseListView;
    /** The num of phrases */
    public int mPhraseNum;
    /** The string array of phrases */
    public String[] mPhraseStr;
    /** The filename of present category */
    public String mFilename;
    /** for DEBUG */
    private final static String TAG = "iWnn";
    /** Title of list */
    private TextView list_title;
    /**
     * Called when the activity is starting.
     *
     * @see android.app.Activity#onCreate
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phrase_list_layout);

        mPhraseListView = (ListView) findViewById(R.id.phrase_list_layout);
        Bundle bundle = this.getIntent().getExtras();
        int categoryIndex = bundle.getInt("category_index");
        mFilename = bundle.getString("file_name");
        list_title = (TextView)findViewById(R.id.phraseListTitle);
        list_title.setText(bundle.getString("category_name"));
        renewPhraseListView();
        mPhraseListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                transferResult(mPhraseStr[arg2]);
            }
        });
    }

    /**
     * Called when renew the view of phrase list.
     *
     */
    protected void renewPhraseListView() {
        mPhraseNum = getPhraseNumFromFile(mFilename);
        mPhraseStr = new String[mPhraseNum];
        readPhraseFromFile(mFilename);
        int index;
        ArrayList<HashMap<String, Object>> phraseList = new ArrayList<HashMap<String, Object>>();
        for (int i = 0; i < mPhraseNum; i++) {
            HashMap<String, Object> phrase = new HashMap<String, Object>();
            index = i + 1;
            phrase.put("number", "[" + index + "]");
            phrase.put("phrase", mPhraseStr[i]);
            phraseList.add(phrase);
        }

        SimpleAdapter phraseItems = new SimpleAdapter(this,
            phraseList,
            R.layout.phrase_item_layout,
            new String[] { "number", "phrase"},
            new int[] { R.id.number, R.id.phrase});
        mPhraseListView.setAdapter(phraseItems);
    }

    /**
     * Called when transfer result to the parent activity.
     *
     * @param result The result which is to be sent.
     */
    private void transferResult(String result) {
        Intent phraseResult = new Intent();
        phraseResult.putExtra("PHRASE_RESULT", result);
        setResult(RESULT_OK, phraseResult);
        finish();
    }

    /**
     * Get the num of phrases from mounted file.
     *
     * @param filename The name of mounted file.
     */
    private int getPhraseNumFromFile(String filename) {
        int phraseNum = 0;
        FileInputStream input = null;
        InputStreamReader ir = null;
        BufferedReader rb = null;
        //Get number of phrases
        try {
            input = openFileInput(filename);
            ir = new InputStreamReader(input);
            rb = new BufferedReader(ir);
            while (rb.readLine() != null && phraseNum < MAX_WORD_COUNT) {
                phraseNum++;
            }
            rb.close();
            ir.close();
            input.close();
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Not found a user orienginal data file", e);
        } catch (IOException e) {
            Log.e(TAG, "Fail to write user orienginal data file", e);
        } finally {
            try {
                if (rb != null)
                    rb.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close BufferedWriter", e);
            }
            try {
                if (ir != null)
                    ir.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close OutputStreamWriter", e);
            }
            try {
                if (input != null)
                    input.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close FileOutputStream", e);
            }
        }
        return phraseNum;
    }

    /**
     * Read phrases from mounted file.
     *
     * @param  filename  The name of mounted file.
     */
    private void readPhraseFromFile(String filename) {
        /* Read all phrases to phrase array */
        FileInputStream input = null;
        InputStreamReader ir = null;
        BufferedReader rb = null;
        try {
            input = openFileInput(filename);
            ir = new InputStreamReader(input);
            rb = new BufferedReader(ir);
            for (int i = 0; i < mPhraseNum; i++) {
                mPhraseStr[i] = rb.readLine();
            }
            rb.close();
            ir.close();
            input.close();
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Not found a user orienginal data file", e);
        } catch (IOException e) {
            Log.e(TAG, "Fail to write user orienginal data file", e);
        } finally {
            try {
                if (rb != null)
                    rb.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close BufferedWriter", e);
            }
            try {
                if (ir != null)
                    ir.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close OutputStreamWriter", e);
            }
            try {
                if (input != null)
                    input.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close FileOutputStream", e);
            }
        }
    }
}
