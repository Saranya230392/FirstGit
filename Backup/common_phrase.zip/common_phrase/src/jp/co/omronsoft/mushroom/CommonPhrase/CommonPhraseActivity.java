package jp.co.omronsoft.mushroom.CommonPhrase;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * The activity of category selection list of fixed phrase input.
 *
 * @author OMRON SOFTWARE Co., Ltd.
 */
public class CommonPhraseActivity extends Activity {
    /** The request code of selected phrase from FixedPhraseList */
    static final int SHOW_PHRASE_LIST = 0;
    /** The key name of intent for Mushroom */
    private static final String REPLACE_KEY = "replace_key";
    /** The flag of default file type */
    private static final int FILE_TYPE_DEFAULT = 0;
    /** The flag of user file type */
    private static final int FILE_TYPE_USER = 1;
    /** The default chosen language is EN_US */
    private static final int DEFAULT_CHOOSE_LANG = 10;
    /** The num of phrase categories */
    private int mCategoryNum;
    /** The value of choose language */
    private int mLanguageIndex;
    /** for DEBUG */
    private final static String TAG = "iWnn";
    /** The name of SharedPreferences */
    private static final String commonPhrase = "LanguageSelection";
    /** The instance variable of SharedPreferences */
    SharedPreferences languageSet;
    /** The types of mounted files: [0]defalt [1]user  */
    int[] mFileTypes;
    /** The filenames which are mounted */
    String[] mFileNames;
    /** The array of language entries */
    String[] languageEntries;
    /** The array of language values */
    String[] languageValues;
    /** The array of category names */
    String[] categoryNames;
    /** The array of category summaries */
    String[] categorySummaries;

    /**
     * Called when the activity is starting.
     *
     * @see android.app.Activity#onCreate
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.commonphraseinput_main);
        languageSet = getSharedPreferences(commonPhrase, 0);
        mLanguageIndex = languageSet.getInt("languageValue", DEFAULT_CHOOSE_LANG);
        languageEntries = getResources().getStringArray(R.array.choose_language_entry);
        languageValues = getResources().getStringArray(R.array.choose_language_value);
        renewCommonPhraseView();
    }

    /**
     * Called when renew the view of phrase list.
     *
     */
    protected void renewCommonPhraseView() {
        mFileNames = getResources().getStringArray(R.array.file_names);
        for (int i=0; i<mFileNames.length; i++){
            mFileNames[i] += "_" + languageValues[mLanguageIndex];
        }

        mFileTypes = getResources().getIntArray(R.array.file_types);
        categoryNames = getResources().getStringArray(R.array.category_names);
        categorySummaries = getResources().getStringArray(R.array.category_summary);

        // Add menu item
        ListView languageList = (ListView) findViewById(R.id.LanguageSelectView);
        ArrayList<HashMap<String, Object>> menuList = new ArrayList<HashMap<String, Object>>();
        HashMap<String, Object> menuItem = new HashMap<String, Object>();
        menuItem.put("ItemTitle", getResources().getString(R.string.ti_preference_choose_language_of_keyboard_title_txt));
        menuItem.put("ItemText", languageEntries[mLanguageIndex]);
        menuList.add(menuItem);
        SimpleAdapter langItemAdapter = new SimpleAdapter(this,menuList,
                R.layout.category_item_layout,
                new String[] {"ItemTitle", "ItemText"},
                new int[] {R.id.ItemTitle,R.id.ItemText}
        );

        languageList.setAdapter(langItemAdapter);
        languageList.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                mLanguageIndex = languageSet.getInt("languageValue", DEFAULT_CHOOSE_LANG);
                showLanguageChooseDialog();
            }
        });
        
        ListView list = (ListView) findViewById(R.id.CategoryListView);
        
        // Add category list
        ArrayList<HashMap<String, Object>> categoryList = new ArrayList<HashMap<String, Object>>();
        mCategoryNum = categoryNames.length;
        for(int i=0;i < mCategoryNum; i++) {
            HashMap<String, Object> categoryItem = new HashMap<String, Object>();
            categoryItem.put("ItemTitle", categoryNames[i]);
            categoryItem.put("ItemText", categorySummaries[i]);
            categoryList.add(categoryItem);
        }

        for(int i=0; i < mCategoryNum; i++) {
            if (mFileTypes[i] == FILE_TYPE_DEFAULT) {
                copyAssetsToLocal(mFileNames[i], mFileNames[i]);
            }
        }

        SimpleAdapter listItemAdapter = new SimpleAdapter(this,categoryList,
            R.layout.category_item_layout,
            new String[] {"ItemTitle", "ItemText"},
            new int[] {R.id.ItemTitle,R.id.ItemText}
        );
        list.setAdapter(listItemAdapter);
        list.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                Intent intentCategoryIndex = new Intent();
                if (mFileTypes[arg2] == FILE_TYPE_DEFAULT){
                    intentCategoryIndex.setClass(CommonPhraseActivity.this, CommonPhraseList.class);
                } else {
                    intentCategoryIndex.setClass(CommonPhraseActivity.this, UserCommonPhraseList.class);
                }
                Bundle bundle = new Bundle();
                bundle.putInt("category_index", arg2);
                bundle.putString("file_name", mFileNames[arg2]);
                bundle.putString("category_name", categoryNames[arg2]);
                intentCategoryIndex.putExtras(bundle);
                startActivityForResult(intentCategoryIndex, SHOW_PHRASE_LIST);
            }
        });       
    }

    /**
     * Called when send selected phrase to Mushroom.
     *
     * @param requestCode The integer request code originally supplied to startActivityForResult().
     * @param resultCode  The integer result code returned by the child activity through its setResult().
     * @param data        An Intent, which can return result data to the caller (various data can be attached to Intent "extras").
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == SHOW_PHRASE_LIST) {
            if (resultCode == RESULT_OK) {
                String result = data.getStringExtra("PHRASE_RESULT");
                Intent transferMushroom = new Intent();
                transferMushroom.putExtra(REPLACE_KEY, result);
                setResult(RESULT_OK, transferMushroom);
                finish();
            }
        }
    }

    /**
     * Copy files in assets folder to local folder when this apk is started for the first time.
     *
     * @param srcFileName   The name of source file.
     * @param distFileName  The name of dist file.
     */
    private void copyAssetsToLocal(String srcFileName, String distFileName){
        String pathName = "/data/data/" + getPackageName() + "/files/" + distFileName;
        File file = new File(pathName);
        if(file.exists()){
            return;
        }
        InputStream input = null;
        FileOutputStream output = null;
        try {
            input = getAssets().open(srcFileName);
            output = openFileOutput(distFileName, MODE_PRIVATE);
            byte[] buffer = new byte[1024];
            int n = 0;
            while ((n = input.read(buffer)) != -1) {
                output.write(buffer, 0, n);
            }
            output.close();
            input.close();
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Not found a common phrase data file", e);
        } catch (IOException e) {
            Log.e(TAG, "Fail to read common phrase data file", e);
        } finally {
            try {
                if (input != null)
                    input.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close InputStream", e);
            }
            try {
                if (output != null)
                    output.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close FileOutputStream", e);
            }
        }
    }

    /**
     * Shows language choosing dialog.
     *
     */
    private void showLanguageChooseDialog(){
        // Create a build for dialog.
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setNegativeButton(R.string.ti_dialog_button_cancel_txt, null);

        // Dialog items' process.
        builder.setSingleChoiceItems(languageEntries, mLanguageIndex, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface inputLanguageSelectDialog, int position) {
                mLanguageIndex = position;
                SharedPreferences.Editor editor = languageSet.edit();
                editor.putInt("languageValue", mLanguageIndex);
                editor.commit();
                inputLanguageSelectDialog.dismiss();
                renewCommonPhraseView();
            }
        });

        AlertDialog langMenu = builder.create();
        langMenu.setTitle(R.string.ti_preference_choose_language_of_keyboard_title_txt);
        langMenu.show();
    }
}
