package jp.co.omronsoft.mushroom.CommonPhrase;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

/**
 * The activity of phrase selection list for user data.
 *
 * @author OMRON SOFTWARE Co., Ltd.
 */
public class PhraseEdit extends Activity {

    /** The view of save button */
    private Button mButtonAdd;
    /** The view of cancel button */
    private Button mButtonCancel;
    /** The view of edit field for phrase */
    private EditText mFieldPhrase;

    /**
     * Called when the activity is starting.
     *
     * @see android.app.Activity#onCreate
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.phrase_edit_layout);
        Bundle bundle = this.getIntent().getExtras();
        String categoryIndex = bundle.getString("edit_phrase");
        findViews();
        mFieldPhrase.setText(categoryIndex);
        if (categoryIndex.length() != 0) {
            mButtonAdd.setEnabled(true);
        } else {
            mButtonAdd.setEnabled(false);
        }

        mButtonAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String phrase = mFieldPhrase.getText().toString();
                if (phrase != null && phrase.length() != 0) {
                    savePhrase(phrase);
                }
            }
        });
        mButtonCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                finish();
            }
        });

        /* set control buttons */
        setAddButtonControl();
    }

    /**
     * Called when set resource ID for Button and EditText View.
     *
     */
    private void findViews() {
        mButtonAdd = (Button)findViewById(R.id.addButton);
        mButtonCancel = (Button)findViewById(R.id.cancelButton);
        mFieldPhrase = (EditText)findViewById(R.id.editPhrase);
    }

    /**
     * Called when transfer result to the parent activity.
     *
     * @param result The result which is to be sent.
     */
    private void savePhrase(String result) {
        Intent phraseResult = new Intent();
        phraseResult.putExtra("PHRASE_RESULT", result);
        setResult(RESULT_OK, phraseResult);
        finish();
    }

     /**
     * Change the state of the "Add" button into the depending state of input area.
     */
    public void setAddButtonControl() {
        /* Text changed listener for the reading text */
        mFieldPhrase.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable s) {
            }
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                /* Enable/disable the "Add" button */
                if (mFieldPhrase.getText().toString().length() != 0) {
                    mButtonAdd.setEnabled(true);
                } else {
                    mButtonAdd.setEnabled(false);
                }
            }
        });
    }
}
