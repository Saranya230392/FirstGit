package jp.co.omronsoft.mushroom.CommonPhrase;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView.AdapterContextMenuInfo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 * The activity of phrase selection list for user data.
 *
 * @author OMRON SOFTWARE Co., Ltd.
 */
public class UserCommonPhraseList extends CommonPhraseList {
    /** for DEBUG */
    private final static String TAG = "iWnn";
    /** The menu ID of ADD item */
    private static final int MENU_ID_ADD = 0;
    /** The menu ID of CLEAR item */
    private static final int MENU_ID_CLEAR = 1;
    /** The menu ID of DEL item */
    private static final int MENU_ID_DEL = 2;
    /** The menu ID of EDIT item */
    private static final int MENU_ID_EDIT = 3;
    /** The request code of add phrase intent */
    private static final int ADD_PHRASE = 0;
    /** The request code of edit phrase intent */
    private static final int EDIT_PHRASE = 1;
    /** The item order which is long pressed */
    private int mSelectOrder = 0;
    /** The state of "Add" menu item */
    private boolean mAddMenuEnabled;
    /** The state of "Initialize" menu item */
    private boolean mInitMenuEnabled;
    /** The flag whether menu has been initialized */
    private boolean mMenuInitialized;
    /** Widgets which constitute this screen of activity */
    private Menu mMenu;

    /**
     * Called when the activity is starting.
     *
     * @see android.app.Activity#onCreate
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        mMenuInitialized = false;
        super.onCreate(savedInstanceState);
        registerForContextMenu(this.mPhraseListView);
    }

    /**
     * Create option menu which includes add option and clear option.
     *
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        /* initialize the menu */
        menu.clear();

        if (mPhraseNum > 0) {
            mInitMenuEnabled = true;
        } else {
            mInitMenuEnabled = false;
        }

        if (mPhraseNum >= MAX_WORD_COUNT) {
            mAddMenuEnabled = false;
        } else {
            mAddMenuEnabled = true;
        }

        menu.add(Menu.NONE, MENU_ID_ADD, Menu.NONE, R.string.ti_category_option_menu_add_name)
            .setIcon(android.R.drawable.ic_menu_add)
            .setEnabled(mAddMenuEnabled);
        menu.add(Menu.NONE, MENU_ID_CLEAR, Menu.NONE, R.string.ti_category_option_menu_clear_name)
            .setIcon(android.R.drawable.ic_menu_delete)
            .setEnabled(mInitMenuEnabled);

        mMenu = menu;
        mMenuInitialized = true;
        return super.onCreateOptionsMenu(menu);
    }

    /**
     * This hook is called whenever an item in your options menu is selected.
     *
     * @param item     The menu item that was selected.
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        boolean ret = true;
        switch (item.getItemId()) {
        default:
            ret = super.onOptionsItemSelected(item);
            break;
        case MENU_ID_ADD:
            Intent intentAddPhrase = new Intent();
            intentAddPhrase.setClass(this, PhraseEdit.class);
            Bundle bundle = new Bundle();
            bundle.putString("edit_phrase", "");
            intentAddPhrase.putExtras(bundle);
            startActivityForResult(intentAddPhrase, ADD_PHRASE);
            ret = true;
            break;
        case MENU_ID_CLEAR:
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.ti_delete_all_user_data_txt);
            builder.setPositiveButton(R.string.ti_dialog_button_ok_txt, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    String pathName = "/data/data/" + getPackageName() + "/files/" + mFilename;
                    File file = new File(pathName);
                    if(file.exists() && file.isFile()){
                        deleteFile(mFilename);
                        mPhraseNum = 0;
                        if (mMenuInitialized) {
                            onCreateOptionsMenu(mMenu);
                        }
                        renewPhraseListView();
                    }
                }});
            builder.setNegativeButton(R.string.ti_dialog_button_cancel_txt, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {

                }});
            builder.setCancelable(true);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
            ret = true;
            break;
        }
        return ret;
    }

     /**
     * Called when save user phrase list to file.
     *
     * @param filename  The name of dist file.
     */
    private void savePhraseToFile(String filename) {
        int i = 0;
        //Get number of phrases
        FileOutputStream output = null;
        OutputStreamWriter ir = null;
        BufferedWriter rb = null;
        try {
            deleteFile(filename);
            output = openFileOutput(filename, MODE_PRIVATE);
            ir = new OutputStreamWriter(output);
            rb = new BufferedWriter(ir);
            while (i < mPhraseNum) {
                rb.write(mPhraseStr[i]);
                rb.newLine();
                i++;
            }
            rb.close();
            ir.close();
            output.close();
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Not found a user orienginal data file", e);
        } catch (IOException e) {
            Log.e(TAG, "Fail to write user orienginal data file", e);
        } finally {
            try {
                if (rb != null)
                    rb.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close BufferedWriter", e);
            }
            try {
                if (ir != null)
                    ir.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close OutputStreamWriter", e);
            }
            try {
                if (output != null)
                    output.close();
            } catch (IOException e) {
                Log.e(TAG, "Fail to close FileOutputStream", e);
            }
        }
    }

    /**
     * Called when the context menu for this view is being built. It is not safe to hold onto the menu after this method returns.
     *
     * @param menu     The context menu that is being built.
     * @param v     The view for which the context menu is being built.
     * @param menuInfo     Extra information about the item for which the context menu should be shown.
     */
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE, MENU_ID_DEL, 0, R.string.ti_category_option_menu_del_name);
        menu.add(Menu.NONE, MENU_ID_EDIT, 0, R.string.ti_category_option_menu_edit_name);
    }

    /**
     * This hook is called whenever an item in a context menu is selected.
     *
     * @param item     The context menu item that was selected.
     */
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
        mSelectOrder = (int)info.id;
        switch(item.getItemId()) {
        case MENU_ID_DEL:
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage(R.string.ti_delete_user_data_txt);
            builder.setPositiveButton(R.string.ti_dialog_button_ok_txt, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    for (int i = mSelectOrder; i < mPhraseNum - 1; i++){
                        mPhraseStr[i] = mPhraseStr[i+1];
                    }
                    mPhraseNum--;
                    if ((mPhraseNum == 0) || (mPhraseNum == MAX_WORD_COUNT - 1)) {
                        if (mMenuInitialized) {
                            onCreateOptionsMenu(mMenu);
                        }
                    }
                    savePhraseToFile(mFilename);
                    renewPhraseListView();
                }});
            builder.setNegativeButton(R.string.ti_dialog_button_cancel_txt, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                }});
            builder.setCancelable(true);
            AlertDialog alertDialog = builder.create();
            alertDialog.show();
            break;
        case MENU_ID_EDIT:
            Intent intentEditPhrase = new Intent();
            intentEditPhrase.setClass(this, PhraseEdit.class);
            Bundle bundle = new Bundle();
            bundle.putString("edit_phrase", mPhraseStr[mSelectOrder]);
            intentEditPhrase.putExtras(bundle);
            startActivityForResult(intentEditPhrase, EDIT_PHRASE);
            break;
        default:
            break;
        }
        return super.onContextItemSelected(item);
    }

    /**
     * Called when send selected phrase to Mushroom.
     *
     * @param requestCode The integer request code originally supplied to startActivityForResult().
     * @param resultCode  The integer result code returned by the child activity through its setResult().
     * @param data        An Intent, which can return result data to the caller (various data can be attached to Intent "extras").
     */
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ADD_PHRASE) {
            if (resultCode == RESULT_OK) {
                FileOutputStream output = null;
                OutputStreamWriter ir = null;
                BufferedWriter rb = null;
                try {
                    String result = data.getStringExtra("PHRASE_RESULT");
                    output = openFileOutput(mFilename, MODE_APPEND);
                    ir = new OutputStreamWriter(output);
                    rb = new BufferedWriter(ir);
                    rb.write(result);
                    rb.newLine();
                    rb.close();
                    output.close();
                } catch (FileNotFoundException e) {
                    Log.e(TAG, "Not found a user orienginal data file", e);
                } catch (IOException e) {
                    Log.e(TAG, "Fail to write user orienginal data file", e);
                } finally {
                    try {
                        if (rb != null)
                            rb.close();
                    } catch (IOException e) {
                        Log.e(TAG, "Fail to close BufferedWriter", e);
                    }
                    try {
                        if (ir != null)
                            ir.close();
                    } catch (IOException e) {
                        Log.e(TAG, "Fail to close OutputStreamWriter", e);
                    }
                    try {
                        if (output != null)
                            output.close();
                    } catch (IOException e) {
                        Log.e(TAG, "Fail to close FileOutputStream", e);
                    }
                }
                renewPhraseListView();
                if ((mPhraseNum == 1) || (mPhraseNum == MAX_WORD_COUNT)) {
                      if (mMenuInitialized) {
                        onCreateOptionsMenu(mMenu);
                    }
                }
            }
        }
        if (requestCode == EDIT_PHRASE) {
            if (resultCode == RESULT_OK) {
                String result = data.getStringExtra("PHRASE_RESULT");
                mPhraseStr[mSelectOrder] = result;
                savePhraseToFile(mFilename);
                renewPhraseListView();
            }
        }
    }
}
